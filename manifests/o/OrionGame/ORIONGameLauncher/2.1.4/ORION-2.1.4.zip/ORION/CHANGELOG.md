# Journal des versions d'ORION

Chaque version d'ORION est testée sur une vraie machine de joueur avant de sortir. Les grandes étapes, de la plus récente à la première.

## 2.1.4 — Fermeture sans fausse alerte
17 octobre 2026 · suite d'un signalement (ORION 2.1.2, « Arrêt brutal » au premier lancement)

- Correction : une session coupée pendant sa fermeture (fermeture lente arrêtée par Windows ou par le Gestionnaire des tâches) était présentée au lancement suivant comme un plantage, avec la question « ORION s'est arrêté brutalement ». La fermeture est maintenant notée dès qu'elle est demandée : seul un vrai arrêt pendant l'utilisation ouvre la question.
- Nouveau : si ORION plante vraiment (erreur de Windows, d'un pilote ou d'une bibliothèque, hors de Python), la trace du plantage est gardée et jointe au rapport de signalement, avec la façon dont la session précédente s'est terminée et la provenance d'ORION (Microsoft Store ou installateur). Rien ne part sans votre accord.
- Correction : après la fermeture de la fenêtre, un téléchargement encore en cours (outil de mesure des images par seconde, visuels) gardait ORION en vie sans fenêtre jusqu'à sa fin : un nouveau lancement ne montrait rien. ORION s'arrête au plus tard 3 s après la fermeture.

## 2.1.3 — Fermeture nette
16 octobre 2026 · correctifs trouvés à la relecture de la 2.1.2 et dans le journal de l'auteur

- Correction : ORION mettait cinq secondes à se fermer, à chaque fois (il attendait le fil d'écriture de la base, qui ne se termine jamais). Il se ferme dès que tout est écrit, en général aussitôt.
- Correction : à la fermeture, la dernière version de la bibliothèque pouvait être recouverte par une version plus ancienne encore en cours d'écriture. Une seule file d'écriture, dans l'ordre des dépôts.
- Correction : après une partie mesurée, la fiche ouverte sur ce jeu n'était pas recalculée (le calcul partait du fil de surveillance de la partie, et son résultat n'était jamais livré) : « Jouer » reprenait le plan d'avant la partie.
- Correction : la bibliothèque est écrite avant le redémarrage pour une mise à jour, et un appel différé demandé depuis un fil de fond est maintenant honoré (il ne partait jamais).
- Correction : la fiche d'un jeu dont le dossier est sur un disque débranché (jonction vers un disque externe) affichait « Erreur : Fonction incorrecte » à chaque calcul des réglages (281 fois dans un journal). Le dossier est tenu pour absent et les réglages se calculent quand même ; ils seront écrits quand le disque sera de retour.
- Correction : la boîte « Copie de jeu interrompue » s'ouvrait à chaque lancement d'ORION quand un jeu déplacé était sur un disque externe débranché. Ce n'est pas une copie interrompue : une notification discrète le dit (« Disque absent pour le moment »), et la boîte ne sert plus qu'aux vraies copies à vérifier.
- Correction : les conseils des recettes (Rocket League, Apex Legends, Counter-Strike 2, Elden Ring, GTA V...) et les messages « X : en cours » et « X démarre... » sont traduits en anglais.
- Retouche : dans la fiche d'un jeu, l'ancrage des cartes de graphismes après un clic marche aussi quand le joueur n'a pas encore fait défiler la page.
- Site : les clics faits depuis la page « Jeux gratuits » étaient comptés « autre » (les scripts cherchaient une ancienne adresse).

## 2.1.2 — Retouches
16 octobre 2026 · nouveautés et correctifs

- Nouveau : ORION se lance au démarrage de Windows, réduit dans la barre des tâches : la veille des prix et de vos jeux tourne sans que vous l'ouvriez, et un clic le rouvre en grand. Pour l'éviter, décochez « Lancer ORION au démarrage de Windows », en tête des Réglages (la même case est dans l'installateur) ; ORION figure aussi dans le Gestionnaire des tâches, onglet Applications de démarrage, où il se coupe d'un clic.
- Nouveau : la recherche de la Boutique, comme sur un site de vente de jeux. La barre est en haut de la page, à côté des onglets, et sert aussi depuis « Gratuits en ce moment ». Dès la première lettre, une liste s'ouvre sous la barre : les jeux trouvés avec leur visuel, leur boutique, la remise et le prix, les types de jeux qui correspondent, puis « Voir les résultats » pour la page complète, avec ses filtres et son tri. Champ vide : les fiches vues récemment, ou les jeux du moment. Fautes et sigles acceptés (gta, bg3, cyberpounk), flèches du clavier et Entrée.
- Correction : les estimations suivent tout ce que l'éditeur promet. Monster Hunter Wilds donne sa configuration recommandée pour 60 images par seconde avec la génération d'images, en réglages Moyens : ORION lisait 60 images par seconde en Haute et annonçait deux fois trop. Le préréglage, la génération d'images et la mise à l'échelle écrits par l'éditeur sont maintenant comptés (Stalker 2, Silent Hill 2, Stellar Blade, Nioh 3…), et les jeux bloqués à 60 images par seconde (Elden Ring, Dark Souls, Sekiro, les jeux de combat) ne sont plus annoncés au-delà. Les jeux qui exigent une carte graphique avec ray tracing matériel (DOOM: The Dark Ages, Indiana Jones et le Cercle Ancien, Ace Combat 8) étaient annoncés jouables sur des cartes qui ne le calculent pas, où ils ne se lancent pas : ORION le dit maintenant, et indique quelle carte il faudrait.
- Nouveau : les codes promo des revendeurs partenaires. Quand Kinguin, Instant Gaming ou Loaded envoie un code de réduction, il s'affiche sous son lien dans la fiche du jeu, avec ses conditions, tant qu'il est valable, puis disparaît seul. Premier code : SPOOK5, −5 % chez Kinguin jusqu'au 31 octobre. Un code annoncé après cette version arrive quand même : ORION relit la liste sur son site au plus une fois par six heures.
- Nouveau : les jeux prêtés par votre famille Steam sont marqués « (Steam Family) » sur la carte de joueur et dans la valeur de la bibliothèque (ils restent comptés), et la case « Steam Family » de la bibliothèque les affiche ou les cache.
- Correction : les jeux offerts par IndieGala étaient présentés comme un téléchargement direct sans compte ; il faut en fait un compte IndieGala gratuit, et ORION le dit. Leur valeur annoncée par IndieGala (29,99 $ pour des jeux sans rapport entre eux) n'est plus affichée.
- Plus fluide : la fenêtre « Valeur estimée de ma bibliothèque » s'ouvre tout de suite (elle restait figée plus d'une seconde avec 400 jeux), la liste se complète en un instant. Et la mesure de fluidité ne compte plus comme accrochages les arrêts quand ORION est derrière un jeu, ni le temps passé dans une fenêtre de Windows (choisir un fichier ou un dossier).
- Nouveau : « Donnez votre avis », un petit lien discret sous l'encart de version, en bas à gauche. Trois questions courtes (ce qui vous sert, ce qui vous gêne, ce qui manque) et un choix : ORION à la place de votre launcher habituel, oui, peut-être ou non. La fenêtre ne s'ouvre jamais d'elle-même ; rien ne part sans le bouton Envoyer, sans rapport technique.
- Correction : une partie mesurée pendant que le jeu était en arrière-plan (bridé par Windows à 15 ou 30 images par seconde) pouvait servir de référence : Aniimo était annoncé à ~20 i/s en Basse au lieu de ~115. ORION ne compte plus que les moments où le jeu est au premier plan, et une mesure douteuse ne remplace jamais une bonne.
- Correction : la fiche d'un jeu sautait jusqu'aux cartes de graphismes à l'ouverture, puis remontait (le plan arrivait avant les captures et les vidéos, et les cartes étaient ancrées sur une page encore courte). L'ancrage ne sert plus qu'après un clic sur une carte.
- Plus fluide : l'ouverture d'une fiche ne fige plus la fenêtre. La bibliothèque n'est plus réécrite à chaque fiche ouverte (et jamais depuis le fil de l'interface), la liste des jeux réservés aux adultes est gardée en mémoire, les vignettes des captures sont lues hors de l'interface, et la bande-annonce ne démarre qu'une fois la fiche posée.
- Correction : au lancement d'un jeu, ORION ne se réduit plus après 1,5 s mais quand la fenêtre du jeu apparaît (Rocket League et Steam mettaient 40 s : bureau vide). En attendant, « X démarre... » reste affiché.
- Nouveau : Rocket League est réglé par ORION (TASystemSettings.ini : définition, plein écran, synchronisation verticale, ombres, filtrage, effets). La limite d'images et l'anticrénelage restent dans le menu du jeu.
- Correction : « Réglage utilisé » n'apparaît plus sur la carte d'un jeu qu'ORION ne règle pas lui-même (jeu qui gère ses réglages) : la carte est un conseil.
- Correction : si le joueur accepte le partage anonyme après la 12e seconde, l'ouverture de sa première session est maintenant comptée.
- Correction : ORION plantait quand une rangée de DLC débordait de la fenêtre et se redessinait, par exemple au passage en affichage salon avec la manette (signalement n° 5). La rangée peint maintenant ses propres cartes.
- Correction : un jeu déplacé sur un disque qui ne répond plus (jonction vers un disque externe débranché) arrêtait net l'analyse de la bibliothèque, la veille des installations et la remise en ordre : plus aucun jeu n'était réexaminé. ORION le note « disque absent pour le moment » et passe au suivant ; le jeu revient avec son disque.
- Correction : la manette agit seulement quand ORION est au premier plan. Derrière un jeu, X relançait le jeu (« déjà lancé » six fois de suite) et Start basculait ORION en affichage salon. Les boutons A et B répondaient aux gâchettes LB et RB : les vrais A et B sont lus.
- Correction : une seule partie mesurée moins bonne que prévu (enregistrement d'écran, autre fenêtre devant) divisait toutes les estimations du PC, parfois par deux. Une partie hachée ou douteuse ne sert plus de référence, et une seule partie n'abaisse les estimations que de 25 % au plus ; il en faut deux qui s'accordent pour aller plus bas.
- Correction : sans recette, ORION supposait que tout jeu réglé dans son menu proposait DLSS, FSR ou XeSS (Rocket League se voyait conseiller « Ultra + DLSS »). La super-résolution n'est proposée que si la recette ou la fiche Steam du jeu la cite.
- Retouche : sur la carte de joueur, un point du fond placé devant le logo ORION se lisait comme une puce ; il a été retiré.
- Retouche : dans la fiche d'un jeu, la carte « Votre écran » retrouve son accent, et la note des modifications prévues ne parle plus du bouton Restaurer, remplacé en 2.1.0 par « Redéfinir les paramètres par défaut ».
- Retouche : les jeux gratuits sans DRM ne sont plus annoncés « sur Sans DRM », et leur prix habituel s'écrit comme les autres prix (29,99 $ et non 29.99 USD).

## 2.1.1 — On travaille aussi le dimanche 😅
11 octobre 2026 · nouveautés et correctifs

- **Nouveau : « Valeur estimée de ma bibliothèque ».** En haut de la bibliothèque, un clic ouvre la liste des jeux comptés, du plus cher au moins cher, avec la boutique d'où vient chaque prix (Steam, Boutique, fiche du jeu), le total aux prix du moment, les jeux gratuits et ceux sans prix connu. À droite, votre carte de joueur : un pseudo et une photo de profil si vous le voulez, gardés sur ce PC et écrits seulement sur l'image, le total et vos trois jeux les plus chers ; l'aperçu suit chaque changement. « Enregistrer l'image » la range où vous voulez (PNG, 1200 x 630), prête à poster.
- **Correction : « Partager en image » ne promet plus de copie.** Le bilan de Ma machine annonçait une copie dans le presse-papiers qui ne donnait rien à coller : l'image est enregistrée là où vous voulez.
- **Correction : la consigne d'achat des clés suit votre pays.** Elle disait « région Global ou Europe » à tout le monde, alors qu'une clé Europe ne s'active pas aux États-Unis. Elle dit maintenant Global ou Europe, États-Unis, Royaume-Uni ou Amérique du Nord, selon le pays choisi dans les Réglages. Kinguin filtrait déjà les clés activables dans votre pays ; Instant Gaming et Loaded n'ont pas ce filtre, la consigne est leur garde.

## 2.1.0 — Votre écran ou votre choix, et tous les jeux
11 octobre 2026 · nouveautés

**L'essentiel**
- **Nouveau : les graphismes d'un jeu, en deux cartes et rien d'autre.** « Votre écran » : votre écran affiche 60, 144, 165 ou 240 images par seconde, ORION lit vos composants et cherche, du plus beau au plus léger (Ultra, Haute, Moyenne, Basse, avec DLSS, FSR ou XeSS quand ça aide), le premier réglage qui tient cet objectif de façon stable ; si même Basse ne le tient pas, il descend par paliers. Après une partie mesurée, il repart des images par seconde réellement vues et se corrige tout seul. « Mon choix » : vous choisissez les graphismes (Ultra par défaut) et les images par seconde ; ORION montre ce que ça donne sur votre PC, puis écrit ce niveau et bride le jeu sur les images demandées. Un clic écrit tout de suite, après sauvegarde ; « Redéfinir les paramètres par défaut » remet le jeu dans l'état d'avant la première intervention d'ORION. Les profils Esport, Détente et Photoréaliste disparaissent.
- **Nouveau : ORION règle bien plus de jeux que Steam et Unreal.** Nouveaux formats lus et écrits sur place (XML, KeyValues de Valve, texte « clé valeur ») et recettes pour GTA V et Red Dead Redemption 2, Far Cry, Battlefield et les jeux EA (Frostbite), Skyrim, Fallout et Starfield, Elden Ring, Baldur's Gate 3, The Witcher 3, Apex Legends et Minecraft. Pour un jeu inconnu, ORION cherche son fichier de réglages et n'y touche qu'aux clés sûres (définition, plein écran, synchronisation, limite d'images) ; les niveaux restent au guide. Jamais une clé inventée, jamais une valeur d'une autre forme que celle en place, sauvegarde avant, relecture après.
- **Nouveau : les précommandes dans la page Sorties, et Call of Duty: Modern Warfare 4 à la une.** Chaque sortie en précommande sur Steam affiche son prix. La sortie à la une a son bloc prix, relu toutes les 10 minutes : le prix officiel d'abord, puis, à part, la clé Steam vérifiée la moins chère chez un revendeur quand elle existe, et l'offre de fidélité de Steam (-10 % sur l'édition Coffre d'armes) si un Call of Duty est dans votre bibliothèque. Le jour de la sortie, une notification, une seule. Kingmakers rejoint la liste, sans date : l'éditeur n'en a pas annoncé.
- **Nouveau : quand votre PC retient un jeu, des pièces neuves qui vont dans votre PC.** Sous « ce qu'il manque » dans Ma machine, ORION cite des pièces compatibles avec ce qu'il a lu : une carte graphique sur un PC de bureau seulement (en rappelant de vérifier l'alimentation et la place), un processeur du même support que le vôtre (AM4, AM5, LGA1700...), de la mémoire du même type et du même format que vos barrettes. Chaque pièce ouvre une recherche chez un revendeur de matériel neuf (LDLC, Materiel.net) ; sans compatibilité vérifiée, pas de lien. Aucun programme partenaire n'est signé : les liens sont des recherches ordinaires, et le jour où l'un le devient, il sera marqué « lien partenaire ».

**Dans le détail**

Réglages des jeux
- Correction : la mesure des images par seconde ne fonctionnait plus depuis le passage à PresentMon 2 : ORION lui passait une option disparue (`--no_top`) et PresentMon s'arrêtait aussitôt. Aucune partie n'était mesurée, donc les réglages ne pouvaient pas apprendre de vos parties. Le message de PresentMon est désormais écrit dans le journal.
- Correction : la mesure ne compte plus les écrans de chargement et les menus sans limite d'images, qui gonflaient la moyenne (52 i/s annoncées pour un jeu bridé à 40). Elle ne suit plus le navigateur intégré d'un lanceur (celui de Larian pour Baldur's Gate 3) au lieu du jeu, et n'arrête plus la mesure d'un autre outil (FrameView) ouverte en même temps. La dernière mesure est gardée dans le dossier d'ORION pour comparaison.
- Les estimations d'images par seconde se corrigent avec vos parties mesurées : chaque jeu mesuré sur votre PC ajuste l'estimation de tous les autres (Baldur's Gate 3 : 55 i/s estimées, 130 vues). Avant, seules les mesures de l'ancien profil « Détente » comptaient.
- La mesure demande à Windows le droit de lire les images affichées : membre du groupe « Utilisateurs du journal de performances », ou administrateur. Quand Windows refuse, Réglages le dit, et l'article « Mesurer les images par seconde » des Tutos donne la marche à suivre.
- Correction : ORION passait devant le jeu juste après le lancement, quand le jeu ferme sa fenêtre de démarrage. Il se réduit maintenant au lancement et revient à la fin de la partie (réglable dans Réglages, « Pendant une partie »).
- Correction : sur les jeux Unity, ORION écrivait la qualité sous un nom que le jeu ne lit pas (empreintes recopiées à la main, fausses) : les noms sont calculés. Aniimo a sa recette, lue sur un vrai PC : le jeu ignore son niveau général au démarrage et relit chaque option, ORION écrit donc le niveau ET toutes ses options (illumination, ombres, reflets, occlusion, animations, mode DLSS), comme le menu du jeu, plus la limite d'images. L'anticrénelage reste le vôtre.
- Correction : Baldur's Gate 3 recalcule lui-même son niveau de graphismes à partir de ses options et efface celui qu'on lui écrit : ORION n'écrit plus ce niveau seul, qui faisait dire « déjà en place » en Basse comme en Ultra. Il écrit la définition et la synchronisation, et la fiche dit quoi choisir dans le menu du jeu. La qualité n'est pas dans le fichier binaire config.lsf : il ne garde que des préférences de jeu.
- Nouveau : une case DLSS (ou FSR, XeSS) sur les deux cartes, quand le jeu et la carte le permettent : cochée, toujours active ; décochée, jamais ; sans y toucher, seulement s'il en faut pour tenir l'objectif. Le gain d'images par seconde s'affiche dès le clic. Aniimo : ORION écrit son anticrénelage (DLSS ou TAA) et le mode DLSS.
- Anti-triche : ORION n'écrit jamais pendant une partie (un programme du jeu ou son lanceur ouvert : rien n'est écrit, la fiche le dit), et pour un jeu inconnu il ne cherche plus de fichier de réglages dans le dossier d'installation, là où les anti-triches vérifient les fichiers. Rien n'est jamais injecté dans un jeu ni dans sa mémoire.
- Plus de fenêtre de confirmation au lancement : le choix fait dans la fiche s'écrit.
- Une recette 2.1.0 n'écrit que les clés présentes dans le fichier du jeu ; celles que le jeu n'a pas sont listées dans les conseils du plan (« Non écrits, ce jeu n'a pas ces options »), et l'état « Réglages appliqués : x sur y » en tient compte.
- La fiche affiche la correspondance « fichier appris, clés sûres seulement » quand ORION a appris le fichier lui-même.
- Les moteurs RAGE (GTA V, Red Dead Redemption 2) et RE Engine (Capcom) sont reconnus à leurs fichiers ; RE Engine passe par le guide.
- Deux écritures dans la même seconde ne partagent plus un dossier de sauvegarde : la première sauvegarde, celle de l'état d'origine, n'est plus écrasée.
- Counter-Strike 2 n'est pas réglé : son fichier vit dans le dossier de Steam, qu'ORION ne modifie pas.

Fluidité
- La fermeture d'ORION n'attend plus le dernier envoi du compteur (1 018 ms mesurées le 7 octobre) : la fenêtre disparaît tout de suite, l'envoi finit en fond, deux secondes au plus.
- Fiche d'un jeu : les captures sont décodées à la taille de leur vignette (quelques millisecondes au lieu de 0,45 s pour dix captures) et posées par lots ; la vue web des bandes-annonces est créée en temps mort après l'analyse, plus à la première fiche ouverte (0,7 à 1,0 s de fenêtre figée).

Boutique
- La case « Afficher les applications » disparaît : les logiciels, formations et bandes originales restent toujours écartés, le résumé dit combien le sont.
- Une enseigne à plusieurs vitrines (Gamesplanet France, Allemagne, Royaume-Uni, États-Unis) n'est plus comptée qu'une fois, dans la monnaie de votre pays : Gamesplanet US, en dollars, ne passe plus devant pour un joueur français.
- Un jeu « Dans la bibliothèque » : sa fiche offre « Voir dans ma bibliothèque », qui ouvre le jeu chez vous.

Sorties
- La grande affiche ne recouvre plus la liste quand la fenêtre est petite, et la clé d'un revendeur porte son vrai libellé (clé Microsoft Store pour Modern Warfare 4, et non « clé Steam vérifiée »).

Ma machine
- Les repères de puissance (« une carte graphique du niveau d'une RTX 4060 ») sont désormais calculés en structure puis mis en phrases : la liste des pièces part des mêmes besoins, jamais d'un texte relu.
- Les processeurs de portable des tables d'ORION sont tenus à part : jamais proposés à l'achat, ils restent comparés comme avant.
- Processeur plus ancien que la carte graphique : en 1440p et au-delà, c'est un conseil et non plus une alerte (la carte graphique y travaille le plus) ; le bilan ne se contredit plus.
- Mémoire bridée avec des barrettes « optimisées AMD » sur un processeur Intel : le conseil le reconnaît (pas de XMP à activer, ou un profil qui ne tient pas : réglage à la main dans le BIOS), et la mémoire proposée à l'achat précise le profil à prendre (Intel XMP) et garde la vitesse prévue.

Stockage
- Les jeux Ankama (Dofus, Wakfu...) se désinstallent par l'Ankama Launcher au lieu d'ouvrir leur dossier, et la confirmation donne la taille du jeu.

Fiche d'un jeu
- Quand « Mon choix » donne le même réglage que « Votre écran », la carte le dit.
- Le choix vaut pour ce jeu et le moteur le relit à chaque plan : « Jouer » refait le même calcul que la carte, et la fiche ouverte est recalculée dès qu'une partie a été mesurée.
- Plus de bouton « Appliquer sans lancer » ni de profil par défaut dans les Réglages : le choix se fait jeu par jeu.
- Choisir une carte, même celle déjà en place, ou cocher la case DLSS ne fait plus sauter la page.

Tutos et Réglages
- Tutos revus : la case DLSS, la mesure et le groupe Windows qu'elle demande (avec la commande à taper), la Boutique et ses trois revendeurs de clés, la sortie à la une, les comptes Epic Games et EA app, la mémoire « optimisée AMD ». Dans Réglages, la mesure ne parle plus de droits d'administrateur, qu'ORION ne demande jamais.

## 2.0.2 — Votre PC en une minute, et les bons pilotes pour votre modèle
8 octobre 2026 · nouveautés et correctifs, jamais publiée : comprise dans la 2.1.0

**L'essentiel**
- **Nouveau : « Votre PC, en une minute ».** À la première installation, après l'analyse, ORION dit en quatre phrases ce qu'il sait faire pour vous : combien de vos jeux tournent en qualité Haute, combien de pilotes sont à mettre à jour, ce que vaut votre bibliothèque, et si des jeux de votre liste d'envies ont baissé. Un bouton par phrase ouvre la page qui va avec. Le bilan reste accessible depuis Ma machine.
- **Nouveau : une image à partager.** Depuis le bilan, « Partager en image » fabrique une carte 1200 × 630 — « Mon PC fait tourner 38 de mes 52 jeux en qualité Haute », la valeur de la bibliothèque, les pilotes à mettre à jour, processeur et carte graphique — enregistrée où vous voulez et copiée dans le presse-papiers. Rien de personnel dessus.
- **Correction : sur un portable ou un PC de marque (HP, Dell, Lenovo, Acer…), ORION envoyait chercher les pilotes réseau, audio et stockage chez Intel ou sur la page d'accueil du constructeur.** Il renvoie maintenant vers la page support du constructeur pour votre modèle, avec le numéro de produit qu'elle demande ; seule la carte graphique NVIDIA ou AMD reste chez son fabricant. Merci au joueur qui l'a signalé.
- **Nouveau : ORION regarde ce que Windows Update propose pour votre matériel.** Quand un pilote plus récent y attend (réseau, audio, stockage…), le conseil le dit avec la version et ouvre la page des mises à jour facultatives. Quand Windows Update n'a rien, le conseil le dit aussi, avec la date de la vérification.
- **Nouveau : sur un PC Dell, Lenovo ou HP, ORION lit le catalogue de pilotes de votre modèle.** C'est la source de Dell Command Update, Lenovo System Update et HP Image Assistant : quand votre réseau, votre audio, votre chipset ou votre carte graphique Intel/AMD a une version plus récente validée pour votre modèle, le conseil la nomme, avec sa date, la page officielle et le fichier.
- **Nouveau : pour une carte NVIDIA, ORION connaît la dernière version de votre série.** GeForce 10, 16, 20, 30, 40 ou 50, de bureau ou de portable : « 561.74 installée, 617.42 disponible », avec la page du bon pilote.
- **Correction : sur certains jeux Unreal (Ready or Not, Aniimo…), les réglages écrits par ORION ne changeaient rien, le jeu restait en Épique.** Unreal range les réglages sous le nom de la classe propre à chaque jeu ; ORION n'écrivait que la section générique. Il écrit maintenant dans la section que le jeu relit, niveaux de qualité compris, et toujours après sauvegarde. Merci à l'auteur de l'avoir constaté sur sa machine.
- **Amélioration : la fenêtre « Quoi de neuf » se lit mieux.** Un espace entre chaque point, des phrases de tous les jours (« Correction : ORION confondait… »), et le gras des notes de version rendu dans la fenêtre de mise à jour.

**Dans le détail**

Ma machine
- Le son HDMI de la carte graphique (Intel, AMD, NVIDIA) et les périphériques audio logiciels ne sont plus comptés comme des pilotes audio à mettre à jour : ils suivent le pilote graphique.
- Chaque pilote est identifié par sa puce (identifiant matériel), pas seulement par son nom : les noms traduits par Windows ne trompent plus l'analyse.
- Le catalogue du constructeur est lu une fois tous les trois jours, en fond, seulement sur un PC de marque ; rien n'est envoyé, seul le modèle sert à choisir le catalogue. Le sous-système de la puce (la version exacte de votre modèle) l'emporte sur la puce seule.
- Une carte ajoutée dans le PC (carte réseau ASUS, carte son Creative, carte Wi-Fi TP-Link…) renvoie vers la page de son fabricant, plus vers celle de la carte mère — et vers la page de son modèle quand son nom le donne (« ASUS XG-C100C » ouvre la page de la XG-C100C, chez ASUS ou TP-Link).
- Sur une tour montée, les puces de la carte mère ne renvoient plus vers l'assistant Intel : Intel publie la dernière version par famille (réseau filaire, Wi-Fi, Bluetooth, chipset, graphique), et le conseil ouvre cette page ; pour le reste (audio Realtek, stockage, USB), il ouvre la page support de la carte mère pour son modèle exact, construite depuis son nom chez ASUS, MSI, Gigabyte et ASRock. Un PC Dell ouvre aussi la page de son modèle.
- Deux cartes réseau de marques différentes donnent deux conseils distincts, chacun avec son lien.
- Un appareil USB d'un autre fabricant (clé Wi-Fi TP-Link, casque, carte son externe) renvoie aussi vers la page de son fabricant.

Réglages
- Depuis le Microsoft Store, ORION demande une note au cinquième lancement, une seule fois, quelle que soit la réponse. Rien n'est envoyé : le bouton ouvre la page de notation du Store.

Sous le capot
- Les clics sur les liens partenaires du site sont comptés comme ceux de l'application (boutique et type de page, sans identifiant ni cookie) : on saura quelles pages font acheter.
- Le tri matériel / logiciel se fait sur le bus qui a déclaré le périphérique (PCI, USB, audio, ACPI contre ROOT, SWD…), plus sur une liste de noms : les cartes virtuelles des VPN, casques VR, outils de streaming et sons virtuels sont écartées quels que soient leur nom et la langue de Windows.
- ORION embarque la base publique des identifiants PCI et USB (pci.ids / usb.ids, 6 000 fabricants) : il nomme le fabricant de n'importe quelle carte ou puce, sans liste entretenue à la main.
- Les notes de version suivent une ligne éditoriale : un titre qui dit la promesse, l'essentiel en trois à six points, le détail par rubrique.
- En anglais, les conseils de pilotes sont traduits en entier : chaque phrase a son entrée, et un détail composé selon la machine est traduit phrase par phrase.
- Avant de compiler, la vérification des sources ne retire plus rien si l'archive de référence n'est pas de la même version que le dossier : elle cherche d'abord `ORION-<version>*.zip`, puis `ORION.zip`, et vérifie leur `version.py`.

## 2.0.1 — ORION ne disparaît plus derrière votre navigateur
7 octobre 2026 · correctifs

**L'essentiel**
- **Correction : ORION confondait certains navigateurs (Opera, Chrome, Firefox, Edge…) et logiciels toujours ouverts (Discord, Spotify, OBS, VLC…) avec des jeux.** Chez certains joueurs, il se cachait alors cinq secondes après le démarrage, comme pendant une partie, et ne revenait jamais ; la mise à jour que ce bug bloquait passe à nouveau. Merci au joueur qui l'a signalé.
- **Correction : sur les jeux Unreal (Aniimo, par exemple), les images par seconde n'étaient pas mesurées.** ORION regardait le petit programme de lancement au lieu du jeu lui-même. Il suit maintenant le vrai programme, et dit dans son journal quand une mesure n'a rien donné.
- **Nouveau : un bilan de fluidité, si vous le voulez.** À la fermeture, ORION peut envoyer combien de fois l'affichage s'est figé, quelle fonction était en cause, le temps de démarrage et le nombre d'erreurs du journal — jamais le jeu, jamais un chemin. C'est ce qui permet de corriger ce qui n'arrive pas sur la machine de l'auteur. La question du partage vous est reposée une fois ; sans nouveau oui, rien n'est compté.

**Dans le détail**

Signalements
- Le rapport joint indique la mémoire vidéo et les écrans (il affichait « ? »).
- Éteindre Windows pendant qu'ORION tourne, même caché, ne fait plus parler d'« arrêt brutal » au démarrage suivant.

## 2.0.0 — Votre PC lu jeu par jeu, et les vrais prix
7 octobre 2026 · grande version

**L'essentiel**
- **La lecture de votre PC.** Dans Ma machine, carte graphique, processeur, mémoire vidéo et mémoire vive ont chacun leur verdict, tiré des jeux évalués : combien de jeux chacun retient sous le niveau Haute, et lequel est le premier frein. Un clic sur un jeu explique son niveau, composant par composant, et ce qui le rendrait jouable sans rien acheter (DLSS, FSR ou XeSS en mode Qualité, définition plus basse).
- **Les portables aussi.** Cartes de portable, puces intégrées, processeurs H, HS, HX et U : tout ce que cite l'enquête matérielle de Steam est reconnu. Quand c'est le processeur qui plafonne, ORION garde le plus beau niveau au lieu de conseiller de tout baisser.
- **Les DLC de vos jeux.** La fiche d'un jeu Steam montre ses contenus additionnels : ceux que vous avez sont marqués « Déjà acquis », lus dans les fichiers de Steam sur ce PC, sans compte ni mot de passe. Les autres s'affichent à leur meilleur prix.
- **Le comparateur, sans rien configurer.** Plus de trente boutiques agréées et le plus bas prix historique de chaque jeu, sans clé à créer. Les prix de Gamesplanet, distributeur officiel, sont relevés toutes les vingt minutes ; Loaded rejoint Instant Gaming et Kinguin parmi les revendeurs de clés, toujours sous les boutiques officielles.
- **Tout le magasin à portée.** Chaque type de jeu a sa page, sans fin : arrivé au bout, ORION va chercher les jeux suivants. Recherche, filtres et tri restent en haut et agissent sur la page en cours.
- **Une recherche qui comprend.** « bo3 » trouve Black Ops III, « cs2 » Counter-Strike 2, « ff16 » Final Fantasy XVI. Un jeu absent du PC (« zelda », « mario kart ») mène à des jeux du même esprit avec leurs prix du jour.
- **Des réglages qui s'appliquent tout de suite.** Plus de redémarrage. Les Réglages ont une recherche et six rubriques, et la molette ne change plus une valeur en passant dessus.
- **Plus fluide.** Le défilement ne saccade plus, les mises à jour de fond attendent que vous ayez fini votre geste, et le démarrage est plus court.

**Dans le détail**

Ma machine
- L'estimation suit ce que l'éditeur a écrit : quand une fiche cite plusieurs cartes ou processeurs (« Core i7-12700 ou Ryzen 7 7800X3D »), le moins puissant sert de référence. Des jeux classés « Basse » à tort remontent (Cyberpunk 2077 sur un Core i9-9900K et une RTX 3080 passe en Haute).
- Sur un écran 4K, la fiche dit que c'est la définition de l'écran qui retient le jeu, pas la carte.
- Le filtre « Rattrapables » liste les jeux qu'un simple réglage ferait monter d'un niveau ; les pastilles Ultra, Haute, Moyenne, Basse et Trop juste filtrent la liste d'un clic.
- « Copier ma configuration » met la configuration en texte dans le presse-papiers ; le PC n'a plus qu'une seule note, et la liste de deux mille jeux ne fige plus la fenêtre.

Boutique
- Des pages de quarante jeux au lieu d'un long défilement ; un type de jeu, un filtre ou « Tout voir » ouvre sa page tout de suite, avec un retour vers l'accueil.
- La page d'un type montre d'abord ses promotions et ses jeux gratuits ; l'accueil ajoute une rangée par type de jeu (ceux que vous possédez le plus d'abord), les petits prix, les mieux notés et les promos Gamesplanet.
- La recherche part d'elle-même pendant la saisie et répond en une ou deux secondes ; un tri « Découverte » mélange la page.
- La recherche Steam ne rend que des jeux, trente résultats au lieu de dix, et comprend les sigles (« bo4 » devient « black ops 4 »). Un autre numéro n'est plus pris pour une faute de frappe : « black ops 4 » ne montre plus Black Ops 7, « tropico 6 » ne ramène plus Tropico 5, 4 et 3, « F1 » ne rend plus Frontline 1942, « fifa » mène aux EA SPORTS FC.
- Plus de jeux sans rapport : un mot court ne se lit qu'au début d'un mot, une ressemblance à l'oreille porte sur des mots entiers (« mario » ne montre plus Marvel). À pertinence égale, le jeu le plus connu passe devant.
- Un jeu introuvable n'est plus une impasse : ORION dit pourquoi il n'est pas en boutique PC et propose des jeux du même esprit. Pour un jeu qui se prend chez son éditeur (Fortnite, Minecraft, Valorant), il donne le site officiel.
- « Au plus bas historique » couvre tout le catalogue : un jeu n'est dit « au plus bas » que s'il est en promotion à son record.
- Les prix des boutiques sont relevés en même temps et le catalogue s'affiche dès qu'ils sont là ; types de jeu, fiches et plus bas historiques se complètent en arrière-plan.
- Dans la fiche d'un jeu, le bouton DLC affiche les contenus additionnels à la place des offres, et « Offres du jeu » y ramène. « Suivre » se défait d'un second clic.
- Le lien « Voir les gratuits » ouvre bien l'onglet des jeux gratuits ; le lien Loaded ouvre les versions PC.
- Une clé Steam vérifiée chez Kinguin ou Loaded qui bat les boutiques officielles apparaît sur la carte du jeu et à côté de « Acheter ». ORION vérifie : le jeu lui-même (ni édition, ni DLC, ni compte, ni « Gift »), une clé Steam pour PC activable dans votre pays, chez un vendeur unique ou très bien noté. Elle reste à part, jamais présentée comme la meilleure offre officielle.
- À prix égal, la boutique partenaire d'ORION passe devant. Le prix est le même pour vous, et le lien partenaire est toujours signalé.
- Les prix de Gamesplanet viennent d'un fichier relevé toutes les vingt minutes pour tout le monde : votre PC n'interroge pas Gamesplanet, et un prix trop ancien n'est jamais affiché. Un prix Loaded n'est affiché que s'il correspond au prix normal du jeu, chez un vendeur unique ; votre PC n'interroge jamais le revendeur.

Fiches de jeux et DLC
- Si ORION ne peut pas lire les fichiers de Steam, il le dit et n'affirme rien : vérifiez dans Steam avant d'acheter.
- La fiche d'un jeu ne montre que la vitrine Gamesplanet de votre pays.

Envies et jeux gratuits
- ORION prévient quand un jeu suivi sans seuil baisse d'au moins 10 %, par exemple ceux importés de votre liste de souhaits Steam ; la meilleure offre tient compte de Gamesplanet, et un clic sur la notification ouvre les Envies.
- Une notification Windows, une seule, le jour où un jeu devient gratuit ; les jeux gratuits en permanence ne sont jamais annoncés. Cela se coupe dans les Réglages.
- L'ajout d'un jeu aux Envies par son nom profite de la même recherche : jeux seulement, sigles, saisie incomplète.

Parties
- ORION suit le jeu lui-même, et plus son lanceur ou son rapporteur de plantage : sur Cyberpunk 2077 et les jeux qui s'ouvrent par un lanceur, la mesure ne s'accrochait pas au bon programme et la partie pouvait sembler finie au bout de quelques secondes.
- Un second clic sur « Jouer » ne lance plus une deuxième partie ni une deuxième mesure.

Bibliothèque, Stockage, Conseils, Comptes
- Bibliothèque : filtres rapides (favoris, joués récemment, jamais lancés), Ctrl+F pour chercher, et une recherche sans résultat propose de chercher le jeu dans la Boutique.
- Stockage : la liste se trie en cliquant un en-tête, se filtre (ce qui dort, sauvegardes) et se cherche ; un double-clic ouvre la fiche. Un jeu tout juste installé n'est plus dit « dormant », et un disque externe en veille ne fige plus la page.
- Conseils : un conseil peut être masqué, un filtre ne garde que ce qui reste à traiter, le rapport se copie en texte, le menu affiche le nombre de points à corriger.
- Comptes : une synthèse de tous vos comptes, « Tout actualiser », et la liste des jeux présents sur plusieurs plateformes.

Réglages
- La largeur des tuiles, les jeux masqués, la manette, la fréquence de la veille, les jeux gratuits et le pays des prix n'attendent plus un redémarrage ; « jamais » arrête vraiment la veille des installations.
- Les données partagées ont leur propre bloc ; un libellé trop long ne pousse plus les boutons hors de la fenêtre.

Décor et lisibilité
- Le fond change chaque jour, parmi cinquante images aux couleurs d'ORION ; votre propre image garde la priorité, et cela se coupe dans les Réglages.
- Une bannière de saison en haut de toutes les pages, qui change le jour de l'équinoxe ou du solstice, différente chaque année.
- Les textes secondaires (menu, légendes, petites mentions) sont plus clairs et un peu plus gras ; les accents manquants sont revenus (« Programmes installés », « Revendeur agréé »), et le processeur porte son nom simple (« Intel Core i9-9900K »).

Sous le capot
- Les cartes des jeux sont dessinées une fois puis recopiées ; sur la page Sorties, seul le compte à rebours est redessiné chaque seconde.
- ORION note dans son journal tout arrêt de l'affichage et sa cause, pour que chaque accrochage restant puisse être corrigé.

## 1.9.8 — Cyberpunk à la bonne taille
5 octobre 2026

- Cyberpunk 2077 : ORION met aussi le jeu à la définition de votre écran et choisit le mode d'affichage. Avant, le jeu pouvait garder une ancienne définition plus grande que l'écran : l'image débordait sur le second écran.
- Cyberpunk 2077 : avec une carte NVIDIA, ORION règle aussi le niveau de DLSS selon le profil choisi.

## 1.9.7 — Compteur et réglages de Cyberpunk 2077
4 octobre 2026

- Cyberpunk 2077 : ORION écrit désormais ses réglages (textures, ombres, reflets, brouillard, foule, ray tracing) au lieu de seulement vous guider. Il s'en tient aux valeurs que le jeu propose et ne touche ni à la définition, ni à DLSS, ni à vos effets de caméra.
- Recettes partagées : elles sont de nouveau chargées sous Windows. Elles étaient écartées à tort, comme si elles avaient été modifiées.
- Compteur anonyme : le service note désormais le pays et la région d'où vient chaque envoi, jamais la ville ni l'adresse. Le texte de la question ayant changé, elle est reposée une fois ; sans nouveau oui, plus rien n'est compté.
- Aide : la page « Mes données partent-elles quelque part ? » précise que le prix d'un revendeur de clés passe par le service d'ORION, qui ne reçoit que le jeu demandé.

## 1.9.6 — Retouches et filtre des jeux pour adultes
4 octobre 2026

- Jeux réservés aux adultes : une seule règle pour toutes les boutiques et plateformes. Ni captures ni vidéos dans leur fiche, et plus aucune apparition dans la Boutique, les jeux gratuits, les Sorties et la recherche des Envies. Les jeux grand public classés 18 ans ne sont pas concernés.
- Curseur des graphismes : un niveau plus léger n'affiche plus jamais moins d'images par seconde qu'un niveau plus lourd.
- Moteur du jeu : il n'est reconnu que sur une signature sûre. Un jeu d'un autre moteur (Cyberpunk 2077 par exemple) n'est plus pris pour un jeu Unreal.
- Les pages ne sautent plus toutes seules : la fiche d'un jeu s'ouvre en haut et y reste.
- Petite fenêtre : la liste des sources défile au lieu de s'écraser.
- Recherche de la bibliothèque : un mot court ne fait plus remonter de jeux sans rapport.
- Captures d'écran : les flèches du clavier font défiler les images.
- Toutes les fenêtres : boutons dans la langue d'ORION (« Oui », « Annuler », « Enregistrer »...) au lieu de l'anglais.
- Bande-annonce terminée : retour à l'affiche du jeu au lieu d'une image noire.
- Jeux gratuits et Ma machine : la recherche accepte les fautes de frappe et les sigles (gta, bg3).
- Images par seconde : au-delà de 300, ORION écrit « plus de 300 » partout (fiche d'un jeu, guide des réglages, Ma machine).
- Recherche de la Boutique : un jeu vendu seulement sur Steam n'est plus masqué comme une application.
- Boutique : dans la fiche d'un jeu, les revendeurs de clés (Instant Gaming, Kinguin) ont leur propre bloc, sous les boutiques officielles et bien séparé d'elles. Le bouton « Clés Steam moins chères » disparaît.
- Boutique : quand Kinguin vend la clé Steam du jeu moins cher que les boutiques officielles, chez un vendeur très bien noté, ORION affiche ce prix et ouvre directement la bonne fiche. Sinon : « Prix sur le site ».
- Boutique : la fiche d'un jeu s'agrandit avec le nombre de boutiques, pour tout lire sans défiler.
- Clés moins chères : le lien Kinguin écarte les offres « Account », le lien Instant Gaming ne montre plus que les clés PC.
- Fermer une page ou ORION ne déclenche plus d'« erreur imprévue » : une action différée est abandonnée quand sa fenêtre n'existe plus.
- Compteur anonyme, seulement si vous dites oui : ORION compte ses ouvertures, les pages utilisées et le nom de la boutique ouverte depuis une offre. Jamais le jeu, jamais rien de personnel. La question est posée une fois ; le choix se change dans Réglages.

## 1.9.5 — Réglages : l'écran d'abord
3 octobre 2026

- Boutique : une colonne « Types de jeux » (FPS, MOBA, MMORPG, RTS, RPG, survie...). Dans chaque type, les plus gros jeux d'abord, puis une sélection au hasard qui change à chaque ouverture.
- Boutique : sous chaque jeu, « Clés Steam moins chères » ouvre la recherche chez Instant Gaming et Kinguin, déjà filtrée sur les clés Steam Europe ou Global.
- Vidéos : la bande-annonce passe en tête et démarre toute seule, son coupé. Réglable dans Réglages.
- Deux propositions quand votre PC ne peut pas tout avoir : « Le plus d'images » (qualité réduite) ou « La plus belle image » (images réduites, jamais sous 60 par seconde). Un clic choisit, pour chaque jeu.
- Avant la première partie d'un jeu qu'ORION ne peut pas régler, il conseille un tour dans les réglages et montre la liste.
- Mesures partagées entre joueurs : si vous dites oui (ORION pose la question une fois), vos parties mesurées aident les joueurs équipés comme vous, et les leurs vous aident. Rien de personnel n'est envoyé ; le choix se change dans Réglages.
- Quand ORION ne peut pas régler un jeu lui-même, la fiche du jeu propose « Voir les réglages » : la liste de ce qu'il faut choisir dans les menus du jeu, ligne par ligne, avec des mots simples. Chaque ligne se coche, et la liste se copie.
- Profil « Recommandé » : ORION vise maintenant la fréquence de votre écran pour tous les jeux (144 images par seconde sur un écran 144 Hz), plus seulement 60. Si le matériel ne suit pas, il règle le jeu et la limite d'images sur le plus haut palier que votre PC tient. Chaque niveau du curseur (Basse, Moyenne, Haute, Ultra) est poussé au maximum d'images.
- Signaler un problème : un seul bouton « Envoyer ». Plus besoin de compte ni de fichier à joindre ; le signalement arrive directement à l'équipe.
- Corrections : les jeux installés hors Steam (Battle.net, Rockstar) retrouvent leur fiche, leurs images et leur bande-annonce ; le compteur « joueurs sur Steam » n'apparaît plus que pour les jeux Steam ; l'affiche de la sortie la plus attendue n'est plus tranchée sur grand écran ; la fenêtre « Comparer les boutiques » garde ses prix.

## 1.9.4 — Plus fluide, et une affiche pour GTA VI
3 octobre 2026

- Affiches : les jaquettes s'affichent une à une dès qu'elles arrivent, celles des jeux visibles en premier, au lieu d'attendre la fin du lot.
- Bibliothèque : ouverture bien plus rapide, les jaquettes sont gardées à la taille des tuiles.
- Molette : le défilement est plus ample et glissé, dans toutes les pages.
- Boutique et Sorties allégées ; la recherche de la bibliothèque attend la fin de la frappe.
- Accents : un titre de jeu n'est plus jamais modifié.
- Premier lancement : la langue et le pays des prix sont pris sur Windows (anglais et dollars pour un joueur américain).
- Prix : chaque montant s'affiche dans la devise du pays choisi ($, £, CHF...), et les jeux gratuits suivent le même pays.
- Anglais : les textes venus de Steam (genres, descriptions, succès) arrivent en anglais.
- Sorties : un jeu absent de Steam (GTA VI en tête) affiche maintenant son visuel officiel.
- Sorties : une remarque peut accompagner une sortie. GTA VI ouvre le bal.

## 1.9.3 — Les accents sont de retour
3 octobre 2026

- Toute l'interface affiche désormais les accents du français : menus, réglages, conseils, tuto et installateur.
- Site : le lien « Faire un don » ouvre une petite fenêtre par-dessus la page (code QR et lien PayPal) au lieu de la remplacer.

## 1.9.2 — Nouvelle adresse : orion-launcher.com
2 octobre 2026

- Le site d'ORION déménage sur orion-launcher.com : l'aide, les réglages et le calendrier des sorties pointent vers la nouvelle adresse.
- Lien partenaire Gamesplanet, distributeur officiel (le prix ne change pas).

## 1.9.1 — Connexion GOG avec Google
2 octobre 2026

- Comptes : nouveau bouton « Se connecter avec mon navigateur » pour GOG. Google refuse les fenêtres intégrées aux applications ; la connexion se fait donc dans votre navigateur habituel, puis ORION reconnaît l'adresse de fin de connexion dès que vous la copiez.
- Lecteur vidéo : la page de consentement de YouTube n'apparaît plus.
- Boutique : les lots de formations n'apparaissent plus parmi les jeux ; la fiche affiche « Chargement » pendant la recherche.
- Lien partenaire Kinguin ajouté (le prix ne change pas).
- Conseils : plus de faux conseil sur le chipset AMD d'un PC Intel, ni sur les périphériques audio virtuels.

## 1.9.0 — Une boutique, des fiches et des réglages entièrement repensés
2 octobre 2026

- Boutique repensée : « À la une » pour les gros jeux du moment, « Pour vous » avec des suggestions tirées de votre bibliothèque (jamais un jeu déjà possédé), grosses promos, plus bas historique, gratuits, et une recherche avec images.
- Les jeux gratuits rejoignent la Boutique (onglet « Gratuits en ce moment »). Logiciels et formations sont masqués par défaut : case « Afficher les applications ».
- Fiche de jeu repensée : Infos (studio, éditeur, sortie, genres, avis, succès), succès compacts, captures et vidéos dans un lecteur intégré (gameplay en français, lives, bande-annonce). Plus de prix ni de marché gris pour un jeu déjà possédé ; le lien Boutique reste là.
- Nouveau profil « Recommandé » : le plus beau réglage qui tient environ 60 images par seconde sur votre PC, avec DLSS ou FSR quand le jeu le permet. Un curseur Performances ↔ Qualité pour ajuster.
- Réglages fiables : état honnête (« Réglages appliqués : 12 sur 14 »), relus juste avant le lancement, fichiers en lecture seule respectés, et plus de confirmation à chaque partie.
- Ma machine : « Ce que votre PC peut faire » en une seule liste claire, avec le niveau fluide de chaque jeu, les filtres Tous / Mes jeux / À acheter et le tri.
- Conseils : analyse de tous les pilotes (graphique, chipset, réseau, audio, stockage, USB, Bluetooth) et des réglages Windows et matériel : mode Jeu, planification GPU, alimentation, fréquence d'écran, XMP/EXPO, mémoire en simple canal, disque plein, jeux sur disque dur, redémarrage en attente, fichier d'échange.
- Stockage : « Sauvegarder sur un autre disque » (copie vérifiée, le jeu installé n'est jamais modifié, progression en %, restauration et suppression). « Recalculer » remesure vraiment. Les jeux déplacés avec l'ancienne fonction peuvent être ramenés.
- Page Sorties : les grosses sorties toutes plateformes avec compte à rebours, renouvelées toutes seules d'après les jeux Steam les plus suivis ; la liste des sorties consoles est mise à jour en ligne.
- Joueurs en ligne (Steam) dans la fiche des jeux en ligne, et valeur de la bibliothèque (prix actuels hors promotion, à titre d'information).
- Comptes : connexion Xbox sans clé de sécurité (le mot de passe est proposé), connexion Google sur GOG mieux gérée, avec un message clair si Google refuse les fenêtres intégrées.
- Titres reconnus sans tenir compte de la ponctuation (« RuneScape - Dragonwilds » = « RuneScape: Dragonwilds ») ; un jeu sans captures le dit au lieu de laisser un vide.
- Fiabilité : relecture complète du code ; installation et mises à jour plus sûres (jamais dans un dossier existant, ORION toujours relancé, mise à jour reportée après la partie) ; base de données et réglages protégés contre les fichiers abîmés ; aucun secret dans le journal.
- Liens partenaires sur certaines boutiques : le prix ne change pas, une petite commission finance ORION (désactivable dans Réglages).

## 1.8 — Vos comptes, vos succès et ce que votre PC peut faire
26 septembre 2026

- Nouvelle page Comptes : Steam (connexion officielle), GOG et Xbox (connexions non officielles, signalées comme telles), dans une fenêtre intégrée. ORION ne voit jamais votre mot de passe : seul un jeton, chiffré par Windows, est gardé sur ce PC.
- Profil de chaque plateforme : niveau, XP, badges, Gamerscore, tous les jeux du compte et leur temps de jeu.
- Succès dans la fiche de chaque jeu : obtenus, manquants (les plus accessibles d'abord) et rareté mondiale.
- Les jeux de vos comptes rejoignent la bibliothèque (non installés) et leur temps de jeu est repris.
- Déplacer un jeu vers un autre disque (page Stockage) : copie vérifiée avant de libérer la place, le jeu reste visible pour son launcher. Retour sur le disque d'origine en un clic.
- Ce que votre PC peut faire (page Ma machine) : note de la machine, jeux fluides en Ultra, Haute et Moyenne, images par seconde attendues et meilleure offre. Chaque résultat dit sa source : mesure sur votre PC, mesures de la communauté ou estimation prudente.
- Ubisoft, Rockstar, Battle.net, Epic et EA : ce qui est possible et pourquoi, clairement affiché.

## 1.7.2 — La version en bas à gauche, la mise à jour en un clic
26 septembre 2026

- La version installée s'affiche en bas à gauche. ORION surveille la page officielle du projet et l'encart s'allume quand une nouvelle version sort.
- Un clic sur l'encart télécharge la nouvelle version, vérifie son empreinte, l'installe et redémarre ORION. La progression s'affiche sur place.
- Plus de fenêtre de mise à jour à chaque démarrage : un rappel discret suffit. L'encart peut être masqué dans Réglages > Mises à jour.
- Mise à jour tout ou rien : la nouvelle version est préparée à côté de l'ancienne, puis échangée d'un coup. Si c'est impossible, l'ancienne reste intacte et ORION redémarre dessus.

## 1.7 — Mises à jour automatiques, mode discret et bibliothèque complète
25 septembre 2026

- Mise à jour automatique : ORION vérifie les nouvelles versions, contrôle l'empreinte du fichier et s'installe en un clic.
- Mode discret en jeu : pendant une partie, même lancée depuis Steam ou Epic, ORION met en pause ses tâches de fond. Le temps de jeu est aussi compté hors d'ORION.
- Jeux possédés mais non installés (Steam, Epic, GOG) : visibles en grisé, avec un bouton pour les installer.
- Bouton « Signaler un problème » : un rapport sans données personnelles, prêt à envoyer. Un plantage n'est plus silencieux.
- Sauvegardes de parties copiées dans OneDrive, Google Drive ou Dropbox si vous le souhaitez.
- Recettes communautaires vérifiées avant usage : aucune ne peut écrire hors du dossier du jeu.
- Interface disponible en anglais.
- Données rangées dans une base locale : plus rapide, et plus de fichier abîmé si le PC s'éteint pendant une écriture.
- Connexions mieux réparties entre les services, indicateur « hors ligne ».

## 1.6 — Fiches de jeu enrichies et première version publique
25 septembre 2026

- Captures d'écran dans la fiche de chaque jeu, avec visionneuse.
- Actualités et mises à jour des jeux traduites intégralement en français, texte d'origine à un clic.
- Encart « marché gris » : revendeurs de clés et leurs risques, toujours séparés des offres sûres.
- Un jeu désinstallé disparaît tout seul, sans relancer d'analyse.
- Jaquettes des jeux tout juste sortis enfin récupérées.
- Première version publique, avec son site et ses téléchargements.

## 1.5 — La Boutique et une bibliothèque plus propre
- Boutique : tous les jeux, le prix le plus bas sur des sites sûrs uniquement, actualisée toutes les 12 minutes.
- Recherche tolérante : fautes de frappe, phonétique et sigles (gta, bg3…).
- Menu rapide ⋮ sur chaque jaquette.
- Doublons fusionnés (un même jeu vu par Steam et par Windows).
- Nouvelle source : Ankama (Dofus, Wakfu).
- Envies plus lisibles, jeux « à venir » reconnus.
- ORION ménage les serveurs de Steam : pause automatique en cas de refus.

## 1.4 — Soutien au projet
- Fenêtre de soutien avec QR code PayPal.
- Lien de don verrouillé dans l'application : personne ne peut le détourner.

## 1.3 — Installateur et assistant IA
- Installateur autonome : raccourcis, entrée dans « Applications installées », désinstallation propre.
- Un seul ORION à la fois : un second lancement rappelle la fenêtre.
- Assistant IA facultatif (Claude, ChatGPT, Gemini, Mistral, Ollama) : il apprend un jeu inconnu à ORION et explique les baisses de performances.
- Bannière d'accueil, navigation à la manette et affichage salon.

## 1.2 — Jeux gratuits, prix et performances
- Jeux gratuits du moment : Epic, Steam, GOG, Prime Gaming et autres, avec leurs conditions.
- Prix, avis et plus bas historique ; liste d'envies avec alertes.
- Mesure des images par seconde réelles (PresentMon) et ajustements proposés.
- Sauvegardes de parties archivées et restaurables.

## 1.1 — Recettes partagées
- Recettes de réglages partagées par la communauté, téléchargées automatiquement.

## 1.0 — Première version
- Détection des jeux Steam, Epic, GOG, Ubisoft, EA, Battle.net, Xbox, des dossiers de jeux et des programmes installés.
- Jaquettes, bannières et logos récupérés automatiquement.
- Analyse du PC : processeur, carte graphique, mémoire, écrans et tous leurs modes.
- Trois profils de lancement (Esport, Détente, Photoréaliste) qui règlent le jeu et l'écran, avec sauvegarde et restauration.
- Temps de jeu par jeu, tri et filtres.
