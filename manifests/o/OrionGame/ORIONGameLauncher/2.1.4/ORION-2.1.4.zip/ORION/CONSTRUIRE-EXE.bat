@echo off
chcp 65001 >nul
title ORION - compilation de l'executable
rem dossier du script, lu UNE fois avant tout changement de dossier : lance
rem par un autre script avec un chemin relatif entre guillemets, le chemin du
rem script se relit apres le cd et pointe ailleurs (10 octobre : ORION\ORION,
rem donc .venv introuvable et PyInstaller "pas installe")
set "ICI=%~dp0"
rem lance par COMPILER-SEUL.bat (sortie dans un journal) : aucune attente de touche
set "PAUSE=pause"
if "%~1"=="--sans-pause" set "PAUSE=rem"
cd /d "%ICI%"
set "LOG=%ICI%_compilation.log"
echo Compilation ORION > "%LOG%"
echo. >> "%LOG%"

echo.
echo   ===========================================
echo    ORION - compilation de l'executable
echo   ===========================================
echo.

rem --- environnement Python isole ---------------------------------------
if not exist ".venv\Scripts\python.exe" (
  echo   Creation de l'environnement Python...
  py -3 -m venv .venv >> "%LOG%" 2>&1 || python -m venv .venv >> "%LOG%" 2>&1
)
set "PY=%ICI%.venv\Scripts\python.exe"

echo   Verification des outils...
"%PY%" -m pip install --upgrade pip >> "%LOG%" 2>&1
"%PY%" -m pip install -r requirements.txt >> "%LOG%" 2>&1
"%PY%" -m pip install pyinstaller >> "%LOG%" 2>&1
if errorlevel 1 (
  echo   ECHEC : PyInstaller n'a pas pu etre installe. Voir _compilation.log
  %PAUSE%
  exit /b 1
)

rem --- aucun fichier d'une ancienne version ne doit etre compile -----------
rem (10 octobre : ORION.zip extrait DANS le dossier, installateur compile avec
rem les sources de la veille) : le controle arrete la compilation (code 3)
"%PY%" outils\sources_propres.py >> "%LOG%" 2>&1
if errorlevel 3 (
  echo.
  echo   ARRET : les sources du dossier ne sont pas celles de ORION.zip.
  echo   Lancez COMPILER-SEUL.bat, a cote de ORION.zip : il met les
  echo   sources a jour au bon endroit, puis compile.
  echo.
  %PAUSE%
  exit /b 1
)

rem --- menage des compilations precedentes -------------------------------
if exist "build" rmdir /s /q "build"
if exist "dist" rmdir /s /q "dist"

rem --- 1) l'application --------------------------------------------------
echo.
echo   [1/2] Compilation de l'application... (plusieurs minutes)
"%PY%" -m PyInstaller --noconfirm --clean --windowed ^
  --name "ORION" ^
  --icon "orion\ui\assets\orion.ico" ^
  --collect-submodules orion ^
  --add-data "orion\ui\assets;orion\ui\assets" ^
  --add-data "orion\plugins\tweaks\recipes;orion\plugins\tweaks\recipes" ^
  --add-data "orion\langues;orion\langues" ^
  --add-data "orion\hardware\fabricants_ids.json;orion\hardware" ^
  --exclude-module tkinter ^
  --hidden-import PySide6.QtWebEngineCore ^
  --hidden-import PySide6.QtWebEngineWidgets ^
  --hidden-import winrt.runtime ^
  --hidden-import winrt.windows.foundation ^
  --hidden-import winrt.windows.applicationmodel ^
  --hidden-import winrt.windows.applicationmodel.activation ^
  --exclude-module PySide6.Qt3DCore ^
  --exclude-module PySide6.QtMultimedia ^
  run.py >> "%LOG%" 2>&1

if not exist "dist\ORION\ORION.exe" (
  echo   ECHEC : l'application n'a pas ete compilee. Voir _compilation.log
  %PAUSE%
  exit /b 1
)
echo         OK : dist\ORION\ORION.exe
"%PY%" outils\alleger.py dist\ORION

rem --- 2) l'installateur, qui transporte l'application -------------------
echo.
echo   [2/2] Compilation de l'installateur...
"%PY%" -m PyInstaller --noconfirm --clean --windowed --onefile ^
  --name "Installateur-ORION" ^
  --icon "orion\ui\assets\orion.ico" ^
  --add-data "dist\ORION;programme" ^
  --add-data "orion\ui\assets;orion\ui\assets" ^
  --exclude-module tkinter ^
  --exclude-module PySide6.QtWebEngineCore ^
  --exclude-module PySide6.QtWebEngineWidgets ^
  --exclude-module winrt ^
  installateur.py >> "%LOG%" 2>&1

if not exist "dist\Installateur-ORION.exe" (
  echo   ECHEC : l'installateur n'a pas ete compile. Voir _compilation.log
  %PAUSE%
  exit /b 1
)

rem --- 3) verification : les extensions survivent-elles a la compilation ?
echo.
echo   Verification de l'application compilee...
"dist\ORION\ORION.exe" --autotest >> "%LOG%" 2>&1
timeout /t 3 >nul
if exist "%LOCALAPPDATA%\ORION\_autotest.txt" (
  type "%LOCALAPPDATA%\ORION\_autotest.txt"
  type "%LOCALAPPDATA%\ORION\_autotest.txt" >> "%LOG%"
  copy /y "%LOCALAPPDATA%\ORION\_autotest.txt" "%ICI%_autotest.txt" >nul 2>&1
) else (
  echo   (verification non concluante, voir _compilation.log)
)

echo.
echo   ===========================================
echo    Termine.
echo.
echo    Installateur : dist\Installateur-ORION.exe
echo    Application  : dist\ORION\ORION.exe
echo   ===========================================
echo.
rem appele par la chaine complete : on n'attend pas de touche
if "%~1"=="--sans-pause" exit /b 0
pause
