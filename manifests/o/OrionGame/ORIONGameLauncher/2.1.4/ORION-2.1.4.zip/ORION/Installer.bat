@echo off
chcp 65001 >nul
title ORION - Installation
cd /d "%~dp0"
echo.
echo   ================================================
echo     ORION Game Launcher - installation
echo   ================================================
echo.

set "PY="
where py >nul 2>&1 && set "PY=py -3"
if not defined PY ( where python >nul 2>&1 && set "PY=python" )

if not defined PY (
  echo   Python n'a pas ete trouve. Installation via winget...
  winget install -e --id Python.Python.3.12 --accept-source-agreements --accept-package-agreements
  set "PY=py -3"
)

echo   [1/3] Creation de l'environnement Python local...
%PY% -m venv "%~dp0.venv"
if errorlevel 1 goto :erreur

echo   [2/3] Installation des composants (PySide6, requests, psutil)...
"%~dp0.venv\Scripts\python.exe" -m pip install --upgrade pip --quiet
"%~dp0.venv\Scripts\python.exe" -m pip install -r "%~dp0requirements.txt"
if errorlevel 1 goto :erreur

echo   [3/3] Creation du raccourci sur le Bureau...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$s=(New-Object -COM WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\ORION.lnk');" ^
  "$s.TargetPath='%~dp0.venv\Scripts\pythonw.exe';" ^
  "$s.Arguments='\"%~dp0run.py\"';" ^
  "$s.WorkingDirectory='%~dp0';" ^
  "$s.IconLocation='%~dp0.venv\Scripts\pythonw.exe';" ^
  "$s.Description='ORION Game Launcher';$s.Save()"

echo.
echo   Installation terminee. Lancez ORION.bat ou le raccourci du Bureau.
echo.
pause
exit /b 0

:erreur
echo.
echo   L'installation a echoue. Consultez les messages ci-dessus.
echo.
pause
exit /b 1
