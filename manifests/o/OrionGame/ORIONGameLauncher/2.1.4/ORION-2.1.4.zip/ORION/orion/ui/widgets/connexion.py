"""Fenetre de connexion integree (1.8).

Elle affiche la page officielle de la plateforme dans un navigateur
integre, avec trois garanties visibles :

* la barre d'adresse montre en permanence le site affiche (cadenas vert
  seulement en HTTPS) : le joueur verifie qu'il est bien chez Steam, GOG
  ou Microsoft. Les fenetres surgissantes (« Se connecter avec Google »...)
  ont leur propre barre d'adresse ;
* le navigateur est « prive » : ni cookies ni historique ne sont gardes
  quand la fenetre se ferme ;
* ORION ne lit pas ce qui est tape dans la page : il attend seulement
  l'adresse de retour prevue par la plateforme, qui contient le jeton ou le
  code. Seule intervention sur les pages : pour Microsoft, un petit script
  masque les cles de securite (passkeys), que ce navigateur ne sait pas
  utiliser, pour que la page propose le mot de passe ou un code.

Le navigateur se presente comme le Chrome dont il est issu (sans la mention
« QtWebEngine »). Si Google refuse malgre tout « Se connecter avec Google »
dans une fenetre integree, ORION l'explique et donne l'autre chemin ; il ne
contourne pas cette protection.
"""
from __future__ import annotations

from ..minuteur import plus_tard

import base64
import json
import re
from urllib.parse import parse_qs, urlparse

from PySide6.QtCore import Qt, QTimer, QUrl, Signal
from PySide6.QtWidgets import (QDialog, QHBoxLayout, QLabel, QLineEdit, QPushButton,
                               QStackedLayout, QVBoxLayout, QWidget)

from ...comptes import NATURES, Plateforme
from ...core.logging_setup import get

log = get("ui.connexion")

try:
    from PySide6.QtWebEngineCore import (QWebEngineLoadingInfo, QWebEnginePage,
                                         QWebEngineProfile, QWebEngineScript,
                                         QWebEngineSettings)
    from PySide6.QtWebEngineWidgets import QWebEngineView
    WEB = True
except Exception:                                   # module absent
    WEB = False


def web_disponible() -> bool:
    return WEB


# ----------------------------------------------------------------------
# textes
# ----------------------------------------------------------------------
CLE_INDISPONIBLE = ("Les cles de securite (passkeys) ne fonctionnent pas dans cette "
                    "fenetre : choisissez une autre methode de connexion (mot de passe "
                    "ou code).")
REFUS_GOOGLE = ("Google refuse les connexions depuis une fenetre integree a une "
                "application (« Ce navigateur ou cette application ne sont peut-etre pas "
                "securises ») et ORION ne contourne pas cette protection. Fermez la "
                "fenetre Google et connectez-vous avec l'adresse e-mail et le mot de "
                "passe de votre compte {nom}.")
REFUS_GOOGLE_ANNEXE = ("Google refuse la connexion dans cette fenetre. Fermez-la : la "
                       "marche a suivre est affichee dans la fenetre de connexion d'ORION.")
TELECHARGEMENT_IGNORE = ("Telechargement ignore : la fenetre de connexion n'enregistre "
                         "aucun fichier.")


# ----------------------------------------------------------------------
# aides pures (testables sans navigateur)
# ----------------------------------------------------------------------
_QTWEBENGINE = re.compile(r"\s*\bQtWebEngine/\S+")


def ua_standard(ua: str) -> str:
    """Identite du navigateur sans la mention « QtWebEngine/x.y » : reste
    celle de Chrome, a la version exacte du moteur embarque."""
    return " ".join(_QTWEBENGINE.sub("", ua or "").split())


def script_sans_cle(domaines) -> str:
    """Script injecte des la creation du document, sur les seuls domaines
    donnes : la page voit les cles de securite (WebAuthn) comme absentes et
    propose le mot de passe ou un code. Il ne lit ni n'envoie rien."""
    liste = json.dumps(sorted({str(d).lower().strip(".") for d in domaines if d}))
    return """(function () {
  "use strict";
  var domaines = __DOMAINES__;
  var hote = String(location.hostname || "").toLowerCase();
  var vise = domaines.some(function (d) {
    return hote === d || hote.slice(-(d.length + 1)) === "." + d;
  });
  if (!vise) { return; }
  /* ORION : cles de securite masquees, la page propose mot de passe ou code */
  try { delete window.PublicKeyCredential; } catch (e) {}
  if (typeof window.PublicKeyCredential !== "undefined") {
    try {
      Object.defineProperty(window, "PublicKeyCredential",
                            {value: undefined, configurable: true, writable: true});
    } catch (e) {}
  }
  var c = navigator.credentials;
  if (c) {
    var refus = function () {
      return Promise.reject(new DOMException(
        "Cles de securite indisponibles dans cette fenetre", "NotAllowedError"));
    };
    try { Object.defineProperty(c, "create", {value: refus, configurable: true}); } catch (e) {}
    try { Object.defineProperty(c, "get", {value: refus, configurable: true}); } catch (e) {}
  }
})();""".replace("__DOMAINES__", liste)


def refus_google(adresse: str) -> bool:
    """Vrai sur la page ou Google refuse la connexion dans un navigateur
    integre (« Ce navigateur ou cette application ne sont peut-etre pas
    securises », erreur 403 disallowed_useragent)."""
    u = urlparse(adresse or "")
    if (u.hostname or "").lower() != "accounts.google.com":
        return False
    if "/signin/rejected" in u.path or "disallowed_useragent" in (adresse or ""):
        return True
    if "/oauth/error" in u.path:
        for v in parse_qs(u.query).get("authError", []):
            try:
                brut = base64.urlsafe_b64decode(v + "=" * (-len(v) % 4))
            except Exception:
                continue
            if b"disallowed_useragent" in brut:
                return True
    return False


def adresse_retour_valide(plateforme, texte: str) -> bool:
    """Vrai pour l'adresse de fin de connexion, code compris (collee par le joueur)."""
    texte = (texte or "").strip()
    if len(texte) > 2000 or not plateforme.est_retour(texte):
        return False
    return bool((parse_qs(urlparse(texte).query).get("code") or [""])[0])


def hote_de(adresse: str) -> str:
    return urlparse(adresse or "").hostname or ""


def message_certificat(hote: str) -> str:
    return (f"Le certificat de securite de {hote or 'ce site'} n'est pas valide : la page "
            "a ete bloquee pour vous proteger. Verifiez la date et l'heure de Windows ; "
            "un antivirus ou un proxy qui inspecte les connexions HTTPS peut aussi en "
            "etre la cause.")


_ERREURS = (
    ((-106,), "Pas de connexion Internet : verifiez le Wi-Fi ou le cable, puis reessayez."),
    ((-105, -137), "Le site {hote} est introuvable : verifiez la connexion Internet."),
    ((-7, -118), "{hote} ne repond pas (delai depasse)."),
    ((-21, -100, -101, -102, -104, -109), "La connexion a {hote} a ete coupee ou refusee."),
    ((-111, -115, -127, -130), "Le proxy configure sur ce PC empeche d'atteindre {hote}."),
)


def message_erreur(code: int, hote: str) -> str:
    """Erreur de chargement en clair (codes d'erreur reseau de Chromium)."""
    hote = hote or "la plateforme"
    code = -abs(int(code or 0))
    if -299 <= code <= -200:
        return message_certificat(hote)
    for codes, texte in _ERREURS:
        if code in codes:
            return texte.format(hote=hote)
    return f"La page de {hote} n'a pas pu etre chargee (erreur {code})."


def _plus_tard(contexte, fonction, delai: int = 0) -> None:
    """Appel differe, annule si `contexte` est detruit entre-temps."""
    plus_tard(contexte, delai, fonction)


def _maj_barre(barre: QLabel, texte: str) -> None:
    if not texte:
        return                       # page pas encore chargee : on garde l'ancienne
    u = urlparse(texte)
    sur = u.scheme == "https"
    barre.setText(("🔒 " if sur else "⚠ ") + (u.hostname or texte))
    barre.setProperty("sur", sur)
    barre.style().unpolish(barre)
    barre.style().polish(barre)


if WEB:
    class _Page(QWebEnginePage):
        retour = Signal(str)

        def __init__(self, profil, plateforme: Plateforme, parent=None,
                     ouvrir=None) -> None:
            super().__init__(profil, parent)
            self._plateforme = plateforme
            self._ouvrir = ouvrir                   # fenetres surgissantes
            s = self.settings()
            s.setAttribute(QWebEngineSettings.WebAttribute.PluginsEnabled, False)
            # erreurs affichees en francais par ORION (voir _Surface)
            s.setAttribute(QWebEngineSettings.WebAttribute.ErrorPageEnabled, False)

        def acceptNavigationRequest(self, url, type_, principal) -> bool:  # noqa: N802
            adresse = url.toString()
            if principal and self._plateforme.est_retour(adresse):
                # traite apres ce rappel : naviguer depuis ici fait planter
                # le moteur web
                _plus_tard(self, lambda: self.retour.emit(adresse))
                return False                         # on ne charge pas la page
            return super().acceptNavigationRequest(url, type_, principal)

        def createWindow(self, type_):              # noqa: N802
            # fenetre surgissante ou nouvel onglet : vraie nouvelle page (le
            # lien window.opener est garde), affichee dans une petite fenetre
            if self._ouvrir is None:
                return None
            try:
                return self._ouvrir(type_)
            except Exception:
                log.exception("Fenetre surgissante impossible")
                return None

    class _Surface(QWidget):
        """Vue web + message d'erreur en francais (avec « Reessayer ») a la
        place des pages d'erreur du moteur."""

        def __init__(self, parent=None) -> None:
            super().__init__(parent)
            self._pile = QStackedLayout(self)
            self.vue = QWebEngineView(self)
            self._pile.addWidget(self.vue)
            panneau = QWidget(self)
            lay = QVBoxLayout(panneau)
            lay.setContentsMargins(24, 24, 24, 24)
            lay.addStretch(1)
            self.message = QLabel("")
            self.message.setWordWrap(True)
            self.message.setAlignment(Qt.AlignmentFlag.AlignCenter)
            lay.addWidget(self.message)
            ligne = QHBoxLayout()
            ligne.addStretch(1)
            self.reessayer = QPushButton("Reessayer")
            self.reessayer.clicked.connect(self._reessayer)
            ligne.addWidget(self.reessayer)
            ligne.addStretch(1)
            lay.addLayout(ligne)
            lay.addStretch(1)
            self._pile.addWidget(panneau)
            self._echec = ""
            #: adresses dont l'echec n'en est pas un (retour intercepte)
            self.ignorer = lambda _adresse: False

        def brancher(self, page) -> None:
            self.vue.setPage(page)
            page.loadingChanged.connect(self._chargement)
            page.certificateError.connect(self._certificat)

        def en_erreur(self) -> bool:
            return self._pile.currentIndex() == 1

        def erreur(self, message: str, adresse: str = "") -> None:
            self._echec = adresse
            self.message.setText(message)
            self._pile.setCurrentIndex(1)

        def _reessayer(self) -> None:
            self._pile.setCurrentIndex(0)
            if self._echec:
                self.vue.setUrl(QUrl(self._echec))
            else:
                self.vue.reload()

        def _chargement(self, info) -> None:
            S = QWebEngineLoadingInfo.LoadStatus
            statut = info.status()
            if statut == S.LoadSucceededStatus:
                if not info.isErrorPage():
                    self._pile.setCurrentIndex(0)
                return
            if statut != S.LoadFailedStatus:
                return
            D = QWebEngineLoadingInfo.ErrorDomain
            domaine, code = info.errorDomain(), int(info.errorCode() or 0)
            adresse = info.url().toString()
            if domaine == D.HttpStatusCodeDomain:
                return                  # le site affiche lui-meme sa page d'erreur
            if abs(code) == 3 or self.ignorer(adresse):
                return                  # navigation interrompue / retour intercepte
            log.info("Chargement impossible (%s, %s) : %s", domaine, code, adresse)
            if domaine == D.CertificateErrorDomain:
                self.erreur(message_certificat(hote_de(adresse)), adresse)
            else:
                self.erreur(message_erreur(code, hote_de(adresse)), adresse)

        def _certificat(self, err) -> None:
            try:
                err.rejectCertificate()             # jamais d'exception de securite
            except Exception:
                pass
            adresse = err.url().toString()
            log.warning("Certificat refuse : %s (%s)", adresse, err.description())
            principal = err.isMainFrame() if hasattr(err, "isMainFrame") else True
            if principal:
                self.erreur(message_certificat(hote_de(adresse)), adresse)

    class _Fenetre(QDialog):
        """Fenetre surgissante ouverte par la page (« Se connecter avec
        Google », lien vers un nouvel onglet) : meme profil prive, et la page
        qui l'a ouverte garde le lien avec elle (window.opener)."""

        def __init__(self, hote: "FenetreConnexion", parent: QWidget) -> None:
            super().__init__(parent)
            self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
            self._titre = f"Connexion a {hote.plateforme.nom}"
            self.setWindowTitle(self._titre)
            self.resize(520, 700)
            lay = QVBoxLayout(self)
            lay.setContentsMargins(10, 10, 10, 10)
            lay.setSpacing(6)
            self.barre = QLabel()
            self.barre.setObjectName("BarreAdresse")
            self.barre.setTextInteractionFlags(
                Qt.TextInteractionFlag.TextSelectableByMouse)
            lay.addWidget(self.barre)
            self.conseil = QLabel("")
            self.conseil.setObjectName("Alerte")
            self.conseil.setWordWrap(True)
            self.conseil.hide()
            lay.addWidget(self.conseil)
            self.surface = _Surface(self)
            self.surface.ignorer = hote.plateforme.est_retour
            lay.addWidget(self.surface, 1)
            # page creee APRES la vue : detruite apres elle, et avant le profil
            self.page = _Page(hote.profil, hote.plateforme, self,
                              ouvrir=hote._ouvrir_fenetre)
            hote._brancher(self.page)
            self.surface.brancher(self.page)
            self.page.windowCloseRequested.connect(self.close)
            self.page.titleChanged.connect(
                lambda t: self.setWindowTitle(t or self._titre))
            self.page.geometryChangeRequested.connect(self._geometrie)
            self.surface.vue.urlChanged.connect(
                lambda u: hote._adresse_annexe(self, u))
            bas = QHBoxLayout()
            bas.addStretch(1)
            fermer = QPushButton("Fermer")
            fermer.setObjectName("Ghost")
            fermer.clicked.connect(self.close)
            bas.addWidget(fermer)
            lay.addLayout(bas)

        def _geometrie(self, rect) -> None:
            # taille demandee par window.open, dans des limites raisonnables
            if rect.width() > 0 and rect.height() > 0:
                self.resize(min(max(rect.width(), 380), 1000) + 20,
                            min(max(rect.height(), 420), 860) + 110)

        def signaler(self, texte: str) -> None:
            self.conseil.setText(texte)
            self.conseil.show()


class FenetreConnexion(QDialog):
    """Connexion a une plateforme. `resultat` : adresse de retour ou « »."""

    def __init__(self, plateforme: Plateforme, parent=None, adresse: str = "",
                 consigne: str = "") -> None:
        super().__init__(parent)
        self.plateforme = plateforme
        self.resultat = ""
        self._fenetres: list = []
        self.setWindowTitle(f"Connexion a {plateforme.nom}")
        self.resize(560, 760)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 14, 14, 14)
        lay.setSpacing(8)

        titre = QLabel(f"<b>{plateforme.nom}</b> · {NATURES[plateforme.nature]}")
        lay.addWidget(titre)
        garantie = self.garantie = QLabel(
            consigne or
            f"Vous etes sur la page officielle de {plateforme.nom}. ORION ne lit pas "
            "votre mot de passe : il recoit seulement un jeton de connexion, garde "
            "chiffre sur ce PC. Rien n'est conserve de cette fenetre a sa fermeture.")
        garantie.setWordWrap(True)
        garantie.setObjectName("Dim")
        lay.addWidget(garantie)

        # conseil permanent (Microsoft : cle de securite) ou explication
        # (Google refuse la fenetre integree)
        self.conseil = QLabel(getattr(plateforme, "conseil_connexion", "") or "")
        self.conseil.setObjectName("Alerte")
        self.conseil.setWordWrap(True)
        self.conseil.setVisible(bool(self.conseil.text()))
        lay.addWidget(self.conseil)

        self.barre = QLabel()
        self.barre.setObjectName("BarreAdresse")
        self.barre.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        lay.addWidget(self.barre)

        if WEB:
            # Ordre de destruction (enfants Qt detruits dans leur ordre de
            # creation) : fenetres surgissantes, puis vue, puis page, puis
            # profil (enfant de la page). Un profil detruit avant une de ses
            # pages fait planter le moteur (« Release of profile requested
            # but WebEnginePage still not deleted »).
            self._annexes = QWidget(self)           # parent des surgissantes
            self._annexes.hide()
            self.surface = _Surface(self)
            self.surface.ignorer = plateforme.est_retour
            self.vue = self.surface.vue
            # profil prive (rien sur le disque)
            self.profil = QWebEngineProfile()
            self._preparer_profil(self.profil)
            self.page = _Page(self.profil, plateforme, self, ouvrir=self._ouvrir_fenetre)
            self.profil.setParent(self.page)     # detruit apres la page, jamais avant
            self._brancher(self.page)
            self.surface.brancher(self.page)
            self.vue.urlChanged.connect(self._adresse)
            lay.addWidget(self.surface, 1)
        else:
            absent = QLabel("Le navigateur integre n'est pas disponible dans cette "
                            "installation d'ORION.")
            absent.setWordWrap(True)
            lay.addWidget(absent, 1)

        # voie de secours : connexion dans le navigateur habituel du joueur
        # (Google y accepte la connexion), puis adresse finale collee ici
        self._navigateur_ok = bool(getattr(plateforme, "connexion_navigateur", False)) \
            and not adresse
        self.voie = QWidget(self)
        vlay = QVBoxLayout(self.voie)
        vlay.setContentsMargins(0, 0, 0, 0)
        vlay.setSpacing(6)
        etapes = QLabel(
            "1. Connectez-vous dans votre navigateur (il vient de s'ouvrir). "
            "2. Une fois connecte, la page devient blanche : copiez son adresse "
            "(Ctrl+L puis Ctrl+C). 3. ORION la reconnait tout seul ; sinon collez-la ici.")
        etapes.setWordWrap(True)
        vlay.addWidget(etapes)
        ligne = QHBoxLayout()
        self.champ_adresse = QLineEdit()
        self.champ_adresse.setPlaceholderText("Adresse de la page blanche (https://embed.gog.com/...)")
        self.champ_adresse.returnPressed.connect(self._valider_adresse)
        ligne.addWidget(self.champ_adresse, 1)
        valider = QPushButton("Valider")
        valider.clicked.connect(self._valider_adresse)
        ligne.addWidget(valider)
        vlay.addLayout(ligne)
        self.voie.hide()
        lay.addWidget(self.voie)
        self._presse = QTimer(self)
        self._presse.timeout.connect(self._lire_presse_papiers)

        bas = QHBoxLayout()
        self.etat = QLabel("")
        self.etat.setObjectName("Faint")
        self.etat.setWordWrap(True)
        bas.addWidget(self.etat, 1)
        self.cle = ""
        self._minuterie = QTimer(self)
        self._minuterie.timeout.connect(lambda: self.lire_texte(self._chercher))
        self.passer = QPushButton("Plus tard")
        self.passer.setObjectName("Ghost")
        self.passer.setToolTip("Terminer sans cle : ORION n'aura que votre identifiant Steam.")
        self.passer.clicked.connect(self.accept)
        self.passer.hide()
        bas.addWidget(self.passer)
        self.bouton_navigateur = QPushButton("Se connecter avec mon navigateur")
        self.bouton_navigateur.setObjectName("Ghost")
        self.bouton_navigateur.setToolTip(
            "Ouvre la page officielle dans votre navigateur habituel : utile pour "
            "« Se connecter avec Google », que Google refuse dans une fenetre integree.")
        self.bouton_navigateur.clicked.connect(self._par_navigateur)
        self.bouton_navigateur.setVisible(self._navigateur_ok)
        bas.addWidget(self.bouton_navigateur)
        annuler = QPushButton("Annuler")
        annuler.setObjectName("Ghost")
        annuler.clicked.connect(self.reject)
        bas.addWidget(annuler)
        lay.addLayout(bas)

        if WEB:
            self.vue.setUrl(QUrl(adresse or plateforme.adresse_connexion()))
            if adresse:                     # etape directe : cle Steam seule
                self.resultat = "-"
                self.passer.show()
                self._minuterie.start(1500)

    # ------------------------------------------------------------------
    # navigateur
    # ------------------------------------------------------------------
    def _preparer_profil(self, profil) -> None:
        profil.setHttpAcceptLanguage("fr-FR,fr;q=0.9,en;q=0.6")
        # identite standard de Chrome (meme version que le moteur)
        profil.setHttpUserAgent(ua_standard(profil.httpUserAgent()))
        profil.downloadRequested.connect(self._telechargement)
        domaines = getattr(self.plateforme, "domaines_sans_cle", ()) or ()
        if domaines:
            script = QWebEngineScript()
            script.setName("orion-sans-cle-de-securite")
            script.setSourceCode(script_sans_cle(domaines))
            script.setInjectionPoint(QWebEngineScript.InjectionPoint.DocumentCreation)
            script.setWorldId(QWebEngineScript.ScriptWorldId.MainWorld)
            script.setRunsOnSubFrames(True)
            profil.scripts().insert(script)

    def _brancher(self, page) -> None:
        """Liens communs a la page principale et aux surgissantes."""
        page.retour.connect(self._retour)
        if hasattr(page, "webAuthUxRequested"):    # Qt 6.7 et suivants
            page.webAuthUxRequested.connect(self._cle_securite)

    def _ouvrir_fenetre(self, _type):
        if not self.isVisible():
            return None
        f = _Fenetre(self, self._annexes)
        self._fenetres.append(f)
        f.show()
        f.raise_()
        f.activateWindow()
        return f.page

    def fenetres_ouvertes(self) -> list:
        """Fenetres surgissantes encore en vie."""
        try:
            from shiboken6 import isValid
        except Exception:                            # pragma: no cover
            def isValid(_o):                          # noqa: N802
                return True
        self._fenetres = [f for f in self._fenetres if isValid(f)]
        return list(self._fenetres)

    def _telechargement(self, demande) -> None:
        try:
            demande.cancel()
        except Exception:
            pass
        log.info("Telechargement ignore dans la fenetre de connexion")
        self.etat.setText(TELECHARGEMENT_IGNORE)

    def _cle_securite(self, demande) -> None:
        # le navigateur integre n'a pas d'interface pour les cles : la demande
        # est annulee et la page propose une autre methode
        try:
            demande.cancel()
        except Exception:
            pass
        self.signaler(getattr(self.plateforme, "conseil_connexion", "") or CLE_INDISPONIBLE)

    def signaler(self, texte: str) -> None:
        self.conseil.setText(texte)
        self.conseil.show()

    # ------------------------------------------------------------------
    # connexion par le navigateur habituel
    # ------------------------------------------------------------------
    def _par_navigateur(self) -> None:
        from PySide6.QtGui import QDesktopServices
        QDesktopServices.openUrl(QUrl(self.plateforme.adresse_connexion()))
        self.voie.show()
        self.champ_adresse.setFocus()
        self.etat.setText("En attente de l'adresse copiee dans votre navigateur...")
        self._presse.start(800)

    def _lire_presse_papiers(self) -> None:
        if not self.isVisible():
            self._presse.stop()
            return
        from PySide6.QtWidgets import QApplication
        texte = (QApplication.clipboard().text() or "").strip()
        if adresse_retour_valide(self.plateforme, texte):
            self.champ_adresse.setText(texte)
            self._valider_adresse()

    def _valider_adresse(self) -> None:
        texte = self.champ_adresse.text().strip()
        if not adresse_retour_valide(self.plateforme, texte):
            self.etat.setText("Cette adresse n'est pas la page de fin de connexion : "
                              "elle doit contenir « code= ».")
            return
        self._presse.stop()
        self._retour(texte)

    def _refus_google(self, fenetre=None) -> None:
        log.info("Google refuse la connexion dans la fenetre integree")
        texte = (getattr(self.plateforme, "aide_refus_google", "")
                 or REFUS_GOOGLE.format(nom=self.plateforme.nom))
        if self._navigateur_ok:
            texte = ("Google refuse les fenetres integrees. Cliquez sur « Se connecter "
                     "avec mon navigateur » en bas : la connexion Google y fonctionne.")
        self.signaler(texte)
        if fenetre is not None:
            fenetre.signaler(REFUS_GOOGLE_ANNEXE)

    def _adresse_annexe(self, fenetre, url: QUrl) -> None:
        texte = url.toString()
        _maj_barre(fenetre.barre, texte)
        if refus_google(texte):
            self._refus_google(fenetre)
        if self.plateforme.est_retour(texte):
            self._retour(texte)
            fenetre.close()

    # ------------------------------------------------------------------
    def _adresse(self, url: QUrl) -> None:
        texte = url.toString()
        _maj_barre(self.barre, texte)
        if refus_google(texte):
            self._refus_google()
        # certaines plateformes finissent par une redirection cote client
        if self.plateforme.est_retour(texte):
            self._retour(texte)

    def _retour(self, adresse: str) -> None:
        if self.resultat:
            return
        self.resultat = adresse
        suite = self.plateforme.etape_apres_connexion() if hasattr(
            self.plateforme, "etape_apres_connexion") else None
        if suite and WEB:
            # deuxieme etape dans la meme fenetre (meme session) : cle Steam
            adresse_suite, consigne = suite
            for f in self.fenetres_ouvertes():
                f.close()
            self.garantie.setText(consigne)
            self.etat.setText("Connecte. Derniere etape ci-dessus.")
            self.passer.show()
            self.vue.setUrl(QUrl(adresse_suite))
            self._minuterie.start(1500)
            return
        self.etat.setText("Connexion reussie, verification...")
        _plus_tard(self, self.accept, 150)

    def _chercher(self, texte: str) -> None:
        if not self.isVisible():
            return               # reponse tardive : fenetre deja fermee (et liberee)
        cle = self.plateforme.cle_dans_page(texte)
        if cle and not self.cle:
            self.cle = cle
            self._minuterie.stop()
            self.etat.setText("Cle trouvee et gardee chiffree.")
            _plus_tard(self, self.accept, 500)

    def lire_texte(self, rappel) -> None:
        """Texte visible de la page courante (sert a reperer la cle Steam
        affichee apres sa creation par le joueur)."""
        if WEB:
            self.page.runJavaScript("document.body ? document.body.innerText : ''", 0,
                                    lambda t: rappel(t or ""))

    def done(self, r: int) -> None:                 # noqa: D401 (Qt)
        if WEB:
            self._minuterie.stop()
            # surgissantes fermees (et liberees) avec la fenetre ; si la
            # fenetre est detruite d'abord, elles partent avant la page
            for f in self.fenetres_ouvertes():
                f.close()
            try:
                self.profil.cookieStore().deleteAllCookies()
                self.profil.clearHttpCache()
            except Exception:
                pass
        super().done(r)
