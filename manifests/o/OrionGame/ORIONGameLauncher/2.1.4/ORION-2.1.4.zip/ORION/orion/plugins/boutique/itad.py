"""IsThereAnyDeal : toutes les boutiques autorisees, en euros.

C'est ce qui fait de la Boutique un vrai comparateur : Fanatical, Humble,
Green Man Gaming, Gamesplanet, GamersGate, Epic, Ubisoft, Microsoft... et le
plus bas prix jamais releve. IsThereAnyDeal n'indexe que des vendeurs
autorises par les editeurs, ce qui colle a la politique de confiance.

Le joueur n'a rien a configurer : les demandes passent par le relais du
service d'ORION, qui porte la cle de l'application (voir `orion/itad.py`).
Une cle personnelle, saisie dans les Reglages, fait passer en direct.
"""
from __future__ import annotations

from datetime import datetime

from ... import itad as acces
from ...core.config import CONFIG
from .base import Offre, SourceBoutique, SourceUnavailable, log


def _pays() -> str:
    pays = str(CONFIG.get("market.country") or "FR").strip().upper()
    return pays if len(pays) == 2 and pays.isalpha() else "FR"


def _demander(methode: str, chemin: str, params: dict, corps=None, timeout: float = 20):
    try:
        return acces.demander(methode, chemin, params, corps, timeout)
    except acces.Indisponible as exc:
        raise SourceUnavailable(str(exc)) from exc


def _montant(bloc) -> float:
    try:
        return round(float((bloc or {}).get("amount") or 0), 2)
    except (TypeError, ValueError):
        return 0.0


def _date(texte) -> float:
    if not texte:
        return 0.0
    try:
        return datetime.fromisoformat(str(texte).replace("Z", "+00:00")).timestamp()
    except ValueError:
        return 0.0


def _image(assets) -> str:
    a = assets or {}
    return a.get("banner400") or a.get("banner300") or a.get("banner600") \
        or a.get("boxart") or ""


def _offre(titre, itad_id, deal, image="", bas=0.0, type_article="") -> Offre:
    return Offre(
        titre=titre, boutique=(deal.get("shop") or {}).get("name", "?"),
        prix=_montant(deal.get("price")),
        prix_normal=_montant(deal.get("regular")),
        remise=int(deal.get("cut") or 0),
        devise=(deal.get("price") or {}).get("currency", "EUR"),
        url=deal.get("url", ""), source="itad", itad_id=itad_id, image=image,
        fin_promo=_date(deal.get("expiry")),
        plus_bas_historique=_montant(deal.get("historyLow")) or bas,
        drm=", ".join(d.get("name", "") for d in (deal.get("drm") or [])[:2]),
        type_article=str(type_article or ""))


class ITADBoutique(SourceBoutique):
    id = "itad"
    label = "IsThereAnyDeal"
    priority = 90
    needs_key = True
    filtre_adulte = ("drapeau « mature » d'IsThereAnyDeal : vitrine demandee avec "
                     "mature=false, resultats de recherche marques ecartes")

    def available(self) -> bool:
        return acces.actif()

    def vitrine(self) -> list[Offre]:
        out: list[Offre] = []
        # « en vogue » et « les plus suivis » ramenent les jeux connus ; « plus
        # grosse remise » complete. Sans tri, la liste est surtout faite de
        # DLC et de bandes originales (constate le 6 octobre 2026 : 50 jeux
        # sur 200, contre 197 et 196 avec ces deux tris).
        for sort in ("-trending", "rank", "-cut"):
            params = {"country": _pays(), "limit": 200, "mature": "false"}
            if sort:
                params["sort"] = sort
            data = _demander("GET", "/deals/v2", params) or {}
            for it in data.get("list") or []:
                if it.get("type") not in (None, "game"):
                    continue    # DLC, lots
                if not acces.du_pays([it.get("deal") or {}], _pays()):
                    continue    # vitrine d'un autre pays (orion/itad.py)
                o = _offre(it.get("title", ""), it.get("id", ""),
                           it.get("deal") or {}, _image(it.get("assets")),
                           type_article=it.get("type") or "")
                o.adulte = self.adulte(it)          # drapeau « mature »
                out.append(o)
        return out

    def chercher(self, terme: str) -> list[Offre]:
        trouves = _demander("GET", "/games/search/v1",
                            {"title": terme.strip()[:80], "results": 12})
        jeux = {g["id"]: g for g in trouves or []
                if g.get("id") and g.get("type") in (None, "game")
                and not self.adulte(g)}     # drapeau « mature »
        return self.prix(jeux)

    def prix(self, jeux: dict[str, dict]) -> list[Offre]:
        """Toutes les offres de chaque jeu : {itad_id: {title, assets}}."""
        if not jeux:
            return []
        entrees: list = []
        ids = list(jeux)
        for i in range(0, len(ids), 60):           # le relais prend 60 jeux par demande
            entrees += _demander("POST", "/games/prices/v3",
                                 {"country": _pays(), "nondeals": "true", "capacity": 30},
                                 ids[i:i + 60]) or []
        out: list[Offre] = []
        for e in entrees or []:
            jeu = jeux.get(e.get("id")) or {}
            bas = _montant((e.get("historyLow") or {}).get("all"))
            for deal in acces.du_pays(e.get("deals") or [], _pays()):
                out.append(_offre(jeu.get("title", ""), e.get("id", ""), deal,
                                  _image(jeu.get("assets")), bas,
                                  jeu.get("type") or ""))
        return out

    def trouver(self, titre: str = "", appid: str = "") -> dict[str, dict]:
        """Identifiant IsThereAnyDeal d'un jeu, par appid Steam ou titre."""
        params = {"appid": appid} if appid else {"title": titre.strip()[:120]}
        try:
            data = _demander("GET", "/games/lookup/v1", params) or {}
        except SourceUnavailable as exc:
            log.debug("%s", exc)
            return {}
        g = data.get("game") or {}
        return {g["id"]: g} if data.get("found") and g.get("id") else {}
