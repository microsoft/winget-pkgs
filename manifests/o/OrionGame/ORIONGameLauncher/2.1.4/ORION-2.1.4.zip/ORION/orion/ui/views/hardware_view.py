"""Page machine : composants, ecrans et modes d'affichage."""
from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (QComboBox, QFrame, QGridLayout, QHBoxLayout,
                               QLabel, QPushButton, QVBoxLayout, QWidget)

from ...core.models import Display, DisplayMode, HardwareInfo
from ...hardware.bilan import DEFINITION as BILAN_DEFINITION
from ...i18n import t
from ..theme import PALETTE
from ..widgets.layouts import clear_layout
from ..defilement import ZoneDefilante


#: couleur du liseré selon la gravite du constat
POINT_COLORS = {"attention": PALETTE["warn"], "conseil": PALETTE["accent"],
                "ok": PALETTE["ok"]}


def _point_card(point) -> QFrame:
    """Un constat du bilan : titre, explication, liseré de couleur."""
    cadre = QFrame()
    cadre.setObjectName("Panel")
    couleur = POINT_COLORS.get(point.level, PALETTE["text_dim"])
    cadre.setStyleSheet(f"QFrame#Panel {{ border-left: 3px solid {couleur}; }}")
    lay = QVBoxLayout(cadre)
    lay.setContentsMargins(14, 10, 14, 10)
    lay.setSpacing(3)
    titre = QLabel(point.title)
    titre.setObjectName("Value")
    lay.addWidget(titre)
    detail = QLabel(point.detail)
    detail.setObjectName("Dim")
    detail.setWordWrap(True)
    lay.addWidget(detail)
    return cadre


def _panel(title: str) -> tuple[QFrame, QVBoxLayout]:
    f = QFrame()
    f.setObjectName("Panel")
    lay = QVBoxLayout(f)
    lay.setContentsMargins(18, 16, 18, 16)
    lay.setSpacing(10)
    t = QLabel(title)
    t.setObjectName("PanelTitle")
    lay.addWidget(t)
    return f, lay


def texte_configuration(hw: HardwareInfo) -> str:
    """La configuration en texte simple, a coller dans un message, un forum
    d'entraide ou une demande d'assistance. Rien de personnel : ni nom de
    session, ni numero de serie, ni chemin."""
    from ...i18n import t
    gpu = hw.gpu
    lignes = [t("Configuration (lue par ORION)")]
    if hw.cpu_name:
        lignes.append(t(f"Processeur : {hw.cpu_name} ({hw.cpu_cores} coeurs / "
                        f"{hw.cpu_threads} fils)") if hw.cpu_cores
                      else t(f"Processeur : {hw.cpu_name}"))
    if gpu.name:
        lignes.append(t(f"Carte graphique : {gpu.name}, {round(gpu.vram_mb / 1024)} Go")
                      if gpu.vram_mb else t(f"Carte graphique : {gpu.name}"))
        if gpu.driver_version:
            lignes.append(t(f"Pilote graphique : {gpu.driver_version}"))
    if hw.ram_gb:
        lignes.append(t(f"Memoire vive : {hw.ram_gb:.0f} Go"))
    if hw.os_name:
        lignes.append(t(f"Systeme : {hw.os_name}")
                      + (f" (build {hw.os_build})" if hw.os_build else ""))
    for d in hw.displays:
        mode = d.current or d.native
        if mode is None:
            continue
        nom = d.name or "?"
        definition = f"{mode.width}x{mode.height}"
        if d.max_refresh_at_native and d.max_refresh_at_native > mode.refresh:
            lignes.append(t(f"Ecran : {nom}, {definition} a {mode.refresh} Hz "
                            f"(jusqu'a {d.max_refresh_at_native} Hz)"))
        else:
            lignes.append(t(f"Ecran : {nom}, {definition} a {mode.refresh} Hz"))
    for disque in hw.disks:
        if disque.get("total_gb"):
            lettre = str(disque.get("mount", "?")).rstrip(chr(92))
            lignes.append(t(f"Disque {lettre} {disque.get('free_gb', 0)} Go libres sur "
                            f"{disque['total_gb']} Go"))
    if hw.score:
        lignes.append(t(f"Indice de configuration ORION : {hw.score}/100"))
    return "\n".join(lignes)


class HardwareView(QWidget):
    apply_mode_requested = Signal(str, object)     # device, DisplayMode
    refresh_requested = Signal()
    ai_requested = Signal()
    bilan_requested = Signal()                      # « Votre PC, en une minute » (2.0.2)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.hw: HardwareInfo | None = None

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = ZoneDefilante()
        self.scroll = scroll
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        outer.addWidget(scroll)
        body = QWidget()
        scroll.setWidget(body)
        self.root = QVBoxLayout(body)
        self.root.setContentsMargins(24, 18, 24, 24)
        self.root.setSpacing(16)

        head = QHBoxLayout()
        t = QLabel("Ma machine")
        t.setObjectName("PageTitle")
        head.addWidget(t)
        self.score = QLabel("")
        self.score.setObjectName("PageHint")
        head.addWidget(self.score)
        head.addStretch(1)
        self.b_bilan = QPushButton("Votre PC, en une minute")
        self.b_bilan.setObjectName("Ghost")
        self.b_bilan.setToolTip("Le bilan en quatre phrases : les jeux qui tournent en qualite Haute, "
                                "les pilotes a mettre a jour, la valeur de la bibliotheque, "
                                "les baisses de prix.")
        self.b_bilan.clicked.connect(self.bilan_requested.emit)
        head.addWidget(self.b_bilan)
        self.b_copier = QPushButton("Copier ma configuration")
        self.b_copier.setObjectName("Ghost")
        self.b_copier.setToolTip("Copie la configuration en texte (processeur, carte "
                                 "graphique, memoire, ecran, disques), pour la coller dans "
                                 "un message ou un forum d'entraide.")
        self.b_copier.clicked.connect(self._copier)
        self.b_copier.setEnabled(False)
        head.addWidget(self.b_copier)
        btn = QPushButton("Reanalyser")
        btn.setObjectName("Ghost")
        btn.clicked.connect(self.refresh_requested.emit)
        head.addWidget(btn)
        self.root.addLayout(head)
        self._montre: dict | None = None      # materiel affiche

        # -- avis sur la configuration ---------------------------------
        self.avis_panel, avis = _panel("Avis sur votre configuration")
        self.verdict = QLabel("")
        self.verdict.setObjectName("Value")
        self.verdict.setWordWrap(True)
        avis.addWidget(self.verdict)

        definition = QLabel(BILAN_DEFINITION)
        definition.setObjectName("Faint")
        definition.setWordWrap(True)
        avis.addWidget(definition)

        self.points_box = QVBoxLayout()
        self.points_box.setSpacing(8)
        avis.addLayout(self.points_box)

        ligne = QHBoxLayout()
        self.ai_button = QPushButton("Approfondir avec l'IA")
        self.ai_button.clicked.connect(self.ai_requested.emit)
        ligne.addWidget(self.ai_button)
        self.ai_hint = QLabel("")
        self.ai_hint.setObjectName("Faint")
        self.ai_hint.setWordWrap(True)
        ligne.addWidget(self.ai_hint, 1)
        avis.addLayout(ligne)

        self.ai_output = QLabel("")
        self.ai_output.setObjectName("Dim")
        self.ai_output.setWordWrap(True)
        self.ai_output.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextSelectableByMouse)
        self.ai_output.setVisible(False)
        avis.addWidget(self.ai_output)
        self.root.addWidget(self.avis_panel)

        # calculateur de puissance (1.8)
        from ..widgets.puissance_panel import PuissancePanel
        self.puissance = PuissancePanel()
        self.root.addWidget(self.puissance)

        self.specs_panel, self.specs_layout = _panel("Composants")
        self.specs_grid = QGridLayout()
        self.specs_grid.setHorizontalSpacing(34)
        self.specs_grid.setVerticalSpacing(8)
        self.specs_layout.addLayout(self.specs_grid)
        self.root.addWidget(self.specs_panel)

        self.displays_box = QVBoxLayout()
        self.displays_box.setSpacing(12)
        self.root.addLayout(self.displays_box)
        self.root.addStretch(1)

    # ------------------------------------------------------------------
    def chercher(self) -> None:
        """Ctrl+F : recherche d'un jeu dans « Ce que votre PC peut faire »."""
        champ = self.puissance.recherche
        champ.setFocus()
        champ.selectAll()
        self.scroll.ensureWidgetVisible(champ)

    def set_bilan(self, points: list, verdict_text: str,
                  ai_ready: bool) -> None:
        """Affiche le bilan local, et dit si l'IA peut aller plus loin."""
        self.verdict.setText(verdict_text)
        clear_layout(self.points_box)
        for point in points:
            self.points_box.addWidget(_point_card(point))
        self.ai_button.setEnabled(ai_ready)
        self.ai_hint.setText(
            "L'IA relit ce bilan et repond dans le detail."
            if ai_ready else
            "Facultatif : renseignez une cle d'IA dans Reglages pour obtenir "
            "une lecture detaillee. Le bilan ci-dessus n'en a pas besoin.")

    def set_ai_answer(self, text: str) -> None:
        self.ai_output.setText(text)
        self.ai_output.setVisible(bool(text))
        self.ai_button.setEnabled(True)
        self.ai_button.setText("Approfondir avec l'IA")

    def set_ai_busy(self) -> None:
        self.ai_button.setEnabled(False)
        self.ai_button.setText("L'IA reflechit...")

    def _copier(self) -> None:
        if self.hw is None:
            return
        from PySide6.QtWidgets import QApplication
        QApplication.clipboard().setText(texte_configuration(self.hw))
        self.b_copier.setText("Copie !")
        from ..minuteur import plus_tard
        plus_tard(self, 1800, lambda: self.b_copier.setText("Copier ma configuration"))

    def set_hardware(self, hw: HardwareInfo) -> None:
        self.hw = hw
        self.b_copier.setEnabled(bool(hw.cpu_name or hw.gpu.name))
        # meme materiel qu'a l'ecran (analyse relancee, mode d'affichage
        # inchange) : les blocs ne sont pas reconstruits
        etat = hw.to_dict()
        if etat == self._montre:
            return
        self._montre = etat
        self.score.setText(f"indice de configuration {hw.score}/100")

        clear_layout(self.specs_grid)

        gpu = hw.gpu
        rows = [
            ("Processeur", f"{hw.cpu_name}"),
            ("Coeurs / fils", f"{hw.cpu_cores} / {hw.cpu_threads}"),
            ("Memoire vive", f"{hw.ram_gb} Go"),
            ("Carte graphique", gpu.name or "-"),
            ("Memoire video", f"{gpu.vram_mb} Mo" if gpu.vram_mb else "-"),
            ("Pilote graphique", gpu.driver_version or "-"),
            ("Systeme", f"{hw.os_name} (build {hw.os_build})"),
            ("Technologies", self._features(gpu.features) or "-"),
        ]
        for i, (k, v) in enumerate(rows):
            kl = QLabel(k)
            kl.setObjectName("Key")
            vl = QLabel(str(v))
            vl.setObjectName("Value")
            vl.setWordWrap(True)
            self.specs_grid.addWidget(kl, i // 2, (i % 2) * 2)
            self.specs_grid.addWidget(vl, i // 2, (i % 2) * 2 + 1)

        if hw.disks:
            row = len(rows) // 2 + 1
            kl = QLabel("Stockage")
            kl.setObjectName("Key")
            self.specs_grid.addWidget(kl, row, 0)
            txt = "   ".join(f"{d['mount']} {d['free_gb']} Go libres "
                            f"/ {d['total_gb']} Go" for d in hw.disks)
            vl = QLabel(txt)
            vl.setObjectName("Value")
            vl.setWordWrap(True)
            self.specs_grid.addWidget(vl, row, 1, 1, 3)

        clear_layout(self.displays_box)
        if not hw.displays:
            panel, lay = _panel("Ecrans")
            msg = QLabel("Aucun ecran detecte : la gestion des modes "
                         "d'affichage n'est disponible que sous Windows.")
            msg.setObjectName("Dim")
            msg.setWordWrap(True)
            lay.addWidget(msg)
            self.displays_box.addWidget(panel)
        for d in hw.displays:
            self.displays_box.addWidget(self._display_panel(d))

    @staticmethod
    def _features(features: list[str]) -> str:
        from ...hardware.gpu import FEATURES
        return ", ".join(t(FEATURES.get(f, f)) for f in features)

    def _display_panel(self, display: Display) -> QFrame:
        title = display.name + (t("  (ecran principal)") if display.primary else "")
        panel, lay = _panel(title)

        info = QLabel(
            f"Mode actuel : {display.current}   ·   "
            f"Definition native : {display.native}   ·   "
            f"{len(display.modes)} modes disponibles")
        info.setObjectName("Dim")
        lay.addWidget(info)

        row = QHBoxLayout()
        row.setSpacing(10)
        combo = QComboBox()
        combo.setMinimumWidth(260)
        native = display.native or display.current
        for m in display.modes:
            label = f"{m.width} x {m.height}  -  {m.refresh} Hz"
            if native and m.width == native.width and m.height == native.height:
                label += t("   (definition native)")
            elif native and m.pixels > native.pixels:
                label += t("   (super-resolution DSR/VSR)")
            combo.addItem(label, m)
        if display.current:
            for i in range(combo.count()):
                m: DisplayMode = combo.itemData(i)
                if (m.width, m.height, m.refresh) == (
                        display.current.width, display.current.height,
                        display.current.refresh):
                    combo.setCurrentIndex(i)
                    break
        row.addWidget(combo)

        apply_btn = QPushButton("Appliquer ce mode")
        apply_btn.setObjectName("Ghost")
        apply_btn.clicked.connect(
            lambda: self.apply_mode_requested.emit(display.device, combo.currentData()))
        row.addWidget(apply_btn)

        best = QPushButton("Frequence maximale")
        best.setObjectName("Ghost")

        def _best() -> None:
            n = display.native or display.current
            if n:
                hz = display.best_refresh(n.width, n.height)
                self.apply_mode_requested.emit(
                    display.device, DisplayMode(n.width, n.height, hz))
        best.clicked.connect(_best)
        row.addWidget(best)
        row.addStretch(1)
        lay.addLayout(row)
        return panel
