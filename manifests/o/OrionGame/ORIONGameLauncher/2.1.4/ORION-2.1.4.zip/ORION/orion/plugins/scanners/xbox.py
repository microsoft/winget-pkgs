"""Detection des jeux Xbox / Microsoft Store (Game Pass PC)."""
from __future__ import annotations

import json
import re
from pathlib import Path

from ...core.logging_setup import get
from ...core.models import Game
from ...core.paths import is_windows
from ...core.winutil import dir_size, run_powershell
from .base import Scanner, detect_engine, pick_main_exe

log = get("scan.xbox")

XBOX_ROOTS = [Path(r"C:\XboxGames"), Path(r"D:\XboxGames"), Path(r"E:\XboxGames")]

PS_LIST = r"""
$out = @()
Get-AppxPackage | Where-Object { -not $_.IsFramework -and $_.InstallLocation } | ForEach-Object {
  $m = Join-Path $_.InstallLocation 'AppxManifest.xml'
  if (Test-Path $m) {
    $x = [xml](Get-Content $m -Raw -ErrorAction SilentlyContinue)
    $app = $x.Package.Applications.Application
    if ($app -is [array]) { $app = $app[0] }
    $isGame = ($x.OuterXml -match 'windows\.xbox' -or $x.OuterXml -match 'Xbox Live' -or $_.InstallLocation -match 'XboxGames')
    if ($isGame -and $app) {
      $out += [pscustomobject]@{
        name = $x.Package.Properties.DisplayName
        pfn  = $_.PackageFamilyName
        appid = $app.Id
        path = $_.InstallLocation
      }
    }
  }
}
$out | ConvertTo-Json -Compress
"""


class XboxScanner(Scanner):
    id = "xbox"
    label = "Xbox / Microsoft Store"
    icon = "XBX"
    priority = 55

    def available(self) -> bool:
        if not is_windows():
            return False
        return any(r.is_dir() for r in XBOX_ROOTS) or Path(
            r"C:\Program Files\WindowsApps").exists()

    def scan(self) -> list[Game]:
        games: list[Game] = []
        seen: set[str] = set()

        raw = run_powershell(PS_LIST, timeout=45)
        for entry in self._parse(raw):
            path = Path(entry.get("path") or "")
            title = self._clean_title(entry.get("name") or path.name)
            if not title or str(path).lower() in seen:
                continue
            seen.add(str(path).lower())
            pfn, appid = entry.get("pfn", ""), entry.get("appid", "")
            games.append(self._mk(
                title=title,
                source_id=pfn,
                install_dir=str(path),
                launch_uri=f"shell:appsFolder\\{pfn}!{appid}" if pfn and appid else "",
                size_bytes=0,
                engine=detect_engine(path),
                extra={"pfn": pfn, "app_id": appid},
            ))

        # dossiers XboxGames non couverts (jeux installes hors AppX classique)
        for root in XBOX_ROOTS:
            if not root.is_dir():
                continue
            for d in root.iterdir():
                if not d.is_dir() or d.name.lower() in ("gamesave", "temp"):
                    continue
                if str(d).lower() in seen:
                    continue
                content = d / "Content"
                target = content if content.is_dir() else d
                games.append(self._mk(
                    title=d.name,
                    source_id=d.name,
                    install_dir=str(target),
                    executable=pick_main_exe(target, d.name),
                    size_bytes=dir_size(target, 6000),
                    engine=detect_engine(target),
                ))
        log.info("%d jeux Xbox", len(games))
        return games

    @staticmethod
    def _parse(raw: str) -> list[dict]:
        raw = (raw or "").strip()
        if not raw:
            return []
        try:
            data = json.loads(raw)
        except Exception:
            return []
        return data if isinstance(data, list) else [data]

    @staticmethod
    def _clean_title(name: str) -> str:
        if name.startswith("ms-resource"):
            return ""
        return re.sub(r"\s*\(?(Windows|PC)\s*Edition\)?$", "", name).strip()
