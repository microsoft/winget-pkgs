"""Tout le fonctionnement d'ORION, en un seul endroit.

Ce module ne contient que du texte : la documentation complete de
l'application, decoupee en articles cherchables. L'onglet « Tuto » l'affiche
tel quel, et le site web est engendre a partir des memes articles. Une
seule source, donc : une page d'aide ne peut pas mentir sur ce que fait
l'application sans que l'autre mente aussi.

Ajouter un article se resume a ajouter un `Article` dans la bonne rubrique.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .core.models import normalize_title


def contains_all(texte: str, query: str) -> bool:
    """Vrai si chaque mot de la recherche apparait dans le texte.

    La comparaison passe par `normalize_title`, qui retire accents, casse
    et ponctuation : « cle gemini », « clé Gemini » et « GEMINI cle »
    trouvent donc la meme chose. Chaque mot est cherche separement, sinon
    une recherche de deux mots ne trouverait jamais rien.
    """
    foin = normalize_title(texte)
    mots = [normalize_title(m) for m in (query or "").split()]
    mots = [m for m in mots if m]
    if not mots:
        return True
    return all(m in foin for m in mots)


@dataclass
class Article:
    """Un sujet d'aide : de quoi il s'agit, puis comment faire."""

    id: str
    title: str
    summary: str
    body: list[str] = field(default_factory=list)
    steps: list[tuple[str, str]] = field(default_factory=list)
    links: list[tuple[str, str]] = field(default_factory=list)
    keywords: list[str] = field(default_factory=list)

    @property
    def haystack(self) -> str:
        return " ".join([self.title, self.summary, *self.body,
                         *[t for t, _ in self.steps],
                         *[d for _, d in self.steps],
                         *[t for t, _ in self.links],
                         *self.keywords])

    def matches(self, query: str) -> bool:
        """Recherche tolerante : accents, casse, ponctuation et ordre."""
        return contains_all(self.haystack, query)


@dataclass
class Rubrique:
    id: str
    title: str
    articles: list[Article]


# ==========================================================================
# 1. Premiers pas
# ==========================================================================

DEMARRER = [
    Article(
        id="installation",
        title="Installer ORION",
        summary="Un executable, aucun droit administrateur, tout dans votre "
                "compte utilisateur.",
        steps=[
            ("Lancer l'installeur",
             "Double-cliquez sur Installateur-ORION.exe. Windows peut "
             "afficher un avertissement SmartScreen parce que l'executable "
             "n'est pas signe : « Informations complementaires » puis "
             "« Executer quand meme »."),
            ("Choisir l'emplacement",
             "Le dossier propose est %LOCALAPPDATA%\\Programs\\ORION. Vous "
             "pouvez en choisir un autre ; aucun droit administrateur n'est "
             "demande dans les deux cas."),
            ("Raccourci sur le Bureau",
             "Coche par defaut. Une entree est aussi ajoutee au menu "
             "Demarrer, et ORION apparait dans « Applications installees » "
             "de Windows."),
            ("Premier demarrage",
             "ORION analyse la machine et les plateformes installees. Le "
             "premier scan prend une quinzaine de secondes ; les suivants "
             "sont quasi instantanes."),
        ],
        body=[
            "ORION s'installe entierement dans votre compte utilisateur : "
            "le programme dans %LOCALAPPDATA%\\Programs\\ORION, ses donnees "
            "dans %LOCALAPPDATA%\\ORION. Rien n'est ecrit ailleurs, aucun "
            "service n'est installe. ORION se lance au demarrage de Windows, "
            "reduit dans la barre des taches ; pour l'eviter, decochez « Lancer "
            "ORION au demarrage de Windows », dans l'installateur ou en tete des "
            "Reglages.",
            "Pour desinstaller : « Applications installees » de Windows, ou "
            "le raccourci de desinstallation. ORION propose alors de garder "
            "ou de supprimer votre bibliotheque et vos sauvegardes.",
        ],
        keywords=["installer", "setup", "exe", "desinstaller", "smartscreen"],
    ),
    Article(
        id="premier-scan",
        title="Trouver vos jeux",
        summary="Neuf sources explorees, sans rien configurer.",
        body=[
            "ORION lit les manifestes de Steam (toutes vos bibliotheques, y "
            "compris sur d'autres disques), ceux d'Epic, la base de registre "
            "pour GOG, Ubisoft Connect, l'EA app et Battle.net, les paquets "
            "du Microsoft Store, vos dossiers de jeux personnels, et la "
            "liste des programmes installes en dernier recours.",
            "Les doublons entre plateformes sont fusionnes, les lanceurs "
            "(Epic Games Launcher, SteamVR, Ubisoft Connect...) sont "
            "ecartes, et les jeux declares par une plateforme dont les "
            "fichiers ont disparu sont signales « introuvable » plutot que "
            "supprimes.",
        ],
        steps=[
            ("Ajouter un dossier de jeux",
             "Reglages > Detection > Dossiers supplementaires. Utile pour "
             "les jeux poses a la main, hors de toute plateforme."),
            ("Relancer une analyse",
             "Bouton « Analyser » en haut de la bibliotheque. ORION detecte "
             "aussi les nouvelles installations tout seul, toutes les dix "
             "minutes par defaut."),
            ("Un jeu manque ?",
             "Verifiez qu'il n'est pas masque (Reglages > Interface > "
             "Afficher les jeux masques) et que son dossier est bien dans "
             "une bibliotheque connue. Sinon, ajoutez son dossier parent."),
        ],
        keywords=["scan", "detection", "steam", "epic", "gog", "manquant"],
    ),
    Article(
        id="retrouver",
        title="Retrouver un jeu ou un reglage",
        summary="Ctrl+F, les filtres rapides de la bibliotheque et la recherche des Reglages.",
        body=[
            "Ctrl+F met le curseur dans la recherche de la page affichee : bibliotheque, Boutique, Ma machine, Stockage ou Reglages. Depuis une page sans recherche, c'est celle de la bibliotheque. Dans la bibliotheque, Echap efface la recherche.",
            "Sous le titre de la bibliotheque, quatre filtres rapides : Tous, Favoris, Joues recemment (trente derniers jours) et Jamais lances, chacun avec son nombre de jeux. Quand une recherche ne trouve rien chez vous, un bouton la relance dans la Boutique.",
            "La page Reglages est rangee en six rubriques (Jeux, Boutique et prix, Apparence, Sauvegardes, Avance, ORION) et se cherche par mot : « prix », « manette », « sauvegarde ». Un reglage change s'applique tout de suite, sans redemarrer ORION ; seule la langue demande un redemarrage.",
        ],
        steps=[
            ("Chercher", "Ctrl+F, puis tapez. La recherche tolere les fautes de frappe et les sigles."),
            ("Aller a une rubrique des Reglages", "Les boutons sous le titre de la page y menent d'un clic."),
            ("La molette et les reglages", "La molette fait toujours defiler la page : elle ne change jamais la valeur d'une liste ou d'un champ numerique qui passe sous le pointeur. Une valeur se change au clic ou au clavier."),
        ],
        keywords=["recherche", "chercher", "ctrl+f", "filtre", "favoris", "jamais lance",
                  "rubrique", "reglage", "molette", "trouver"],
    ),
    Article(
        id="jaquettes",
        title="Jaquettes et visuels",
        summary="Recuperes automatiquement, y compris hors Steam.",
        body=[
            "ORION telecharge la jaquette verticale, la banniere large et le "
            "logo de chaque jeu. Pour les jeux hors Steam, l'identifiant est "
            "retrouve a partir du titre, ce qui couvre la grande majorite "
            "des cas.",
            "Une cle SteamGridDB (gratuite) ameliore nettement la couverture "
            "des jeux rares, des mods et des jeux poses a la main.",
        ],
        steps=[
            ("Forcer la recuperation",
             "Reglages > Jaquettes > « Completer les visuels manquants »."),
            ("Choisir une image a la main",
             "Fiche du jeu > bouton du visuel > choisissez un fichier local. "
             "Votre choix n'est jamais ecrase par une mise a jour."),
        ],
        keywords=["image", "cover", "banniere", "logo", "steamgriddb"],
    ),
]


# ==========================================================================
# 2. Regler et lancer
# ==========================================================================

REGLAGES = [
    Article(
        id="profils",
        title="Les graphismes : votre ecran, ou votre choix",
        summary="« Votre ecran » : le plus beau reglage qui tient la frequence de "
                "l'ecran. « Mon choix » : les graphismes et les images par seconde "
                "que vous voulez.",
        body=[
            "« Votre ecran », la carte conseillee. Votre ecran affiche 60, 144, "
            "165 ou 240 images par seconde : ORION lit vos composants et "
            "cherche, du plus beau au plus leger (Ultra, Haute, Moyenne, Basse, "
            "avec DLSS, FSR ou XeSS quand ca aide), le premier reglage qui tient "
            "cet objectif de facon stable. Si meme Basse ne le tient pas, il "
            "descend par paliers (144, 120, 100, 90...) : on vise les images par "
            "seconde stables les plus hautes.",
            "« Mon choix ». Vous choisissez les graphismes (Ultra par defaut) et "
            "les images par seconde. ORION montre ce que ce reglage donne sur "
            "votre PC : les images par seconde attendues, la super-resolution "
            "retenue pour tenir l'objectif, et si l'objectif est tenu (« tient "
            "120 i/s ») ou non (« jusqu'a 70 i/s »). Au clic, il ecrit ce niveau "
            "et bride le jeu sur les images par seconde demandees.",
            "Sur chaque carte, la case « Activer DLSS » (FSR ou XeSS selon votre "
            "carte graphique) ajoute ou retire la super-resolution : la carte se "
            "recalcule des le clic et le gain s'affiche en vert (« +18 i/s »). Si "
            "cette carte est deja en place, le jeu est reecrit avec votre choix.",
            "Pendant une partie, ORION mesure les images par seconde reellement "
            "obtenues. Au prochain calcul, « Votre ecran » repart de cette "
            "mesure, pas de l'estimation : le reglage se corrige tout seul, vers "
            "le plus fluide. « Mon choix » garde votre niveau et montre les "
            "images par seconde mesurees.",
            "Un clic sur une carte ecrit les reglages dans le jeu tout de "
            "suite, apres une sauvegarde, puis les relit pour verifier. Le "
            "choix vaut pour ce jeu : « Jouer » refait le meme calcul.",
        ],
        steps=[
            ("Choisir",
             "Fiche du jeu > Graphismes > cliquez « Votre ecran », ou reglez le "
             "niveau et les images par seconde dans « Mon choix » puis cliquez "
             "la carte. La ligne « Reglages ecrits » confirme."),
            ("Revenir en arriere",
             "« Restaurer » remet la sauvegarde faite avant la derniere "
             "ecriture. « Redefinir les parametres par defaut » remet le jeu "
             "dans l'etat d'avant la toute premiere intervention d'ORION, "
             "apres confirmation."),
            ("Ajuster une valeur precise",
             "Fiche du jeu > Reglages calcules > modifiez la valeur. ORION "
             "retient votre correction et la reapplique ensuite."),
        ],
        keywords=["graphismes", "mon choix", "ecran", "fps", "images par seconde",
                  "ultra", "preset", "dlss", "fsr", "xess", "super-resolution", "gain",
                  "qualite", "60 fps", "par defaut"],
    ),
    Article(
        id="ecriture",
        title="Comment ORION regle un jeu",
        summary="Apercu, sauvegarde, ecriture, puis verification.",
        body=[
            "ORION n'ecrit jamais dans un jeu sans montrer d'abord ce qui va "
            "changer. L'apercu liste chaque cle, sa valeur actuelle et sa "
            "nouvelle valeur, avec le fichier concerne. La confirmation n'est "
            "demandee qu'une fois : tant que les valeurs ne changent pas, une "
            "partie suivante ne la redemande pas.",
            "Les fichiers touches sont sauvegardes avant toute ecriture. Le "
            "bouton « Restaurer » de la fiche du jeu remet l'etat precedent "
            "en un clic, meme apres plusieurs applications.",
            "Juste avant chaque lancement, ORION relit les fichiers : si le jeu "
            "a remis ses propres valeurs entre-temps, elles sont reecrites. "
            "Apres ecriture, chaque reglage est relu pour verifier qu'il est "
            "bien en place.",
            "La fiche dit honnetement ou on en est : « Reglages appliques : 12 "
            "sur 14 », les reglages non pris en compte, ou « Le jeu a modifie "
            "N reglage(s) ». Un fichier en lecture seule n'est jamais force : "
            "ORION le signale et ecrit les autres. Si le jeu remplace ses "
            "reglages a chaque partie (Steam Cloud, par exemple), ORION le dit "
            "et continue de regler l'ecran.",
            "Trois moteurs sont reconnus nativement : Unreal Engine, Unity "
            "et Source. Les autres jeux passent par une recette.",
        ],
        steps=[
            ("Appliquer sans lancer",
             "Fiche du jeu > « Appliquer sans lancer » : utile pour preparer "
             "une session sans demarrer tout de suite."),
            ("Revenir en arriere",
             "Fiche du jeu > « Restaurer ». Les sauvegardes sont dans "
             "%LOCALAPPDATA%\\ORION\\backups."),
            ("Desactiver la confirmation",
             "Reglages > Lancement des jeux. Deconseille : la confirmation est "
             "le seul moment ou vous voyez ce qui va changer."),
        ],
        keywords=["appliquer", "restaurer", "sauvegarde", "ini", "registre",
                  "lecture seule", "verifier", "12 sur 14", "confirmation"],
    ),
    Article(
        id="non-reglable",
        title="Quand un jeu n'est pas reglable",
        summary="ORION conseille un niveau, a choisir dans le jeu.",
        body=[
            "Certains jeux ne stockent rien de lisible sur le disque : "
            "moteur maison, reglages gardes en ligne sur le compte du "
            "joueur, ou fichier de configuration cree seulement apres une "
            "premiere partie.",
            "Dans ce cas la fiche affiche « Ce jeu n'est pas encore pris en "
            "charge » et le niveau conseille pour votre PC, a regler vous-meme "
            "dans les options graphiques du jeu. Le jeu se lance normalement, "
            "sans qu'ORION touche a ses fichiers.",
            "Lancez le jeu une fois, puis revenez sur sa fiche : s'il a ecrit "
            "sa configuration entre-temps, les profils reapparaissent tout "
            "seuls.",
        ],
        steps=[
            ("Tenter la recette automatique",
             "Fiche du jeu > Assistant IA > « Apprendre ce jeu a ORION ». "
             "L'IA lit les fichiers reellement presents sur votre disque et "
             "ecrit la recette. Demande une cle d'IA."),
            ("Ecrire la recette a la main",
             "Un fichier JSON depose dans %LOCALAPPDATA%\\ORION\\recipes "
             "suffit. Le format est decrit dans le depot des recettes."),
        ],
        keywords=["aucun fichier", "pas de reglage", "moteur maison",
                  "aniimo", "impossible", "pas pris en charge"],
    ),
    Article(
        id="apprendre",
        title="Apprendre les niveaux d'un jeu",
        summary="Vous choisissez les niveaux dans le menu du jeu, ORION retient ce qu'il ecrit.",
        body=[
            "Certains jeux recalculent eux-memes leur niveau de graphismes ou "
            "rangent leurs options a leur facon (Baldur's Gate 3, par exemple). "
            "Le bouton « Apprendre les niveaux de ce jeu », sous les cartes de la "
            "fiche, fait apprendre a ORION ce que le menu du jeu ecrit vraiment "
            "pour chaque niveau.",
            "Quatre etapes, dont deux facultatives : le niveau le plus bas, un "
            "niveau moyen, un niveau eleve, le niveau le plus haut. A chaque "
            "etape, vous lancez le jeu, choisissez le niveau general dans son "
            "menu Video, appliquez, puis quittez. ORION relit le fichier de "
            "reglages entre deux etapes ; rien n'est ecrit dans le jeu pendant "
            "l'apprentissage.",
            "Ensuite, Basse, Moyenne, Haute et Ultra ecrivent exactement les "
            "valeurs du jeu, y compris les options qu'un jeu n'ecrit que "
            "lorsqu'elles quittent leur valeur par defaut (l'apercu les montre "
            "« par defaut du jeu »). La definition, le mode fenetre et tout ce "
            "qui ressemble a un identifiant de compte ne sont jamais retenus.",
            "Si vous partagez vos mesures (Reglages > Donnees partagees), les "
            "niveaux appris sont aussi proposes aux autres joueurs d'ORION : des "
            "noms et des valeurs de reglages, rien de personnel.",
        ],
        steps=[
            ("Apprendre",
             "Fiche du jeu > Graphismes > « Apprendre les niveaux de ce jeu », "
             "puis suivez les etapes. A la fin, ORION dit combien de reglages "
             "changent avec le niveau."),
            ("Recommencer",
             "Apres une grosse mise a jour du jeu, refaites l'apprentissage : "
             "les nouveaux niveaux remplacent les anciens."),
        ],
        keywords=["apprendre", "exemple", "niveaux", "baldur", "bg3", "menu video",
                  "deja en place", "preset", "par defaut du jeu"],
    ),
    Article(
        id="ecrans",
        title="Ecran, definition et frequence",
        summary="La fluidite deja payee, et souvent inutilisee.",
        body=[
            "ORION lit tous les modes de chaque ecran, et distingue la "
            "definition native de la dalle des super-resolutions ajoutees "
            "par le pilote (DSR chez NVIDIA, VSR chez AMD) : une image "
            "calculee en 3620x2036 sur une dalle 2560x1440 coute tres cher "
            "pour un gain discutable.",
            "Au lancement, l'ecran choisi passe dans le mode du profil, puis "
            "revient a son etat precedent a la fin de la partie si l'option "
            "est active.",
        ],
        steps=[
            ("Choisir l'ecran d'un jeu",
             "Fiche du jeu > menu « Ecran », en haut a droite des profils."),
            ("Remettre la frequence maximale",
             "Ma machine > votre ecran > « Frequence maximale »."),
            ("Ne pas toucher a l'ecran",
             "Reglages > Lancement > decochez « Regler l'ecran au lancement »."),
        ],
        keywords=["hz", "resolution", "definition", "dsr", "vsr", "180"],
    ),
    Article(
        id="performances",
        title="Mesurer les images par seconde",
        summary="Des chiffres reels, pas une estimation.",
        body=[
            "La mesure s'appuie sur PresentMon, l'outil d'Intel qui compte "
            "les images reellement affichees. ORION le telecharge tout seul "
            "au premier usage.",
            "Apres la partie, ORION affiche la moyenne, le 1 % bas et le "
            "0,1 % bas — les moments de saccade, ceux qu'une moyenne cache. "
            "Il compare ensuite au profil choisi et propose des ajustements "
            "chiffres.",
            "La mesure lit les evenements d'affichage de Windows, que Windows "
            "reserve aux administrateurs et au groupe « Utilisateurs du journal "
            "de performances ». ORION ne demande jamais les droits "
            "d'administrateur : si votre compte n'est pas dans ce groupe, la "
            "mesure est refusee, et Reglages > Mesure des performances le dit.",
        ],
        steps=[
            ("Activer la mesure",
             "Reglages > Mesure des performances > « Installer l'outil de "
             "mesure ». La mesure demarre a votre partie suivante."),
            ("Si Windows refuse la mesure",
             "Ouvrez un terminal en administrateur (clic droit sur Demarrer > "
             "Terminal (administrateur)), tapez cmd /c net localgroup "
             "\"Utilisateurs du journal de performances\" %USERNAME% /add, "
             "validez, puis fermez votre session Windows et rouvrez-la. Sur un "
             "Windows en anglais, le groupe s'appelle \"Performance Log Users\"."),
            ("Lire les resultats",
             "Fiche du jeu > Performances. Chaque profil garde son propre "
             "historique."),
        ],
        keywords=["fps", "presentmon", "1% low", "saccade", "stutter", "acces refuse",
                  "utilisateurs du journal de performances", "performance log users"],
    ),
]


# ==========================================================================
# 3. Les autres pages
# ==========================================================================

PAGES = [
    Article(
        id="banniere",
        title="La banniere d'accueil",
        summary="Le dernier jeu joue, puis l'horizon de votre bibliotheque.",
        body=[
            "La premiere place revient toujours au dernier jeu joue : c'est "
            "la reponse a « qu'est-ce que je relance ? ». La banniere fait "
            "ensuite defiler vos favoris, vos parties recentes et vos "
            "dernieres installations, en fondu.",
            "Le defilement s'arrete des que la souris entre dans la "
            "banniere : un bouton qui bouge sous le curseur est un bouton "
            "rate. Les pastilles en bas a droite permettent d'aller "
            "directement a un jeu.",
        ],
        steps=[
            ("Changer la vitesse de defilement",
             "Reglages > Interface > banniere. Mettre 0 fige la banniere sur "
             "le dernier jeu joue."),
            ("Masquer la banniere",
             "Reglages > Interface > decochez « Mettre en avant la derniere "
             "partie »."),
        ],
        keywords=["banniere", "accueil", "reprendre", "carrousel", "defilement"],
    ),
    Article(
        id="boutique",
        title="Boutique : le prix le plus bas, sur des sites surs",
        summary="Une vitrine qui vous ressemble, toutes les boutiques autorisees, "
                "actualisee toutes les 12 minutes.",
        body=[
            "La Boutique releve les promotions et les meilleures ventes de "
            "Steam, GOG et, grace a IsThereAnyDeal, de plus de "
            "trente boutiques agreees (Fanatical, Humble, Green Man Gaming, "
            "Epic, Gamesplanet...). Elle s'actualise toute seule toutes les 12 "
            "minutes (reglable de 10 a 60 dans Reglages > Prix et evaluations).",
            "La vitrine se lit de haut en bas. « A la une » : les gros jeux du "
            "moment en grand, qui defilent seuls (la souris arrete le "
            "defilement ; fleches, points ou liste a droite pour choisir). "
            "« Pour vous » : des jeux proches de ceux de votre bibliotheque. "
            "Puis « Grosses promos » (-50 % et plus sur des jeux connus), « Au "
            "plus bas historique », « Gratuits en ce moment », une rangee par "
            "type de jeu, les petits prix et les mieux notes.",
            "La barre du haut reste a l'ecran : la recherche, les filtres et le "
            "tri agissent sur la page en cours. Un type de jeu (colonne de "
            "gauche), un filtre ou « Tout voir » ouvre sa page, decoupee en "
            "pages de quarante jeux ; « Accueil de la boutique » ramene a la "
            "vitrine. Sur la page des FPS, par exemple, on trie par prix ou on "
            "cherche un nom sans quitter les FPS. Au bout d'une page, « Plus de "
            "jeux » va chercher la suite du magasin.",
            "« Pour vous » est calcule sur votre PC, sans compte ni envoi : "
            "genres, studios et series de vos jeux, ponderes par votre temps de "
            "jeu, vos favoris et vos parties recentes. Un jeu que vous possedez "
            "deja n'est jamais propose ; ailleurs, il porte la mention « Dans la "
            "bibliotheque », et sa fiche offre « Voir dans ma bibliotheque », qui "
            "ouvre le jeu chez vous.",
            "Le prix affiche est le moins cher parmi les boutiques SURES "
            "uniquement : boutiques officielles et revendeurs agrees, qui "
            "achetent leurs cles aux editeurs. Une enseigne a plusieurs vitrines "
            "(Gamesplanet France, Allemagne, Royaume-Uni, Etats-Unis) n'est "
            "comptee qu'une fois, dans la monnaie de votre pays.",
            "Les revendeurs de cles ne sont jamais retenus comme meilleur prix. "
            "Trois sont proposes a part, apres les boutiques officielles, si "
            "l'option est active (Reglages > Prix et evaluations) : Instant "
            "Gaming, Kinguin et Loaded, pour une cle Steam du jeu lui-meme, "
            "region Global ou celle de votre pays (Europe en France), jamais un cadeau (« Gift ») ni un compte. "
            "G2A, Gamivo, Eneba et les autres places de marche sont ecartees : "
            "cles parfois revoquees, comptes suspendus, argent qui ne va pas aux "
            "createurs.",
            "La page a deux onglets : « Offres » (la vitrine et le comparateur) "
            "et « Gratuits en ce moment » (voir l'article Jeux gratuits). Le "
            "nombre de jeux gratuits a recuperer s'affiche sur l'onglet et a "
            "cote de « Boutique » dans la barre laterale.",
        ],
        steps=[
            ("Trouver n'importe quel jeu",
             "Dans le champ de recherche en haut de la page, tapez son nom : "
             "la recherche dans toutes les boutiques part d'elle-meme (Entree "
             "ou « Chercher partout » la lance tout de suite). Meme hors "
             "promotion, les resultats s'affichent avec leur image. Les fautes "
             "et les sigles passent : « cyberpounk », « bg3 », « gta », « bo3 »."),
            ("Voir toute une rangee",
             "« Tout voir » a droite d'une rangee affiche toutes ses offres "
             "dans la grille de recherche, deja filtrees et triees."),
            ("Comparer",
             "Cliquez un jeu : sa fiche montre toutes les boutiques, avec leur "
             "niveau de confiance, la remise et le prix. Clic droit : menu "
             "rapide (offre, comparer, suivre)."),
            ("Filtrer",
             "Meilleures affaires (20 % et plus), Au plus bas historique, "
             "Moins de 5 € ou 15 €, et le tri de votre choix."),
            ("Les logiciels sont ecartes",
             "Les applications (logiciels, formations, livres numeriques, "
             "bandes originales, contenus additionnels) ne sont jamais "
             "montrees : la Boutique ne vend que des jeux. Le resume en bas "
             "de la barre dit combien sont masquees."),
            ("Suivre un jeu",
             "« Suivre » l'ajoute a vos Envies : ORION vous previent quand il "
             "passe sous le seuil que vous fixez. Un second clic sur le bouton "
             "annule."),
        ],
        keywords=["boutique", "magasin", "prix", "moins cher", "promo",
                  "comparateur", "revendeur", "g2a", "instant gaming",
                  "kinguin", "cle", "sur", "arnaque", "application",
                  "logiciel", "formation", "a la une", "pour vous",
                  "suggestion", "recommandation"],
    ),
    Article(
        id="fiche-jeu",
        title="La fiche d'un jeu",
        summary="Tout sur un jeu de votre bibliotheque, au meme endroit.",
        body=[
            "En haut : le visuel, le titre, Jouer, et le bouton « Boutique » qui "
            "ouvre la page du jeu sur sa plateforme. Pour un jeu en ligne vendu "
            "sur Steam, une ligne verte donne le nombre de joueurs connectes.",
            "Le panneau Infos rassemble le studio, l'editeur, la date de sortie, "
            "les genres, les avis Steam, la note Metacritic et vos succes "
            "(obtenus, pourcentage, succes rares). Le panneau Succes, compact, "
            "montre les prochains a viser ; « Voir tout » deplie la liste.",
            "Viennent ensuite les captures d'ecran (cliquez pour agrandir, "
            "fleches pour defiler), les videos, les actualites traduites, les "
            "sauvegardes de parties, les performances mesurees et les "
            "graphismes. Un jeu sans captures le dit au lieu de laisser un vide.",
            "Le jeu est a vous : la fiche ne montre plus de prix ni de revendeurs "
            "du marche gris.",
        ],
        steps=[
            ("Mettre a jour les infos",
             "Panneau Infos > « Actualiser » relit les informations du jeu."),
            ("Ouvrir la page boutique",
             "Bouton « Boutique » en haut de la fiche."),
        ],
        keywords=["fiche", "infos", "studio", "editeur", "sortie", "genres",
                  "avis", "metacritic", "succes", "captures", "details"],
    ),
    Article(
        id="videos",
        title="Videos : gameplay, lives et bande-annonce",
        summary="Un lecteur integre a la fiche, rien ne se charge sans vous.",
        body=[
            "La section Videos de la fiche propose trois onglets. « Gameplay "
            "(FR) » : des resultats YouTube en francais s'affichent dans le "
            "lecteur ; la video que vous choisissez est lue sur place et "
            "proposee directement la prochaine fois. « En direct » : les lives "
            "YouTube se regardent ici, Twitch s'ouvre dans votre navigateur (son "
            "lecteur utilise un format que le lecteur integre ne sait pas lire). "
            "« Bande-annonce » : les videos officielles de la fiche Steam.",
            "Rien n'est charge tant que vous n'avez pas clique, et la lecture "
            "s'arrete des que vous quittez la fiche. Le son des bandes-annonces "
            "Steam n'est pas pris en charge par le lecteur integre (image seule) : "
            "« Ouvrir sur Steam (avec le son) » les ouvre dans le navigateur. Sans "
            "video officielle sur Steam, ORION propose de chercher la "
            "bande-annonce sur YouTube.",
            "ORION ne lit jamais les pages de resultats YouTube tout seul : "
            "c'est vous qui choisissez la video, lue ensuite avec le lecteur "
            "officiel de YouTube. Aucune cle ni aucun compte n'est necessaire.",
        ],
        steps=[
            ("Changer de video",
             "« Choisir une autre video » sous le lecteur."),
            ("Regarder dans le navigateur",
             "« Ouvrir sur YouTube », « Voir sur Twitch » ou « Ouvrir sur Steam "
             "(avec le son) » sous le lecteur."),
        ],
        keywords=["video", "videos", "gameplay", "youtube", "twitch", "live",
                  "direct", "bande-annonce", "trailer", "stream"],
    ),
    Article(
        id="en-ligne",
        title="Joueurs en ligne en ce moment",
        summary="Combien de joueurs sont connectes a un jeu en ligne.",
        body=[
            "Dans la fiche d'un jeu en ligne vendu sur Steam, une ligne verte indique "
            "combien de joueurs y sont connectes a l'instant. Le chiffre est publie par "
            "Steam et actualise toutes les 5 minutes tant que la fiche est ouverte.",
            "Seuls les joueurs connectes via Steam sont comptes : ceux d'Epic, du Xbox "
            "ou des consoles ne le sont pas. Les autres editeurs ne publient pas ce "
            "chiffre, ORION ne l'invente donc pas : la ligne n'apparait pas.",
        ],
        keywords=["joueurs", "en ligne", "connectes", "multijoueur", "population",
                  "serveurs", "steam charts"],
    ),
    Article(
        id="envies",
        title="Envies et veille de prix",
        summary="Un seuil par jeu, une alerte quand il est atteint.",
        body=[
            "La page Envies suit les jeux que vous n'avez pas encore. Pour "
            "chacun : le prix actuel, la meilleure offre du moment sur des "
            "dizaines de boutiques, et le plus bas prix jamais releve.",
            "Fixez un seuil et ORION vous previent — notification Windows "
            "comprise — des que le prix passe en dessous.",
        ],
        steps=[
            ("Importer votre liste Steam",
             "Envies > « Importer depuis Steam ». Votre liste de souhaits "
             "doit etre publique dans la confidentialite de votre profil."),
            ("Ajouter un jeu a la main",
             "Tapez son nom dans le champ de recherche de la page, puis "
             "choisissez-le dans la liste proposee."),
            ("Fixer un seuil",
             "Colonne « Alerte sous » : entrez le prix qui declenche "
             "l'alerte. Laisser a zero suit le jeu sans alerter."),
        ],
        keywords=["prix", "promo", "soldes", "wishlist", "alerte", "seuil"],
    ),
    Article(
        id="valeur",
        title="Valeur de la bibliotheque",
        summary="Ce que couterait votre catalogue aujourd'hui, a titre "
                "d'information.",
        body=[
            "Au-dessus de la bibliotheque, un bouton additionne le prix actuel "
            "hors promotion de chaque jeu possede, installe ou non, tel que les "
            "boutiques l'affichent aujourd'hui. Ce n'est ni ce que vous avez "
            "paye, ni une valeur de revente. Les jeux gratuits comptent pour 0.",
            "Les prix viennent des fiches deja relevees, du magasin Steam et de "
            "la Boutique, sans cle ni compte. Un jeu sans prix connu n'est pas "
            "compte : le bouton dit combien de jeux ont ete estimes sur combien.",
            "Cliquez dessus : la fenetre « Valeur estimee de ma bibliotheque » "
            "liste les jeux comptes, du plus cher au moins cher, avec la boutique "
            "d'ou vient chaque prix. A droite, votre carte de joueur : un pseudo "
            "et une photo de profil si vous le voulez (ils restent sur ce PC), le "
            "total et vos trois jeux les plus chers. « Enregistrer l'image » la "
            "range ou vous voulez, en PNG, prete a poster.",
        ],
        keywords=["valeur", "bibliotheque", "collection", "prix", "total",
                  "combien"],
    ),
    Article(
        id="gratuits",
        title="Jeux gratuits",
        summary="Ce qui est offert maintenant, et ce que ca engage vraiment.",
        body=[
            "Les jeux gratuits sont dans la Boutique, onglet « Gratuits en ce "
            "moment ». La pastille a cote de « Boutique », dans la barre "
            "laterale, compte les offres a recuperer ; elle passe en orange "
            "quand l'une d'elles se termine bientot.",
            "Quatre sources publiques sont interrogees en direct : l'API des "
            "jeux offerts d'Epic, l'agregateur GamerPower (Prime Gaming, "
            "GOG, Ubisoft, itch.io, cles d'editeurs), les mises en avant de "
            "Steam et le catalogue gratuit de GOG.",
            "La distinction decisive est la nature de la gratuite. "
            "« Gratuit pour toujours » ne expire jamais. « A recuperer, "
            "garde a vie » : l'offre expire, mais le jeu reste acquis une "
            "fois reclame. « Gratuit temporairement » : le jeu n'est jouable "
            "que pendant la periode annoncee.",
            "Chaque offre affiche ses conditions d'obtention : compte a "
            "creer, points a echanger, abonnement necessaire. Les demos, "
            "playtests, bandes-son et artbooks sont ecartes : ce ne sont pas "
            "des jeux.",
        ],
        steps=[
            ("Voir ce qui presse",
             "Les offres sont triees par echeance. Le compte a rebours "
             "passe en orange dans les 36 dernieres heures."),
            ("A la fin d'une gratuite temporaire",
             "ORION previent, propose de desinstaller le jeu devenu "
             "injouable, et ouvre la page d'achat pour ceux qui veulent "
             "continuer."),
            ("Changer la frequence de recherche",
             "Reglages > Jeux gratuits > « Chercher toutes les »."),
        ],
        keywords=["gratuit", "offert", "epic", "giveaway", "free weekend",
                  "alienware", "conditions"],
    ),
    Article(
        id="sorties",
        title="Les grosses sorties a venir",
        summary="Toutes plateformes, avec un compte a rebours.",
        body=[
            "Page Sorties : les plus grosses sorties annoncees sur PC, PlayStation, "
            "Xbox et Switch. La plus attendue est mise en avant avec un grand compte a "
            "rebours ; les autres suivent, de la plus proche a la plus lointaine.",
            "Seules les dates officielles des editeurs donnent un compte a rebours, "
            "jusqu'a minuit (heure de votre PC) le jour de la sortie. Un jeu annonce "
            "sans date affiche sa periode (« Fin 2027 ») ou « Date non annoncee ».",
            "La page se tient a jour toute seule : un jeu sorti reste visible 3 jours "
            "avec la mention Disponible, puis laisse sa place au suivant parmi les jeux "
            "a venir les plus suivis sur Steam (classement par listes de souhaits, date "
            "donnee par l'editeur). La grande affiche passe elle aussi au jeu le plus "
            "attendu des mois suivants.",
            "La liste des sorties consoles (GTA VI, Zelda...) est mise a jour en ligne "
            "par ORION quand une date change, sans nouvelle version a installer. Hors "
            "ligne, la derniere liste connue reste affichee.",
            "Une grosse sortie PC peut aussi passer « A la une » sur la grande "
            "affiche. Quand elle se precommande, l'affiche montre le prix de la "
            "boutique officielle, releve toutes les 10 minutes, et, si les "
            "revendeurs sont actives (Reglages > Prix et evaluations), le meilleur "
            "prix d'une cle verifiee, toujours apres la boutique officielle.",
        ],
        steps=[
            ("Filtrer", "PC, PS5, Xbox Series ou Switch 2 : les puces au-dessus des cartes."),
            ("Ouvrir la fiche", "Cliquez sur une carte : fiche Steam pour un jeu PC, "
             "page officielle sinon."),
            ("Suivre le prix", "« Suivre dans mes Envies » sur la grande affiche : ORION "
             "vous previent des baisses de prix."),
            ("Precommander", "« Precommander » ouvre la boutique officielle ; le bouton "
             "de la cle verifiee ouvre la fiche du revendeur. Un lien partenaire est "
             "signale comme tel, et le prix ne change pas pour vous."),
        ],
        keywords=["sorties", "sortie", "a venir", "compte a rebours", "date", "gta",
                  "zelda", "calendrier", "prochainement", "precommande", "a la une",
                  "call of duty"],
    ),
    Article(
        id="sauvegardes",
        title="Sauvegardes de parties",
        summary="Archivees en zip lisible, restaurees sans ecraser.",
        body=[
            "ORION cherche les dossiers de sauvegarde aux emplacements "
            "habituels : Documents, %LOCALAPPDATA%, %APPDATA%, Saved Games, "
            "le dossier du jeu, et le cloud local de Steam.",
            "Les archives sont des fichiers zip horodates, relisibles sans "
            "ORION. La restauration met l'existant de cote au lieu de "
            "l'ecraser : une mauvaise manipulation reste reversible.",
        ],
        steps=[
            ("Archiver maintenant",
             "Fiche du jeu > Sauvegardes > « Archiver »."),
            ("Automatiser",
             "Reglages > Sauvegardes de parties > « Archiver "
             "automatiquement a la fin d'une partie »."),
            ("Restaurer",
             "Fiche du jeu > Sauvegardes > choisissez une archive > "
             "« Restaurer »."),
            ("Copier dans le cloud",
             "Reglages > Sauvegardes de parties > « Copie dans le cloud » : "
             "choisissez votre dossier OneDrive, Google Drive ou Dropbox. Sur "
             "un autre PC, choisissez le meme dossier : les archives "
             "apparaissent dans la fiche du jeu."),
        ],
        keywords=["save", "sauvegarde", "zip", "restaurer", "perdu", "cloud",
                  "onedrive", "google drive", "dropbox"],
    ),
    Article(
        id="stockage",
        title="Stockage",
        summary="Quel jeu sur quel disque, ce qui dort, et vos sauvegardes.",
        body=[
            "La page montre tous les jeux installes, un disque a la fois. "
            "Cliquez une carte de disque pour ne voir que ses jeux, ou "
            "« Tous les disques » pour la vue complete. Chaque carte indique "
            "aussi le nombre de sauvegardes de jeux qu'elle contient.",
            "Au premier affichage, les tailles sont celles annoncees par les "
            "launchers. « Recalculer » remesure la taille reelle de chaque jeu "
            "installe et la place libre de chaque disque, avec l'avancement en "
            "pourcentage.",
            "Un jeu est signale « dormant » quand il n'a jamais vraiment ete "
            "joue, ou qu'aucune partie n'a eu lieu depuis plus de trois "
            "mois. C'est une indication, pas un ordre.",
            "ORION ne supprime jamais un jeu lui-meme : il archive la "
            "sauvegarde, puis ouvre le desinstalleur de la plateforme "
            "concernee (l'Ankama Launcher pour Dofus ou Wakfu, par exemple). "
            "Pour un jeu sans desinstalleur declare, il ouvre simplement son "
            "dossier.",
        ],
        steps=[
            ("Remesurer", "Bouton « Recalculer » en haut de la page."),
            ("Trier, filtrer, chercher", "Un clic sur un en-tete trie la liste (un second clic inverse l'ordre) ; les boutons Tout, Ce qui dort et Sauvegardes la filtrent ; le champ de recherche trouve un jeu. Un double-clic ouvre la fiche du jeu."),
            ("Sauvegarder un jeu", "Selectionnez-le puis « Sauvegarder sur un "
             "autre disque » (voir l'article dedie)."),
        ],
        keywords=["disque", "place", "go", "desinstaller", "menage", "plein",
                  "recalculer", "taille"],
    ),
    Article(
        id="sauvegarde-disque",
        title="Sauvegarder un jeu sur un autre disque",
        summary="Une copie complete et verifiee, sans toucher au jeu installe.",
        body=[
            "Page Stockage : selectionnez un jeu puis « Sauvegarder sur un autre "
            "disque » et choisissez le disque. ORION copie le jeu dans "
            "« Sauvegardes ORION » sur ce disque, fichier par fichier, avec la "
            "progression en pourcentage, puis verifie la copie (memes fichiers, "
            "memes tailles, memes dates).",
            "Le jeu installe n'est jamais modifie : il reste a sa place et "
            "Steam, Epic, GOG et les autres launchers continuent de l'utiliser. "
            "Une sauvegarde precedente n'est remplacee qu'une fois la nouvelle "
            "complete et verifiee. « Annuler » arrete la copie et supprime ce "
            "qui avait deja ete copie.",
            "Sous la liste, l'encart « Sauvegardes de... » montre les "
            "sauvegardes du jeu choisi, avec leur date, leur taille et leur "
            "disque (« introuvable » si le disque est debranche).",
            "Quittez le jeu avant de le sauvegarder ou de le restaurer : ses "
            "fichiers ne doivent pas changer pendant la copie.",
        ],
        steps=[
            ("Restaurer", "Encart des sauvegardes > « Restaurer la sauvegarde » : "
             "la copie revient a l'emplacement du jeu, verifiee fichier par "
             "fichier. Si des fichiers du jeu sont presents, ORION demande avant "
             "de les remplacer. Si le launcher croit le jeu desinstalle, lancez "
             "son installation vers le meme dossier : il retrouve les fichiers."),
            ("Supprimer", "« Supprimer la sauvegarde » : le jeu installe n'est "
             "pas touche."),
            ("Un disque externe", "Branchez-le puis cliquez « Recalculer » : il "
             "apparait dans la liste des disques."),
            ("Jeu deplace par une version precedente", "Les jeux deplaces avec "
             "l'ancien « Deplacer vers un autre disque » (1.8) affichent "
             "« Ramener sur le disque d'origine » : un clic les remet a leur "
             "emplacement d'origine. Fermez le launcher du jeu pendant "
             "l'operation."),
        ],
        keywords=["sauvegarder", "sauvegarde", "copie", "disque", "externe",
                  "restaurer", "ramener", "deplacer", "stockage", "ssd", "backup"],
    ),
    Article(
        id="machine",
        title="Ma machine",
        summary="Le bilan de configuration, et ou ca coince.",
        body=[
            "ORION croise le processeur, la carte graphique, la memoire, les "
            "disques et les ecrans pour reperer les desequilibres connus : "
            "processeur plus ancien que la carte graphique (un frein surtout en "
            "1080p : en 1440p et au-dela, c'est la carte qui travaille le plus), "
            "memoire video juste "
            "pour la definition de l'ecran, disque presque plein, ecran qui "
            "ne tourne pas a sa frequence maximale.",
            "Ce bilan est calcule localement, sans reseau ni cle. "
            "L'assistant IA, s'il est configure, part de ce bilan pour aller "
            "plus loin — il ne le remplace pas.",
            "La page montre aussi chaque ecran et ses modes, et le panneau « Ce "
            "que votre PC peut faire ». Les pilotes et les reglages de Windows "
            "sont analyses dans la page Conseils.",
        ],
        steps=[
            ("Copier la configuration", "Bouton « Copier ma configuration » : processeur, carte graphique, memoire, ecran et disques en texte, a coller dans un message ou un forum d'entraide. Rien de personnel n'y figure."),
        ],
        keywords=["bottleneck", "goulot", "bilan", "materiel", "carte "
                  "graphique", "processeur", "copier", "configuration"],
    ),
    Article(
        id="puissance",
        title="Ce que votre PC peut faire",
        summary="Une seule liste : le niveau fluide de chaque jeu, sans fausse "
                "promesse.",
        body=[
            "Page Ma machine, panneau « Ce que votre PC peut faire » : la note de "
            "la machine, le nombre de jeux par niveau, puis une seule liste : vos "
            "jeux et des jeux a acheter. Pour chacun : le niveau fluide (le plus beau reglage qui "
            "tient environ 60 images par seconde a la definition de votre "
            "ecran : Ultra, Haute, Moyenne, Basse ou Trop juste), les images par "
            "seconde attendues, la source du resultat et ou l'avoir (« Dans votre "
            "bibliotheque » ou la meilleure offre).",
            "Chaque resultat dit sa source. Mesure : releve sur votre PC en jouant "
            "avec la mesure des performances d'ORION ; c'est la seule source qui "
            "peut classer un jeu en Ultra. Communaute : au moins 3 joueurs ORION "
            "avec une carte proche. Estimation : deduite de la configuration "
            "recommandee du jeu, fourchette prudente, valeur basse d'abord, "
            "jamais en Ultra.",
            "Un processeur trop juste (« processeur ») ou une memoire video "
            "insuffisante (« mem. video ») sont signales a cote du niveau. Vos "
            "mesures corrigent automatiquement les estimations suivantes pour "
            "votre PC. Le profil « Recommande » de la fiche d'un jeu utilise le "
            "meme calcul : les deux disent la meme chose.",
        ],
        steps=[
            ("Lire son PC", "En tete du panneau, pour la carte graphique, le processeur, la memoire video et la memoire vive : le nombre de jeux evalues que chacun retient sous le niveau Haute, les composants de puissance voisine, et le premier frein de la machine en une phrase."),
            ("Comprendre un niveau", "Un clic sur un jeu : sa configuration demandee face a la votre, composant par composant ; ce qui le rend jouable sans rien acheter (DLSS, FSR ou XeSS en mode Qualite, definition d'affichage inferieure) ; et ce qu'il manquerait pour le niveau au-dessus. Les composants cites sont des reperes de puissance ; en dessous, quand ORION a pu verifier la compatibilite, des pieces neuves qui vont dans votre PC (carte graphique sur un PC de bureau, processeur du meme support, memoire du meme type), avec une recherche chez un revendeur de materiel neuf. Sans compatibilite verifiee, pas de lien ; un lien partenaire serait marque comme tel."),
            ("Jeux rattrapables, filtre par niveau", "La puce « Rattrapables » liste les jeux qu'un reglage ferait monter d'un niveau (la piste est ecrite a cote du niveau). Un clic sur une pastille Ultra, Haute, Moyenne, Basse ou Trop juste ne garde que ce niveau ; un second clic montre tout."),
            ("Filtrer et trier", "Puces Tous / Mes jeux / A acheter, champ de "
             "recherche, et « Trier par » Niveau, Nom, Images/s ou Prix (ou un "
             "clic sur l'en-tete d'une colonne)."),
            ("Ouvrir un jeu", "Double-clic : la fiche d'un de vos jeux, ou "
             "l'offre pour un jeu a acheter."),
            ("Analyser plus de jeux", "Le bouton lit les configurations de 45 "
             "jeux supplementaires ; ORION continue tout seul en arriere-plan."),
            ("Obtenir une mesure", "Lancez le jeu depuis ORION avec la mesure des "
             "performances activee (Reglages > Mesure des performances)."),
        ],
        keywords=["puissance", "fps", "ultra", "config", "calculateur", "jouable",
                  "performances", "images par seconde", "niveau fluide", "a acheter"],
    ),
    Article(
        id="conseils",
        title="Conseils : pilotes et reglages de Windows",
        summary="Ce qui freine vos jeux, rubrique par rubrique, avec la marche a "
                "suivre.",
        body=[
            "La page Conseils relit la machine en quelques secondes et range ses "
            "constats en quatre rubriques, resumees par des tuiles en haut de la "
            "page (un clic y mene) : Pilotes, Windows, Materiel et Jeux.",
            "Pilotes : l'inventaire complet (carte graphique, chipset, reseau, "
            "audio, stockage, USB, Bluetooth). ORION signale les peripheriques "
            "sans pilote ou en erreur, les pilotes generiques de Microsoft la ou "
            "le fabricant en propose un meilleur, les pilotes du chipset absents "
            "et les pilotes anciens, avec le lien vers la bonne page de "
            "telechargement.",
            "Windows : mode Jeu, planification GPU acceleree, enregistrement en "
            "arriere-plan de la Game Bar, plan et mode d'alimentation (y compris "
            "le cas des Ryzen X3D), redemarrage en attente et fichier d'echange.",
            "Materiel : frequence et definition des ecrans, memoire qui ne tourne "
            "pas a sa vitesse prevue (profil XMP/EXPO non active, ou kit optimise "
            "AMD sur processeur Intel, dont le profil n'est pas toujours lu), memoire en "
            "simple canal ou barrettes sur le meme canal, memoire vive ou video "
            "juste, disque presque plein, Windows sur un disque dur. Jeux : jeux "
            "installes sur un disque dur et mises a jour en attente.",
            "Chaque conseil indique sa gravite (A corriger, Conseil, Info, "
            "Verifie), le constat, les valeurs lues sur votre PC (« Afficher les "
            "lignes ») et, quand c'est utile, un bouton qui ouvre la bonne page "
            "(site du fabricant, parametre de Windows). ORION ne modifie rien "
            "lui-meme dans Windows.",
        ],
        steps=[("Relancer l'analyse", "Bouton « Actualiser » en haut de la page."),
               ("Masquer un conseil", "« Masquer » sur sa carte : il ne revient plus aux analyses suivantes et ne compte plus dans le menu. « Reafficher », en bas de la page, les ramene tous."),
               ("Ne voir que ce qui reste a faire", "Bouton « A traiter seulement » : les verifications deja bonnes sont repliees."),
               ("Partager le bilan", "« Copier le rapport » met tous les conseils en texte dans le presse-papiers, valeurs lues comprises.")],
        keywords=["conseils", "pilote", "driver", "chipset", "reseau", "audio",
                  "bluetooth", "usb", "mode jeu", "hags", "planification gpu",
                  "alimentation", "xmp", "expo", "simple canal", "dual channel",
                  "fichier d'echange", "redemarrage"],
    ),
    Article(
        id="manette",
        title="Manette et affichage salon",
        summary="ORION se pilote entierement au pad.",
        body=[
            "Les manettes sont lues par XInput, la meme interface que les "
            "jeux. La croix directionnelle et les joysticks naviguent, A "
            "valide, B revient en arriere, Start bascule en affichage salon.",
            "L'affichage salon agrandit les tuiles et retire les elements "
            "secondaires, pour une lecture a trois metres.",
        ],
        keywords=["manette", "pad", "xbox", "salon", "big picture", "canape"],
    ),
]


# ==========================================================================
# 4. Recettes et communaute
# ==========================================================================

RECETTES = [
    Article(
        id="recette-principe",
        title="Ce qu'est une recette",
        summary="Un petit fichier JSON qui apprend un jeu a ORION.",
        body=[
            "Une recette dit ou se trouvent les options d'un jeu et comment "
            "les ecrire. Unreal Engine, Unity et Source sont couverts "
            "nativement ; pour les autres, une recette est necessaire.",
            "Une recette ecrite par une personne sert a tout le monde : le "
            "depot communautaire est lu une fois par jour, et les recettes "
            "nouvelles ou mises a jour sont telechargees automatiquement. "
            "Rien n'est envoye depuis votre poste : la synchronisation est "
            "en lecture seule.",
        ],
        steps=[
            ("Recuperer les recettes partagees",
             "Reglages > Recettes partagees > « Synchroniser »."),
            ("Partager la votre",
             "Fiche du jeu > « Partager cette recette ». Deux fichiers sont "
             "prepares dans votre dossier ORION, prets a etre deposes sur le "
             "depot."),
        ],
        links=[("Depot des recettes",
                "https://github.com/Sikher-kisa/orion-recettes")],
        keywords=["recette", "json", "partage", "communaute", "depot"],
    ),
    Article(
        id="extensions",
        title="Ajouter une source ou un fournisseur",
        summary="Un fichier Python depose dans un dossier suffit.",
        body=[
            "ORION decouvre ses extensions toutes seules : sources de jeux, "
            "fournisseurs de jaquettes, comparateurs de prix, formats de "
            "reglages et sources de jeux gratuits. Aucun import a ajouter "
            "nulle part.",
            "Deposez votre fichier dans le sous-dossier correspondant de "
            "%LOCALAPPDATA%\\ORION\\plugins, puis Reglages > Extensions > "
            "« Recharger les extensions et recettes ».",
        ],
        keywords=["plugin", "extension", "python", "developpeur", "module"],
    ),
]


# ==========================================================================
# 5. Cles d'API, pas a pas
# ==========================================================================

CLES = [
    Article(
        id="cles-principe",
        title="Faut-il une cle ?",
        summary="Non. Tout ce qui compte fonctionne sans.",
        body=[
            "La detection des jeux, les jaquettes Steam, les prix Steam, les "
            "jeux gratuits, la mesure des performances, les reglages et les "
            "sauvegardes fonctionnent sans aucune cle ni aucun compte.",
            "Les cles ci-dessous sont facultatives. Elles sont stockees en "
            "clair dans votre fichier de configuration local et ne sont "
            "jamais transmises a ORION : l'application appelle directement "
            "le service concerne depuis votre machine.",
        ],
        keywords=["api", "cle", "gratuit", "obligatoire", "compte"],
    ),
    Article(
        id="cle-steamgriddb",
        title="SteamGridDB (jaquettes) — gratuit",
        summary="Ameliore les visuels des jeux hors Steam, des mods et des "
                "jeux poses a la main.",
        steps=[
            ("Creer un compte",
             "Rendez-vous sur steamgriddb.com et connectez-vous avec votre "
             "compte Steam : aucun mot de passe supplementaire a retenir."),
            ("Ouvrir les preferences",
             "Cliquez votre avatar en haut a droite > « Preferences », puis "
             "l'onglet « API »."),
            ("Generer la cle",
             "Bouton « Generate API Key ». Copiez la suite de caracteres "
             "affichee."),
            ("La coller dans ORION",
             "Reglages > Jaquettes > champ « Cle SteamGridDB ». Elle prend "
             "effet immediatement ; relancez « Completer les visuels "
             "manquants » pour en profiter tout de suite."),
        ],
        links=[("SteamGridDB", "https://www.steamgriddb.com"),
               ("Preferences / API",
                "https://www.steamgriddb.com/profile/preferences/api")],
        keywords=["steamgriddb", "jaquette", "grid", "cle", "api"],
    ),
    Article(
        id="cle-itad",
        title="IsThereAnyDeal (prix) — facultatif",
        summary="ORION compare deja plus de trente boutiques sans cle. Votre "
                "propre cle fait interroger IsThereAnyDeal directement.",
        steps=[
            ("Creer un compte",
             "isthereanydeal.com, bouton « Sign up ». Une adresse e-mail "
             "suffit."),
            ("Declarer une application",
             "Allez sur isthereanydeal.com/apps/my/ puis « New application ». "
             "Nom : ORION. Type : « Desktop application ». L'adresse de "
             "redirection peut rester vide."),
            ("Copier la cle",
             "La page affiche une « API key » : copiez-la."),
            ("La coller dans ORION",
             "Reglages > Prix et evaluations > champ « Cle IsThereAnyDeal ». "
             "Les prix des autres boutiques apparaissent au rafraichissement "
             "suivant."),
        ],
        links=[("IsThereAnyDeal", "https://isthereanydeal.com"),
               ("Vos applications", "https://isthereanydeal.com/apps/my/")],
        keywords=["itad", "prix", "deal", "comparateur", "cle", "api"],
    ),
    Article(
        id="cle-claude",
        title="Claude (Anthropic) — payant a l'usage",
        summary="L'assistant qui ecrit les recettes et analyse votre "
                "configuration.",
        steps=[
            ("Creer un compte developpeur",
             "console.anthropic.com, puis creez un compte ou connectez-vous."),
            ("Ajouter du credit",
             "Menu « Billing » : l'API est facturee a l'usage, independamment "
             "d'un eventuel abonnement Claude. Quelques euros couvrent des "
             "centaines de recettes."),
            ("Generer la cle",
             "Menu « API keys » > « Create Key ». Copiez-la tout de suite : "
             "elle ne sera plus affichee ensuite. Elle commence par sk-ant-."),
            ("La coller dans ORION",
             "Reglages > Assistant IA > fournisseur « Claude (Anthropic) », "
             "puis collez la cle. Le champ « Modele » peut rester vide."),
        ],
        links=[("Console Anthropic", "https://console.anthropic.com"),
               ("Cles d'API",
                "https://console.anthropic.com/settings/keys")],
        keywords=["claude", "anthropic", "ia", "cle", "api", "sk-ant"],
    ),
    Article(
        id="cle-openai",
        title="ChatGPT (OpenAI) — payant a l'usage",
        summary="Autre fournisseur pour l'assistant IA.",
        steps=[
            ("Creer un compte developpeur",
             "platform.openai.com. Attention : c'est un espace different de "
             "chatgpt.com, et un abonnement ChatGPT Plus n'y donne pas "
             "acces."),
            ("Ajouter du credit",
             "« Billing » > « Add payment method », puis un premier credit."),
            ("Generer la cle",
             "« API keys » > « Create new secret key ». Copiez-la "
             "immediatement ; elle commence par sk-."),
            ("La coller dans ORION",
             "Reglages > Assistant IA > fournisseur « ChatGPT (OpenAI) »."),
        ],
        links=[("Plateforme OpenAI", "https://platform.openai.com"),
               ("Cles d'API", "https://platform.openai.com/api-keys")],
        keywords=["openai", "chatgpt", "gpt", "cle", "api"],
    ),
    Article(
        id="cle-gemini",
        title="Gemini (Google) — palier gratuit",
        summary="Le plus simple pour essayer l'IA sans payer.",
        steps=[
            ("Ouvrir Google AI Studio",
             "aistudio.google.com, connectez-vous avec un compte Google."),
            ("Generer la cle",
             "« Get API key » > « Create API key ». Choisissez un projet ou "
             "laissez Google en creer un."),
            ("La coller dans ORION",
             "Reglages > Assistant IA > fournisseur « Gemini (Google) ». Le "
             "palier gratuit limite le nombre de requetes par minute, ce qui "
             "suffit largement a l'usage qu'en fait ORION."),
        ],
        links=[("Google AI Studio", "https://aistudio.google.com/app/apikey")],
        keywords=["gemini", "google", "ai studio", "gratuit", "cle"],
    ),
    Article(
        id="cle-mistral",
        title="Mistral — palier gratuit",
        summary="Fournisseur europeen, offre d'essai disponible.",
        steps=[
            ("Creer un compte",
             "console.mistral.ai, inscription par e-mail ou compte Google."),
            ("Activer une offre",
             "L'offre « Experiment » est gratuite et suffit pour ORION ; une "
             "verification par numero de telephone est demandee."),
            ("Generer la cle",
             "« API Keys » > « Create new key »."),
            ("La coller dans ORION",
             "Reglages > Assistant IA > fournisseur « Mistral »."),
        ],
        links=[("Console Mistral", "https://console.mistral.ai")],
        keywords=["mistral", "europe", "cle", "api", "gratuit"],
    ),
    Article(
        id="cle-ollama",
        title="Ollama — local, sans cle ni connexion",
        summary="L'IA tourne sur votre machine : rien ne sort de chez vous.",
        body=[
            "Ollama fait tourner un modele de langage en local. Aucune cle, "
            "aucun compte, aucun envoi sur Internet. En contrepartie, la "
            "qualite depend du modele choisi et de votre carte graphique.",
            "Comptez au moins 8 Go de memoire video pour un modele "
            "confortable ; ORION reste utilisable avec un modele plus "
            "leger.",
        ],
        steps=[
            ("Installer Ollama",
             "Telechargez l'installeur Windows sur ollama.com et lancez-le."),
            ("Telecharger un modele",
             "Ouvrez une invite de commandes et tapez : ollama pull llama3.1 "
             "(ou qwen2.5-coder pour les recettes)."),
            ("Verifier qu'il tourne",
             "Ollama demarre un service local sur "
             "http://localhost:11434. Si vous l'avez change, indiquez la "
             "bonne adresse dans ORION."),
            ("Choisir Ollama dans ORION",
             "Reglages > Assistant IA > fournisseur « Ollama (local) », "
             "champ « Modele » : le nom exact du modele telecharge. Laissez "
             "la cle vide."),
        ],
        links=[("Ollama", "https://ollama.com"),
               ("Bibliotheque de modeles", "https://ollama.com/library")],
        keywords=["ollama", "local", "hors ligne", "prive", "llama", "gratuit"],
    ),
]


# ==========================================================================
# 6. Fichiers, depannage, FAQ
# ==========================================================================

TECHNIQUE = [
    Article(
        id="comptes",
        title="Connecter Steam, GOG et Xbox",
        summary="Tous vos jeux, vos succes et votre profil, sans donner de mot de passe.",
        body=[
            "La page Comptes relie ORION a vos comptes. La connexion se fait sur la "
            "page officielle de chaque plateforme, dans une fenetre integree dont la "
            "barre d'adresse montre le site affiche (cadenas vert). ORION ne lit pas ce "
            "que vous y tapez : il recoit un jeton, garde chiffre par Windows sur ce PC, "
            "et rien de la fenetre n'est conserve a sa fermeture.",
            "Steam utilise sa connexion officielle. Pour les jeux, succes, niveau et "
            "badges, Steam demande une cle Web API personnelle et gratuite : ORION ouvre "
            "la page de creation juste apres la connexion et repere la cle tout seul.",
            "GOG et Xbox passent par des methodes non officielles, utilisees depuis des "
            "annees par les launchers libres (Heroic, Legendary, Playnite). Elles sont "
            "signalees comme telles. Epic Games et l'EA app : ORION lit sur le PC les "
            "jeux installes (et, pour Epic, les jeux possedes) ; la connexion du compte "
            "n'est pas encore proposee. Ubisoft n'offre aucune connexion sans donner son "
            "mot de passe, Rockstar aucun acces aux applications tierces, et Battle.net "
            "n'expose pas la bibliotheque des comptes : ORION y lit seulement les jeux "
            "installes.",
            "Tout est en lecture seule : ORION ne peut rien acheter ni modifier.",
        ],
        steps=[
            ("Se connecter", "Comptes > Se connecter sur la carte de la plateforme."),
            ("Steam : ajouter la cle", "Nom de domaine : orion.localhost, accepter, "
             "Enregistrer (confirmation possible sur le telephone)."),
            ("Xbox : cle de securite proposee", "Les cles de securite (passkeys) ne "
             "fonctionnent pas dans la fenetre integree : choisissez « Autres facons "
             "de se connecter » puis « Mot de passe » (ou un code recu par e-mail "
             "ou SMS)."),
            ("GOG avec un compte Google", "Google refuse les fenetres integrees, et "
             "ORION ne contourne pas cette protection : connectez-vous a GOG avec "
             "e-mail et mot de passe. Compte cree avec Google, sans mot de passe "
             "GOG ? « Mot de passe oublie ? » sur la page de connexion GOG, avec "
             "l'adresse de votre compte Google, permet d'en creer un."),
            ("Voir les succes", "Ouvrez la fiche d'un jeu : panneau Succes."),
            ("Se deconnecter", "Comptes > Se deconnecter : le jeton est efface."),
            ("Tout actualiser", "Avec plusieurs comptes connectes, « Tout actualiser » relit chacun ; la ligne au-dessus des cartes resume l'ensemble (jeux, heures de jeu, succes, jeux jamais lances)."),
            ("Jeux en double", "Sous les cartes, ORION liste les jeux presents sur plusieurs plateformes (comptes connectes, jeux installes, jeux possedes lus sur le PC) : utile avant un achat."),
        ],
        keywords=["compte", "steam", "gog", "xbox", "succes", "achievements", "badges",
                  "niveau", "connexion", "cle api", "game pass"],
    ),
    Article(
        id="mises-a-jour",
        title="Mises a jour",
        summary="ORION se met a jour tout seul, apres verification.",
        body=[
            "Des mises a jour arrivent "
            "regulierement. ORION verifie au demarrage, puis toutes les 3 "
            "heures, si une nouvelle version est publiee sur la page "
            "officielle du projet.",
            "En bas a gauche, l'encart de version indique la version "
            "installee. Quand une nouvelle version sort, il s'allume : un clic "
            "la telecharge, l'installe et redemarre ORION, sans autre "
            "fenetre. La progression s'affiche dans l'encart.",
            "Avant d'installer, l'empreinte SHA-256 du fichier telecharge est "
            "comparee a celle publiee : un fichier different est supprime. "
            "La mise a jour remplace le programme, jamais vos donnees ; ORION "
            "se ferme puis redemarre tout seul. Pendant une partie, elle "
            "attend la fin du jeu pour s'installer.",
            "Apres chaque mise a jour, la fenetre « Quoi de neuf » resume les "
            "changements.",
        ],
        steps=[
            ("Installer une nouvelle version", "Cliquez sur l'encart « Nouvelle "
             "version » en bas a gauche : ORION redemarre tout seul."),
            ("Verifier maintenant", "Cliquez sur l'encart de version en bas a "
             "gauche, ou Reglages > Mises a jour > « Rechercher une mise a jour »."),
            ("Masquer l'encart", "Reglages > Mises a jour > decochez « Afficher "
             "la version en bas a gauche »."),
            ("Revoir les nouveautes", "Reglages > Mises a jour > « Nouveautes »."),
            ("Desactiver la verification", "Decochez « Verifier automatiquement "
             "les nouvelles versions »."),
        ],
        links=[("Site officiel", "https://orion-launcher.com/")],
        keywords=["mise a jour", "update", "version", "essai", "nouveautes"],
    ),
    Article(
        id="discret",
        title="Mode discret pendant une partie",
        summary="ORION se fait oublier quand vous jouez.",
        body=[
            "Toutes les 15 secondes, ORION regarde quels programmes tournent "
            "depuis le dossier d'un jeu de votre bibliotheque, meme lance "
            "depuis Steam, Epic ou un raccourci. Rien n'est injecte dans le "
            "jeu : c'est la meme information que le Gestionnaire des taches.",
            "Pendant la partie, ORION suspend l'actualisation de la Boutique, "
            "des jeux gratuits et des envies, la veille des installations, "
            "les jaquettes et les recettes, et passe en priorite basse. Tout "
            "reprend, echelonne, a la fin de la partie.",
            "Le temps de jeu des parties lancees hors d'ORION est aussi compte.",
        ],
        steps=[("Regler", "Reglages > Pendant une partie.")],
        keywords=["discret", "performance", "fps", "arriere-plan", "temps de jeu"],
    ),
    Article(
        id="non-installes",
        title="Jeux possedes non installes",
        summary="Toute votre collection, installee ou non.",
        body=[
            "ORION lit sur ce PC les jeux que vous possedez : Steam (jeux deja "
            "joues et bibliotheque affichee par Steam), Epic Games (cache du "
            "lanceur) et GOG Galaxy (sa base locale). Aucun compte ni cle.",
            "Ils apparaissent en grise a la fin de la bibliotheque. Un clic "
            "ouvre leur installation dans la bonne plateforme ; une fois "
            "installes, ils deviennent des jeux normaux.",
        ],
        steps=[("Masquer la liste", "Case « Non installes » en haut de la "
                "bibliotheque, ou Reglages > Jeux possedes non installes.")],
        keywords=["possedes", "collection", "non installe", "installer", "library"],
    ),
    Article(
        id="fichiers",
        title="Ou sont mes fichiers",
        summary="Tout dans %LOCALAPPDATA%, rien ailleurs.",
        body=[
            "Programme : %LOCALAPPDATA%\\Programs\\ORION",
            "Configuration : %LOCALAPPDATA%\\ORION\\config.json",
            "Bibliotheque, prix, historiques : %LOCALAPPDATA%\\ORION\\orion.db "
            "(base SQLite ; les anciens .json sont gardes en .avant-sqlite)",
            "Rapports de probleme : %LOCALAPPDATA%\\ORION\\rapports",
            "Jaquettes et visuels : %LOCALAPPDATA%\\ORION\\cache",
            "Sauvegardes de reglages : %LOCALAPPDATA%\\ORION\\backups",
            "Archives de parties : %LOCALAPPDATA%\\ORION\\sauvegardes",
            "Recettes personnelles : %LOCALAPPDATA%\\ORION\\recipes",
            "Extensions : %LOCALAPPDATA%\\ORION\\plugins",
            "Journal : %LOCALAPPDATA%\\ORION\\logs\\orion.log",
        ],
        steps=[
            ("Ouvrir un de ces dossiers",
             "Reglages > Extensions : chaque ligne a son bouton « Ouvrir »."),
            ("Repartir de zero",
             "Fermez ORION, supprimez config.json, relancez. Votre "
             "bibliotheque et vos sauvegardes sont conservees."),
        ],
        keywords=["dossier", "chemin", "config", "journal", "log", "cache"],
    ),
    Article(
        id="depannage",
        title="Quand quelque chose ne va pas",
        summary="Le journal dit presque toujours pourquoi.",
        steps=[
            ("Signaler le probleme",
             "Barre laterale > « Signaler un probleme ». ORION prepare un "
             "rapport sans donnees personnelles (chemins, cles et identifiants "
             "masques), vous le relisez, puis la page de signalement du projet "
             "s'ouvre, deja remplie."),
            ("Lire le journal",
             "Reglages > A propos > « Journal de l'application ». Les lignes "
             "ERROR portent la cause exacte."),
            ("Un jeu refuse de se lancer",
             "Si le message parle d'elevation, le jeu reclame les droits "
             "administrateur : ORION repasse par Windows, qui affiche sa "
             "demande d'autorisation. Acceptez-la."),
            ("Un jeu apparait en double",
             "Relancez une analyse : les doublons sont fusionnes au scan. "
             "S'il persiste, masquez celui qui est en trop depuis sa fiche."),
            ("Les prix ne se mettent pas a jour",
             "Verifiez le pays dans Reglages > Prix. Quand le comparateur "
             "complet est indisponible, seuls les prix Steam sont connus : "
             "ORION reessaie de lui-meme."),
            ("ORION ne s'ouvre pas",
             "Il est peut-etre deja lance : un second demarrage rappelle la "
             "fenetre existante au lieu d'en ouvrir une seconde. Regardez la "
             "barre des taches."),
        ],
        keywords=["bug", "erreur", "plante", "probleme", "journal", "marche pas"],
    ),
]


FAQ = [
    ("ORION est-il gratuit ?",
     "Oui, entierement, et sans publicite, sans compte et "
     "sans fonction bridee. Le projet vit des dons libres (bouton de la barre "
     "laterale) et de liens partenaires vers certaines boutiques, qui ne "
     "changent pas le prix que vous payez. Aucun des deux ne debloque quoi "
     "que ce soit."),
    ("ORION evolue-t-il encore ?",
     "Oui. Tout fonctionne, et des "
     "ameliorations arrivent regulierement : ORION se met a jour tout seul."),
    ("ORION remplace-t-il Steam ou Epic ?",
     "Non. Les plateformes restent necessaires pour telecharger, mettre a "
     "jour et authentifier les jeux. ORION se place au-dessus : il les "
     "rassemble, les regle et les lance."),
    ("Est-ce que ca peut casser mes jeux ?",
     "ORION sauvegarde chaque fichier avant de le modifier, et le bouton "
     "« Restaurer » remet l'etat precedent. Il n'ecrit jamais sans montrer "
     "l'apercu et demander confirmation, ne force jamais un fichier en lecture "
     "seule, et relit chaque reglage apres l'avoir ecrit."),
    ("Mes donnees partent-elles quelque part ?",
     "Rien ne part sans votre accord, et jamais rien de personnel. ORION "
     "pose la question une fois (modifiable dans Reglages). Si vous dites "
     "oui, il partage vos mesures de performances (jeu, carte graphique, "
     "processeur, definition, images par seconde) et un compteur anonyme : "
     "qu'ORION a ete ouvert, quelles pages sont utilisees, et le nom de la "
     "boutique quand vous ouvrez une offre, jamais le jeu. Le service note "
     "aussi le pays et la region d'ou vient l'envoi, jamais la ville. A la "
     "fermeture, ORION envoie encore un bilan de fluidite : combien de fois "
     "l'affichage s'est fige, le nom de la fonction d'ORION en cause, le temps "
     "de demarrage et le nombre d'erreurs du journal, jamais le jeu ni un "
     "chemin de fichier. Quand vous apprenez a ORION les niveaux d'un jeu, "
     "la recette obtenue (noms et valeurs de reglages, rien de personnel) "
     "est proposee aux autres joueurs. Si vous "
     "dites non, les seules connexions sortantes servent a recuperer les "
     "jaquettes, les prix et les jeux gratuits aupres des boutiques, depuis "
     "votre machine ; les prix de Gamesplanet viennent d'un fichier public "
     "heberge sur GitHub ; le prix d'un revendeur de cles passe par le service "
     "d'ORION, qui ne recoit que le jeu demande. Les DLC que vous possedez "
     "sont lus dans les fichiers de Steam de votre PC et n'en sortent pas. "
     "Aucun compte n'est demande."),
    ("Pourquoi certains jeux n'ont-ils pas de profil ?",
     "Parce qu'ils n'exposent aucun fichier de reglages lisible. ORION "
     "prefere le dire plutot que proposer des boutons sans effet. Voir "
     "l'article « Quand un jeu n'est pas reglable »."),
    ("Faut-il les droits administrateur ?",
     "Jamais pour ORION lui-meme. Seuls certains jeux les reclament pour "
     "demarrer ; dans ce cas c'est Windows qui demande l'autorisation. La "
     "mesure des images par seconde demande seulement que votre compte soit "
     "dans le groupe « Utilisateurs du journal de performances » (voir "
     "l'article « Mesurer les images par seconde »)."),
    ("Est-ce que ca marche sur Linux ou macOS ?",
     "Non. ORION s'appuie sur des interfaces propres a Windows pour les "
     "ecrans, la base de registre et les manettes."),
    ("Que se passe-t-il si je desinstalle ORION ?",
     "Les reglages deja ecrits dans vos jeux restent en place. Vos "
     "sauvegardes de parties et vos archives sont conservees, sauf si vous "
     "demandez explicitement leur suppression."),
    ("Puis-je utiliser ORION sans Internet ?",
     "Oui, pour tout ce qui touche a la detection, aux reglages, au "
     "lancement et aux sauvegardes. Seuls les jaquettes, les prix et les "
     "jeux gratuits ont besoin du reseau."),
    ("L'IA est-elle obligatoire ?",
     "Non. Elle n'ajoute que quatre actions, dont « Apprendre ce jeu a "
     "ORION ». Tout le reste fonctionne sans."),
]


RUBRIQUES = [
    Rubrique("demarrer", "Premiers pas", DEMARRER),
    Rubrique("reglages", "Regler et lancer", REGLAGES),
    Rubrique("pages", "Les pages d'ORION", PAGES),
    Rubrique("recettes", "Recettes et extensions", RECETTES),
    Rubrique("cles", "Cles d'API, pas a pas", CLES),
    Rubrique("technique", "Fichiers et depannage", TECHNIQUE),
]


def search(query: str) -> list[tuple[Rubrique, list[Article]]]:
    """Rubriques et articles correspondant a la recherche."""
    out: list[tuple[Rubrique, list[Article]]] = []
    for rubrique in RUBRIQUES:
        trouves = [a for a in rubrique.articles if a.matches(query)]
        if trouves:
            out.append((rubrique, trouves))
    return out


def faq_matching(query: str) -> list[tuple[str, str]]:
    return [(q, r) for q, r in FAQ if contains_all(q + " " + r, query)]
