"""Jeux bloques a un nombre d'images par seconde (13 octobre 2026).

Elden Ring ne depasse jamais 60 images par seconde, quelle que soit la
carte : le site annoncait « 88 a 121 i/s » avec une RTX 4060. Ces jeux
ont une limite fixee par leur moteur (ou, pour les jeux de combat, par le jeu
en ligne) ; l'estimation est ramenee a cette limite et le dit.

Seules des limites connues et sans reglage dans le jeu figurent ici (un mod
peut parfois les lever : ORION ne le suppose pas). Identifiants Steam.
"""
from __future__ import annotations

#: appid Steam -> images par seconde au plus
IMAGES_MAX: dict[str, int] = {
    "1245620": 60,     # ELDEN RING
    "2622380": 60,     # ELDEN RING NIGHTREIGN
    "374320": 60,      # DARK SOULS III
    "570940": 60,      # DARK SOULS: REMASTERED
    "335300": 60,      # DARK SOULS II: Scholar of the First Sin
    "814380": 60,      # Sekiro: Shadows Die Twice
    "524220": 60,      # NieR:Automata
    "1888160": 120,    # ARMORED CORE VI FIRES OF RUBICON
    "502500": 60,      # ACE COMBAT 7: SKIES UNKNOWN
    # jeux de combat : 60 images par seconde, la cadence du jeu en ligne
    "1778820": 60,     # TEKKEN 8
    "1364780": 60,     # Street Fighter 6
    "1971870": 60,     # Mortal Kombat 1
    "976310": 60,      # Mortal Kombat 11
    "678950": 60,      # DRAGON BALL FighterZ
    "1384160": 60,     # GUILTY GEAR -STRIVE-
    "520440": 60,      # GUILTY GEAR Xrd REV 2
    "348550": 60,      # GUILTY GEAR XX ACCENT CORE PLUS R
}


def limite(appid) -> int | None:
    """Images par seconde au plus pour ce jeu, ou None."""
    return IMAGES_MAX.get(str(appid or ""))
