"""Scan libre de dossiers de jeux (installations manuelles, repacks, portables).

Les emplacements viennent de la configuration (`scan.extra_folders`) et d'une
liste de candidats classiques detectes sur les disques presents.
"""
from __future__ import annotations

from pathlib import Path

from ...core.config import CONFIG
from ...core.logging_setup import get
from ...core.models import Game
from ...core.paths import expand, is_windows
from ...core.winutil import dir_size
from .base import Scanner, detect_engine, looks_like_game_folder, pick_main_exe

log = get("scan.folders")

COMMON_NAMES = ("Games", "Jeux", "Game", "GAMES", "SteamLibrary", "Jeux PC")

#: dossiers a ne jamais explorer
SKIP = {"windows", "program files", "program files (x86)", "programdata",
        "$recycle.bin", "system volume information", "appdata"}


def _drives() -> list[Path]:
    if not is_windows():
        return []
    out = []
    for letter in "CDEFGHIJKLMNOPQRSTUVWXYZ":
        p = Path(f"{letter}:\\")
        try:
            if p.exists():
                out.append(p)
        except OSError:
            continue
    return out


def candidate_folders() -> list[Path]:
    """Dossiers ou chercher des jeux : ceux de la config + les classiques."""
    out: list[Path] = []
    for raw in CONFIG.get("scan.extra_folders", []) or []:
        p = expand(raw)
        if p.is_dir():
            out.append(p)
    for drive in _drives():
        for name in COMMON_NAMES:
            p = drive / name
            if p.is_dir() and p not in out:
                out.append(p)
    home_games = Path.home() / "Games"
    if home_games.is_dir() and home_games not in out:
        out.append(home_games)
    return out


class FolderScanner(Scanner):
    id = "dossier"
    label = "Dossiers de jeux"
    icon = "DIR"
    priority = 20

    def available(self) -> bool:
        return bool(candidate_folders())

    def scan(self) -> list[Game]:
        games: list[Game] = []
        min_mb = float(CONFIG.get("scan.min_exe_mb", 1) or 1)

        for base in candidate_folders():
            for child in self._children(base):
                try:
                    if not looks_like_game_folder(child):
                        continue
                    exe = pick_main_exe(child, child.name, min_mb=min_mb)
                    if not exe:
                        continue
                    games.append(self._mk(
                        title=self._title(child.name),
                        source_id=str(child).lower(),
                        install_dir=str(child),
                        executable=exe,
                        working_dir=str(Path(exe).parent),
                        size_bytes=dir_size(child, 6000),
                        engine=detect_engine(child),
                        extra={"scanned_from": str(base)},
                    ))
                except Exception:
                    log.exception("Dossier ignore : %s", child)
        log.info("%d jeux dans les dossiers libres", len(games))
        return games

    @staticmethod
    def _children(base: Path) -> list[Path]:
        try:
            kids = [p for p in base.iterdir()
                    if p.is_dir() and p.name.lower() not in SKIP
                    and not p.name.startswith(".")]
        except Exception:
            return []
        # une bibliotheque Steam a ses jeux dans steamapps/common
        common = base / "steamapps" / "common"
        if common.is_dir():
            try:
                kids += [p for p in common.iterdir() if p.is_dir()]
            except Exception:
                pass
        return kids

    @staticmethod
    def _title(name: str) -> str:
        """Nettoie un nom de dossier pour en faire un titre lisible."""
        import re
        t = name.replace("_", " ")
        t = re.sub(r"\s*\[[^\]]*\]", "", t)                       # [FitGirl Repack]
        t = re.sub(r"\s*\((?:[^)]*(?:repack|multi\d*|elamigos|goty|codex|"
                   r"plaza|dodi)[^)]*|v?[\d\.]+)\)", "", t, flags=re.I)
        t = re.sub(r"[\s\.\-]*(v\d[\d\.]*|build[\s\.]?\d+|"
                   r"\d+\.\d+\.\d+[\d\.]*)\s*$", "", t, flags=re.I)
        # un point qui separe deux vrais mots devient une espace
        t = re.sub(r"(?<=[A-Za-z]{2})\.(?=[A-Za-z0-9])", " ", t)
        t = re.sub(r"\s{2,}", " ", t)
        return t.strip(" -.") or name
