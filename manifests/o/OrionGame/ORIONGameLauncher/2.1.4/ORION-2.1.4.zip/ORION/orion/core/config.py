"""Configuration persistante (JSON) avec valeurs par defaut fusionnees."""
from __future__ import annotations

import copy
import json
import os
import shutil
import threading
import time
import weakref
from pathlib import Path
from typing import Any

from .logging_setup import get
from .paths import CONFIG_FILE, ecrire_atomique, ensure_dirs
from ..version import CONFIG_SCHEMA

log = get("config")

DEFAULTS: dict[str, Any] = {
    "schema": CONFIG_SCHEMA,
    "ui": {
        "accent": "#38E1FF",
        "card_width": 190,
        "sort": "title",            # title | last_played | playtime | size | recent
        "show_hidden": False,
        "hide_missing": True,
        "start_maximized": True,
        "background": "",            # image de fond ; vide = celle livree
        "fond_du_jour": True,        # le fond livre change chaque jour
        "banniere_saison": True,     # banniere de la saison en haut des pages
        "background_dim": 78,        # densite du voile, en pour cent
        "dynamic_background": True,  # le fond prend la jaquette du jeu ouvert
        "gamepad": True,             # navigation a la manette
        "big_picture": False,        # affichage salon (grandes tuiles)
        "splash": True,              # ecran de demarrage
        "single_instance": True,     # un seul ORION a la fois
        "hero": True,                # banniere du dernier jeu joue
        "hero_rotation_seconds": 9,  # defilement de la banniere (0 = fige)
        "hero_count": 8,             # nombre de jeux dans la banniere
    },
    "scan": {
        "enabled_sources": [],       # vide = toutes les sources disponibles
        "extra_folders": [],         # dossiers a explorer en plus
        "min_exe_mb": 1,             # taille minimale d'un .exe candidat
        "auto_scan_on_start": True,
        "watch_interval_min": 10,     # veille des nouvelles installations
        "watch_enabled": True,
    },
    "artwork": {
        "enabled": True,
        "steamgriddb_key": "",       # optionnel, ameliore les jaquettes
        "max_parallel": 6,
    },
    "optimizer": {
        "default_profile": "recommande",
        "apply_display_mode": True,
        "restore_display_after": True,
        "backup_before_write": True,
        "confirm_before_write": True,     # jamais d'ecriture sans validation
    },
    "free": {
        # Veille des jeux gratuits : offres a recuperer, week-ends gratuits,
        # jeux gratuits pour toujours.
        "enabled": True,
        "refresh_hours": 6,
        "notify": True,
        "sources": [],             # vide = toutes les sources disponibles
        "detail_budget": 40,       # fiches Steam consultees par passage
        "hide_demos": True,        # ecarter les demos, playtests et betas
    },
    "market": {
        "enabled": True,
        "itad_key": "",              # cle IsThereAnyDeal personnelle (facultative)
        "itad_relais": {},           # etat du relais du service (voir orion/itad.py)
        "country": "FR",
        "cache_hours": 12,
        "translate_news": True,      # actualites des jeux traduites en francais
    },
    "ai": {
        "provider": "anthropic",     # anthropic | openai | google | mistral | ollama
        "api_key": "",
        "model": "",
        "ollama_url": "http://localhost:11434",
        "enabled": False,
    },
    "saves": {
        "enabled": True,
        "auto_after_play": True,     # archiver a la fin d'une partie
        "keep": 10,                  # nombre d'archives conservees par jeu
        "cloud_dir": "",             # dossier OneDrive / Google Drive / Dropbox
    },
    "wishlist": {
        "steamid": "",
        "check_hours": 6,            # frequence de verification des prix
        "notify": True,
        "alerte_baisse": True,       # prevenir d'une baisse nette, meme sans seuil (2.0)
    },
    "perf": {
        "enabled": False,          # mesure des images par seconde
    },
    "community": {
        "enabled": True,
        "index_url": "https://raw.githubusercontent.com/Sikher-kisa/orion-recettes/main/index.json",
        "sync_hours": 24,
        "author": "",
    },
    "support": {
        # Le lien de don n'est PAS un reglage : voir DONATE_URL plus bas.
        # Seul l'affichage du bouton se regle depuis l'application.
        "show_button": True,
    },
    "marche_gris": {
        "afficher": True,          # encart de liens dans la fiche des jeux
    },
    "boutique": {
        "refresh_minutes": 12,     # vitrine de la Boutique (10 a 15 min conseille)
        "liens_partenaires": True, # identifiant partenaire ORION sur les liens de boutique
        "afficher_applications": False,  # logiciels, formations, BO... masques par defaut
        "types_complets": True,    # jeux les plus en vue de chaque type, en promotion ou non
        "plus_bas": True,          # plus bas historique de chaque jeu (IsThereAnyDeal)
        "meme_esprit": True,       # jeu introuvable : proposer des jeux du meme esprit
    },
    "maj": {
        "auto": True,                # verifier les nouvelles versions
        "afficher_version": True,    # encart version / nouvelle version (bas gauche)
        "derniere_vue": "",          # version dont les nouveautes ont ete vues
    },
    "jeu": {
        "discret": True,             # pause des taches de fond pendant une partie
        "compter_hors_orion": True,  # temps de jeu des parties lancees ailleurs
        "reduire": True,             # reduire ORION quand il lance un jeu (2.1.0)
    },
    "bibliotheque": {
        "non_installes": True,       # afficher les jeux possedes non installes
    },
    "langue": "fr",                  # fr | en
    "region_detectee": False,
    "videos": {
        "lecture_auto": True,        # la bande-annonce demarre seule, son coupe
    },
    "partage": {                     # mesures anonymes partagees (voir partage.py)
        "actif": False,              # jamais sans un oui du joueur
        "demande": False,            # la question a-t-elle ete posee ?
        "poste": "",                 # identifiant tire au hasard
    },        # langue et pays pris sur Windows au 1er lancement
    "diagnostic": {
        "fluidite": True,            # noter au journal les arrets de l'affichage et leur cause
    },
    "advisor": {
        "check_gpu_driver": True,
        "check_disk_space": True,
        "check_game_updates": True,
        # conseils que le joueur ne veut plus voir (voir advice_card.cle)
        "masques": [],
        # page Conseils : n'afficher que ce qui demande une action
        "a_traiter": False,
    },
}


#: Lien de don de l'auteur. Volontairement code en dur, et non dans le
#: fichier de configuration : un reglage modifiable laisserait n'importe qui
#: (ou n'importe quel script) rediriger les dons vers un autre compte sans
#: que l'utilisateur s'en rende compte. Le projet reste ouvert -- qui veut
#: changer ce lien modifie cette ligne et recompile, ce qui est un acte
#: delibere et visible.
DONATE_URL = "https://paypal.me/FoxSikh"
DONATE_LABEL = "Soutenir ORION"

#: reglages retires : effaces des fichiers existants a l'ouverture.
RETIRES: tuple[str, ...] = (
    "support.donate_url", "support.donate_label",
    # reglages que plus rien ne lisait (menage du 7 octobre 2026)
    "artwork.prefer_animated", "free.country", "optimizer.close_launcher_on_play",
    "perf.min_seconds", "scan.follow_steam_libraries", "integrations",
)

#: anciennes valeurs remplacees automatiquement a l'ouverture, pour que les
#: installations existantes suivent les corrections sans intervention.
OBSOLETE: dict[str, tuple[str, ...]] = {
    "community.index_url": (
        "https://raw.githubusercontent.com/FoxSikh/orion-recettes/main/index.json",
    ),
}


def _merge(base: dict, over: dict) -> dict:
    """Fusion profonde, sur une copie : `base` (souvent DEFAULTS) n'est
    jamais modifie, et le resultat ne partage aucun dictionnaire avec lui."""
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


def defauts() -> dict[str, Any]:
    """Copie independante des valeurs par defaut."""
    return copy.deepcopy(DEFAULTS)


def mettre_de_cote(fichier: Path) -> Path | None:
    """Copie un fichier illisible en `<nom>.illisible-<horodatage>`. Rend
    la copie, ou None si elle n'a pas pu etre faite."""
    copie = fichier.with_name(f"{fichier.name}.illisible-{time.strftime('%Y%m%d-%H%M%S')}")
    n = 1
    while copie.exists():
        n += 1
        copie = fichier.with_name(
            f"{fichier.name}.illisible-{time.strftime('%Y%m%d-%H%M%S')}-{n}")
    try:
        shutil.copy2(fichier, copie)
        log.warning("Configuration illisible copiee dans %s", copie.name)
        return copie
    except OSError:
        log.exception("Copie de la configuration illisible impossible")
    # copie impossible (disque plein...) : le fichier est renomme, il ne
    # sera donc pas ecrase par le prochain enregistrement
    try:
        os.replace(fichier, copie)
        log.warning("Configuration illisible renommee en %s", copie.name)
        return copie
    except OSError:
        log.exception("Configuration illisible ni copiee ni renommee")
        return None


class Config:
    """Acces par chemin pointe : cfg.get("ui.accent"), cfg.set("ui.accent", "#f00")."""

    def __init__(self) -> None:
        self._verrou = threading.RLock()
        #: fonctions prevenues quand un reglage change (voir `ecouter`)
        self._ecouteurs: list = []
        self.data: dict[str, Any] = defauts()
        #: copie de cote d'un fichier illisible (None si tout va bien)
        self.illisible: Path | None = None
        self.load()

    def load(self) -> None:
        try:
            ensure_dirs()
        except OSError:
            log.exception("Dossier de configuration inaccessible")
        #: tout premier lancement (aucun fichier de configuration)
        self.nouvelle = not CONFIG_FILE.exists()
        if self.nouvelle:
            self.data = defauts()
            self.save()
            return
        try:
            lu = json.loads(CONFIG_FILE.read_text("utf-8"))
            if not isinstance(lu, dict):
                raise ValueError("la configuration n'est pas un objet JSON")
        except Exception:
            log.exception("Configuration illisible, valeurs par defaut utilisees")
            # le fichier abime est copie de cote AVANT toute ecriture : le
            # prochain enregistrement l'ecrase, les cles API et reglages de
            # l'utilisateur doivent rester recuperables a la main
            self.illisible = mettre_de_cote(CONFIG_FILE)
            self.data = defauts()
            return
        self.data = _merge(DEFAULTS, lu)
        if self._migrate():
            self.save()

    def _migrate(self) -> bool:
        """Remplace les valeurs devenues obsoletes par celles par defaut."""
        changed = False
        for path, dead in OBSOLETE.items():
            if self.get(path) in dead:
                default: object = DEFAULTS
                for part in path.split("."):
                    default = default[part]        # type: ignore[index]
                self.set(path, default, save=False)
                log.info("Reglage mis a jour : %s", path)
                changed = True
        for path in RETIRES:
            if self._forget(path):
                log.info("Reglage retire : %s", path)
                changed = True
        return changed

    def _forget(self, path: str) -> bool:
        """Supprime une cle devenue non modifiable. Vrai si elle existait."""
        parts = path.split(".")
        cur = self.data
        for part in parts[:-1]:
            if not isinstance(cur, dict) or part not in cur:
                return False
            cur = cur[part]
        if isinstance(cur, dict) and parts[-1] in cur:
            del cur[parts[-1]]
            return True
        return False

    def save(self) -> None:
        # un seul enregistrement a la fois : deux fils qui enregistrent en
        # meme temps ecrivaient dans le meme fichier provisoire
        with self._verrou:
            try:
                ensure_dirs()
                texte = json.dumps(self.data, indent=2, ensure_ascii=False)
                ecrire_atomique(CONFIG_FILE, texte)
            except Exception:
                log.exception("Ecriture de la configuration impossible")

    def get(self, path: str, default: Any = None) -> Any:
        cur: Any = self.data
        for part in path.split("."):
            if not isinstance(cur, dict) or part not in cur:
                return default
            cur = cur[part]
        return cur

    def set(self, path: str, value: Any, save: bool = True) -> None:
        parts = path.split(".")
        with self._verrou:
            cur = self.data
            for p in parts[:-1]:
                suivant = cur.get(p)
                if not isinstance(suivant, dict):
                    suivant = cur[p] = {}
                cur = suivant
            change = parts[-1] not in cur or cur[parts[-1]] != value
            cur[parts[-1]] = value
            if save:
                self.save()
        if change:
            self._prevenir(path)

    # -- ecouteurs -------------------------------------------------------
    def ecouter(self, fonction) -> None:
        """`fonction(chemin)` est appelee apres chaque `set` qui CHANGE une
        valeur (2.0).

        Avant, un reglage n'etait relu que la ou il servait, au moment ou il
        servait : la largeur des tuiles ne bougeait qu'au rafraichissement
        suivant de la bibliotheque, la frequence de la veille et la manette
        qu'au redemarrage. Ce qui depend d'un reglage s'abonne ici et
        s'applique tout de suite.

        L'ecouteur est garde par reference faible (une fenetre fermee ne
        reste pas en memoire) et peut etre appele depuis un fil de fond : a
        lui de revenir dans le fil d'affichage s'il touche a l'interface."""
        try:
            ref = weakref.WeakMethod(fonction)
        except TypeError:
            ref = weakref.ref(fonction)
        with self._verrou:
            self._ecouteurs.append(ref)

    def _prevenir(self, path: str) -> None:
        with self._verrou:
            refs = list(self._ecouteurs)
        morts = []
        for ref in refs:
            fonction = ref()
            if fonction is None:
                morts.append(ref)
                continue
            try:
                fonction(path)
            except RuntimeError:
                morts.append(ref)          # objet Qt detruit
            except Exception:
                log.exception("Ecouteur de reglage en echec (%s)", path)
        if morts:
            with self._verrou:
                self._ecouteurs = [r for r in self._ecouteurs if r not in morts]


CONFIG = Config()
