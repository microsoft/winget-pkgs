"""Pages de pilotes precises, construites a partir de ce qu'ORION a lu (2.0.2).

Retour de l'auteur (8 octobre, tour MSI) : sur une tour montee, les pilotes
Intel de la carte mere renvoyaient vers l'assistant Intel (une page qui
demande d'installer un outil), et la carte reseau ASUS XG-C100C vers le
centre de telechargement general d'ASUS. Or le modele de la carte mere est
lu (BaseBoard.Product), le modele d'une carte ajoutee est dans son nom, et
ces fabricants ont une adresse par modele : on la construit, pour n'importe
quel modele, au lieu d'entretenir une liste.

- `page_modele(fabricant, modele, genre, plateforme)` : la page support du
  modele chez ASUS, MSI, Gigabyte, ASRock, Dell (carte mere, portable, PC).
- `page_carte(fabricant, nom)` : la page support d'une carte ajoutee, le
  modele etant tire de son nom (« ASUS XG-C100C 10G PCI-E Network Adapter »).
- `page_puce(marque, categorie, nom)` : la page de telechargement du
  fabricant de la puce quand il en publie une par famille (Intel : reseau
  filaire, Wi-Fi, Bluetooth, chipset, graphique).

Adresses verifiees le 8 octobre 2026.
"""
from __future__ import annotations

import re
from urllib.parse import quote

from orion.hardware.systeme import simple

# -- pages par modele ---------------------------------------------------------

#: genres MSI selon la machine (adresse www.msi.com/<Genre>/<modele>/support)
_GENRES_MSI = {"carte_mere": "Motherboard", "portable": "Laptop", "pc": "Desktop", "carte": "Graphics-Card"}


def _slug_msi(modele: str) -> str:
    m = re.sub(r"\s*\((MS|ms)-[0-9A-Za-z]+\)\s*", " ", modele)      # « (MS-7B51) »
    m = re.sub(r"[^A-Za-z0-9.+]+", "-", m.strip()).strip("-")
    return m


def page_modele(fabricant: str, modele: str, genre: str = "carte_mere", plateforme: str = "") -> tuple[str, str]:
    """(adresse, nom du fabricant) de la page support d'un modele precis, ou
    ("", "") quand le fabricant n'a pas d'adresse par modele connue.
    `plateforme` : « Intel » ou « AMD » (ASRock range ses cartes meres ainsi)."""
    f, m = simple(fabricant), (modele or "").strip()
    if not m or simple(m) in ("", "to be filled by o.e.m.", "default string", "system product name"):
        return "", ""
    if re.search(r"\basus", f):
        return f"https://www.asus.com/supportonly/{quote(m.lower())}/helpdesk_download/", "ASUS"
    if re.search(r"\b(micro-star|msi)", f):
        slug = _slug_msi(m)
        if not slug or re.fullmatch(r"MS-?\w+", slug, re.I):      # « MS-7B51 » seul : le code, pas le nom
            return "", ""
        return f"https://www.msi.com/{_GENRES_MSI.get(genre, 'Motherboard')}/{slug}/support", "MSI"
    if re.search(r"\bgigabyte", f):
        return f"https://www.gigabyte.com/Search?kw={quote(m)}", "Gigabyte"
    if re.search(r"\basrock", f):
        if plateforme in ("Intel", "AMD"):
            return f"https://www.asrock.com/mb/{plateforme}/{quote(m)}/index.asp#Download", "ASRock"
        return "", ""
    if re.search(r"\b(dell|alienware)", f):
        slug = re.sub(r"[^a-z0-9]+", "-", simple(m)).strip("-")
        return f"https://www.dell.com/support/home/fr-fr/product-support/product/{slug}/drivers", "Dell"
    return "", ""


# -- cartes ajoutees ----------------------------------------------------------

#: mots qui ne sont jamais un modele (noms de famille, bus, usages)
_MOTS_GENERIQUES = {
    "10g", "2.5g", "1g", "5g", "pci", "pci-e", "pcie", "pci-express", "usb", "usb3", "usb3.0", "network",
    "adapter", "gigabit", "ethernet", "wireless", "wi-fi", "wifi", "bluetooth", "dual", "band", "controller",
    "family", "series", "audio", "sound", "card", "lan", "wlan", "gaming", "pro", "plus", "ultra", "high",
    "definition", "device", "driver", "windows", "the", "and", "with",
}


def modele_dans_nom(nom: str, fabricant: str = "") -> str:
    """Le code modele d'un appareil d'apres son nom : « ASUS XG-C100C 10G
    PCI-E Network Adapter » -> « XG-C100C », « TP-Link Archer T4E » ->
    « Archer T4E ». Vide quand rien n'y ressemble."""
    mots = re.sub(r"\(R\)|\(TM\)|®|™", " ", nom or "").split()
    fab = simple(fabricant)
    debut = 0
    for i, mot in enumerate(mots):
        s = simple(mot).strip(",.")
        if fab and s and (s in fab or fab.startswith(s[:4])):     # « ASUS » dans « asustek computer inc. »
            debut = i + 1
        else:
            break
    reste = mots[debut:]
    for i, mot in enumerate(reste[:3]):
        propre = mot.strip(",.;:()")
        if simple(propre) in _MOTS_GENERIQUES:
            return ""
        if re.fullmatch(r"[A-Za-z]*\d[A-Za-z0-9.-]*|[A-Za-z]+-[A-Za-z0-9-]*\d[A-Za-z0-9-]*", propre):
            precedent = reste[i - 1].strip(",.;:()") if i == 1 else ""
            if precedent and re.fullmatch(r"[A-Za-z][A-Za-z]+", precedent) and simple(precedent) not in _MOTS_GENERIQUES:
                return f"{precedent} {propre}"
            return propre
    return ""


def page_carte(fabricant: str, nom: str) -> tuple[str, str]:
    """(adresse, modele) de la page support d'une carte ajoutee ou d'un
    appareil USB, chez un fabricant qui a une adresse par modele."""
    modele = modele_dans_nom(nom, fabricant)
    if not modele:
        return "", ""
    f = simple(fabricant)
    if re.search(r"\basus", f):
        return f"https://www.asus.com/supportonly/{quote(modele.lower())}/helpdesk_download/", modele
    if re.search(r"\btp-?link", f):
        return f"https://www.tp-link.com/fr/support/download/{quote(modele.lower().replace(' ', '-'))}/", modele
    if re.search(r"\b(micro-star|msi)", f):
        return f"https://www.msi.com/search/{quote(modele)}", modele
    return "", modele


# -- pages du fabricant de la puce, par famille -------------------------------

_INTEL = "https://www.intel.com/content/www/us/en/download/"
_PAGES_INTEL = {
    "reseau": ("Pilotes reseau Intel (pack complet)", _INTEL + "15084/intel-ethernet-adapter-complete-driver-pack.html"),
    "wifi": ("Pilotes Wi-Fi Intel", _INTEL + "19351/intel-wireless-wi-fi-drivers-for-windows-10-and-windows-11.html"),
    "bluetooth": ("Pilotes Bluetooth Intel", _INTEL + "18649/intel-wireless-bluetooth-drivers-for-windows-10-and-windows-11.html"),
    "chipset": ("Pilotes du chipset Intel (INF)", _INTEL + "19347/chipset-inf-utility.html"),
    "graphique": ("Pilotes graphiques Intel", _INTEL + "785597/intel-arc-iris-xe-graphics-windows.html"),
}
_WIFI = re.compile(r"wi-?fi|wireless|\bAX\d{3}|\bBE\d{3}|dual band", re.I)


def page_puce(marque: str, categorie: str, nom: str = "") -> tuple[str, str]:
    """(bouton, adresse) de la page de telechargement du fabricant de la
    puce pour cette famille, ou ("", "") quand il n'en publie pas (Realtek,
    stockage Intel, USB...) : le pilote vient alors de la carte mere."""
    if marque != "intel":
        return "", ""
    if categorie == "reseau" and _WIFI.search(nom or ""):
        categorie = "wifi"
    return _PAGES_INTEL.get(categorie, ("", ""))
