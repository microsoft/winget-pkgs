"""Contrat commun aux sources de jeux gratuits.

Une source repond a une seule question : quels jeux sont gratuits en ce
moment, et pour combien de temps. Elle ne sait rien du reste : c'est le
service qui fusionne les doublons, complete les details depuis Steam et
range le resultat.

Trois natures de gratuite sont distinguees, parce qu'elles n'engagent pas
du tout la meme chose pour le joueur :

``definitif``
    Le jeu est gratuit pour toujours (free-to-play, ou passe gratuit
    definitivement). Aucune date de fin.
``a_garder``
    Offre limitee dans le temps, mais une fois recupere le jeu reste dans
    le compte pour toujours (Epic du jeudi, cadeaux GOG, Prime Gaming).
    Seule la fenetre de recuperation expire.
``temporaire``
    Le jeu n'est jouable que pendant la periode annoncee : week-end
    gratuit, essai. Passee la date, il faut l'acheter pour continuer.
    C'est le seul cas ou ORION propose la desinstallation a l'expiration.
"""
from __future__ import annotations

import re
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone

from ...core.logging_setup import get
from ...core.models import normalize_title

log = get("gratuits")

from ...core.steam_limite import NAVIGATEUR as HEADERS  # noqa: E402

DEFINITIF = "definitif"
A_GARDER = "a_garder"
TEMPORAIRE = "temporaire"

KIND_LABELS = {
    DEFINITIF: "Gratuit pour toujours",
    A_GARDER: "A recuperer, garde a vie",
    TEMPORAIRE: "Gratuit temporairement",
}

#: formulations qui trahissent un week-end gratuit plutot qu'un cadeau
_TEMPORARY_HINTS = re.compile(
    r"(free\s*weekend|week[- ]?end\s*gratuit|free\s*to\s*play\s*weekend|"
    r"play\s*for\s*free\s*until|free\s*trial|essai\s*gratuit|"
    r"jouer\s*gratuitement\s*jusqu|temporarily\s*free)", re.I)


class SourceUnavailable(RuntimeError):
    """La source n'a pas pu etre interrogee (reseau, service en panne).

    A distinguer absolument d'une reponse vide : « aucune offre en ce
    moment » signifie que les offres connues doivent disparaitre de la
    liste, tandis qu'une source injoignable ne doit rien faire disparaitre
    du tout. Une coupure reseau de trente secondes ne doit pas vider la
    page des jeux gratuits.
    """


def fetch_json(url: str, params: dict | None = None, timeout: int = 15):
    """Appel HTTP d'une source, qui echoue franchement plutot qu'a vide."""
    from orion.core import reseau
    from ...core import steam_limite
    steam = steam_limite.concerne(url)
    if steam:
        if steam_limite.en_pause():
            raise SourceUnavailable("Steam en pause apres un refus")
        steam_limite.attendre()
    try:
        r = reseau.get(url, params=params or {}, headers=HEADERS,
                         timeout=timeout)
    except Exception as exc:
        raise SourceUnavailable(f"{url} injoignable : {exc}") from exc
    if r.status_code != 200:
        if steam and r.status_code in (403, 429):
            steam_limite.signaler_refus()
        raise SourceUnavailable(f"{url} a repondu {r.status_code}")
    try:
        return r.json()
    except Exception as exc:
        raise SourceUnavailable(f"{url} : reponse illisible") from exc


def looks_temporary(*texts: str) -> bool:
    """Vrai si le libelle decrit un acces temporaire, pas un cadeau."""
    return any(_TEMPORARY_HINTS.search(t or "") for t in texts)


#: une demo, un playtest ou une beta ne sont pas des jeux gratuits : ce sont
#: des extraits d'un jeu payant. Les catalogues les melangent pourtant aux
#: vrais gratuits, au point de les noyer. Le marqueur est toujours en fin de
#: titre, ce qui evite de confondre avec un jeu nomme « Demolition ».
_DEMO = re.compile(
    r"(?:[\s:\-\u2013\u2014(\[]|^)"
    r"(?:demo|d[eé]mo|playtest|play\s*test|pre[- ]?alpha|"
    r"closed\s*(?:beta|test)|open\s*beta|beta\s*test|test\s*version|"
    r"version\s*d[\'\u2019]essai|avant[- ]premi[eè]re)"
    r"[\s)\]]*$", re.I)


def is_demo(title: str) -> bool:
    """Vrai si le titre designe une demo, un playtest ou une beta d'essai."""
    return bool(_DEMO.search((title or "").strip()))


#: ce qui accompagne un jeu sans en etre un : bandes-son, artbooks, fonds
#: d'ecran, contenus additionnels. Les catalogues les publient comme des
#: offres gratuites a part entiere, alors que la page repond a une seule
#: question : « a quel jeu puis-je jouer gratuitement ? »
_NOT_A_GAME = re.compile(
    r"(?:[\s:\-\u2013\u2014(\[]|^)"
    r"(?:soundtrack|bande[- ]son|original\s*soundtrack|ost|"
    r"art\s*book|artbook|livre\s*d[\'\u2019]art|"
    r"wallpapers?(?:\s*pack)?|fonds?\s*d[\'\u2019]ecran|"
    r"season\s*pass|expansion\s*pass|dlc|"
    r"skins?\s*pack|cosmetic\s*pack|avatar\s*pack|"
    r"digital\s*(?:deluxe\s*)?(?:art|bonus|extras?)|"
    r"comics?|manual|guide\s*strategique)"
    r"[\s)\]]*$", re.I)


def is_extra(title: str) -> bool:
    """Vrai si le titre designe un a-cote (bande-son, DLC, artbook...)."""
    return bool(_NOT_A_GAME.search((title or "").strip()))


def parse_date(value) -> float:
    """Convertit une date d'API en horodatage. 0 si inconnue ou absente."""
    if not value or str(value).strip().upper() in ("N/A", "NONE", "NULL"):
        return 0.0
    raw = str(value).strip().replace("Z", "+00:00")
    for fmt in (None, "%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            if fmt is None:
                dt = datetime.fromisoformat(raw)
            else:
                dt = datetime.strptime(raw, fmt)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt.timestamp()
        except Exception:
            continue
    return 0.0


#: condition minimale connue par boutique, quand l'offre n'en publie pas
SHOP_CONDITIONS = {
    "Epic Games Store": "Compte Epic Games requis (gratuit). Le jeu reste "
                        "acquis definitivement une fois reclame.",
    "Steam": "Compte Steam requis (gratuit).",
    "GOG": "Compte GOG requis (gratuit). Jeu sans DRM, telechargeable a vie.",
    "Prime Gaming": "Abonnement Amazon Prime necessaire ; la cle obtenue "
                    "reste valable apres la fin de l'abonnement.",
    "Ubisoft Connect": "Compte Ubisoft requis (gratuit).",
    "EA app": "Compte EA requis (gratuit).",
    "Battle.net": "Compte Battle.net requis (gratuit).",
    "itch.io": "Compte itch.io requis pour conserver le jeu dans la "
               "bibliotheque ; le telechargement direct est souvent possible "
               "sans compte.",
    "Xbox": "Compte Microsoft requis (gratuit).",
    "Sans DRM": "Telechargement direct, sans compte ni DRM.",
    "IndieGala": "Compte IndieGala requis (gratuit) ; le jeu se telecharge ensuite sans DRM "
                 "depuis votre bibliotheque IndieGala.",
}

#: a defaut de tout le reste, ce que la nature de l'offre implique
DEFAULT_CONDITION = {
    "definitif": "Aucune condition : le jeu est gratuit en permanence.",
    "a_garder": "Un compte sur la boutique concernee est generalement "
                "necessaire pour reclamer l'offre.",
    "temporaire": "Le jeu est jouable gratuitement pendant la periode "
                  "annoncee, puis redevient payant.",
}



def _montant(valeur: float, devise: str) -> str:
    """(2.1.2) « 29,99 $ » en français, « $29.99 » en anglais, comme les prix de la
    boutique ; avant : « 29.99 USD » quelle que soit la langue. Un prix rond garde
    ses décimales retirées (« 20 $ »)."""
    from orion.core import region
    rond = abs(valeur - round(valeur)) < 0.005
    return region.prix(valeur, devise or "EUR", decimales=not rond)

@dataclass
class Freebie:
    """Un jeu gratuit repere en ligne."""

    key: str                          # identifiant stable "source:id"
    title: str
    source: str = ""                  # plugin d'origine
    shop: str = ""                    # boutique lisible (Epic, Steam, GOG...)
    url: str = ""                     # lien direct vers la page de l'offre
    kind: str = A_GARDER
    starts_at: float = 0.0
    ends_at: float = 0.0
    worth: float = 0.0                # prix habituel du jeu
    currency: str = "EUR"
    image: str = ""                   # illustration distante
    description: str = ""

    # -- details completes depuis Steam ---------------------------------
    steam_appid: str = ""
    conditions: str = ""              # ce qu'il faut faire pour l'obtenir
    screenshots: list[str] = field(default_factory=list)   # adresses distantes
    shots_local: list[str] = field(default_factory=list)   # copies en cache
    price_before: float = 0.0         # dernier prix connu avant la gratuite
    modes: list[str] = field(default_factory=list)
    platforms: list[str] = field(default_factory=list)
    genres: list[str] = field(default_factory=list)
    review_score: int = 0
    review_count: int = 0
    review_label: str = ""
    metacritic: int = 0
    release_date: str = ""
    developer: str = ""
    buy_url: str = ""                 # page d'achat, pour l'apres-gratuite

    # -- suivi utilisateur ----------------------------------------------
    seen_at: float = field(default_factory=time.time)
    claimed_at: float = 0.0           # date du clic sur "Recuperer"
    alerted_at: float = 0.0           # date de l'alerte de fin de gratuite
    dismissed: bool = False
    #: vrai quand le sort de l'annonce « jeu gratuit du jour » est regle
    #: (notifiee, ou ecartee pour de bon) : une offre n'est annoncee qu'une fois
    annonce: bool = False
    #: jeu reserve aux adultes (voir `contenu_adulte`) : jamais affiche
    adulte: bool = False

    # ------------------------------------------------------------------
    @property
    def norm(self) -> str:
        return normalize_title(self.title)

    @property
    def temporary(self) -> bool:
        return self.kind == TEMPORAIRE

    @property
    def permanent(self) -> bool:
        """Le jeu reste jouable apres la fin de l'offre."""
        return self.kind in (DEFINITIF, A_GARDER)

    @property
    def claimed(self) -> bool:
        return bool(self.claimed_at)

    @property
    def expired(self) -> bool:
        return bool(self.ends_at) and self.ends_at < time.time()

    @property
    def upcoming(self) -> bool:
        return bool(self.starts_at) and self.starts_at > time.time()

    @property
    def seconds_left(self) -> float:
        return max(0.0, self.ends_at - time.time()) if self.ends_at else 0.0

    @property
    def kind_label(self) -> str:
        return KIND_LABELS.get(self.kind, self.kind)

    @property
    def deadline_label(self) -> str:
        """Compte a rebours lisible, ou la nature de l'offre si illimitee."""
        if self.upcoming:
            return "disponible le " + time.strftime(
                "%d/%m a %Hh", time.localtime(self.starts_at))
        if not self.ends_at:
            return "sans date de fin"
        left = self.seconds_left
        if not left:
            return "offre terminee"
        days, rest = divmod(int(left), 86400)
        hours = rest // 3600
        if days >= 2:
            return f"il reste {days} jours"
        if days == 1:
            return f"il reste 1 jour et {hours} h"
        if hours >= 1:
            return f"il reste {hours} h"
        return "il reste moins d'une heure"

    @property
    def urgent(self) -> bool:
        return bool(self.ends_at) and 0 < self.seconds_left < 36 * 3600

    @property
    def genre_label(self) -> str:
        return ", ".join(self.genres[:3])

    @property
    def price_before_label(self) -> str:
        prix = self.price_before or self.worth
        if not prix:
            return ""
        return _montant(prix, self.currency)

    @property
    def conditions_label(self) -> str:
        """Ce qu'il faut faire pour obtenir ce jeu, en une phrase.

        Les agregateurs publient des instructions brutes (« Login to your
        Alienware Arena account and redeem 10 ARP »). Quand la boutique n'en
        publie pas, ORION donne au moins la condition minimale : la plupart
        des cadeaux demandent un compte sur la boutique concernee.
        """
        if self.conditions:
            from .consignes import traduire_consignes
            return traduire_consignes(self.conditions)[0]
        return SHOP_CONDITIONS.get(self.shop, DEFAULT_CONDITION.get(self.kind, ""))

    @property
    def worth_label(self) -> str:
        if not self.worth:
            return ""
        return _montant(self.worth, self.currency)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Freebie":
        known = set(cls.__dataclass_fields__)
        fb = cls(**{k: v for k, v in d.items() if k in known})
        if "annonce" not in d:
            # offre deja connue d'une version precedente : jamais annoncee
            # apres coup, sauf si elle n'a pas encore commence
            fb.annonce = not fb.upcoming
        return fb


class FreebieSource:
    """Sous-classer et implementer `fetch`. Decouverte automatique.

    Deposer un fichier dans `%LOCALAPPDATA%/ORION/plugins/freebies/` suffit
    a ajouter une source, sans toucher au code livre.
    """

    abstract = True
    id: str = ""
    label: str = ""
    priority: int = 50
    needs_key: bool = False
    #: OBLIGATOIRE : comment cette source signale les jeux reserves aux
    #: adultes. Une source sans cette declaration fait echouer les tests.
    filtre_adulte: str = ""

    @staticmethod
    def adulte(brut: dict) -> bool:
        """A appeler sur chaque produit brut : `Freebie(..., adulte=self.adulte(p))`."""
        from ...contenu_adulte import produit_adulte
        return produit_adulte(brut)

    def available(self) -> bool:
        return True

    def fetch(self) -> list[Freebie]:
        """Retourne les offres en cours. Ne doit jamais lever d'exception."""
        return []
