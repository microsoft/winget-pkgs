"""Jeux possedes mais non installes (Steam, Epic, GOG).

Tout est lu sur le disque, sans compte ni cle :

* **Steam** : les jeux deja joues (localconfig.vdf de chaque compte local)
  et ceux affiches dans la bibliotheque Steam (dossier appcache/
  librarycache). Les noms et le type (jeu, DLC, bande-son...) sont
  demandes en un seul appel groupe a l'API publique du magasin ;
* **Epic** : le cache du catalogue du lanceur (catcache.bin, du JSON en
  base64) ;
* **GOG Galaxy** : sa base locale (galaxy-2.0.db).

Un jeu possede apparait en grise dans la bibliotheque ; un clic ouvre sa
page d'installation dans la bonne plateforme. Des qu'il est installe, le
scan normal le trouve et il quitte cette liste.
"""
from __future__ import annotations

from orion.core import region

import base64
import json
import os
import sqlite3
import time
from pathlib import Path

from .core.logging_setup import get
from .core.models import Game, normalize_title

log = get("possedes")

EPIC_CATCACHE = Path(os.environ.get("PROGRAMDATA", r"C:\ProgramData")) / \
    "Epic" / "EpicGamesLauncher" / "Data" / "Catalog" / "catcache.bin"
GOG_DB = Path(os.environ.get("PROGRAMDATA", r"C:\ProgramData")) / \
    "GOG.com" / "Galaxy" / "storage" / "galaxy-2.0.db"

#: types d'articles Steam (IStoreBrowseService) : 0 = jeu
_STEAM_JEU = 0


def _jeu(titre: str, source: str, source_id: str, uri: str, magasin: str = "",
         extra: dict | None = None) -> Game:
    g = Game(title=titre, source=source, source_id=source_id,
             launch_uri=uri, store_url=magasin,
             extra={"non_installe": True, **(extra or {})})
    return g


# --------------------------------------------------------------------------
# Steam
# --------------------------------------------------------------------------
def steam_appids(racine: Path | None = None) -> set[str]:
    from .plugins.scanners.steam import steam_playtimes, steam_root
    racine = racine or steam_root()
    if racine is None:
        return set()
    ids = set(steam_playtimes(racine))
    cache = racine / "appcache" / "librarycache"
    if cache.is_dir():
        for entree in cache.iterdir():
            nom = entree.name.split("_")[0].split(".")[0]
            if nom.isdigit():
                ids.add(nom)
    return {i for i in ids if i.isdigit() and i != "0"}


def steam_noms(appids: list[str]) -> dict[str, str]:
    """{appid: nom} pour les jeux (les DLC, outils et bandes-son sont ecartes).

    Un appel pour 100 identifiants : quelques appels suffisent pour toute
    une bibliotheque. Les reponses sont gardees 30 jours.
    """
    from .core import reseau
    from .core.base import Table
    from .core.steam_limite import NAVIGATEUR
    memo = Table("steam_noms")
    sortie: dict[str, str] = {}
    a_demander = []
    for a in appids:
        m = memo.get(a)
        if m and time.time() - m.get("le", 0) < 30 * 86400:
            if m.get("jeu") and m.get("nom"):
                sortie[a] = m["nom"]
        else:
            a_demander.append(a)
    for i in range(0, len(a_demander), 100):
        lot = a_demander[i:i + 100]
        requete = json.dumps({"ids": [{"appid": int(a)} for a in lot],
                              "context": {"language": region.langue_steam(), "country_code": region.pays()},
                              "data_request": {}})
        try:
            r = reseau.get("https://api.steampowered.com/IStoreBrowseService/GetItems/v1/",
                           params={"input_json": requete}, headers=NAVIGATEUR, timeout=20)
            items = ((r.json() or {}).get("response") or {}).get("store_items") or []
        except Exception as exc:
            log.info("Noms Steam indisponibles : %s", exc)
            break
        vus = set()
        for it in items:
            a = str(it.get("appid") or it.get("id") or "")
            if not a:
                continue
            vus.add(a)
            jeu = it.get("type", _STEAM_JEU) == _STEAM_JEU and it.get("success", 1) == 1 \
                and bool(it.get("name"))
            memo.set(a, {"le": time.time(), "jeu": jeu, "nom": it.get("name", "")})
            if jeu:
                sortie[a] = it["name"]
        for a in lot:
            if a not in vus:
                memo.set(a, {"le": time.time(), "jeu": False, "nom": ""})
    return sortie


def steam() -> list[Game]:
    ids = sorted(steam_appids())
    if not ids:
        return []
    noms = steam_noms(ids)
    # (2.1.2) la bibliotheque Steam montre aussi les jeux de la famille Steam :
    # un jeu absent de la liste du compte connecte est marque, et sera dit
    # « Steam Family » s'il est payant (voir steam_famille)
    from .steam_famille import HORS_COMPTE, jeux_du_compte
    compte = jeux_du_compte()
    return [_jeu(nom, "steam", a, f"steam://install/{a}",
                 f"https://store.steampowered.com/app/{a}",
                 {"steam_appid": a, **({HORS_COMPTE: True} if compte is not None and a not in compte else {})})
            for a, nom in noms.items()]


# --------------------------------------------------------------------------
# Epic
# --------------------------------------------------------------------------
def lire_catcache(contenu: bytes) -> list[dict]:
    """Articles du cache Epic (fonction pure, testee)."""
    try:
        donnees = json.loads(base64.b64decode(contenu).decode("utf-8", "ignore"))
    except Exception:
        return []
    return donnees if isinstance(donnees, list) else []


def epic(fichier: Path = EPIC_CATCACHE) -> list[Game]:
    try:
        articles = lire_catcache(fichier.read_bytes())
    except OSError:
        return []
    sortie = []
    vus = set()
    for a in articles:
        if not isinstance(a, dict):
            continue
        categories = {str((c or {}).get("path", "")).lower()
                      for c in a.get("categories") or []}
        if "games" not in categories or "addons" in categories \
                or a.get("mainGameItem"):
            continue
        titre = a.get("title") or ""
        infos = a.get("releaseInfo") or [{}]
        app = str((infos[0] or {}).get("appId") or "")
        ns, cid = a.get("namespace", ""), a.get("id", "")
        if not titre or not app or app in vus:
            continue
        vus.add(app)
        uri = (f"com.epicgames.launcher://apps/{ns}%3A{cid}%3A{app}?action=install"
               if ns and cid else f"com.epicgames.launcher://apps/{app}?action=install")
        sortie.append(_jeu(titre, "epic", app, uri, "",
                           {"namespace": ns, "catalog_item": cid}))
    return sortie


# --------------------------------------------------------------------------
# GOG Galaxy
# --------------------------------------------------------------------------
def gog(base: Path = GOG_DB) -> list[Game]:
    if not base.exists():
        return []
    try:
        # lecture seule, sans verrouiller la base de Galaxy
        cx = sqlite3.connect(f"file:{base}?mode=ro&immutable=1", uri=True, timeout=5)
        lignes = cx.execute("""
            SELECT gp.releaseKey, gp.value FROM GamePieces gp
            JOIN GamePieceTypes t ON t.id = gp.gamePieceTypeId
            WHERE t.type = 'title'
              AND gp.releaseKey IN (SELECT releaseKey FROM LibraryReleases)
        """).fetchall()
        cx.close()
    except Exception as exc:
        log.info("Base GOG Galaxy illisible : %s", exc)
        return []
    sortie = []
    for cle, valeur in lignes:
        if not str(cle).startswith("gog_"):
            continue                  # Galaxy agrege aussi Steam, Epic... : deja traites
        try:
            titre = (json.loads(valeur) or {}).get("title") or ""
        except Exception:
            titre = ""
        gid = str(cle)[4:]
        if titre and gid.isdigit():
            sortie.append(_jeu(titre, "gog", gid, f"goggalaxy://openGameView/{cle}",
                               f"https://www.gog.com/game/{normalize_title(titre)}"))
    return sortie


# --------------------------------------------------------------------------
def non_installes(installes: list[Game]) -> list[Game]:
    """Jeux possedes absents de la bibliotheque installee."""
    deja_id = {(g.source, str(g.source_id)) for g in installes if g.source_id}
    deja_titre = {normalize_title(g.title) for g in installes}
    trouves: list[Game] = []
    for source, fonction in (("steam", steam), ("epic", epic), ("gog", gog)):
        try:
            jeux = fonction()
        except Exception:
            log.exception("Lecture des jeux possedes %s impossible", source)
            continue
        for g in jeux:
            if (g.source, str(g.source_id)) in deja_id:
                continue
            if normalize_title(g.title) in deja_titre:
                continue
            trouves.append(g)
        log.info("Jeux %s possedes non installes : %d", source,
                 len([g for g in trouves if g.source == source]))
    # comptes connectes (1.8) : la liste complete vue par la plateforme,
    # y compris ce que les fichiers locaux ignorent
    deja_trouves = {(g.source, str(g.source_id)) for g in trouves}
    for g in jeux_des_comptes():
        cle = (g.source, str(g.source_id))
        if cle in deja_id or cle in deja_trouves:
            continue
        if normalize_title(g.title) in deja_titre:
            continue
        trouves.append(g)
        deja_trouves.add(cle)
    return trouves


def jeux_des_comptes() -> list[Game]:
    """Jeux possedes selon les comptes connectes (Steam, GOG), en cache."""
    sortie: list[Game] = []
    try:
        from .comptes import PLATEFORMES
    except Exception:
        return sortie
    for pid, uri, magasin in (
            ("steam", "steam://install/{id}", "https://store.steampowered.com/app/{id}"),
            ("gog", "goggalaxy://openGameView/{id}", "")):
        p = PLATEFORMES.get(pid)
        if p is None or not p.connecte():
            continue
        for j in p.jeux_gardes():
            g = _jeu(j.titre, pid, j.id, uri.format(id=j.id),
                     magasin.format(id=j.id) if magasin else "",
                     {"compte": True, "minutes_compte": j.minutes})
            g.external_seconds = j.minutes * 60
            sortie.append(g)
    return sortie


class Possedes:
    """Liste persistante (base locale), avec les visuels deja recuperes."""

    def __init__(self) -> None:
        from .core.base import Document
        self._doc = Document("possedes")
        brut = self._doc.lire({}) or {}
        self.maj = float(brut.get("maj") or 0)
        self.jeux: dict[str, Game] = {}
        for d in brut.get("jeux") or []:
            try:
                g = Game.from_dict(d)
                self.jeux[g.uid] = g
            except Exception:
                continue

    def enregistrer(self) -> None:
        self._doc.ecrire({"maj": self.maj,
                          "jeux": [g.to_dict() for g in self.jeux.values()]})

    def actualiser(self, installes: list[Game]) -> int:
        """Relit les plateformes ; conserve les visuels deja telecharges."""
        neufs = non_installes(installes)
        anciens = self.jeux
        self.jeux = {}
        for g in neufs:
            vieux = anciens.get(g.uid)
            if vieux is not None:
                for champ in ("art_cover", "art_hero", "art_logo", "art_icon",
                              "hidden", "favorite"):
                    setattr(g, champ, getattr(vieux, champ))
            self.jeux[g.uid] = g
        self.maj = time.time()
        self.enregistrer()
        return len(self.jeux)


    def get(self, uid: str) -> Game | None:
        return self.jeux.get(uid)

    def tous(self) -> list[Game]:
        return list(self.jeux.values())
