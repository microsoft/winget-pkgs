"""Fenetres de la 1.7 : nouveautes, mise a jour disponible, signalement."""
from __future__ import annotations

import webbrowser

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QCheckBox, QDialog, QHBoxLayout, QLabel,
                               QLineEdit, QPlainTextEdit, QProgressBar, QPushButton,
                               QScrollArea, QVBoxLayout, QWidget)

from ...version import APP_NAME, APP_VERSION
from ..theme import build_qss
from ..defilement import ZoneDefilante


def _base(dialogue: QDialog, titre: str, largeur: int = 520) -> QVBoxLayout:
    dialogue.setWindowTitle(titre)
    dialogue.setStyleSheet(build_qss())
    dialogue.setMinimumWidth(largeur)
    lay = QVBoxLayout(dialogue)
    lay.setContentsMargins(26, 22, 26, 22)
    lay.setSpacing(12)
    return lay


def _texte(texte: str, nom: str = "Dim") -> QLabel:
    l = QLabel(texte)
    l.setObjectName(nom)
    l.setWordWrap(True)
    return l


def _liste(points: list[str]) -> QWidget:
    """Les points d'une version, un paragraphe chacun, aeres (retour de
    l'auteur sur la 2.0.1 : une liste collee se lit mal)."""
    from ...i18n import t
    boite = QWidget()
    lay = QVBoxLayout(boite)
    lay.setContentsMargins(0, 0, 0, 0)
    lay.setSpacing(16)            # une ligne vide entre deux points
    for p in points:
        l = QLabel(f"•&nbsp; {t(p)}")
        l.setObjectName("Dim")
        l.setWordWrap(True)
        l.setTextFormat(Qt.TextFormat.RichText)
        lay.addWidget(l)
    return boite


# --------------------------------------------------------------------------
class DialogueNouveautes(QDialog):
    """Ce qui a change depuis la derniere version vue."""

    def __init__(self, entrees: list[dict], parent=None) -> None:
        super().__init__(parent)
        lay = _base(self, "Nouveautes", 560)
        titre = QLabel(f"Quoi de neuf dans {APP_NAME} {APP_VERSION}")
        titre.setObjectName("PanelTitle")
        lay.addWidget(titre)

        zone = ZoneDefilante()
        zone.setWidgetResizable(True)
        zone.setMinimumHeight(260)
        corps = QWidget()
        cl = QVBoxLayout(corps)
        cl.setContentsMargins(0, 0, 8, 0)
        cl.setSpacing(10)
        for e in entrees:
            t = QLabel(f"{e['version']} — {e.get('titre', '')}")
            t.setObjectName("Value")
            t.setWordWrap(True)
            cl.addWidget(t)
            cl.addWidget(_liste(e.get("points") or []))
        cl.addStretch(1)
        zone.setWidget(corps)
        lay.addWidget(zone, 1)

        essai = _texte("Vos retours decident des "
                       "prochaines ameliorations (bouton « Signaler un probleme »).",
                       "Faint")
        lay.addWidget(essai)
        row = QHBoxLayout()
        row.addStretch(1)
        ok = QPushButton("C'est parti")
        ok.setObjectName("Primary")
        ok.clicked.connect(self.accept)
        row.addWidget(ok)
        lay.addLayout(row)


# --------------------------------------------------------------------------
class DialogueBilan(QDialog):
    """Le bilan en une minute (2.0.2) : quatre phrases qui disent ce que
    vaut ORION sur ce PC. Un bouton par ligne ouvre la page qui va avec."""

    def __init__(self, bilan, parent=None, premiere_fois: bool = False) -> None:
        super().__init__(parent)
        self.page_demandee = ""
        lay = _base(self, "Votre PC, en une minute", 600)
        titre = QLabel("Votre PC, en une minute" if not premiere_fois
                       else f"Bienvenue dans {APP_NAME} : votre PC, en une minute")
        titre.setObjectName("PanelTitle")
        titre.setWordWrap(True)
        lay.addWidget(titre)
        if not bilan.complet:
            lay.addWidget(_texte("Certains elements se lisent encore en fond ; ce bilan "
                                 "se complete depuis la page Ma machine.", "Faint"))
        for ligne in bilan.lignes:
            bloc = QWidget()
            bl = QHBoxLayout(bloc)
            bl.setContentsMargins(0, 0, 0, 0)
            bl.setSpacing(12)
            textes = QVBoxLayout()
            textes.setSpacing(4)
            t = QLabel(_t(ligne.titre))
            t.setObjectName("Value")
            t.setWordWrap(True)
            textes.addWidget(t)
            if ligne.details:
                textes.addWidget(_texte(" ".join(_t(x) for x in ligne.details), "Faint"))
            bl.addLayout(textes, 1)
            if ligne.bouton and ligne.page:
                b = QPushButton(ligne.bouton)
                b.setObjectName("Ghost")
                b.clicked.connect(lambda _c=False, p=ligne.page: self._ouvrir(p))
                bl.addWidget(b, 0, Qt.AlignmentFlag.AlignTop)
            lay.addWidget(bloc)
        if premiere_fois:
            lay.addWidget(_texte("Rien n'est envoye sans votre accord : ORION travaille "
                                 "sur votre PC, sans compte ni publicite.", "Faint"))
        row = QHBoxLayout()
        self.b_partager = QPushButton("Partager en image")
        self.b_partager.setObjectName("Ghost")
        self.b_partager.setToolTip("Une image a poster (1200 x 630) : ce que votre PC fait tourner, "
                                   "la valeur de votre bibliotheque, processeur et carte graphique. "
                                   "Rien de personnel.")
        self.b_partager.clicked.connect(lambda: self._ouvrir("partager"))
        row.addWidget(self.b_partager)
        row.addStretch(1)
        ok = QPushButton("C'est parti" if premiere_fois else "Fermer")
        ok.setObjectName("Primary")
        ok.clicked.connect(self.accept)
        row.addWidget(ok)
        lay.addLayout(row)

    def _ouvrir(self, page: str) -> None:
        self.page_demandee = page
        self.accept()


# --------------------------------------------------------------------------
class DialogueNote(QDialog):
    """Une note sur le Microsoft Store ? Posee une fois, au cinquieme
    lancement d'une installation venue du Store (2.0.2)."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.oui = False
        lay = _base(self, "Une note pour ORION ?", 480)
        titre = QLabel(f"{APP_NAME} vous est utile ?")
        titre.setObjectName("PanelTitle")
        lay.addWidget(titre)
        lay.addWidget(_texte("Une note sur le Microsoft Store aide d'autres joueurs a le trouver. "
                             "Cette question ne reviendra pas, quelle que soit votre reponse."))
        row = QHBoxLayout()
        non = QPushButton("Non merci")
        non.setObjectName("Ghost")
        non.clicked.connect(self.reject)
        row.addWidget(non)
        row.addStretch(1)
        ok = QPushButton("Noter ORION")
        ok.setObjectName("Primary")
        ok.clicked.connect(self._oui)
        row.addWidget(ok)
        lay.addLayout(row)

    def _oui(self) -> None:
        self.oui = True
        self.accept()


# --------------------------------------------------------------------------
class DialogueAvis(QDialog):
    """Votre avis sur ORION : trois questions et un choix (2.1.2). Ouverte
    seulement par le lien « Donnez votre avis », sous l'encart de version."""

    ENVOYER, ANNULER = "envoyer", "annuler"

    def __init__(self, parent=None) -> None:
        from PySide6.QtWidgets import QButtonGroup
        from ... import avis
        super().__init__(parent)
        self.action = self.ANNULER
        lay = _base(self, "Votre avis sur ORION", 560)
        titre = QLabel("Deux minutes pour aider ORION ?")
        titre.setObjectName("PanelTitle")
        lay.addWidget(titre)
        lay.addWidget(_texte("Repondez aux questions que vous voulez, en quelques mots. "
                             "Chaque reponse est lue et peut changer la prochaine version. "
                             "Rien ne part sans le bouton Envoyer, et aucun rapport "
                             "technique n'est joint.", "Faint"))
        self.zones: dict[str, QPlainTextEdit] = {}
        for cle, question in avis.QUESTIONS:
            lay.addWidget(_texte(question, "Dim"))
            zone = QPlainTextEdit()
            zone.setMinimumHeight(64)
            zone.setMaximumHeight(110)
            self.zones[cle] = zone
            lay.addWidget(zone)
        lay.addWidget(_texte(avis.QUESTION_CHOIX, "Dim"))
        ligne = QHBoxLayout()
        ligne.setSpacing(8)
        self.groupe = QButtonGroup(self)
        self.groupe.setExclusive(True)
        self.choix_boutons: dict[str, QPushButton] = {}
        for c in avis.CHOIX:
            b = QPushButton(c)
            b.setCheckable(True)
            b.setObjectName("Ghost")
            self.groupe.addButton(b)
            self.choix_boutons[c] = b
            ligne.addWidget(b)
        ligne.addStretch(1)
        lay.addLayout(ligne)

        self.aide = _texte("", "Faint")
        self.aide.hide()
        lay.addWidget(self.aide)

        row = QHBoxLayout()
        row.setSpacing(10)
        envoyer = QPushButton("Envoyer")
        envoyer.setObjectName("Primary")
        envoyer.clicked.connect(self._envoyer)
        row.addWidget(envoyer)
        row.addStretch(1)
        annuler = QPushButton("Annuler")
        annuler.setObjectName("Ghost")
        annuler.clicked.connect(lambda: self._fin(self.ANNULER))
        row.addWidget(annuler)
        lay.addLayout(row)

    def valeurs(self) -> tuple[dict[str, str], str]:
        reponses = {cle: z.toPlainText().strip() for cle, z in self.zones.items()}
        choix = next((c for c, b in self.choix_boutons.items() if b.isChecked()), "")
        return reponses, choix

    def _envoyer(self) -> None:
        from ... import avis
        reponses, choix = self.valeurs()
        if avis.vide(reponses, choix):
            self.aide.setText("Ecrivez quelques mots, ou choisissez une reponse, avant d'envoyer.")
            self.aide.show()
            return
        self._fin(self.ENVOYER)

    def _fin(self, action: str) -> None:
        self.action = action
        if action == self.ENVOYER:
            self.accept()
        else:
            self.reject()


# --------------------------------------------------------------------------
class DialogueMiseAJour(QDialog):
    """Une nouvelle version est publiee : installer maintenant ou plus tard."""

    INSTALLER, PLUS_TARD, IGNORER = 1, 2, 3

    def __init__(self, pub, parent=None) -> None:
        super().__init__(parent)
        self.choix = self.PLUS_TARD
        lay = _base(self, "Mise a jour disponible")
        titre = QLabel(f"{APP_NAME} {pub.version} est disponible")
        titre.setObjectName("PanelTitle")
        lay.addWidget(titre)
        lay.addWidget(_texte(f"Vous utilisez la version {APP_VERSION}. "
                             "La mise a jour conserve votre bibliotheque, vos "
                             "reglages et vos sauvegardes."))
        if pub.points:
            lay.addWidget(_liste(pub.points[:8]))
        taille = f" ({pub.taille / (1024 * 1024):.0f} Mo)" if pub.taille else ""
        verif = ("Le fichier sera verifie (empreinte SHA-256) avant installation."
                 if pub.verifiable else
                 "Empreinte introuvable : l'installation automatique est "
                 "desactivee pour cette version, la page de telechargement "
                 "s'ouvrira a la place.")
        lay.addWidget(_texte(f"Telechargement{taille}. {verif} ORION se "
                             "fermera puis se relancera tout seul.", "Faint"))

        self.barre = QProgressBar()
        self.barre.setRange(0, 100)
        self.barre.hide()
        lay.addWidget(self.barre)
        self.etat = _texte("", "Faint")
        self.etat.hide()
        lay.addWidget(self.etat)

        row = QHBoxLayout()
        row.setSpacing(10)
        self.bouton = QPushButton("Installer maintenant" if pub.verifiable
                                  else "Ouvrir la page de telechargement")
        self.bouton.setObjectName("Primary")
        self.bouton.clicked.connect(lambda: self._fin(self.INSTALLER))
        row.addWidget(self.bouton)
        tard = QPushButton("Plus tard")
        tard.setObjectName("Ghost")
        tard.clicked.connect(lambda: self._fin(self.PLUS_TARD))
        row.addWidget(tard)
        notes = QPushButton("Notes de version")
        notes.setObjectName("Ghost")
        notes.clicked.connect(lambda: webbrowser.open(pub.page))
        row.addWidget(notes)
        row.addStretch(1)
        ignorer = QPushButton("Ignorer cette version")
        ignorer.setObjectName("Ghost")
        ignorer.clicked.connect(lambda: self._fin(self.IGNORER))
        row.addWidget(ignorer)
        lay.addLayout(row)

    def _fin(self, choix: int) -> None:
        self.choix = choix
        self.accept()


# --------------------------------------------------------------------------
class DialogueSignalement(QDialog):
    """Decrire le probleme ; le rapport anonymise est prepare a cote."""

    def __init__(self, parent=None, erreur: str = "", titre: str = "") -> None:
        super().__init__(parent)
        self.erreur = erreur
        lay = _base(self, "Signaler un probleme", 560)
        t = QLabel("Signaler un probleme")
        t.setObjectName("PanelTitle")
        lay.addWidget(t)
        if erreur:
            lay.addWidget(_texte(f"{APP_NAME} a rencontre une erreur imprevue. "
                                 "Elle a ete notee ; vous pouvez continuer a "
                                 "utiliser l'application."))
        lay.addWidget(_texte(
            "Dites en quelques mots ce qui ne va pas, puis cliquez sur Envoyer : "
            "c'est tout. ORION joint un rapport technique sans donnees "
            "personnelles (chemins, noms, cles et identifiants sont masques). "
            "Aucun compte n'est necessaire.", "Faint"))

        self.titre = QLineEdit()
        self.titre.setPlaceholderText("En une phrase (ex. : l'affiche de Cyberpunk est mal cadree)")
        if titre:
            self.titre.setText(titre)
        lay.addWidget(self.titre)

        self.description = QPlainTextEdit()
        self.description.setPlaceholderText(
            "Sur quelle page, avec quel jeu, ce que vous attendiez, ce qui s'est passe...")
        self.description.setMinimumHeight(120)
        lay.addWidget(self.description)

        self.joindre = QCheckBox("Joindre le rapport technique (recommande)")
        self.joindre.setChecked(True)
        lay.addWidget(self.joindre)

        row = QHBoxLayout()
        row.setSpacing(10)
        envoyer = QPushButton("Envoyer")
        envoyer.setObjectName("Primary")
        envoyer.clicked.connect(self._envoyer)
        row.addWidget(envoyer)
        voir = QPushButton("Voir le rapport")
        voir.setObjectName("Ghost")
        voir.clicked.connect(self._voir)
        row.addWidget(voir)
        row.addStretch(1)
        annuler = QPushButton("Annuler")
        annuler.setObjectName("Ghost")
        annuler.clicked.connect(self.reject)
        row.addWidget(annuler)
        lay.addLayout(row)
        self._rappel_rapport = None

    def _envoyer(self) -> None:
        """Il faut au moins quelques mots : un signalement vide n'aide personne."""
        if not self.erreur and not (self.titre.text().strip()
                                    or self.description.toPlainText().strip()):
            self.titre.setFocus()
            self.titre.setPlaceholderText("Ecrivez quelques mots avant d'envoyer")
            return
        self.accept()

    def valeurs(self) -> tuple[str, str, bool]:
        titre = self.titre.text().strip()
        description = self.description.toPlainText().strip()
        if not titre:
            titre = (description.splitlines()[0][:120] if description else
                     "Erreur imprevue" if self.erreur else "Probleme rencontre")
        return titre, description or titre, self.joindre.isChecked()

    def _voir(self) -> None:
        """Montre exactement ce qui serait joint, avant tout envoi."""
        if self._rappel_rapport is None:
            return
        texte = self._rappel_rapport(self.description.toPlainText().strip())
        apercu = QDialog(self)
        lay = _base(apercu, "Rapport technique", 720)
        zone = QPlainTextEdit(texte)
        zone.setReadOnly(True)
        zone.setMinimumHeight(420)
        lay.addWidget(zone)
        fermer = QPushButton("Fermer")
        fermer.setObjectName("Ghost")
        fermer.clicked.connect(apercu.accept)
        lay.addWidget(fermer, 0, Qt.AlignmentFlag.AlignRight)
        apercu.exec()


# --------------------------------------------------------------------------
class DialogueGuide(QDialog):
    """Les reglages a faire soi-meme dans le jeu, une ligne = une action.

    Affiche quand ORION ne peut rien ecrire dans le jeu. Chaque ligne se
    coche une fois faite ; la liste peut etre copiee (telephone, papier)."""

    def __init__(self, titre_jeu: str, lignes: list, parent=None,
                 avant_partie: bool = False) -> None:
        super().__init__(parent)
        from ...optimizer import guide
        self.jouer = False
        self._titre = titre_jeu
        self._lignes = list(lignes)
        self._cases: list[QCheckBox] = []
        lay = _base(self, "Reglages a faire dans le jeu", 600)
        t = QLabel("Reglages a faire dans le jeu, car ORION n'y a pas acces")
        t.setObjectName("PanelTitle")
        t.setWordWrap(True)
        lay.addWidget(t)
        if avant_partie:
            conseil = QLabel("Nous vous conseillons un tour dans les reglages "
                             "avant de commencer.")
            conseil.setObjectName("Value")
            conseil.setWordWrap(True)
            lay.addWidget(conseil)
        lay.addWidget(_texte(
            "Ce jeu garde ses reglages pour lui : ORION ne peut pas les changer "
            "a votre place. Voici quoi choisir, c'est l'affaire de deux minutes."))
        etapes = QLabel("<br>".join(
            f"<b>{i}.</b>&nbsp; {_t(e)}" for i, e in enumerate(guide.ETAPES_MENU, 1)))
        etapes.setWordWrap(True)
        etapes.setTextFormat(Qt.TextFormat.RichText)
        lay.addWidget(etapes)

        zone = QWidget()
        col = QVBoxLayout(zone)
        col.setContentsMargins(0, 0, 8, 0)
        col.setSpacing(10)
        self._ajouter(col, [l for l in self._lignes if l.essentiel])
        autres = [l for l in self._lignes if not l.essentiel]
        if autres:
            s = QLabel("Si vous les trouvez")
            s.setObjectName("Faint")
            col.addWidget(s)
            self._ajouter(col, autres)
        col.addStretch(1)
        defile = ZoneDefilante()
        defile.setWidgetResizable(True)
        defile.setFrameShape(QScrollArea.Shape.NoFrame)
        defile.setWidget(zone)
        defile.setMinimumHeight(300)
        lay.addWidget(defile, 1)

        self.avancement = _texte("", "Faint")
        lay.addWidget(self.avancement)
        row = QHBoxLayout()
        row.setSpacing(10)
        self.copier = QPushButton("Copier la liste")
        self.copier.setObjectName("Ghost")
        self.copier.clicked.connect(self._copier)
        row.addWidget(self.copier)
        row.addStretch(1)
        fermer = QPushButton("Fermer")
        fermer.setObjectName("Ghost")
        fermer.clicked.connect(self.reject)
        row.addWidget(fermer)
        lancer = QPushButton("Lancer le jeu")
        lancer.setObjectName("Primary")
        lancer.clicked.connect(self._lancer)
        row.addWidget(lancer)
        lay.addLayout(row)
        self._compter()

    def _ajouter(self, col: QVBoxLayout, lignes: list) -> None:
        for l in lignes:
            case = QCheckBox()
            case.setText(f"{_t(l.nom)} :  {_t(l.valeur)}")
            f = case.font()
            f.setPointSize(f.pointSize() + 2)
            f.setBold(True)
            case.setFont(f)
            case.toggled.connect(self._compter)
            self._cases.append(case)
            col.addWidget(case)
            if l.aide:
                aide = _texte(l.aide, "Faint")
                aide.setContentsMargins(28, 0, 0, 0)
                col.addWidget(aide)

    def _compter(self) -> None:
        faits = sum(c.isChecked() for c in self._cases)
        if faits == len(self._cases):
            self.avancement.setText("Tout est fait. Bon jeu !")
        else:
            self.avancement.setText(
                f"{faits} sur {len(self._cases)} faits. Cochez chaque ligne une fois reglee.")

    def _copier(self) -> None:
        from PySide6.QtWidgets import QApplication
        from ...optimizer import guide
        traduites = [guide.Ligne(_t(l.nom), _t(l.valeur)) for l in self._lignes]
        QApplication.clipboard().setText(guide.texte(self._titre, traduites))
        self.copier.setText("Liste copiee")

    def _lancer(self) -> None:
        self.jouer = True
        self.accept()


# --------------------------------------------------------------------------
class DialoguePartage(QDialog):
    """La question, posee une seule fois par version de son texte : partager
    ses mesures, et etre compte anonymement (`partage.QUESTION`) ?"""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.oui = False
        lay = _base(self, "Aider les autres joueurs", 540)
        t = QLabel("Aider les autres joueurs ?")
        t.setObjectName("PanelTitle")
        lay.addWidget(t)
        lay.addWidget(_texte(
            "Quand ORION mesure une de vos parties, il peut partager le "
            "resultat : « ce jeu tourne a 90 images par seconde avec cette "
            "carte graphique ». Les joueurs equipes comme vous recoivent alors "
            "des reglages bases sur du vrai, et vous aussi."))
        lay.addWidget(_liste([
            "Envoye : le jeu, le modele de carte graphique et de processeur, "
            "la definition de l'ecran, le niveau de reglages, les images par seconde.",
            "Envoye aussi, pour savoir si ORION sert : un compteur anonyme. "
            "Qu'ORION a ete ouvert (version, Microsoft Store ou installateur), "
            "quelles pages sont utilisees, et le nom de la boutique quand vous "
            "ouvrez une offre. Jamais le jeu concerne. Le service note aussi "
            "le pays et la region d'ou vient l'envoi, jamais la ville.",
            "Envoye aussi, a la fermeture, pour corriger les accrochages : un "
            "bilan de fluidite. Combien de fois l'affichage s'est fige, le nom "
            "de la fonction d'ORION en cause, le temps de demarrage et le "
            "nombre d'erreurs du journal. Jamais le jeu, jamais un chemin de "
            "fichier.",
            "Jamais envoye : votre nom, vos comptes, vos fichiers, votre adresse.",
            "Vous pouvez changer d'avis a tout moment dans Reglages.",
            "Si vous dites oui, ORION installe son outil de mesure (PresentMon, "
            "Intel, gratuit) et mesure vos parties.",
        ]))
        row = QHBoxLayout()
        row.setSpacing(10)
        row.addStretch(1)
        non = QPushButton("Non merci")
        non.setObjectName("Ghost")
        non.clicked.connect(self.reject)
        row.addWidget(non)
        oui = QPushButton("Oui, je partage")
        oui.setObjectName("Primary")
        oui.clicked.connect(self._oui)
        row.addWidget(oui)
        lay.addLayout(row)

    def _oui(self) -> None:
        self.oui = True
        self.accept()


def _t(texte: str) -> str:
    from ...i18n import t
    return t(texte)
