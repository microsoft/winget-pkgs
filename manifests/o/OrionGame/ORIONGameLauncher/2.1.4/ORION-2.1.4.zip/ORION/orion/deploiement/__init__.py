"""Mise en place d'ORION sur la machine : installation, raccourcis, retrait."""
