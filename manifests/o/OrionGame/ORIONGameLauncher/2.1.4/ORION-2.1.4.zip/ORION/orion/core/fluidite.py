"""Mesure des accrochages de l'interface (2.0).

Une interface « accroche » quand le fil d'affichage reste occupe : pendant ce
temps la fenetre ne se redessine pas, la molette et la souris ne repondent
pas. Aucune impression ne remplace une mesure : cette vigie note chaque arret
du fil d'affichage, sa duree, et CE QUE FAISAIT ORION a ce moment-la.

Principe : un minuteur bat dans le fil d'affichage ; un fil de fond regarde
l'heure du dernier battement. S'il tarde, le fil de fond photographie la pile
d'appels du fil d'affichage (`sys._current_frames`). Quand le battement
revient, l'arret est ecrit au journal :

    Affichage fige 430 ms : boutique_view._rendre:2046 < main_window._boutique_actualisee:1590

Cout : un minuteur toutes les 100 ms et un fil qui dort. Rien n'est ecrit
tant que l'interface reste fluide. Se coupe avec `diagnostic.fluidite`.

Ne comptent pas (2.1.2, journaux des 10 et 11 octobre : la moitie du temps
« fige » n'en etait pas) :

* un arret quand ORION n'est pas devant (un jeu ou une autre application au
  premier plan) : Windows ralentit les programmes en arriere-plan et le
  joueur regarde ailleurs ; 30 arrets sur 98, 21 s sur 51 ;
* le temps passe dans une fenetre de Windows (choisir un fichier, un
  dossier) : son ouverture et l'attente du joueur ne sont pas un defaut
  d'ORION ; 13 arrets, 6,5 s, mis jusque-la sur le dos de la traduction.

Ils sont comptes a part (`ecartes`), jamais envoyes comme accrochages.
"""
from __future__ import annotations

import contextlib
import re
import sys
import threading
import time

from PySide6.QtCore import QObject, QTimer

from .logging_setup import get

log = get("fluidite")

#: battement du fil d'affichage, en secondes
PERIODE = 0.1
#: arret a partir duquel on photographie la pile, puis on l'ecrit
SEUIL = 0.2
#: lignes ecrites au plus par session (un defaut repete ne remplit pas le journal)
MAX_LIGNES = 300
#: photos de la pile gardees par arret
MAX_PHOTOS = 60


def _au_premier_plan() -> bool:
    """ORION est-il l'application devant le joueur ?"""
    from PySide6.QtCore import Qt
    from PySide6.QtGui import QGuiApplication
    return QGuiApplication.applicationState() == Qt.ApplicationState.ApplicationActive


def _pile(cadre, profondeur: int = 7) -> str:
    """Les appels d'ORION en cours, du plus profond au plus ancien :
    « module.fonction:ligne < module.fonction:ligne »."""
    morceaux: list[str] = []
    dehors = ""
    while cadre is not None and len(morceaux) < profondeur:
        fichier = cadre.f_code.co_filename.replace("\\", "/")
        nom = cadre.f_code.co_name
        if "/orion/" in fichier or fichier.startswith("orion/"):
            module = fichier.rsplit("/", 1)[-1].removesuffix(".py")
            if module != "fluidite":
                morceaux.append(f"{module}.{nom}:{cadre.f_lineno}")
        elif not morceaux and not dehors:
            # hors d'ORION (Qt, bibliotheque standard) : ce qui tourne vraiment
            dehors = f"{fichier.rsplit('/', 1)[-1]}:{nom}"
        cadre = cadre.f_back
    if dehors:
        morceaux.insert(0, f"[{dehors}]")
    return " < ".join(morceaux) or "(hors d'ORION)"


def resumer(photos: list[str], combien: int = 3) -> str:
    """Les travaux qui ont occupe l'arret, du plus long au plus court :
    « 70 % library_view.refresh:342 < ... | 30 % free_view.set_items:417 < ... ».
    Deux photos comptent pour le meme travail si elles partagent leurs deux
    appels les plus anciens (le point d'entree), quelle que soit la ligne en
    cours tout au fond."""
    if not photos:
        return "(pile indisponible)"
    groupes: dict[str, list[str]] = {}
    for pile in photos:
        appels = [a for a in pile.split(" < ") if not a.startswith("[")]
        entree = " < ".join(a.rsplit(":", 1)[0] for a in appels[-2:]) or pile
        groupes.setdefault(entree, []).append(pile)
    tries = sorted(groupes.values(), key=len, reverse=True)[:combien]
    if len(tries) == 1 and len(photos) <= 2:
        return tries[0][0]
    return " | ".join(f"{round(100 * len(g) / len(photos))} % {g[len(g) // 2]}" for g in tries)


class Vigie(QObject):
    """Note les arrets du fil d'affichage. Une seule par application."""

    def __init__(self, parent=None, periode: float = PERIODE, seuil: float = SEUIL,
                 horloge=time.perf_counter, premier_plan=_au_premier_plan) -> None:
        super().__init__(parent)
        self.periode, self.seuil, self._horloge = periode, seuil, horloge
        self._premier_plan = premier_plan
        self._devant = True                     # ORION devant au dernier battement
        self._systeme = 0                       # fenetres de Windows ouvertes
        self._systeme_vu = False                # ... pendant l'arret en cours
        self.ecartes = 0                        # arrets non comptes (voir en tete)
        self._fil_affichage = threading.get_ident()
        self._battement = horloge()
        self._photos: list[str] = []            # piles prises pendant l'arret en cours
        self._stop = threading.Event()
        self.arrets: list[tuple[float, str]] = []   # (duree en s, pile)
        self._ecrites = 0
        self._minuteur = QTimer(self)
        self._minuteur.setInterval(int(periode * 1000))
        self._minuteur.timeout.connect(self._battre)
        self._garde: threading.Thread | None = None

    # -- fil d'affichage ---------------------------------------------------
    def demarrer(self) -> None:
        self._battement = self._horloge()
        self._devant = self._devant_maintenant()
        self._minuteur.start()
        if self._garde is None:
            self._garde = threading.Thread(target=self._veiller, name="orion-fluidite",
                                           daemon=True)
            self._garde.start()

    def arreter(self) -> None:
        self._stop.set()
        self._minuteur.stop()

    def _devant_maintenant(self) -> bool:
        try:
            return bool(self._premier_plan())
        except Exception:
            return True

    def _battre(self) -> None:
        maintenant = self._horloge()
        retard = maintenant - self._battement - self.periode
        photos, self._photos = self._photos, []
        systeme, self._systeme_vu = self._systeme_vu or self._systeme > 0, False
        devant, self._devant = self._devant, self._devant_maintenant()
        self._battement = maintenant
        if retard < self.seuil or not (photos or systeme):
            return
        if systeme or not devant:
            # derriere un jeu, ou dans une fenetre de Windows : pas un accrochage
            self.ecartes += 1
            return
        self.noter(retard, resumer(photos))

    def noter(self, duree: float, pile: str) -> None:
        self.arrets.append((duree, pile))
        if self._ecrites < MAX_LIGNES:
            self._ecrites += 1
            log.warning("Affichage fige %d ms : %s", round(duree * 1000), pile)

    # -- fil de fond -------------------------------------------------------
    def _veiller(self) -> None:
        while not self._stop.wait(self.periode / 2):
            if self._horloge() - self._battement - self.periode < self.seuil:
                continue
            if self._systeme > 0:
                self._systeme_vu = True         # une fenetre de Windows : rien a photographier
                continue
            # arret en cours : une photo de la pile a chaque passage (un long
            # arret enchaine souvent plusieurs travaux, il faut les voir tous)
            if len(self._photos) < MAX_PHOTOS:
                cadre = sys._current_frames().get(self._fil_affichage)
                self._photos.append(_pile(cadre) if cadre is not None
                                    else "(pile indisponible)")

    # -- bilan ---------------------------------------------------------------
    def bilan(self) -> str:
        a_part = (f" ; {self.ecartes} arret(s) non compte(s) (ORION derriere un jeu ou "
                  "une autre application, ou fenetre de Windows)") if self.ecartes else ""
        if not self.arrets:
            return "aucun accrochage" + a_part
        total = sum(d for d, _ in self.arrets)
        pire = max(self.arrets)
        return (f"{len(self.arrets)} accrochage(s), {total:.1f} s en tout, "
                f"le plus long {round(pire[0] * 1000)} ms ({pire[1].split(' < ')[0][:60]})" + a_part)


_vigie: Vigie | None = None
#: duree du demarrage (de l'entree dans `app.main` a la fenetre affichee), en ms
demarrage_ms: int | None = None
#: causes gardees dans le bilan envoye (les plus frequentes)
CAUSES_ENVOYEES = 5


def noter_demarrage(ms: float) -> None:
    global demarrage_ms
    demarrage_ms = max(0, int(round(ms)))


def cause(pile: str) -> str:
    """La cause d'un arret telle qu'elle est partagee : la fonction d'ORION la
    plus profonde et le point d'entree, sans numero de ligne, sans ce qui est
    hors d'ORION. « boutique_view._rendre < main_window._boutique_actualisee »."""
    appels = [a.rsplit(":", 1)[0] for a in pile.split(" < ") if a and not a.startswith(("[", "("))]
    # une fonction d'ORION : « module.fonction », rien d'autre
    appels = [a for a in appels if re.fullmatch(r"[a-z0-9_]+\.[A-Za-z0-9_<>]+", a)]
    if not appels:
        return ""
    if len(appels) == 1 or appels[0] == appels[-1]:
        return appels[0]
    return f"{appels[0]} < {appels[-1]}"


def bilan_envoi() -> dict | None:
    """Le bilan anonyme de la session, pour le compteur (`compteur.fermer`) :
    nombre d'arrets, temps fige, demarrage, erreurs du journal, et les causes
    les plus frequentes. Rien d'autre que des nombres et des noms de fonctions
    d'ORION. None si la vigie n'a pas tourne."""
    if _vigie is None:
        return None
    from .logging_setup import nb_erreurs
    groupes: dict[str, list[float]] = {}
    for duree, pile in _vigie.arrets:
        c = cause(pile)
        if c:
            groupes.setdefault(c, []).append(duree)
    causes = sorted(groupes.items(), key=lambda kv: (-len(kv[1]), -sum(kv[1])))[:CAUSES_ENVOYEES]
    return {
        "arrets": len(_vigie.arrets),
        "duree_ms": int(round(sum(d for d, _ in _vigie.arrets) * 1000)),
        "demarrage_ms": demarrage_ms,
        "erreurs": nb_erreurs(),
        "causes": [{"pile": c, "n": len(d), "ms": int(round(sum(d) * 1000))} for c, d in causes],
    }


@contextlib.contextmanager
def fenetre_systeme():
    """Le temps passe ici (une fenetre de Windows) n'est pas un accrochage."""
    v = _vigie
    if v is None:
        yield
        return
    v._systeme += 1
    v._systeme_vu = True
    try:
        yield
    finally:
        v._systeme -= 1


#: les fenetres de Windows qu'ORION ouvre (choix d'un fichier, d'un dossier)
FENETRES_SYSTEME = ("getOpenFileName", "getOpenFileNames", "getSaveFileName", "getExistingDirectory")


def _enrober_fenetres_systeme() -> None:
    from PySide6.QtWidgets import QFileDialog
    for nom in FENETRES_SYSTEME:
        origine = getattr(QFileDialog, nom, None)
        if origine is None or getattr(origine, "_fenetre_systeme", False):
            continue

        def fonction(*args, _origine=origine, **kwargs):
            with fenetre_systeme():
                return _origine(*args, **kwargs)
        fonction._fenetre_systeme = True
        setattr(QFileDialog, nom, staticmethod(fonction))


def installer(app) -> Vigie | None:
    """Demarre la vigie pour cette application (une seule fois)."""
    global _vigie
    if _vigie is None:
        _vigie = Vigie(app)
        _vigie.demarrer()
        _enrober_fenetres_systeme()
        app.aboutToQuit.connect(_fermer)
    return _vigie


def _fermer() -> None:
    if _vigie is not None:
        _vigie.arreter()
        log.info("Fluidite de la session : %s", _vigie.bilan())


def vigie() -> Vigie | None:
    return _vigie
