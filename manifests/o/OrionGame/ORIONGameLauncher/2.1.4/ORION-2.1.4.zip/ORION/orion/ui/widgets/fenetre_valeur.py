"""Valeur estimee de ma bibliotheque (2.1.1) : la fenetre ouverte depuis
l'en-tete de la bibliotheque.

A gauche, le total, ce qu'il veut dire (prix actuels hors promotion, a titre
indicatif) et la liste des jeux comptes, du plus cher au moins cher, avec la
boutique d'ou vient chaque prix. A droite, la carte de joueur a enregistrer
(1200 x 630, `orion.ui.carte_joueur`) : un pseudo et une photo de profil
facultatifs, gardes sur ce PC, le total et les trois jeux les plus chers.
L'apercu suit chaque changement ; rien n'est envoye.
"""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QStandardPaths, Qt
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (QDialog, QFileDialog, QFrame, QHBoxLayout, QLabel, QLineEdit,
                               QPushButton, QVBoxLayout, QWidget)

from ...core import region
from ...core.config import CONFIG
from ...i18n import t as _t
from .. import carte_joueur
from ..defilement import ZoneDefilante
from ..minuteur import plus_tard
from ...steam_famille import avec_mention
from ..theme import GLASS, PALETTE, build_qss

#: d'ou vient le prix d'un jeu (valeur_catalogue.estimer, champ « origine »)
ORIGINES = {"steam": "Steam", "boutique": "Boutique", "releve": "Fiche du jeu"}
#: jeux montres un par un (au-dela : une ligne de resume)
AFFICHES = 400
#: lignes posees a l'ouverture ; les suivantes arrivent par paquets, sans
#: figer l'affichage (400 lignes d'un coup : plus d'une seconde, 2.1.1)
PREMIERES = 30
PAQUET = 30
APERCU = (480, 252)


def montant(valeur, somme: float, decimales: bool = True) -> str:
    return region.prix(somme, valeur.devise, decimales=decimales)


def payants(valeur) -> list[dict]:
    return [j for j in (valeur.liste or []) if float(j.get("normal") or 0) > 0]


def image_carte(valeur, pseudo: str = "", photo: str = ""):
    """La carte de joueur de cette valeur (QImage 1200 x 630)."""
    pastilles = [_t(f"{valeur.estimes} jeux comptes")]
    if valeur.gratuits:
        pastilles.append(_t(f"{valeur.gratuits} gratuits"))
    if valeur.actuel and valeur.actuel < valeur.total - 1:
        pastilles.append(_t(f"{montant(valeur, valeur.actuel, False)} avec les promos"))
    # (2.1.2) un jeu prete par la famille Steam le dit sur la carte
    meilleurs = [(avec_mention(carte_joueur.titre_propre(j["titre"]), bool(j.get("famille"))),
                  montant(valeur, float(j["normal"])))
                 for j in payants(valeur)[:3]]
    return carte_joueur.dessiner(
        _t("Ma bibliotheque vaut"), montant(valeur, valeur.total, False), pastilles, meilleurs,
        pseudo=pseudo, photo=carte_joueur.photo_carree(photo), eyebrow=_t("Carte de joueur"),
        pied=_t("orion-launcher.com · gratuit, sans compte, sans publicite"))


class LigneJeu(QFrame):
    """Un jeu compte : rang, titre, boutique du prix, barre relative, prix."""

    def __init__(self, rang: int, jeu: dict, valeur, plus_cher: float) -> None:
        super().__init__()
        self.setObjectName("LigneValeur")
        lay = QHBoxLayout(self)
        lay.setContentsMargins(12, 7, 12, 7)
        lay.setSpacing(12)
        r = QLabel(str(rang))
        r.setFixedWidth(30)
        r.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        r.setObjectName("ValeurRang")
        lay.addWidget(r)
        textes = QVBoxLayout()
        textes.setSpacing(1)
        titre = QLabel(avec_mention(carte_joueur.titre_propre(jeu.get("titre") or ""), bool(jeu.get("famille"))))
        titre.setObjectName("ValeurTitre")
        textes.addWidget(titre)
        source = QLabel(ORIGINES.get(jeu.get("origine") or "", "Boutique"))
        source.setObjectName("ValeurSource")
        textes.addWidget(source)
        lay.addLayout(textes, 1)
        normal = float(jeu.get("normal") or 0)
        barre = QFrame()
        barre.setFixedHeight(6)
        barre.setFixedWidth(max(4, int(110 * normal / plus_cher)) if plus_cher > 0 else 4)
        barre.setObjectName("ValeurBarre")
        lay.addWidget(barre, 0, Qt.AlignmentFlag.AlignVCenter)
        prix = QLabel(montant(valeur, normal) if normal > 0 else "Gratuit")
        prix.setMinimumWidth(86)
        prix.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        prix.setObjectName("ValeurPrix")
        lay.addWidget(prix)
        actuel = float(jeu.get("actuel") or 0)
        if normal > 0 and actuel < normal - 0.009:
            self.setToolTip(f"En promotion en ce moment : {montant(valeur, actuel)}")


class FenetreValeur(QDialog):
    def __init__(self, valeur, parent=None) -> None:
        super().__init__(parent)
        self.valeur = valeur
        self.photo = str(CONFIG.get("carte.photo", "") or "")
        if self.photo and not Path(self.photo).is_file():
            self.photo = ""
        self.setWindowTitle("Valeur estimee de ma bibliotheque")
        # 400 lignes de 5 elements : une regle par nom, jamais une feuille par
        # element ni la feuille entiere d'ORION une seconde fois (elle vient
        # deja de la fenetre principale). Avant la 2.1.2 : 1,1 a 1,4 s a
        # l'ouverture, interface figee.
        self.setStyleSheet((build_qss() if parent is None else "") + (
            f"QFrame#LigneValeur{{background:{GLASS['glass_flat']};border:1px solid {PALETTE['border']};"
            "border-radius:10px;}"
            f"QLabel#ValeurRang{{color:{PALETTE['text_faint']};font-size:12px;}}"
            f"QLabel#ValeurTitre{{color:{PALETTE['text']};font-size:13px;font-weight:600;}}"
            f"QLabel#ValeurSource{{color:{PALETTE['text_faint']};font-size:11px;}}"
            f"QFrame#ValeurBarre{{background:{PALETTE['accent']};border-radius:3px;}}"
            f"QLabel#ValeurPrix{{color:{PALETTE['text']};font-size:13px;font-weight:700;}}"
            f"QFrame#LigneValeur:hover{{border-color:{PALETTE['border_hi']};}}"
            f"QFrame#ColonneCarte{{background:{GLASS['glass_flat']};border:1px solid {PALETTE['border']};"
            "border-radius:16px;}"))
        self.setMinimumSize(1120, 680)
        racine = QHBoxLayout(self)
        racine.setContentsMargins(28, 24, 28, 22)
        racine.setSpacing(22)
        racine.addLayout(self._colonne_liste(valeur), 1)
        racine.addWidget(self._colonne_carte(), 0)
        self.actualiser()

    # -- a gauche : le total et les jeux comptes ---------------------------
    def _colonne_liste(self, valeur) -> QVBoxLayout:
        lay = QVBoxLayout()
        lay.setSpacing(10)
        haut = QLabel("VALEUR ESTIMEE DE MA BIBLIOTHEQUE")
        haut.setStyleSheet(f"color:{PALETTE['accent']}; font-size:11px; font-weight:700; letter-spacing:2px;")
        lay.addWidget(haut)
        total = QLabel(montant(valeur, valeur.total, False))
        total.setObjectName("ValeurTotal")
        total.setStyleSheet(f"color:{PALETTE['text']}; font-size:40px; font-weight:800;")
        lay.addWidget(total)
        sous = [f"Prix actuels hors promotion, {valeur.estimes} jeux sur {valeur.jeux} estimes."]
        if valeur.actuel and abs(valeur.actuel - valeur.total) >= 1:
            sous.append(f"Aux prix du moment (promotions comprises) : {montant(valeur, valeur.actuel, False)}.")
        if valeur.partiel:
            sous.append("Steam n'a pas repondu pour tous les jeux : l'estimation sera completee plus tard.")
        for s in sous:
            l = QLabel(s)
            l.setObjectName("Dim")
            l.setWordWrap(True)
            lay.addWidget(l)
        entete = QLabel("Jeux comptes, du plus cher au moins cher")
        entete.setObjectName("Value")
        entete.setContentsMargins(0, 10, 0, 2)
        lay.addWidget(entete)
        zone = ZoneDefilante()
        zone.setWidgetResizable(True)
        zone.setFrameShape(QFrame.Shape.NoFrame)
        corps = QWidget()
        cl = QVBoxLayout(corps)
        cl.setContentsMargins(0, 0, 8, 0)
        cl.setSpacing(6)
        jeux = list(valeur.liste or [])
        liste = payants(valeur)
        plus_cher = max((float(j["normal"]) for j in liste), default=0.0)
        self._liste_lay, self._plus_cher, self._posees = cl, plus_cher, 0
        self._a_poser = list(enumerate(liste[:AFFICHES], 1))
        self._poser(PREMIERES)
        if not jeux:
            vide = QLabel("La liste des jeux comptes apparaitra au prochain calcul de la valeur "
                          "(au demarrage, ou en relancant l'analyse de la bibliotheque).")
            vide.setObjectName("Faint")
            vide.setWordWrap(True)
            cl.addWidget(vide)
        restants = len(liste) - AFFICHES
        if restants > 0:
            cl.addWidget(self._petit(f"Et {restants} autres jeux."))
        if valeur.gratuits:
            cl.addWidget(self._petit(f"{valeur.gratuits} jeux gratuits, comptes 0."))
        manquants = valeur.jeux - valeur.estimes
        if manquants > 0:
            cl.addWidget(self._petit(f"{manquants} jeux sans prix connu ne sont pas comptes (hors Steam, "
                                     "retires de la vente, ajoutes a la main)."))
        cl.addStretch(1)
        if self._a_poser:
            plus_tard(self, 0, self._poser_suite)
        zone.setWidget(corps)
        lay.addWidget(zone, 1)
        note = QLabel("A titre indicatif : somme des prix affiches aujourd'hui par les boutiques, hors "
                      "promotion. Ce n'est ni ce que vous avez paye, ni une valeur de revente.")
        note.setObjectName("Faint")
        note.setWordWrap(True)
        lay.addWidget(note)
        return lay

    def _poser(self, combien: int) -> None:
        """Les lignes suivantes, a leur place (avant les notes du bas)."""
        paquet, self._a_poser = self._a_poser[:combien], self._a_poser[combien:]
        for rang, jeu in paquet:
            self._liste_lay.insertWidget(self._posees, LigneJeu(rang, jeu, self.valeur, self._plus_cher))
            self._posees += 1

    def _poser_suite(self) -> None:
        self._poser(PAQUET)
        if self._a_poser:
            plus_tard(self, 0, self._poser_suite)

    # -- a droite : la carte de joueur -------------------------------------
    def _colonne_carte(self) -> QFrame:
        cadre = QFrame()
        cadre.setObjectName("ColonneCarte")
        cadre.setFixedWidth(APERCU[0] + 40)
        lay = QVBoxLayout(cadre)
        lay.setContentsMargins(20, 18, 20, 18)
        lay.setSpacing(10)
        titre = QLabel("Ma carte de joueur")
        titre.setObjectName("PanelTitle")
        lay.addWidget(titre)
        self.apercu = QLabel()
        self.apercu.setFixedSize(*APERCU)
        self.apercu.setStyleSheet("border-radius:12px;")
        lay.addWidget(self.apercu)
        lp = QLabel("Pseudo (facultatif)")
        lp.setObjectName("Dim")
        lay.addWidget(lp)
        self.pseudo = QLineEdit(str(CONFIG.get("carte.pseudo", "") or ""))
        self.pseudo.setMaxLength(carte_joueur.PSEUDO_MAX)
        self.pseudo.setPlaceholderText("Votre pseudo de joueur")
        self.pseudo.textChanged.connect(self._pseudo_change)
        lay.addWidget(self.pseudo)
        rangee = QHBoxLayout()
        self.b_photo = QPushButton("Choisir une photo de profil")
        self.b_photo.setObjectName("Ghost")
        self.b_photo.clicked.connect(self.choisir_photo)
        rangee.addWidget(self.b_photo)
        self.b_retirer = QPushButton("Retirer la photo")
        self.b_retirer.setObjectName("Ghost")
        self.b_retirer.clicked.connect(lambda: self.poser_photo(""))
        rangee.addWidget(self.b_retirer)
        rangee.addStretch(1)
        lay.addLayout(rangee)
        prive = QLabel("Le pseudo et la photo restent sur ce PC : ils ne sont ecrits que sur l'image.")
        prive.setObjectName("Faint")
        prive.setWordWrap(True)
        lay.addWidget(prive)
        lay.addStretch(1)
        self.etat = QLabel("")
        self.etat.setObjectName("Faint")
        self.etat.setWordWrap(True)
        self.etat.setVisible(False)
        lay.addWidget(self.etat)
        bas = QHBoxLayout()
        self.b_carte = QPushButton("Enregistrer l'image")
        self.b_carte.setObjectName("Primary")
        self.b_carte.setToolTip("Une image PNG de 1200 x 630 a poster : votre carte de joueur, le total "
                                "et vos trois jeux les plus chers.")
        self.b_carte.setEnabled(self.valeur.connue)
        self.b_carte.clicked.connect(lambda: self.enregistrer_carte())
        bas.addWidget(self.b_carte)
        bas.addStretch(1)
        fermer = QPushButton("Fermer")
        fermer.setObjectName("Ghost")
        fermer.clicked.connect(self.accept)
        bas.addWidget(fermer)
        lay.addLayout(bas)
        return cadre

    @staticmethod
    def _petit(texte: str) -> QLabel:
        l = QLabel(texte)
        l.setObjectName("Faint")
        l.setWordWrap(True)
        l.setContentsMargins(12, 4, 12, 0)
        return l

    def _pseudo_change(self, texte: str) -> None:
        CONFIG.set("carte.pseudo", texte.strip())
        self.actualiser()

    def choisir_photo(self) -> None:
        dossier = (QStandardPaths.writableLocation(QStandardPaths.StandardLocation.PicturesLocation)
                   or str(Path.home()))
        chemin, _f = QFileDialog.getOpenFileName(self, "Choisir une photo de profil", dossier,
                                                 "Images (*.png *.jpg *.jpeg *.webp *.bmp)")
        if chemin:
            self.poser_photo(chemin)

    def poser_photo(self, chemin: str) -> None:
        if chemin and carte_joueur.photo_carree(chemin) is None:
            self.etat.setText("Cette image ne se lit pas : choisissez un fichier PNG ou JPG.")
            self.etat.setVisible(True)
            return
        self.photo = chemin
        CONFIG.set("carte.photo", chemin)
        self.actualiser()

    def image(self):
        return image_carte(self.valeur, self.pseudo.text(), self.photo)

    def actualiser(self) -> None:
        self.b_retirer.setVisible(bool(self.photo))
        pm = QPixmap.fromImage(self.image()).scaled(
            APERCU[0], APERCU[1], Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
        self.apercu.setPixmap(pm)

    def enregistrer_carte(self, chemin: str | None = None) -> bool:
        """Propose ou enregistrer l'image (PNG). `chemin` : sans fenetre de
        choix (essais)."""
        if chemin is None:
            images = (QStandardPaths.writableLocation(QStandardPaths.StandardLocation.PicturesLocation)
                      or str(Path.home()))
            chemin, _f = QFileDialog.getSaveFileName(
                self, "Enregistrer ma carte de joueur",
                str(Path(images) / "ORION-ma-carte-de-joueur.png"), "Image PNG (*.png)")
        if not chemin:
            return False
        if not chemin.lower().endswith(".png"):
            chemin += ".png"
        ok = carte_joueur.enregistrer(self.image(), chemin)
        self.etat.setText(f"Image enregistree : {chemin}" if ok
                          else "L'image n'a pas pu etre enregistree a cet endroit : choisissez un autre dossier.")
        self.etat.setVisible(True)
        return ok
