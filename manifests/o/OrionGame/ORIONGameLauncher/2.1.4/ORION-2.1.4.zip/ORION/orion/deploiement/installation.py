"""Installation, raccourcis et desinstallation sous Windows.

Tout se fait dans l'espace de l'utilisateur : `%LOCALAPPDATA%\\Programs\\ORION`
pour le programme, `%LOCALAPPDATA%\\ORION` pour ses donnees. Aucune elevation
n'est demandee, rien n'est ecrit dans `Program Files` ni dans HKEY_LOCAL_MACHINE,
et la desinstallation n'a donc rien a nettoyer ailleurs.

Les raccourcis sont crees par le shell Windows lui-meme (WScript.Shell), ce
qui evite d'ajouter une dependance juste pour ecrire un fichier `.lnk`.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

from ..core.logging_setup import get
from ..core.paths import DATA_DIR, is_windows
from ..version import APP_NAME, APP_VERSION

log = get("installation")

#: cle de desinstallation, visible dans « Applications installees »
UNINSTALL_KEY = (r"Software\Microsoft\Windows\CurrentVersion\Uninstall"
                 f"\\{APP_NAME}")

#: nom de l'executable une fois installe
EXE_NAME = f"{APP_NAME}.exe"


#: fichier depose dans le dossier d'installation : il signe « ceci est ORION »
MARQUEUR = ".orion-installation"


def default_target() -> Path:
    """Dossier d'installation propose par defaut."""
    base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
    return Path(base) / "Programs" / APP_NAME


def _dossier_shell(nom: str) -> Path | None:
    """Emplacement reel d'un dossier de l'utilisateur (Bureau redirige vers
    OneDrive, deplace sur un autre disque...), lu la ou Windows le range."""
    if not is_windows():
        return None
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                            r"Software\Microsoft\Windows\CurrentVersion"
                            r"\Explorer\User Shell Folders") as key:
            valeur, _ = winreg.QueryValueEx(key, nom)
        texte = os.path.expandvars(str(valeur)).strip()
        return Path(texte) if texte else None
    except Exception:
        return None


def desktop_dir() -> Path:
    reel = _dossier_shell("Desktop")
    if reel is not None and reel.is_dir():
        return reel
    for name in ("Desktop", "Bureau"):
        candidate = Path.home() / name
        if candidate.is_dir():
            return candidate
    return Path.home() / "Desktop"


def start_menu_dir() -> Path:
    reel = _dossier_shell("Programs")
    if reel is not None and reel.is_dir():
        return reel
    base = os.environ.get("APPDATA") or str(Path.home() / "AppData" / "Roaming")
    return Path(base) / "Microsoft" / "Windows" / "Start Menu" / "Programs"


def emplacement_declare() -> Path | None:
    """Dossier d'installation declare a Windows (« Applications installees »)."""
    if not is_windows():
        return None
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, UNINSTALL_KEY) as key:
            valeur, _ = winreg.QueryValueEx(key, "InstallLocation")
        texte = str(valeur).strip()
        return Path(texte) if texte else None
    except Exception:
        return None


def dossier_installe() -> Path:
    """Dossier ou ORION est reellement installe.

    Dans l'ordre : le dossier du programme en cours s'il s'agit d'ORION.exe
    (desinstallation lancee par Windows), l'emplacement declare dans le
    registre (l'utilisateur a pu choisir un autre dossier que celui par
    defaut), sinon le dossier par defaut."""
    exe = Path(sys.executable)
    if getattr(sys, "frozen", False) and exe.name.lower() == EXE_NAME.lower():
        return exe.parent
    declare = emplacement_declare()
    if declare is not None and (declare / EXE_NAME).exists():
        return declare
    return default_target()


def installed_exe() -> Path:
    return dossier_installe() / EXE_NAME


def is_installed() -> bool:
    return installed_exe().exists()


def est_installation_orion(dossier: Path) -> bool:
    """Peut-on remplacer ce dossier sans detruire autre chose qu'ORION ?

    Oui s'il n'existe pas ou est vide, s'il porte la marque d'ORION ou
    contient ORION.exe, ou s'il s'agit d'un reste d'ORION a moitie retire
    (dossier « ORION » ne contenant que `_internal`). Jamais un dossier
    quelconque de l'utilisateur : le remplacement le supprimerait en entier."""
    dossier = Path(dossier)
    if not dossier.exists():
        return True
    if not dossier.is_dir():
        return False
    try:
        contenu = list(dossier.iterdir())
    except OSError:
        return False
    if not contenu:
        return True
    if (dossier / MARQUEUR).exists() or (dossier / EXE_NAME).exists():
        return True
    noms = {p.name.lower() for p in contenu}
    return (dossier.name.lower() == APP_NAME.lower()
            and noms <= {"_internal", MARQUEUR.lower(), EXE_NAME.lower()})


# --------------------------------------------------------------------------
# Raccourcis
# --------------------------------------------------------------------------

def _powershell(script: str) -> bool:
    if not is_windows():
        log.info("Raccourci simulé : %s", script.splitlines()[0][:60])
        return True
    try:
        from ..core.lancement import contexte_propre, dossier_neutre, environnement_propre
        creation = 0x08000000        # CREATE_NO_WINDOW : pas de fenetre noire
        with contexte_propre():
            done = subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive",
                 "-ExecutionPolicy", "Bypass", "-Command", script],
                capture_output=True, text=True, timeout=30, creationflags=creation,
                cwd=dossier_neutre(), env=environnement_propre())
        if done.returncode != 0:
            log.warning("PowerShell a échoué : %s", (done.stderr or "").strip()[:200])
        return done.returncode == 0
    except Exception:
        log.exception("Création de raccourci impossible")
        return False


def _ps(texte) -> str:
    """Chaine PowerShell entre apostrophes : une apostrophe s'y double
    (« C:\\Users\\D'Angelo », « Jeux d'action »)."""
    return "'" + str(texte).replace("'", "''") + "'"


def make_shortcut(link: Path, target: Path, icon: Path | None = None,
                  arguments: str = "", description: str = "") -> bool:
    """Cree un raccourci Windows (.lnk). Ne leve jamais : un raccourci
    manquant ne doit pas faire echouer une installation deja en place."""
    try:
        link.parent.mkdir(parents=True, exist_ok=True)
    except OSError:
        log.warning("Dossier du raccourci inaccessible : %s", link.parent)
        return False
    icon_path = str(icon or target)
    # le dossier de travail du raccourci n'est pas celui d'ORION : un dossier
    # courant ne peut pas etre renomme par Windows, ce qui bloquait la mise
    # a jour tant qu'un programme lance par ORION l'avait herite
    script = (
        "$w = New-Object -ComObject WScript.Shell; "
        f"$s = $w.CreateShortcut({_ps(link)}); "
        f"$s.TargetPath = {_ps(target)}; "
        "$s.WorkingDirectory = [Environment]::GetFolderPath('UserProfile'); "
        f"$s.IconLocation = {_ps(icon_path)}; "
        f"$s.Description = {_ps(description or APP_NAME)}; "
        + (f"$s.Arguments = {_ps(arguments)}; " if arguments else "")
        + "$s.Save()")
    ok = _powershell(script)
    if ok:
        log.info("Raccourci créé : %s", link)
    return ok


def remove_shortcuts() -> int:
    """Retire les raccourcis poses par l'installation."""
    removed = 0
    for link in (desktop_dir() / f"{APP_NAME}.lnk",
                 start_menu_dir() / f"{APP_NAME}.lnk"):
        try:
            if link.exists():
                link.unlink()
                removed += 1
        except OSError:
            log.debug("Raccourci non supprimé : %s", link)
    return removed


# --------------------------------------------------------------------------
# Base de registre
# --------------------------------------------------------------------------

def register_uninstall(target: Path, size_kb: int = 0) -> bool:
    """Declare l'application dans « Applications installees » de Windows."""
    if not is_windows():
        return False
    try:
        import winreg
        exe = target / EXE_NAME
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, UNINSTALL_KEY) as key:
            values = {
                "DisplayName": APP_NAME,
                "DisplayVersion": APP_VERSION,
                "Publisher": "ORION",
                "DisplayIcon": str(exe),
                "InstallLocation": str(target),
                "UninstallString": f'"{exe}" --desinstaller',
                "QuietUninstallString": f'"{exe}" --desinstaller --silencieux',
                "NoModify": 1,
                "NoRepair": 1,
            }
            for name, value in values.items():
                kind = (winreg.REG_DWORD if isinstance(value, int)
                        else winreg.REG_SZ)
                winreg.SetValueEx(key, name, 0, kind, value)
            if size_kb:
                winreg.SetValueEx(key, "EstimatedSize", 0,
                                  winreg.REG_DWORD, int(size_kb))
        log.info("Désinstallation déclarée dans le registre")
        return True
    except Exception:
        log.exception("Déclaration dans le registre impossible")
        return False


def unregister_uninstall() -> bool:
    if not is_windows():
        return False
    try:
        import winreg
        winreg.DeleteKey(winreg.HKEY_CURRENT_USER, UNINSTALL_KEY)
        return True
    except FileNotFoundError:
        return True
    except Exception:
        log.debug("Cle de désinstallation non retirée")
        return False


# --------------------------------------------------------------------------
# Installation
# --------------------------------------------------------------------------

def folder_size_kb(folder: Path) -> int:
    total = 0
    try:
        for path in folder.rglob("*"):
            if path.is_file():
                total += path.stat().st_size
    except OSError:
        pass
    return total // 1024


#: temps maximal d'attente d'un ancien ORION qui finit de se fermer
ATTENTE_VERROU = 60


def _renommer(source: Path, cible: Path, secondes: float) -> bool:
    """Renomme un dossier, en reessayant tant qu'un fichier y est verrouille.

    Sous Windows, renommer un dossier echoue si un programme y tient encore
    un fichier ouvert (un ORION qui finit de se fermer) : c'est exactement
    le test voulu, et il ne detruit rien s'il echoue.
    """
    import time
    fin = time.monotonic() + secondes
    attente = 0.5
    while True:
        try:
            source.rename(cible)
            return True
        except OSError as exc:
            if time.monotonic() >= fin:
                log.warning("Renommage impossible (%s -> %s) : %s", source, cible, exc)
                return False
            time.sleep(attente)
            attente = min(attente * 1.5, 3.0)


def _horodatage(reste: Path) -> int:
    try:
        return int(reste.name.rsplit("-", 1)[-1])
    except ValueError:
        return 0


def nettoyer_anciennes(target: Path | None = None) -> None:
    """Supprime les restes de versions remplacees (ORION.ancien-*) et de
    copies interrompues (ORION.nouveau, ORION.nouveau-*). Appele par
    l'installateur et au demarrage d'ORION : un reste verrouille sera retire
    la fois suivante.

    Si le programme lui-meme manque (echange interrompu, puis retour en
    arriere impossible), la version precedente la plus recente est remise en
    place au lieu d'etre effacee : c'etait alors la seule copie d'ORION."""
    target = Path(target or dossier_installe())
    parent = target.parent
    try:
        anciens = sorted(parent.glob(f"{target.name}.ancien-*"),
                         key=_horodatage, reverse=True)
        nouveaux = list(parent.glob(f"{target.name}.nouveau*"))
    except OSError:
        return
    if not target.exists():
        for reste in list(anciens):
            if (reste / EXE_NAME).exists() and _renommer(reste, target, 2):
                log.warning("Version précédente remise en place : %s", reste.name)
                anciens.remove(reste)
                break
    for reste in anciens + nouveaux:
        if not reste.is_dir():
            continue
        try:
            shutil.rmtree(reste, ignore_errors=True)
        except Exception:                      # un reste verrouille : plus tard
            log.debug("Reste non supprimé : %s", reste)


def install(payload: Path, target: Path, desktop_shortcut: bool = True,
            progress=None, demarrage: bool | None = None) -> tuple[bool, str]:
    """Copie le programme puis pose les raccourcis.

    `demarrage` : lancer ORION a l'ouverture de session Windows (case de
    l'installateur). None, pour une mise a jour silencieuse, garde le choix
    deja fait (allume ou coupe) ; sans choix connu, ORION est inscrit allume,
    comme la case cochee d'office.

    `payload` est le dossier contenant l'application deja compilee, `target`
    l'emplacement final. Les donnees de l'utilisateur (`%LOCALAPPDATA%/ORION`)
    ne sont jamais touchees.

    Le remplacement est tout ou rien : la nouvelle version est d'abord copiee
    a cote (`ORION.nouveau`), puis les deux dossiers sont echanges par
    renommage. Si l'ancienne version est encore utilisee, rien n'est
    supprime : elle reste en place, intacte, et l'installation s'arrete avec
    un message clair. (Jusqu'a la 1.7.1, l'ancien dossier etait efface fichier
    par fichier : un seul fichier verrouille laissait ORION a moitie retire.)
    """
    def step(message: str, percent: int) -> None:
        if progress:
            progress(message, percent)

    payload, target = Path(payload), Path(target)
    if not (payload / EXE_NAME).exists():
        return False, f"Programme introuvable dans {payload}"
    if not str(target).strip() or not target.is_absolute():
        return False, f"Dossier d'installation invalide : « {target} »"
    # Le dossier cible est remplace en entier : jamais un dossier qui n'est
    # pas ORION (« D:\Jeux » tape a la main effacait tous les jeux).
    if not est_installation_orion(target):
        return False, (f"Le dossier {target} contient déjà d'autres fichiers : "
                       f"choisissez un dossier vide, ou un sous-dossier "
                       f"« {APP_NAME} ». Rien n'a été modifié.")

    step("Preparation...", 5)
    neuf = target.parent / f"{target.name}.nouveau"
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        nettoyer_anciennes(target)
        if neuf.exists():
            shutil.rmtree(neuf, ignore_errors=True)
            if neuf.exists():
                neuf = target.parent / f"{target.name}.nouveau-{int(time.time())}"
    except Exception as exc:
        return False, f"Preparation impossible : {exc}"

    step("Copie des fichiers...", 20)
    try:
        shutil.copytree(payload, neuf)
        if not (neuf / EXE_NAME).exists():
            raise OSError("copie incomplète")
        try:
            (neuf / MARQUEUR).write_text(f"{APP_NAME} {APP_VERSION}\n", encoding="utf-8")
        except OSError:
            log.debug("Marque d'installation non écrite")
    except Exception as exc:
        shutil.rmtree(neuf, ignore_errors=True)
        return False, f"Copie impossible : {exc}"

    ancien = None
    if target.exists():
        step("Remplacement de la version précédente...", 60)
        ancien = target.parent / f"{target.name}.ancien-{int(time.time())}"
        if not _renommer(target, ancien, ATTENTE_VERROU):
            # l'ancienne version est encore utilisee : on la laisse intacte
            shutil.rmtree(neuf, ignore_errors=True)
            return False, ("La version précédente est encore utilisée : "
                           "fermez ORION puis relancez l'installation. "
                           "Rien n'a été modifié.")
    if not _renommer(neuf, target, 20):
        # cas extreme : on remet l'ancienne version en place
        if ancien is None or _renommer(ancien, target, 20):
            shutil.rmtree(neuf, ignore_errors=True)
            return False, "Mise en place impossible : la version précédente est conservée."
        # ni l'une ni l'autre ne peut reprendre sa place : on ne supprime
        # rien, le prochain demarrage de l'installateur remettra l'ancienne
        # version en place (nettoyer_anciennes)
        log.error("Échange impossible : ancienne version dans %s, nouvelle dans %s",
                  ancien, neuf)
        return False, (f"Mise en place impossible : la version précédente est "
                       f"conservée dans {ancien}. Relancez l'installation.")
    if ancien is not None:
        shutil.rmtree(ancien, ignore_errors=True)   # un reste verrouille partira plus tard

    # A partir d'ici le programme est en place : un raccourci ou une
    # declaration manquants ne font jamais echouer l'installation.
    step("Création des raccourcis...", 78)
    exe = target / EXE_NAME
    icon = exe
    liens = []
    if desktop_shortcut:
        liens.append(lambda: desktop_dir() / f"{APP_NAME}.lnk")
    liens.append(lambda: start_menu_dir() / f"{APP_NAME}.lnk")
    for lien in liens:
        try:
            make_shortcut(lien(), exe, icon, description="Launcher de jeux ORION")
        except Exception:
            log.exception("Raccourci non créé")

    regler_demarrage(exe, demarrage)

    step("Déclaration auprès de Windows...", 92)
    try:
        register_uninstall(target, folder_size_kb(target))
    except Exception:
        log.exception("Déclaration auprès de Windows impossible")

    step("Termine", 100)
    log.info("%s %s installé dans %s", APP_NAME, APP_VERSION, target)
    return True, str(target)


def regler_demarrage(exe: Path | None, voulu: bool | None) -> None:
    """Lancement au demarrage de Windows (cle « Run » de l'utilisateur) :
    allume (True), coupe mais toujours liste (False), choix deja fait ou
    allume par defaut (None, mise a jour) ; sans programme (`exe` None,
    desinstallation), retire. Ne fait jamais echouer l'installation."""
    if not is_windows():
        return
    try:
        from .. import demarrage
        if exe is None:
            demarrage.retirer_cle()
        elif voulu is None:
            if not demarrage.suivre_installation(exe):
                demarrage.activer_cle(exe)
        elif voulu:
            demarrage.activer_cle(exe)
        else:
            demarrage.couper_cle(exe)
    except Exception:
        log.exception("Lancement au démarrage de Windows non réglé")


def uninstall(remove_data: bool = False, progress=None,
              target: Path | None = None) -> tuple[bool, str]:
    """Retire le programme, ses raccourcis et sa declaration.

    Les donnees (bibliotheque, sauvegardes de reglages, jaquettes) ne sont
    supprimees que si l'utilisateur le demande explicitement.
    `target` : dossier du programme (par defaut, celui ou ORION est
    reellement installe, qui n'est pas forcement le dossier par defaut).
    """
    def step(message: str, percent: int) -> None:
        if progress:
            progress(message, percent)

    target = Path(target) if target else dossier_installe()
    step("Retrait des raccourcis...", 15)
    remove_shortcuts()
    regler_demarrage(None, False)
    unregister_uninstall()

    notes = []
    if remove_data:
        step("Suppression des données...", 45)
        try:
            shutil.rmtree(DATA_DIR, ignore_errors=True)
            notes.append("données supprimées")
        except Exception:
            notes.append("données conservées (suppression impossible)")
    else:
        notes.append(f"données conservées dans {DATA_DIR}")

    step("Suppression du programme...", 70)
    # le programme en cours d'execution ne peut pas s'effacer lui-meme :
    # un script differé s'en charge une fois le processus termine.
    ok = _schedule_self_removal(target)
    step("Termine", 100)
    return ok, " - ".join(notes)


def script_retrait(target: Path, pid: int) -> str:
    """Script PowerShell de suppression differee du dossier du programme.

    Il attend la fin du processus `pid` (le programme qui se desinstalle,
    peut-etre encore occupe a afficher « ORION a ete retire ») au lieu d'un
    delai fixe, puis reessaie tant qu'un fichier reste verrouille."""
    return (
        f"$p = {int(pid)}; $d = {_ps(target)}; "
        "try { Wait-Process -Id $p -Timeout 600 -ErrorAction Stop } catch { }; "
        "Start-Sleep -Milliseconds 800; "
        "for ($i = 0; $i -lt 30; $i++) { "
        "if (-not (Test-Path -LiteralPath $d)) { break }; "
        "Remove-Item -LiteralPath $d -Recurse -Force -ErrorAction SilentlyContinue; "
        "if (-not (Test-Path -LiteralPath $d)) { break }; "
        "Start-Sleep -Seconds 1 }")


def _schedule_self_removal(target: Path, pid: int | None = None) -> bool:
    """Programme la suppression du dossier apres la fermeture du programme."""
    target = Path(target)
    if not target.exists():
        return True
    if not est_installation_orion(target):
        log.warning("Dossier non supprimé (ce n'est pas ORION) : %s", target)
        return False
    if not is_windows():
        shutil.rmtree(target, ignore_errors=True)
        return True
    import base64
    script = script_retrait(target, pid or os.getpid())
    # -EncodedCommand : le script voyage en UTF-16 sur la ligne de commande,
    # sans fichier .cmd (lu dans la page de code OEM : un chemin accentue,
    # « C:\Users\Jerome » avec accents, n'etait jamais supprime)
    code = base64.b64encode(script.encode("utf-16-le")).decode("ascii")
    try:
        from ..core.lancement import popen_propre
        # dossier courant hors du dossier a supprimer : Windows ne supprime
        # pas le dossier courant d'un processus
        popen_propre(["powershell", "-NoProfile", "-NonInteractive",
                      "-ExecutionPolicy", "Bypass", "-EncodedCommand", code],
                     cwd=str(target.parent),
                     creationflags=0x08000008)   # sans fenetre, detache
        return True
    except Exception:
        log.exception("Suppression différée impossible")
        return False
