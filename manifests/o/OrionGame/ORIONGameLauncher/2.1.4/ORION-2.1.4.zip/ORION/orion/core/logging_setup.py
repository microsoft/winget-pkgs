"""Journalisation : un fichier tournant + la console."""
from __future__ import annotations

import logging
import re
import logging.handlers
import sys

from .paths import LOG_DIR, ensure_dirs

_READY = False


class MasqueSecrets(logging.Filter):
    """Aucun jeton, cle ou code de connexion ne doit finir dans le journal,
    meme recopie par un message d'erreur (adresse complete d'une requete)
    ou par la trace d'une exception (`log.exception`, erreurs enchainees)."""
    _MOTIFS = [
        (re.compile(r"([?&](?:key|api_key|access_token|refresh_token|token|code|"
                    r"client_secret|authorization)=)[^&\s'\"]+", re.I), r"\1<masque>"),
        (re.compile(r"(Bearer|XBL3\.0 x=[^;]*;)\s*[A-Za-z0-9._~+/=-]{12,}"), r"\1 <masque>"),
        (re.compile(r"([\"'](?:access_token|refresh_token|cle|token|ms_access|ms_refresh|"
                    r"xsts|client_secret)[\"']\s*:\s*[\"'])[^\"']+"), r"\1<masque>"),
    ]
    _FORMAT = logging.Formatter()

    @classmethod
    def masquer(cls, texte: str) -> str:
        for motif, remplacement in cls._MOTIFS:
            texte = motif.sub(remplacement, texte)
        return texte

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            message = record.getMessage()
        except Exception:
            return True
        propre = self.masquer(message)
        if propre != message:
            record.msg, record.args = propre, None
        # la trace de l'exception est ajoutee par le formateur apres les
        # filtres : on la met en forme ici, masquee, et le formateur la
        # reprend telle quelle (exc_text)
        try:
            if record.exc_info:
                texte = record.exc_text or self._FORMAT.formatException(record.exc_info)
                record.exc_text = self.masquer(texte)
                record.exc_info = None
            elif record.exc_text:
                record.exc_text = self.masquer(record.exc_text)
            if record.stack_info:
                record.stack_info = self.masquer(record.stack_info)
        except Exception:
            pass
        return True


class CompteErreurs(logging.Handler):
    """Compte les lignes d'erreur de la session (pour le bilan de fluidite
    anonyme, `core.fluidite.bilan_envoi`) : un nombre, jamais un texte."""

    def __init__(self) -> None:
        super().__init__(logging.ERROR)
        self.n = 0

    def emit(self, record: logging.LogRecord) -> None:
        self.n += 1


_ERREURS = CompteErreurs()


def nb_erreurs() -> int:
    """Lignes de niveau ERROR ou plus ecrites depuis le demarrage."""
    return _ERREURS.n


def setup(level: int = logging.INFO) -> logging.Logger:
    global _READY
    root = logging.getLogger("orion")
    if _READY:
        return root

    ensure_dirs()
    root.setLevel(logging.DEBUG)
    fmt = logging.Formatter(
        "%(asctime)s  %(levelname)-7s  %(name)-26s  %(message)s", "%d/%m %H:%M:%S"
    )

    fh = logging.handlers.RotatingFileHandler(
        LOG_DIR / "orion.log", maxBytes=2_000_000, backupCount=3, encoding="utf-8"
    )
    fh.setFormatter(fmt)
    fh.addFilter(MasqueSecrets())
    fh.setLevel(logging.DEBUG)
    root.addHandler(fh)

    if sys.stderr is not None:
        sh = logging.StreamHandler(sys.stderr)
        sh.setFormatter(fmt)
        sh.addFilter(MasqueSecrets())
        sh.setLevel(level)
        root.addHandler(sh)

    root.addHandler(_ERREURS)
    root.propagate = False
    _READY = True
    return root


def get(name: str) -> logging.Logger:
    setup()
    return logging.getLogger("orion." + name)
