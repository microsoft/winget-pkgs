"""Detection des jeux GOG (base de registre GOG.com\\Games)."""
from __future__ import annotations

from pathlib import Path

from ...core.logging_setup import get
from ...core.models import Game
from ...core.winutil import HKLM, dir_size, reg_subkeys, reg_values
from .base import Scanner, detect_engine, pick_main_exe

log = get("scan.gog")

REG_PATHS = (r"SOFTWARE\GOG.com\Games", r"SOFTWARE\WOW6432Node\GOG.com\Games")


class GOGScanner(Scanner):
    id = "gog"
    label = "GOG"
    icon = "GOG"
    priority = 80

    def _keys(self) -> list[tuple[str, str]]:
        out = []
        for base in REG_PATHS:
            for sub in reg_subkeys(HKLM, base):
                out.append((base, sub))
        return out

    def available(self) -> bool:
        return bool(self._keys())

    def scan(self) -> list[Game]:
        games: list[Game] = []
        seen: set[str] = set()
        for base, sub in self._keys():
            v = reg_values(HKLM, f"{base}\\{sub}")
            gid = str(v.get("gameID") or sub)
            if gid in seen:
                continue
            seen.add(gid)
            title = v.get("gameName") or v.get("startMenu") or ""
            path = v.get("path") or v.get("workingDir") or ""
            if not title or not path or not Path(path).is_dir():
                continue
            exe = v.get("exe") or ""
            full = str(Path(path) / exe) if exe and not Path(exe).is_absolute() else exe
            if not full or not Path(full).exists():
                full = pick_main_exe(Path(path), title)

            games.append(self._mk(
                title=title,
                source_id=gid,
                install_dir=path,
                executable=full,
                working_dir=v.get("workingDir") or path,
                size_bytes=dir_size(Path(path), 8000),
                engine=detect_engine(Path(path)),
                extra={"build_id": v.get("BUILDID", "")},
            ))
        log.info("%d jeux GOG", len(games))
        return games
