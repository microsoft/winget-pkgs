"""Persistance de la bibliotheque et des statistiques de jeu."""
from __future__ import annotations

import time

from .logging_setup import get
from .doublons import dedoublonner, fusionner, meme_jeu
from .fichiers import existe
from .models import Game
from .base import Document
from .paths import LIBRARY_FILE, STATS_FILE, ensure_dirs

log = get("store")


_DOC_BIBLIO = Document("bibliotheque", LIBRARY_FILE)
_DOC_STATS = Document("statistiques", STATS_FILE)


class LibraryStore:
    """Bibliotheque en memoire, sauvegardee dans la base locale.

    Le fusionnement conserve les donnees utilisateur (favoris, temps de jeu,
    profil prefere) quand un nouveau scan redecouvre le meme jeu.
    """

    USER_FIELDS = (
        "favorite", "hidden", "play_seconds", "last_played",
        "preferred_profile", "preferred_display", "notes",
    )

    #: cles de `extra` posees par ORION (pas par les scanners) : un nouveau
    #: scan ne doit pas les effacer. « deplace » : jeu deplace vers un autre
    #: disque (1.8) ; sans elle, le bouton « Ramener » disparaissait.
    #: « sauvegardes_disque » : copies du jeu sur d'autres disques (1.9).
    EXTRA_CONSERVES = ("deplace", "sauvegardes_disque")

    def __init__(self) -> None:
        self.games: dict[str, Game] = {}
        self.last_scan: float = 0.0
        self.load()

    # -- E/S ------------------------------------------------------------
    def load(self) -> None:
        ensure_dirs()
        try:
            raw = _DOC_BIBLIO.lire(None)
            if not raw:
                return
            self.last_scan = raw.get("last_scan", 0.0)
            for d in raw.get("games", []):
                g = Game.from_dict(d)
                self.games[g.uid] = g
            log.info("Bibliotheque chargee : %d jeux", len(self.games))
            # les versions precedentes laissaient passer des doublons
            # (registre + Steam) : on les resorbe des l'ouverture.
            if self.dedoublonner():
                self.save()
        except Exception:
            log.exception("Bibliotheque illisible")

    def save(self, attendre: bool = False) -> None:
        """La bibliotheque est serialisee ici (quelques millisecondes) puis
        ecrite par le fil d'ecriture de la base : le fil graphique n'attend
        jamais le disque ni le verrou. `attendre` : ecriture immediate
        (fermeture de l'application)."""
        contenu = {"last_scan": self.last_scan,
                   "games": [g.to_dict() for g in self.games.values()]}
        _DOC_BIBLIO.deposer(contenu, attendre=attendre)

    def dedoublonner(self, priorites: dict[str, int] | None = None,
                     preferes: set[str] | None = None) -> int:
        """Fusionne les fiches d'un meme jeu. Retourne le nombre retire."""
        avant = len(self.games)
        anciens = dict(self.games)
        preferes = preferes or set()
        # a rang egal, une fiche revue par le dernier scan l'emporte
        ordre = sorted(self.games.values(), key=lambda g: g.uid not in preferes)
        self.games = {g.uid: g for g in dedoublonner(ordre, priorites)}
        for g in self.games.values():
            for uid in g.extra.get("merged_uids") or []:
                if uid in anciens and uid not in self.games:
                    self._reprendre_extras(g, anciens[uid])
        retires = avant - len(self.games)
        if retires:
            log.info("Doublons fusionnes : %d", retires)
        return retires

    @classmethod
    def _reprendre_extras(cls, garde: Game, autre: Game) -> None:
        """La fiche conservee herite des cles d'ORION de la fiche retiree
        (une sauvegarde sur un autre disque ne doit pas etre oubliee parce
        que le jeu a change de source)."""
        for cle in cls.EXTRA_CONSERVES:
            valeur = (autre.extra or {}).get(cle)
            if not valeur:
                continue
            if cle == "sauvegardes_disque":
                deja = {str(s.get("chemin", "")).lower()
                        for s in garde.extra.get(cle) or [] if isinstance(s, dict)}
                ajout = [s for s in valeur if isinstance(s, dict)
                         and str(s.get("chemin", "")).lower() not in deja]
                if ajout:
                    garde.extra[cle] = list(garde.extra.get(cle) or []) + ajout
            elif cle not in garde.extra:
                garde.extra[cle] = valeur

    @staticmethod
    def _path_key(game: Game) -> str:
        return (game.install_dir or "").lower().rstrip("\\/")

    # -- Contenu --------------------------------------------------------
    def all(self, include_hidden: bool = False) -> list[Game]:
        return [g for g in self.games.values() if include_hidden or not g.hidden]

    def get(self, uid: str) -> Game | None:
        return self.games.get(uid)


    def merge_scan(self, found: list[Game]) -> tuple[int, int]:
        """Integre un resultat de scan. Retourne (nouveaux, mis a jour)."""
        added = updated = 0

        for g in found:
            old = self.games.get(g.uid)
            if old is not None:
                for f in self.USER_FIELDS:
                    setattr(g, f, getattr(old, f))
                # le temps rapporte par la plateforme prime sur l'ancien
                if not g.external_seconds:
                    g.external_seconds = old.external_seconds
                for f in ("art_cover", "art_hero", "art_logo", "art_icon", "accent_color"):
                    if not getattr(g, f) and getattr(old, f):
                        setattr(g, f, getattr(old, f))
                for cle in self.EXTRA_CONSERVES:
                    if cle not in g.extra and cle in (old.extra or {}):
                        g.extra[cle] = old.extra[cle]
                updated += 1
            else:
                added += 1
            self.games[g.uid] = g

        # Entrees qui n'ont pas ete revues par ce scan :
        #  - couvertes par une autre source au meme emplacement -> supprimees
        #    (c'est le cas quand un jeu passe du scan generique a sa vraie
        #     plateforme, par exemple de "registre" a "battlenet") ;
        #  - dossier disparu -> supprimees (jeu desinstalle) ;
        #  - sinon -> simplement marquees comme introuvables.
        alive = {g.uid for g in found}

        # une fiche enregistree qui designe un jeu revu sous une autre
        # source (registre -> Steam, dossier -> GOG...) est fusionnee dans
        # celle-ci : ses donnees utilisateur suivent, elle disparait.
        vivants = [self.games[u] for u in alive if u in self.games]
        for uid, g in list(self.games.items()):
            if uid in alive:
                continue
            jumeau = next((v for v in vivants if meme_jeu(v, g)), None)
            if jumeau is not None:
                fusionner(jumeau, g)
                self._reprendre_extras(jumeau, g)
                self.games.pop(uid, None)
        by_path = {self._path_key(g): g.uid for g in found if self._path_key(g)}

        for uid, g in list(self.games.items()):
            if uid in alive:
                # le marquage "introuvable" des jeux revus par ce scan est
                # decide en amont (le dossier existe-t-il encore ?) : on ne
                # le touche pas ici.
                continue
            if g.extra.get("manual"):
                continue
            key = self._path_key(g)
            if key and by_path.get(key, uid) != uid:
                self._reprendre_extras(self.games[by_path[key]], g)
                self.games.pop(uid, None)
                continue
            if g.install_dir and not existe(g.install_dir) \
                    and not g.extra.get("sauvegardes_disque"):
                # jeu desinstalle ; s'il a une sauvegarde sur un autre
                # disque, sa fiche reste (marquee introuvable) pour pouvoir
                # la restaurer depuis la page Stockage
                self.games.pop(uid, None)
                continue
            g.extra["missing"] = True

        self.last_scan = time.time()
        self.save()
        return added, updated

    def remove(self, uid: str) -> None:
        self.games.pop(uid, None)
        self.save()

    def add_manual(self, game: Game) -> Game:
        game.extra["manual"] = True
        self.games[game.uid] = game
        self.save()
        return game


class StatsStore:
    """Historique de sessions de jeu (duree, date)."""

    def __init__(self) -> None:
        self.sessions: list[dict] = []
        self.load()

    def load(self) -> None:
        ensure_dirs()
        try:
            self.sessions = (_DOC_STATS.lire({}) or {}).get("sessions", [])
        except Exception:
            log.exception("Statistiques illisibles")

    def save(self) -> None:
        _DOC_STATS.ecrire({"sessions": self.sessions[-2000:]})

    def record(self, uid: str, seconds: int, profile: str = "") -> None:
        self.sessions.append(
            {"uid": uid, "at": time.time(), "seconds": int(seconds), "profile": profile}
        )
        self.save()

    def renommer(self, correspondances: dict[str, str]) -> int:
        """Rattache les sessions d'une fiche fusionnee a la fiche conservee."""
        n = 0
        for session in self.sessions:
            neuf = correspondances.get(session.get("uid", ""))
            if neuf:
                session["uid"] = neuf
                n += 1
        if n:
            self.save()
        return n

