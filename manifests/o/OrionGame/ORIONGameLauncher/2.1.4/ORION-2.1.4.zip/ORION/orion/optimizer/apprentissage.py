"""Moteur inconnu : ORION apprend le fichier de reglages du jeu (2.1.0).

Demande de l'auteur (7 octobre, « tous les jeux ont un fonctionnement de
config different, mais il y a un moyen ») : quand aucune recette ne
connait le jeu, ORION cherche son fichier de reglages aux endroits
habituels (Documents, Documents/My Games, Saved Games, %LOCALAPPDATA%,
%APPDATA%). Jamais dans le dossier d'installation du jeu (9 octobre,
anti-triche) : c'est la que les anti-triches verifient les fichiers, et un
fichier devine n'y a pas sa place ; seule une recette ecrite pour le jeu
peut y toucher et n'y touche que des CLES SURES, reconnues a
leur nom et dont la valeur actuelle confirme le sens : definition
(largeur, hauteur), plein ecran, synchronisation verticale, limite
d'images. Les niveaux de qualite restent au guide, dont les noms varient
trop d'un jeu a l'autre pour etre devines.

Regles : jamais une cle creee, jamais une valeur d'une autre forme que
celle en place (« true »/« false » reste en minuscules, « 1 »/« 0 » reste
numerique), sauvegarde avant, relecture apres (comme toute recette).
Le resultat est une `Recipe` de confiance « appris ».
"""
from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any

from ..core.logging_setup import get
from ..core.models import Game

log = get("optimizer.apprentissage")

TAILLE_MAX = 512 * 1024
EXTENSIONS = {".ini", ".cfg", ".xml", ".json", ".txt", ".config", ".settings", ".conf", ""}
#: noms de fichiers qui ressemblent a des reglages
_NOM_FICHIER = re.compile(r"(setting|config|option|graphic|video|render|user|profile|pref|display)", re.I)
#: dossiers a ne jamais fouiller dans le dossier du jeu
_DOSSIERS_EXCLUS = re.compile(r"(^|[\\/])(engine|binaries|bin|redist|_commonredist|localization|loc|"
                              r"sound|audio|movies?|videos?|shaders?|cache|logs?|crash|dotnet|mono|"
                              r"steamapps|installers?|support|tools?|sdk|saves?)([\\/]|$)", re.I)

#: cles sures : (nom du reglage abstrait, motif sur le nom de la cle)
CLES = {
    "largeur": re.compile(r"^(?:[bif]?)(?:screen|resolution|res|display|window|fullscreen|render)?[_. ]?"
                          r"(?:width|sizex|size_x|res_?x|resolution_?x|w)$", re.I),
    "hauteur": re.compile(r"^(?:[bif]?)(?:screen|resolution|res|display|window|fullscreen|render)?[_. ]?"
                          r"(?:height|sizey|size_y|res_?y|resolution_?y|h)$", re.I),
    "plein_ecran": re.compile(r"^(?:[bi]|is|b_|use)?[_ ]?(?:full[_ ]?screen|fullscreenmode|fullscreenenabled|"
                              r"screenmode|windowmode|window_mode|displaymode)$", re.I),
    "vsync": re.compile(r"^(?:[bi]|is|b_|use|enable)?[_ ]?v[_]?sync(?:enabled|mode|_?enable)?$", re.I),
    "limite": re.compile(r"^(?:max[_ ]?fps|fps[_ ]?(?:cap|limit|max)|frame[_ ]?rate[_ ]?(?:limit|cap|max)|"
                         r"framecap|limitfps|maxframerate|targetfps|fpslimit)$", re.I),
}


def _candidats(game: Game) -> list[Path]:
    """Fichiers de reglages plausibles, du plus proche du jeu au plus loin."""
    from .discovery import context_for
    ctx = context_for(game)
    titre = game.title
    variantes = {titre, re.sub(r"[^A-Za-z0-9 ]", "", titre), re.sub(r"[^A-Za-z0-9]", "", titre),
                 titre.replace(":", "").replace("'", "")}
    racines: list[Path] = []
    for base in (ctx.get("documents"), ctx.get("saved_games"), ctx.get("localappdata"), ctx.get("appdata")):
        if not base:
            continue
        for v in variantes:
            if v:
                racines += [Path(base) / v, Path(base) / "My Games" / v]
        # dossier au nom du studio ou du jeu, forme libre : premier mot du titre
        premier = re.sub(r"[^A-Za-z0-9]", "", titre.split(" ")[0]) if titre else ""
        if len(premier) >= 4:
            try:
                for d in Path(base).iterdir():
                    if d.is_dir() and premier.lower() in d.name.replace(" ", "").lower():
                        racines += [d, d / "My Games"]
            except OSError:
                pass
            try:
                mg = Path(base) / "My Games"
                for d in mg.iterdir():
                    if d.is_dir() and premier.lower() in d.name.replace(" ", "").lower():
                        racines.append(d)
            except OSError:
                pass
    # jamais le dossier d'installation (anti-triche, voir en tete)
    dossier_jeu = os.path.normcase(os.path.normpath(game.install_dir)) if game.install_dir else ""
    fichiers: list[Path] = []
    vus: set[str] = set()
    for racine in racines:
        if not racine.is_dir():
            continue
        try:
            for p in _parcourir(racine, profondeur=3):
                k = str(p).lower()
                if k in vus:
                    continue
                if dossier_jeu and os.path.normcase(os.path.normpath(str(p))).startswith(
                        dossier_jeu.rstrip("\\/") + os.sep):
                    continue
                vus.add(k)
                fichiers.append(p)
        except OSError:
            continue
    return fichiers


def _parcourir(racine: Path, profondeur: int):
    for dirpath, dirnames, filenames in os.walk(racine):
        rel = os.path.relpath(dirpath, racine)
        if rel != "." and (rel.count(os.sep) + 1 > profondeur or _DOSSIERS_EXCLUS.search(rel)):
            dirnames[:] = []
            continue
        for f in filenames:
            p = Path(dirpath) / f
            if p.suffix.lower() not in EXTENSIONS or not _NOM_FICHIER.search(p.stem):
                continue
            try:
                if p.stat().st_size > TAILLE_MAX or p.stat().st_size == 0:
                    continue
            except OSError:
                continue
            yield p


# -- lecture des cles presentes, par format ---------------------------------

def _cles_ini(texte: str) -> list[tuple[str, str, str]]:
    """[(section, cle, valeur)] d'un fichier INI (sections) ou « cle=valeur »."""
    out, section = [], ""
    for ligne in texte.splitlines():
        s = ligne.strip()
        if not s or s[0] in ";#/":
            continue
        m = re.match(r"^\[(.+?)\]$", s)
        if m:
            section = m.group(1).strip()
            continue
        m = re.match(r'^"?([^"=:\s][^"=:]*?)"?\s*(?:=|:)\s*"?([^"\r\n]*?)"?\s*$', s)
        if m:
            out.append((section, m.group(1).strip(), m.group(2).strip()))
            continue
        m = re.match(r'^"?([A-Za-z_][\w.]*)"?\s+"?([^"\r\n]*?)"?\s*$', s)   # « Cle valeur »
        if m:
            out.append((section, m.group(1).strip(), m.group(2).strip()))
    return out


def _cles_xml(texte: str) -> list[tuple[str, str]]:
    """[(adresse xml_writer, valeur)] : attributs des balises et texte des
    elements simples (une seule ligne)."""
    out: list[tuple[str, str]] = []
    for m in re.finditer(r"<([A-Za-z_][\w.:-]*)\b([^>]*)>", texte):
        balise, attrs = m.group(1), m.group(2)
        for a in re.finditer(r"\b([A-Za-z_][\w.:-]*)\s*=\s*([\"'])(.*?)\2", attrs):
            out.append((f"{balise}@{a.group(1)}", a.group(3)))
    for m in re.finditer(r"<([A-Za-z_][\w.:-]*)>([^<\r\n]{1,80})</\1>", texte):
        out.append((m.group(1), m.group(2).strip()))
    # Larian : <attribute id="X" value="Y"/>
    for m in re.finditer(r"<attribute\b[^>]*\bid\s*=\s*\"([^\"]+)\"[^>]*\bvalue\s*=\s*\"([^\"]*)\"", texte):
        out.append((f"attribute[id={m.group(1)}]@value", m.group(2)))
    return out


def _cles_json(texte: str) -> list[tuple[str, str]]:
    import json
    try:
        data = json.loads(texte)
    except Exception:
        return []
    out: list[tuple[str, str]] = []

    def marcher(obj, chemin):
        if isinstance(obj, dict):
            for k, v in obj.items():
                if isinstance(v, (dict, list)):
                    if isinstance(v, dict):
                        marcher(v, f"{chemin}.{k}" if chemin else k)
                else:
                    out.append((f"{chemin}.{k}" if chemin else k, str(v)))
    marcher(data, "")
    return out


def _type_valeur(v: str) -> str:
    s = v.strip()
    if s.lower() in ("true", "false"):
        return "bool_minuscule" if s in ("true", "false") else "bool_capitale"
    if re.fullmatch(r"-?\d+", s):
        return "entier"
    if re.fullmatch(r"-?\d+\.\d+", s):
        return "decimal"
    if re.fullmatch(r"\d{3,5}x\d{3,5}", s):
        return "definition"
    return "texte"


def _valeur(reglage: str, type_: str, actuel: str, settings: dict[str, Any]) -> str | None:
    """La valeur a ecrire, dans la forme du fichier ; None si on ne sait pas."""
    w, h = int(settings.get("resolution_w") or 0), int(settings.get("resolution_h") or 0)
    cap = int(settings.get("fps_cap") or 0)
    plein = settings.get("window_mode") == "fullscreen"
    vsync = bool(settings.get("vsync"))
    if reglage == "largeur":
        return (str(w) if type_ == "entier" else f"{w}.000000" if type_ == "decimal" else None) if w else None
    if reglage == "hauteur":
        return (str(h) if type_ == "entier" else f"{h}.000000" if type_ == "decimal" else None) if h else None
    if reglage in ("plein_ecran", "vsync"):
        valeur = plein if reglage == "plein_ecran" else vsync
        if type_ == "bool_minuscule":
            return "true" if valeur else "false"
        if type_ == "bool_capitale":
            return "True" if valeur else "False"
        if type_ == "entier" and actuel.strip() in ("0", "1"):
            return "1" if valeur else "0"
        return None                         # 0/1/2 (modes) : trop ambigu
    if reglage == "limite":
        if not cap or type_ not in ("entier", "decimal"):
            return None                     # « sans limite » se code differemment partout
        return str(cap) if type_ == "entier" else f"{cap}.000000"
    return None


def _format(p: Path, texte: str) -> str:
    t = texte.lstrip()
    if t.startswith("<"):
        return "xml"
    if re.search(r"^\s*\[[^\]\n]+\]\s*$", texte, re.M):
        return "ini"                        # une ligne « [Section] » : INI avant tout
    if t.startswith(("{", "[")):
        return "json"
    return "texte"


def apprendre(game: Game, settings: dict[str, Any]) -> dict | None:
    """Une recette (dictionnaire) batie sur le fichier trouve, ou None."""
    for p in _candidats(game):
        try:
            texte = p.read_bytes().decode("utf-8-sig", errors="replace")
        except OSError:
            continue
        fmt = _format(p, texte)
        trouvees: list[tuple[str, str, str, str]] = []     # (reglage, section, cle, valeur)
        if fmt == "ini" or fmt == "texte":
            for section, cle, valeur in _cles_ini(texte):
                for reglage, motif in CLES.items():
                    if motif.match(cle):
                        trouvees.append((reglage, section, cle, valeur))
                        break
        elif fmt == "xml":
            for adresse, valeur in _cles_xml(texte):
                nom = adresse.split("@")[-1] if "@" in adresse and not adresse.startswith("attribute[") else \
                    (re.search(r"id=([^\]]+)", adresse).group(1) if adresse.startswith("attribute[") else adresse)
                for reglage, motif in CLES.items():
                    if motif.match(nom):
                        trouvees.append((reglage, "", adresse, valeur))
                        break
        elif fmt == "json":
            for chemin, valeur in _cles_json(texte):
                for reglage, motif in CLES.items():
                    if motif.match(chemin.split(".")[-1]):
                        trouvees.append((reglage, "", chemin, valeur))
                        break
        if not trouvees:
            continue
        reglages = {r for r, *_ in trouvees}
        if not ({"largeur", "hauteur"} <= reglages or "plein_ecran" in reglages or "vsync" in reglages):
            continue                         # une seule cle isolee : pas assez sur
        entries = []
        vus: set[tuple[str, str]] = set()
        for reglage, section, cle, valeur in trouvees:
            if (section, cle) in vus:
                continue
            vus.add((section, cle))
            v = _valeur(reglage, _type_valeur(valeur), valeur, settings)
            if v is None:
                continue
            entries.append({"section": section, "key": cle, "value": v,
                            "label": {"largeur": "Largeur de l'image", "hauteur": "Hauteur de l'image",
                                      "plein_ecran": "Plein ecran", "vsync": "Synchronisation verticale",
                                      "limite": "Limite d'images"}[reglage]})
        if not entries:
            continue
        log.info("Reglages appris pour %s : %s (%d cle(s) sure(s))", game.title, p.name, len(entries))
        return {"id": f"appris_{game.uid}", "name": f"Fichier appris : {p.name}",
                "match": {}, "confidence": "appris", "creer_cles": False,
                "targets": [{"format": "ini" if fmt == "ini" else fmt, "paths": [str(p)], "entries": entries}],
                "advice": ["Reglages appris dans le fichier du jeu : seules les cles sures (definition, "
                           "plein ecran, synchronisation, limite d'images) sont ecrites. Les niveaux de "
                           "qualite restent a choisir dans le menu du jeu (voir le guide)."]}
    return None
