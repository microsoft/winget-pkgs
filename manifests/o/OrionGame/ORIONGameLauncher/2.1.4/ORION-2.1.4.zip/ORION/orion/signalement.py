"""Signaler un probleme : rapport anonymise et gestion des plantages.

Le rapport contient ce qui aide a comprendre un bug, et rien de personnel :

* version d'ORION, de Windows, processeur, carte graphique, ecrans ;
* nombre de jeux par source (pas leurs noms) ;
* reglages, cles et identifiants masques ;
* fin du journal, chemins et adresses anonymises.

Il est ecrit dans `%LOCALAPPDATA%\\ORION\\rapports\\`, et un signalement
GitHub deja rempli s'ouvre dans le navigateur : l'utilisateur relit,
ajoute le fichier s'il le souhaite, et envoie lui-meme. Rien ne part sans
lui.

Plantages : `installer_gestionnaires()` intercepte les erreurs non prevues
(fil principal et taches de fond). ORION ne se ferme plus en silence : il
note l'erreur et propose de la signaler. Un temoin de session detecte
aussi un arret brutal (au demarrage suivant) ; `faulthandler` garde la trace
d'un plantage natif, et une session coupee pendant sa fermeture n'est pas
prise pour un plantage (2.1.4).
"""
from __future__ import annotations

import faulthandler
import json
import os
import platform
import re
import sys
import threading
import time
import traceback
from pathlib import Path
from urllib.parse import quote

from .core.logging_setup import get
from .core.paths import DATA_DIR, LOG_DIR
from .version import APP_NAME, APP_VERSION

log = get("signalement")

DEPOT = "Sikher-kisa/orion-game-launcher"
RAPPORTS = DATA_DIR / "rapports"
TEMOIN = DATA_DIR / ".session-en-cours"
#: trace des plantages natifs (Qt, pilote, DLL) : `faulthandler` y ecrit si le
#: processus meurt hors de Python, la ou `sys.excepthook` ne voit rien
TRACE_NATIVE = DATA_DIR / "trace-native.txt"

#: ce que la session precedente a laisse : etat du temoin, trace native
_precedente: dict = {}
_trace_fichier = None

#: reglages dont la valeur n'apparait jamais dans un rapport
_SECRETS = re.compile(r"(key|cle|token|secret|password|mdp|steamid|author|api)",
                      re.I)

_MOTIFS = [
    # C:\Users\Prenom\...  ->  C:\Users\<utilisateur>\...
    (re.compile(r"([A-Za-z]:\\\\?Users\\\\?)[^\\/\s\"']+", re.I), r"\1<utilisateur>"),
    (re.compile(r"(/home/|/Users/)[^/\s\"']+"), r"\1<utilisateur>"),
    (re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+"), "<adresse>"),
    (re.compile(r"\b7656119\d{10}\b"), "<steamid>"),
    (re.compile(r"\b(sk-[A-Za-z0-9_-]{8,}|AIza[0-9A-Za-z_-]{20,})"), "<cle>"),
    (re.compile(r"([?&](key|api_key|token|steamid|access_token|refresh_token|code)=)[^&\s]+",
                re.I), r"\1<masque>"),
    (re.compile(r"(Bearer|XBL3\.0 x=[^;]*;)\s*[A-Za-z0-9._~+/=-]{12,}"), r"\1 <masque>"),
]


def anonymiser(texte: str) -> str:
    from .core.logging_setup import MasqueSecrets
    texte = MasqueSecrets.masquer(texte)          # jetons, cles, secrets OAuth
    for motif, remplacement in _MOTIFS:
        texte = motif.sub(remplacement, texte)
    nom = os.environ.get("USERNAME") or os.environ.get("USER") or ""
    if len(nom) >= 3:
        texte = re.sub(re.escape(nom), "<utilisateur>", texte, flags=re.I)
    return texte


def _reglages_masques(donnees, chemin: str = "") -> object:
    if isinstance(donnees, dict):
        return {k: ("<masque>" if _SECRETS.search(k) and v not in ("", None, False, [], {})
                    else _reglages_masques(v, f"{chemin}.{k}"))
                for k, v in donnees.items()}
    if isinstance(donnees, list):
        return [_reglages_masques(v, chemin) for v in donnees][:20]
    return donnees


def _fin_journal(lignes: int = 250) -> str:
    fichier = LOG_DIR / "orion.log"
    try:
        contenu = fichier.read_text("utf-8", errors="replace").splitlines()
    except OSError:
        return "(journal indisponible)"
    return "\n".join(contenu[-lignes:])


def _machine(hw=None) -> list[str]:
    lignes = [f"Windows : {platform.platform()}",
              f"Python : {platform.python_version()}"]
    if hw is not None:
        try:
            lignes.append(f"Processeur : {hw.cpu_name} ({hw.cpu_threads} fils)")
            lignes.append(f"Memoire : {hw.ram_gb:.0f} Go")
            vus = set()
            for g in hw.gpus[:4]:
                if g.name in vus:
                    continue            # la meme carte listee deux fois par Windows
                vus.add(g.name)
                vram = getattr(g, "vram_mb", 0) or 0
                lignes.append(f"Carte graphique : {g.name} "
                              f"({round(vram / 1024) if vram else '?'} Go)")
            for d in hw.displays[:3]:
                mode = getattr(d, "current", None)
                lignes.append(f"Ecran : {getattr(d, 'name', '') or '?'} "
                              f"{mode.width}x{mode.height} @ {mode.refresh} Hz" if mode
                              else f"Ecran : {getattr(d, 'name', '') or '?'}")
        except Exception:
            pass
    return lignes


def rapport(description: str = "", erreur: str = "", hw=None,
            jeux: list | None = None) -> str:
    from .core.config import CONFIG
    parties = [f"# Rapport {APP_NAME} {APP_VERSION}",
               f"Date : {time.strftime('%Y-%m-%d %H:%M')}", ""]
    if description:
        parties += ["## Ce qui s'est passe", description.strip(), ""]
    if erreur:
        parties += ["## Erreur", erreur.strip(), ""]
    parties += ["## Machine", *_machine(hw), ""]
    parties += ["## Installation", _installation(), ""]
    if _precedente:
        parties += ["## Session precedente", *_resume_precedente(), ""]
    if jeux is not None:
        compte: dict[str, int] = {}
        for g in jeux:
            src = getattr(g, "source", "?") or "?"
            compte[src] = compte.get(src, 0) + 1
        parties += ["## Bibliotheque",
                    ", ".join(f"{k} : {v}" for k, v in sorted(compte.items())) or "vide",
                    ""]
    try:
        from .core import reseau
        parties += ["## Reseau", str(reseau.etat()), ""]
    except Exception:
        pass
    try:
        import json
        parties += ["## Reglages",
                    json.dumps(_reglages_masques(CONFIG.data), indent=1,
                               ensure_ascii=False)[:6000], ""]
    except Exception:
        pass
    parties += ["## Fin du journal", _fin_journal()]
    return anonymiser("\n".join(parties))


def enregistrer(texte: str) -> Path:
    RAPPORTS.mkdir(parents=True, exist_ok=True)
    f = RAPPORTS / f"rapport-{time.strftime('%Y%m%d-%H%M%S')}.txt"
    f.write_text(texte, "utf-8")
    # on ne garde que les 15 derniers
    for vieux in sorted(RAPPORTS.glob("rapport-*.txt"))[:-15]:
        vieux.unlink(missing_ok=True)
    return f


#: adresse de contact du projet, pour qui n'a pas de compte GitHub
CONTACT = "oriongamelauncher@gmail.com"


def adresse_courriel(titre: str, description: str = "", erreur: str = "",
                     fichier: Path | None = None) -> str:
    """Lien « mailto: » deja rempli. Comme pour GitHub, l'utilisateur relit,
    joint le fichier s'il le souhaite, et envoie lui-meme."""
    corps = [
        "Ce qui s'est passé :",
        description.strip() or "(décrivez ce que vous faisiez)",
        "",
        f"Version : {APP_NAME} {APP_VERSION} · {platform.platform(terse=True)}",
    ]
    if erreur:
        corps += ["", "Erreur :", anonymiser(erreur.strip().splitlines()[-1][:300])]
    if fichier is not None:
        corps += ["", f"Rapport complet : joignez le fichier {fichier.name} "
                      "(dossier ouvert automatiquement)."]
    texte = "\n".join(corps)[:1500]
    return (f"mailto:{CONTACT}?subject={quote('[ORION] ' + titre[:120])}"
            f"&body={quote(texte)}")


# --------------------------------------------------------------------------
# Plantages
# --------------------------------------------------------------------------
_dernier_dialogue = 0.0
_rappel = None          # fonction de l'interface appelee pour proposer un signalement


def envoyer(titre: str, description: str = "", erreur: str = "",
            rapport_technique: str = "") -> int:
    """Envoie le signalement au service d'ORION, sans compte ni fichier a
    joindre. Rend son numero. Leve une exception si l'envoi echoue : l'appelant
    propose alors le courriel."""
    from . import partage
    from .core import reseau
    donnees = {
        "v": 1, "app": APP_VERSION, "poste": partage.poste(),
        "titre": titre[:200], "description": anonymiser(description)[:4000],
        "erreur": anonymiser(erreur)[:8000], "rapport": rapport_technique[:60000],
    }
    r = reseau.post(partage.SERVICE + "/signalement", json=donnees, timeout=25)
    if not 200 <= r.status_code < 300:
        raise RuntimeError(f"service : {r.status_code}")
    try:
        return int((r.json() or {}).get("numero") or 0)
    except Exception:
        return 0


def installer_gestionnaires(rappel=None) -> None:
    """Intercepte les erreurs non prevues du fil principal et des taches."""
    global _rappel
    _rappel = rappel
    sys.excepthook = _sur_erreur
    threading.excepthook = lambda a: _sur_erreur(a.exc_type, a.exc_value, a.exc_traceback)


def _sur_erreur(type_, valeur, trace) -> None:
    global _dernier_dialogue
    if issubclass(type_, (KeyboardInterrupt, SystemExit)):
        return
    texte = "".join(traceback.format_exception(type_, valeur, trace))
    log.error("Erreur non prevue :\n%s", texte)
    try:
        enregistrer(rapport(erreur=texte))
    except Exception:
        pass
    # un dialogue au plus toutes les 30 s : une erreur repetee en boucle
    # ne doit pas ensevelir l'utilisateur sous les fenetres
    if _rappel is not None and time.time() - _dernier_dialogue > 30:
        _dernier_dialogue = time.time()
        try:
            _rappel(texte)
        except Exception:
            pass


def _installation() -> str:
    try:
        from .maj import depuis_store
        if depuis_store():
            return "Microsoft Store"
    except Exception:
        pass
    return "installateur ou winget"


def _lire_temoin() -> dict:
    """Etat laisse par la session precedente. Ancien format (2.1.3 et avant) :
    l'heure de debut seule, lue comme une session « en cours »."""
    try:
        texte = TEMOIN.read_text("utf-8").strip()
    except OSError:
        return {}
    try:
        d = json.loads(texte)
        if isinstance(d, dict):
            return d
        return {"etat": "en_cours", "debut": float(d)}
    except (ValueError, TypeError):
        return {"etat": "en_cours"}


def _ecrire_temoin(**champs) -> None:
    try:
        TEMOIN.parent.mkdir(parents=True, exist_ok=True)
        TEMOIN.write_text(json.dumps(champs), "utf-8")
    except OSError:
        pass


def _lire_trace_native() -> str:
    try:
        texte = TRACE_NATIVE.read_text("utf-8", errors="replace").strip()
    except OSError:
        return ""
    return texte[-12000:]


def _activer_trace_native() -> None:
    """Ouvre la trace de la session qui commence. Le fichier reste ouvert
    jusqu'a la fermeture : `faulthandler` doit pouvoir y ecrire au moment
    meme du plantage, sans rien allouer."""
    global _trace_fichier
    try:
        TRACE_NATIVE.parent.mkdir(parents=True, exist_ok=True)
        _trace_fichier = open(TRACE_NATIVE, "w", encoding="utf-8")
        faulthandler.enable(file=_trace_fichier, all_threads=True)
    except (OSError, RuntimeError, ValueError):
        _trace_fichier = None


def _resume_precedente() -> list[str]:
    p = _precedente
    lignes = []
    etat = p.get("etat")
    if etat == "fermeture":
        duree = ""
        if p.get("demande") and p.get("vu"):
            duree = f", {max(0.0, p['vu'] - p['demande']):.0f} s apres la demande"
        lignes.append(f"Fin : coupee pendant la fermeture{duree}")
    elif etat == "en_cours":
        lignes.append("Fin : arretee pendant l'utilisation")
    if p.get("version"):
        lignes.append(f"Version : {p['version']}")
    if p.get("trace"):
        lignes += ["Trace native :", p["trace"]]
    return lignes


def ouvrir_session() -> bool:
    """Pose le temoin de session. Vrai si la session precedente s'est arretee
    brutalement PENDANT L'UTILISATION.

    Signalement du 17/10/2026 (ORION 2.1.2, premier lancement) : aucune erreur
    dans le journal. La fermeture de la 2.1.2 restait figee 5 s avant de
    retirer le temoin ; un processus coupe a ce moment (Windows « ne repond
    pas », gestionnaire des taches, outil de test) etait presente au joueur
    comme un plantage. Desormais la fermeture est notee des la demande
    (`marquer_fermeture`) : une session coupee pendant sa fermeture n'ouvre
    plus la question « ORION s'est arrete brutalement », sauf si une trace
    native prouve un vrai plantage."""
    global _precedente
    present = TEMOIN.exists()
    _precedente = _lire_temoin() if present else {}
    trace = _lire_trace_native()
    if _precedente:
        _precedente["vu"] = time.time()
        if trace:
            _precedente["trace"] = trace
    _activer_trace_native()
    _ecrire_temoin(etat="en_cours", debut=time.time(), version=APP_VERSION)
    if not present:
        return False
    if _precedente.get("etat") == "fermeture":
        log.info("Session precedente coupee pendant sa fermeture%s",
                 " (trace native presente)" if trace else " : pas un plantage")
        return bool(trace)
    log.warning("Session precedente arretee brutalement%s",
                " (trace native presente)" if trace else "")
    return True


def marquer_fermeture() -> None:
    """A appeler des que la fermeture est demandee : tout ce qui suit
    (ecriture finale, dernier envoi) peut etre long ou coupe sans que ce soit
    un plantage."""
    log.info("Fermeture demandee")
    prec = _lire_temoin()
    _ecrire_temoin(etat="fermeture", debut=prec.get("debut", time.time()),
                   demande=time.time(), version=APP_VERSION)


def fermer_session() -> None:
    global _trace_fichier
    try:
        TEMOIN.unlink(missing_ok=True)
    except OSError:
        pass
    # fin propre : la trace de cette session est vide, elle disparait
    try:
        faulthandler.disable()
    except Exception:
        pass
    if _trace_fichier is not None:
        try:
            _trace_fichier.close()
        except OSError:
            pass
        _trace_fichier = None
    try:
        TRACE_NATIVE.unlink(missing_ok=True)
    except OSError:
        pass
