"""Sources de detection de jeux.

Chaque module de ce paquet expose une ou plusieurs classes `Scanner`.
Le registre les charge automatiquement : aucun import a ajouter ici.
"""
