"""Images de la Boutique : chargees en arriere-plan, gardees en memoire et sur disque.

Une carte demande une liste d'adresses (la plus belle d'abord : banniere
sans texte, capsule, en-tete...) et une taille. Le chargeur :

* rend tout de suite l'image si elle est deja en memoire, a la bonne
  taille (aucun redimensionnement pendant le defilement) ;
* sinon la lit sur le disque ou la telecharge dans un fil de travail, la
  decode et la reduit la-bas, puis previent les cartes (`prete`) ;
* passe a l'adresse suivante si une image manque (404) et s'en souvient.

L'interface ne bloque jamais : la carte dessine un degrade en attendant.
Les fichiers sont ceux de `boutique.IMAGES` (meme nom que les vignettes
deja telechargees par `BoutiqueService.vignettes`).
"""
from __future__ import annotations

import hashlib
import time
from collections import OrderedDict
from pathlib import Path

from PySide6.QtCore import QObject, QRunnable, QSize, Qt, QThreadPool, Signal
from PySide6.QtGui import QImage, QPixmap

#: taille maximale gardee en memoire (largeur), selon l'usage
LARGEUR_MAX = 1600
#: une image introuvable n'est redemandee qu'apres ce delai (secondes) : une
#: coupure reseau ne doit pas priver la Boutique d'images pour toujours
OUBLI_ABSENT = 2 * 86400


def _absente(marque: Path) -> bool:
    try:
        return time.time() - marque.stat().st_mtime < OUBLI_ABSENT
    except OSError:
        return False


def fichier_cache(url: str) -> Path:
    from ...boutique import IMAGES
    return IMAGES / (hashlib.sha1(url.encode()).hexdigest()[:16] + ".jpg")


def telecharger(url: str, cible: Path) -> bool:
    """Telechargement d'une image (remplacable dans les tests)."""
    from ...plugins.artwork.base import download
    return download(url, cible)


class _Signaux(QObject):
    fini = Signal(str, QImage)          # adresse, image (nulle = echec)


class _Travail(QRunnable):
    def __init__(self, url: str, signaux: _Signaux, local: str = "") -> None:
        super().__init__()
        self.url, self.signaux, self.local = url, signaux, local
        self.setAutoDelete(True)

    def run(self) -> None:          # fil de travail
        image = QImage()
        try:
            chemin = Path(self.local) if self.local else fichier_cache(self.url)
            absent = chemin.with_suffix(".absent")
            if not (chemin.exists() and chemin.stat().st_size > 0):
                if self.local or _absente(absent):
                    raise FileNotFoundError(self.url)
                if not ChargeurImages.telecharger(self.url, chemin):
                    try:
                        absent.parent.mkdir(parents=True, exist_ok=True)
                        absent.touch()       # pas de nouvel essai a chaque demarrage
                    except OSError:
                        pass
                    raise FileNotFoundError(self.url)
            image = QImage(str(chemin))
            if not image.isNull() and image.width() > LARGEUR_MAX:
                image = image.scaledToWidth(LARGEUR_MAX,
                                            Qt.TransformationMode.SmoothTransformation)
        except Exception:
            image = QImage()
        try:
            self.signaux.fini.emit(self.url, image)
        except RuntimeError:
            pass                     # application en cours de fermeture


class ChargeurImages(QObject):
    """Chargeur partage par toutes les vues de la Boutique."""

    prete = Signal(str)             # une adresse vient d'aboutir (ou d'echouer)

    #: fonction de telechargement (url, chemin) -> bool
    telecharger = staticmethod(telecharger)
    _instance: "ChargeurImages | None" = None

    def __init__(self, parent=None, fils: int = 4, memoire: int = 220) -> None:
        super().__init__(parent)
        self._pool = QThreadPool(self)
        self._pool.setMaxThreadCount(fils)
        self._signaux = _Signaux(self)
        self._signaux.fini.connect(self._fini)
        self._sources: OrderedDict[str, QPixmap] = OrderedDict()   # url -> image
        self._tailles: OrderedDict[tuple, QPixmap] = OrderedDict()  # (url, w, h)
        self._memoire = memoire
        self._en_cours: set[str] = set()
        self._echecs: set[str] = set()
        self._locaux: dict[str, str] = {}

    @classmethod
    def instance(cls) -> "ChargeurImages":
        if cls._instance is None:
            cls._instance = ChargeurImages()
        return cls._instance

    # ------------------------------------------------------------------
    def local(self, url: str, chemin: str) -> None:
        """Image deja telechargee ailleurs pour cette adresse."""
        if url and chemin:
            self._locaux[url] = chemin

    def source(self, urls) -> tuple[str, QPixmap] | None:
        """(adresse, image d'origine) de la premiere adresse disponible, ou
        None en attendant (son chargement est alors lance)."""
        for url in urls or ():
            if not url or url in self._echecs:
                continue
            source = self._sources.get(url)
            if source is None:
                self._lancer(url)
                return None
            self._sources.move_to_end(url)
            return url, source
        return None

    def image(self, urls, taille: QSize) -> QPixmap | None:
        """L'image a la taille voulue si elle est prete, sinon None (et le
        chargement de la meilleure adresse disponible est lance)."""
        trouve = self.source(urls)
        if trouve is None:
            return None
        return self.a_la_taille(trouve[0], trouve[1], taille)

    def attendue(self, urls) -> bool:
        """Vrai si une des adresses peut encore donner une image."""
        return any(u and u not in self._echecs for u in urls or ())

    def precharger(self, urls) -> None:
        for url in urls or ():
            if url and url not in self._echecs:
                if url not in self._sources:
                    self._lancer(url)
                return

    def oublier_echecs(self) -> None:
        """Nouvel essai des adresses en echec (apres une actualisation)."""
        self._echecs.clear()

    def vider(self) -> None:
        self._sources.clear()
        self._tailles.clear()
        self._echecs.clear()

    # ------------------------------------------------------------------
    def _lancer(self, url: str) -> None:
        if url in self._en_cours:
            return
        self._en_cours.add(url)
        self._pool.start(_Travail(url, self._signaux, self._locaux.get(url, "")))

    def _fini(self, url: str, image: QImage) -> None:
        self._en_cours.discard(url)
        if image.isNull():
            self._echecs.add(url)
        else:
            self._sources[url] = QPixmap.fromImage(image)
            while len(self._sources) > self._memoire:
                vieux, _ = self._sources.popitem(last=False)
                for k in [k for k in self._tailles if k[0] == vieux]:
                    del self._tailles[k]
        self.prete.emit(url)

    def a_la_taille(self, url: str, source: QPixmap, taille: QSize,
                    transformer=None) -> QPixmap:
        cle = (url, taille.width(), taille.height(),
               getattr(transformer, "__name__", ""))
        pix = self._tailles.get(cle)
        if pix is not None:
            self._tailles.move_to_end(cle)
            return pix
        pix = (transformer or recadrer)(source, taille)
        self._tailles[cle] = pix
        while len(self._tailles) > self._memoire * 2:
            self._tailles.popitem(last=False)
        return pix


def recadrer(source: QPixmap, taille: QSize) -> QPixmap:
    """Remplit `taille` en recadrant au centre (sans deformer)."""
    if taille.isEmpty():
        return source
    scaled = source.scaled(taille, Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                           Qt.TransformationMode.SmoothTransformation)
    x = max(0, (scaled.width() - taille.width()) // 2)
    y = max(0, (scaled.height() - taille.height()) // 3)   # un peu vers le haut
    return scaled.copy(x, y, taille.width(), taille.height())
