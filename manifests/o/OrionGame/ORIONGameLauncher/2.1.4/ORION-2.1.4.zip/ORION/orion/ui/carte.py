"""La carte a partager (2.0.2) : une image 1200 x 630 qui dit ce que le PC
fait tourner, ce que vaut la bibliotheque, et d'ou ca vient.

« Mon PC fait tourner 38 de mes 52 jeux en qualite Haute » est la seule publicite
qui grandit toute seule : un joueur la poste, ses amis cherchent ORION.
L'image ne porte rien de personnel : pas de nom, pas de pseudo, pas de
chemin, seulement les chiffres du bilan, le processeur et la carte
graphique (ce qu'on ecrit sur n'importe quel forum), et l'adresse du site.
Tout est dessine avec Qt, sans dependance supplementaire.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from PySide6.QtCore import QRect, QRectF, Qt
from PySide6.QtGui import QColor, QFont, QImage, QLinearGradient, QPainter, QPen, QPixmap

from ..core.paths import ROOT_DIR
from .theme import PALETTE

LARGEUR, HAUTEUR = 1200, 630
SITE = "orion-launcher.com"


@dataclass
class Carte:
    titre: str                              # « Mon PC fait tourner 38 de mes 52 jeux en qualite Haute »
    sous_titre: str = ""                    # « Environ 60 images par seconde en 1080p »
    lignes: list[str] = field(default_factory=list)   # trois lignes au plus : bibliotheque, pilotes, machine
    pied: str = f"{SITE} · gratuit, sans compte, sans publicite"


def depuis_bilan(bilan, hw) -> Carte:
    """Les chiffres du bilan (orion.bilan) et la machine, en une carte."""
    from ..i18n import t as _t
    lignes_b = list(getattr(bilan, "lignes", []) or [])
    titre = _t("Mon PC et mes jeux, lus par ORION")
    sous = biblio = pilotes = ""
    for l in lignes_b:
        t = l.titre
        if t.startswith("Votre PC fait tourner"):
            titre = _a_la_premiere_personne(_t(t))
            sous = _t(l.details[0]).split(",")[0] if l.details else ""
        elif t.startswith("Votre bibliotheque vaut"):
            biblio = _a_la_premiere_personne(_t(t))
        elif "pilote" in t.lower() and ("mettre a jour" in t or t == "Pilotes a jour"):
            pilotes = _t(t)
            pilotes = pilotes[0].upper() + pilotes[1:]
    machine = " · ".join(x for x in (getattr(hw, "cpu_name", "") or "",
                                     getattr(getattr(hw, "gpu", None), "name", "") or "") if x)
    return Carte(titre, sous, [x for x in (biblio, pilotes, machine) if x],
                 pied=_t("orion-launcher.com · gratuit, sans compte, sans publicite"))


def _a_la_premiere_personne(texte: str) -> str:
    """« Votre PC fait tourner 38 de vos 52 jeux » -> « Mon PC fait tourner 38
    de mes 52 jeux » (et l'anglais : Your -> My)."""
    for a, b in (("Votre PC", "Mon PC"), ("vos ", "mes "), ("votre jeu", "mon jeu"),
                 ("Votre bibliothèque", "Ma bibliothèque"), ("Votre bibliotheque", "Ma bibliotheque"),
                 ("Your PC", "My PC"), ("your ", "my "), ("Your library", "My library")):
        texte = texte.replace(a, b)
    return texte


def dessiner(carte: Carte) -> QImage:
    """L'image, prete a enregistrer ou a copier."""
    img = QImage(LARGEUR, HAUTEUR, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(QColor(PALETTE["bg"]))
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setRenderHint(QPainter.RenderHint.TextAntialiasing)
    # fond : un degrade sobre, un trait d'accent
    g = QLinearGradient(0, 0, LARGEUR, HAUTEUR)
    g.setColorAt(0.0, QColor(PALETTE["bg_alt"]))
    g.setColorAt(1.0, QColor(PALETTE["surface"]))
    p.fillRect(img.rect(), g)
    p.fillRect(QRect(0, 0, 14, HAUTEUR), QColor(PALETTE["accent"]))
    # logo et nom
    logo = ROOT_DIR / "orion" / "ui" / "assets" / "orion.png"
    x = 64
    if Path(logo).exists():
        pm = QPixmap(str(logo)).scaled(72, 72, Qt.AspectRatioMode.KeepAspectRatio,
                                       Qt.TransformationMode.SmoothTransformation)
        p.drawPixmap(x, 56, pm)
        x += 92
    p.setPen(QColor(PALETTE["text"]))
    p.setFont(QFont("Segoe UI", 30, QFont.Weight.Bold))
    p.drawText(QRect(x, 56, 800, 72), int(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft), "ORION")
    from ..i18n import t as _t
    p.setPen(QColor(PALETTE["text_faint"]))
    p.setFont(QFont("Segoe UI", 16))
    p.drawText(QRect(x + 150, 56, 900, 72), int(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft),
               _t("lit votre PC et vous dit quoi jouer, avec quels reglages, a quel prix"))
    # titre
    p.setPen(QColor(PALETTE["text"]))
    p.setFont(QFont("Segoe UI", 44, QFont.Weight.Bold))
    p.drawText(QRectF(64, 170, LARGEUR - 128, 170),
               int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter | Qt.TextFlag.TextWordWrap),
               carte.titre)
    y = 352
    if carte.sous_titre:
        p.setPen(QColor(PALETTE["accent"]))
        p.setFont(QFont("Segoe UI", 19))
        p.drawText(QRectF(64, y, LARGEUR - 128, 40), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
                   carte.sous_titre)
        y += 54
    p.setPen(QPen(QColor(PALETTE["border_hi"]), 2))
    p.drawLine(64, y, LARGEUR - 64, y)
    y += 24
    p.setFont(QFont("Segoe UI", 20))
    for l in carte.lignes[:3]:
        p.setPen(QColor(PALETTE["accent"]))
        p.drawText(QRectF(64, y, 24, 36), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), "•")
        p.setPen(QColor(PALETTE["text_dim"]))
        p.drawText(QRectF(92, y, LARGEUR - 156, 36), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), l)
        y += 42
    # pied
    p.setPen(QColor(PALETTE["text_faint"]))
    p.setFont(QFont("Segoe UI", 17))
    p.drawText(QRect(64, HAUTEUR - 70, LARGEUR - 128, 40), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
               carte.pied)
    p.end()
    return img


def enregistrer(img: QImage, chemin) -> bool:
    return bool(img.save(str(chemin), "PNG"))
