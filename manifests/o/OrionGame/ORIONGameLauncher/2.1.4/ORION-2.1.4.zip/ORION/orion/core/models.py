"""Modeles de donnees partages par tous les modules.

Un scanner produit des `Game`, une sonde produit `HardwareInfo` et `Display`,
l'optimiseur consomme les deux et produit un `OptimizationPlan`.
Ces structures sont le contrat entre les modules : les respecter suffit pour
brancher un nouveau plugin.
"""
from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field, asdict
from typing import Any

# --------------------------------------------------------------------------
# Jeux
# --------------------------------------------------------------------------

_CLEAN_RE = re.compile(r"[^a-z0-9]+")
_NOISE = (
    "gotyedition", "goty", "definitiveedition", "deluxeedition", "ultimateedition",
    "standardedition", "remastered", "directorscut", "repack", "fitgirl", "dodi",
    "elamigos", "codex", "plaza", "skidrow", "cracked",
)


def normalize_title(title: str) -> str:
    """Cle de comparaison d'un titre (sert au dedoublonnage et a la recherche)."""
    s = _CLEAN_RE.sub("", (title or "").lower())
    for n in _NOISE:
        s = s.replace(n, "")
    return s


@dataclass
class Game:
    """Un jeu detecte sur la machine."""

    # -- Identite ---------------------------------------------------------
    title: str
    source: str                      # "steam", "epic", "gog", "dossier"...
    source_id: str = ""              # identifiant natif (appid Steam, etc.)
    uid: str = ""                    # identifiant stable interne

    # -- Emplacement / lancement -----------------------------------------
    install_dir: str = ""
    executable: str = ""
    launch_uri: str = ""             # steam://..., uplay://..., etc.
    launch_args: list[str] = field(default_factory=list)
    working_dir: str = ""

    # -- Metadonnees ------------------------------------------------------
    size_bytes: int = 0
    engine: str = ""                 # "unreal", "unity", "source", ...
    installed_at: float = 0.0
    last_updated: float = 0.0
    store_url: str = ""
    update_pending: bool = False     # une mise a jour attend d'etre installee

    # -- Visuels (chemins locaux dans le cache) ---------------------------
    art_cover: str = ""              # jaquette verticale 600x900
    art_hero: str = ""               # banniere large
    art_logo: str = ""
    art_icon: str = ""
    accent_color: str = ""           # "#RRGGBB" deduit de la jaquette

    # -- Suivi utilisateur ------------------------------------------------
    favorite: bool = False
    hidden: bool = False
    play_seconds: int = 0            # temps compte par ORION
    external_seconds: int = 0        # temps deja compte par la plateforme
    last_played: float = 0.0
    preferred_profile: str = ""      # profil applique par defaut
    preferred_display: str = ""      # ex. "\\\\.\\DISPLAY1"
    notes: str = ""

    extra: dict[str, Any] = field(default_factory=dict)

    # ---------------------------------------------------------------
    def __post_init__(self) -> None:
        if not self.uid:
            self.uid = self.compute_uid()

    def compute_uid(self) -> str:
        base = f"{self.source}:{self.source_id or self.install_dir or self.title}"
        return hashlib.sha1(base.encode("utf-8", "ignore")).hexdigest()[:16]

    @property
    def key(self) -> str:
        """Cle de dedoublonnage entre sources."""
        return normalize_title(self.title)

    @property
    def total_play_seconds(self) -> int:
        """Temps de jeu total : celui de la plateforme + celui d'ORION."""
        return int(self.external_seconds) + int(self.play_seconds)

    @property
    def size_gb(self) -> float:
        return round(self.size_bytes / (1024 ** 3), 1) if self.size_bytes else 0.0

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Game":
        known = {f for f in cls.__dataclass_fields__}      # noqa: F821
        return cls(**{k: v for k, v in d.items() if k in known})


# --------------------------------------------------------------------------
# Materiel et ecrans
# --------------------------------------------------------------------------

@dataclass
class DisplayMode:
    width: int
    height: int
    refresh: int
    bpp: int = 32

    def __str__(self) -> str:
        return f"{self.width}x{self.height} @ {self.refresh} Hz"

    @property
    def pixels(self) -> int:
        return self.width * self.height

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Display:
    device: str                      # "\\\\.\\DISPLAY1"
    name: str = ""                   # "LG ULTRAGEAR"
    primary: bool = False
    current: DisplayMode | None = None
    native: DisplayMode | None = None     # mode de plus haute definition
    max_refresh_at_native: int = 60
    modes: list[DisplayMode] = field(default_factory=list)
    position: tuple[int, int] = (0, 0)
    hdr: bool = False

    def modes_for(self, width: int, height: int) -> list[DisplayMode]:
        return sorted(
            (m for m in self.modes if m.width == width and m.height == height),
            key=lambda m: m.refresh, reverse=True,
        )

    def best_refresh(self, width: int, height: int) -> int:
        lst = self.modes_for(width, height)
        return lst[0].refresh if lst else (self.current.refresh if self.current else 60)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["current"] = self.current.to_dict() if self.current else None
        d["native"] = self.native.to_dict() if self.native else None
        d["modes"] = [m.to_dict() for m in self.modes]
        return d


@dataclass
class GPUInfo:
    name: str = ""
    vendor: str = ""                 # nvidia / amd / intel
    vram_mb: int = 0
    driver_version: str = ""
    driver_date: str = ""
    tier: int = 0                    # 0 entree, 1 milieu, 2 haut, 3 tres haut
    features: list[str] = field(default_factory=list)   # dlss, fsr, rt, framegen

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class HardwareInfo:
    cpu_name: str = ""
    cpu_cores: int = 0
    cpu_threads: int = 0
    cpu_ghz: float = 0.0
    ram_gb: float = 0.0
    os_name: str = ""
    os_build: str = ""
    gpus: list[GPUInfo] = field(default_factory=list)
    displays: list[Display] = field(default_factory=list)
    disks: list[dict] = field(default_factory=list)
    score: int = 0                   # note de synthese 0-100

    @property
    def gpu(self) -> GPUInfo:
        """GPU principal (le premier qui n'est pas virtuel)."""
        return self.gpus[0] if self.gpus else GPUInfo()

    @property
    def primary_display(self) -> Display | None:
        for d in self.displays:
            if d.primary:
                return d
        return self.displays[0] if self.displays else None

    def to_dict(self) -> dict:
        return {
            "cpu_name": self.cpu_name, "cpu_cores": self.cpu_cores,
            "cpu_threads": self.cpu_threads, "cpu_ghz": self.cpu_ghz,
            "ram_gb": self.ram_gb, "os_name": self.os_name, "os_build": self.os_build,
            "gpus": [g.to_dict() for g in self.gpus],
            "displays": [d.to_dict() for d in self.displays],
            "disks": self.disks, "score": self.score,
        }


# --------------------------------------------------------------------------
# Optimisation
# --------------------------------------------------------------------------

@dataclass
class TweakOp:
    """Une modification unitaire a appliquer (fichier INI ou registre)."""
    kind: str                        # "ini" | "registry" | "note"
    target: str                      # chemin du fichier ou cle de registre
    section: str = ""
    key: str = ""
    value: str = ""
    current: str | None = None       # valeur lue avant modification
    label: str = ""                  # libelle lisible pour l'apercu

    @property
    def changed(self) -> bool:
        return str(self.current) != str(self.value)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class OptimizationPlan:
    """Ce qu'ORION s'apprete a faire : ecran + reglages + conseils."""
    game_uid: str = ""
    profile: str = ""
    display_device: str = ""
    display_mode: DisplayMode | None = None
    display_current: DisplayMode | None = None
    ops: list[TweakOp] = field(default_factory=list)
    advice: list[str] = field(default_factory=list)
    recipe_name: str = ""
    confidence: str = "generique"    # "exact" | "moteur" | "generique"
    #: reglages a recopier a la main quand ORION ne peut rien ecrire dans
    #: le jeu (voir optimizer/guide.py) ; vide quand il regle tout lui-meme
    guide: list = field(default_factory=list)

    @property
    def has_changes(self) -> bool:
        return any(o.changed for o in self.ops if o.kind != "note")

    @property
    def tunable(self) -> bool:
        """Vrai si ORION peut reellement ecrire des reglages dans le jeu.

        Certains jeux ne stockent rien de lisible sur le disque : moteur
        maison, reglages dans le nuage, ou configuration creee seulement
        apres une premiere partie. ORION ne doit alors rien promettre : le
        jeu reste dans la bibliotheque, avec sa jaquette et son visuel, il
        se lance normalement, mais aucun profil graphique n'est propose.
        """
        return any(o.kind != "note" for o in self.ops)

    @property
    def display_changes(self) -> bool:
        if not self.display_mode or not self.display_current:
            return False
        a, b = self.display_mode, self.display_current
        return (a.width, a.height, a.refresh) != (b.width, b.height, b.refresh)
