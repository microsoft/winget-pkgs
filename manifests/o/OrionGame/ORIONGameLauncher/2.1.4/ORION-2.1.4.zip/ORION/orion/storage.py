"""Menage du stockage : quels jeux occupent de la place pour rien.

ORION croise la taille sur le disque, la date de la derniere partie et le
temps de jeu pour classer les candidats a la desinstallation. Il ne supprime
jamais rien lui-meme : il ouvre le desinstalleur de la plateforme concernee,
apres avoir propose d'archiver la sauvegarde.
"""
from __future__ import annotations

import os
import shutil
import time
from dataclasses import dataclass
from pathlib import Path, PureWindowsPath

from .core.logging_setup import get
from .core.models import Game, HardwareInfo
from .core.winutil import HKCU, HKLM, reg_subkeys, reg_values

log = get("stockage")

DAY = 86400
#: jours pendant lesquels un jeu tout juste installe n'est pas dit « dormant »
RECENT = 14


@dataclass
class Candidate:
    """Un jeu propose au menage, avec la raison."""
    game: Game
    reason: str
    score: float
    days_idle: float

    @property
    def size_gb(self) -> float:
        return self.game.size_gb

    @property
    def played_label(self) -> str:
        total = self.game.total_play_seconds
        if total < 60:
            return "jamais joue"
        if total < 3600:
            return f"{total // 60} min de jeu"
        return f"{total // 3600} h de jeu"

    @property
    def last_label(self) -> str:
        if not self.game.last_played:
            return "aucune partie enregistree"
        months = self.days_idle / 30.0
        if months >= 1:
            return f"pas lance depuis {months:.0f} mois"
        return f"derniere partie il y a {self.days_idle:.0f} jours"


@dataclass
class Entry:
    """Un jeu installe, avec son disque et l'avis d'ORION sur son sort."""
    game: Game
    disk: str                          # lettre ou point de montage
    reason: str = ""                   # pourquoi il est propose au menage
    score: float = 0.0
    days_idle: float = 0.0
    installe: bool = True              # faux : desinstalle, mais sauvegarde

    @property
    def dormant(self) -> bool:
        return bool(self.reason)

    @property
    def sauvegardes(self) -> list[dict]:
        """Copies du jeu sur d'autres disques (`game.extra`), plus recente
        en premier."""
        brut = (self.game.extra or {}).get("sauvegardes_disque") or []
        valides = [s for s in brut if isinstance(s, dict) and s.get("chemin")]
        return sorted(valides, key=lambda s: -(s.get("date") or 0))

    @property
    def disques_sauvegarde(self) -> list[str]:
        vus: list[str] = []
        for s in self.sauvegardes:
            lettre = disk_letter(s["chemin"]).upper()
            if lettre and lettre not in vus:
                vus.append(lettre)
        return vus

    @property
    def sauvegarde_label(self) -> str:
        """« F: · 12/09/2026 », « F:, G: · 12/09/2026 » ou « aucune »."""
        sauvegardes = self.sauvegardes
        if not sauvegardes:
            return "aucune"
        date = sauvegardes[0].get("date")
        quand = time.strftime("%d/%m/%Y", time.localtime(date)) if date else ""
        return ", ".join(self.disques_sauvegarde) + (f"  ·  {quand}" if quand else "")

    @property
    def size_gb(self) -> float:
        return self.game.size_gb

    @property
    def size_label(self) -> str:
        size = self.game.size_gb
        if size >= 1:
            return f"{size:.0f} Go"
        if self.game.size_bytes:
            return f"{self.game.size_bytes / (1024 ** 2):.0f} Mo"
        return "taille inconnue"

    @property
    def played_label(self) -> str:
        total = self.game.total_play_seconds
        if total < 60:
            return "jamais joue"
        if total < 3600:
            return f"{total // 60} min"
        return f"{total // 3600} h"

    @property
    def last_label(self) -> str:
        if not self.game.last_played:
            return "jamais"
        months = self.days_idle / 30.0
        if self.days_idle < 1:
            return "aujourd'hui"
        if self.days_idle < 2:
            return "hier"
        if months >= 1:
            return f"il y a {months:.0f} mois"
        return f"il y a {self.days_idle:.0f} jours"

    @property
    def state_label(self) -> str:
        if not self.installe:
            return "desinstalle  ·  sauvegarde disponible"
        if self.game.extra.get("deplace"):
            return "deplace (ancienne methode)"
        return self.reason or "en service"


def disk_letter(path: str) -> str:
    """Lettre du disque d'un chemin (« D: »), ou son point de montage.

    Les chemins analyses sont ceux de Windows, y compris quand ORION est
    execute ailleurs pour ses essais : `PureWindowsPath` les comprend sur
    toutes les plateformes, contrairement a `Path`.
    """
    if not path:
        return ""
    brut = str(path)
    if len(brut) > 1 and brut[1] == ":":
        return brut[:2].upper()
    ancre = str(PureWindowsPath(brut).anchor).rstrip("\\/")
    if ancre:
        return ancre
    return str(Path(brut).anchor).rstrip("\\/") or "/"


def inventory(games: list[Game], hw: HardwareInfo) -> list[Entry]:
    """Tous les jeux presents sur le disque, du plus gros au plus petit.

    La page stockage repond d'abord a « qu'est-ce qui occupe mes disques ? ».
    Elle montre donc tout ce qui est installe, et signale au passage ce qui
    dort ; l'ancienne version ne listait que les candidats au menage, ce qui
    donnait l'impression que des jeux manquaient.
    """
    now = time.time()
    dormants = {c.game.uid: c for c in analyse(games, hw)}
    out: list[Entry] = []
    for game in games:
        if not game.install_dir:
            continue
        sauvegarde = bool(game.extra.get("sauvegardes_disque"))
        if game.extra.get("missing") and not sauvegarde:
            continue
        last = game.last_played or game.last_updated or game.installed_at
        days_idle = (now - last) / DAY if last else 999
        candidat = dormants.get(game.uid)
        installe = not game.extra.get("missing")
        out.append(Entry(
            game=game,
            # un jeu deplace par ORION occupe le disque de destination
            disk=disk_letter((game.extra.get("deplace") or {}).get("vers")
                             or game.install_dir),
            reason=candidat.reason if candidat and installe else "",
            score=candidat.score if candidat and installe else 0.0,
            days_idle=days_idle,
            installe=installe))
    # les jeux installes d'abord, du plus gros au plus petit
    out.sort(key=lambda e: (not e.installe, -e.game.size_bytes))
    return out


def disks_in_use(entries: list[Entry], hw: HardwareInfo) -> list[dict]:
    """Disques qui portent au moins un jeu, avec ce qu'ils contiennent.

    Un disque annonce par le systeme mais sans aucun jeu n'a rien a faire
    sur cette page ; un disque qui porte des jeux sans etre reconnu par la
    sonde y figure quand meme, avec ce qu'on sait de lui.
    """
    par_lettre: dict[str, dict] = {}
    for disque in hw.disks:
        cle = str(disque.get("mount", "")).rstrip("\\/").upper()
        if cle:
            par_lettre[cle] = dict(disque)

    utilises: dict[str, dict] = {}

    def disque(cle: str) -> dict:
        info = utilises.setdefault(cle, dict(par_lettre.get(cle, {"mount": cle})))
        # disque connu seulement par une fiche (sauvegarde sur un disque
        # externe debranche...) : signale, une fois la sonde passee
        info.setdefault("absent", bool(par_lettre) and cle not in par_lettre)
        for champ in ("jeux", "sauvegardes"):
            info.setdefault(champ, 0)
        for champ in ("jeux_go", "dormants_go", "sauvegardes_go"):
            info.setdefault(champ, 0.0)
        return info

    for entry in entries:
        cle = entry.disk.upper()
        if cle and entry.installe:
            info = disque(cle)
            info["jeux"] += 1
            info["jeux_go"] = round(info["jeux_go"] + entry.size_gb, 1)
            info["dormants_go"] = round(
                info["dormants_go"] + (entry.size_gb if entry.dormant else 0), 1)
        # une sauvegarde occupe le disque ou elle se trouve
        for sauvegarde in entry.sauvegardes:
            lettre = disk_letter(sauvegarde["chemin"]).upper()
            if not lettre:
                continue
            info = disque(lettre)
            info["sauvegardes"] += 1
            info["sauvegardes_go"] = round(
                info["sauvegardes_go"] + (sauvegarde.get("octets") or 0) / 1024 ** 3, 1)
    return [utilises[cle] for cle in sorted(utilises)]


# --------------------------------------------------------------------------
# Recalcul (bouton « Recalculer »)
# --------------------------------------------------------------------------

def taille_dossier(dossier: str) -> int:
    """Taille reelle d'un dossier, sans limite de fichiers. Les liens a
    l'interieur ne sont pas suivis (un jeu deplace se mesure depuis son
    ancien emplacement : la jonction de depart, elle, est suivie)."""
    total = 0
    pile = [str(dossier)]
    while pile:
        courant = pile.pop()
        try:
            with os.scandir(courant) as entrees:
                for e in entrees:
                    try:
                        if e.is_dir(follow_symlinks=False):
                            if not e.is_symlink() and not (
                                    hasattr(e, "is_junction") and e.is_junction()):
                                pile.append(e.path)
                        elif e.is_file(follow_symlinks=False):
                            total += e.stat(follow_symlinks=False).st_size
                    except OSError:
                        continue
        except OSError:
            continue
    return total


def mesurer_stockage(jeux: list[tuple[str, str]], montages: list[str],
                     progress_cb=None, detecter: bool = False) -> dict:
    """Remesure les jeux installes et la place libre des disques.

    `jeux` : (uid, dossier) ; `montages` : racines des disques (« C:\\ »).
    Rend `{"tailles": {uid: octets}, "disques": {montage: {...}},
    "heure": horodatage, "liste_disques"?: [...]}` ; `detecter` relit la
    liste des disques (ceux branches depuis la derniere analyse y entrent).
    Tourne en tache de fond (peut prendre une minute sur une grosse
    bibliotheque).
    """
    tailles: dict[str, int] = {}
    n = len(jeux)
    for i, (uid, dossier) in enumerate(jeux):
        if progress_cb:
            progress_cb(f"Mesure des jeux ({i + 1}/{n})", int(i * 95 / max(n, 1)))
        if dossier and os.path.isdir(dossier):
            tailles[uid] = taille_dossier(dossier)
    disques: dict[str, dict] = {}
    for montage in montages:
        try:
            u = shutil.disk_usage(montage)
        except (OSError, ValueError):
            continue
        if u.total <= 0:
            continue
        disques[montage] = {"total_gb": round(u.total / 1024 ** 3),
                            "free_gb": round(u.free / 1024 ** 3),
                            "percent_used": round(u.used / u.total * 100)}
    resultat = {"tailles": tailles, "disques": disques, "heure": time.time()}
    if detecter:
        # disques branches depuis la derniere analyse (disque externe...)
        try:
            from .hardware.probe import _disks
            resultat["liste_disques"] = _disks()
        except Exception:
            log.exception("Liste des disques illisible")
    if progress_cb:
        progress_cb("Mesure terminee", 100)
    return resultat


def analyse(games: list[Game], hw: HardwareInfo) -> list[Candidate]:
    """Classe les jeux du plus au moins interessant a desinstaller."""
    now = time.time()
    out: list[Candidate] = []

    for game in games:
        if game.extra.get("missing") or not game.install_dir:
            continue
        size_gb = game.size_gb
        if size_gb < 1:
            continue

        played = game.total_play_seconds
        last = game.last_played or game.last_updated or game.installed_at
        days_idle = (now - last) / DAY if last else 999

        # Un gros jeu jamais lance et qui dort depuis longtemps remonte.
        score = size_gb
        if played < 600:                       # moins de dix minutes
            # un jeu installe ces jours-ci n'est pas « oublie » : il attend
            # d'etre lance (il etait signale des le lendemain de l'installation)
            if game.installed_at and now - game.installed_at < RECENT * DAY:
                continue
            score *= 3.0
            reason = "installe mais jamais vraiment joue"
        elif days_idle > 180:
            score *= 2.0
            reason = "aucune partie depuis plus de six mois"
        elif days_idle > 90:
            score *= 1.4
            reason = "aucune partie depuis plus de trois mois"
        else:
            continue                           # jeu encore actif : on ne touche pas

        if game.favorite:
            score *= 0.3
            reason += " (mais marque comme favori)"

        out.append(Candidate(game, reason, score, days_idle))

    out.sort(key=lambda c: -c.score)
    return out


# --------------------------------------------------------------------------
# Desinstallation
# --------------------------------------------------------------------------

def uninstall_command(game: Game) -> tuple[str, str]:
    """(commande a executer, description) pour desinstaller ce jeu."""
    if game.source == "steam" and game.source_id:
        return (f"steam://uninstall/{game.source_id}",
                "Steam va demander confirmation.")
    if game.source == "epic":
        ns = game.extra.get("namespace", "")
        cid = game.extra.get("catalog_item", "")
        app = game.source_id
        if ns and cid and app:
            return (f"com.epicgames.launcher://apps/{ns}%3A{cid}%3A{app}"
                    "?action=uninstall",
                    "L'Epic Games Launcher va demander confirmation.")
        return ("com.epicgames.launcher://apps",
                "Ouvre l'Epic Games Launcher : desinstallez depuis la "
                "bibliotheque.")
    if game.source == "ubisoft" and game.source_id:
        return (f"uplay://uninstall/{game.source_id}",
                "Ubisoft Connect va demander confirmation.")
    if game.source == "xbox":
        return ("ms-settings:appsfeatures",
                "Ouvre les applications installees de Windows.")
    if game.source == "ankama":
        # 10 octobre (capture de l'auteur, Dofus Retro) : les jeux Ankama se
        # desinstallent par l'Ankama Launcher, pas en supprimant le dossier
        from .plugins.scanners.ankama import lanceur
        exe = lanceur()
        if exe:
            return (f'"{exe}"', f"L'Ankama Launcher s'ouvre : desinstallez {game.title} depuis sa page "
                                "(roue crantee, Desinstaller).")

    uninstaller = _registry_uninstaller(game)
    if uninstaller:
        return uninstaller, "Lance le desinstalleur du jeu."
    if game.install_dir:
        return game.install_dir, ("Aucun desinstalleur declare : ORION ouvre "
                                  "le dossier, a vous de le supprimer.")
    return "", "Aucun moyen de desinstallation trouve."


def _registry_uninstaller(game: Game) -> str:
    """Cherche la commande de desinstallation dans la base de registre."""
    bases = (
        (HKLM, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
        (HKLM, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"),
        (HKCU, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
    )
    target = (game.install_dir or "").lower().rstrip("\\/")
    title = game.title.lower()
    for root, base in bases:
        for sub in reg_subkeys(root, base):
            values = reg_values(root, f"{base}\\{sub}")
            location = str(values.get("InstallLocation") or "").lower().rstrip("\\/")
            name = str(values.get("DisplayName") or "").lower()
            if (target and location == target) or (name and name == title):
                command = str(values.get("QuietUninstallString")
                              or values.get("UninstallString") or "")
                if command:
                    return command
    return ""
