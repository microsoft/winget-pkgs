"""Profils de jeu et traduction en reglages concrets.

Un profil decrit une *intention* ("je veux le maximum d'images par seconde").
`compute_settings` transforme cette intention en valeurs precises en tenant
compte du materiel reel et de l'ecran choisi : c'est la que se joue
l'optimisation.

Ajouter un profil = ajouter une entree dans `PROFILES`. Rien d'autre.

Le profil « Recommande » (profil par defaut) ne fixe pas de niveau : il
choisit, jeu par jeu, le plus beau niveau qui tient l'objectif d'images par
seconde sur CE PC (voir `recommande.py`).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..core.logging_setup import get
from ..core.models import Display, DisplayMode, Game, HardwareInfo

log = get("optimizer.profils")

# Echelle de qualite commune : 0 = bas, 1 = moyen, 2 = eleve, 3 = maximum
# memes noms que les niveaux du profil Recommande et de « Ma machine »
QUALITY_NAMES = {0: "Basse", 1: "Moyenne", 2: "Haute", 3: "Ultra"}


@dataclass
class Profile:
    id: str
    label: str
    tagline: str
    description: str
    accent: str
    quality: int                  # niveau de qualite vise
    latency_first: bool = False   # privilegier la latence sur l'image
    allow_upscaling: bool = True
    allow_frame_gen: bool = False
    allow_ray_tracing: bool = False
    vsync: bool = False
    cap_to_refresh: bool = True   # limiter les fps sous le taux de l'ecran
    fullscreen_exclusive: bool = True
    effects: dict[str, Any] = field(default_factory=dict)


PROFILES: dict[str, Profile] = {
    "recommande": Profile(
        id="recommande", label="Votre ecran", tagline="Le plus beau reglage qui tient votre objectif",
        description=(
            "La plus belle image qui reste fluide sur votre PC : ORION choisit "
            "le niveau (Ultra, Haute, Moyenne ou Basse) et la super-resolution "
            "qui exploitent votre ecran au maximum (144 images par seconde sur "
            "un ecran 144 Hz). Si le materiel ne suit pas, il vise le plus haut "
            "palier tenable et y pose la limite d'images. Il se corrige apres "
            "chaque partie mesuree."
        ),
        accent="#3DDC97", quality=2,
        allow_upscaling=True, allow_frame_gen=False, allow_ray_tracing=False,
        vsync=False, cap_to_refresh=True, fullscreen_exclusive=True,
        effects={"motion_blur": False, "depth_of_field": True, "bloom": True,
                 "film_grain": False, "chromatic": False, "vignette": True},
    ),
}

ORDER = ["recommande"]

#: anciens profils (Esport, Detente, Photorealiste, jusqu'a la 2.0.2) : un
#: jeu ou un reglage qui les cite retombe sur le profil unique
ANCIENS = {"esport", "detente", "photo"}

PROFIL_DEFAUT = "recommande"


def profil_par_defaut() -> str:
    """Profil applique aux jeux pour lesquels rien n'a ete choisi."""
    from ..core.config import CONFIG
    pid = str(CONFIG.get("optimizer.default_profile", PROFIL_DEFAUT) or "")
    return pid if pid in PROFILES else PROFIL_DEFAUT


def profil_valide(pid: str | None) -> str:
    """Le profil moteur a utiliser pour un identifiant memorise (les anciens
    noms Esport / Detente / Photorealiste retombent sur le profil unique)."""
    return pid if pid in PROFILES else profil_par_defaut()


def migrer_profil_par_defaut() -> bool:
    """Une seule fois : « Recommande » devient le profil par defaut.

    L'ancien defaut (« detente ») etait celui de tout le monde ; un choix
    fait apres cette migration n'est plus jamais touche."""
    from ..core.config import CONFIG
    if CONFIG.get("optimizer.recommande_migre"):
        return False
    if CONFIG.get("optimizer.default_profile") in (None, "", "detente"):
        CONFIG.set("optimizer.default_profile", PROFIL_DEFAUT, save=False)
    CONFIG.set("optimizer.recommande_migre", True)
    return True


# --------------------------------------------------------------------------
# Choix du mode d'affichage
# --------------------------------------------------------------------------

def choose_display_mode(profile: Profile, hw: HardwareInfo,
                        display: Display) -> DisplayMode | None:
    """Resolution et frequence a appliquer a l'ecran.

    Regle generale : on reste toujours en definition native (mettre une
    definition inferieure sur un ecran plat degrade l'image), et on monte la
    frequence au maximum permis par cette definition. Seule exception : un
    GPU d'entree de gamme face a un ecran haute definition en profil esport.
    """
    if not display or not display.modes:
        return None
    native = display.native or display.current
    if native is None:
        return None

    width, height = native.width, native.height
    gpu = hw.gpu

    if profile.latency_first and gpu.tier <= 1 and native.pixels > 2_400_000:
        # 4K ou ultra-large sur une carte modeste : on descend d'un cran
        for cand in ((2560, 1440), (1920, 1080)):
            if display.modes_for(*cand):
                width, height = cand
                break

    refresh = display.best_refresh(width, height)
    return DisplayMode(width, height, refresh, 32)


def target_fps(profile: Profile, refresh: int, gpu_tier: int) -> int:
    """Limite d'images par seconde conseillee."""
    if not profile.cap_to_refresh:
        return 0                                  # aucune limite
    if profile.latency_first:
        # marge pour rester sous le seuil du VRR et eviter la file d'attente
        return max(refresh - 3, 60)
    return max(refresh - 2, 60)


# --------------------------------------------------------------------------
# Traduction en reglages abstraits
# --------------------------------------------------------------------------

def _upscaler(profile: Profile, hw: HardwareInfo, mode: DisplayMode | None) -> str:
    """Choisit la technologie de super-resolution et son niveau."""
    if not profile.allow_upscaling:
        return "off"
    feats = hw.gpu.features
    family = "dlss" if "dlss" in feats else "xess" if "xess" in feats else "fsr"
    pixels = mode.pixels if mode else 2_073_600
    tier = hw.gpu.tier

    if profile.latency_first:
        level = "performance" if pixels > 2_400_000 or tier <= 1 else "balanced"
    elif profile.quality >= 3:
        # en photorealiste, si la carte encaisse, on privilegie la nettete
        level = "dlaa" if (tier >= 3 and pixels <= 3_700_000 and family == "dlss") \
            else "quality"
    else:
        level = "quality" if tier >= 2 else "balanced"
    return f"{family}_{level}"


def compute_settings(profile: Profile, hw: HardwareInfo, display: Display | None,
                     game: Game | None = None,
                     capacites: list[str] | None = None) -> dict[str, Any]:
    """Reglages abstraits, independants du jeu, consommes par les recettes.

    `capacites` : ce que la recette du jeu sait regler en plus des niveaux
    (« upscaler », « echelle_resolution ») ; sans elle, on reprend celles
    du dernier plan construit pour ce jeu."""
    mode = choose_display_mode(profile, hw, display) if display else None
    refresh = mode.refresh if mode else 60
    gpu = hw.gpu
    q = profile.quality

    reco = None
    if profile.id == "recommande":
        from . import recommande
        reco = recommande.recommander(game, hw, display, capacites, refresh=refresh)
        q = recommande.QUALITE[reco.niveau]
    else:
        # ajustement selon la puissance reelle : on n'impose pas du maximum a
        # une carte qui ne suivra pas, ni du bas de gamme a une carte capable.
        if q >= 3 and gpu.tier <= 1:
            q = 2
        if q == 2 and gpu.tier == 0:
            q = 1
        if q <= 1 and gpu.tier >= 3 and not profile.latency_first:
            q = 2
    competitif = profile.latency_first or bool(reco and reco.esport)

    vram_tight = bool(gpu.vram_mb and gpu.vram_mb < 8000)
    # Les textures coutent de la memoire video, presque pas d'images par
    # seconde : on les garde hautes meme en esport quand la VRAM suit.
    textures = q if not vram_tight else max(q - 1, 0)
    if not vram_tight and gpu.vram_mb >= 8000:
        textures = max(textures, 2)
    if mode and mode.pixels > 3_500_000 and vram_tight:
        textures = max(textures - 1, 0)

    rt = "off"
    if profile.allow_ray_tracing and "rt" in gpu.features:
        rt = "max" if gpu.tier >= 3 else "on"

    frame_gen = bool(profile.allow_frame_gen and
                     ("dlss_fg" in gpu.features or "fsr_fg" in gpu.features))
    if profile.latency_first:
        frame_gen = False

    s: dict[str, Any] = {
        "profile": profile.id,
        "resolution_w": mode.width if mode else 1920,
        "resolution_h": mode.height if mode else 1080,
        "refresh": refresh,
        "fps_cap": target_fps(profile, refresh, gpu.tier),
        "window_mode": "fullscreen" if profile.fullscreen_exclusive else "borderless",
        "vsync": profile.vsync,
        "quality": q,
        "q_textures": textures,
        "q_shadows": max(q - (1 if profile.latency_first else 0), 0),
        "q_effects": q,
        "q_postprocess": 0 if profile.latency_first else q,
        "q_view_distance": 3 if q >= 2 else max(q, 1),
        "q_foliage": q,
        "q_antialiasing": 0 if profile.latency_first else q,
        "q_reflections": q,
        "upscaler": reco.upscaler if reco else _upscaler(profile, hw, mode),
        "resolution_scale": (reco.echelle if reco and reco.famille == "echelle"
                             else 100),
        "frame_gen": frame_gen,
        "ray_tracing": rt,
        "reflex": 2 if (competitif and "reflex" in gpu.features)
                  else (1 if "reflex" in gpu.features else 0),
        "anti_lag": "anti_lag" in gpu.features,
        "hdr": bool(display.hdr) if display else False,
    }
    # niveau de DLSS, pour les recettes qui savent l'ecrire dans le jeu. Sans
    # super-resolution demandee, « dlaa » : rendu a la definition de l'ecran,
    # c'est-a-dire aucune mise a l'echelle. Vide sans carte DLSS : la recette
    # saute alors ses lignes DLSS au lieu d'ecrire un reglage sans effet.
    niveau = str(s["upscaler"])
    if "dlss" not in gpu.features:
        s["dlss"] = ""
    elif niveau.startswith("dlss_"):
        s["dlss"] = niveau[5:]
    else:
        s["dlss"] = "dlaa"
    s.update({f"fx_{k}": v for k, v in profile.effects.items()})
    if reco is not None:
        s["recommande"] = reco.to_dict()
        from .recommande import cible_du_jeu
        voulu = cible_du_jeu(game)
        if voulu:
            # « Mon choix » : la limite d'images est celle que le joueur a fixee
            s["fps_cap"] = min(int(s["fps_cap"] or voulu), voulu)
        if 0 < reco.palier < reco.cible:
            # le materiel ne tient pas la frequence de l'ecran : on bride
            # sur ce qu'il tient, pour un rythme d'images regulier
            s["fps_cap"] = reco.palier
        if reco.esport:
            # jeu competitif : image nette et lisible, sans effets qui genent
            s.update({"fx_motion_blur": False, "fx_depth_of_field": False,
                      "fx_film_grain": False, "fx_chromatic": False})

    # Ajustements memorises apres mesure (voir optimizer/adaptive.py) :
    # ils ont le dernier mot, puisqu'ils viennent du comportement reel du
    # jeu sur cette machine.
    if game is not None:
        tuning = (game.extra.get("tuning") or {}).get(profile.id) or {}
        for key, value in tuning.items():
            if key == "upscaler_level":
                family = str(s.get("upscaler", "off")).split("_")[0]
                s["upscaler"] = f"{family}_{value}" if family != "off" \
                    else s["upscaler"]
            elif key in s:
                s[key] = value
        if tuning:
            s["tuned"] = True
    return s


def describe(settings: dict[str, Any]) -> list[tuple[str, str]]:
    """Resume lisible des reglages, affiche avant de lancer le jeu."""
    up = str(settings.get("upscaler", "off"))
    up_label = "Desactivee"
    if up != "off" and "_" in up:
        fam, lvl = up.split("_", 1)
        fam = {"dlss": "DLSS", "fsr": "FSR", "xess": "XeSS"}.get(fam, fam.upper())
        lvl = {"quality": "Qualite", "balanced": "Equilibre",
               "performance": "Performance", "dlaa": "Native (DLAA)"}.get(lvl, lvl)
        up_label = f"{fam} - {lvl}"
    elif int(settings.get("resolution_scale") or 100) < 100:
        up_label = f"Rendu {int(settings['resolution_scale'])} % (echelle du jeu)"

    cap = settings.get("fps_cap") or 0
    lignes: list[tuple[str, str]] = []
    reco = settings.get("recommande")
    if reco:
        from .recommande import NOMS_NIVEAUX, texte_fps
        niveau = NOMS_NIVEAUX.get(reco.get("niveau"), "?")
        if reco.get("force"):
            niveau += f" (choisi ; conseille : {NOMS_NIVEAUX.get(reco.get('conseille'), '?')})"
        else:
            niveau += " (conseille pour votre PC)"
        fps = tuple(reco["fps"]) if reco.get("fps") else None
        lignes += [("Niveau retenu", niveau),
                   ("Images/s attendues",
                    texte_fps(fps, reco.get("cible", 60), reco.get("source", "")))]
    return lignes + [
        ("Definition", f"{settings['resolution_w']} x {settings['resolution_h']}"),
        ("Frequence", f"{settings['refresh']} Hz"),
        ("Limite d'images", f"{cap} i/s" if cap else "Aucune limite"),
        ("Affichage", "Plein ecran exclusif"
            if settings.get("window_mode") == "fullscreen" else "Sans bordure"),
        ("Niveau des details", QUALITY_NAMES.get(settings.get("quality", 2), "?")),
        ("Textures", QUALITY_NAMES.get(settings.get("q_textures", 2), "?")),
        ("Super-resolution", up_label),
        ("Generation d'images", "Activee" if settings.get("frame_gen") else "Desactivee"),
        ("Ray tracing", {"off": "Desactive", "on": "Active",
                         "max": "Maximum"}[settings.get("ray_tracing", "off")]),
        ("Synchro verticale", "Activee" if settings.get("vsync") else "Desactivee"),
        ("Reflex / Anti-Lag",
         "Actif + Boost" if settings.get("reflex") == 2
         else "Actif" if settings.get("reflex") or settings.get("anti_lag")
         else "Indisponible"),
        ("Flou de mouvement", "Active" if settings.get("fx_motion_blur") else "Desactive"),
    ]


# --------------------------------------------------------------------------
# Donnees du bloc « Graphismes » de la fiche
# --------------------------------------------------------------------------

def donnees_fiche(game: Game | None, hw: HardwareInfo, display: Display | None,
                  plan=None) -> dict[str, Any]:
    """Tout ce que le bloc « Graphismes » de la fiche affiche, en un appel
    (a faire dans la tache qui construit le plan : quelques millisecondes).

    ``{"choix": [Choix : « Votre ecran », « Mon choix »], "choix_id": str,
    "niveau": str, "cible": int (0 : l'ecran), "objectifs": [int],
    "recommandation": Recommandation,
    "statut": fiabilite.Statut, "sauvegarde_origine": bool}``"""
    from . import choix as choix_mod, fiabilite, recommande as reco_mod
    capacites = reco_mod.capacites_connues(game) or []
    runs = None
    if game is not None:
        try:
            from ..perf.store import mesures_du_jeu
            runs = mesures_du_jeu(game.uid)
        except Exception:
            runs = {}
    mode = choose_display_mode(PROFILES["recommande"], hw, display) if display else None
    refresh = mode.refresh if mode else 60
    reco = reco_mod.recommander(game, hw, display, capacites, runs=runs or {}, refresh=refresh)
    origine = False
    if game is not None:
        try:
            from . import backup
            origine = bool(backup.list_backups(game))
        except Exception:
            origine = False
    return {"choix": choix_mod.les_choix(game, hw, display, capacites, runs or {}, refresh=refresh),
            "choix_id": choix_mod.choix_du_jeu(game),
            "niveau": choix_mod.choix_memorise(game)[0],
            "cible": choix_mod.cible_du_jeu(game),
            "objectifs": choix_mod.objectifs(refresh),
            "recommandation": reco,
            "statut": fiabilite.statut(plan, game),
            "sauvegarde_origine": origine}
