"""Base de donnees locale (SQLite) : bibliotheque, caches et historiques.

Jusqu'a la 1.6, chaque module ecrivait son propre fichier JSON. Deux
defauts en decoulaient : un fichier a moitie ecrit (PC eteint, plantage
pendant l'ecriture) etait perdu en entier, et les gros caches (prix,
traductions) etaient relus et reecrits en bloc a chaque modification.

Ici, tout passe par un seul fichier `orion.db` :

* `Document("bibliotheque")` remplace un fichier JSON entier. Lecture et
  ecriture sont atomiques : une ecriture interrompue laisse la version
  precedente intacte.
* `Table("traductions")` est un dictionnaire persistant, cle par cle,
  pour les caches qui grossissent (seule la ligne modifiee est ecrite).

Migration : au premier acces, si la base ne contient rien et qu'un ancien
fichier JSON existe, son contenu est importe puis le fichier est renomme
en `.avant-sqlite` (il reste sur le disque, par prudence).

La configuration (`config.json`) reste un fichier texte : elle est
documentee dans le Tuto et peut etre ouverte a la main.
"""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any, Iterator

from .logging_setup import get
from .paths import DATA_DIR, ensure_dirs

log = get("base")

FICHIER = DATA_DIR / "orion.db"

_verrou = threading.RLock()
_connexion: sqlite3.Connection | None = None
_chemin_ouvert: Path | None = None


def _ouvrir() -> sqlite3.Connection:
    """Connexion unique, partagee entre les fils d'execution (sous verrou).

    Ne leve jamais d'erreur de base : une base abimee est mise de cote et
    remplacee par une neuve ; si meme cela echoue (disque plein, fichier
    verrouille), ORION demarre sur une base en memoire plutot que pas du
    tout."""
    global _connexion, _chemin_ouvert
    chemin = FICHIER
    if _connexion is not None and _chemin_ouvert == chemin:
        return _connexion
    try:
        ensure_dirs()
        chemin.parent.mkdir(parents=True, exist_ok=True)
    except OSError:
        log.exception("Dossier de la base inaccessible")
    try:
        cx = _connecter(chemin)
    except sqlite3.Error as exc:
        # base illisible : on la met de cote et on repart d'une base neuve ;
        # les anciens JSON (.avant-sqlite) permettent de la reconstituer
        log.error("Base illisible (%s)", exc)
        cx = None
        if _mettre_de_cote(chemin):
            _reactiver_anciens_json(chemin.parent)
            try:
                cx = _connecter(chemin)
            except sqlite3.Error:
                log.exception("Base neuve impossible a creer")
        if cx is None:
            log.error("Base en memoire pour cette session : rien ne sera conserve")
            cx = _connecter(":memory:")
    _connexion, _chemin_ouvert = cx, chemin
    return cx


#: fichiers accompagnant la base en mode WAL
_SUFFIXES = ("", "-wal", "-shm", "-journal")


def _mettre_de_cote(chemin: Path) -> bool:
    """Renomme la base abimee et ses fichiers WAL/SHM. Vrai si la place est
    libre ensuite (un -wal reste sur place serait rejoue sur la base neuve,
    ou la rendrait illisible a son tour)."""
    marque = f"abimee-{int(time.time())}"
    ok = True
    for suffixe in _SUFFIXES:
        source = chemin.with_name(chemin.name + suffixe)
        if not source.exists():
            continue
        dest = chemin.with_name(f"{chemin.stem}.{marque}{chemin.suffix}{suffixe}")
        try:
            source.replace(dest)
            log.error("Base illisible, mise de cote : %s", dest.name)
        except OSError as exc:
            log.error("Mise de cote impossible : %s (%s)", source.name, exc)
        if source.exists():
            ok = False
    return ok


def _connecter(chemin: Path | str) -> sqlite3.Connection:
    """Ouvre et prepare la base. En cas d'echec la connexion est refermee :
    sous Windows, un fichier encore ouvert ne peut pas etre renomme."""
    cx = sqlite3.connect(str(chemin), timeout=15, check_same_thread=False,
                         isolation_level=None)
    try:
        cx.execute("PRAGMA journal_mode=WAL")
        cx.execute("PRAGMA synchronous=NORMAL")
        cx.execute("PRAGMA foreign_keys=ON")
        cx.executescript("""
            CREATE TABLE IF NOT EXISTS documents (
                nom     TEXT PRIMARY KEY,
                contenu TEXT NOT NULL,
                maj     REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS entrees (
                espace  TEXT NOT NULL,
                cle     TEXT NOT NULL,
                valeur  TEXT NOT NULL,
                maj     REAL NOT NULL,
                PRIMARY KEY (espace, cle)
            );
            CREATE INDEX IF NOT EXISTS entrees_maj ON entrees(espace, maj);
        """)
        if str(chemin) != ":memory:" and not _saine(cx):
            # un index abime se reconstruit ; le reste est une base abimee,
            # mise de cote par l'appelant plutot qu'utilisee a moitie
            log.warning("Controle de la base en echec : reconstruction des index")
            try:
                cx.execute("REINDEX")
            except sqlite3.Error:
                pass
            if not _saine(cx):
                raise sqlite3.DatabaseError("controle d'integrite en echec")
    except BaseException:
        try:
            cx.close()
        except Exception:
            pass
        raise
    return cx


def _saine(cx: sqlite3.Connection) -> bool:
    try:
        etat = cx.execute("PRAGMA quick_check").fetchone()
    except sqlite3.Error:
        return False
    return bool(etat) and str(etat[0]).lower() == "ok"


def _reactiver_anciens_json(dossier: Path) -> None:
    """Apres la perte de la base, les JSON d'avant la migration redeviennent
    la source : ils seront reimportes au prochain acces."""
    for f in dossier.rglob("*.avant-sqlite"):
        cible = f.with_suffix("")
        if not cible.exists():
            try:
                f.replace(cible)
            except OSError:
                pass


def fermer() -> None:
    """Ferme la base (fin de l'application, ou tests)."""
    global _connexion, _chemin_ouvert
    with _verrou:
        if _connexion is not None:
            try:
                _connexion.close()
            except Exception:
                pass
        _connexion, _chemin_ouvert = None, None


def _migrer_fichier(ancien: Path | None):
    """Contenu d'un ancien fichier JSON, qui est ensuite renomme."""
    if ancien is None or not ancien.exists():
        return None
    try:
        contenu = json.loads(ancien.read_text("utf-8"))
    except Exception:
        log.warning("Ancien fichier illisible, ignore : %s", ancien.name)
        return None
    try:
        ancien.replace(ancien.with_name(ancien.name + ".avant-sqlite"))
    except OSError:
        pass
    log.info("Migre vers la base : %s", ancien.name)
    return contenu


class _Ecrivain:
    """Un seul fil ecrit les documents deposes par `Document.deposer` ; pour
    chaque document, seule la derniere version deposee est ecrite, et dans
    l'ordre des depots : rien d'autre n'ecrit ces documents, donc une version
    ancienne ne peut pas recouvrir une plus recente.

    15 octobre 2026 (enregistrement de l'auteur) : la bibliotheque (plusieurs
    centaines de jeux) etait reecrite depuis le fil graphique a chaque
    ouverture de fiche, et l'ecriture attendait le verrou tenu par un releve
    en cours : 300 a 400 ms figes a chaque fois.

    16 octobre (relecture de la 2.1.2) : `vider` rejoignait le fil, qui ne se
    termine jamais : 5 s figees a chaque fermeture d'ORION. Et la fermeture
    ecrivait la bibliotheque elle-meme, en parallele du fil : la version du
    fil, plus ancienne, pouvait recouvrir la finale. `vider` attend desormais
    que le fil ait tout ecrit, et la fermeture passe par lui."""

    def __init__(self) -> None:
        self._attente: dict[str, tuple[Document, Any]] = {}
        self._condition = threading.Condition()
        self._fil: threading.Thread | None = None
        self._en_cours = 0      # ecritures sorties de l'attente, pas encore finies

    def deposer(self, document: Document, contenu: Any) -> None:
        with self._condition:
            self._attente[document.nom] = (document, contenu)
            if self._fil is None or not self._fil.is_alive():
                self._fil = threading.Thread(target=self._tourner, name="base-ecriture", daemon=True)
                self._fil.start()
            self._condition.notify()

    def en_attente(self) -> bool:
        with self._condition:
            return bool(self._attente) or self._en_cours > 0

    def vider(self, delai: float = 5.0) -> None:
        """Attend que tout ce qui est depose soit ecrit (fermeture de
        l'application) ; revient tout de suite s'il n'y a rien a ecrire."""
        if self._fil is threading.current_thread():
            return
        fin = time.monotonic() + delai
        with self._condition:
            while self._attente or self._en_cours:
                if self._fil is None or not self._fil.is_alive():
                    break
                reste = fin - time.monotonic()
                if reste <= 0:
                    log.warning("Ecriture de la base encore en cours apres %.1f s : abandonnee", delai)
                    return
                self._condition.wait(reste)
            restes = list(self._attente.values())
            self._attente.clear()
        for document, contenu in restes:      # fil absent : ecrit ici
            document.ecrire(contenu)

    def _tourner(self) -> None:
        while True:
            with self._condition:
                while not self._attente:
                    self._condition.wait()
                nom, (document, contenu) = next(iter(self._attente.items()))
                del self._attente[nom]
                self._en_cours += 1
            try:
                document.ecrire(contenu)
            except Exception:
                log.exception("Ecriture du document %s impossible", nom)
            finally:
                with self._condition:
                    self._en_cours -= 1
                    self._condition.notify_all()


_ecrivain = _Ecrivain()


def ecrire_en_attente() -> None:
    """Ecrit les documents deposes qui ne le sont pas encore."""
    _ecrivain.vider()


class Document:
    """Un objet JSON complet, lu et ecrit d'un bloc, de facon atomique."""

    def __init__(self, nom: str, ancien_fichier: Path | None = None) -> None:
        self.nom = nom
        self.ancien = ancien_fichier

    def deposer(self, contenu: Any, attendre: bool = False) -> None:
        """Comme `ecrire`, mais depuis un fil a part : l'appelant ne touche
        pas la base. `contenu` ne doit plus etre modifie ensuite. `attendre` :
        revient une fois le document ecrit (fermeture), par le meme fil, pour
        qu'aucune version plus ancienne deja deposee ne le recouvre."""
        _ecrivain.deposer(self, contenu)
        if attendre:
            _ecrivain.vider()

    def lire(self, defaut: Any = None) -> Any:
        try:
            with _verrou:
                cx = _ouvrir()
                ligne = cx.execute("SELECT contenu FROM documents WHERE nom=?",
                                   (self.nom,)).fetchone()
                if ligne is None:
                    migre = _migrer_fichier(self.ancien)
                    if migre is None:
                        return defaut
                    self._ecrire(cx, migre)
                    return migre
        except sqlite3.Error:
            log.exception("Lecture du document %s impossible", self.nom)
            return defaut
        try:
            return json.loads(ligne[0])
        except Exception:
            log.exception("Document %s illisible", self.nom)
            return defaut

    def ecrire(self, contenu: Any) -> bool:
        try:
            with _verrou:
                self._ecrire(_ouvrir(), contenu)
            return True
        except Exception:
            log.exception("Ecriture du document %s impossible", self.nom)
            return False

    def _ecrire(self, cx: sqlite3.Connection, contenu: Any) -> None:
        texte = json.dumps(contenu, ensure_ascii=False)
        cx.execute("INSERT INTO documents(nom, contenu, maj) VALUES (?,?,?) "
                   "ON CONFLICT(nom) DO UPDATE SET contenu=excluded.contenu, "
                   "maj=excluded.maj", (self.nom, texte, time.time()))

    def date(self) -> float:
        try:
            with _verrou:
                ligne = _ouvrir().execute("SELECT maj FROM documents WHERE nom=?",
                                          (self.nom,)).fetchone()
        except sqlite3.Error:
            return 0.0
        return float(ligne[0]) if ligne else 0.0


class Table:
    """Dictionnaire persistant, ecrit entree par entree."""

    def __init__(self, espace: str, ancien_fichier: Path | None = None,
                 maximum: int = 0) -> None:
        self.espace = espace
        self.ancien = ancien_fichier
        self.maximum = maximum
        self._migre = False

    def _preparer(self, cx: sqlite3.Connection) -> None:
        if self._migre:
            return
        self._migre = True
        if self.ancien is None or not self.ancien.exists():
            return
        deja = cx.execute("SELECT 1 FROM entrees WHERE espace=? LIMIT 1",
                          (self.espace,)).fetchone()
        if deja:
            return
        contenu = _migrer_fichier(self.ancien)
        if isinstance(contenu, dict):
            self._ecrire_plusieurs(cx, contenu.items())

    def get(self, cle: str, defaut: Any = None) -> Any:
        try:
            with _verrou:
                cx = _ouvrir()
                self._preparer(cx)
                ligne = cx.execute("SELECT valeur FROM entrees WHERE espace=? AND cle=?",
                                   (self.espace, str(cle))).fetchone()
        except sqlite3.Error:
            log.exception("Lecture impossible dans %s", self.espace)
            return defaut
        if ligne is None:
            return defaut
        try:
            return json.loads(ligne[0])
        except Exception:
            return defaut

    def __contains__(self, cle: str) -> bool:
        return self.get(cle, _ABSENT) is not _ABSENT

    def set(self, cle: str, valeur: Any) -> None:
        try:
            with _verrou:
                cx = _ouvrir()
                self._preparer(cx)
                self._ecrire_plusieurs(cx, [(str(cle), valeur)])
                self._elaguer(cx)
        except Exception:
            log.exception("Ecriture impossible dans %s", self.espace)

    def update(self, valeurs: dict) -> None:
        try:
            with _verrou:
                cx = _ouvrir()
                self._preparer(cx)
                self._ecrire_plusieurs(cx, valeurs.items())
                self._elaguer(cx)
        except Exception:
            log.exception("Ecriture impossible dans %s", self.espace)

    def supprimer(self, cle: str) -> None:
        try:
            with _verrou:
                _ouvrir().execute("DELETE FROM entrees WHERE espace=? AND cle=?",
                                  (self.espace, str(cle)))
        except sqlite3.Error:
            log.exception("Suppression impossible dans %s", self.espace)

    def vider(self) -> None:
        try:
            with _verrou:
                _ouvrir().execute("DELETE FROM entrees WHERE espace=?", (self.espace,))
        except sqlite3.Error:
            log.exception("Vidage impossible de %s", self.espace)

    def items(self) -> Iterator[tuple[str, Any]]:
        try:
            with _verrou:
                cx = _ouvrir()
                self._preparer(cx)
                lignes = cx.execute("SELECT cle, valeur FROM entrees WHERE espace=? "
                                    "ORDER BY maj", (self.espace,)).fetchall()
        except sqlite3.Error:
            log.exception("Lecture impossible dans %s", self.espace)
            lignes = []
        for cle, valeur in lignes:
            try:
                yield cle, json.loads(valeur)
            except Exception:
                continue

    def tout(self) -> dict[str, Any]:
        return dict(self.items())

    def __len__(self) -> int:
        try:
            with _verrou:
                cx = _ouvrir()
                self._preparer(cx)
                return int(cx.execute("SELECT COUNT(*) FROM entrees WHERE espace=?",
                                      (self.espace,)).fetchone()[0])
        except sqlite3.Error:
            log.exception("Lecture impossible dans %s", self.espace)
            return 0

    def _ecrire_plusieurs(self, cx: sqlite3.Connection, paires) -> None:
        maintenant = time.time()
        lignes = [(self.espace, str(c), json.dumps(v, ensure_ascii=False), maintenant)
                  for c, v in paires]
        if not lignes:
            return
        cx.execute("BEGIN")
        try:
            cx.executemany(
                "INSERT INTO entrees(espace, cle, valeur, maj) VALUES (?,?,?,?) "
                "ON CONFLICT(espace, cle) DO UPDATE SET valeur=excluded.valeur, "
                "maj=excluded.maj", lignes)
            cx.execute("COMMIT")
        except Exception:
            cx.execute("ROLLBACK")
            raise

    def _elaguer(self, cx: sqlite3.Connection) -> None:
        """Borne la taille du cache en retirant les entrees les plus anciennes."""
        if self.maximum <= 0:
            return
        n = cx.execute("SELECT COUNT(*) FROM entrees WHERE espace=?",
                       (self.espace,)).fetchone()[0]
        if n > self.maximum * 1.1:
            cx.execute("DELETE FROM entrees WHERE espace=? AND cle IN ("
                       "SELECT cle FROM entrees WHERE espace=? ORDER BY maj LIMIT ?)",
                       (self.espace, self.espace, n - self.maximum))


_ABSENT = object()

