"""Capture des images par seconde avec PresentMon.

PresentMon est l'outil de mesure d'Intel (gratuit, open source). Il observe
les images reellement presentees a l'ecran par le jeu, ce qui donne la meme
mesure que les outils de test de reference — bien plus fiable qu'une
estimation.

ORION le telecharge tout seul a la premiere utilisation : rien a installer
a la main. Windows ne laisse lire ses evenements d'affichage qu'aux
administrateurs et au groupe « Utilisateurs du journal de performances » :
ORION ne demande jamais l'elevation. Sans ce groupe, la mesure est refusee
(`ACCES_REFUSE`, signale dans Reglages) et le reste continue de fonctionner.
"""
from __future__ import annotations

import csv
import os
import re
import subprocess
import threading
import time
from pathlib import Path

from ..core.logging_setup import get
from ..core.paths import DATA_DIR, ensure_dirs, is_windows

log = get("perf.presentmon")

TOOL_DIR = DATA_DIR / "outils"
RELEASES = "https://api.github.com/repos/GameTechDev/PresentMon/releases/latest"
HEADERS = {"User-Agent": "ORION-Launcher/1.0 (+local)"}

CREATE_NO_WINDOW = 0x08000000


# --------------------------------------------------------------------------
# Installation
# --------------------------------------------------------------------------

def installed_path() -> Path | None:
    """Chemin de PresentMon s'il est deja present."""
    ensure_dirs()
    TOOL_DIR.mkdir(parents=True, exist_ok=True)
    candidates = sorted(TOOL_DIR.glob("PresentMon*.exe"))
    return candidates[0] if candidates else None


def ensure_tool(progress_cb=None) -> tuple[bool, str]:
    """Telecharge PresentMon si necessaire. Retourne (pret, message)."""
    if not is_windows():
        return False, "La mesure n'est disponible que sous Windows."

    existing = installed_path()
    if existing:
        return True, str(existing)

    from orion.core import reseau
    if progress_cb:
        progress_cb("Telechargement de l'outil de mesure...", 10)
    try:
        r = reseau.get(RELEASES, headers=HEADERS, timeout=20)
        if r.status_code != 200:
            return False, f"Publication introuvable (code {r.status_code})."
        assets = (r.json() or {}).get("assets") or []
    except Exception as exc:
        return False, f"Telechargement impossible : {exc}"

    url = ""
    for asset in assets:
        name = str(asset.get("name") or "")
        if name.lower().endswith(".exe") and "x64" in name.lower() \
                and "console" in name.lower():
            url = asset.get("browser_download_url", "")
            break
    if not url:
        for asset in assets:
            name = str(asset.get("name") or "")
            if name.lower().endswith(".exe") and "x64" in name.lower():
                url = asset.get("browser_download_url", "")
                break
    if not url:
        return False, "Aucun executable compatible dans la derniere version."

    dest = TOOL_DIR / Path(url).name
    try:
        with reseau.get(url, headers=HEADERS, timeout=120, stream=True) as resp:
            if resp.status_code != 200:
                return False, f"Telechargement refuse (code {resp.status_code})."
            total = int(resp.headers.get("content-length") or 0)
            done = 0
            with open(dest, "wb") as fh:
                for chunk in resp.iter_content(65536):
                    fh.write(chunk)
                    done += len(chunk)
                    if progress_cb and total:
                        progress_cb("Telechargement de l'outil de mesure...",
                                    10 + int(done / total * 80))
    except Exception as exc:
        return False, f"Telechargement interrompu : {exc}"

    log.info("PresentMon installe : %s", dest)
    return True, str(dest)


# --------------------------------------------------------------------------
# Capture
# --------------------------------------------------------------------------

#: nom de la session de mesure de Windows ouverte par ORION
SESSION = "ORION_Mesure"
#: la derniere trace est gardee sous ce nom (diagnostic, comparaison avec un
#: autre outil) ; elle est remplacee a chaque partie
DERNIERE_TRACE = "derniere_mesure.csv"


class Capture:
    """Une session de mesure sur un processus de jeu."""

    def __init__(self, process_name: str, game_uid: str, profile: str, pid: int = 0) -> None:
        self.process_name = process_name
        #: numero du processus du jeu : PresentMon le suit sans avoir a lire
        #: son nom. Sans droits d'administrateur, il ne peut pas lire le nom
        #: d'un jeu protege par un anti-triche (Aniimo, 9 octobre : « listed
        #: as '<unknown>' and can't be targeted by --process_name »).
        self.pid = int(pid or 0)
        self.game_uid = game_uid
        self.profile = profile
        self.csv_path = TOOL_DIR / f"capture_{game_uid}.csv"
        self.proc: subprocess.Popen | None = None
        self.started_at = 0.0
        self.error = ""
        #: (secondes depuis le debut de la mesure, le jeu est-il devant ?),
        #: releve chaque seconde (2.1.2). Le 11 octobre, Aniimo est reste
        #: 66 minutes en arriere-plan pendant une mesure : Windows et le jeu le
        #: bridaient a 15-30 images par seconde, et la mesure a retenu 21 i/s
        #: au lieu de ~115 en jeu.
        self.premier_plan: list[tuple[float, bool]] = []
        self._veille_stop = threading.Event()

    def start(self) -> bool:
        tool = installed_path()
        if tool is None or not self.process_name:
            self.error = "Outil de mesure absent."
            return False
        try:
            if self.csv_path.exists():
                self.csv_path.unlink()
        except OSError:
            pass

        cible = (["--process_id", str(self.pid)] if self.pid > 0
                 else ["--process_name", self.process_name])
        args = [str(tool), *cible,
                "--output_file", str(self.csv_path),
                "--terminate_on_proc_exit",
                # session a son nom : la session par defaut (« PresentMon »)
                # est aussi celle de FrameView, que « --stop_existing_session »
                # arretait en pleine mesure (9 octobre) ; seule une ancienne
                # session d'ORION est arretee
                "--session_name", SESSION,
                "--stop_existing_session",
                # PresentMon 2.x : « --no_top » n'existe plus (c'etait 1.x).
                # Une option inconnue lui fait afficher son aide et s'arreter :
                # 36 mesures sur 36 perdues jusqu'au 9 octobre.
                "--no_console_stats"]
        try:
            self.proc = subprocess.Popen(
                args, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                creationflags=CREATE_NO_WINDOW)
            self.started_at = time.time()
            log.info("Mesure demarree sur %s", self.process_name)
            threading.Thread(target=self._veiller, daemon=True).start()
            return True
        except Exception as exc:
            self.error = str(exc)
            log.debug("Mesure impossible : %s", exc)
            return False

    def _veiller(self) -> None:
        """Chaque seconde : le jeu est-il la fenetre au premier plan ?"""
        while not self._veille_stop.wait(1.0):
            p = processus_au_premier_plan()
            if p is None:
                continue                      # inconnu : rien a conclure
            pid, nom = p
            devant = bool((self.pid > 0 and pid == self.pid)
                          or (nom and nom.lower() == self.process_name.lower()))
            self.premier_plan.append((time.time() - self.started_at, devant))

    def _fermer_session(self) -> None:
        tool = installed_path()
        if tool is None:
            return
        try:
            subprocess.run([str(tool), "--session_name", SESSION, "--terminate_existing_session"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10,
                           creationflags=CREATE_NO_WINDOW)
        except Exception:
            log.debug("Fermeture de la session de mesure impossible")

    def stop(self) -> dict | None:
        """Arrete la capture et renvoie les statistiques. Sans resultat,
        `self.error` dit pourquoi : le message de PresentMon lui-meme (il
        etait jete jusqu'a la 2.1.0, et 36 mesures sur 36 ont echoue le
        9 octobre sans qu'on sache pourquoi)."""
        sortie = b""
        if self.proc is not None:
            deja_fini = self.proc.poll() is not None
            try:
                if not deja_fini:
                    # arret propre : fermer la session de mesure de Windows fait
                    # sortir PresentMon de lui-meme, fichier ecrit jusqu'au bout.
                    # Tuer le programme laissait la session ouverte (« a trace
                    # session named ORION_Mesure is already running », 10 octobre)
                    # et pouvait perdre la fin du releve.
                    self._fermer_session()
                    try:
                        self.proc.wait(timeout=8)
                    except Exception:
                        self.proc.terminate()
                _out, sortie = self.proc.communicate(timeout=10)
            except Exception:
                try:
                    self.proc.kill()
                except Exception:
                    pass
            message = (sortie or b"").decode("utf-8", errors="replace").strip()
            if message:
                if _aide(message):
                    # PresentMon a refuse une option et affiche son aide
                    self.error = "PresentMon a refuse une option de la ligne de commande"
                    log.warning("PresentMon (%s) : option refusee, aide affichee : %s",
                                self.process_name, message[:300])
                else:
                    # PresentMon ecrit toujours des avertissements (droits,
                    # session) : seule une ligne « error: » est une erreur
                    erreurs = [ligne.strip() for ligne in message.splitlines()
                               if ligne.strip().lower().startswith("error")]
                    if erreurs:
                        self.error = erreurs[0][:300]
                    log.info("PresentMon (%s) : %s", self.process_name, message[-600:])
            if deja_fini and not self.error:
                self.error = f"PresentMon s'est arrete seul (code {self.proc.returncode})"
        self._veille_stop.set()
        time.sleep(0.6)
        stats = analyse(self.csv_path, self.game_uid, self.profile, premier_plan=self.premier_plan)
        if stats is None and not self.error:
            self.error = ("aucune trace ecrite" if not self.csv_path.exists()
                          else "trace trop courte (moins de 60 images)")
        if stats is None and self.error and _acces_refuse(self.error):
            self.error = ACCES_REFUSE
        return stats


def processus_au_premier_plan() -> tuple[int, str] | None:
    """(numero, nom de l'executable) du programme dont la fenetre est au
    premier plan ; `None` si on ne peut pas le savoir (hors Windows, erreur)."""
    if not is_windows():
        return None
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        fenetre = user32.GetForegroundWindow()
        if not fenetre:
            return 0, ""
        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(fenetre, ctypes.byref(pid))
        nom = ""
        try:
            import psutil
            nom = psutil.Process(int(pid.value)).name()
        except Exception:
            pass
        return int(pid.value), nom
    except Exception:
        return None


def secondes_hors_jeu(premier_plan: list[tuple[float, bool]] | None) -> set[int] | None:
    """Les secondes de la mesure ou le jeu n'etait pas au premier plan, avec
    une seconde de marge de chaque cote (le releve est fait chaque seconde).
    `None` quand le releve ne permet pas de conclure : vide, ou le jeu n'a
    presque jamais ete vu devant (sa fenetre appartient peut-etre a un autre
    programme) ; on ne jette alors rien, plutot que toute la partie."""
    if not premier_plan:
        return None
    devant = sum(1 for _, d in premier_plan if d)
    if devant < max(5, len(premier_plan) * 0.1):
        return None
    fond: set[int] = set()
    for t, d in premier_plan:
        if not d:
            s = int(t)
            fond.update((s - 1, s, s + 1))
    return fond


#: PresentMon lit les evenements de Windows (ETW) : il faut etre
#: administrateur ou membre du groupe « Utilisateurs du journal de
#: performances » (SID S-1-5-32-559). ORION ne demande pas les droits
#: d'administrateur : sans ce groupe, aucune mesure n'est possible.
ACCES_REFUSE = ("acces refuse par Windows : la mesure demande d'etre membre du groupe "
                "« Utilisateurs du journal de performances »")


def _aide(message: str) -> bool:
    """Vrai quand PresentMon a affiche son aide (option inconnue) : on y lit
    « administrator » ou « elevated », ce qui n'est PAS un refus d'acces
    (premiere lecture fausse le 9 octobre). Son avertissement « requires
    elevated privilege ... --process_name » n'est pas l'aide."""
    return "--restart_as_admin" in message and "--stop_existing_session" in message


def _acces_refuse(message: str) -> bool:
    if _aide(message):
        return False
    m = message.lower()
    return any(x in m for x in ("access denied", "access is denied", "acces refuse",
                                "accès refusé", "0x80070005", "performance log users"))


# --------------------------------------------------------------------------
# Analyse
# --------------------------------------------------------------------------

FRAME_COLUMNS = ("msbetweenpresents", "frametime", "msbetweendisplaychange")


def jeu_seulement(frames: list[float]) -> list[float]:
    """Ecarte les ecrans de chargement et les menus sans limite d'images.

    9 octobre (Aniimo bride a 40 i/s, « c'est bizarre ton calcul ») : 52,4 i/s
    de moyenne et un maximum de 1 075 i/s. Un chargement affiche des
    centaines d'images par seconde : 10 secondes y ajoutent 10 000 images et
    gonflent la moyenne. Repere : la duree d'image autour de laquelle se
    passe la moitie du TEMPS de jeu (et non la moitie des images, que ces
    rafales fausseraient). Une image 4 fois plus courte n'est pas du jeu."""
    if len(frames) < 60:
        return frames
    moitie = sum(frames) / 2
    cumul = 0.0
    repere = frames[0]
    for f in sorted(frames):
        cumul += f
        if cumul >= moitie:
            repere = f
            break
    garde = [f for f in frames if f >= repere / 4]
    return garde if len(garde) >= 60 else frames


def analyse(csv_path: Path, game_uid: str = "", profile: str = "",
            premier_plan: list[tuple[float, bool]] | None = None) -> dict | None:
    """Transforme la trace en statistiques lisibles. Avec `premier_plan`
    (releve de `Capture`), les images faites pendant que le jeu n'etait pas
    devant sont retirees d'abord : ce n'etait pas du jeu (2.1.2)."""
    if not csv_path.exists():
        return None
    fond = secondes_hors_jeu(premier_plan)
    par_chaine: dict[str, list[float]] = {}
    hors_jeu = 0
    try:
        with open(csv_path, "r", encoding="utf-8", errors="ignore") as fh:
            reader = csv.DictReader(fh)
            column = chaine = temps = ""
            echelle = 1.0
            for row in reader:
                if not column:
                    for name in reader.fieldnames or []:
                        cle = re.sub(r"[^a-z]", "", name.lower())
                        if not column and cle in FRAME_COLUMNS:
                            column = name
                        if cle == "swapchainaddress":
                            chaine = name
                        if cle == "timeinms" and not temps:
                            temps, echelle = name, 0.001          # PresentMon 2.x
                        elif cle == "timeinseconds" and not temps:
                            temps, echelle = name, 1.0            # PresentMon 1.x
                    if not column:
                        return None
                try:
                    value = float(row.get(column) or 0)
                except (TypeError, ValueError):
                    continue
                if fond and temps:
                    try:
                        if int(float(row.get(temps) or 0) * echelle) in fond:
                            hors_jeu += 1
                            continue
                    except (TypeError, ValueError):
                        pass
                if 0.1 < value < 2000:
                    par_chaine.setdefault(str(row.get(chaine) or "") if chaine else "", []).append(value)
    except Exception:
        log.debug("Trace de mesure illisible : %s", csv_path)
        return None

    # la chaine d'affichage du jeu : celle qui a affiche le plus longtemps
    # (une seconde chaine, celle d'un menu ou d'un outil, ne se melange pas)
    frames = max(par_chaine.values(), key=sum) if par_chaine else []
    if len(frames) < 60:
        return None
    total = len(frames)
    frames = jeu_seulement(frames)
    ecartees = total - len(frames)

    frames_sorted = sorted(frames, reverse=True)   # du plus lent au plus rapide
    count = len(frames_sorted)
    avg_ms = sum(frames) / count
    p1 = frames_sorted[max(int(count * 0.01) - 1, 0)]
    p01 = frames_sorted[max(int(count * 0.001) - 1, 0)]

    def fps(ms: float) -> float:
        return round(1000.0 / ms, 1) if ms else 0.0

    stats = {
        "uid": game_uid,
        "profile": profile,
        "at": time.time(),
        "frames": count,
        "seconds": round(sum(frames) / 1000.0, 1),
        "fps_avg": fps(avg_ms),
        "fps_low_1": fps(p1),
        "fps_low_01": fps(p01),
        "fps_max": fps(min(frames)),
        "stutter": round(sum(1 for f in frames if f > avg_ms * 2)
                         / count * 100, 2),
        "ecartees": ecartees,
    }
    if hors_jeu:
        stats["hors_jeu"] = hors_jeu
    # plus d'images ecartees que gardees : le tri « menus et chargements » a
    # pris le jeu pour un menu (une longue attente en arriere-plan, une limite
    # d'images du jeu) ; la mesure est gardee pour le diagnostic, jamais
    # utilisee comme reference (11 octobre : Aniimo a 21 i/s au lieu de ~115)
    if ecartees > count:
        stats["douteuse"] = True
    try:
        os.replace(csv_path, csv_path.with_name(DERNIERE_TRACE))
    except OSError:
        try:
            os.remove(csv_path)
        except OSError:
            pass
    log.info("Mesure : %s", stats)
    return stats
