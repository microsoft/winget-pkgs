"""Apprentissage par l'exemple : ORION apprend les niveaux d'un jeu (2.1.0).

Demande de l'auteur (10 octobre, « ca va etre chiant s'il faut tout refaire
jeu par jeu ») : ce que nous avons fait a la main pour Aniimo (six releves du
registre et deux videos) et pour Baldur's Gate 3, ORION le fait seul.

1. Il photographie les reglages du jeu : ses fichiers de reglages aux
   endroits habituels (jamais dans le dossier d'installation, voir
   `apprentissage`) et, pour un jeu Unity, sa cle de registre.
2. Le joueur lance le jeu, choisit le niveau le plus BAS dans son menu,
   quitte ; ORION photographie. Puis, s'il le veut, un niveau moyen et un
   niveau eleve ; enfin le plus HAUT.
3. Les cles qui changent d'une photo a l'autre sont celles que le menu du
   jeu ecrit pour un niveau. ORION garde EXACTEMENT les valeurs que le jeu a
   ecrites lui-meme : jamais une valeur inventee, jamais une cle creee.

La recette obtenue est enregistree dans les recettes personnelles (elle
prime sur celle livree avec ORION, dont elle reprend les autres reglages :
definition, synchronisation...). Si le joueur partage deja ses mesures, elle
est aussi proposee au service d'ORION pour les autres joueurs : elle ne
contient que des noms et des valeurs de reglages, et des chemins ramenes a
%LOCALAPPDATA%, %APPDATA% ou %USERPROFILE% (aucun nom de compte). Les cles
qui pourraient dire quelque chose du joueur (compte, identifiant, langue,
touches, son, fenetre, date...) ne sont jamais retenues.
"""
from __future__ import annotations

import json
import os
import re
import time
from pathlib import Path
from typing import Any

from ..core.logging_setup import get
from ..core.models import Game

log = get("optimizer.exemple")

#: etapes, dans l'ordre ; les deux du milieu sont facultatives
ETAPES = ("bas", "moyen", "eleve", "haut")
FACULTATIVES = ("moyen", "eleve")
NOMS_ETAPES = {"bas": "le niveau le plus bas", "moyen": "un niveau moyen",
               "eleve": "un niveau eleve (juste sous le maximum)", "haut": "le niveau le plus haut"}
#: niveau d'ORION (0 Basse ... 3 Ultra) -> etapes a utiliser, la premiere photographiee l'emporte
NIVEAUX_ORION = {"0": ("bas",), "1": ("moyen", "bas"), "2": ("eleve", "haut"), "3": ("haut",)}

TAILLE_MAX = 512 * 1024
#: cles jamais retenues : elles ne decrivent pas un niveau de graphismes, ou
#: pourraient dire quelque chose du joueur
_EXCLUES = re.compile(
    r"(resolution|width|height|largeur|hauteur|window|fenetre|monitor|display|screen|"
    r"fullscreen|vsync|refresh|volume|audio|sound|music|voice|language|langue|locale|"
    r"subtitle|key|bind|input|mouse|sensitiv|controller|gamepad|account|user|login|"
    r"token|steam|uuid|guid|session|time|date|stamp|count|version|path|dir|folder|seen|"
    r"tutorial|last|recent|hdr|gamma|brightness|position|pos[xy]|ip\b|server|region|"
    r"uid|userid|playerid|deviceid|machineid|hwid|serial|email|mail|name|nick|pseudo|"
    r"(^|_)id($|_)|\bid\b)", re.I)
#: une valeur de reglage : petit nombre, booleen, mot (au plus 3 chiffres :
#: « x16 », « Anisotropic16x »). Un horodatage, un numero de compte ou un
#: jeton aleatoire n'y ressemble pas et n'est jamais retenu.
_NOMBRE = re.compile(r"-?\d{1,7}(\.\d{1,8})?")
_MOT = re.compile(r"[A-Za-z][A-Za-z0-9_\-]{0,39}")


def _valeur_simple(v: str) -> bool:
    v = str(v)
    if _NOMBRE.fullmatch(v) or v in ("true", "false", "True", "False"):
        return True
    return bool(_MOT.fullmatch(v)) and sum(c.isdigit() for c in v) <= 3


# --------------------------------------------------------------------------
# Photographie
# --------------------------------------------------------------------------

#: ce qu'il faut pour recreer une entree Larian absente : (chemin, adresse) ->
#: « larian=<Type>:<type de Value> » (voir xml_writer)
_LARIAN_TYPES: dict[tuple[str, str], str] = {}


def _cles_larian(texte: str, chemin: str = "") -> list[tuple[str, str]]:
    """Entrees Larian (« ConfigEntry » : MapKey puis Value) -> adresse xml_writer."""
    out = []
    for m in re.finditer(r'<node id="ConfigEntry">(.*?)</node>', texte, re.S):
        bloc = m.group(1)
        k = re.search(r'id="MapKey"[^>]*\bvalue="([^"]*)"', bloc)
        v = re.search(r'id="Value"[^>]*\bvalue="([^"]*)"', bloc)
        if k and v:
            adresse = f"attribute[value={k.group(1)}]/attribute[id=Value]@value"
            out.append((adresse, v.group(1)))
            code = re.search(r'id="Type"[^>]*\bvalue="(-?\d+)"', bloc)
            sorte = re.search(r'id="Value"[^>]*\btype="([A-Za-z0-9_]+)"', bloc)
            if chemin and code and sorte:
                _LARIAN_TYPES[(chemin, adresse)] = f"larian={code.group(1)}:{sorte.group(1)}"
    return out


def _larian(cle: tuple) -> str:
    """« larian=... » si `cle` est une entree Larian connue, sinon ""."""
    return _LARIAN_TYPES.get((cle[1], cle[3]), "") if cle and cle[0] == "xml" else ""


def _lire_fichier(p: Path) -> dict[tuple, str]:
    from .apprentissage import _cles_ini, _cles_json, _cles_xml, _format
    try:
        if p.stat().st_size > TAILLE_MAX:
            return {}
        texte = p.read_bytes().decode("utf-8-sig", errors="replace")
    except OSError:
        return {}
    fmt = _format(p, texte)
    out: dict[tuple, str] = {}
    if fmt in ("ini", "texte"):
        for section, cle, valeur in _cles_ini(texte):
            out[(fmt, str(p), section, cle)] = valeur
    elif fmt == "xml":
        larian = _cles_larian(texte, str(p))
        paires = larian or _cles_xml(texte)
        vus: dict[str, int] = {}
        for adresse, _v in paires:
            vus[adresse] = vus.get(adresse, 0) + 1
        for adresse, valeur in paires:
            if vus[adresse] == 1:              # adresse unique : sans ambiguite
                out[("xml", str(p), "", adresse)] = valeur
    elif fmt == "json":
        for chemin, valeur in _cles_json(texte):
            out[("json", str(p), "", chemin)] = valeur
    return out


def cle_unity(game: Game) -> str:
    """« HKCU/Software/<editeur>/<produit> » d'un jeu Unity (fichier
    `<Jeu>_Data/app.info` du dossier d'installation, lu sans rien y ecrire)."""
    racine = Path(game.install_dir or "")
    if not game.install_dir or not racine.is_dir():
        return ""
    try:
        for info in racine.glob("*_Data/app.info"):
            lignes = [x.strip() for x in info.read_text("utf-8", errors="ignore").splitlines() if x.strip()]
            if len(lignes) >= 2:
                return f"HKCU/Software/{lignes[0]}/{lignes[1]}"
    except OSError:
        pass
    return ""


def _lire_registre(chemin: str) -> dict[tuple, str]:
    from ..core.paths import is_windows
    if not chemin or not is_windows():
        return {}
    from ..core.winutil import reg_values
    from ..plugins.tweaks.registry_writer import _split, texte_binaire
    root, sous = _split(chemin)
    out: dict[tuple, str] = {}
    for nom, val in (reg_values(root, sous) or {}).items():
        if isinstance(val, (bytes, bytearray)):
            val = texte_binaire(bytes(val))
        out[("registry", chemin, "", str(nom))] = str(val)
    return out


def _connus(game: Game, base: dict | None) -> tuple[list[Path], list[str]]:
    """Fichiers et cles de registre que la recette deja connue pour ce jeu
    designe (Baldur's Gate 3 range ses reglages sous « Larian Studios », ou
    la recherche par le titre ne va pas)."""
    fichiers: list[Path] = []
    cles: list[str] = []
    if not base:
        return fichiers, cles
    from .discovery import context_for
    from .engine import _resolve_paths
    ctx = context_for(game)
    for t in base.get("targets") or []:
        motifs = [str(x) for x in t.get("paths") or []]
        if t.get("format") == "registry":
            cles += [m.replace("\\", "/") for m in motifs if "{" not in m]
        else:
            try:
                fichiers += [Path(x) for x in _resolve_paths(motifs, ctx, False)]
            except Exception:
                continue
    return fichiers, cles


def photographier(game: Game, base: dict | None = None) -> dict[tuple, str]:
    """Tous les reglages lisibles du jeu, a cet instant : ses fichiers aux
    endroits habituels, ceux de la recette deja connue, sa cle Unity."""
    from .apprentissage import _candidats
    from . import securite
    photo: dict[tuple, str] = {}
    fichiers, cles = _connus(game, base)
    vus: set[str] = set()
    for p in list(_candidats(game)) + fichiers:
        k = str(p).lower()
        if k in vus or not securite.chemin_autorise(str(p), "", partagee=True):
            continue                       # jamais le dossier d'installation (anti-triche)
        vus.add(k)
        photo.update(_lire_fichier(p))
    for cle in dict.fromkeys(cles + [cle_unity(game)]):
        photo.update(_lire_registre(cle))
    return photo


# --------------------------------------------------------------------------
# Recette
# --------------------------------------------------------------------------

def _nom_de_cle(cle: tuple) -> str:
    adresse = str(cle[3])
    m = re.search(r"attribute\[value=([^\]]+)\]", adresse)
    if m:
        return m.group(1)
    nom = re.split(r"[.@/]", adresse)[-1] if not adresse.startswith("attribute") else adresse
    return re.sub(r"_h\d+$", "", nom)          # Unity : « Nom_h12345 »


def retenues(photos: dict[str, dict[tuple, str]]) -> list[tuple]:
    """Les cles qui changent entre le niveau le plus bas et le plus haut, avec
    des valeurs de reglage simples, et jamais une cle qui dirait quelque chose
    du joueur."""
    bas, haut = photos.get("bas") or {}, photos.get("haut") or {}
    out = []
    # Larian : une entree absente a un niveau vaut la valeur par defaut du jeu
    # (Baldur's Gate 3 n'ecrit que les reglages qui different du defaut) ;
    # ailleurs, la cle doit etre lue au niveau le plus bas et au plus haut
    larian = {c for p in photos.values() for c in p if _larian(c)}
    for cle in sorted((set(bas) & set(haut)) | larian, key=str):
        if _larian(cle):
            niveaux = [p.get(cle) for p in photos.values()]
            if len(set(niveaux)) < 2:
                continue
        elif bas[cle] == haut[cle]:
            continue
        if _EXCLUES.search(_nom_de_cle(cle)) or _EXCLUES.search(str(cle[2])):
            continue
        valeurs = [p[cle] for p in photos.values() if cle in p]
        if not valeurs or not all(_valeur_simple(v) for v in valeurs):
            continue
        out.append(cle)
    return out


def _chemin_partageable(chemin: str) -> str:
    """Chemin reel -> chemin de recette, sans le nom du compte Windows ; vide
    si le fichier n'est pas dans un dossier de donnees de l'utilisateur."""
    if chemin.startswith("HKCU/"):
        return chemin
    p = os.path.normpath(chemin)
    for var in ("LOCALAPPDATA", "APPDATA", "USERPROFILE"):
        base = os.environ.get(var, "")
        if base and os.path.normcase(p).startswith(os.path.normcase(os.path.normpath(base)) + os.sep):
            return f"%{var}%/" + p[len(os.path.normpath(base)) + 1:].replace("\\", "/")
    return ""


def _slug(titre: str) -> str:
    return (re.sub(r"[^a-z0-9]+", "_", titre.lower()).strip("_") or "jeu")[:50]


from ..plugins.tweaks.xml_writer import ABSENT  # noqa: E402


def recette(game: Game, photos: dict[str, dict[tuple, str]], base: dict | None = None) -> dict | None:
    """La recette apprise, ou None si rien de sur n'a change. `base` : la
    recette deja connue pour ce jeu (ses autres reglages sont gardes ; une cle
    apprise remplace la sienne)."""
    if not photos.get("bas") or not photos.get("haut"):
        return None
    cles = retenues(photos)
    derive: dict[str, Any] = {}
    cibles: dict[tuple[str, str], list[dict]] = {}
    for i, cle in enumerate(cles):
        fmt, chemin, section, nom = cle
        partage = _chemin_partageable(chemin)
        if not partage:
            continue
        larian = _larian(cle)
        carte = {}
        for niveau, etapes in NIVEAUX_ORION.items():
            for e in etapes:
                if cle in (photos.get(e) or {}):
                    carte[niveau] = photos[e][cle]
                    break
                if larian and photos.get(e):
                    carte[niveau] = ABSENT       # le jeu garde sa valeur par defaut
                    break
        if len(carte) < 4:
            continue
        derive[f"ex_{i}"] = {"from": "quality", "map": carte}
        entree = {"key": nom, "value": "{ex_%d}" % i, "label": _nom_de_cle(cle)}
        if larian:
            entree["section"] = larian          # de quoi recreer l'entree, ou la retirer
            entree["creer"] = True
        elif section:
            entree["section"] = section
        cibles.setdefault((fmt, partage), []).append(entree)
    if not cibles:
        return None
    appris = {(f, p): {e["key"] for e in es} for (f, p), es in cibles.items()}
    targets = []
    for (fmt, partage), entries in cibles.items():
        t: dict[str, Any] = {"format": fmt, "paths": [partage], "entries": entries}
        targets.append(t)
    r: dict[str, Any] = {
        "id": f"exemple_{_slug(game.title)}",
        "name": f"{game.title} (appris par l'exemple)",
        "match": {"title": [game.title]},
        "confidence": "exact",
        "creer_cles": False,
        "derive": derive,
        "targets": targets,
        "advice": ["Niveaux appris par l'exemple : ORION ecrit pour chaque niveau les valeurs que le "
                   "menu du jeu a lui-meme ecrites."],
        "_appris": {"le": time.strftime("%Y-%m-%d"), "etapes": [e for e in ETAPES if photos.get(e)],
                    "cles": len(cles), "format": 2},
    }
    if game.source == "steam" and str(game.source_id).isdigit():
        r["match"]["appid"] = [int(game.source_id)]
    if base:
        # les autres reglages de la recette connue (definition, synchronisation...)
        for nom, regle in (base.get("derive") or {}).items():
            r["derive"].setdefault(nom, regle)
        for t in base.get("targets") or []:
            t = json.loads(json.dumps(t))
            noms = set()
            for (f, p), ks in appris.items():
                if f == t.get("format"):
                    noms |= ks
            if t.get("unity_prefs"):
                from .engine import cle_unity as hache
                t["entries"] = [e for e in t.get("entries") or []
                                if e.get("key") not in noms and hache(str(e.get("key"))) not in noms]
            else:
                t["entries"] = [e for e in t.get("entries") or [] if e.get("key") not in noms]
            if t["entries"]:
                r["targets"].append(t)
        r["capacites"] = list(base.get("capacites") or [])
        r["advice"] += [a for a in (base.get("advice") or []) if "config.lsf" not in a]
    return r


def enregistrer(r: dict) -> Path:
    """La recette rejoint les recettes personnelles (elle prime sur les autres)."""
    from ..core.paths import RECIPE_USER_DIR, ensure_dirs, ecrire_atomique
    ensure_dirs()
    RECIPE_USER_DIR.mkdir(parents=True, exist_ok=True)
    dest = RECIPE_USER_DIR / f"{r['id']}.json"
    ecrire_atomique(dest, json.dumps(r, ensure_ascii=False, indent=2) + "\n")
    log.info("Recette apprise par l'exemple : %s (%d cible(s))", dest.name, len(r.get("targets") or []))
    return dest


def base_du_jeu(game: Game) -> dict | None:
    """La recette deja connue pour ce jeu (livree ou partagee), en dictionnaire."""
    try:
        from .engine import load_recipes, select_recipe
        connue = select_recipe(game, [x for x in load_recipes()
                                      if not str(getattr(x, "id", "")).startswith("exemple_")])
        if connue is None or not connue.match:
            return None
        data = json.loads(json.dumps(connue.data))
        data.pop("community", None)
        return data
    except Exception:
        log.debug("Recette connue illisible pour %s", game.title)
        return None
