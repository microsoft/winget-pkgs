"""Recettes partagees : ORION apprend des autres utilisateurs.

Le principe est volontairement simple et sans serveur : un depot public
contient un fichier `index.json` qui liste les recettes disponibles avec leur
version. ORION le lit au demarrage, telecharge celles qui manquent ou qui ont
ete mises a jour, et les depose a cote des recettes personnelles.

Consequence directe : chaque recette ecrite par un utilisateur (a la main ou
par l'assistant IA) peut profiter a tous les autres, et la couverture des jeux
grandit sans que l'application change d'une ligne.

Format attendu de l'index :

    {
      "name": "Recettes communautaires ORION",
      "updated": "2026-09-20",
      "recipes": [
        {"id": "cyberpunk2077", "file": "recipes/cyberpunk2077.json",
         "version": 3, "title": "Cyberpunk 2077", "author": "FoxSikh"}
      ]
    }
"""
from __future__ import annotations

import json
import time
from pathlib import Path

from .core.config import CONFIG
from .core.logging_setup import get
from .core.paths import RECIPE_COMMUNITY_DIR, RECIPE_USER_DIR, ensure_dirs

log = get("communaute")

STATE_FILE = RECIPE_COMMUNITY_DIR / "_index_local.json"
HEADERS = {"User-Agent": "ORION-Launcher/1.0 (+local)"}


def _base_url(index_url: str) -> str:
    return index_url.rsplit("/", 1)[0] + "/"


class CommunityRecipes:
    """Telechargement et partage des recettes de la communaute."""

    def __init__(self) -> None:
        ensure_dirs()
        self.state: dict = {}
        self._load_state()

    # -- etat local -----------------------------------------------------
    def _load_state(self) -> None:
        try:
            if STATE_FILE.exists():
                self.state = json.loads(STATE_FILE.read_text("utf-8"))
        except Exception:
            self.state = {}

    def _save_state(self) -> None:
        try:
            STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
            STATE_FILE.write_text(json.dumps(self.state, indent=1,
                                             ensure_ascii=False), "utf-8")
        except Exception:
            log.debug("Etat des recettes communautaires non enregistre")

    @property
    def installed(self) -> int:
        try:
            return len(list(RECIPE_COMMUNITY_DIR.glob("*.json"))) - (
                1 if STATE_FILE.exists() else 0)
        except Exception:
            return 0

    @property
    def last_sync(self) -> float:
        return float(self.state.get("last_sync") or 0)

    # -- synchronisation ------------------------------------------------
    def should_sync(self) -> bool:
        if not CONFIG.get("community.enabled", True):
            return False
        hours = float(CONFIG.get("community.sync_hours", 24) or 24)
        return (time.time() - self.last_sync) > hours * 3600

    def sync(self, force: bool = False) -> dict:
        """Recupere les recettes manquantes ou mises a jour."""
        result = {"added": 0, "updated": 0, "total": 0, "error": ""}
        if not CONFIG.get("community.enabled", True) and not force:
            result["error"] = "Partage desactive dans les reglages."
            return result

        index_url = str(CONFIG.get("community.index_url") or "").strip()
        if not index_url:
            result["error"] = "Aucune adresse de depot configuree."
            return result

        from orion.core import reseau
        try:
            r = reseau.get(index_url, headers=HEADERS, timeout=15)
            if r.status_code != 200:
                result["error"] = f"Depot injoignable (code {r.status_code})."
                return result
            index = r.json() or {}
        except Exception as exc:
            result["error"] = f"Depot injoignable : {exc}"
            return result

        entries = index.get("recipes") or []
        result["total"] = len(entries)
        known = self.state.setdefault("recipes", {})
        base = _base_url(index_url)

        for entry in entries:
            rid = str(entry.get("id") or "").strip()
            rel = str(entry.get("file") or "").strip()
            if not rid or not rel:
                continue
            version = int(entry.get("version") or 1)
            if known.get(rid, {}).get("version", 0) >= version and not force:
                continue
            # une recette personnelle du meme nom n'est jamais ecrasee
            if (RECIPE_USER_DIR / f"{rid}.json").exists():
                continue
            url = rel if rel.startswith("http") else base + rel.lstrip("/")
            try:
                rr = reseau.get(url, headers=HEADERS, timeout=15)
                if rr.status_code != 200:
                    continue
                from .optimizer import securite
                attendue = str(entry.get("sha256") or "").lower()
                if attendue and securite.empreinte(rr.content) != attendue:
                    log.warning("Recette %s ignoree : empreinte differente de "
                                "celle publiee dans l'index", rid)
                    continue
                data = rr.json()
                # une recette peut n'apporter que des conseils : c'est le cas
                # du reglage ecran seul, qui n'ecrit dans aucun fichier.
                if not isinstance(data, dict) or not (
                        data.get("targets") or data.get("advice")):
                    continue
                ok, raisons = securite.verifier_recette(data, partagee=True)
                if not ok:
                    log.warning("Recette %s refusee : %s", rid, "; ".join(raisons[:4]))
                    result.setdefault("refusees", 0)
                    result["refusees"] += 1
                    continue
                data.setdefault("id", rid)
                data["community"] = {
                    "author": entry.get("author", ""),
                    "version": version,
                    "source": url,
                }
                dest = RECIPE_COMMUNITY_DIR / f"{rid}.json"
                existed = dest.exists()
                texte = json.dumps(data, indent=2, ensure_ascii=False)
                # octets exacts : en mode texte, Windows change les fins de
                # ligne et le fichier ne correspond plus a son empreinte
                dest.write_bytes(texte.encode("utf-8"))
                known[rid] = {"version": version,
                              "title": entry.get("title", rid),
                              "sha256": securite.empreinte(texte.encode("utf-8"))}
                result["updated" if existed else "added"] += 1
            except Exception:
                log.debug("Recette communautaire ignoree : %s", rid)

        self.state["last_sync"] = time.time()
        self._save_state()
        log.info("Recettes communautaires : %s", result)
        return result

    # -- partage --------------------------------------------------------
    @staticmethod
    def prepare_share(recipe_path: Path, author: str = "") -> tuple[bool, str]:
        """Prepare une recette personnelle pour le partage.

        Le fichier est copie dans un sous-dossier `a_partager` avec l'entree
        d'index correspondante, prete a etre deposee sur le depot.
        """
        try:
            data = json.loads(Path(recipe_path).read_text("utf-8"))
        except Exception as exc:
            return False, f"Recette illisible : {exc}"

        rid = str(data.get("id") or Path(recipe_path).stem)
        data.pop("community", None)
        out_dir = RECIPE_USER_DIR / "a_partager"
        out_dir.mkdir(parents=True, exist_ok=True)

        (out_dir / f"{rid}.json").write_text(
            json.dumps(data, indent=2, ensure_ascii=False), "utf-8")

        entry = {"id": rid, "file": f"recipes/{rid}.json", "version": 1,
                 "title": data.get("name", rid), "author": author}
        (out_dir / f"{rid}.index.json").write_text(
            json.dumps(entry, indent=2, ensure_ascii=False), "utf-8")

        return True, str(out_dir)
