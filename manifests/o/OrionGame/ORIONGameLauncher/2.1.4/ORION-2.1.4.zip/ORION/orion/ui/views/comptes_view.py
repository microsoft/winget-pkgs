"""Page « Comptes » (1.8) : connexion aux plateformes de jeu.

Une carte par plateforme connectable (Steam, GOG, Xbox) avec :
son statut, la nature de la connexion (officielle, toleree, locale), le
profil du joueur (niveau, badges, score), ses chiffres (jeux, heures,
succes) et ses jeux les plus joues. En dessous, les plateformes qui
restent en lecture locale, avec la raison en clair.
"""
from __future__ import annotations

import time

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (QFrame, QGridLayout, QHBoxLayout, QLabel,
                               QPushButton, QVBoxLayout, QWidget)

from ...comptes import CATALOGUE_LOCAL, NATURES, PLATEFORMES
from ...i18n import t
from ..widgets.layouts import clear_layout
from ..defilement import ZoneDefilante


def _heures(minutes: int) -> str:
    h = minutes / 60
    if h >= 100:
        return f"{h:,.0f} h".replace(",", " ")
    return f"{h:.1f} h".replace(".", ",") if h < 10 else f"{h:.0f} h"


class CarteCompte(QFrame):
    connecter = Signal(str)
    deconnecter = Signal(str)
    actualiser = Signal(str)
    cle = Signal(str)

    def __init__(self, pid: str, parent=None) -> None:
        super().__init__(parent)
        self.pid = pid
        p = PLATEFORMES[pid]
        self.setObjectName("Panel")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(18, 16, 18, 16)
        lay.setSpacing(8)

        tete = QHBoxLayout()
        nom = QLabel(p.nom)
        nom.setObjectName("PanelTitle")
        tete.addWidget(nom)
        nature = QLabel(NATURES[p.nature])
        nature.setObjectName("Pastille")
        nature.setProperty("nature", p.nature)
        nature.setToolTip({
            "officiel": "Methode publiee par la plateforme.",
            "tolere": "Methode non officielle, utilisee depuis des annees par les "
                      "launchers libres (Heroic, Legendary, Playnite). Jamais de mot de "
                      "passe transmis a ORION.",
            "local": "Rien ne sort du PC."}[p.nature])
        tete.addWidget(nature)
        tete.addStretch(1)
        self.statut = QLabel("")
        self.statut.setObjectName("Faint")
        tete.addWidget(self.statut)
        lay.addLayout(tete)

        self.apport = QLabel(p.apport)
        self.apport.setObjectName("Dim")
        self.apport.setWordWrap(True)
        lay.addWidget(self.apport)

        self.profil = QLabel("")
        self.profil.setWordWrap(True)
        self.profil.setTextFormat(Qt.TextFormat.RichText)
        self.profil.setOpenExternalLinks(True)
        lay.addWidget(self.profil)

        self.chiffres = QLabel("")
        self.chiffres.setObjectName("Value")
        self.chiffres.setWordWrap(True)
        lay.addWidget(self.chiffres)

        self.top = QLabel("")
        self.top.setObjectName("Dim")
        self.top.setWordWrap(True)
        lay.addWidget(self.top)

        self.alerte = QLabel("")
        self.alerte.setObjectName("Alerte")
        self.alerte.setWordWrap(True)
        self.alerte.hide()
        lay.addWidget(self.alerte)

        boutons = QHBoxLayout()
        boutons.setSpacing(8)
        self.b_connecter = QPushButton("Se connecter")
        self.b_connecter.setObjectName("Primary")
        self.b_connecter.clicked.connect(lambda: self.connecter.emit(self.pid))
        boutons.addWidget(self.b_connecter)
        self.b_cle = QPushButton("Ajouter ma cle Web API")
        self.b_cle.clicked.connect(lambda: self.cle.emit(self.pid))
        self.b_cle.hide()
        boutons.addWidget(self.b_cle)
        self.b_actualiser = QPushButton("Actualiser")
        self.b_actualiser.setObjectName("Ghost")
        self.b_actualiser.clicked.connect(lambda: self.actualiser.emit(self.pid))
        boutons.addWidget(self.b_actualiser)
        self.b_deconnecter = QPushButton("Se deconnecter")
        self.b_deconnecter.setObjectName("Ghost")
        self.b_deconnecter.setToolTip("Efface le jeton garde sur ce PC.")
        self.b_deconnecter.clicked.connect(lambda: self.deconnecter.emit(self.pid))
        boutons.addWidget(self.b_deconnecter)
        boutons.addStretch(1)
        lay.addLayout(boutons)
        self.definir(None, [], "")

    # ------------------------------------------------------------------
    def definir(self, profil, jeux: list, erreur: str = "", occupe: bool = False) -> None:
        connecte = profil is not None
        self.b_connecter.setVisible(not connecte)
        self.b_actualiser.setVisible(connecte)
        self.b_deconnecter.setVisible(connecte)
        self.b_actualiser.setEnabled(not occupe)
        self.b_connecter.setEnabled(not occupe)
        # deconnecter pendant une actualisation laissait la tache en cours
        # reecrire le profil et les jeux qui venaient d'etre effaces
        self.b_deconnecter.setEnabled(not occupe)
        self.b_cle.setEnabled(not occupe)
        self.apport.setVisible(not connecte)
        cle_manquante = bool(connecte and profil.extra.get("cle_manquante"))
        self.b_cle.setVisible(cle_manquante)
        self.alerte.setVisible(bool(erreur) or cle_manquante)
        self.alerte.setText(erreur or (
            "Connecte, mais sans cle Web API : Steam ne donne alors que votre "
            "identifiant. Ajoutez votre cle (gratuite) pour voir vos jeux, succes, "
            "niveau et badges."))

        if occupe:
            self.statut.setText("Actualisation...")
        elif connecte:
            maj = time.strftime("%d/%m %H:%M", time.localtime(profil.maj)) if profil.maj else ""
            self.statut.setText(f"Connecte · {maj}" if maj else "Connecte")
        else:
            self.statut.setText("Non connecte")

        if not connecte:
            self.profil.setText("")
            self.chiffres.setText("")
            self.top.setText("")
            return

        morceaux = []
        nom = profil.pseudo or profil.id
        if profil.adresse:
            from ..theme import accent
            morceaux.append(f'<b><a style="color:{accent()}; text-decoration:none" '
                            f'href="{profil.adresse}">{nom}</a></b>')
        else:
            morceaux.append(f"<b>{nom}</b>")
        if profil.niveau is not None:
            morceaux.append(t(f"niveau {profil.niveau}"))
        if profil.xp is not None and profil.xp_prochain_niveau:
            morceaux.append(t(f"{profil.xp} XP ({profil.xp_prochain_niveau} pour le "
                              "niveau suivant)"))
        if profil.badges is not None:
            morceaux.append(t(f"{profil.badges} badges"))
        if profil.score:
            morceaux.append(f"{profil.score:,} G".replace(",", " "))
        if profil.membre_depuis:
            morceaux.append(t("membre depuis ") + time.strftime(
                "%Y", time.localtime(profil.membre_depuis)))
        if profil.prive:
            morceaux.append(t("<i>profil prive : certaines donnees peuvent manquer</i>"))
        self.profil.setText(" · ".join(morceaux))

        if jeux:
            total = sum(j.minutes for j in jeux)
            joues = sum(1 for j in jeux
                        if j.minutes > 0 or j.derniere_partie or j.succes_obtenus)
            txt = t(f"{len(jeux)} jeux · {joues} lances")
            if total:
                txt += t(f" · {_heures(total)} de jeu")
            obtenus = sum(j.succes_obtenus for j in jeux)
            if obtenus:
                txt += t(f" · {obtenus} succes")
            recent = sum(j.minutes_2sem for j in jeux)
            if recent:
                txt += t(f" · {_heures(recent)} ces deux dernieres semaines")
            self.chiffres.setText(txt)
            tops = sorted((j for j in jeux if j.minutes), key=lambda j: -j.minutes)[:5]
            if not tops:
                tops = sorted(jeux, key=lambda j: -j.derniere_partie)[:5]
            self.top.setText(t("Les plus joues : ") + ", ".join(
                f"{j.titre} ({_heures(j.minutes)})" if j.minutes else j.titre
                for j in tops) if tops else "")
        else:
            self.chiffres.setText("")
            self.top.setText("")


#: jeux en double cites en clair (les autres sont dans l'infobulle)
DOUBLONS_MONTRES = 6


def synthese(comptes: dict) -> str:
    """Une phrase pour tous les comptes connectes : `comptes` associe une
    plateforme a (profil, jeux). Vide si aucun compte n'est connecte."""
    connectes = {pid: jeux for pid, (profil, jeux) in comptes.items() if profil is not None}
    if not connectes:
        return ""
    n = len(connectes)
    jeux = [j for liste in connectes.values() for j in liste]
    texte = t(f"{n} comptes connectes") if n > 1 else t("1 compte connecte")
    if jeux:
        texte += t(f" · {len(jeux)} jeux")
        minutes = sum(j.minutes for j in jeux)
        if minutes:
            texte += t(f" · {_heures(minutes)} de jeu")
        obtenus = sum(j.succes_obtenus for j in jeux)
        if obtenus:
            texte += t(f" · {obtenus} succes")
        jamais = sum(1 for j in jeux
                     if not (j.minutes or j.derniere_partie or j.succes_obtenus))
        if jamais:
            texte += t(f" · {jamais} jamais lances")
    return texte


class ComptesView(QWidget):
    connecter = Signal(str)
    deconnecter = Signal(str)
    actualiser = Signal(str)
    cle = Signal(str)
    tout_actualiser = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = ZoneDefilante()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        outer.addWidget(scroll)
        corps = QWidget()
        scroll.setWidget(corps)
        self.root = QVBoxLayout(corps)
        self.root.setContentsMargins(24, 18, 24, 28)     # meme en-tete que les autres pages
        self.root.setSpacing(14)

        titre = QLabel("Comptes")
        titre.setObjectName("PageTitle")
        self.root.addWidget(titre)
        intro = QLabel(
            "Connectez vos comptes pour retrouver tous vos jeux, installes ou non, "
            "votre temps de jeu, vos succes et votre profil. ORION ne voit jamais "
            "vos mots de passe : la connexion se fait sur la page officielle de "
            "chaque plateforme, et seul un jeton, chiffre par Windows, est garde sur "
            "ce PC. Lecture seule : ORION ne peut rien acheter ni modifier.")
        intro.setObjectName("Dim")
        intro.setWordWrap(True)
        self.root.addWidget(intro)

        # -- synthese de tous les comptes ---------------------------------
        ligne = QHBoxLayout()
        ligne.setSpacing(10)
        self.synthese = QLabel("")
        self.synthese.setObjectName("Value")
        self.synthese.setWordWrap(True)
        ligne.addWidget(self.synthese, 1)
        self.b_tout = QPushButton("Tout actualiser")
        self.b_tout.setObjectName("Ghost")
        self.b_tout.setToolTip("Relit le profil et les jeux de chaque compte connecte.")
        self.b_tout.clicked.connect(self.tout_actualiser.emit)
        ligne.addWidget(self.b_tout)
        self.root.addLayout(ligne)
        self.synthese.hide()                  # rien a resumer sans compte connecte
        self.b_tout.hide()
        self._comptes: dict[str, tuple] = {}       # pid -> (profil, jeux)
        self._occupes: set[str] = set()
        self._bibliotheque: dict[str, list[str]] = {}

        grille = QGridLayout()
        grille.setSpacing(14)
        self.cartes: dict[str, CarteCompte] = {}
        for i, pid in enumerate(PLATEFORMES):
            c = CarteCompte(pid)
            c.connecter.connect(self.connecter.emit)
            c.deconnecter.connect(self.deconnecter.emit)
            c.actualiser.connect(self.actualiser.emit)
            c.cle.connect(self.cle.emit)
            grille.addWidget(c, i // 2, i % 2)
            self.cartes[pid] = c
        self.root.addLayout(grille)

        # -- jeux presents sur plusieurs plateformes ------------------------
        self.doublons = QFrame()
        self.doublons.setObjectName("PanelFlat")
        dl = QVBoxLayout(self.doublons)
        dl.setContentsMargins(14, 10, 14, 10)
        dl.setSpacing(3)
        self.doublons_titre = QLabel("")
        self.doublons_titre.setObjectName("Value")
        dl.addWidget(self.doublons_titre)
        self.doublons_liste = QLabel("")
        self.doublons_liste.setObjectName("Dim")
        self.doublons_liste.setWordWrap(True)
        dl.addWidget(self.doublons_liste)
        aide = QLabel("A savoir avant un achat, ou pour choisir la plateforme sur "
                      "laquelle installer le jeu.")
        aide.setObjectName("Faint")
        aide.setWordWrap(True)
        dl.addWidget(aide)
        self.doublons.hide()
        self.root.addWidget(self.doublons)

        autres = QLabel("Autres plateformes")
        autres.setObjectName("SectionTitle")
        self.root.addWidget(autres)
        self.locales = QVBoxLayout()
        self.locales.setSpacing(6)
        self.root.addLayout(self.locales)
        self.set_locales({})
        self.root.addStretch(1)

    def set_compte(self, pid: str, profil, jeux: list, erreur: str = "",
                   occupe: bool = False) -> None:
        if pid in self.cartes:
            self.cartes[pid].definir(profil, jeux, erreur, occupe)
            self._comptes[pid] = (profil, list(jeux or []))
            (self._occupes.add if occupe else self._occupes.discard)(pid)
            self._resumer()

    def set_bibliotheque(self, titres_par_source: dict[str, list[str]]) -> None:
        """Titres des jeux connus hors comptes (installes, possedes lus sur
        le PC), par nom de plateforme : ils comptent pour les doublons."""
        self._bibliotheque = {k: list(v) for k, v in (titres_par_source or {}).items()}
        self._resumer()

    def jeux_en_double(self) -> list[tuple[str, list[str]]]:
        from ...comptes import doublons
        par_plateforme: dict[str, list[str]] = {
            k: list(v) for k, v in self._bibliotheque.items()}
        for pid, (profil, jeux) in self._comptes.items():
            if profil is not None:
                par_plateforme.setdefault(PLATEFORMES[pid].nom, []).extend(
                    j.titre for j in jeux)
        return doublons(par_plateforme)

    def _resumer(self) -> None:
        texte = synthese(self._comptes)
        connectes = [pid for pid, (profil, _j) in self._comptes.items() if profil is not None]
        self.synthese.setText(texte)
        self.synthese.setVisible(bool(texte))
        self.b_tout.setVisible(len(connectes) > 1)
        self.b_tout.setEnabled(not self._occupes)
        self.b_tout.setText("Actualisation..." if self._occupes else "Tout actualiser")
        doubles = self.jeux_en_double()
        self.doublons.setVisible(bool(doubles))
        if doubles:
            n = len(doubles)
            self.doublons_titre.setText(
                t(f"{n} jeux presents sur plusieurs plateformes") if n > 1
                else t("1 jeu present sur plusieurs plateformes"))
            lignes = [f"{titre} ({', '.join(noms)})" for titre, noms in doubles]
            self.doublons_liste.setText(
                " · ".join(lignes[:DOUBLONS_MONTRES])
                + (t(f" · et {n - DOUBLONS_MONTRES} autres")
                   if n > DOUBLONS_MONTRES else ""))
            self.doublons_liste.setToolTip("\n".join(lignes[:60]))

    def set_locales(self, installes: dict[str, int]) -> None:
        if installes == getattr(self, "_locales_montrees", None):
            return                       # memes chiffres : rien a refaire
        self._locales_montrees = dict(installes)
        clear_layout(self.locales)
        for pid, nom, nature, texte in CATALOGUE_LOCAL:
            ligne = QFrame()
            ligne.setObjectName("PanelFlat")
            h = QVBoxLayout(ligne)
            h.setContentsMargins(14, 10, 14, 10)
            h.setSpacing(3)
            n = installes.get(pid, 0)
            tete = QLabel(f"<b>{nom}</b> · {t(NATURES[nature])}"
                          + (t(f" · {n} jeux installes") if n > 1 else
                             t(" · 1 jeu installe") if n else ""))
            h.addWidget(tete)
            explication = QLabel(texte)
            explication.setObjectName("Faint")
            explication.setWordWrap(True)
            h.addWidget(explication)
            self.locales.addWidget(ligne)
