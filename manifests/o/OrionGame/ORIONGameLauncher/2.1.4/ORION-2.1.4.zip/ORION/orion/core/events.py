"""Bus d'evenements minimaliste.

Les modules publient des evenements sans se connaitre : l'interface s'abonne,
un futur plugin (overlay, Discord, statistiques...) s'abonne aussi, sans
qu'aucun code existant n'ait a etre modifie.
"""
from __future__ import annotations

from collections import defaultdict
from typing import Any, Callable

from .logging_setup import get

log = get("events")

Handler = Callable[..., Any]


class EventBus:
    def __init__(self) -> None:
        self._subs: dict[str, list[Handler]] = defaultdict(list)

    def on(self, topic: str, handler: Handler) -> Handler:
        self._subs[topic].append(handler)
        return handler

    def off(self, topic: str, handler: Handler) -> None:
        if handler in self._subs.get(topic, []):
            self._subs[topic].remove(handler)

    def emit(self, topic: str, **payload: Any) -> None:
        for h in list(self._subs.get(topic, [])):
            try:
                h(**payload)
            except Exception:
                log.exception("Erreur dans un abonne de '%s'", topic)


#: Bus partage par toute l'application.
BUS = EventBus()


# --- Noms d'evenements (constantes pour eviter les fautes de frappe) ---------
SCAN_STARTED = "scan.started"
SCAN_SOURCE_DONE = "scan.source_done"
SCAN_FINISHED = "scan.finished"
ART_UPDATED = "art.updated"
GAME_LAUNCHED = "game.launched"
GAME_EXITED = "game.exited"
DISPLAY_CHANGED = "display.changed"
TWEAKS_APPLIED = "tweaks.applied"
NOTIFY = "ui.notify"
