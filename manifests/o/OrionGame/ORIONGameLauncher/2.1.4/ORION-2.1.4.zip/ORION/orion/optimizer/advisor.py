"""Conseils : ce qu'ORION a remarque sur la machine et sur chaque jeu.

Chaque regle est une petite fonction independante enregistree dans une liste :
en ajouter une ne demande de toucher a rien d'autre.

Les conseils sont ranges en quatre groupes (Pilotes, Windows, Materiel,
Jeux). Chacun s'appuie sur une valeur lue sur la machine — version et date
d'un pilote, cle de registre, vitesse configuree de la memoire... — rappelee
dans `preuve` : ORION n'affirme jamais qu'un element est depasse sans
l'avoir constate.

Les regles qui exploitent l'etat du systeme (`hardware/systeme.py`) sont
ecrites comme des fonctions pures (`conseils_pilotes`, `conseils_windows`,
`conseils_materiel`, `conseils_jeux`) pour etre testees hors de Windows.
"""
from __future__ import annotations

import datetime as _dt
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable

from ..core.config import CONFIG
from ..core.logging_setup import get
from ..core.models import Display, Game, GPUInfo, HardwareInfo
from ..hardware import pages_support as _pages
from ..hardware import systeme as _sys

log = get("optimizer.conseils")

GROUPES = ("Pilotes", "Windows", "Materiel", "Jeux")


@dataclass
class Advice:
    level: str            # info | conseil | attention | ok
    title: str
    detail: str
    action: str = ""      # texte du bouton eventuel
    action_url: str = ""
    groupe: str = ""      # Pilotes | Windows | Materiel | Jeux
    preuve: str = ""      # valeurs lues sur la machine (une par ligne)

    @property
    def rank(self) -> int:
        return {"attention": 0, "conseil": 1, "info": 2, "ok": 3}.get(self.level, 4)


SystemRule = Callable[[HardwareInfo], list[Advice]]
GameRule = Callable[[Game, HardwareInfo, Display | None], list[Advice]]
GamesRule = Callable[[list[Game], HardwareInfo], list[Advice]]

SYSTEM_RULES: list[SystemRule] = []
GAME_RULES: list[GameRule] = []
GAMES_RULES: list[GamesRule] = []
_GROUPE_REGLE: dict[str, str] = {}


def system_rule(fn: SystemRule | None = None, *, groupe: str = "Materiel"):
    """Enregistre une regle machine ; `groupe` est applique a ses conseils."""
    def enregistrer(f: SystemRule) -> SystemRule:
        SYSTEM_RULES.append(f)
        _GROUPE_REGLE[f.__name__] = groupe
        return f
    return enregistrer(fn) if fn is not None else enregistrer


def game_rule(fn: GameRule) -> GameRule:
    GAME_RULES.append(fn)
    return fn


def games_rule(fn: GamesRule) -> GamesRule:
    """Regle sur l'ensemble de la bibliotheque (groupe Jeux de la page)."""
    GAMES_RULES.append(fn)
    _GROUPE_REGLE[fn.__name__] = "Jeux"
    return fn


def _etat(hw: HardwareInfo):
    """Etat du systeme joint par la sonde (None hors Windows ou en echec)."""
    return getattr(hw, "systeme", None)


def _date(d: _dt.date | None) -> str:
    return f"{d.day:02d}/{d.month:02d}/{d.year}" if d else "date inconnue"


def _duree(jours: int) -> str:
    if jours >= 730:
        return f"{jours // 365} ans"
    return f"{max(1, jours // 30)} mois"


# --------------------------------------------------------------------------
# Regles machine (groupe Materiel)
# --------------------------------------------------------------------------

@system_rule
def _disk_space(hw: HardwareInfo) -> list[Advice]:
    if not CONFIG.get("advisor.check_disk_space", True):
        return []
    out = []
    for d in hw.disks:
        free, total = d.get("free_gb", 0), d.get("total_gb", 1)
        if d.get("type") in ("cdrom", "network", "removable"):
            continue
        systeme = str(d.get("mount", "")).upper().startswith("C")
        # seuils : quelques pourcents de la capacite, bornes en Go
        critique = max(25, min(total * 0.05, 40)) if systeme else 25
        limite = max(60, min(total * 0.10, 100))
        if total and free < critique:
            out.append(Advice(
                "attention", f"Disque {d['mount']} presque plein",
                f"Il reste {free} Go sur {total} Go. Avec si peu de place, "
                "Windows et les jeux perdent en reactivite (fichier "
                "d'echange, cache de shaders) et les mises a jour echouent.",
                preuve=f"{d['mount']} : {free} Go libres sur {total} Go"))
        elif total and systeme and free < limite:
            out.append(Advice(
                "conseil", f"Espace limite sur {d['mount']}",
                f"{free} Go libres. Windows a besoin de marge pour ses mises a "
                "jour, le fichier d'echange et le cache de shaders : deplacez "
                "une bibliotheque de jeux vers un autre disque depuis le "
                "launcher, ou desinstallez ce qui dort (page Stockage).",
                preuve=f"{d['mount']} : {free} Go libres sur {total} Go"))
    return out


@system_rule
def _refresh_rate(hw: HardwareInfo) -> list[Advice]:
    out = []
    for d in hw.displays:
        if not d.current or not d.modes:
            continue
        best = d.best_refresh(d.current.width, d.current.height)
        if best - d.current.refresh >= 10:
            out.append(Advice(
                "attention", f"{d.name} tourne a {d.current.refresh} Hz",
                f"Cet ecran accepte {best} Hz en {d.current.width}x{d.current.height}. "
                "ORION peut appliquer la frequence maximale au lancement d'un jeu.",
                action="Passer a la frequence maximale",
                preuve=f"Mode actuel : {d.current} ; meilleur mode : "
                       f"{d.current.width}x{d.current.height} @ {best} Hz"))
        native = d.native
        if native and d.current and native.pixels > d.current.pixels:
            out.append(Advice(
                "conseil", f"{d.name} n'est pas en definition native",
                f"Affichage en {d.current.width}x{d.current.height} alors que la "
                f"dalle accepte {native.width}x{native.height}."))
    return out


@system_rule
def _super_resolution(hw: HardwareInfo) -> list[Advice]:
    """Signale les definitions superieures a la dalle (DSR NVIDIA, VSR AMD)."""
    out = []
    for d in hw.displays:
        if not d.native or not d.modes:
            continue
        bigger = [m for m in d.modes if m.pixels > d.native.pixels]
        if not bigger:
            continue
        best = max(bigger, key=lambda m: m.pixels)
        level = "attention" if (d.current and
                                d.current.pixels > d.native.pixels) else "info"
        detail = (f"{d.name} accepte des definitions au-dela de sa dalle "
                  f"(jusqu'a {best.width}x{best.height}) : c'est le DSR/VSR du "
                  f"pilote. ORION ne les applique jamais automatiquement et "
                  f"s'en tient a {d.native.width}x{d.native.height}.")
        if level == "attention":
            detail += (" Attention : l'ecran tourne actuellement dans une de "
                       "ces definitions, ce qui coute beaucoup de performances.")
        out.append(Advice(level, "Super-resolution du pilote activee", detail))
    return out


@system_rule
def _vram(hw: HardwareInfo) -> list[Advice]:
    gpu = hw.gpu
    if not gpu.name:
        return []
    big = any(d.native and d.native.pixels > 3_500_000 for d in hw.displays)
    if gpu.vram_mb and gpu.vram_mb < 8000 and big:
        return [Advice(
            "conseil", "Memoire video juste pour cette definition",
            f"{gpu.vram_mb} Mo de VRAM pour un ecran 4K : baissez les textures "
            "d'un cran et activez la super-resolution pour eviter les saccades.")]
    return []


@system_rule
def _cpu_balance(hw: HardwareInfo) -> list[Advice]:
    if hw.cpu_threads and hw.cpu_threads <= 8 and hw.gpu.tier >= 3:
        return [Advice(
            "info", "Le processeur peut limiter la carte graphique",
            f"{hw.cpu_name} ({hw.cpu_threads} fils d'execution) avec un GPU haut "
            "de gamme : en competition, jouer en definition native evite de "
            "reporter la charge sur le processeur.")]
    if hw.ram_gb and hw.ram_gb < 16:
        return [Advice(
            "attention", "Memoire vive limitee",
            f"{hw.ram_gb} Go : les jeux recents en demandent 16 Go pour eviter "
            "les micro-saccades liees au fichier d'echange.")]
    return []


@system_rule
def _materiel_systeme(hw: HardwareInfo) -> list[Advice]:
    etat = _etat(hw)
    return conseils_materiel(etat, hw) if etat is not None else []


# --------------------------------------------------------------------------
# Pilotes
# --------------------------------------------------------------------------

#: au-dela, un pilote fourni par le fabricant est signale (en jours)
SEUIL_GRAPHIQUE = 240
SEUIL_GRAPHIQUE_FORT = 730
SEUIL_PILOTE = 730                  # chipset, reseau, audio, stockage, USB, Bluetooth

CATEGORIES = {
    "graphique": "Carte graphique",
    "reseau": "Reseau",
    "audio": "Audio",
    "chipset": "Chipset",
    "stockage": "Stockage",
    "usb": "USB",
    "bluetooth": "Bluetooth",
}

#: pourquoi chaque pilote compte en jeu
POURQUOI = {
    "graphique": "C'est lui qui traduit les images du jeu pour la carte : "
                 "chaque version apporte des optimisations pour les sorties "
                 "recentes et corrige plantages et saccades.",
    "reseau": "En ligne, latence, pertes de paquets et deconnexions dependent "
              "aussi du pilote de la carte reseau.",
    "audio": "Le pilote audio gere le son positionnel, la latence et les "
             "craquements en jeu.",
    "chipset": "Le chipset regle la gestion d'energie du processeur, la "
               "repartition des coeurs et la stabilite PCIe et USB : il pese "
               "sur les images par seconde minimales.",
    "stockage": "Le controleur de stockage influe sur les temps de chargement "
                "et le chargement des textures en cours de partie.",
    "usb": "Les controleurs USB portent manettes, souris haute frequence et "
           "casques : un pilote ancien provoque deconnexions et latence.",
    "bluetooth": "Manettes et casques sans fil passent par le Bluetooth : "
                 "latence et coupures en dependent.",
}

TITRES_ANCIEN = {
    "graphique": "Pilote graphique ancien",
    "reseau": "Pilote reseau ancien",
    "audio": "Pilote audio ancien",
    "chipset": "Pilotes du chipset anciens",
    "stockage": "Pilote de stockage ancien",
    "usb": "Pilote USB ancien",
    "bluetooth": "Pilote Bluetooth ancien",
}

LIENS = {
    "amd": "https://www.amd.com/fr/support/download/drivers.html",
    "intel": "https://www.intel.com/content/www/us/en/support/"
             "intel-driver-support-assistant.html",
    "nvidia": "https://www.nvidia.com/fr-fr/drivers/",
    "samsung": "https://semiconductor.samsung.com/consumer-storage/support/tools/",
}
BOUTONS = {
    "amd": "Pilotes AMD",
    "intel": "Intel Driver & Support Assistant",
    "nvidia": "Pilotes NVIDIA",
    "samsung": "Logiciels Samsung",
}

#: pages de support des fabricants de cartes meres et de PC portables
SUPPORT = (
    ("asus", "https://www.asus.com/fr/support/download-center/"),
    ("micro-star", "https://fr.msi.com/support"),
    ("msi", "https://fr.msi.com/support"),
    ("gigabyte", "https://www.gigabyte.com/fr/Support"),
    ("asrock", "https://www.asrock.com/support/index.fr.asp"),
    ("dell", "https://www.dell.com/support/home/fr-fr"),
    ("alienware", "https://www.dell.com/support/home/fr-fr"),
    ("hewlett", "https://support.hp.com/fr-fr/drivers"),
    ("hp", "https://support.hp.com/fr-fr/drivers"),
    ("lenovo", "https://pcsupport.lenovo.com/fr/fr"),
    ("acer", "https://www.acer.com/fr-fr/support/drivers-and-manuals"),
    ("samsung", "https://www.samsung.com/fr/support/downloadcenter/"),
    ("microsoft", "https://support.microsoft.com/fr-fr/surface/download-drivers-and-firmware-for-surface-09bb2e09-2a4b-cb69-0951-078a7739e120"),
    ("razer", "https://mysupport.razer.com/app/answers/detail/a_id/3618"),
    ("medion", "https://www.medion.com/fr/service/"),
    ("huawei", "https://consumer.huawei.com/fr/support/"),
    ("honor", "https://www.honor.com/fr/support/"),
    ("xiaomi", "https://www.mi.com/fr/support/"),
    ("dynabook", "https://support.dynabook.com/"),
    ("toshiba", "https://support.dynabook.com/"),
    ("fujitsu", "https://support.ts.fujitsu.com/"),
    ("lg", "https://www.lg.com/fr/support/"),
)


def _fabricant_carte(etat) -> tuple[str, str]:
    """(fabricant, modele) de la carte mere, ou du PC si elle est anonyme."""
    fab, mod = etat.carte_mere if etat else ("", "")
    if not fab or _sys.simple(fab) in ("", "to be filled by o.e.m.", "default string"):
        fab, mod = etat.pc if etat else ("", "")
    return fab, mod


def _page_support(etat) -> str:
    candidats = [_fabricant_carte(etat)[0]]
    if etat is not None and etat.pc and etat.pc[0]:
        candidats.insert(0, etat.pc[0])           # un portable HP a parfois une carte « Quanta »
    for fab in candidats:
        s = _sys.simple(fab)
        for motif, url in SUPPORT:
            if re.search(r"\b" + re.escape(motif), s):     # « asus » dans « asustek »
                return url
    return ""


#: constructeurs de PC complets (portables et tours de marque) : leurs pilotes
#: reseau, audio, chipset, stockage... sont adaptes au modele et se prennent
#: sur leur page support, pas chez Intel, Realtek ou Synaptics
#: (ASUS, MSI, Gigabyte, ASRock n'y sont pas : une tour montee soi-meme porte
#: le nom de sa carte mere comme « fabricant du PC » ; leurs portables sont
#: reconnus par le boitier)
CONSTRUCTEURS = ("hewlett", "hp", "dell", "alienware", "lenovo", "acer", "samsung", "lg",
                 "huawei", "honor", "xiaomi", "microsoft", "razer", "medion", "toshiba",
                 "dynabook", "fujitsu", "sony", "vaio")


def _nom_constructeur(fab: str) -> str:
    s = _sys.simple(fab)
    if "hewlett" in s or s.startswith("hp"):
        return "HP"
    for motif, nom in (("alienware", "Alienware"), ("dell", "Dell"), ("lenovo", "Lenovo"),
                       ("acer", "Acer"), ("asus", "ASUS"), ("micro-star", "MSI"), ("msi", "MSI"),
                       ("gigabyte", "Gigabyte"), ("samsung", "Samsung"), ("microsoft", "Microsoft"),
                       ("razer", "Razer"), ("medion", "Medion"), ("huawei", "Huawei"),
                       ("honor", "Honor"), ("xiaomi", "Xiaomi"), ("dynabook", "Dynabook"),
                       ("toshiba", "Toshiba"), ("fujitsu", "Fujitsu"), ("vaio", "VAIO"),
                       ("sony", "Sony"), ("lg", "LG")):
        if re.search(r"\b" + re.escape(motif), s):
            return nom
    return (fab or "").strip()


def _pc_de_marque(etat) -> bool:
    """Portable, ou tour vendue complete par un constructeur (HP, Dell...)."""
    if etat is None:
        return False
    if etat.boitier == "portable":
        return True
    fab = _sys.simple(etat.pc[0] if etat.pc else "")
    if not fab or fab in ("system manufacturer", "to be filled by o.e.m.", "default string"):
        return False
    return any(re.search(r"\b" + re.escape(m), fab) for m in CONSTRUCTEURS)


def _lien(p: _sys.Pilote, etat) -> tuple[str, str, str]:
    """(bouton, adresse, phrase « ou le trouver ») pour un pilote.

    Retour de l'auteur (8 octobre, portable HP) : les pilotes reseau, audio
    et stockage d'un portable renvoyaient vers l'assistant Intel, qui ne les
    fournit pas ; l'audio Synaptics renvoyait vers la page generale de HP.
    Sur un portable ou un PC de marque, tout sauf la carte graphique
    NVIDIA/AMD vient de la page support du constructeur, pour ce modele, avec
    le numero de produit qu'elle demande."""
    cat = p.categorie
    nom_carte, url_carte, modele_carte = _carte_ajoutee(p, etat)
    if nom_carte:
        quoi = "un appareil" if p.bus == "USB" else "une carte"
        pour = f" pour le modele {modele_carte}" if modele_carte else ""
        return ((f"Pilotes {nom_carte}{' ' + modele_carte if modele_carte else ''}" if url_carte else ""), url_carte,
                f"C'est {quoi} {nom_carte} ajoute{'' if quoi == 'un appareil' else 'e'} "
                f"dans le PC : son pilote se prend sur la page support de {nom_carte}{pour}, "
                f"pas sur celle de la carte mere ni chez le fabricant de la puce.")
    if _pc_de_marque(etat):
        if cat == "graphique" and p.marque in ("nvidia", "amd"):
            return BOUTONS[p.marque], LIENS[p.marque], ""
        fab, mod = etat.pc if etat.pc and etat.pc[0] else _fabricant_carte(etat)
        nom = _nom_constructeur(fab)
        genre_pc = "portable" if etat.boitier == "portable" else "pc"
        url, _n = _pages.page_modele(fab, mod, genre_pc)
        url = url or _page_support(etat) or _page_support_pc(etat)
        repere = (f" (numero de produit {etat.pc_sku})" if getattr(etat, "pc_sku", "") else "")
        genre = "un portable" if etat.boitier == "portable" else "un PC de marque"
        ou = (f"Sur {genre}, ce pilote se prend sur la page support de {nom} pour le "
              f"modele {mod}{repere}, pas chez le fabricant de la puce : les versions de "
              f"{nom} sont adaptees a la machine." if mod else
              f"Sur {genre}, ce pilote se prend sur la page support de {nom}, pas chez "
              f"le fabricant de la puce.")
        return (f"Pilotes {nom} pour ce modele" if url and nom else
                ("Ouvrir la page de support" if url else "")), url, ou
    # -- tour montee : les puces soudees sur la carte mere ---------------------
    # Retour de l'auteur (8 octobre, tour MSI) : les pilotes Intel de la carte
    # mere renvoyaient vers l'assistant Intel. Le fabricant de la puce publie
    # la derniere version par famille (Intel : reseau, Wi-Fi, Bluetooth,
    # chipset, graphique) ; sinon c'est la page support de la carte mere, pour
    # ce modele precis, qui fournit le pilote (audio Realtek, stockage, USB).
    if cat == "graphique" and p.marque in ("nvidia", "amd"):
        return BOUTONS[p.marque], LIENS[p.marque], ""
    fab, mod = _fabricant_carte(etat)
    nom = _nom_constructeur(fab)
    url_modele, nom_modele = _pages.page_modele(fab, mod, "carte_mere", _plateforme(etat))
    bouton_puce, url_puce = _pages.page_puce(p.marque, cat, p.nom)
    if bouton_puce:
        ou = (f"{p.marque.capitalize()} publie la derniere version de ce pilote pour toute la "
              f"famille de la puce ; la version validee pour la carte mere {mod} est aussi sur "
              f"la page support de {nom_modele or nom}." if mod else
              f"{p.marque.capitalize()} publie la derniere version de ce pilote pour toute la "
              f"famille de la puce.")
        return bouton_puce, url_puce, ou
    if url_modele:
        return (f"Pilotes {nom_modele} pour {mod}", url_modele,
                f"Sur une tour montee, ce pilote se prend sur la page support de {nom_modele} "
                f"pour la carte mere {mod} : c'est elle qui fournit les pilotes des puces "
                f"soudees dessus (reseau, audio, chipset, stockage), pas le fabricant de la puce.")
    if p.marque in LIENS:
        return BOUTONS[p.marque], LIENS[p.marque], ""
    url = _page_support(etat)
    ou = (f"La version a jour se trouve sur la page support de {nom or fab} "
          f"({mod})." if fab and mod else
          "La version a jour se trouve sur la page support du fabricant de "
          "la carte mere ou du PC.")
    return ("Ouvrir la page de support" if url else ""), url, ou


def _plateforme(etat) -> str:
    """« Intel » ou « AMD » d'apres les puces du chipset (ASRock range ses
    cartes meres par plateforme)."""
    for p in (etat.pilotes or []) if etat else []:
        if p.categorie == "chipset" and p.marque in ("intel", "amd"):
            return "Intel" if p.marque == "intel" else "AMD"
    return ""


#: pages support des fabricants de cartes d'extension absents de SUPPORT
PAGES_CARTES = (
    ("evga", "https://www.evga.com/support/drivers/"),
    ("tp-link", "https://www.tp-link.com/fr/support/download/"),
    ("creative", "https://support.creative.com/"),
    ("corsair", "https://www.corsair.com/fr/fr/s/downloads"),
    ("logitech", "https://support.logi.com/"),
    ("steelseries", "https://steelseries.com/gg"),
    ("razer", "https://www.razer.com/fr-fr/synapse-4"),
)


def _page_fabricant(nom: str) -> str:
    """La page support d'un fabricant nomme (carte mere, PC ou carte ajoutee)."""
    s = _sys.simple(nom)
    for motif, url in (*SUPPORT, *PAGES_CARTES):
        if re.search(r"\b" + re.escape(motif), s):
            return url
    return ""


def _carte_ajoutee(p: _sys.Pilote, etat) -> tuple[str, str, str]:
    """(nom, page support, modele) du fabricant d'une carte d'extension ou
    d'un appareil USB, quand la puce n'est ni soudee sur la carte mere ni
    fournie par le constructeur du PC. La page est celle du modele quand le
    nom de l'appareil le donne et que le fabricant a une adresse par modele
    (« ASUS XG-C100C » -> la page de la XG-C100C), sinon sa page generale.

    Retour de l'auteur (8 octobre, tour MSI) : la carte reseau 10G ASUS
    XG-C100C etait envoyee sur la page support de MSI. Le sous-systeme PCI
    (« SUBSYS_87411043 », 1043 = ASUS) dit qui a fabrique la carte ; le nom
    vient de la base publique des identifiants, pour n'importe quel
    fabricant. Un fabricant de puces (Intel, Realtek...) n'est jamais une
    carte ajoutee : sa puce suit la carte mere ou le PC."""
    if p.categorie == "graphique":
        return "", "", ""                # la carte graphique a son fabricant de puce
    fab = p.fabricant_carte
    if not fab or fab in _sys.PUCES.get(p.bus, ()):
        return "", "", ""
    nom = p.nom_fabricant_carte
    if not nom:
        return "", "", ""
    maison = {_sys.simple(_nom_constructeur(_fabricant_carte(etat)[0]))}
    if etat is not None and etat.pc and etat.pc[0]:
        maison.add(_sys.simple(_nom_constructeur(etat.pc[0])))
    if _sys.simple(nom) in maison:
        return "", "", ""                # puce de la carte mere ou du PC lui-meme
    url, modele = _pages.page_carte(nom, p.nom)
    return nom, url or _page_fabricant(nom), modele


def _page_support_pc(etat) -> str:
    """Page support d'apres le fabricant du PC (quand la carte mere est anonyme)."""
    fab = _sys.simple(etat.pc[0] if etat and etat.pc else "")
    for motif, url in SUPPORT:
        if re.search(r"\b" + re.escape(motif), fab):
            return url
    return ""


def _etiquette(p: _sys.Pilote, etat) -> str:
    """Qui distingue ce pilote dans un titre : le fabricant de la carte ajoutee
    (« ASUS »), sinon la marque de la puce (« Intel »)."""
    nom, _url, _modele = _carte_ajoutee(p, etat)
    return nom or {"amd": "AMD", "msi": "MSI", "asrock": "ASRock"}.get(
        p.marque, (p.marque or p.fabricant or p.nom).capitalize())


def _ligne(p: _sys.Pilote) -> str:
    return (f"{p.nom} · version {p.version or '?'} · {_date(p.date)} · "
            f"{p.fournisseur or 'fournisseur inconnu'}")


def _age_constate(p: _sys.Pilote, aujourdhui: _dt.date) -> int | None:
    """Age d'un pilote fourni par le fabricant ; None pour un pilote Microsoft
    (tenu a jour par Windows Update) ou une date factice."""
    if p.generique:
        return None
    return p.age_jours(aujourdhui)


def _marque_cpu(nom: str) -> str:
    s = (nom or "").lower()
    return "amd" if ("amd" in s or "ryzen" in s) else ("intel" if "intel" in s else "")


_GENERIQUE_AUDIO = re.compile(r"^(high definition audio device|peripherique high "
                              r"definition audio)", re.I)
_GENERIQUE_BT = re.compile(r"(generic bluetooth|bluetooth generique|"
                           r"adaptateur bluetooth generique)", re.I)
_SANS_PILOTE_CODES = {
    1: "mal configure", 10: "ne peut pas demarrer", 18: "pilote a reinstaller",
    28: "aucun pilote installe", 31: "ne fonctionne pas correctement",
    39: "pilote endommage ou absent", 43: "arrete par Windows apres une erreur",
}


def conseils_pilotes(etat, hw: HardwareInfo,
                     aujourdhui: _dt.date | None = None, maj=None, nvidia=None,
                     catalogue=None) -> list[Advice]:
    """Analyse de l'inventaire des pilotes (fonction pure si `maj`, `nvidia`
    et `catalogue` sont donnes : le resultat de la recherche Windows Update,
    les dernieres versions NVIDIA par serie, et le catalogue du constructeur
    du PC (Dell, Lenovo, HP) ; None quand rien n'est encore connu)."""
    aujourdhui = aujourdhui or _dt.date.today()
    if etat is None:
        return []
    if maj is None:
        from ..hardware import maj_pilotes as _wu
        maj = _wu.dernier()
    if nvidia is None:
        from ..hardware import pilotes_nvidia as _nv
        nvidia = _nv.connu()
    if catalogue is None:
        from ..hardware import catalogues as _cat
        catalogue = _cat.dernier()
        if catalogue is not None and (catalogue.source, catalogue.modele) != _cat.identite(etat):
            catalogue = None             # catalogue d'un autre PC (dossier de donnees copie)
    if etat.pilotes is None:
        return [Advice(
            "info", "Inventaire des pilotes indisponible",
            "Windows n'a pas repondu a la demande de liste des pilotes "
            "(service WMI occupe ou desactive). Cliquez sur Actualiser pour "
            "relancer l'analyse.", groupe="Pilotes",
            preuve="\n".join(etat.erreurs[:2]))]

    out: list[Advice] = []
    verifier_gpu = CONFIG.get("advisor.check_gpu_driver", True)
    gpu = hw.gpu

    # -- peripheriques en erreur ou sans pilote ---------------------------
    pannes = [x for x in etat.sans_pilote if int(x.get("code") or 0)]
    if pannes:
        lignes = [f"{x.get('nom') or 'Peripherique inconnu'}"
                  f"{' (' + str(x['classe']) + ')' if x.get('classe') else ''}"
                  f" · code {x.get('code')} : "
                  f"{_SANS_PILOTE_CODES.get(int(x.get('code') or 0), 'erreur')}"
                  for x in pannes[:8]]
        if len(pannes) > 8:
            lignes.append(f"... et {len(pannes) - 8} autres")
        out.append(Advice(
            "attention", "Peripheriques sans pilote ou en erreur",
            f"Le Gestionnaire de peripheriques signale {len(pannes)} "
            "peripherique(s) en erreur. Un controleur sans pilote peut priver "
            "le systeme d'une fonction (capteurs, gestion d'energie, USB...) "
            "et un code 43 sur une carte graphique la bride au minimum.",
            action="Ouvrir le Gestionnaire de peripheriques",
            action_url="devmgmt.msc", groupe="Pilotes",
            preuve="\n".join(lignes)))

    # -- carte graphique sur le pilote de base de Windows ------------------
    for p in etat.pilotes:
        if p.categorie == "graphique" and re.search(
                r"(basic display|carte graphique de base|affichage de base)",
                _sys.simple(p.nom)):
            out.append(Advice(
                "attention", "Carte graphique sans pilote",
                "Windows utilise son pilote d'affichage de base : pas "
                "d'acceleration 3D complete, frequence d'ecran et definition "
                "limitees. Installez le pilote du fabricant de la carte "
                "graphique.", action=BOUTONS.get(gpu.vendor, ""),
                action_url=LIENS.get(gpu.vendor, ""), groupe="Pilotes",
                preuve=_ligne(p)))

    # -- plus recent dans le catalogue du constructeur (Dell, Lenovo, HP) ----
    # Le catalogue du modele est la source que lisent Dell Command Update,
    # Lenovo System Update et HP Image Assistant : la version qu'il donne est
    # celle validee pour ce PC, avec la page et le fichier officiels.
    proposes: set[str] = set()
    if catalogue is not None and catalogue.offres:
        for p in etat.pilotes:
            if not p.cle_materiel or p.cle_materiel in proposes:
                continue
            if p.categorie == "graphique" and p.marque == "nvidia":
                continue                 # NVIDIA : la serie, par le service (plus a jour que l'OEM)
            o = catalogue.pour(p)
            if o is None:
                continue
            proposes.add(p.cle_materiel)
            quand = f" du {_date(_sys.lire_date(o.date))}" if o.date else ""
            out.append(Advice(
                "conseil", f"Pilote plus recent chez {catalogue.source} : "
                           f"{CATEGORIES.get(p.categorie, p.categorie).lower()}",
                f"{p.nom} : version {p.version or '?'} installee ({_date(p.date)}). "
                f"{catalogue.source} publie la {o.version}{quand} pour ce modele "
                f"(« {o.nom} ») : c'est la version validee par le constructeur pour "
                f"ce PC. {POURQUOI.get(p.categorie, '')}".strip(),
                action="Ouvrir la page du pilote" if o.details else "",
                action_url=o.details or o.fichier, groupe="Pilotes",
                preuve=_ligne(p) + f"\n{catalogue.source} : {o.nom} {o.version}"
                       f"{' (' + o.date + ')' if o.date else ''}"
                       f"{chr(10) + 'Fichier : ' + o.fichier if o.fichier else ''}"))

    # -- plus recent dans Windows Update (apparie par identifiant materiel) --
    # Le constructeur a publie chez Microsoft un pilote plus recent pour cette
    # puce precise : c'est le bon, valide pour ce PC. Avant tout jugement sur
    # l'age, et sans doublon avec « pilote ancien » pour la meme puce.
    if maj is not None and maj.pilotes:
        for p in etat.pilotes:
            m = maj.pour(p.cle_materiel)
            if m is None or p.cle_materiel in proposes:
                continue
            proposes.add(p.cle_materiel)
            version = m.version or "plus recente"
            out.append(Advice(
                "conseil", f"Pilote plus recent dans Windows Update : {CATEGORIES.get(p.categorie, p.categorie).lower()}",
                f"{p.nom} : version {p.version or '?'} installee ({_date(p.date)}). Windows Update "
                f"propose {m.fabricant or m.fournisseur or 'le fabricant'} {version}"
                f"{' du ' + _date(m.date) if m.date else ''}, en mise a jour facultative : "
                f"c'est la version publiee par le constructeur pour cette puce, validee pour "
                f"ce PC. {POURQUOI.get(p.categorie, '')}".strip(),
                action="Ouvrir Windows Update", action_url=_wu_adresse(), groupe="Pilotes",
                preuve=f"{_ligne(p)}\nWindows Update : {m.titre}"
                       + (f" · {m.taille / 1048576:.0f} Mo" if m.taille else "")))
        autres = [m for m in maj.pilotes
                  if m.cle_materiel not in proposes
                  and not any(m.cle_materiel and m.cle_materiel == p.cle_materiel for p in etat.pilotes)]
        if autres:
            out.append(Advice(
                "info", f"{len(autres)} autre(s) pilote(s) facultatif(s) dans Windows Update",
                "Windows Update propose aussi des pilotes pour des peripheriques qu'ORION "
                "n'analyse pas (capteurs, imprimantes, lecteurs de cartes...). Ils "
                "s'installent depuis la page des mises a jour facultatives.",
                action="Ouvrir Windows Update", action_url=_wu_adresse(), groupe="Pilotes",
                preuve="\n".join(m.titre for m in autres[:8])))

    # -- NVIDIA : la derniere version de la serie, relevee par le service ----
    nvidia_traite = False
    if verifier_gpu and gpu.vendor == "nvidia":
        nvidia_traite = _nvidia(out, etat, gpu, nvidia)

    # -- pilotes anciens, par categorie et par marque ----------------------
    groupes: dict[tuple[str, str], list[_sys.Pilote]] = {}
    for p in etat.pilotes:
        if p.cle_materiel and p.cle_materiel in proposes:
            continue                     # deja traite ci-dessus
        if nvidia_traite and p.categorie == "graphique" and p.marque == "nvidia":
            continue
        groupes.setdefault((p.categorie, p.marque), []).append(p)

    anciens: list[tuple[str, list]] = []
    for (cat, mrq), lot in groupes.items():
        if cat == "graphique" and not verifier_gpu:
            continue
        dates = [(p, _age_constate(p, aujourdhui)) for p in lot]
        dates = [(p, a) for p, a in dates if a is not None]
        if not dates:
            continue
        if cat == "chipset":
            # un paquet chipset installe ensemble : on juge sur le plus recent
            p, age = min(dates, key=lambda x: x[1])
            vieux = [(p, age)] if age > SEUIL_PILOTE else []
        else:
            seuil = SEUIL_GRAPHIQUE if cat == "graphique" else SEUIL_PILOTE
            vieux = [(p, a) for p, a in dates if a > seuil]
        if vieux:
            anciens.append((cat, vieux))
    par_categorie: dict[str, int] = {}
    for cat, _v in anciens:
        par_categorie[cat] = par_categorie.get(cat, 0) + 1
    for cat, vieux in anciens:
        p, age = max(vieux, key=lambda x: x[1])
        bouton, url, ou = _lien(p, etat)
        niveau = "attention" if (cat == "graphique"
                                 and age > SEUIL_GRAPHIQUE_FORT) else "conseil"
        version = p.version
        if (cat == "graphique" and gpu.vendor == "nvidia" and p.marque == "nvidia"
                and gpu.driver_version and gpu.driver_version != p.version):
            version = f"{p.version} (NVIDIA {gpu.driver_version})"
        sujet = (f"Paquet chipset {p.marque.upper()}" if cat == "chipset"
                 and p.marque else p.nom)
        detail = (f"{sujet} : version {version} du {_date(p.date)}, soit "
                  f"environ {_duree(age)}. {POURQUOI[cat]}")
        if cat != "graphique":
            if catalogue is not None and catalogue.offres and not catalogue.erreur:
                detail += (f" Le catalogue {catalogue.source} de ce modele n'en "
                           f"propose pas de plus recent (lu le {_date(catalogue.date)}).")
            elif maj is not None and not maj.erreur:
                detail += (f" Windows Update n'en propose pas de plus recent "
                           f"(verifie le {_date(maj.date)}) : la version a jour, "
                           f"si elle existe, est chez le fabricant.")
            else:
                detail += (" Un pilote ancien n'est pas forcement depasse : "
                           "l'outil du fabricant confirmera s'il existe plus "
                           "recent pour ce materiel.")
        if ou:
            detail += " " + ou
        lignes = [_ligne(x) for x, _ in sorted(vieux, key=lambda x: -x[1])][:6]
        titre = TITRES_ANCIEN[cat]
        if par_categorie.get(cat, 0) > 1:
            # deux cartes reseau de marques differentes : deux conseils, deux
            # titres (sinon masquer l'un masque l'autre)
            titre = f"{titre} : {_etiquette(p, etat)}"
        out.append(Advice(niveau, titre, detail, action=bouton,
                          action_url=url, groupe="Pilotes",
                          preuve="\n".join(lignes)))

    # -- pilotes generiques Microsoft la ou le fabricant en propose un -----
    for p in etat.pilotes:
        if not p.generique:
            continue
        n = _sys.simple(p.nom)
        if p.categorie == "reseau" and p.marque in (
                "realtek", "intel", "mediatek", "qualcomm", "broadcom", "marvell"):
            bouton, url, ou = _lien(p, etat)
            out.append(Advice(
                "conseil", "Carte reseau sous pilote generique Microsoft",
                f"{p.nom} fonctionne avec le pilote de Windows plutot qu'avec "
                f"celui de {p.marque.capitalize()}. Le pilote du fabricant "
                "regle mieux la gestion d'energie et la moderation des "
                f"interruptions, qui jouent sur la latence en ligne. {ou}".strip(),
                action=bouton, action_url=url, groupe="Pilotes",
                preuve=_ligne(p)))
        elif p.categorie == "audio" and _GENERIQUE_AUDIO.search(n):
            bouton, url, ou = _lien(p, etat)
            out.append(Advice(
                "conseil", "Puce audio sous pilote generique Microsoft",
                "La puce audio de la carte mere (Realtek le plus souvent) "
                "utilise le pilote « High Definition Audio » de Windows : pas "
                "de detection des prises en facade ni de reglages du "
                f"fabricant, latence moins bien maitrisee. {ou}".strip(),
                action=bouton, action_url=url, groupe="Pilotes",
                preuve=_ligne(p)))
        elif p.categorie == "bluetooth" and _GENERIQUE_BT.search(n):
            bouton, url, ou = _lien(p, etat)
            out.append(Advice(
                "conseil" if p.marque else "info",
                "Bluetooth sous pilote generique Microsoft",
                "L'adaptateur Bluetooth utilise le pilote generique de "
                "Windows. Le pilote du fabricant (Intel, Realtek, MediaTek...) "
                "corrige souvent coupures et latence des manettes et casques "
                f"sans fil. {ou}".strip(),
                action=bouton, action_url=url, groupe="Pilotes",
                preuve=_ligne(p)))

    # -- pilotes du chipset absents -----------------------------------------
    cpu = _marque_cpu(hw.cpu_name)
    systeme_lus = getattr(etat, "classes_brutes", {}).get("SYSTEM", 0)
    if cpu and systeme_lus >= 10:
        presents = [p for p in etat.pilotes if p.categorie == "chipset"
                    and p.marque == cpu and not p.generique]
        if not presents:
            lien = LIENS[cpu]
            out.append(Advice(
                "conseil", f"Pilotes du chipset {cpu.upper()} absents",
                f"Aucun pilote systeme publie par {cpu.upper()} n'a ete trouve "
                f"parmi {systeme_lus} peripheriques systeme. Sans eux, Windows "
                "gere moins finement l'energie et la repartition des coeurs "
                "du processeur.", action=BOUTONS[cpu], action_url=lien,
                groupe="Pilotes",
                preuve=f"Processeur : {hw.cpu_name}"))

    # -- recapitulatif : ce qui a ete lu ------------------------------------
    if etat.pilotes:
        out.append(_recapitulatif(etat.pilotes, out))
    return out


def _nvidia(out: list, etat, gpu: GPUInfo, dernieres: dict) -> bool:
    """Compare le pilote NVIDIA installe a la derniere version de sa serie.
    Rend vrai quand un verdict a ete donne (plus recent disponible, ou a jour)."""
    from ..hardware import pilotes_nvidia as _nv
    cle = _nv.serie(gpu.name, etat is not None and etat.boitier == "portable")
    installee = _nv.version_installee(gpu)
    derniere = (dernieres or {}).get(cle) if cle else None
    if not derniere or not installee:
        return False
    pilote = next((p for p in etat.pilotes if p.categorie == "graphique" and p.marque == "nvidia"), None)
    preuve = (_ligne(pilote) + "\n" if pilote else "") + \
             f"NVIDIA : {derniere.nom or 'pilote'} {derniere.version}" + \
             (f" du {derniere.date}" if derniere.date else "") + f" (serie {cle.rstrip('p')})"
    if _nv.plus_recente(installee, derniere.version):
        out.append(Advice(
            "conseil", f"Pilote graphique : {derniere.version} disponible",
            f"{gpu.name} : version {installee} installee. NVIDIA publie la {derniere.version}"
            f"{' depuis le ' + derniere.date if derniere.date else ''} pour cette serie de cartes"
            f"{' (' + derniere.nom + ')' if derniere.nom else ''}. {POURQUOI['graphique']}",
            action="Ouvrir la page du pilote", action_url=derniere.details or LIENS["nvidia"],
            groupe="Pilotes", preuve=preuve))
    else:
        out.append(Advice(
            "ok", f"Pilote graphique a jour ({installee})",
            f"{gpu.name} : la version installee est la derniere publiee par NVIDIA pour cette "
            f"serie de cartes{' (' + derniere.date + ')' if derniere.date else ''}.",
            groupe="Pilotes", preuve=preuve))
    return True


def _wu_adresse() -> str:
    from ..hardware import maj_pilotes as _wu
    return _wu.ADRESSE_WINDOWS_UPDATE


def _recapitulatif(pilotes: list[_sys.Pilote], deja: list[Advice]) -> Advice:
    lignes = []
    for cat, libelle in CATEGORIES.items():
        lot = [p for p in pilotes if p.categorie == cat]
        if not lot:
            continue
        if cat in ("chipset", "usb") and len(lot) > 2:
            par_fournisseur: dict[str, list[_sys.Pilote]] = {}
            for p in lot:
                par_fournisseur.setdefault(p.fournisseur or "?", []).append(p)
            for four, ps in par_fournisseur.items():
                recent = max(ps, key=lambda p: p.date or _dt.date.min)
                lignes.append(f"{libelle} · {len(ps)} pilote(s) {four} · plus "
                              f"recent : {recent.version} du {_date(recent.date)}")
        else:
            for p in lot:
                lignes.append(f"{libelle} · {_ligne(p)}")
    problemes = sum(1 for a in deja if a.level in ("attention", "conseil"))
    detail = ("Carte graphique, reseau, audio, chipset, stockage, USB et "
              "Bluetooth. Seuls les pilotes publies par un fabricant sont "
              "dates : ceux de Microsoft suivent Windows Update.")
    titre = (f"{len(pilotes)} pilotes analyses" if problemes else
             f"{len(pilotes)} pilotes analyses, rien a signaler")
    return Advice("ok", titre, detail, groupe="Pilotes",
                  preuve="\n".join(lignes))


@system_rule(groupe="Pilotes")
def _pilotes(hw: HardwareInfo) -> list[Advice]:
    etat = _etat(hw)
    if etat is None or etat.pilotes is None and not etat.erreurs:
        return []
    return conseils_pilotes(etat, hw)


@system_rule(groupe="Pilotes")
def _driver(hw: HardwareInfo) -> list[Advice]:
    """Pilote graphique lu dans le registre : seulement si l'inventaire complet
    des pilotes n'a pas pu etre fait."""
    etat = _etat(hw)
    if etat is not None and etat.pilotes is not None:
        return []
    if not CONFIG.get("advisor.check_gpu_driver", True):
        return []
    gpu = hw.gpu
    if not gpu.driver_version:
        return []
    age = _driver_age_days(gpu.driver_date)
    if age and age > SEUIL_GRAPHIQUE:
        return [Advice(
            "conseil", "Pilote graphique ancien",
            f"Version {gpu.driver_version}, installee il y a environ "
            f"{age // 30} mois. Les pilotes recents apportent souvent des gains "
            "notables sur les nouveaux jeux.",
            action="Ouvrir la page des pilotes",
            action_url=_driver_url(gpu.vendor),
            preuve=f"{gpu.name} · version {gpu.driver_version} · {gpu.driver_date}")]
    return [Advice("info", "Pilote graphique",
                   f"{gpu.name} - version {gpu.driver_version}"
                   + (f" ({gpu.driver_date})" if gpu.driver_date else ""),
                   action="Verifier les mises a jour",
                   action_url=_driver_url(gpu.vendor))]


def _driver_url(vendor: str) -> str:
    return LIENS.get(vendor, "") if vendor in ("nvidia", "amd", "intel") else ""


def _driver_age_days(date_str: str) -> int:
    m = re.match(r"(\d{1,2})-(\d{1,2})-(\d{4})", str(date_str or ""))
    if not m:
        return 0
    month, day, year = (int(x) for x in m.groups())
    try:
        stamp = time.mktime((year, month, day, 0, 0, 0, 0, 0, -1))
    except (ValueError, OverflowError):
        return 0
    return max(0, int((time.time() - stamp) / 86400))


# --------------------------------------------------------------------------
# Windows
# --------------------------------------------------------------------------

def _gere_hags(gpu: GPUInfo) -> bool:
    """La carte accepte la planification GPU acceleree par le materiel."""
    n = gpu.name or ""
    if gpu.vendor == "nvidia":
        m = re.search(r"(?:RTX|GTX)\s*(\d{3,4})", n, re.I)
        return bool(m) and int(m.group(1)) >= 1000
    if gpu.vendor == "amd":
        m = re.search(r"RX\s*(\d{4})", n, re.I)
        return bool(m) and int(m.group(1)) >= 5000
    if gpu.vendor == "intel":
        return bool(re.search(r"\barc\b", n, re.I))
    return False


def _x3d_double(cpu: str, coeurs: int) -> bool:
    """Ryzen X3D a deux blocs de coeurs (7900X3D, 7950X3D, 9900X3D, 9950X3D)."""
    s = (cpu or "").lower()
    return "x3d" in s and (coeurs >= 12 or bool(re.search(r"\b\d9[05]0x3d", s)))


def conseils_windows(etat, hw: HardwareInfo) -> list[Advice]:
    """Reglages de Windows qui pesent sur les jeux (fonction pure)."""
    if etat is None:
        return []
    out: list[Advice] = []

    if etat.mode_jeu == 0:
        out.append(Advice(
            "conseil", "Mode jeu de Windows desactive",
            "Le mode jeu donne la priorite au jeu au premier plan et suspend "
            "les installations de Windows Update pendant la partie.",
            action="Ouvrir les reglages du mode jeu",
            action_url="ms-settings:gaming-gamemode", groupe="Windows",
            preuve="Registre : HKCU\\Software\\Microsoft\\GameBar · "
                   "AutoGameModeEnabled = 0"))

    gpu = hw.gpu
    if etat.hags == 1 and _gere_hags(gpu):
        fg = "dlss_fg" in (gpu.features or [])
        out.append(Advice(
            "attention" if fg else "info",
            "Planification GPU acceleree desactivee",
            ("La generation d'images DLSS exige ce reglage : sans lui, "
             f"l'option reste grisee dans les jeux avec {gpu.name}. "
             if fg else
             "Ce reglage laisse la carte graphique gerer sa propre file de "
             "travail ; il reduit un peu la latence sur les cartes recentes. ")
            + "Il s'active dans Parametres > Affichage > Graphiques et "
              "demande un redemarrage.",
            action="Ouvrir les parametres graphiques",
            action_url="ms-settings:display-advancedgraphics", groupe="Windows",
            preuve="Registre : GraphicsDrivers · HwSchMode = 1 (desactive)"))

    if etat.capture_fond == 1:
        out.append(Advice(
            "conseil", "Enregistrement en arriere-plan actif",
            "La Xbox Game Bar enregistre en permanence les dernieres minutes "
            "de jeu : cela occupe l'encodeur video et coute quelques images "
            "par seconde. Desactivez-le si vous ne vous en servez pas.",
            action="Ouvrir les reglages de capture",
            action_url="ms-settings:gaming-gamedvr", groupe="Windows",
            preuve="Registre : GameDVR · HistoricalCaptureEnabled = 1"))

    out.extend(_conseils_alimentation(etat, hw))

    redem = etat.redemarrage or {}
    if redem.get("cbs") or redem.get("wu"):
        sources = [n for n, k in (("Windows Update", "wu"),
                                  ("maintenance des composants", "cbs"))
                   if redem.get(k)]
        out.append(Advice(
            "conseil", "Redemarrage en attente",
            "Des mises a jour (pilotes compris) sont installees mais ne "
            "s'appliqueront qu'au prochain redemarrage. Redemarrez avant une "
            "longue session : certains anti-triche refusent de se lancer "
            "dans cet etat.", groupe="Windows",
            preuve="Indicateur de redemarrage present : " + ", ".join(sources)))

    out.extend(_conseils_pagination(etat, hw))
    return out


def _conseils_alimentation(etat, hw: HardwareInfo) -> list[Advice]:
    plan = etat.plan_actif
    if not plan:
        return []
    nom = etat.plan_nom or plan
    preuve = f"Plan actif : {nom} ({plan})"
    if etat.surcouche:
        preuve += f"\nMode d'alimentation : {etat.surcouche}"
    cpu = hw.cpu_name or ""
    portable = etat.boitier == "portable"

    if _x3d_double(cpu, hw.cpu_cores) and plan in (_sys.PLAN_PERFORMANCES,
                                                    _sys.PLAN_ULTIME):
        return [Advice(
            "attention", "Plan d'alimentation inadapte au Ryzen X3D",
            f"{cpu} a deux blocs de coeurs : le pilote AMD n'envoie les jeux "
            "sur celui qui porte le cache 3D qu'avec le plan « Utilisation "
            "normale ». Avec un plan de performances, les jeux peuvent tourner "
            "sur le mauvais bloc. Repassez en Utilisation normale (Panneau de "
            "configuration > Options d'alimentation).", groupe="Windows",
            preuve=preuve)]
    if plan == _sys.PLAN_ECONOMIE:
        return [Advice(
            "conseil" if portable else "attention",
            "Plan Economie d'energie actif",
            "Ce plan bride la frequence du processeur et parfois celle du bus "
            "PCIe : les images par seconde chutent, surtout les minimales. "
            "Choisissez « Utilisation normale » ou mieux pour jouer.",
            action="Ouvrir les options d'alimentation",
            action_url="ms-settings:powersleep", groupe="Windows", preuve=preuve)]
    if etat.bureau and etat.surcouche == _sys.SURCOUCHE_ECONOMIE:
        return [Advice(
            "conseil", "Mode d'alimentation economique sur un PC de bureau",
            "Le mode « Efficacite energetique maximale » limite le processeur. "
            "Sur un PC de bureau, le mode « Performances optimales » "
            "(Parametres > Systeme > Alimentation) n'a pas d'inconvenient.",
            action="Ouvrir les options d'alimentation",
            action_url="ms-settings:powersleep", groupe="Windows", preuve=preuve)]
    if (etat.bureau and plan == _sys.PLAN_EQUILIBRE
            and _marque_cpu(cpu) == "intel"
            and etat.surcouche != _sys.SURCOUCHE_PERFORMANCES):
        return [Advice(
            "conseil", "Mode d'alimentation equilibre sur un PC de bureau",
            "Le mode equilibre laisse le processeur redescendre en frequence "
            "entre deux images, ce qui coute un peu de reactivite. Sur un PC "
            "de bureau, choisissez « Performances optimales » dans Parametres "
            "> Systeme > Alimentation.",
            action="Ouvrir les options d'alimentation",
            action_url="ms-settings:powersleep", groupe="Windows", preuve=preuve)]
    return []


def _conseils_pagination(etat, hw: HardwareInfo) -> list[Advice]:
    if etat.pagination_auto is not False or etat.pagination is None:
        return []
    if not etat.pagination and not etat.pagination_usage:
        return [Advice(
            "attention", "Fichier d'echange desactive",
            "Sans fichier d'echange, Windows ne peut pas reserver de memoire "
            "au-dela de la RAM : des jeux plantent (« memoire insuffisante ») "
            "meme avec beaucoup de memoire libre. Reactivez la gestion "
            "automatique (Parametres systeme avances > Performances > "
            "Memoire virtuelle).", action="Ouvrir les options de performances",
            action_url="SystemPropertiesPerformance.exe", groupe="Windows",
            preuve="Gestion automatique : non · aucun fichier d'echange "
                   "configure")]
    if any(int(x.get("maximum") or 0) == 0 for x in etat.pagination):
        return []                       # taille geree par le systeme
    total = sum(int(x.get("maximum") or 0) for x in etat.pagination)
    if total and total < 4096:
        return [Advice(
            "conseil", "Fichier d'echange tres petit",
            f"Taille maximale fixee a {total} Mo. Certains jeux reservent "
            "plusieurs gigaoctets au demarrage et plantent s'ils ne les "
            "obtiennent pas. Laissez Windows gerer la taille automatiquement.",
            action="Ouvrir les options de performances",
            action_url="SystemPropertiesPerformance.exe", groupe="Windows",
            preuve="\n".join(f"{x.get('nom')} : {x.get('initial')} a "
                             f"{x.get('maximum')} Mo" for x in etat.pagination))]
    return []


@system_rule(groupe="Windows")
def _windows(hw: HardwareInfo) -> list[Advice]:
    return conseils_windows(_etat(hw), hw)


# --------------------------------------------------------------------------
# Materiel lu par l'etat du systeme
# --------------------------------------------------------------------------

def conseils_materiel(etat, hw: HardwareInfo) -> list[Advice]:
    """Memoire et disque systeme (fonction pure)."""
    if etat is None:
        return []
    out: list[Advice] = []
    barrettes = [b for b in etat.barrettes if float(b.get("capacite") or 0) > 0]
    portable = etat.boitier == "portable"

    def desc(b: dict) -> str:
        go = round(float(b.get("capacite") or 0) / 1024 ** 3)
        ref = str(b.get("reference") or "").strip()
        return (f"{b.get('emplacement') or '?'} · {go} Go"
                + (f" · {ref}" if ref else "")
                + f" · annoncee {_vitesse_barrette(b) or '?'} · configuree "
                  f"{b.get('configuree') or '?'} MT/s")

    # -- vitesse de la memoire (XMP / EXPO) ---------------------------------
    configurees = [int(b.get("configuree") or 0) for b in barrettes]
    annoncees = [_vitesse_barrette(b) for b in barrettes]
    if barrettes and all(configurees) and all(annoncees) and not portable:
        conf, prevue = min(configurees), min(annoncees)
        if conf < prevue * 0.93:
            marque = _marque_cpu(hw.cpu_name)
            ddr5 = any(int(b.get("type") or 0) == 34 for b in barrettes)
            kit_amd = marque == "intel" and any(kit_optimise_amd(str(b.get("reference") or ""))
                                                for b in barrettes)
            profil = ("EXPO (ou DOCP/XMP selon la carte mere)"
                      if marque == "amd" else "XMP")
            if kit_amd and ddr5:
                # 10 octobre (PC de l'auteur) : un kit « optimise AMD » sur une
                # carte Intel. En DDR5, le profil EXPO n'est pas lu par une carte Intel.
                detail = (f"Les barrettes sont prevues pour {prevue} MT/s mais tournent a {conf} MT/s. "
                          "Ce sont des barrettes « optimisees AMD » (profil EXPO) : une carte mere Intel "
                          "ne lit pas ce profil, il n'y a donc pas de XMP a activer. Reglez la vitesse, "
                          "les timings et la tension a la main dans le BIOS (valeurs sur l'etiquette), "
                          "ou gardez la vitesse actuelle si le PC devient instable.")
            elif kit_amd:
                # en DDR4, un kit « optimise AMD » porte souvent un profil XMP
                # regle pour Ryzen : absent du BIOS ou instable sur certaines cartes Intel
                detail = (f"Les barrettes sont prevues pour {prevue} MT/s mais tournent a {conf} MT/s. "
                          "Ce sont des barrettes « optimisees AMD » : sur une carte mere Intel, leur profil "
                          "XMP peut manquer (rien a activer dans le BIOS) ou ne pas tenir. Si le BIOS "
                          "propose XMP (A-XMP chez MSI), essayez-le ; sinon reglez la vitesse, les timings "
                          "et la tension a la main (valeurs sur l'etiquette), ou gardez la vitesse "
                          "actuelle si le PC devient instable. La memoire plus rapide augmente surtout "
                          "les images par seconde minimales.")
            else:
                detail = (f"Les barrettes sont prevues pour {prevue} MT/s mais "
                          f"tournent a {conf} MT/s : le profil {profil} n'est pas "
                          "active dans le BIOS. La memoire plus rapide augmente "
                          "surtout les images par seconde minimales.")
                if marque == "intel":
                    detail += (" Si le BIOS ne propose aucun profil (barrettes « optimisees "
                               "AMD » par exemple), la vitesse se regle a la main.")
            if ddr5 and len(barrettes) >= 4:
                detail += (" Avec quatre barrettes DDR5, la vitesse maximale "
                           "est souvent inatteignable : visez un cran en "
                           "dessous.")
            out.append(Advice(
                "attention" if conf <= prevue * 0.8 else "conseil",
                f"Memoire a {conf} MT/s au lieu de {prevue}", detail,
                groupe="Materiel", preuve="\n".join(desc(b) for b in barrettes)))

    # -- canaux memoire ------------------------------------------------------
    if len(barrettes) == 1 and not portable:
        out.append(Advice(
            "attention" if etat.bureau else "conseil",
            "Memoire en simple canal",
            "Une seule barrette : le processeur n'a que la moitie de sa bande "
            "passante memoire. Dans les jeux limites par le processeur, une "
            "deuxieme barrette identique apporte souvent 10 a 30 % d'images "
            "par seconde en plus.", groupe="Materiel",
            preuve=desc(barrettes[0])))
    elif len(barrettes) >= 2 and not portable:
        canaux = [_sys.canal(str(b.get("emplacement") or ""),
                             str(b.get("banque") or "")) for b in barrettes]
        if all(canaux) and len(set(canaux)) == 1:
            out.append(Advice(
                "conseil", "Barrettes sur le meme canal",
                f"Les {len(barrettes)} barrettes sont toutes sur le canal "
                f"{canaux[0]} : la memoire fonctionne probablement en simple "
                "canal. Le manuel de la carte mere indique les emplacements a "
                "utiliser (souvent A2 et B2).", groupe="Materiel",
                preuve="\n".join(desc(b) for b in barrettes)))

    # -- Windows sur un disque dur -------------------------------------------
    if etat.type_disque("C") == "HDD":
        d = etat.lettres.get("C", {})
        out.append(Advice(
            "attention", "Windows est installe sur un disque dur",
            "Demarrage, chargements et mises a jour sont plusieurs fois plus "
            "lents que sur un SSD, et le fichier d'echange y est tres lent. "
            "Un SSD pour le systeme est l'amelioration la plus sensible.",
            groupe="Materiel",
            preuve=f"C: · {d.get('nom') or 'disque'} · type {d.get('type')}"))
    return out


#: references de kits « optimises AMD » : Corsair « ...GX4M2Z... » (Vengeance
#: pour Ryzen), G.Skill Flare X (« -GFX », « -FX5 »), Trident Z Neo / Z5 Neo
#: (« GTZN », « TZ5N »), Kingston FURY DDR5 EXPO (« KF5...E... »), Corsair DDR5
#: EXPO (« ...GX5M2...Z... »)
_KITS_AMD = re.compile(r"^(CM[A-Z]{1,3}\d+GX[45]M\d[A-Z]?\d*Z|F[45]-.*(GFX|FX5)\b|F4-.*GTZN|F5-.*TZ5N"
                       r"|KF5\d+.*E)", re.I)


def kit_optimise_amd(reference: str) -> bool:
    return bool(_KITS_AMD.match((reference or "").strip()))


def _vitesse_barrette(b: dict) -> int:
    return max(int(b.get("vitesse") or 0),
               _sys.vitesse_annoncee(str(b.get("reference") or "")))


# --------------------------------------------------------------------------
# Jeux (ensemble de la bibliotheque)
# --------------------------------------------------------------------------

def _lettre(chemin: str) -> str:
    ancre = str(Path(chemin).anchor or "") if chemin else ""
    m = re.match(r"([A-Za-z]):", ancre or chemin or "")
    return m.group(1).upper() if m else ""


#: le launcher sait deplacer un jeu en gardant son suivi (mises a jour,
#: succes) ; ORION, lui, ne fait que des sauvegardes sur un autre disque
DEPLACER_LAUNCHER = (
    "Pour le passer sur un SSD sans le reinstaller, utilisez la fonction du "
    "launcher : Steam > clic droit sur le jeu > Proprietes > Fichiers "
    "installes > Deplacer le dossier d'installation (Epic, EA app et "
    "Ubisoft Connect ont un equivalent).")


def conseils_jeux(jeux: Iterable[Game], etat, hw: HardwareInfo) -> list[Advice]:
    """Conseils sur l'ensemble des jeux installes (fonction pure)."""
    installes = [g for g in jeux or [] if g.install_dir and not g.hidden]
    out: list[Advice] = []

    if etat is not None and etat.lettres:
        sur_hdd = [g for g in installes
                   if etat.type_disque(_lettre(g.install_dir)) == "HDD"]
        if sur_hdd:
            sur_hdd.sort(key=lambda g: -(g.size_bytes or 0))
            ssd = [f"{d.get('mount')} ({d.get('free_gb')} Go libres)"
                   for d in hw.disks
                   if etat.type_disque(_lettre(str(d.get("mount") or ""))) == "SSD"]
            detail = ("Sur un disque dur, les chargements sont plus longs et "
                      "les mondes ouverts saccadent quand le jeu charge des "
                      "donnees en cours de partie ; plusieurs jeux recents "
                      "exigent un SSD. ")
            detail += (DEPLACER_LAUNCHER + " SSD disponibles : "
                       + ", ".join(ssd) + "." if ssd else
                       "Aucun SSD n'a ete detecte : c'est l'achat le plus "
                       "utile pour ces jeux.")
            lignes = []
            for g in sur_hdd[:6]:
                lettre = _lettre(g.install_dir)
                nom = etat.lettres.get(lettre, {}).get("nom") or "disque dur"
                taille = (f" · {g.size_bytes / 1024 ** 3:.0f} Go"
                          if g.size_bytes else "")
                lignes.append(f"{g.title} · {lettre}: ({nom}){taille}")
            if len(sur_hdd) > 6:
                lignes.append(f"... et {len(sur_hdd) - 6} autres")
            titre = ("Un jeu installe sur un disque dur" if len(sur_hdd) == 1
                     else f"{len(sur_hdd)} jeux installes sur un disque dur")
            out.append(Advice("conseil", titre, detail, groupe="Jeux",
                              preuve="\n".join(lignes)))

    if CONFIG.get("advisor.check_game_updates", True):
        en_attente = [g for g in installes if g.update_pending]
        if en_attente:
            titre = ("Un jeu attend une mise a jour" if len(en_attente) == 1
                     else f"{len(en_attente)} jeux attendent une mise a jour")
            out.append(Advice(
                "conseil", titre,
                "La plateforme signale une mise a jour non installee : "
                "lancez-la avant de jouer pour eviter une deconnexion en "
                "ligne ou un long telechargement au moment de jouer.",
                groupe="Jeux",
                preuve="\n".join(g.title for g in en_attente[:8])
                + (f"\n... et {len(en_attente) - 8} autres"
                   if len(en_attente) > 8 else "")))
    return out


@games_rule
def _jeux(jeux: list[Game], hw: HardwareInfo) -> list[Advice]:
    return conseils_jeux(jeux, _etat(hw), hw)


# --------------------------------------------------------------------------
# Regles par jeu
# --------------------------------------------------------------------------

@game_rule
def _pending_update(game: Game, hw: HardwareInfo, disp: Display | None) -> list[Advice]:
    if game.update_pending:
        return [Advice("attention", "Mise a jour en attente",
                       "Steam signale une mise a jour non installee : lancez-la "
                       "avant de jouer pour eviter une deconnexion en ligne.")]
    return []


@game_rule
def _install_disk(game: Game, hw: HardwareInfo, disp: Display | None) -> list[Advice]:
    if not game.install_dir:
        return []
    drive = str(Path(game.install_dir).anchor).rstrip("\\/")
    for d in hw.disks:
        if d.get("mount", "").rstrip("\\/").lower() == drive.lower():
            if d.get("free_gb", 99) < 15:
                return [Advice(
                    "attention", "Peu d'espace sur le disque du jeu",
                    f"{d['free_gb']} Go libres sur {drive} : les mises a jour et "
                    "le cache de shaders risquent d'echouer.")]
    return []


@game_rule
def _install_hdd(game: Game, hw: HardwareInfo, disp: Display | None) -> list[Advice]:
    etat = _etat(hw)
    lettre = _lettre(game.install_dir)
    if etat is None or not lettre or etat.type_disque(lettre) != "HDD":
        return []
    nom = etat.lettres.get(lettre, {}).get("nom") or "disque dur"
    return [Advice(
        "conseil", "Jeu installe sur un disque dur",
        f"{lettre}: est un disque dur ({nom}) : chargements plus longs et "
        "saccades possibles quand le jeu charge des donnees en cours de "
        "partie. " + DEPLACER_LAUNCHER)]


@game_rule
def _engine_hint(game: Game, hw: HardwareInfo, disp: Display | None) -> list[Advice]:
    hints = {
        "unreal": "Moteur Unreal : la premiere partie compile les shaders, "
                  "quelques saccades initiales sont normales.",
        "unity": "Moteur Unity : les options sont souvent limitees dans le menu, "
                 "ORION ecrit directement dans le registre du jeu.",
        "source": "Moteur Source : les options de console (fps_max, mat_queue_mode) "
                  "pesent plus que le menu graphique.",
    }
    if game.engine in hints:
        return [Advice("info", "Moteur detecte : " + game.engine.capitalize(),
                       hints[game.engine])]
    return []


@game_rule
def _upscaling_hint(game: Game, hw: HardwareInfo, disp: Display | None) -> list[Advice]:
    feats = hw.gpu.features
    if "dlss" in feats and "dlss_fg" not in feats:
        return [Advice(
            "info", "Generation d'images non disponible",
            "Cette carte gere DLSS en super-resolution mais pas la generation "
            "d'images materielle (reservee aux RTX 40 et 50). Si le jeu propose "
            "FSR 3 Frame Generation, il fonctionne aussi sur cette carte.")]
    return []


# --------------------------------------------------------------------------

def for_system(hw: HardwareInfo, games: Iterable[Game] | None = None) -> list[Advice]:
    """Conseils de la page Conseils. `games` (facultatif) active le groupe Jeux."""
    out: list[Advice] = []
    for rule in SYSTEM_RULES:
        try:
            lot = rule(hw) or []
        except Exception:
            log.exception("Regle de conseil en echec : %s", rule.__name__)
            continue
        for a in lot:
            a.groupe = a.groupe or _GROUPE_REGLE.get(rule.__name__, "Materiel")
        out.extend(lot)
    if games is not None:
        jeux = list(games)
        for rule in GAMES_RULES:
            try:
                lot = rule(jeux, hw) or []
            except Exception:
                log.exception("Regle de conseil en echec : %s", rule.__name__)
                continue
            for a in lot:
                a.groupe = a.groupe or "Jeux"
            out.extend(lot)
    out.sort(key=lambda a: a.rank)
    return out


def for_game(game: Game, hw: HardwareInfo, display: Display | None) -> list[Advice]:
    out: list[Advice] = []
    for rule in GAME_RULES:
        try:
            out.extend(rule(game, hw, display) or [])
        except Exception:
            log.exception("Regle de conseil en echec : %s", rule.__name__)
    out.sort(key=lambda a: a.rank)
    return out
