"""Affichage d'un conseil : gravite, constat, valeurs lues et action."""
from __future__ import annotations

import webbrowser

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (QFrame, QHBoxLayout, QLabel, QPushButton,
                               QSizePolicy, QVBoxLayout)

from ...core.logging_setup import get
from ...optimizer.advisor import Advice
from ..theme import PALETTE

log = get("ui.conseil")

#: libelle et couleur de la pastille de gravite
NIVEAUX = {
    "attention": ("A corriger", PALETTE["warn"]),
    "conseil": ("Conseil", PALETTE["accent"]),
    "info": ("Info", PALETTE["text_dim"]),
    "ok": ("Verifie", PALETTE["ok"]),
}

#: au-dela, les valeurs lues sont repliees derriere un bouton
LIGNES_VISIBLES = 3

_STYLE = f"""
QFrame#Advice[level="ok"] {{ border-left: 3px solid {PALETTE['ok']}; }}
QLabel#AdviceNiveau {{
    font-size: 10px; font-weight: 700; letter-spacing: 1px;
    border-radius: 4px; padding: 2px 7px; background: transparent;
}}
QLabel#AdvicePreuve {{
    color: {PALETTE['text_faint']}; font-size: 11px;
    background: {PALETTE['bg_alt']}; border: 1px solid {PALETTE['border']};
    border-radius: 6px; padding: 6px 9px;
}}
QPushButton#AdviceDeplier {{
    background: transparent; border: none; color: {PALETTE['text_faint']};
    font-size: 11px; padding: 0; text-align: left;
}}
QPushButton#AdviceDeplier:hover {{ color: {PALETTE['text']}; }}
"""


def ouvrir(adresse: str) -> None:
    """Page web dans le navigateur ; ms-settings:, devmgmt.msc... via le shell."""
    try:
        if adresse.startswith(("http://", "https://")):
            webbrowser.open(adresse)
        else:
            from ...core.lancement import startfile_propre
            startfile_propre(adresse)
    except Exception:
        log.warning("Impossible d'ouvrir %s", adresse)


def cle(advice: Advice) -> str:
    """Identite d'un conseil, pour s'en souvenir d'une analyse a l'autre : sa
    rubrique et son titre, chiffres retires (« 2 jeux installes sur un disque
    dur » et « 3 jeux... » sont le meme conseil ; « Disque C: » et « Disque
    D: » en sont deux)."""
    import re
    return f"{advice.groupe}|{re.sub(r'[0-9]+', '#', advice.title).strip().lower()}"


def texte_brut(advice: Advice) -> str:
    """Le conseil en texte simple (rapport a copier)."""
    from ...i18n import t
    etat = t(NIVEAUX.get(advice.level, NIVEAUX["info"])[0])
    lignes = [f"[{etat}] {t(advice.title)}", t(advice.detail)]
    lignes += ["    " + x for x in (advice.preuve or "").splitlines() if x.strip()]
    return "\n".join(x for x in lignes if x)


class AdviceCard(QFrame):
    #: « ne plus afficher ce conseil » (cle du conseil)
    masquer = Signal(str)

    def __init__(self, advice: Advice, parent=None, masquable: bool = False) -> None:
        super().__init__(parent)
        self.advice = advice
        self.setObjectName("Advice")
        self.setProperty("level", advice.level)
        self.setStyleSheet(_STYLE)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(15, 12, 15, 12)
        lay.setSpacing(5)

        head = QHBoxLayout()
        head.setSpacing(10)
        texte, couleur = NIVEAUX.get(advice.level, NIVEAUX["info"])
        niveau = QLabel(texte.upper())
        niveau.setObjectName("AdviceNiveau")
        niveau.setStyleSheet(f"color: {couleur}; border: 1px solid {couleur};")
        niveau.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        head.addWidget(niveau, 0, Qt.AlignmentFlag.AlignTop)

        title = QLabel(advice.title)
        title.setObjectName("Value")
        title.setWordWrap(True)
        head.addWidget(title, 1)

        if advice.action and advice.action_url:
            btn = QPushButton(advice.action)
            btn.setObjectName("Ghost")
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.setToolTip(advice.action_url)
            btn.clicked.connect(lambda: ouvrir(advice.action_url))
            head.addWidget(btn, 0, Qt.AlignmentFlag.AlignTop)
        if masquable and advice.level in ("attention", "conseil", "info"):
            # un conseil qu'on ne veut ou ne peut pas suivre ne doit pas
            # rester en alerte a chaque visite
            self.b_masquer = QPushButton("Masquer")
            self.b_masquer.setObjectName("AdviceDeplier")
            self.b_masquer.setCursor(Qt.CursorShape.PointingHandCursor)
            self.b_masquer.setToolTip(
                "Ne plus afficher ce conseil. Il reste retrouvable en bas de la "
                "page (« conseils masques »).")
            self.b_masquer.clicked.connect(lambda: self.masquer.emit(cle(advice)))
            head.addWidget(self.b_masquer, 0, Qt.AlignmentFlag.AlignTop)
        lay.addLayout(head)

        detail = QLabel(advice.detail)
        detail.setObjectName("Dim")
        detail.setWordWrap(True)
        lay.addWidget(detail)

        self.preuve: QLabel | None = None
        lignes = [x for x in (advice.preuve or "").splitlines() if x.strip()]
        if lignes:
            self._lignes = lignes
            self.preuve = QLabel()
            self.preuve.setObjectName("AdvicePreuve")
            self.preuve.setWordWrap(True)
            self.preuve.setTextInteractionFlags(
                Qt.TextInteractionFlag.TextSelectableByMouse)
            lay.addWidget(self.preuve)
            self.deplier: QPushButton | None = None
            if len(lignes) > LIGNES_VISIBLES + 1:
                self.deplier = QPushButton()
                self.deplier.setObjectName("AdviceDeplier")
                self.deplier.setCursor(Qt.CursorShape.PointingHandCursor)
                self.deplier.clicked.connect(self._basculer)
                lay.addWidget(self.deplier, 0, Qt.AlignmentFlag.AlignLeft)
            self._ouvert = False
            self._afficher()

    def _afficher(self) -> None:
        lignes = self._lignes
        if self.deplier is not None and not self._ouvert:
            lignes = lignes[:LIGNES_VISIBLES]
        self.preuve.setText("\n".join(lignes))
        if self.deplier is not None:
            self.deplier.setText(
                "Masquer le detail" if self._ouvert
                else f"Afficher les {len(self._lignes)} lignes")

    def _basculer(self) -> None:
        self._ouvert = not self._ouvert
        self._afficher()
