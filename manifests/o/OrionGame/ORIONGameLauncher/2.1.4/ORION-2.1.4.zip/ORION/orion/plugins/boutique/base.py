"""Contrat des sources de la Boutique ultime.

Une source fournit deux choses :

* `vitrine()` : ce qu'elle met en avant maintenant (promotions, gratuits,
  meilleures ventes). Appelee a chaque actualisation, toutes les 10-15 min.
* `chercher(terme)` : tous les jeux qui correspondent a une recherche,
  meme hors promotion. C'est ce qui rend la boutique exhaustive.

Chaque resultat est une `Offre` : un jeu, une boutique, un prix. La fusion
des offres d'un meme jeu en une `Fiche` est faite par le service.
"""
from __future__ import annotations

import re
import time
from dataclasses import asdict, dataclass, field

from ...core.logging_setup import get
from ..freebies.base import SourceUnavailable, fetch_json  # noqa: F401  (reexportes)
from .confiance import niveau

log = get("boutique")



@dataclass
class Offre:
    """Un jeu en vente sur une boutique, a un prix donne."""
    titre: str
    boutique: str
    prix: float                      # 0 = gratuit
    prix_normal: float = 0.0
    remise: int = 0                  # pourcentage
    devise: str = "EUR"
    url: str = ""
    source: str = ""                 # fournisseur qui a releve l'offre
    steam_appid: str = ""
    itad_id: str = ""
    image: str = ""                  # vignette distante (paysage)
    genres: list[str] = field(default_factory=list)
    sortie: str = ""
    note: int = 0                    # pourcentage d'avis positifs
    fin_promo: float = 0.0           # horodatage, 0 = inconnu
    plus_bas_historique: float = 0.0
    drm: str = ""
    #: nature de l'article selon la source quand elle la donne : « game »,
    #: « dlc », « package », « app »... (vide = inconnue)
    type_article: str = ""
    #: mise en avant par la boutique (meilleures ventes, a la une...) :
    #: 0 = inconnue, 100 = en tete des ventes
    populaire: int = 0
    #: jeu reserve aux adultes d'apres la source (voir `contenu_adulte`) :
    #: la Boutique ecarte alors le jeu entier, toutes boutiques confondues
    adulte: bool = False
    releve_le: float = field(default_factory=time.time)

    @property
    def gratuit(self) -> bool:
        return self.prix <= 0.0

    @property
    def confiance(self):
        return niveau(self.boutique, self.source)

    @property
    def sure(self) -> bool:
        return self.confiance.sur

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Offre":
        champs = cls.__dataclass_fields__
        return cls(**{k: v for k, v in d.items() if k in champs})


class SourceBoutique:
    """Une source de prix. Voir le docstring du module."""
    abstract = True
    id: str = ""
    label: str = ""
    priority: int = 50
    needs_key: bool = False
    #: OBLIGATOIRE : comment cette source signale les jeux reserves aux
    #: adultes (en une phrase). Une source sans cette declaration fait
    #: echouer les tests : on ne branche pas une boutique sans y avoir pense.
    filtre_adulte: str = ""

    @staticmethod
    def adulte(brut: dict) -> bool:
        """A appeler sur chaque produit brut : `Offre(..., adulte=self.adulte(p))`.
        Reconnait les drapeaux et etiquettes de n'importe quelle boutique."""
        from ...contenu_adulte import produit_adulte
        return produit_adulte(brut)

    def available(self) -> bool:
        return True

    def vitrine(self) -> list[Offre]:
        return []

    def chercher(self, terme: str) -> list[Offre]:
        return []


_PRIX = re.compile(r"(\d+(?:[.,\s]\d{3})*(?:[.,]\d{1,2})?)")


def lire_prix(texte) -> float:
    """« 1,55 € », « 19.99 », « Gratuit » -> 1.55, 19.99, 0.0."""
    if texte is None:
        return 0.0
    if isinstance(texte, (int, float)):
        return float(texte)
    s = str(texte).strip().lower()
    if not s or "grat" in s or "free" in s:
        return 0.0
    m = _PRIX.search(s.replace(" ", " "))
    if not m:
        return 0.0
    brut = m.group(1).replace(" ", "")
    if "," in brut and "." in brut:
        brut = brut.replace(".", "").replace(",", ".") \
            if brut.rfind(",") > brut.rfind(".") else brut.replace(",", "")
    else:
        brut = brut.replace(",", ".")
    try:
        return round(float(brut), 2)
    except ValueError:
        return 0.0
