"""Profil « Recommande » : la plus belle image qui reste fluide.

Inspire de ce que fait NVIDIA App (le curseur « Performances <-> Qualite »
avec un point « optimal » calcule pour votre machine), en plus simple et
sans base de donnees en ligne :

1. **Objectif d'images par seconde** : la frequence de l'ecran, pour tous
   les jeux (144 i/s sur un ecran 144 Hz), jamais plus que ce que l'ecran
   affiche. Si le materiel ne suit pas, l'objectif descend par paliers
   (120, 90, 60...) jusqu'au plus haut que ce PC tient, et la limite
   d'images est posee sur ce palier pour garder un rythme regulier.
   Reglable (`optimizer.recommande_fps`).
2. **Images par seconde attendues a chaque niveau** (Basse, Moyenne,
   Haute, Ultra) : mesure reelle sur CE PC d'abord, puis mesures de la
   communaute, puis estimation depuis la configuration du jeu (le meme
   calcul que la page « Ma machine », donc les deux disent la meme chose).
3. **Choix** : le niveau le plus beau qui atteint l'objectif. Quand la
   recette du jeu sait regler la super-resolution (DLSS, FSR, XeSS ou
   l'echelle de rendu d'Unreal), ORION peut monter d'un niveau en
   l'activant en mode Qualite plutot que de baisser les details.
4. **Prudence** : une estimation n'autorise jamais « Ultra » (seule une
   mesure le peut) et retient le bas de sa fourchette. Apres chaque partie
   mesuree, le calcul repart de la mesure : le profil se corrige seul.

Le joueur peut deplacer le curseur pour CE jeu (`choisir_niveau`) ; le
point recommande reste affiche pour revenir en un clic.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..core.logging_setup import get
from ..core.models import Display, Game, HardwareInfo, normalize_title

log = get("optimizer.recommande")

#: du plus fluide au plus beau
NIVEAUX = ("basse", "moyenne", "haute", "ultra")
NOMS_NIVEAUX = {"basse": "Basse", "moyenne": "Moyenne", "haute": "Haute",
                "ultra": "Ultra"}
#: niveau -> echelle de qualite des profils (0 = bas ... 3 = maximum)
QUALITE = {"basse": 0, "moyenne": 1, "haute": 2, "ultra": 3}
NIVEAU_DE_QUALITE = {v: k for k, v in QUALITE.items()}
#: couleurs des pastilles de niveau (communes au curseur et a « Ma machine »)
COULEURS_NIVEAUX = {"ultra": "#B98CFF", "haute": "#3DDC97", "moyenne": "#38E1FF",
                    "basse": "#FFB454", "insuffisant": "#FF5A5F"}

#: images/s relatives au niveau « haute » (memes conventions que
#: puissance.estimation : moyenne x1.3, basse x1.75 ; ultra ~ -23 %)
COUT = {"basse": 1.75, "moyenne": 1.3, "haute": 1.0, "ultra": 0.77}

#: super-resolution : gain d'images/s, perte de finesse, echelle de rendu (%)
MODES = {
    "off": (1.0, 0.0, 100),
    "quality": (1.35, 0.3, 67),
    "balanced": (1.5, 0.7, 58),
    "performance": (1.7, 1.3, 50),
}
NOMS_MODES = {"off": "", "quality": "Qualite", "balanced": "Equilibre",
              "performance": "Performance"}
NOMS_FAMILLES = {"dlss": "DLSS", "fsr": "FSR", "xess": "XeSS",
                 "echelle": "Rendu"}
#: au-dela, la definition est du « 4K » (3840x2160 = 8,3 Mpx ; le 1440p,
#: 3,7 Mpx, etait compte comme de la 4K par erreur)
PIXELS_4K = 6_000_000
#: une super-resolution moins fine coute plus cher en image
PENALITE_FAMILLE = {"dlss": 1.0, "xess": 1.3, "fsr": 1.6, "echelle": 1.8}

#: jeux competitifs : l'objectif devient la frequence de l'ecran
ESPORT_APPIDS = {"730", "570", "440", "1172470", "252950", "578080", "2357570",
                 "359550", "1938090", "2073850", "2767030", "1422450", "2507950",
                 "1599340", "291550", "444090"}
ESPORT_TITRES = ("counterstrike", "valorant", "leagueoflegends", "dota2",
                 "overwatch", "apexlegends", "fortnite", "rainbowsix",
                 "rocketleague", "pubg", "battlegrounds", "callofduty", "warzone",
                 "thefinals", "marvelrivals", "deadlock", "teamfortress",
                 "splitgate", "xdefiant", "quakechampions", "paladins", "smite",
                 "deltaforce", "brawlhalla", "starcraft", "halo infinite")

#: (uid -> capacites de la recette retenue au dernier plan) : permet a
#: `compute_settings` appele sans recette de dire la meme chose que le plan
_CAPACITES: dict[str, list[str]] = {}


# --------------------------------------------------------------------------
@dataclass
class Option:
    """Un point du curseur : niveau + super-resolution + images/s attendues."""
    niveau: str
    mode: str = "off"
    fps: tuple[int, int] | None = None     # (prudent, haut)
    atteint: bool = False

    @property
    def echelle(self) -> int:
        return MODES[self.mode][2]


@dataclass
class Recommandation:
    niveau: str = "haute"                 # niveau applique
    niveau_conseille: str = "haute"       # point « Recommande » : le plus d'images
    #: l'autre proposition : la plus belle image qui reste fluide (60 i/s).
    #: Egal a `niveau_conseille` quand le PC tient l'ecran sans rien sacrifier.
    niveau_beau: str = ""
    force: bool = False                   # le joueur a deplace le curseur
    mode: str = "off"                     # off | quality | balanced | performance
    famille: str = ""                     # dlss | fsr | xess | echelle | ""
    cible: int = 60                       # frequence de l'ecran visee
    palier: int = 0                       # objectif tenu (= cible si atteinte)
    esport: bool = False
    fps: tuple[int, int] | None = None
    atteint: bool = True
    source: str = "inconnu"               # mesure | communaute | estime | inconnu
    raison: str = ""
    options: dict[str, Option] = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)
    gpu: str = ""                         # « RTX 3070 »
    definition: str = ""                  # « 1440p »
    #: niveaux reellement mesures (les autres sont deduits de ces mesures)
    niveaux_mesures: tuple[str, ...] = ()

    @property
    def upscaler(self) -> str:
        """Valeur du reglage abstrait « upscaler » (ex. « dlss_quality »)."""
        if self.mode == "off" or self.famille in ("", "echelle"):
            return "off"
        return f"{self.famille}_{self.mode}"

    @property
    def echelle(self) -> int:
        return MODES[self.mode][2] if self.mode != "off" else 100

    @property
    def nom_niveau(self) -> str:
        return NOMS_NIVEAUX.get(self.niveau, self.niveau)

    @property
    def texte_mode(self) -> str:
        """« DLSS Qualite », « Rendu 67 % », ou "" sans super-resolution."""
        if self.mode == "off" or not self.famille:
            return ""
        if self.famille == "echelle":
            return f"Rendu {self.echelle} %"
        return f"{NOMS_FAMILLES.get(self.famille, self.famille)} {NOMS_MODES[self.mode]}"

    @property
    def phrase(self) -> str:
        """Le choix en une phrase, comme NVIDIA App :
        « Haute + DLSS Qualite : ~72 i/s attendues sur votre RTX 3070 en 1440p »."""
        reglage = self.nom_niveau + (f" + {self.texte_mode}" if self.texte_mode else "")
        ou = ""
        if self.gpu:
            ou = f" sur votre {self.gpu}"
        if self.definition:
            ou += f" en {self.definition}"
        if not self.fps:
            return (f"{reglage} : choisi d'apres la gamme de votre carte graphique"
                    + (f" ({self.gpu})" if self.gpu else "")
                    + ", images/s non verifiees")
        if self.source == "mesure" and self.niveau in self.niveaux_mesures \
                and self.mode == "off":
            texte = f"{reglage} : ~{self.fps[1]} i/s mesurees{ou}"
        elif self.source == "mesure":
            texte = f"{reglage} : ~{self.fps[1]} i/s attendues{ou}, d'apres vos mesures"
        else:
            # milieu de la fourchette : la prudence est dans le choix du
            # niveau (le bas de la fourchette doit tenir l'objectif)
            texte = f"{reglage} : ~{(self.fps[0] + self.fps[1]) // 2} i/s attendues{ou}"
        if not self.atteint:
            texte += f" (objectif {self.cible} i/s hors de portee)"
        return texte

    @property
    def texte_fps(self) -> str:
        """« environ 72 a 99 i/s (objectif 60) »."""
        return texte_fps(self.fps, self.cible, self.source)

    @property
    def resume(self) -> str:
        """« Haute · DLSS Qualite · environ 72 a 99 i/s (objectif 60) »."""
        morceaux = [self.nom_niveau]
        if self.texte_mode:
            morceaux.append(self.texte_mode)
        morceaux.append(self.texte_fps)
        return " · ".join(morceaux)

    @property
    def sous_titre(self) -> str:
        """« Le plus beau reglage qui tient 60 i/s sur votre RTX 3070 en 1440p »."""
        ou = (f" sur votre {self.gpu}" if self.gpu else " sur votre PC") + (
            f" en {self.definition}" if self.definition else "")
        if self.force:
            return (f"Niveau choisi pour ce jeu{ou} ; conseille : "
                    f"{NOMS_NIVEAUX.get(self.niveau_conseille, '?')}")
        if not self.fps:
            return f"Choisi d'apres la gamme de votre carte graphique{ou}"
        if not self.atteint and self.palier:
            return (f"Votre ecran affiche {self.cible} i/s ; ce PC en tient "
                    f"{self.palier} sur ce jeu{ou}")
        if not self.atteint:
            return f"Le reglage le plus fluide possible{ou}, sous l'objectif de {self.cible} i/s"
        return (f"Le plus beau reglage qui tient la frequence de votre ecran "
                f"({self.cible} i/s){ou}")

    @property
    def origine(self) -> str:
        """D'ou viennent les images/s, en une phrase courte."""
        texte = {
            "mesure": "D'apres vos parties mesurees par ORION.",
            "communaute": "D'apres les mesures de joueurs ORION equipes comme vous.",
            "estime": ("Estimation prudente d'apres la configuration recommandee du "
                       "jeu ; elle se corrige apres une partie mesuree."),
        }.get(self.source, "Configuration du jeu inconnue : images/s non verifiees.")
        if self.source == "estime" and self.niveau_conseille == "haute":
            texte += " Ultra n'est propose qu'apres une mesure reelle."
        return texte

    def to_dict(self) -> dict[str, Any]:
        return {"niveau": self.niveau, "conseille": self.niveau_conseille, "beau": self.niveau_beau,
                "force": self.force, "mode": self.mode, "famille": self.famille,
                "cible": self.cible, "palier": self.palier, "fps": list(self.fps) if self.fps else None,
                "atteint": self.atteint, "source": self.source,
                "resume": self.resume, "phrase": self.phrase,
                "raison": self.raison}


def gpu_court(nom: str) -> str:
    """« NVIDIA GeForce RTX 3070 Laptop GPU » -> « RTX 3070 Laptop »."""
    import re
    n = re.sub(r"\((?:R|TM)\)|™|®", "", nom or "")
    n = re.sub(r"^\s*(NVIDIA|AMD|ATI|Intel)\s+", "", n, flags=re.I)
    n = re.sub(r"^\s*(GeForce|Radeon(?=\s+(RX|R\d|HD|VII|Pro))|Graphics)\s+", "", n,
               flags=re.I)
    n = re.sub(r"\s+(GPU|Graphics)\s*$", "", n, flags=re.I)
    return " ".join(n.split())[:28]


def nom_definition(largeur: int, hauteur: int) -> str:
    """« 1440p », « 4K », « 1080p », sinon « 3440x1440 »."""
    if not largeur or not hauteur:
        return ""
    if largeur / max(hauteur, 1) > 2.0:
        return f"{largeur}x{hauteur}"           # ultra-large : on dit tout
    if hauteur >= 2100:
        return "4K"
    if hauteur in (1440, 1600, 1200, 1080, 900, 720) or hauteur in (1050, 768):
        return f"{hauteur}p"
    return f"{largeur}x{hauteur}"


#: au-dela, le chiffre n'a plus de sens pour le joueur (« 1035 a 1423 i/s »).
#: Une seule mise en forme pour toute l'application : fiche d'un jeu, guide
#: des reglages, page « Ma machine ».
PLAFOND_FPS = 300


def plage_fps(fps: tuple[int, int]) -> str:
    """« 72 a 99 », « 144 », « plus de 300 »."""
    bas, haut = int(fps[0]), int(fps[1])
    if bas >= PLAFOND_FPS:
        return f"plus de {PLAFOND_FPS}"
    if haut >= PLAFOND_FPS:
        return f"plus de {bas}"
    return f"{bas} a {haut}" if haut > bas else f"{bas}"


def valeur_fps(fps: tuple[int, int], source: str = "") -> int:
    """Le chiffre unique montre au joueur : la mesure, sinon le milieu de
    la fourchette estimee."""
    return int(fps[1]) if source == "mesure" else (int(fps[0]) + int(fps[1])) // 2


def court_fps(fps: tuple[int, int], source: str = "") -> str:
    """« ~85 », ou « 300+ » au-dela du plafond."""
    v = valeur_fps(fps, source)
    return f"{PLAFOND_FPS}+" if v >= PLAFOND_FPS else f"~{v}"


def texte_fps(fps: tuple[int, int] | None, cible: int, source: str = "") -> str:
    if not fps:
        return f"objectif {cible} i/s (non verifie)"
    valeur = plage_fps(fps)
    prefixe = "" if source == "mesure" or valeur.startswith("plus de") else "environ "
    return f"{prefixe}{valeur} i/s (objectif {cible})"


# --------------------------------------------------------------------------
# Objectif
# --------------------------------------------------------------------------

def appid_steam(game: Game | None) -> str:
    if game is None:
        return ""
    if game.source == "steam" and game.source_id:
        return str(game.source_id)
    return str(game.extra.get("steam_appid") or "")


def est_esport(game: Game | None) -> bool:
    """Jeu competitif : chaque image compte, l'objectif suit l'ecran."""
    if game is None:
        return False
    if game.extra.get("esport") is not None:            # choix explicite
        return bool(game.extra.get("esport"))
    if appid_steam(game) in ESPORT_APPIDS:
        return True
    cle = normalize_title(game.title)
    return any(normalize_title(t) in cle for t in ESPORT_TITRES if normalize_title(t))


def cible_du_jeu(game: Game | None) -> int:
    """Objectif d'images par seconde choisi par le joueur pour CE jeu
    (« Mon choix », 2.1.0) ; 0 quand c'est la frequence de l'ecran."""
    if game is None:
        return 0
    try:
        return max(0, int(game.extra.get("cible_fps") or 0))
    except (TypeError, ValueError):
        return 0


def cible_fps(game: Game | None, refresh: int) -> int:
    """Images par seconde visees : la frequence de l'ecran, pour tous les
    jeux, sauf si le joueur a fixe un objectif pour ce jeu (« Mon choix »),
    ou un objectif general dans les reglages. Le but est d'exploiter
    l'ecran au maximum ; quand le materiel ne suit pas, `recommander`
    descend par paliers (voir `paliers`)."""
    from ..core.config import CONFIG
    refresh = int(refresh or 60)
    voulu = cible_du_jeu(game)
    if not voulu:
        try:
            voulu = int(CONFIG.get("optimizer.recommande_fps", 0) or 0)
        except (TypeError, ValueError):
            voulu = 0
    if voulu > 0:
        return max(30, min(voulu, refresh))
    return max(30, refresh)


#: en dessous, un jeu n'est plus « fluide » : plancher de la proposition
#: « la plus belle image »
PLANCHER_FLUIDE = 60

#: objectifs de repli quand la frequence de l'ecran est hors de portee
PALIERS = (240, 200, 165, 144, 120, 100, 90, 75, 60, 50, 40, 30)


def paliers(cible: int) -> list[int]:
    """La cible puis les paliers inferieurs, du plus haut au plus bas."""
    return [cible] + [p for p in PALIERS if p < cible]


# --------------------------------------------------------------------------
# Images par seconde par niveau
# --------------------------------------------------------------------------

def _deriver(connus: dict[str, tuple[float, float]]) -> dict[str, tuple[float, float]]:
    """Complete les niveaux manquants depuis le niveau connu le plus proche."""
    if not connus:
        return {}
    sortie = dict(connus)
    for n in NIVEAUX:
        if n in sortie:
            continue
        proche = min(connus, key=lambda k: abs(NIVEAUX.index(k) - NIVEAUX.index(n)))
        r = COUT[n] / COUT[proche]
        sortie[n] = (connus[proche][0] * r, connus[proche][1] * r)
    return sortie


def _depuis_runs(runs: dict[str, dict]) -> dict[str, tuple[float, float]]:
    """Mesures (meilleure par profil) -> images/s natives par niveau.
    Une mesure faite avec la super-resolution est ramenee a la definition
    native pour pouvoir etre comparee."""
    from ..puissance.estimation import PROFIL_PRESET
    par_niveau: dict[str, tuple[float, float, float]] = {}
    for profil, run in (runs or {}).items():
        if not isinstance(run, dict):
            continue
        niveau = run.get("preset") or PROFIL_PRESET.get(profil)
        try:
            moy = float(run.get("fps_avg") or 0)
            bas = float(run.get("fps_low_1") or 0) or moy * 0.7
        except (TypeError, ValueError):
            continue
        if niveau not in NIVEAUX or moy <= 0:
            continue
        mode = run.get("upscaler_mode") or "off"
        gain = MODES.get(mode, MODES["off"])[0]
        quand = float(run.get("at") or 0)
        if niveau not in par_niveau or quand >= par_niveau[niveau][2]:
            par_niveau[niveau] = (bas / gain, moy / gain, quand)
    return {n: (v[0], v[1]) for n, v in par_niveau.items()}


@dataclass
class Table:
    fps: dict[str, tuple[float, float]]
    source: str
    ultra_autorise: bool = False
    niveau_max: str = "ultra"
    plafond_cpu: float | None = None
    notes: list[str] = field(default_factory=list)
    mesures: tuple[str, ...] = ()


def table_fps(game: Game | None, hw: HardwareInfo, display: Display | None,
              runs: dict | None = None, exig=None, communaute: list | None = None) -> Table:
    """Images/s natives attendues a chaque niveau, avec leur source."""
    from ..puissance import estimation
    mesure = _depuis_runs(runs or {})
    if mesure:
        return Table(_deriver(mesure), estimation.MESURE, ultra_autorise=True,
                     notes=["Mesure reelle sur votre PC."], mesures=tuple(mesure))

    machine = estimation.machine_depuis(hw)
    mode = (display.native or display.current) if display else None
    if mode is not None and mode.width and mode.height:
        machine.pixels = mode.width * mode.height
        machine.definition = f"{mode.width}x{mode.height}"
    titre = game.title if game else ""
    appid = appid_steam(game)
    if exig is None and appid:
        try:
            from ..puissance import exigences
            exig = exigences.en_cache(appid)
        except Exception:
            exig = None

    if communaute is None:
        # mesures partagees deja lues (jamais d'appel reseau ici)
        from ..puissance import mesures_en_memoire
        communaute = mesures_en_memoire()
    from ..partage import cle_jeu
    cle = cle_jeu(game)
    if communaute and cle:
        ev = estimation.depuis_communaute(titre, cle, machine, communaute)
        if ev is not None:
            connus = {p: (float(v[0]), float(v[1])) for p, v in ev.fps.items()}
            return Table(_deriver(connus), estimation.COMMUNAUTE,
                         ultra_autorise="ultra" in ev.fps, notes=list(ev.notes))


    # corrigee par les parties mesurees sur ce PC (BG3, 9 octobre : 55 i/s
    # estimees, 130 vues)
    try:
        from ..perf import store as perf_store
        runs_pc = perf_store._ACTIF.runs if perf_store._ACTIF is not None else []
    except Exception:
        runs_pc = []
    ev = estimation.estimer(titre, exig, machine, estimation.calibration_du_pc(runs_pc, machine))
    if ev.source != estimation.ESTIME or ev.bloque:
        # jeu qui ne se lance pas sur cette carte (ray tracing exige) : aucun
        # reglage a promettre, la note dit pourquoi
        return Table({}, estimation.INCONNU, notes=list(ev.notes))
    connus = {p: (float(v[0]), float(v[1])) for p, v in ev.fps.items()}
    t = Table(_deriver(connus), estimation.ESTIME, ultra_autorise=False,
              notes=list(ev.notes))
    if ev.limite == "vram" or any("Memoire vive" in n and "recommandation" in n
                                  for n in ev.notes):
        t.niveau_max = "moyenne"
    # plafond du processeur : la super-resolution ne le depasse pas
    valeurs = [ev.fps[p][1] for p in ("haute", "moyenne", "basse") if p in ev.fps]
    if len(valeurs) >= 2 and valeurs[-1] == valeurs[-2]:
        t.plafond_cpu = float(valeurs[-1])
    return t


# --------------------------------------------------------------------------
# Super-resolution disponible
# --------------------------------------------------------------------------

def famille_upscaler(hw: HardwareInfo, capacites: list[str] | None) -> str:
    """Technologie que la recette sait regler ET que la carte gere."""
    caps = set(capacites or [])
    feats = set(hw.gpu.features or [])
    if "upscaler" in caps:
        if "dlss" in feats:
            return "dlss"
        if "xess" in feats and hw.gpu.vendor == "intel":
            return "xess"
        return "fsr"                       # FSR fonctionne sur toutes les cartes
    if "echelle_resolution" in caps:
        return "echelle"
    return ""


def _penalite(mode: str, famille: str, pixels: int) -> float:
    base = MODES[mode][1] * PENALITE_FAMILLE.get(famille, 1.5)
    if pixels >= PIXELS_4K:                # 4K : la super-resolution y excelle
        base *= 0.6
    elif pixels <= 2_100_000 and mode != "off":   # 1080p : elle y est plus visible
        base *= 1.25
    return base


def _option(t: Table, niveau: str, mode: str, cible: int) -> Option:
    if niveau not in t.fps:
        return Option(niveau, mode, None, False)
    gain = MODES[mode][0]
    bas, haut = t.fps[niveau]
    bas, haut = bas * gain, haut * gain
    if t.plafond_cpu:
        bas, haut = min(bas, t.plafond_cpu), min(haut, t.plafond_cpu)
    if t.source == "mesure":
        # (1 % bas, moyenne) : moyenne a l'objectif et creux contenus
        atteint = haut >= cible * 0.97 and bas >= cible * 0.6
    else:
        # fourchette prudente : le bas de la fourchette doit suivre
        atteint = bas >= cible * 0.92
    return Option(niveau, mode, (int(bas), int(haut)), atteint)


# --------------------------------------------------------------------------
# Choix
# --------------------------------------------------------------------------

#: capacites de super-resolution : retirees quand le joueur decoche la case
SR_CAPACITES = ("upscaler", "echelle_resolution")
#: valeur par defaut de `recommander(sr=...)` : lire la case du jeu
DU_JEU = "du_jeu"


def sr_du_jeu(game: Game | None, carte: str) -> bool | None:
    """La case « DLSS » de cette carte pour ce jeu (10 octobre, demande de
    l'auteur : « une coche » sur les deux cartes) : True cochee, False
    decochee, None si le joueur n'y a pas touche (ORION l'utilise alors
    seulement quand il en faut pour tenir l'objectif)."""
    if game is None:
        return None
    v = (game.extra.get("sr") or {}).get(carte)
    return v if isinstance(v, bool) else None


def carte_active(game: Game | None) -> str:
    """« choix » des que le joueur a fixe un niveau ou un objectif, sinon « ecran »."""
    if game is None:
        return "ecran"
    return "choix" if (niveau_choisi(game) or cible_du_jeu(game)) else "ecran"


def niveau_choisi(game: Game | None) -> str:
    """Niveau impose par le joueur pour ce jeu (curseur deplace), sinon ""."""
    if game is None:
        return ""
    n = str(game.extra.get("recommande_niveau") or "")
    return n if n in NIVEAUX else ""


def choisir_niveau(game: Game, niveau: str) -> None:
    """Deplace le curseur pour CE jeu ; "" revient au point recommande."""
    if niveau in NIVEAUX:
        game.extra["recommande_niveau"] = niveau
    else:
        game.extra.pop("recommande_niveau", None)


def capacites_connues(game: Game | None) -> list[str] | None:
    if game is None:
        return None
    return _CAPACITES.get(game.uid)


def noter_capacites(game: Game, capacites: list[str]) -> None:
    _CAPACITES[game.uid] = list(capacites or [])


def recommander(game: Game | None, hw: HardwareInfo, display: Display | None,
                capacites: list[str] | None = None, runs: dict | None = None,
                exig=None, communaute: list | None = None,
                refresh: int | None = None, cible: int | None = None,
                sr=DU_JEU) -> Recommandation:
    """Le meilleur niveau qui tient l'objectif d'images par seconde (la
    frequence de l'ecran, l'objectif du joueur pour ce jeu, ou `cible`
    quand l'appelant veut en essayer un autre).

    `sr` : la case DLSS / FSR / XeSS. True : toujours activee (un bond
    d'images par seconde) ; False : jamais (image a la definition de
    l'ecran) ; None : seulement s'il en faut pour tenir l'objectif. Par
    defaut, la case de la carte en place pour ce jeu."""
    if capacites is None:
        capacites = capacites_connues(game) or []
    if sr == DU_JEU:
        sr = sr_du_jeu(game, carte_active(game))
    if sr is False:
        capacites = [c for c in capacites if c not in SR_CAPACITES]
    if runs is None and game is not None:
        try:
            from ..perf.store import mesures_du_jeu
            runs = mesures_du_jeu(game.uid)
        except Exception:
            runs = {}
    if refresh is None:
        refresh = 60
        if display is not None:
            n = display.native or display.current
            refresh = (display.best_refresh(n.width, n.height) if n else
                       display.max_refresh_at_native) or 60
    pixels = 2_073_600
    definition = ""
    if display is not None and (display.native or display.current):
        natif = display.native or display.current
        pixels = natif.pixels
        definition = nom_definition(natif.width, natif.height)

    objectif = cible_fps(game, refresh) if not cible else max(30, min(int(cible), int(refresh or 60)))
    r = Recommandation(cible=objectif, esport=est_esport(game),
                       gpu=gpu_court(hw.gpu.name), definition=definition)
    t = table_fps(game, hw, display, runs, exig, communaute)
    r.source = t.source
    r.notes = list(t.notes)
    r.niveaux_mesures = t.mesures
    famille = famille_upscaler(hw, capacites)
    modes = ["off"] + (["quality", "balanced", "performance"] if famille else [])
    if sr is True and famille:
        modes = ["quality", "balanced", "performance"]      # case cochee : toujours active

    autorises = [n for n in NIVEAUX
                 if NIVEAUX.index(n) <= NIVEAUX.index(t.niveau_max)
                 and (n != "ultra" or t.ultra_autorise)]

    if not t.fps:
        # aucune donnee : repli prudent selon la gamme de la carte
        tier = hw.gpu.tier
        n = "haute" if tier >= 2 else "moyenne" if tier == 1 else "basse"
        mode = "quality" if famille and (sr is True or tier <= 1 or pixels >= PIXELS_4K) else "off"
        r.niveau_conseille = n
        r.options = {x: Option(x, mode if x == n else "off") for x in NIVEAUX}
        r.raison = ("Configuration du jeu inconnue : niveau choisi d'apres la gamme "
                    "de votre carte graphique, sans garantie d'images par seconde.")
        r.atteint = False
        _appliquer(r, game, famille, mode)
        return r

    # meilleure option de chaque niveau : sans super-resolution si elle suffit,
    # sinon le mode le plus fin qui atteint l'objectif
    # Chaque niveau est pousse au maximum de ce que l'ecran et le materiel
    # permettent : sans super-resolution si elle suffit, sinon le mode le
    # plus fin qui tient la frequence de l'ecran ; et si aucun ne la tient,
    # le mode le plus fin qui donne (a 3 % pres) le plus d'images possible.
    for n in NIVEAUX:
        essais = [_option(t, n, m, r.cible) for m in modes]
        choix = next((o for o in essais if o.atteint), None)
        if choix is None:
            sommet = max((o.fps[1] for o in essais if o.fps), default=0)
            choix = next((o for o in essais if o.fps and o.fps[1] >= sommet * 0.97),
                         essais[0])
        r.options[n] = choix

    # Point conseille : le plus beau reglage qui tient la frequence de
    # l'ecran ; sinon le plus haut palier que ce PC tient, et le plus beau
    # reglage a ce palier.
    meilleure = None
    for objectif in paliers(r.cible):
        score_max = None
        for n in autorises:
            for m in modes:
                o = _option(t, n, m, objectif)
                if not o.atteint:
                    continue
                score = QUALITE[n] - _penalite(m, famille, pixels)
                if score_max is None or score > score_max + 1e-9:
                    meilleure, score_max = o, score
        if meilleure is not None:
            r.palier = objectif
            break
    if meilleure is None:
        # meme 30 i/s hors de portee : le plus fluide possible, sans limite
        n = autorises[0] if autorises else "basse"
        meilleure = _option(t, n, modes[-1], r.cible)
        r.atteint = False
        r.raison = (f"Meme en Basse, l'objectif de {r.cible} i/s n'est pas atteint "
                    "sur ce PC : ORION choisit le reglage le plus fluide.")
    elif r.palier < r.cible:
        meilleure.atteint = False
        r.atteint = False
        r.raison = (f"Votre ecran affiche {r.cible} images par seconde, ce PC en "
                    f"tient {r.palier} sur ce jeu : ORION regle le jeu et la limite "
                    f"d'images sur {r.palier} i/s pour un rythme regulier.")
    else:
        r.raison = _raison(meilleure, r, t)
    r.niveau_conseille = meilleure.niveau
    r.options[meilleure.niveau] = meilleure
    # L'autre proposition, pour qui prefere l'image aux images : le plus
    # beau reglage qui reste fluide (60 i/s, ou l'ecran s'il affiche moins).
    r.niveau_beau = meilleure.niveau
    plancher = min(PLANCHER_FLUIDE, r.cible)
    belle, score_max = None, None
    for n in autorises:
        for m in modes:
            o = _option(t, n, m, plancher)
            if not o.atteint:
                continue
            score = QUALITE[n] - _penalite(m, famille, pixels)
            if score_max is None or score > score_max + 1e-9:
                belle, score_max = o, score
    if belle is not None and QUALITE[belle.niveau] > QUALITE[meilleure.niveau]:
        belle.atteint = False              # sous la frequence de l'ecran, par choix
        r.niveau_beau = belle.niveau
        r.options[belle.niveau] = belle
    _ordonner(r, t, modes)
    _appliquer(r, game, famille, meilleure.mode, meilleure)
    if r.force:                 # niveau choisi a la main : son propre palier
        r.palier = 0
        if r.fps:
            mesure = t.source == "mesure"
            bas, haut = r.fps
            r.palier = next((p for p in paliers(r.cible)
                             if (haut >= p * 0.97 and bas >= p * 0.6 if mesure
                                 else bas >= p * 0.92)), 0)
            r.atteint = r.palier >= r.cible
    return r


def _milieu(o: Option | None) -> float | None:
    return (o.fps[0] + o.fps[1]) / 2 if o is not None and o.fps else None


def _ordonner(r: Recommandation, t: Table, modes: list[str]) -> None:
    """Le curseur reste coherent : baisser la qualite ne fait jamais perdre
    d'images, la monter n'en fait jamais gagner.

    Chaque niveau choisit sa propre super-resolution ; sans cette passe, un
    niveau leger sans super-resolution pouvait afficher moins d'images qu'un
    niveau lourd qui en utilise une (« Basse 105 i/s, Haute 120 i/s »).
    Le niveau conseille sert de repere et n'est jamais modifie."""
    if r.niveau_conseille not in NIVEAUX:
        return
    pivot = NIVEAUX.index(r.niveau_conseille)

    # niveaux plus legers : au moins autant d'images que le niveau au-dessus
    for i in range(pivot - 1, -1, -1):
        n, sup = NIVEAUX[i], NIVEAUX[i + 1]
        o, s = r.options.get(n), r.options.get(sup)
        mo, ms = _milieu(o), _milieu(s)
        if mo is None or ms is None or mo >= ms:
            continue
        essais = [_option(t, n, m, r.cible) for m in modes]
        choix = next((e for e in essais if (_milieu(e) or 0) >= ms), None)
        if choix is None:                 # table incoherente (mesures bruitees)
            choix = Option(n, s.mode, s.fps, o.atteint)
        r.options[n] = choix

    # niveaux plus lourds : au plus autant d'images que le niveau en dessous
    for i in range(pivot + 1, len(NIVEAUX)):
        n, inf = NIVEAUX[i], NIVEAUX[i - 1]
        o, b = r.options.get(n), r.options.get(inf)
        mo, mb = _milieu(o), _milieu(b)
        if mo is None or mb is None or mo <= mb or n == r.niveau_beau:
            continue
        essais = [_option(t, n, m, r.cible) for m in modes]
        choix = next((e for e in essais if _milieu(e) is not None
                      and _milieu(e) <= mb), None)
        if choix is None:
            choix = Option(n, b.mode, b.fps, False)
        r.options[n] = choix


def _raison(o: Option, r: Recommandation, t: Table) -> str:
    objectif = f"la frequence de votre ecran ({r.cible} i/s)"
    origine = {"mesure": "d'apres vos parties mesurees",
               "communaute": "d'apres les mesures de joueurs equipes comme vous",
               "estime": "d'apres la configuration recommandee du jeu"}.get(t.source, "")
    texte = (f"Le plus beau niveau qui tient {objectif}, {origine}.").replace(", .", ".")
    if o.niveau == "haute" and not t.ultra_autorise and t.source == "estime":
        texte += " Ultra n'est propose qu'apres une mesure reelle."
    return texte


def _appliquer(r: Recommandation, game: Game | None, famille: str, mode: str,
               option: Option | None = None) -> None:
    """Applique le choix du joueur s'il a deplace le curseur."""
    force = niveau_choisi(game)
    if force and force != r.niveau_conseille:
        r.force = True
        option = r.options.get(force) or Option(force)
        r.niveau = force
        r.mode = option.mode
        r.fps = option.fps
        r.atteint = option.atteint
        r.raison = (f"Niveau choisi pour ce jeu (conseille : "
                    f"{NOMS_NIVEAUX[r.niveau_conseille]}).")
    else:
        r.niveau = r.niveau_conseille
        r.mode = mode
        if option is not None:
            r.fps = option.fps
            r.atteint = r.atteint and option.atteint
    r.famille = famille if r.mode != "off" else ""
    if not r.atteint and r.fps is None:
        r.atteint = False
