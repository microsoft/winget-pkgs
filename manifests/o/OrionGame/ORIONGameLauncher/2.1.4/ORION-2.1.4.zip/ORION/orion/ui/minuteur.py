"""Appels differes : « fais ceci dans 15 secondes ».

`QTimer.singleShot(delai, fonction)` n'a pas de proprietaire : l'appel part
meme si la fenetre ou le widget qui l'a demande a ete detruit entre-temps,
et Qt leve alors « Internal C++ object already deleted » (une « erreur
imprevue » pour le joueur, a la fermeture d'une page ou d'ORION).

`plus_tard` attache la minuterie a son proprietaire : s'il disparait, elle
disparait avec lui et l'appel n'a jamais lieu. Tout appel differe d'ORION
passe par ici (un test interdit `QTimer.singleShot` ailleurs).
"""
from __future__ import annotations

from PySide6.QtCore import QObject, QThread, QTimer


def plus_tard(proprietaire: QObject, delai_ms: int, fonction) -> QTimer | None:
    """Appelle `fonction` dans `delai_ms`, seulement si `proprietaire`
    existe encore a ce moment-la."""
    if QThread.currentThread() is not proprietaire.thread():
        # demande venue d'un autre fil : Qt porte l'appel dans le fil du
        # proprietaire, et l'abandonne de meme s'il est detruit. Seul un delai
        # nul est porte ainsi (appel mis en file) : une minuterie demarree
        # depuis un fil sans boucle Qt ne sonne jamais. Pour un vrai delai, on
        # porte d'abord la demande dans le fil du proprietaire, qui la pose.
        delai_ms = max(0, int(delai_ms))
        if delai_ms:
            QTimer.singleShot(0, proprietaire, lambda: plus_tard(proprietaire, delai_ms, fonction))  # noqa: minuteur
        else:
            QTimer.singleShot(0, proprietaire, fonction)  # noqa: minuteur
        return None
    minuteur = QTimer(proprietaire)
    minuteur.setSingleShot(True)
    minuteur.timeout.connect(fonction)
    minuteur.timeout.connect(minuteur.deleteLater)
    minuteur.start(max(0, int(delai_ms)))
    return minuteur
