"""Le bilan en une minute : ce que vaut l'installation d'ORION, en quatre
phrases, des que l'analyse du PC et le scan de la bibliotheque sont faits.

Un nouveau venu voyait une bibliotheque vide et devait deviner a quoi
sert ORION. Le bilan dit tout de suite : combien de ses jeux tournent en
Haute sur ce PC, combien de pilotes sont a mettre a jour, ce que vaut sa
bibliotheque, et si des jeux de sa liste d'envies ont baisse. Il s'ouvre
une fois, a la premiere installation, et reste accessible depuis « Ma
machine ». Fonction pure (`calculer`) : rien n'est lu ici, tout est passe
par la fenetre principale.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .version import APP_NAME


@dataclass
class Ligne:
    titre: str                      # la phrase qui compte
    details: list[str] = field(default_factory=list)   # precisions, en gris : des phrases entieres, traduites une a une
    page: str = ""                  # page a ouvrir (« advice », « hardware », « wishlist », « library »)
    bouton: str = ""                # libelle du bouton, vide : pas de bouton

    @property
    def detail(self) -> str:
        return " ".join(self.details)


@dataclass
class Bilan:
    lignes: list[Ligne] = field(default_factory=list)
    complet: bool = True            # faux : des elements sont encore en cours de lecture

    @property
    def vide(self) -> bool:
        return not self.lignes


def _pluriel(n: int, un: str, plusieurs: str) -> str:
    return un if n == 1 else plusieurs


def calculer(jeux: list, resultats: list | None, conseils: list | None,
             envies: list | None, valeur=None, analyse_faite: bool = True) -> Bilan:
    """`jeux` : les jeux de la bibliotheque ; `resultats` : les couples
    (candidat, evaluation) du calculateur de puissance (None : pas encore
    evalues) ; `conseils` : la page Conseils ; `envies` : la liste d'envies ;
    `valeur` : la valeur de la bibliotheque (None : inconnue)."""
    b = Bilan()
    nb = len(jeux or [])

    # -- les jeux qui tournent ------------------------------------------
    if nb == 0:
        b.lignes.append(Ligne(
            "Aucun jeu trouve pour l'instant",
            [f"{APP_NAME} cherche les jeux de Steam, GOG, Epic, Xbox, Ubisoft et EA sur vos disques.",
             "Ajoutez un dossier ou un jeu a la main depuis la bibliotheque."],
            "library", "Ouvrir la bibliotheque"))
    elif resultats is None or not analyse_faite:
        b.lignes.append(Ligne(
            f"{nb} {_pluriel(nb, 'jeu trouve', 'jeux trouves')}",
            ["Les configurations requises se lisent en fond : dans quelques minutes, "
             "la page Ma machine dira lesquels tournent en qualite Haute."], "hardware", "Voir ma machine"))
        b.complet = False
    else:
        installes = [(c, e) for c, e in resultats if getattr(c, "installe", False)]
        evalues = [(c, e) for c, e in installes if getattr(e, "source", "") != "inconnu"]
        haute = sum(1 for _c, e in evalues if e.niveau == "haute" and getattr(e, "fluide", True))
        jouables = sum(1 for _c, e in evalues if e.niveau and e.niveau != "insuffisant")
        if not evalues:
            b.lignes.append(Ligne(
                f"{nb} {_pluriel(nb, 'jeu trouve', 'jeux trouves')}",
                ["Les configurations requises se lisent en fond : dans quelques minutes, "
                 "la page Ma machine dira lesquels tournent en qualite Haute."], "hardware", "Voir ma machine"))
            b.complet = False
        else:
            n_ev = len(evalues)
            if haute == n_ev:
                titre = (f"Votre PC fait tourner vos {n_ev} jeux en qualite Haute" if n_ev > 1
                         else "Votre PC fait tourner votre jeu en qualite Haute")
            else:
                titre = (f"Votre PC fait tourner {haute} de vos {n_ev} jeux en qualite Haute"
                         if haute else f"Votre PC fait tourner {jouables} de vos {n_ev} jeux")
            details = ["Environ 60 images par seconde en 1080p, d'apres les configurations des editeurs."]
            if jouables < n_ev:
                n = n_ev - jouables
                details.append(f"{n} {_pluriel(n, 'jeu est', 'jeux sont')} en dessous de la configuration minimale.")
            if n_ev < len(installes):
                n = len(installes) - n_ev
                details.append(f"{n} sans configuration connue.")
            b.lignes.append(Ligne(titre, details, "hardware", "Voir le detail"))

    # -- les pilotes --------------------------------------------------------
    if conseils is not None:
        a_faire = [a for a in conseils if getattr(a, "groupe", "") == "Pilotes"
                   and getattr(a, "level", "") in ("conseil", "attention")]
        precis = [a for a in a_faire if any(m in (getattr(a, "title", "") or "")
                                             for m in ("plus recent", "disponible"))]
        if a_faire:
            n = len(a_faire)
            titre = f"{n} {_pluriel(n, 'pilote a mettre a jour', 'pilotes a mettre a jour')}"
            if precis:
                detail = (f"{len(precis)} {_pluriel(len(precis), 'version precise connue', 'versions precises connues')} "
                          "(constructeur, NVIDIA ou Windows Update), avec la page ou la prendre.")
            else:
                detail = "Des pilotes anciens, et la page de leur fabricant pour chacun."
            b.lignes.append(Ligne(titre, [detail], "advice", "Voir les conseils"))
        else:
            b.lignes.append(Ligne("Pilotes a jour", ["Rien de plus recent connu pour votre materiel."], "advice", ""))
    else:
        b.complet = False

    # -- la bibliotheque ----------------------------------------------------
    if valeur is not None and getattr(valeur, "connue", False) and nb:
        b.lignes.append(Ligne(
            f"Votre bibliotheque vaut environ {valeur.montant(valeur.total)} {valeur.devise}",
            [f"Prix actuels hors promotion, {valeur.estimes} jeux sur {valeur.jeux} estimes.",
             "Ni ce que vous avez paye, ni une valeur de revente."], "library", ""))

    # -- la liste d'envies --------------------------------------------------
    envies = list(envies or [])
    if envies:
        baisses = [i for i in envies if (getattr(i, "cut", 0) or 0) > 0
                   and (getattr(i, "dropped", False) or getattr(i, "reached", False))]
        if baisses:
            n = len(baisses)
            noms = ", ".join(getattr(i, "title", "") for i in baisses[:3])
            b.lignes.append(Ligne(
                ("1 jeu de votre liste d'envies a baisse" if n == 1
                 else f"{n} jeux de votre liste d'envies ont baisse"),
                [noms + ("..." if n > 3 else "") + ".", "Boutiques officielles d'abord."],
                "wishlist", "Voir les prix"))
        else:
            n = len(envies)
            b.lignes.append(Ligne(
                f"{n} {_pluriel(n, 'jeu suivi', 'jeux suivis')} dans votre liste d'envies",
                [f"{APP_NAME} vous previent quand l'un d'eux baisse."], "wishlist", ""))
    else:
        b.lignes.append(Ligne(
            "Aucun jeu suivi pour l'instant",
            [f"Importez votre liste d'envies Steam : {APP_NAME} vous previent quand un jeu baisse, "
             "boutiques officielles d'abord."], "wishlist", "Ouvrir la liste d'envies"))
    return b
