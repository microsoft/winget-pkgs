"""Pieces neuves quand le PC retient un jeu (2.1.0).

`puissance.lecture.besoins` dit quel niveau de composant il faudrait pour
un jeu (« une carte graphique du niveau d'une RTX 4060 »). Ce module en
tire des pieces que le joueur peut vraiment mettre dans SON PC, et des
liens de recherche chez des revendeurs de materiel neuf.

Regles de l'auteur (7 octobre) :

* materiel neuf uniquement : les liens vont vers des revendeurs (LDLC,
  Materiel.net), jamais vers un marche d'occasion ni Amazon ;
* la compatibilite d'abord : une carte graphique sur un PC de bureau
  seulement ; un processeur du meme support (socket) que celui en place ;
  de la memoire du meme type (DDR4 / DDR5) et du meme format que les
  barrettes lues. Quand ORION ne peut pas verifier, il ne met pas de lien ;
* « lien partenaire » seulement quand c'en est un : le programme est
  declare dans `affiliation` avec un identifiant ; sans identifiant, le
  lien est une recherche ordinaire et n'est pas presente comme partenaire.
"""
from __future__ import annotations

import re
import urllib.parse
from dataclasses import dataclass, field

from . import affiliation
from .puissance.lecture import (Besoin, _cpu_tous, _exemples_cpu, _exemples_gpu,
                                _marque_gpu, joli_cpu)
from .puissance.references import CPU_PORTABLES

#: revendeurs de materiel neuf (nom, gabarit de recherche)
REVENDEURS: tuple[tuple[str, str], ...] = (
    ("LDLC", "https://www.ldlc.com/recherche/{q}/"),
    ("Materiel.net", "https://www.materiel.net/recherche/{q}/"),
)

NOMS = {"gpu": "Carte graphique", "cpu": "Processeur", "ram": "Memoire vive"}

#: SMBIOSMemoryType -> famille
TYPES_MEMOIRE = {20: "DDR", 21: "DDR2", 24: "DDR3", 26: "DDR4", 34: "DDR5", 35: "LPDDR5"}


@dataclass
class Lien:
    boutique: str
    url: str
    partenaire: bool = False     # vrai seulement avec un identifiant actif


@dataclass
class Piece:
    cle: str                     # gpu | cpu | ram
    nom: str                     # « Carte graphique »
    exemples: list[str] = field(default_factory=list)   # modeles neufs compatibles
    precision: str = ""          # « 8 Go de memoire video », « DDR4 3200, 16 Go au total »
    reserve: str = ""            # ce qui reste a verifier, ou pourquoi pas de lien
    liens: dict[str, list[Lien]] = field(default_factory=dict)   # exemple -> liens

    @property
    def achetable(self) -> bool:
        return bool(self.liens)


# --------------------------------------------------------------------------
# Support du processeur
# --------------------------------------------------------------------------
def support(nom: str) -> str:
    """Support (socket) d'un processeur de bureau d'apres son nom, « » pour
    un processeur portable ou inconnu : « AMD Ryzen 5 5600X » -> AM4,
    « Intel Core i5-12400F » -> LGA1700, « Core Ultra 7 265K » -> LGA1851."""
    n = (nom or "").lower().replace("(r)", "").replace("(tm)", "")
    if "threadripper" in n or "epyc" in n or "ryzen ai" in n:
        return ""
    if "ryzen" in n:
        m = re.search(r"\b(\d{4})([a-z0-9]*)\b", n)
        if not m:
            return ""
        numero, suffixe = int(m.group(1)), m.group(2)
        if re.match(r"(h|hs|hx|u)", suffixe):
            return ""                                   # portable
        serie = numero // 1000
        if serie in (1, 2, 3, 4, 5):
            return "AM4"
        if serie in (7, 8, 9):
            return "AM5"
        return ""
    if "core" in n:
        m = re.search(r"ultra\s*[3579]?\s*(\d{3})([a-z]*)", n)
        if m:
            numero, suffixe = m.group(1), m.group(2)
            if numero.startswith("2") and suffixe in ("k", "kf", "f", "", "t"):
                return "LGA1851"
            return ""                                   # 1xxH, 2xxV, 2xxH : portable
        m = re.search(r"i[3579][- ](\d{4,5})([a-z]*)", n)
        if not m:
            return ""
        numero, suffixe = m.group(1), m.group(2)
        if re.search(r"[hupy]", suffixe):
            return ""                                   # portable
        gen = int(numero) // 1000                   # 12400 -> 12, 8700 -> 8
        return {2: "LGA1155", 3: "LGA1155", 4: "LGA1150", 5: "LGA1150",
                6: "LGA1151", 7: "LGA1151", 8: "LGA1151v2", 9: "LGA1151v2",
                10: "LGA1200", 11: "LGA1200", 12: "LGA1700", 13: "LGA1700",
                14: "LGA1700"}.get(gen, "")
    return ""


def _support_de_la_cle(cle: str, amd: bool) -> str:
    if amd:
        return support(f"ryzen 5 {cle}")
    if re.fullmatch(r"\d{3}[a-z]*", cle):
        return support(f"core ultra 7 {cle}")
    return support(f"core i5-{cle}")


def processeurs(indice: float, socket: str, combien: int = 2) -> list[str]:
    """Processeurs neufs du support demande, juste suffisants (les plus
    petits indices au-dessus du besoin), noms lisibles."""
    if not socket:
        return []
    candidats = [(v, k, amd) for v, k, amd in _cpu_tous()
                 if v >= indice and k not in CPU_PORTABLES
                 and _support_de_la_cle(k, amd) == socket]
    proches = [(k, amd) for v, k, amd in candidats if v <= indice * 1.15] \
        or [(k, amd) for _v, k, amd in candidats[:1]]
    noms: list[str] = []
    for k, amd in proches:
        nom = joli_cpu(k, amd)
        if nom not in noms:
            noms.append(nom)
    return noms[:combien]


# --------------------------------------------------------------------------
# Memoire
# --------------------------------------------------------------------------
def memoire_en_place(barrettes: list[dict] | None, portable: bool) -> tuple[str, int, int]:
    """(famille « DDR4 », vitesse MHz, nombre de barrettes) d'apres les
    barrettes lues ; famille « » si inconnue."""
    familles, vitesses, n = set(), [], 0
    for b in barrettes or []:
        if not isinstance(b, dict):
            continue
        n += 1
        fam = TYPES_MEMOIRE.get(int(b.get("type") or 0), "")
        if fam:
            familles.add(fam)
        # vitesse prevue d'abord : une barrette bridee faute de profil
        # (2666 au lieu de 3200) ne doit pas faire proposer plus lent
        for cle in ("vitesse", "configuree"):
            try:
                v = int(b.get(cle) or 0)
            except (TypeError, ValueError):
                v = 0
            if v:
                vitesses.append(v)
                break
    if len(familles) != 1:
        return "", 0, n
    fam = familles.pop()
    if portable and not fam.startswith("LP"):
        fam = "SO-DIMM " + fam
    return fam, max(vitesses) if vitesses else 0, n


def profil_memoire(cpu_nom: str, famille: str) -> str:
    """Le profil a chercher sur le kit (10 octobre, PC de l'auteur : kit
    « optimise AMD » sur un Core i9, profil illisible, memoire bridee a
    2666 au lieu de 3200) : une recherche de memoire ne doit pas reconduire
    l'erreur."""
    nom = (cpu_nom or "").lower()
    if "intel" in nom:
        return ("Prenez un kit au profil Intel XMP, pas un kit « optimise AMD » : une "
                "carte mere Intel ne lit pas toujours son profil.")
    if ("amd" in nom or "ryzen" in nom) and "DDR5" in famille:
        return "Prenez un kit au profil EXPO (ou XMP garanti compatible AMD)."
    return ""


# --------------------------------------------------------------------------
# Liens
# --------------------------------------------------------------------------
def recherche(requete: str) -> list[Lien]:
    """Un lien de recherche par revendeur ; « partenaire » seulement si le
    programme est actif dans `affiliation`."""
    q = urllib.parse.quote(requete.strip())
    liens: list[Lien] = []
    for nom, gabarit in REVENDEURS:
        url = gabarit.format(q=q)
        liens.append(Lien(nom, url, affiliation.est_partenaire(url)))
    return liens


def _requete_gpu(nom: str) -> str:
    """« RTX 4060 » -> « GeForce RTX 4060 », « Arc B580 » -> « Intel Arc B580 »."""
    marque = _marque_gpu(nom.lower())
    return {"nvidia": "GeForce ", "amd": "Radeon ", "intel": "Intel "}[marque] + nom


# --------------------------------------------------------------------------
# Les pieces d'un besoin
# --------------------------------------------------------------------------
def pieces(besoin: Besoin | None, machine, etat=None) -> list[Piece]:
    """Pieces neuves compatibles pour atteindre le besoin : carte graphique
    (PC de bureau), processeur du meme support, memoire du meme type. Une
    piece sans lien porte en `reserve` la raison."""
    if besoin is None:
        return []
    boitier = getattr(etat, "boitier", "") or ""
    portable = boitier == "portable"
    resultat: list[Piece] = []
    if besoin.gpu is not None:
        p = Piece("gpu", NOMS["gpu"], exemples=[e for e in _exemples_gpu(besoin.gpu).split(" ou ") if e])
        if besoin.vram_go:
            p.precision = f"{besoin.vram_go:g} Go de memoire video"
        if portable:
            p.reserve = "Sur un portable, la carte graphique ne se change pas."
        else:
            p.liens = {e: recherche(_requete_gpu(e)) for e in p.exemples}
            p.reserve = ("Verifiez l'alimentation (puissance et connecteurs) et la place "
                         "dans le boitier.")
            if not boitier:
                p.reserve = "Sur un PC de bureau. " + p.reserve
        resultat.append(p)
    if besoin.cpu is not None:
        socket = support(getattr(machine, "cpu_nom", "") or "")
        p = Piece("cpu", NOMS["cpu"])
        if portable or not socket:
            p.exemples = [e for e in _exemples_cpu(besoin.cpu).split(" ou ") if e]
            p.reserve = ("Sur un portable, le processeur ne se change pas." if portable else
                         "Support de votre processeur inconnu : ORION ne propose rien "
                         "sans compatibilite verifiee.")
        else:
            p.exemples = processeurs(besoin.cpu, socket)
            if p.exemples:
                p.liens = {e: recherche(e) for e in p.exemples}
                p.precision = f"support {socket}"
                p.reserve = ("Meme support que votre processeur : verifiez que votre carte "
                             "mere l'accepte (mise a jour du BIOS parfois necessaire).")
            else:
                p.exemples = [e for e in _exemples_cpu(besoin.cpu).split(" ou ") if e]
                p.reserve = ("Un processeur de ce niveau demanderait une autre carte mere : "
                             "ORION ne le propose pas.")
        resultat.append(p)
    if besoin.ram_go:
        fam, vitesse, n = memoire_en_place(getattr(etat, "barrettes", None), portable)
        p = Piece("ram", NOMS["ram"], precision=f"{besoin.ram_go:g} Go au total")
        if fam:
            requete = f"{fam} {vitesse} {besoin.ram_go:g} Go" if vitesse else f"{fam} {besoin.ram_go:g} Go"
            p.exemples = [requete]
            p.liens = {requete: recherche(requete)}
            p.reserve = (f"{n} barrette(s) en place : verifiez les emplacements libres, "
                         "ou remplacez-les.")
            profil = profil_memoire(getattr(machine, "cpu_nom", "") or "", fam)
            if profil:
                p.reserve += " " + profil
        else:
            p.reserve = ("Type de vos barrettes non lu : ORION ne propose rien sans "
                         "compatibilite verifiee.")
        resultat.append(p)
    return resultat


def pieces_du_jeu(besoins: list[Besoin], machine, etat=None) -> list[Piece]:
    """Les pieces pour l'objectif le plus haut (« Haute »)."""
    return pieces(besoins[-1] if besoins else None, machine, etat)
