"""Liste d'envies et veille de prix.

ORION surveille les jeux que vous n'avez pas encore, compare leur prix sur
les boutiques qu'il connait, et previent quand le seuil que vous avez fixe
est atteint. La liste peut etre importee depuis Steam en un clic : ORION
retrouve tout seul le compte connecte sur la machine.
"""
from __future__ import annotations

from orion.core import region

import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

from .core.config import CONFIG
from .core.logging_setup import get
from .core.models import Game
from .core.paths import DATA_DIR, ensure_dirs
from .core.winutil import read_vdf
from .plugins.scanners.steam import steam_root

log = get("envies")

WISHLIST_FILE = DATA_DIR / "envies.json"
#: alerte de baisse sans seuil : au moins 10 % de moins qu'a la verification
#: precedente, et une remise d'au moins 10 % sur le prix normal
BAISSE_MIN = 0.10
BAISSE_REMISE = 10
#: le prix est remonte nettement : la prochaine baisse sera de nouveau signalee
REMONTEE = 1.05
from .core.steam_limite import NAVIGATEUR as HEADERS  # noqa: E402

WISHLIST_API = "https://api.steampowered.com/IWishlistService/GetWishlist/v1/"
WISHLIST_WEB = "https://store.steampowered.com/wishlist/profiles/{sid}/wishlistdata/"
STORE_SEARCH = "https://store.steampowered.com/api/storesearch/"


@dataclass
class WishItem:
    """Un jeu suivi mais pas encore achete."""
    appid: str
    title: str
    target_price: float = 0.0        # seuil de declenchement, 0 = aucun
    current_price: float = 0.0
    best_shop: str = ""
    best_url: str = ""
    cut: int = 0
    historical_low: float = 0.0
    review_score: int = 0
    art_cover: str = ""
    added_at: float = field(default_factory=time.time)
    last_check: float = 0.0
    notified_price: float = 0.0      # dernier prix ayant declenche une alerte
    source: str = "manuel"
    #: prix releve a la verification precedente : sert a reperer une baisse
    previous_price: float = 0.0
    #: nature de la derniere alerte : « seuil » ou « baisse » (vide = aucune)
    alert_kind: str = ""

    @property
    def uid(self) -> str:
        return f"wish:{self.appid}"

    @property
    def reached(self) -> bool:
        if not self.target_price or not self.current_price:
            return False
        return self.current_price <= self.target_price + 0.001

    @property
    def dropped(self) -> bool:
        """Baisse marquee depuis la verification precedente (2.0) : au moins
        10 % de moins, sur un jeu en promotion. Sert aux jeux suivis sans
        seuil, comme ceux importes de la liste de souhaits Steam."""
        if not self.previous_price or not self.current_price or self.cut < BAISSE_REMISE:
            return False
        return self.current_price <= self.previous_price * (1 - BAISSE_MIN) + 0.001

    def alert(self, baisses: bool = True) -> str:
        """« seuil », « baisse » ou « » : faut-il prevenir, et pourquoi.
        Un prix deja signale ne l'est pas une seconde fois."""
        deja = self.notified_price and self.current_price >= self.notified_price - 0.001
        if deja:
            return ""
        if self.reached:
            return "seuil"
        if baisses and not self.target_price and self.dropped:
            return "baisse"
        return ""

    def as_game(self) -> Game:
        """Objet Game minimal, pour reutiliser jaquettes et prix."""
        g = Game(title=self.title, source="steam", source_id=self.appid,
                 store_url=f"https://store.steampowered.com/app/{self.appid}")
        g.art_cover = self.art_cover
        return g

    def to_dict(self) -> dict:
        return asdict(self)


def _vignette(appid: str, url: str) -> str:
    """Telecharge la petite image d'un resultat de recherche, et la garde.

    Quelques kilo-octets par jeu : de quoi reconnaitre un titre d'un coup
    d'oeil, ce que le nom seul ne permet pas toujours (rééditions,
    homonymes, compilations).
    """
    if not url or not appid:
        return ""
    from .core.paths import ART_DIR
    from .plugins.artwork.base import download
    dossier = ART_DIR / "recherche"
    dossier.mkdir(parents=True, exist_ok=True)
    cible = dossier / f"{appid}.jpg"
    if cible.exists():
        return str(cible)
    try:
        download(url, cible)
    except Exception:
        return ""
    return str(cible) if cible.exists() else ""


def message_alertes(alertes: list) -> tuple[str, str]:
    """(titre, texte) de la notification pour une liste d'alertes."""
    if not alertes:
        return "", ""
    if len(alertes) == 1:
        a = alertes[0]
        prix = region.prix(a.current_price)
        chez = a.best_shop or "Steam"
        remise = f" (-{a.cut} %)" if a.cut else ""
        if a.alert_kind == "seuil":
            return "Prix voulu atteint", f"Prix voulu : {a.title} a {prix} chez {chez}{remise}"
        return "Baisse de prix", f"Baisse : {a.title} a {prix} chez {chez}{remise}"
    noms = ", ".join(f"{a.title} ({region.prix(a.current_price)})" for a in alertes[:3])
    return ("Bons plans reperes",
            f"{len(alertes)} jeux en baisse ou au prix voulu : {noms}"
            + (" ..." if len(alertes) > 3 else ""))


class WishlistService:
    def __init__(self) -> None:
        self.items: dict[str, WishItem] = {}
        self.load()

    # -- persistance ----------------------------------------------------
    def load(self) -> None:
        ensure_dirs()
        from .core.base import Document
        self._doc = Document("envies", WISHLIST_FILE)
        try:
            raw = self._doc.lire(None)
            for d in (raw or {}).get("items", []):
                known = {f for f in WishItem.__dataclass_fields__}
                item = WishItem(**{k: v for k, v in d.items() if k in known})
                self.items[item.appid] = item
        except Exception:
            log.exception("Liste d'envies illisible")

    def save(self) -> None:
        # copie d'abord : la veille des prix enregistre depuis une tache de
        # fond pendant que l'interface peut ajouter ou retirer un jeu
        # (« dictionary changed size during iteration »)
        items = list(self.items.values())
        self._doc.ecrire({"items": [i.to_dict() for i in items]})

    # -- contenu --------------------------------------------------------
    def all(self) -> list[WishItem]:
        return sorted(list(self.items.values()),
                      key=lambda i: (not i.reached, i.title.lower()))

    def add(self, appid: str, title: str, target: float = 0.0,
            source: str = "manuel") -> WishItem:
        item = self.items.get(str(appid))
        if item is None:
            item = WishItem(appid=str(appid), title=title, source=source)
            self.items[item.appid] = item
        if target:
            item.target_price = float(target)
        self.save()
        return item

    def remove(self, appid: str) -> None:
        self.items.pop(str(appid), None)
        self.save()

    def set_target(self, appid: str, target: float) -> None:
        item = self.items.get(str(appid))
        if item is not None:
            item.target_price = float(target)
            item.notified_price = 0.0
            self.save()

    # -- recherche ------------------------------------------------------
    @staticmethod
    def search(term: str, limit: int = 8) -> list[dict]:
        """Recherche un jeu dans la boutique Steam (sorties du jour incluses).

        Meme recherche que la Boutique : les jeux seulement (trente resultats
        au lieu de dix, DLC compris), le sigle de serie developpe (« bo3 » ->
        « black ops 3 ») et, quand presque rien ne sort, le terme sans son
        dernier mot (« F1 202 » -> « F1 »). L'ancienne recherche reste en
        secours."""
        from .contenu_adulte import est_marque
        from .core import recherche
        from .plugins.boutique.steam import SteamBoutique
        source = SteamBoutique()
        offres: dict[str, object] = {}

        def lire(termes) -> None:
            for t in termes:
                try:
                    for o in source.chercher(t):
                        if not o.adulte and not est_marque(o.steam_appid):
                            offres.setdefault(o.steam_appid, o)
                except Exception as exc:
                    log.info("Recherche Steam indisponible pour « %s » : %s", t, exc)
        lectures = recherche.variantes(term)
        lire(recherche.termes_a_poser(term))

        def classer():
            return recherche.classer_variantes(lectures, list(offres.values()),
                                               cle=lambda o: o.titre, seuil=0.55)
        classees = classer()
        # meme regle que la Boutique : on compte les jeux TROUVES, pas les
        # reponses brutes de Steam
        meilleure = recherche.note_variantes(lectures, classees[0].titre) if classees else 0.0
        if recherche.faut_raccourcir(term, len(classees), meilleure):
            toutes = recherche.variantes(term, raccourcie=True)
            lire(t for t, _ in toutes[len(lectures):])
            lectures = toutes
            classees = classer()
        if classees:
            return [{"appid": o.steam_appid, "title": o.titre, "price": o.prix,
                     "cover": _vignette(o.steam_appid, o.image), "release": ""}
                    for o in classees[:limit]]
        return WishlistService._search_court(term, limit)

    @staticmethod
    def _search_court(term: str, limit: int = 8) -> list[dict]:
        """Ancienne recherche Steam (dix resultats, DLC compris), en secours."""
        from orion.core import reseau
        try:
            r = reseau.get(STORE_SEARCH, headers=HEADERS, timeout=12,
                             params={"term": term, "l": region.langue_steam(), "cc": region.cc()})
            if r.status_code != 200:
                return []
            items = (r.json() or {}).get("items") or []
        except Exception:
            return []
        # meme regle que partout : aucun jeu reserve aux adultes
        from .contenu_adulte import resultat_adulte, visibles
        items = visibles([i for i in items if isinstance(i, dict)], adulte=resultat_adulte)
        out = []
        for item in items[:limit]:
            price = item.get("price") or {}
            appid = str(item.get("id") or "")
            out.append({
                "appid": appid,
                "title": item.get("name", ""),
                "price": round(int(price.get("final", 0)) / 100, 2)
                if price else 0.0,
                # la vignette permet de reconnaitre le jeu d'un coup d'oeil,
                # ce qu'un titre seul ne permet pas toujours (rééditions,
                # homonymes, compilations).
                "cover": _vignette(appid, item.get("tiny_image", "")),
                "release": item.get("release_date", ""),
            })
        return out

    # -- import Steam ---------------------------------------------------
    @staticmethod
    def steam_account() -> tuple[str, str]:
        """(SteamID64, pseudo) du dernier compte connecte sur cette machine."""
        root = steam_root()
        if root is None:
            return "", ""
        data = read_vdf(Path(root) / "config" / "loginusers.vdf")
        users = data.get("users") or {}
        best: tuple[str, str, int] = ("", "", -1)
        for sid, info in users.items():
            if not isinstance(info, dict):
                continue
            recent = 1 if str(info.get("MostRecent") or "0") == "1" else 0
            stamp = int(info.get("Timestamp") or 0) + recent * 10 ** 12
            if stamp > best[2]:
                best = (str(sid), str(info.get("PersonaName") or ""), stamp)
        return best[0], best[1]

    def import_steam(self, steamid: str = "") -> tuple[int, str]:
        """Importe la liste de souhaits Steam. Retourne (ajoutes, message)."""
        from orion.core import reseau

        sid = steamid or str(CONFIG.get("wishlist.steamid") or "")
        pseudo = ""
        if not sid:
            sid, pseudo = self.steam_account()
        if not sid:
            return 0, ("Compte Steam introuvable sur cette machine : indiquez "
                       "votre identifiant Steam dans les reglages.")

        entries: list[dict] = []
        try:
            r = reseau.get(WISHLIST_API, headers=HEADERS, timeout=20,
                             params={"steamid": sid})
            if r.status_code == 200:
                items = ((r.json() or {}).get("response") or {}).get("items") or []
                entries = [{"appid": str(i.get("appid"))} for i in items]
        except Exception:
            entries = []

        if not entries:
            try:
                r = reseau.get(WISHLIST_WEB.format(sid=sid), headers=HEADERS,
                                 timeout=20, params={"p": 0})
                if r.status_code == 200:
                    data = r.json() or {}
                    if isinstance(data, dict):
                        entries = [{"appid": str(k), "title": v.get("name", "")}
                                   for k, v in data.items()
                                   if isinstance(v, dict)]
            except Exception:
                entries = []

        if not entries:
            return 0, ("Liste de souhaits inaccessible. Elle doit etre publique "
                       "dans la confidentialite de votre profil Steam.")

        CONFIG.set("wishlist.steamid", sid)
        added = 0
        for entry in entries:
            appid = entry.get("appid") or ""
            if not appid or appid in self.items:
                continue
            title = entry.get("title") or ""
            if not title:
                found = self.search(appid, 1)
                title = found[0]["title"] if found else f"Jeu {appid}"
            self.add(appid, title, source="steam")
            added += 1
        self.save()
        who = f" de {pseudo}" if pseudo else ""
        return added, f"{added} jeu(x) importe(s){who}."

    # -- veille de prix -------------------------------------------------
    def refresh(self, market, artwork=None, progress_cb=None) -> list[WishItem]:
        """Met a jour les prix. Retourne les articles a signaler."""
        alerts: list[WishItem] = []
        items = list(self.items.values())
        baisses = bool(CONFIG.get("wishlist.alerte_baisse", True))
        # prix de Gamesplanet (distributeur officiel partenaire) : un fichier
        # commun, lu une fois pour toute la liste
        from . import prix_gamesplanet
        if items:
            prix_gamesplanet.actualiser()
        for index, item in enumerate(items):
            if progress_cb:
                progress_cb(f"Prix : {item.title}",
                            int(index / max(len(items), 1) * 100))
            game = item.as_game()
            try:
                info = market.get(game, force=False)
            except Exception:
                continue

            offer = info.best or info.current
            if offer:
                item.previous_price = item.current_price
                item.current_price = offer.price
                item.best_shop = offer.shop
                item.best_url = offer.url
                item.cut = offer.cut
                # Gamesplanet le vend moins cher : c'est lui la meilleure offre
                try:
                    normal = float(getattr(info, "base_price", 0) or 0)
                    gp = None if offer.price <= 0 else prix_gamesplanet.offre(
                        item.appid, item.title, normal)
                    if gp is not None and gp.prix < offer.price - 0.001:
                        item.current_price, item.cut = gp.prix, gp.remise
                        item.best_shop, item.best_url = gp.boutique, gp.url
                except Exception:
                    log.debug("Prix Gamesplanet ignore pour %s", item.appid)
                # prix nettement remonte depuis la derniere alerte : on repart de zero
                if item.notified_price and item.current_price > item.notified_price * REMONTEE:
                    item.notified_price = 0.0
            item.historical_low = info.historical_low or item.historical_low
            item.review_score = info.review_score or item.review_score
            item.last_check = time.time()

            if getattr(info, "adulte", False):
                item.art_cover = ""              # regle commune : aucune image
            elif artwork is not None and not item.art_cover:
                try:
                    artwork.ensure(game)
                    item.art_cover = game.art_cover
                except Exception:
                    pass

            item.alert_kind = item.alert(baisses) if offer else ""
            if item.alert_kind:
                item.notified_price = item.current_price
                alerts.append(item)

        self.save()
        if progress_cb:
            progress_cb("", 100)
        return alerts
