"""Page bibliotheque : recherche, tri et grille de jeux."""
from __future__ import annotations

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtWidgets import (QButtonGroup, QCheckBox, QComboBox, QHBoxLayout,
                               QLabel, QLineEdit, QProgressBar, QPushButton,
                               QVBoxLayout, QWidget)

from ...core.config import CONFIG
from ...core.models import Game
from ...i18n import t
from ..widgets.flow_layout import FlowLayout
from ..widgets.game_card import GameCard, signature
from ..widgets.hero import HeroBanner
from ..defilement import ZoneDefilante

#: jours pendant lesquels une partie est dite « recente »
RECENT_JOURS = 30

#: filtres rapides : (cle, libelle, infobulle)
FILTRES = (
    ("tous", "Tous", ""),
    ("favoris", "Favoris", "Jeux marques comme favoris (menu ⋮ d'une tuile)."),
    ("recents", "Joues recemment", "Jeux lances au cours des trente derniers jours."),
    ("jamais", "Jamais lances", "Jeux installes qui n'ont encore jamais ete lances."),
)


def du_filtre(game: Game, cle: str, maintenant: float) -> bool:
    """Ce jeu repond-il au filtre rapide ? Un jeu possede mais non installe
    n'est ni « recent » ni « jamais lance » : ces deux filtres parlent de ce
    qui est sur le disque."""
    if cle == "favoris":
        return bool(game.favorite)
    installe = not game.extra.get("non_installe")
    if cle == "recents":
        return installe and bool(game.last_played) and \
            maintenant - game.last_played < RECENT_JOURS * 86400
    if cle == "jamais":
        return installe and not game.last_played and game.total_play_seconds < 60
    return True


SORTS = [
    ("title", "Nom (A-Z)"),
    ("last_played", "Joue recemment"),
    ("playtime", "Temps de jeu"),
    ("size", "Taille"),
    ("recent", "Installe recemment"),
    ("source", "Plateforme"),
]


class LibraryView(QWidget):
    game_selected = Signal(str)
    game_play = Signal(str)
    game_action = Signal(str, str)         # uid, action du menu ⋮
    hero_play = Signal(str, str)           # uid, profil
    rescan_requested = Signal()
    add_requested = Signal()
    #: « chercher ce nom dans la Boutique » (recherche sans resultat ici)
    boutique_requested = Signal(str)
    #: la liste des jeux (installes ou possedes) a change : la valeur de la
    #: bibliotheque est a recalculer (la fenetre regroupe les demandes)
    contenu_change = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._games: list[Game] = []
        self._possedes: list[Game] = []
        self._cards: dict[str, GameCard] = {}
        self._filter_sources: set[str] | None = None
        self._filtre = "tous"                # filtre rapide (voir FILTRES)
        self._featured: list[Game] = []
        self._profiles: dict[str, str] = {}
        self._tunable: dict[str, bool] = {}
        self._big_picture = False
        self._toutes: dict[str, GameCard] = {}     # toutes les tuiles construites
        self._signatures: dict[str, tuple] = {}
        self._largeur = 0
        self._ordre_tab: list[str] = []

        root = QVBoxLayout(self)
        root.setContentsMargins(24, 18, 24, 12)
        root.setSpacing(14)

        # -- barre d'outils ------------------------------------------
        bar = QHBoxLayout()
        bar.setSpacing(10)

        self.title = QLabel("Bibliotheque")
        self.title.setObjectName("PageTitle")
        bar.addWidget(self.title)

        self.count = QLabel("")
        self.count.setObjectName("PageHint")
        bar.addWidget(self.count)
        bar.addStretch(1)

        self.search = QLineEdit()
        self.search.setObjectName("Search")
        self.search.setPlaceholderText("Rechercher un jeu...")
        self.search.setFixedWidth(220)
        self.search.setClearButtonEnabled(True)
        # la recherche attend la fin de la frappe (classement flou couteux)
        self._frappe = QTimer(self)
        self._frappe.setSingleShot(True)
        self._frappe.setInterval(140)
        self._frappe.timeout.connect(self.refresh)
        self.search.textChanged.connect(lambda _t: self._frappe.start())
        self.search.setToolTip("Ctrl+F pour venir ici, Echap pour effacer")
        from PySide6.QtGui import QKeySequence, QShortcut
        QShortcut(QKeySequence(Qt.Key.Key_Escape), self.search,
                  activated=self.search.clear,
                  context=Qt.ShortcutContext.WidgetShortcut)
        bar.addWidget(self.search)

        self.sort = QComboBox()
        for key, label in SORTS:
            self.sort.addItem(label, key)
        current = CONFIG.get("ui.sort", "title")
        idx = max(0, [k for k, _ in SORTS].index(current) if current in
                  [k for k, _ in SORTS] else 0)
        self.sort.setCurrentIndex(idx)
        self.sort.currentIndexChanged.connect(self._sort_changed)
        bar.addWidget(self.sort)

        self.add_game = QPushButton("Ajouter un jeu")
        self.add_game.setObjectName("Ghost")
        self.add_game.setToolTip(
            "Un jeu installe n'apparait pas ? Choisissez son executable "
            "(.exe) ou son raccourci : il rejoint la bibliotheque.")
        self.add_game.clicked.connect(self.add_requested.emit)
        bar.addWidget(self.add_game)

        self.rescan = QPushButton("Analyser")
        self.rescan.setObjectName("Ghost")
        self.rescan.clicked.connect(self.rescan_requested.emit)
        bar.addWidget(self.rescan)
        root.addLayout(bar)

        # -- filtres rapides et options d'affichage ---------------------
        # (les deux cases etaient sur la premiere ligne : a la largeur
        # minimale de la fenetre, « Ajouter un jeu » et « Analyser »
        # sortaient de l'ecran)
        filtres = QHBoxLayout()
        filtres.setContentsMargins(0, 0, 0, 0)
        filtres.setSpacing(6)
        self._groupe_filtres = QButtonGroup(self)
        self._groupe_filtres.setExclusive(True)
        self.filtres: dict[str, QPushButton] = {}
        for cle, texte, bulle in FILTRES:
            b = QPushButton(texte)
            b.setObjectName("Chip")
            b.setCheckable(True)
            b.setChecked(cle == self._filtre)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.setToolTip(bulle)
            b.clicked.connect(lambda _=False, c=cle: self.set_filtre(c))
            self._groupe_filtres.addButton(b)
            filtres.addWidget(b)
            self.filtres[cle] = b
        filtres.addStretch(1)
        self.hide_missing = QCheckBox("Masquer les introuvables")
        self.hide_missing.setMinimumWidth(self.hide_missing.sizeHint().width())
        self.hide_missing.setChecked(bool(CONFIG.get("ui.hide_missing", True)))
        self.hide_missing.setToolTip(
            "Jeux encore declares par leur plateforme alors que leurs "
            "fichiers ont disparu du disque")
        self.hide_missing.stateChanged.connect(self._missing_changed)

        self.voir_possedes = QCheckBox("Non installes")
        self.voir_possedes.setChecked(bool(CONFIG.get("ui.voir_non_installes", True)))
        self.voir_possedes.setToolTip(
            "Jeux que vous possedez sur Steam, Epic ou GOG sans les avoir "
            "installes sur ce PC. Un clic ouvre leur installation.")
        self.voir_possedes.stateChanged.connect(self._possedes_changed)
        self.voir_possedes.hide()

        # (2.1.2) jeux pretes par la famille Steam : affiches ou non
        self.voir_famille = QCheckBox("Steam Family")
        self.voir_famille.setChecked(bool(CONFIG.get("ui.voir_steam_family", True)))
        self.voir_famille.setToolTip(
            "Afficher les jeux de votre famille Steam : ceux qu'un proche vous prete, "
            "et que vous ne possedez pas vous-meme.")
        self.voir_famille.stateChanged.connect(self._famille_changed)
        self.voir_famille.hide()

        filtres.addWidget(self.voir_possedes)
        filtres.addWidget(self.voir_famille)
        filtres.addWidget(self.hide_missing)
        root.addLayout(filtres)

        # -- valeur du catalogue possede (a titre indicatif) ------------
        ligne = QHBoxLayout()
        ligne.setContentsMargins(0, 0, 0, 0)
        # 2.1.1 : un bouton qui ouvre « Valeur estimee de ma bibliotheque »
        # (la liste des jeux comptes et la carte a enregistrer)
        self.valeur = QPushButton("")
        self.valeur.setObjectName("ValeurBibliotheque")
        self.valeur.setCursor(Qt.CursorShape.PointingHandCursor)
        self.valeur.setVisible(False)
        self.valeur.clicked.connect(self.ouvrir_valeur)
        ligne.addWidget(self.valeur)
        ligne.addStretch(1)
        root.addLayout(ligne)
        self._valeur = None

        # -- progression ---------------------------------------------
        self.progress = QProgressBar()
        self.progress.setVisible(False)
        self.progress.setTextVisible(False)
        root.addWidget(self.progress)

        # -- banniere + grille ----------------------------------------
        # les deux defilent ensemble : la banniere laisse la place aux jeux
        # des qu'on descend dans la bibliotheque.
        self.scroll = ZoneDefilante()
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        page = QWidget()
        column = QVBoxLayout(page)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(18)

        self.hero = HeroBanner()
        self.hero.setVisible(False)
        self.hero.open_requested.connect(self.game_selected.emit)
        self.hero.play_requested.connect(self.hero_play.emit)
        column.addWidget(self.hero)

        self.holder = QWidget()
        self.grid = FlowLayout(self.holder, margin=2, spacing=16)
        column.addWidget(self.holder)
        column.addStretch(1)

        # -- rien ne correspond (recherche ou filtre) -------------------
        self.aucun = QWidget()
        al = QVBoxLayout(self.aucun)
        al.setContentsMargins(4, 30, 4, 10)
        al.setSpacing(12)
        self.aucun_texte = QLabel("")
        self.aucun_texte.setObjectName("Dim")
        self.aucun_texte.setWordWrap(True)
        self.aucun_texte.setAlignment(Qt.AlignmentFlag.AlignCenter)
        al.addWidget(self.aucun_texte)
        boutons = QHBoxLayout()
        boutons.setSpacing(10)
        boutons.addStretch(1)
        self.b_boutique = QPushButton("")
        self.b_boutique.setObjectName("Primary")
        self.b_boutique.clicked.connect(
            lambda: self.boutique_requested.emit(self.search.text().strip()))
        boutons.addWidget(self.b_boutique)
        self.b_tout_montrer = QPushButton("Tout afficher")
        self.b_tout_montrer.setObjectName("Ghost")
        self.b_tout_montrer.clicked.connect(self.tout_afficher)
        boutons.addWidget(self.b_tout_montrer)
        boutons.addStretch(1)
        al.addLayout(boutons)
        self.aucun.setVisible(False)
        column.insertWidget(column.count() - 1, self.aucun)

        self.scroll.setWidget(page)
        root.addWidget(self.scroll, 1)

        self.empty = QLabel(
            "Aucun jeu pour le moment.\n\n"
            "Lancez une analyse : ORION explore Steam, Epic, GOG, Ubisoft, EA, "
            "Battle.net, le Microsoft Store et vos dossiers de jeux.")
        self.empty.setObjectName("Dim")
        self.empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.empty.setVisible(False)
        root.addWidget(self.empty, 1)

    # ------------------------------------------------------------------
    def set_big_picture(self, enabled: bool) -> None:
        """Affichage salon : on ne garde que l'essentiel a l'ecran."""
        self._big_picture = enabled
        for widget in (self.search, self.sort, self.hide_missing, self.rescan,
                       *self.filtres.values()):
            widget.setVisible(not enabled)
        if enabled and self._filtre != "tous":
            self.set_filtre("tous")           # salon : toute la bibliotheque
        self.valeur.setVisible(not enabled and self._valeur is not None
                               and self._valeur.connue)
        self._update_hero()
        font = self.title.font()
        font.setPointSize(22 if enabled else 13)
        self.title.setFont(font)
        self.grid.setSpacing(26 if enabled else 16)

    def set_games(self, games: list[Game]) -> None:
        self._games = games
        self.refresh()
        self.contenu_change.emit()

    def set_valeur(self, valeur) -> None:
        """Valeur du catalogue possede (`orion.valeur_catalogue.Valeur`)."""
        from ..theme import GLASS, PALETTE
        self._valeur = valeur
        if valeur is None or not valeur.connue:
            self.valeur.setVisible(False)
            return
        from ...core import region
        montant = region.prix(valeur.total, valeur.devise, decimales=False)
        self.valeur.setText(f"Valeur estimee de ma bibliotheque :  {montant}  ·  "
                            f"{valeur.estimes} jeux sur {valeur.jeux}  ›")
        self.valeur.setToolTip(valeur.detail() + "\n\nCliquez pour voir les jeux comptes et "
                               "enregistrer la carte a partager.")
        self.valeur.setStyleSheet(
            f"QPushButton#ValeurBibliotheque{{background:{GLASS['glass_flat']};color:{PALETTE['text']};"
            f"border:1px solid {PALETTE['border']};border-radius:10px;"
            "padding:5px 14px;font-size:12px;font-weight:600;text-align:left;}"
            f"QPushButton#ValeurBibliotheque:hover{{border-color:{PALETTE['accent']};}}")
        self.valeur.setVisible(not self._big_picture)

    def ouvrir_valeur(self) -> None:
        """La fenetre « Valeur estimee de ma bibliotheque »."""
        if self._valeur is None or not self._valeur.connue:
            return
        from ..widgets.fenetre_valeur import FenetreValeur
        FenetreValeur(self._valeur, self).exec()

    def set_possedes(self, games: list[Game]) -> None:
        """Jeux possedes non installes (affiches en grise, en fin de liste)."""
        self._possedes = list(games or [])
        self.voir_possedes.setVisible(bool(self._possedes))
        self.voir_possedes.setText(f"Non installes ({len(self._possedes)})")
        self.refresh()
        self.contenu_change.emit()

    def _possedes_changed(self, state: int) -> None:
        CONFIG.set("ui.voir_non_installes", bool(state))
        self.refresh()

    def set_featured(self, games, profiles: dict | None = None,
                     tunable: dict | None = None) -> None:
        """Jeux de la banniere d'accueil. Le premier est le dernier joue."""
        if isinstance(games, Game) or games is None:
            games = [games] if games is not None else []
        self._featured = list(games)
        self._profiles = dict(profiles or {})
        self._tunable = dict(tunable or {})
        self._update_hero()

    def _update_hero(self) -> None:
        """La banniere s'efface des qu'on cherche : elle repondrait a cote.

        Quand l'utilisateur filtre ou cherche, la page repond a une question
        precise ; une proposition sans rapport avec la recherche en cours
        n'aurait plus de sens en haut de l'ecran.
        """
        searching = bool(self.search.text().strip()) or \
            self._filter_sources is not None or self._filtre != "tous"
        show = bool(self._featured) and not searching \
            and not self._big_picture and bool(CONFIG.get("ui.hero", True))
        self.hero.set_games(self._featured if show else [],
                            self._profiles, self._tunable)

    def set_source_filter(self, sources: set[str] | None) -> None:
        # None : toutes les sources (aucun filtre, la banniere revient)
        self._filter_sources = set(sources) if sources is not None else None
        self.refresh()

    def set_filtre(self, cle: str) -> None:
        """Filtre rapide : tous, favoris, joues recemment, jamais lances."""
        self._filtre = cle if cle in self.filtres else "tous"
        self.filtres[self._filtre].setChecked(True)
        self.refresh()

    def tout_afficher(self) -> None:
        """Efface la recherche et le filtre rapide."""
        self._filtre = "tous"
        self.filtres["tous"].setChecked(True)
        if self.search.text():
            self.search.clear()               # relance refresh() apres la frappe
        self._frappe.stop()
        self.refresh()

    def chercher(self) -> None:
        """Ctrl+F : le curseur va dans la recherche."""
        self.search.setFocus()
        self.search.selectAll()

    def _famille_changed(self, state: int) -> None:
        CONFIG.set("ui.voir_steam_family", bool(state))
        self.refresh()

    def _missing_changed(self, state: int) -> None:
        CONFIG.set("ui.hide_missing", bool(state))
        self.refresh()

    def _sort_changed(self) -> None:
        CONFIG.set("ui.sort", self.sort.currentData())
        self.refresh()

    def _base(self) -> tuple[list[Game], list[Game]]:
        """(jeux installes, jeux possedes non installes) apres les filtres de
        sources et les cases, avant filtre rapide et recherche."""
        games = [g for g in self._games if not g.hidden or
                 CONFIG.get("ui.show_hidden", False)]
        if self._filter_sources is not None:
            games = [g for g in games if g.source in self._filter_sources]
        if self.hide_missing.isChecked():
            games = [g for g in games if not g.extra.get("missing")]
        possedes = []
        if getattr(self, "_possedes", None) and self.voir_possedes.isChecked():
            possedes = [g for g in self._possedes if not g.hidden or
                        CONFIG.get("ui.show_hidden", False)]
            if self._filter_sources is not None:
                possedes = [g for g in possedes if g.source in self._filter_sources]
        from ...steam_famille import de_la_famille, payants
        prix = payants(self._valeur)
        famille = [g for g in games + possedes if de_la_famille(g, prix)]
        self.voir_famille.setVisible(bool(famille))
        if famille:
            self.voir_famille.setText(f"Steam Family ({len(famille)})")
        if famille and not self.voir_famille.isChecked():
            exclus = {id(g) for g in famille}
            games = [g for g in games if id(g) not in exclus]
            possedes = [g for g in possedes if id(g) not in exclus]
        return games, possedes

    def visible_games(self) -> list[Game]:
        import time
        query = self.search.text().strip()
        games, possedes = self._base()
        # compteurs des filtres rapides, sur ce que les autres filtres laissent
        maintenant = time.time()
        for cle, texte, _bulle in FILTRES:
            n = sum(1 for g in games + possedes if du_filtre(g, cle, maintenant))
            self.filtres[cle].setText(f"{t(texte)}  {n}")
        if self._filtre != "tous":
            games = [g for g in games if du_filtre(g, self._filtre, maintenant)]
            possedes = [g for g in possedes if du_filtre(g, self._filtre, maintenant)]

        key = self.sort.currentData() or "title"
        keys = {
            "title": lambda g: g.title.lower(),
            "last_played": lambda g: -g.last_played,
            "playtime": lambda g: -g.total_play_seconds,
            "size": lambda g: -g.size_bytes,
            "recent": lambda g: -(g.last_updated or g.installed_at),
            "source": lambda g: (g.source, g.title.lower()),
        }
        games.sort(key=keys.get(key, keys["title"]))
        # les favoris remontent toujours en tete
        games.sort(key=lambda g: not g.favorite)
        # les jeux possedes non installes viennent apres les jeux installes
        possedes.sort(key=keys.get(key, keys["title"]))
        games = games + possedes
        if query:
            # recherche tolerante (fautes, sigles, phonetique) : le plus
            # pertinent d'abord, le tri choisi departage les ex aequo
            from ...core.recherche import classer
            games = classer(query, games, cle=lambda g: g.title)
        return games

    def refresh(self) -> None:
        """Met la grille d'accord avec les filtres, la recherche et le tri.

        Les tuiles sont gardees d'un rafraichissement a l'autre : filtrer
        (introuvables, sources, non installes, recherche) ne fait que montrer
        ou masquer des tuiles existantes et les remettre dans l'ordre. Une
        tuile n'est reconstruite que si ce qu'elle affiche a change (jaquette,
        titre, etat) ; c'etait la reconstruction de centaines de tuiles, avec
        relecture de chaque jaquette, qui prenait 10 a 15 secondes."""
        self._update_hero()
        games = self.visible_games()

        width = int(CONFIG.get("ui.card_width", 190))
        if width != self._largeur:
            self._oublier_tuiles()           # nouvelle taille : tout refaire
            self._largeur = width

        ordre: list[GameCard] = []
        montres: set[str] = set()
        for game in games:
            if game.uid in montres:
                continue
            montres.add(game.uid)
            card = self._tuile(game, width)
            ordre.append(card)

        # tuiles de jeux disparus (desinstalles, retires) : detruites
        connus = {g.uid for g in self._games} | {g.uid for g in self._possedes}
        for uid in [u for u in self._toutes if u not in connus]:
            self._detruire(uid)

        # une seule mise en page pour tout le lot (sinon chaque tuile montree
        # ou masquee relancait le calcul de toute la grille)
        self.grid.setEnabled(False)
        try:
            for uid, card in self._toutes.items():
                voulu = uid in montres
                if card.isHidden() == voulu:     # seulement ce qui change
                    card.setVisible(voulu)
            self.grid.ordonner(ordre)
        finally:
            self.grid.setEnabled(True)
        self.grid.invalidate()
        # ordre de tabulation = ordre visuel (clavier et manette)
        if [c.game.uid for c in ordre] != self._ordre_tab:
            for a, b in zip(ordre, ordre[1:]):
                QWidget.setTabOrder(a, b)
            self._ordre_tab = [c.game.uid for c in ordre]
        self._cards = {c.game.uid: c for c in ordre}

        total = len([g for g in self._games if not g.hidden])
        absent = len([g for g in self._games if g.extra.get("missing")])
        installes = len([g for g in games if not g.extra.get("non_installe")])
        morceaux = [f"{installes} sur {total} jeux"] if games else []
        if len(games) > installes:
            morceaux.append(f"{len(games) - installes} non installe(s)")
        if absent and self.hide_missing.isChecked():
            morceaux.append(f"{absent} introuvable(s)")
        self.count.setText("  ·  ".join(morceaux))
        connus = bool(self._games) or bool(self._possedes)
        self.empty.setVisible(not games and not connus)
        self.scroll.setVisible(bool(games) or connus)
        self._dire_aucun(not games and connus)

    def _dire_aucun(self, vide: bool) -> None:
        """Rien ne correspond a la recherche ou au filtre : on le dit, et on
        propose la suite (avant, la page restait simplement vide)."""
        self.aucun.setVisible(vide)
        self.holder.setVisible(not vide)
        if not vide:
            return
        cherche = self.search.text().strip()
        if cherche:
            self.aucun_texte.setText(
                f"Aucun jeu de votre bibliotheque ne correspond a « {cherche} ».")
            self.b_boutique.setText(f"Chercher « {cherche[:40]} » dans la Boutique")
        elif self._filtre == "favoris":
            self.aucun_texte.setText(
                "Aucun favori pour l'instant. Le menu ⋮ d'une tuile (ou la fiche d'un "
                "jeu) ajoute un jeu aux favoris : ils restent en tete de la bibliotheque.")
        elif self._filtre == "recents":
            self.aucun_texte.setText("Aucun jeu lance au cours des trente derniers jours.")
        elif self._filtre == "jamais":
            self.aucun_texte.setText("Tous vos jeux installes ont deja ete lances.")
        else:
            self.aucun_texte.setText("Aucun jeu ne correspond aux filtres choisis "
                                     "(sources, introuvables, non installes).")
        self.b_boutique.setVisible(bool(cherche) and not self._big_picture)
        self.b_tout_montrer.setVisible(bool(cherche) or self._filtre != "tous")

    def _tuile(self, game: Game, width: int) -> GameCard:
        """Tuile du jeu : l'existante si rien de visible n'a change."""
        sig = signature(game)
        card = self._toutes.get(game.uid)
        if card is not None and self._signatures.get(game.uid) == sig:
            card.game = game                 # meme affichage, objet a jour
            return card
        if card is not None:
            self._detruire(game.uid)
        card = GameCard(game, width)
        card.clicked.connect(self.game_selected.emit)
        card.play_requested.connect(self.game_play.emit)
        card.action_requested.connect(self.game_action.emit)
        card.setVisible(False)               # montree par refresh() si voulue
        self.grid.addWidget(card)
        self._toutes[game.uid] = card
        self._signatures[game.uid] = sig
        return card

    def _detruire(self, uid: str) -> None:
        card = self._toutes.pop(uid, None)
        self._signatures.pop(uid, None)
        self._cards.pop(uid, None)
        if card is None:
            return
        self.grid.removeWidget(card)
        card.blockSignals(True)
        card.hide()
        card.setParent(None)
        card.deleteLater()

    def _oublier_tuiles(self) -> None:
        for uid in list(self._toutes):
            self._detruire(uid)
        self._ordre_tab = []

    def update_card(self, game: Game) -> None:
        card = self._cards.get(game.uid)
        if card is not None:
            card.game = game
            card.refresh_art()
            self._signatures[game.uid] = signature(game)

    def set_progress(self, text: str, percent: int) -> None:
        visible = 0 <= percent < 100
        self.progress.setVisible(visible)
        if visible:
            self.progress.setValue(max(percent, 1))
        self.title.setText("Bibliotheque" if not visible else text)
        self.rescan.setEnabled(not visible)
