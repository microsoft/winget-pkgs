"""Navigation a la manette, sans dependance externe.

L'etat des manettes est lu directement par l'API XInput de Windows (celle
qu'utilisent les jeux). Les entrees sont converties en evenements clavier
Qt : la navigation au pad marche donc partout dans l'application, y compris
dans les listes et les boutons, sans code specifique a chaque page.

Aucune manette branchee : le module se met en veille et ne coute rien.
"""
from __future__ import annotations

import ctypes
import time
from ctypes import wintypes

from PySide6.QtCore import QObject, Qt, QTimer, Signal
from PySide6.QtGui import QKeyEvent
from PySide6.QtWidgets import QApplication

from ..core.logging_setup import get
from ..core.paths import is_windows

log = get("ui.manette")

# --- XInput ---------------------------------------------------------------
#: masques XInput (XINPUT_GAMEPAD_*). 15 octobre : A et B pointaient sur les
#: gachettes LB et RB (0x0100, 0x0200), et le vrai A (0x1000) ne faisait rien.
BUTTONS = {
    0x0001: "up", 0x0002: "down", 0x0004: "left", 0x0008: "right",
    0x0010: "start", 0x0020: "back",
    0x0040: "l3", 0x0080: "r3",
    0x0100: "lb", 0x0200: "rb",
    0x1000: "a", 0x2000: "b", 0x4000: "x", 0x8000: "y",
}
DEADZONE = 12000
REPEAT_FIRST = 0.42
REPEAT_NEXT = 0.12


class XINPUT_GAMEPAD(ctypes.Structure):
    _fields_ = [("wButtons", wintypes.WORD),
                ("bLeftTrigger", ctypes.c_ubyte),
                ("bRightTrigger", ctypes.c_ubyte),
                ("sThumbLX", ctypes.c_short),
                ("sThumbLY", ctypes.c_short),
                ("sThumbRX", ctypes.c_short),
                ("sThumbRY", ctypes.c_short)]


class XINPUT_STATE(ctypes.Structure):
    _fields_ = [("dwPacketNumber", wintypes.DWORD),
                ("Gamepad", XINPUT_GAMEPAD)]


def _load_xinput():
    if not is_windows():
        return None
    for name in ("XInput1_4.dll", "XInput1_3.dll", "XInput9_1_0.dll"):
        try:
            return ctypes.windll.LoadLibrary(name)   # type: ignore[attr-defined]
        except OSError:
            continue
    return None


#: correspondance bouton -> touche envoyee a l'interface
KEYMAP = {
    "up": (Qt.Key.Key_Up, Qt.KeyboardModifier.NoModifier),
    "down": (Qt.Key.Key_Down, Qt.KeyboardModifier.NoModifier),
    "left": (Qt.Key.Key_Backtab, Qt.KeyboardModifier.ShiftModifier),
    "right": (Qt.Key.Key_Tab, Qt.KeyboardModifier.NoModifier),
    "a": (Qt.Key.Key_Return, Qt.KeyboardModifier.NoModifier),
    "b": (Qt.Key.Key_Escape, Qt.KeyboardModifier.NoModifier),
}


class GamepadBridge(QObject):
    """Lit les manettes et transforme leurs entrees en touches."""

    connected = Signal(bool)
    action = Signal(str)          # start, y, x, lb, rb...

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.xinput = _load_xinput()
        self.available = self.xinput is not None
        self._pressed: dict[str, float] = {}
        self._was_connected = False
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._poll)

    def start(self, interval_ms: int = 60) -> bool:
        if not self.available:
            return False
        self._timer.start(interval_ms)
        return True

    def stop(self) -> None:
        self._timer.stop()
        self._pressed.clear()

    @staticmethod
    def au_premier_plan() -> bool:
        """Vrai quand une fenetre d'ORION est active (au premier plan)."""
        return QApplication.activeWindow() is not None

    # ------------------------------------------------------------------
    def _state(self):
        state = XINPUT_STATE()
        for index in range(4):
            if self.xinput.XInputGetState(index, ctypes.byref(state)) == 0:
                return state.Gamepad
        return None

    def _poll(self) -> None:
        pad = self._state()
        if pad is None:
            if self._was_connected:
                self._was_connected = False
                self.connected.emit(False)
            self._pressed.clear()
            return
        now = time.time()
        active: set[str] = set()

        for mask, name in BUTTONS.items():
            if pad.wButtons & mask:
                active.add(name)
        if pad.sThumbLY > DEADZONE:
            active.add("up")
        elif pad.sThumbLY < -DEADZONE:
            active.add("down")
        if pad.sThumbLX > DEADZONE:
            active.add("right")
        elif pad.sThumbLX < -DEADZONE:
            active.add("left")

        if not self._was_connected:
            # manette (re)connectee : les boutons deja tenus a cet instant ne
            # declenchent rien (15 octobre : la manette, lachee et reprise par
            # le jeu, revenait avec X ou Start encore enfonces et ORION
            # relancait le jeu six fois de suite, puis basculait en salon)
            self._was_connected = True
            self._pressed = {name: now for name in active}
            self.connected.emit(True)
            log.info("Manette detectee")
            return

        if not self.au_premier_plan():
            # ORION derriere un jeu ou une autre fenetre : la manette est au
            # jeu. Rien n'est emis, et les boutons tenus restent connus pour
            # ne pas « commencer » quand ORION revient devant.
            self._pressed = {name: self._pressed.get(name, now) for name in active}
            return

        for name in list(self._pressed):
            if name not in active:
                self._pressed.pop(name, None)

        for name in active:
            first = name not in self._pressed
            last = self._pressed.get(name, 0.0)
            delay = REPEAT_FIRST if (now - last) > REPEAT_NEXT * 3 else REPEAT_NEXT
            if first or (now - last) >= delay:
                self._pressed[name] = now
                self._emit(name, repeat=not first)

    def _emit(self, name: str, repeat: bool) -> None:
        if name in KEYMAP:
            key, modifier = KEYMAP[name]
            window = QApplication.activeWindow()
            target = QApplication.focusWidget() or window
            if target is not None:
                QApplication.postEvent(target, QKeyEvent(
                    QKeyEvent.Type.KeyPress, key, modifier))
                QApplication.postEvent(target, QKeyEvent(
                    QKeyEvent.Type.KeyRelease, key, modifier))
            return
        if not repeat:
            self.action.emit(name)
