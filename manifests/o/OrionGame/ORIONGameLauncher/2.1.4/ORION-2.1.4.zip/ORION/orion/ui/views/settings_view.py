"""Page reglages : comportement d'ORION, dossiers, extensions."""
from __future__ import annotations

import os
import subprocess
import webbrowser
from pathlib import Path

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (QCheckBox, QComboBox, QFileDialog, QFrame,
                               QHBoxLayout, QLabel, QLineEdit, QListWidget,
                               QPushButton, QSpinBox, QVBoxLayout, QWidget)

from ...ai.client import ORDER as AI_ORDER, PROVIDERS as AI_PROVIDERS
from ...core.config import CONFIG, DONATE_URL
from ...core.paths import (BACKUP_DIR, LOG_DIR, PLUGIN_USER_DIR,
                           RECIPE_USER_DIR, is_windows)
from ...version import APP_NAME, APP_VERSION
from ..defilement import ZoneDefilante


#: rubriques de la page, dans l'ordre d'affichage
RUBRIQUES = (
    ("jeux", "Jeux"),
    ("boutique", "Boutique et prix"),
    ("apparence", "Apparence"),
    ("sauvegardes", "Sauvegardes"),
    ("avance", "Avance"),
    ("orion", "ORION"),
)


#: au-dela, le libelle d'une case est pose a cote d'elle et passe a la ligne
LIBELLE_LONG = 70

#: la case du demarrage avec Windows, en tete de la page (2.1.2)
DEMARRAGE = "Lancer ORION au demarrage de Windows"
AIDE_DEMARRAGE = (
    "A l'ouverture de votre session, ORION s'ouvre reduit dans la barre des "
    "taches : la veille des prix et de vos jeux tourne sans que vous l'ouvriez. "
    "Il se coupe aussi dans le Gestionnaire des taches, onglet Applications "
    "de demarrage.")


class _Libelle(QLabel):
    """Libelle d'une case a cocher, sur plusieurs lignes ; un clic dessus
    coche la case, comme sur le texte d'une case ordinaire."""

    def __init__(self, texte: str, case: QCheckBox, parent=None) -> None:
        super().__init__(texte, parent)
        self._case = case
        self.setObjectName("LibelleCase")
        self.setWordWrap(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def mouseReleaseEvent(self, event) -> None:      # noqa: N802 (API Qt)
        if event.button() == Qt.MouseButton.LeftButton and self.rect().contains(
                event.position().toPoint()) and self._case.isEnabled():
            self._case.toggle()
        super().mouseReleaseEvent(event)


def _panel(title: str, hint: str = "") -> tuple[QFrame, QVBoxLayout]:
    f = QFrame()
    f.setObjectName("Panel")
    lay = QVBoxLayout(f)
    lay.setContentsMargins(18, 16, 18, 16)
    lay.setSpacing(9)
    t = QLabel(title)
    t.setObjectName("PanelTitle")
    lay.addWidget(t)
    if hint:
        h = QLabel(hint)
        h.setObjectName("Faint")
        h.setWordWrap(True)
        lay.addWidget(h)
    return f, lay


class SettingsView(QWidget):
    donate_changed = Signal()
    community_sync_requested = Signal()
    perf_tool_requested = Signal()
    rescan_requested = Signal()
    reload_plugins_requested = Signal()
    art_refresh_requested = Signal()
    background_changed = Signal()
    maj_demandee = Signal()
    version_visible_changee = Signal(bool)
    nouveautes_demandees = Signal()
    signaler_demande = Signal()
    possedes_change = Signal()
    frequence_envies_changee = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # -- en-tete fixe : titre, recherche, rubriques ------------------
        # la page compte une vingtaine de blocs : on y va par son nom
        # (recherche) ou par sa rubrique, sans tout faire defiler
        tete = QWidget()
        haut = QVBoxLayout(tete)
        haut.setContentsMargins(24, 18, 24, 10)
        haut.setSpacing(10)
        ligne = QHBoxLayout()
        ligne.setSpacing(10)
        t = QLabel("Reglages")
        t.setObjectName("PageTitle")
        ligne.addWidget(t)
        self.compte = QLabel("")
        self.compte.setObjectName("PageHint")
        ligne.addWidget(self.compte)
        ligne.addStretch(1)
        # en tete et toujours visible : se lit et se change sans chercher
        self.cb_demarrage = QCheckBox(DEMARRAGE)
        self.cb_demarrage.setObjectName("CaseDemarrage")
        self.cb_demarrage.setCursor(Qt.CursorShape.PointingHandCursor)
        self.cb_demarrage.setToolTip(AIDE_DEMARRAGE)
        self.cb_demarrage.setEnabled(False)      # l'etat est lu a l'affichage
        self.cb_demarrage.toggled.connect(self._demarrage_coche)
        ligne.addWidget(self.cb_demarrage)
        ligne.addSpacing(14)
        self.recherche = QLineEdit()
        self.recherche.setObjectName("Search")
        self.recherche.setPlaceholderText("Rechercher un reglage...")
        self.recherche.setClearButtonEnabled(True)
        self.recherche.setFixedWidth(260)
        self.recherche.textChanged.connect(self._filtrer)
        ligne.addWidget(self.recherche)
        haut.addLayout(ligne)
        self._barre_rubriques = QHBoxLayout()
        self._barre_rubriques.setSpacing(6)
        haut.addLayout(self._barre_rubriques)
        outer.addWidget(tete)

        scroll = ZoneDefilante()
        self.scroll = scroll
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        outer.addWidget(scroll, 1)
        body = QWidget()
        scroll.setWidget(body)
        root = QVBoxLayout(body)
        root.setContentsMargins(24, 6, 24, 24)
        root.setSpacing(16)
        self._root = root
        #: (rubrique, rang, panneau), dans l'ordre de creation
        self._rangement: list[tuple[str, int, QFrame]] = []

        # -- comportement --------------------------------------------
        p, lay = _panel(
            "Lancement des jeux",
            "ORION ne modifie jamais un fichier sans sauvegarde prealable.")
        self.cb_display = self._check(
            lay, "Appliquer la definition et la frequence au lancement",
            "optimizer.apply_display_mode")
        self.cb_restore = self._check(
            lay, "Remettre l'ecran comme avant a la fermeture du jeu",
            "optimizer.restore_display_after")
        self.cb_backup = self._check(
            lay, "Sauvegarder les fichiers de configuration avant modification",
            "optimizer.backup_before_write")
        self.cb_confirm = self._check(
            lay, "Demander confirmation avant d'ecrire dans un jeu",
            "optimizer.confirm_before_write")
        # 2.1.0 : plus de « profil par defaut » (un seul profil moteur ; le
        # choix se fait jeu par jeu dans la fiche, en trois cartes)
        self._ranger("jeux", 1, p)

        # -- detection ------------------------------------------------
        p, lay = _panel(
            "Detection des jeux",
            "Ajoutez ici les dossiers ou vous installez vos jeux hors plateforme.")
        self.folders = QListWidget()
        self.folders.setMaximumHeight(130)
        self.folders.addItems(CONFIG.get("scan.extra_folders", []) or [])
        lay.addWidget(self.folders)

        row = QHBoxLayout()
        add = QPushButton("Ajouter un dossier")
        add.clicked.connect(self._add_folder)
        row.addWidget(add)
        rem = QPushButton("Retirer")
        rem.setObjectName("Ghost")
        rem.clicked.connect(self._remove_folder)
        row.addWidget(rem)
        row.addStretch(1)
        scan = QPushButton("Relancer une analyse")
        scan.setObjectName("Ghost")
        scan.clicked.connect(self.rescan_requested.emit)
        row.addWidget(scan)
        lay.addLayout(row)

        size_row = QHBoxLayout()
        size_row.addWidget(QLabel("Taille minimale d'un executable candidat"))
        self.min_mb = QSpinBox()
        self.min_mb.setRange(0, 500)
        self.min_mb.setSuffix(" Mo")
        self.min_mb.setValue(int(CONFIG.get("scan.min_exe_mb", 1)))
        self.min_mb.valueChanged.connect(
            lambda v: CONFIG.set("scan.min_exe_mb", v))
        size_row.addWidget(self.min_mb)
        size_row.addStretch(1)
        lay.addLayout(size_row)
        self._ranger("jeux", 2, p)

        # -- visuels --------------------------------------------------
        p, lay = _panel(
            "Jaquettes",
            "Les visuels officiels Steam sont utilises sans cle. Une cle "
            "SteamGridDB (gratuite) ameliore la couverture des jeux hors Steam.")
        self.cb_art = self._check(lay, "Telecharger les jaquettes", "artwork.enabled")
        self.cb_video_auto = self._check(
            lay, "Lancer la bande-annonce toute seule dans la fiche d'un jeu (son coupe)",
            "videos.lecture_auto")
        row = QHBoxLayout()
        row.addWidget(QLabel("Cle SteamGridDB"))
        self.sgdb = QLineEdit(CONFIG.get("artwork.steamgriddb_key", ""))
        self.sgdb.setEchoMode(QLineEdit.EchoMode.Password)
        self.sgdb.setPlaceholderText("facultatif")
        self.sgdb.editingFinished.connect(
            lambda: CONFIG.set("artwork.steamgriddb_key", self.sgdb.text().strip()))
        row.addWidget(self.sgdb, 1)
        refresh = QPushButton("Recharger les visuels")
        refresh.setObjectName("Ghost")
        refresh.clicked.connect(self.art_refresh_requested.emit)
        row.addWidget(refresh)
        lay.addLayout(row)
        self._ranger("apparence", 2, p)

        # -- comparateur de prix --------------------------------------
        p, lay = _panel(
            "Prix et evaluations",
            "Les prix, les avis Steam et le comparateur complet (meilleure offre du "
            "moment sur plus de trente boutiques agreees, plus bas prix historique : "
            "donnees IsThereAnyDeal) s'affichent sans rien configurer. Une cle "
            "IsThereAnyDeal personnelle reste possible : ORION interroge alors "
            "IsThereAnyDeal directement, sans passer par son service.")
        self.cb_market = self._check(lay, "Afficher les prix et les avis",
                                     "market.enabled")
        self.cb_gris = self._check(
            lay, "Proposer aussi les revendeurs de cles Steam (Instant Gaming, "
            "Kinguin, Loaded) dans la Boutique, apres les boutiques officielles",
            "marche_gris.afficher")
        self.cb_traduire = self._check(
            lay, "Traduire en francais les actualites des jeux "
            "(service de traduction gratuit, textes publics uniquement)",
            "market.translate_news")
        row = QHBoxLayout()
        row.addWidget(QLabel("Cle IsThereAnyDeal"))
        self.itad = QLineEdit(CONFIG.get("market.itad_key", ""))
        self.itad.setEchoMode(QLineEdit.EchoMode.Password)
        self.itad.setPlaceholderText("facultatif")
        self.itad.editingFinished.connect(
            lambda: CONFIG.set("market.itad_key", self.itad.text().strip()))
        row.addWidget(self.itad, 1)
        get_key = QPushButton("Obtenir une cle")
        get_key.setObjectName("Ghost")
        get_key.clicked.connect(lambda: webbrowser.open(
            "https://isthereanydeal.com/apps/my/"))
        row.addWidget(get_key)
        row.addWidget(QLabel("Pays"))
        self.country = QComboBox()
        for code in ("FR", "BE", "CH", "CA", "LU", "US", "GB", "DE", "ES", "IT"):
            self.country.addItem(code, code)
        idx = self.country.findData(CONFIG.get("market.country", "FR"))
        self.country.setCurrentIndex(max(idx, 0))
        self.country.currentIndexChanged.connect(
            lambda: CONFIG.set("market.country", self.country.currentData()))
        row.addWidget(self.country)
        lay.addLayout(row)

        row = QHBoxLayout()
        row.addWidget(QLabel("Actualiser la Boutique toutes les"))
        self.boutique_min = QSpinBox()
        self.boutique_min.setRange(10, 60)
        self.boutique_min.setSuffix(" min")
        self.boutique_min.setValue(int(CONFIG.get("boutique.refresh_minutes", 12) or 12))
        self.boutique_min.valueChanged.connect(
            lambda v: CONFIG.set("boutique.refresh_minutes", int(v)))
        row.addWidget(self.boutique_min)
        row.addStretch(1)
        lay.addLayout(row)

        steps = QLabel(
            "Comment obtenir la cle : creez un compte sur isthereanydeal.com, "
            "ouvrez isthereanydeal.com/apps/my/, cliquez sur New application, "
            "nommez-la ORION, choisissez le type Desktop application, puis "
            "copiez la cle affichee et collez-la ci-dessus.")
        steps.setObjectName("Faint")
        steps.setWordWrap(True)
        lay.addWidget(steps)

        self.cb_affiliate = self._check(
            lay,
            "Soutenir ORION avec les liens partenaires des boutiques",
            "boutique.liens_partenaires")
        affiliate_note = QLabel(
            "Quand vous ouvrez un jeu sur une boutique partenaire, le lien porte "
            "l'identifiant d'ORION : votre prix ne change pas et une petite "
            "commission finance le projet. Les liens relayes par IsThereAnyDeal "
            "restent les leurs. Decochez pour des liens sans identifiant.")
        affiliate_note.setObjectName("Faint")
        affiliate_note.setWordWrap(True)
        lay.addWidget(affiliate_note)
        self._ranger("boutique", 1, p)

        # -- assistant IA ---------------------------------------------
        p, lay = _panel(
            "Assistant IA",
            "Entierement facultatif. Une fois une cle enregistree, ORION peut "
            "analyser un jeu inconnu et ecrire lui-meme la recette qui "
            "permettra de le regler automatiquement, expliquer une "
            "contre-performance, ou conseiller un achat.")

        row = QHBoxLayout()
        row.addWidget(QLabel("Fournisseur"))
        self.ai_provider = QComboBox()
        for pid in AI_ORDER:
            self.ai_provider.addItem(AI_PROVIDERS[pid].label, pid)
        idx = self.ai_provider.findData(CONFIG.get("ai.provider", "anthropic"))
        self.ai_provider.setCurrentIndex(max(idx, 0))
        self.ai_provider.currentIndexChanged.connect(self._ai_provider_changed)
        row.addWidget(self.ai_provider)

        row.addWidget(QLabel("Modele"))
        self.ai_model = QComboBox()
        self.ai_model.setEditable(True)
        self.ai_model.setMinimumWidth(220)
        self.ai_model.currentTextChanged.connect(
            lambda text: CONFIG.set("ai.model", text.strip()))
        row.addWidget(self.ai_model)
        row.addStretch(1)
        lay.addLayout(row)

        row = QHBoxLayout()
        row.addWidget(QLabel("Cle d'API"))
        self.ai_key = QLineEdit(CONFIG.get("ai.api_key", ""))
        self.ai_key.setEchoMode(QLineEdit.EchoMode.Password)
        self.ai_key.setPlaceholderText("collez la cle ici")
        self.ai_key.editingFinished.connect(
            lambda: CONFIG.set("ai.api_key", self.ai_key.text().strip()))
        row.addWidget(self.ai_key, 1)
        self.ai_get = QPushButton("Obtenir une cle")
        self.ai_get.setObjectName("Ghost")
        self.ai_get.clicked.connect(self._open_key_page)
        row.addWidget(self.ai_get)
        self.ai_test = QPushButton("Tester")
        self.ai_test.clicked.connect(self._test_ai)
        row.addWidget(self.ai_test)
        lay.addLayout(row)

        self.ai_tutorial = QLabel("")
        self.ai_tutorial.setObjectName("Faint")
        self.ai_tutorial.setWordWrap(True)
        lay.addWidget(self.ai_tutorial)

        self.ai_result = QLabel("")
        self.ai_result.setObjectName("Dim")
        self.ai_result.setWordWrap(True)
        lay.addWidget(self.ai_result)

        privacy = QLabel(
            "Ce qui est envoye : le modele de votre materiel, le nom du jeu et, "
            "pour la generation de recette, le contenu de ses fichiers de "
            "reglages. Rien d'autre ne quitte le PC, et la cle reste dans "
            "votre dossier de configuration local. Avec Ollama, tout reste "
            "sur la machine.")
        privacy.setObjectName("Faint")
        privacy.setWordWrap(True)
        lay.addWidget(privacy)
        self._ranger("avance", 1, p)
        self._ai_provider_changed()

        # -- interface ------------------------------------------------
        p, lay = _panel("Interface")
        row = QHBoxLayout()
        row.addWidget(QLabel("Largeur des tuiles"))
        self.card_width = QSpinBox()
        self.card_width.setRange(140, 320)
        self.card_width.setSingleStep(10)
        self.card_width.setSuffix(" px")
        self.card_width.setValue(int(CONFIG.get("ui.card_width", 190)))
        self.card_width.valueChanged.connect(
            lambda v: CONFIG.set("ui.card_width", v))
        row.addWidget(self.card_width)
        row.addStretch(1)
        lay.addLayout(row)
        self.cb_hidden = self._check(lay, "Afficher les jeux masques", "ui.show_hidden")
        self.cb_hero = self._check(
            lay, "Mettre en avant la derniere partie en haut de la "
            "bibliotheque", "ui.hero")
        self.cb_splash = self._check(
            lay, "Ecran de demarrage au lancement", "ui.splash")
        self._ranger("apparence", 1, p)

        # -- decor -----------------------------------------------------
        p, lay = _panel(
            "Fond d'ecran",
            "L'interface est posee sur une image. ORION en livre une "
            "cinquantaine et en change chaque jour ; vous pouvez mettre la "
            "votre. Le haut des pages porte une banniere qui suit les saisons.")
        row = QHBoxLayout()
        row.addWidget(QLabel("Image"))
        self.background = QLineEdit(str(CONFIG.get("ui.background", "")))
        self.background.setPlaceholderText("celles livrees avec ORION")
        self.background.editingFinished.connect(self._background_saved)
        row.addWidget(self.background, 1)
        pick = QPushButton("Parcourir")
        pick.setObjectName("Ghost")
        pick.clicked.connect(self._pick_background)
        row.addWidget(pick)
        reset = QPushButton("Celles d'ORION")
        reset.setObjectName("Ghost")
        reset.clicked.connect(lambda: (self.background.setText(""),
                                       self._background_saved()))
        row.addWidget(reset)
        lay.addLayout(row)

        row = QHBoxLayout()
        row.addWidget(QLabel("Assombrir l'image"))
        self.background_dim = QSpinBox()
        self.background_dim.setRange(0, 100)
        self.background_dim.setSuffix(" %")
        self.background_dim.setValue(int(CONFIG.get("ui.background_dim", 78)))
        self.background_dim.valueChanged.connect(self._dim_changed)
        row.addWidget(self.background_dim)
        hint = QLabel("plus la valeur est haute, plus le texte ressort")
        hint.setObjectName("Faint")
        row.addWidget(hint)
        row.addStretch(1)
        lay.addLayout(row)

        self.cb_fond_jour = self._check(
            lay, "Changer de fond chaque jour (sinon : la constellation d'Orion)",
            "ui.fond_du_jour")
        self.cb_fond_jour.stateChanged.connect(
            lambda _: self.background_changed.emit())
        self.cb_banniere = self._check(
            lay, "Banniere de saison en haut des pages",
            "ui.banniere_saison")
        self.cb_banniere.stateChanged.connect(
            lambda _: self.background_changed.emit())
        self.cb_dyn_bg = self._check(
            lay, "Utiliser la jaquette du jeu ouvert comme fond",
            "ui.dynamic_background")
        self.cb_dyn_bg.stateChanged.connect(
            lambda _: self.background_changed.emit())
        self._ranger("apparence", 3, p)

        # -- confort ---------------------------------------------------
        p, lay = _panel(
            "Manette et affichage salon",
            "La navigation a la manette fonctionne partout dans "
            "l'application : croix directionnelle pour se deplacer, A pour "
            "ouvrir, X pour lancer le jeu, B pour revenir, Start pour "
            "l'affichage salon (egalement disponible avec la touche F11).")
        self.cb_gamepad = self._check(lay, "Activer la navigation a la manette",
                                      "ui.gamepad")
        self._ranger("apparence", 4, p)

        # -- sauvegardes -----------------------------------------------
        p, lay = _panel(
            "Sauvegardes de parties",
            "ORION repere les dossiers de sauvegarde de chaque jeu et les "
            "archive au format zip, lisible sans ORION. Rien n'est archive "
            "sans que l'emplacement ait ete valide sur la fiche du jeu.")
        self.cb_saves = self._check(lay, "Gerer les sauvegardes de parties",
                                    "saves.enabled")
        self.cb_saves_auto = self._check(
            lay, "Archiver automatiquement a la fin d'une partie",
            "saves.auto_after_play")
        row = QHBoxLayout()
        row.addWidget(QLabel("Archives conservees par jeu"))
        self.saves_keep = QSpinBox()
        self.saves_keep.setRange(1, 100)
        self.saves_keep.setValue(int(CONFIG.get("saves.keep", 10)))
        self.saves_keep.valueChanged.connect(
            lambda v: CONFIG.set("saves.keep", v))
        row.addWidget(self.saves_keep)
        row.addStretch(1)
        lay.addLayout(row)

        row = QHBoxLayout()
        row.addWidget(QLabel("Copie dans le cloud"))
        self.nuage = QComboBox()
        self.nuage.setMinimumWidth(320)
        self._remplir_nuage()
        self.nuage.activated.connect(self._nuage_choisi)
        row.addWidget(self.nuage, 1)
        lay.addLayout(row)
        info = QLabel(
            "Chaque archive est aussi copiee dans le dossier OneDrive, Google "
            "Drive ou Dropbox choisi : c'est ce service, avec votre compte, qui "
            "l'envoie en ligne. Sur un autre PC, les archives de ce dossier "
            "apparaissent dans la fiche du jeu et se restaurent en un clic. "
            "ORION n'a aucun serveur et ne voit rien passer.")
        info.setObjectName("Faint")
        info.setWordWrap(True)
        lay.addWidget(info)
        self._ranger("sauvegardes", 1, p)

        # -- veille de prix --------------------------------------------
        p, lay = _panel(
            "Veille de prix",
            "ORION verifie le prix des jeux de votre liste d'envies et vous "
            "previent quand le seuil que vous avez fixe est atteint, ou quand "
            "un jeu suivi sans seuil baisse nettement.")
        self.cb_notify = self._check(
            lay, "Notification Windows quand un seuil est atteint ou qu'un prix baisse",
            "wishlist.notify")
        self.cb_baisses = self._check(
            lay, "Prevenir aussi des baisses d'au moins 10 % sur les jeux suivis sans seuil",
            "wishlist.alerte_baisse")
        row = QHBoxLayout()
        row.addWidget(QLabel("Verifier les prix toutes les"))
        self.wish_hours = QSpinBox()
        self.wish_hours.setRange(1, 168)
        self.wish_hours.setSuffix(" heures")
        self.wish_hours.setValue(int(CONFIG.get("wishlist.check_hours", 6)))
        self.wish_hours.valueChanged.connect(self._frequence_envies)
        row.addWidget(self.wish_hours)
        row.addStretch(1)
        lay.addLayout(row)
        self._ranger("boutique", 2, p)

        # -- jeux gratuits ---------------------------------------------
        p, lay = _panel(
            "Jeux gratuits",
            "ORION cherche en ligne ce qui est offert en ce moment : cadeaux "
            "des boutiques, week-ends gratuits, jeux gratuits pour toujours. "
            "Il distingue ce qui se garde a vie de ce qui s'arrete, et ne "
            "propose une desinstallation que pour les acces temporaires.")
        self.cb_free = self._check(
            lay, "Surveiller les jeux gratuits", "free.enabled")
        self.cb_free_notify = self._check(
            lay, "Prevenir quand une nouvelle offre apparait", "free.notify")
        self.cb_free_demos = self._check(
            lay, "Ecarter les demos, playtests et betas d'essai",
            "free.hide_demos")
        row = QHBoxLayout()
        row.addWidget(QLabel("Chercher toutes les"))
        self.free_hours = QSpinBox()
        self.free_hours.setRange(1, 72)
        self.free_hours.setSuffix(" heures")
        self.free_hours.setValue(int(CONFIG.get("free.refresh_hours", 6)))
        self.free_hours.valueChanged.connect(
            lambda v: CONFIG.set("free.refresh_hours", v))
        row.addWidget(self.free_hours)
        row.addSpacing(18)
        # le pays est celui des prix (Reglages > Prix) : un seul reglage
        row.addStretch(1)
        lay.addLayout(row)
        note = QLabel(
            "Sources interrogees : Epic Games Store, agregateur de cadeaux et "
            "de week-ends gratuits, mises en avant Steam, catalogue GOG. "
            "Toutes sont publiques et gratuites. Une source supplementaire "
            "s'ajoute en deposant un fichier dans le dossier "
            "plugins/freebies.")
        note.setObjectName("Faint")
        note.setWordWrap(True)
        lay.addWidget(note)
        self._ranger("boutique", 3, p)

        # -- mesure des performances -----------------------------------
        p, lay = _panel(
            "Mesure des performances",
            "ORION peut mesurer les images par seconde reellement affichees "
            "pendant vos parties, puis proposer des ajustements chiffres. "
            "L'outil utilise est PresentMon (Intel, gratuit) : ORION le "
            "telecharge tout seul. Windows reserve cette mesure aux "
            "administrateurs et au groupe « Utilisateurs du journal de "
            "performances » ; ORION ne demande jamais les droits "
            "d'administrateur (marche a suivre : Tutos > Mesurer les images "
            "par seconde).")
        self.cb_perf = self._check(
            lay, "Mesurer les images par seconde pendant les parties",
            "perf.enabled")
        row = QHBoxLayout()
        self.perf_tool_btn = QPushButton("Installer l'outil de mesure")
        self.perf_tool_btn.clicked.connect(self.perf_tool_requested.emit)
        row.addWidget(self.perf_tool_btn)
        self.perf_tool_state = QLabel("")
        self.perf_tool_state.setObjectName("Faint")
        self.perf_tool_state.setWordWrap(True)
        row.addWidget(self.perf_tool_state, 1)
        lay.addLayout(row)
        self._ranger("jeux", 6, p)

        # -- recettes partagees ----------------------------------------
        p, lay = _panel(
            "Recettes partagees",
            "ORION telecharge les recettes de reglages publiees par les autres "
            "utilisateurs : chaque jeu appris par quelqu'un devient reglable "
            "pour tout le monde. Vos propres recettes ne sont jamais envoyees "
            "sans que vous le demandiez.")
        self.cb_community = self._check(
            lay, "Recuperer automatiquement les recettes partagees",
            "community.enabled")
        row = QHBoxLayout()
        row.addWidget(QLabel("Depot"))
        self.community_url = QLineEdit(CONFIG.get("community.index_url", ""))
        self.community_url.setPlaceholderText(
            "https://.../index.json")
        self.community_url.editingFinished.connect(
            lambda: CONFIG.set("community.index_url",
                               self.community_url.text().strip()))
        row.addWidget(self.community_url, 1)
        sync = QPushButton("Synchroniser")
        sync.clicked.connect(self.community_sync_requested.emit)
        row.addWidget(sync)
        lay.addLayout(row)

        row = QHBoxLayout()
        row.addWidget(QLabel("Votre pseudo (pour signer vos partages)"))
        self.community_author = QLineEdit(CONFIG.get("community.author", ""))
        self.community_author.setPlaceholderText("facultatif")
        self.community_author.editingFinished.connect(
            lambda: CONFIG.set("community.author",
                               self.community_author.text().strip()))
        row.addWidget(self.community_author, 1)
        lay.addLayout(row)

        self.community_state = QLabel("")
        self.community_state.setObjectName("Faint")
        self.community_state.setWordWrap(True)
        lay.addWidget(self.community_state)
        self._ranger("avance", 2, p)

        # -- soutien ---------------------------------------------------
        p, lay = _panel(
            "Soutien au projet",
            "ORION est gratuit, sans publicite et sans compte. Il vit de deux "
            "choses seulement : les dons libres (bouton de la barre laterale) "
            "et des liens partenaires vers certaines boutiques, qui ne changent "
            "ni le prix que vous payez ni l'ordre des offres. Aucune "
            "contrepartie ne vous est demandee.")
        row = QHBoxLayout()
        row.addWidget(QLabel("Lien officiel"))
        lien = QLabel(DONATE_URL)
        lien.setObjectName("Dim")
        lien.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextSelectableByMouse)
        row.addWidget(lien, 1)
        test = QPushButton("Ouvrir")
        test.setObjectName("Ghost")
        test.clicked.connect(lambda: webbrowser.open(DONATE_URL))
        row.addWidget(test)
        lay.addLayout(row)

        self.cb_donate = self._check(lay, "Afficher le bouton de soutien",
                                     "support.show_button")
        self.cb_donate.stateChanged.connect(lambda _: self.donate_changed.emit())

        howto = QLabel(
            "Ce lien n'est pas modifiable depuis l'application : ainsi, "
            "personne ne peut detourner les dons vers un autre compte a votre "
            "insu. Vous pouvez masquer le bouton si vous le souhaitez.")
        howto.setObjectName("Faint")
        howto.setWordWrap(True)
        lay.addWidget(howto)
        self._ranger("orion", 3, p)

        # -- veille ----------------------------------------------------
        p, lay = _panel(
            "Veille automatique",
            "ORION verifie regulierement si un jeu vient d'etre installe, et "
            "l'ajoute avec sa jaquette sans intervention.")
        self.cb_watch = self._check(lay, "Detecter automatiquement les "
                                    "nouvelles installations", "scan.watch_enabled")
        row = QHBoxLayout()
        row.addWidget(QLabel("Verifier toutes les"))
        self.watch_min = QSpinBox()
        self.watch_min.setRange(0, 240)
        self.watch_min.setSuffix(" minutes")
        self.watch_min.setSpecialValueText("jamais")
        self.watch_min.setValue(int(CONFIG.get("scan.watch_interval_min", 10)))
        self.watch_min.valueChanged.connect(
            lambda v: CONFIG.set("scan.watch_interval_min", v))
        row.addWidget(self.watch_min)
        row.addStretch(1)
        lay.addLayout(row)
        self._ranger("jeux", 3, p)

        # -- extensions -----------------------------------------------
        p, lay = _panel(
            "Extensions",
            "ORION est modulaire : un fichier Python depose dans le dossier des "
            "extensions ajoute une source de jeux, un fournisseur de jaquettes ou "
            "un format de reglages. Un fichier JSON depose dans le dossier des "
            "recettes apprend a ORION a regler un jeu de plus.")
        for label, folder in (("Extensions", PLUGIN_USER_DIR),
                              ("Recettes de jeux", RECIPE_USER_DIR),
                              ("Sauvegardes", BACKUP_DIR),
                              ("Journaux", LOG_DIR)):
            row = QHBoxLayout()
            k = QLabel(label)
            k.setObjectName("Key")
            k.setFixedWidth(150)
            row.addWidget(k)
            v = QLabel(str(folder))
            v.setObjectName("Faint")
            v.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            row.addWidget(v, 1)
            btn = QPushButton("Ouvrir")
            btn.setObjectName("Ghost")
            btn.setFixedWidth(90)
            btn.clicked.connect(lambda _=False, f=folder: self._open(f))
            row.addWidget(btn)
            lay.addLayout(row)

        row = QHBoxLayout()
        reload_btn = QPushButton("Recharger les extensions et recettes")
        reload_btn.clicked.connect(self.reload_plugins_requested.emit)
        row.addWidget(reload_btn)
        row.addStretch(1)
        lay.addLayout(row)
        self._ranger("avance", 3, p)

        # -- mises a jour ------------------------------------------------
        p, lay = _panel(
            "Mises a jour",
            "Des ameliorations arrivent "
            "regulierement. La mise a jour se telecharge depuis la page "
            "officielle du projet, son empreinte est verifiee, puis ORION "
            "redemarre tout seul. Vos donnees ne sont jamais touchees.")
        from ... import maj
        store = maj.depuis_store()
        self.cb_maj = self._check(lay, "Verifier automatiquement les nouvelles versions",
                                  "maj.auto")
        self.cb_version = self._check(
            lay, "Afficher la version en bas a gauche et signaler les nouvelles "
            "versions (un clic installe la mise a jour et redemarre ORION)",
            "maj.afficher_version")
        self.cb_version.toggled.connect(self.version_visible_changee.emit)
        self.maj_etat = QLabel(f"Version installee : {APP_VERSION}")
        self.maj_etat.setObjectName("Dim")
        lay.addWidget(self.maj_etat)
        row = QHBoxLayout()
        row.setSpacing(10)
        b = QPushButton("Rechercher une mise a jour")
        b.clicked.connect(self.maj_demandee.emit)
        row.addWidget(b)
        if store:      # version du Microsoft Store : il s'occupe des mises a jour
            self.cb_maj.hide()
            self.cb_version.hide()
            b.hide()
            self.maj_etat.setText("Les mises a jour passent par le Microsoft Store")
        b = QPushButton("Nouveautes")
        b.setObjectName("Ghost")
        b.clicked.connect(self.nouveautes_demandees.emit)
        row.addWidget(b)
        b = QPushButton("Signaler un probleme")
        b.setObjectName("Ghost")
        b.clicked.connect(self.signaler_demande.emit)
        row.addWidget(b)
        row.addStretch(1)
        lay.addLayout(row)
        self._ranger("orion", 1, p)

        # -- donnees partagees --------------------------------------------
        # un bloc a lui (2.0) : ce choix etait range sous « Mises a jour »,
        # ou personne ne le cherche
        p, lay = _panel(
            "Donnees partagees",
            "Rien de personnel ne quitte ce PC. Vous decidez ici si vos mesures "
            "aident les autres joueurs, et si ORION peut vous compter "
            "anonymement.")
        self.cb_partage = self._check(
            lay, "Partager mes mesures de performances, sans rien de personnel "
            "(jeu, carte graphique, processeur, definition, images par seconde), "
            "etre compte anonymement (ouverture d'ORION, pages utilisees, "
            "nom de la boutique ouverte, pays et region) et envoyer a la "
            "fermeture un bilan de fluidite (accrochages de l'affichage et "
            "fonction d'ORION en cause, temps de demarrage, erreurs du journal), "
            "et proposer aux autres joueurs les niveaux des jeux que vous apprenez a ORION "
            "(noms et valeurs de reglages)",
            "partage.actif")
        from ... import partage as _partage
        self.cb_partage.stateChanged.connect(
            lambda _e: (CONFIG.set("partage.demande", True),
                        CONFIG.set("partage.question", _partage.QUESTION)))
        self._ranger("orion", 2, p)

        # -- pendant une partie ------------------------------------------
        p, lay = _panel(
            "Pendant une partie",
            "ORION repere les jeux en cours, meme lances depuis Steam, Epic ou "
            "un raccourci, en lisant simplement la liste des programmes ouverts "
            "(rien n'est injecte dans le jeu).")
        self._check(lay, "Mode discret : suspendre les taches de fond et baisser "
                    "la priorite d'ORION pendant une partie", "jeu.discret")
        self._check(lay, "Compter aussi le temps de jeu des parties lancees hors d'ORION",
                    "jeu.compter_hors_orion")
        self._check(lay, "Reduire ORION quand il lance un jeu (il revient a la fin de la partie)",
                    "jeu.reduire")
        self._ranger("jeux", 5, p)

        # -- jeux possedes -----------------------------------------------
        p, lay = _panel(
            "Jeux possedes non installes",
            "Lus sur ce PC (Steam, Epic Games, GOG Galaxy), sans compte ni cle. "
            "Ils apparaissent en grise a la fin de la bibliotheque ; un clic "
            "ouvre leur installation dans la bonne plateforme.")
        cb = self._check(lay, "Afficher les jeux possedes non installes",
                         "bibliotheque.non_installes")
        cb.stateChanged.connect(lambda _: self.possedes_change.emit())
        self._ranger("jeux", 4, p)

        # -- langue -------------------------------------------------------
        p, lay = _panel("Langue / Language")
        row = QHBoxLayout()
        row.addWidget(QLabel("Langue de l'interface"))
        self.langue = QComboBox()
        self.langue.addItem("Francais", "fr")
        self.langue.addItem("English", "en")
        self.langue.setCurrentIndex(1 if CONFIG.get("langue", "fr") == "en" else 0)
        self.langue.currentIndexChanged.connect(self._langue_changee)
        row.addWidget(self.langue)
        row.addStretch(1)
        lay.addLayout(row)
        self.langue_info = QLabel("Redemarrez ORION pour appliquer le changement. "
                                  "/ Restart ORION to apply.")
        self.langue_info.setObjectName("Faint")
        self.langue_info.hide()
        lay.addWidget(self.langue_info)
        self._ranger("apparence", 5, p)

        # -- a propos ---------------------------------------------------
        p, lay = _panel(f"A propos d'{APP_NAME}")
        about = QLabel(
            f"{APP_NAME} {APP_VERSION} — launcher de jeux pour "
            "Windows. Des mises a jour arrivent regulierement.\n\n"
            "Gratuit, sans publicite et sans compte. Rien n'est envoye sans "
            "votre accord. Aucun "
            "reglage n'est ecrit dans un jeu sans apercu, confirmation et "
            "sauvegarde prealable.")
        about.setObjectName("Dim")
        about.setWordWrap(True)
        lay.addWidget(about)

        made = QLabel(
            "ORION lit votre PC et vous dit quoi jouer, avec quels reglages, a quel prix.\n\n"
            "Un projet vibe code : ORION est developpe en dialoguant, en "
            "francais, avec Claude (Anthropic). L'auteur fixe le cap et essaie "
            "chaque version ; Claude propose l'architecture, ecrit, teste et "
            "corrige le code.\n\n"
            "Technologies : Python 3.13 et PySide6 (Qt 6) pour l'interface ; "
            "ctypes pour les API Windows natives (user32 pour les ecrans, "
            "XInput pour la manette, winreg pour la base de registre) ; "
            "requests et psutil ; SQLite pour la base locale ; API publiques "
            "Steam et GOG pour les "
            "jaquettes, les prix et les actualites ; IsThereAnyDeal et "
            "SteamGridDB en option ; PresentMon (Intel) pour la mesure des "
            "images par seconde ; base publique des identifiants PCI et USB "
            "(pci.ids, usb.ids) pour nommer les fabricants ; assistants IA au "
            "choix (Claude, ChatGPT, Gemini, Mistral, ou Ollama en local).\n\n"
            "Site officiel : orion-launcher.com")
        made.setObjectName("Faint")
        made.setWordWrap(True)
        lay.addWidget(made)

        row = QHBoxLayout()
        row.setSpacing(10)
        donate = QPushButton("Soutenir le projet")
        donate.clicked.connect(lambda: webbrowser.open(DONATE_URL))
        row.addWidget(donate)

        repo = QPushButton("Depot des recettes")
        repo.setObjectName("Ghost")
        repo.clicked.connect(lambda: webbrowser.open(
            str(CONFIG.get("community.index_url") or "")
            .replace("raw.githubusercontent.com", "github.com")
            .replace("/main/index.json", "")))
        row.addWidget(repo)

        logs = QPushButton("Journal de l'application")
        logs.setObjectName("Ghost")
        logs.clicked.connect(lambda: self._open(LOG_DIR))
        row.addWidget(logs)
        row.addStretch(1)
        lay.addLayout(row)
        self._ranger("orion", 4, p)

        self._assembler()

    # ------------------------------------------------------------------
    # Rubriques et recherche
    # ------------------------------------------------------------------
    def _ranger(self, rubrique: str, rang: int, panneau: QFrame) -> None:
        self._rangement.append((rubrique, rang, panneau))

    def _assembler(self) -> None:
        """Pose les blocs rubrique par rubrique, avec un titre et un bouton
        d'acces par rubrique."""
        self._titres: dict[str, QLabel] = {}
        self._panneaux: dict[str, list[QFrame]] = {}
        self._boutons: dict[str, QPushButton] = {}
        for cle, nom in RUBRIQUES:
            blocs = [p for r, _rang, p in sorted(
                (x for x in self._rangement if x[0] == cle), key=lambda x: x[1])]
            if not blocs:
                continue
            titre = QLabel(nom)
            titre.setObjectName("SectionTitle")
            self._root.addWidget(titre)
            self._titres[cle] = titre
            self._panneaux[cle] = blocs
            for p in blocs:
                self._root.addWidget(p)
            b = QPushButton(nom)
            b.setObjectName("Chip")
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.clicked.connect(lambda _=False, c=cle: self.aller_a(c))
            self._barre_rubriques.addWidget(b)
            self._boutons[cle] = b
        self._barre_rubriques.addStretch(1)
        self.aucun = QLabel("")
        self.aucun.setObjectName("Dim")
        self.aucun.setWordWrap(True)
        self.aucun.hide()
        self._root.addWidget(self.aucun)
        self._root.addStretch(1)

    def aller_a(self, rubrique: str) -> None:
        """Fait defiler jusqu'a la rubrique (la recherche est effacee : elle
        pourrait masquer la rubrique demandee)."""
        if self.recherche.text():
            self.recherche.clear()
        titre = self._titres.get(rubrique)
        if titre is not None:
            self._root.activate()             # positions a jour apres un filtre
            self.scroll.verticalScrollBar().setValue(max(0, titre.y() - 6))

    @staticmethod
    def _textes(panneau: QFrame) -> set[str]:
        """Les mots qui se lisent dans un bloc (titre, explications, cases,
        boutons, listes), tels qu'affiches : la recherche suit la langue de
        l'interface."""
        from ...core.recherche import mots
        morceaux: list[str] = []
        for w in panneau.findChildren(QWidget):
            if isinstance(w, (QLabel, QCheckBox, QPushButton)):
                morceaux.append(w.text())
            elif isinstance(w, QComboBox):
                morceaux.extend(w.itemText(i) for i in range(w.count()))
            elif isinstance(w, QLineEdit) and w.echoMode() == QLineEdit.EchoMode.Normal:
                morceaux.append(w.placeholderText())
            elif isinstance(w, QSpinBox):
                morceaux.append(w.suffix())
        return set(mots(" ".join(m for m in morceaux if m)))

    def correspondants(self, texte: str) -> list[QFrame]:
        """Blocs qui contiennent tous les mots cherches. Un mot cherche peut
        etre le debut d'un mot du bloc (« sauveg » trouve « sauvegardes »),
        jamais son milieu (« ia » ne trouve pas « partenaires »)."""
        from ...core.recherche import mots
        cherches = mots(texte)
        tous = [p for blocs in self._panneaux.values() for p in blocs]
        if not cherches:
            return tous
        gardes = []
        for p in tous:
            lus = self._textes(p)
            if all(any(m.startswith(c) for m in lus) for c in cherches):
                gardes.append(p)
        return gardes

    def _filtrer(self, texte: str = "") -> None:
        gardes = set(self.correspondants(texte))
        for cle, blocs in self._panneaux.items():
            visibles = 0
            for p in blocs:
                montre = p in gardes
                if p.isHidden() == montre:
                    p.setVisible(montre)
                visibles += montre
            self._titres[cle].setVisible(bool(visibles))
        cherche = texte.strip()
        self.aucun.setVisible(bool(cherche) and not gardes)
        if cherche and not gardes:
            self.aucun.setText(f"Aucun reglage ne correspond a « {cherche} ». Essayez un "
                               "autre mot (« prix », « manette », « sauvegarde »...).")
        self.compte.setText(
            (f"{len(gardes)} bloc(s) trouve(s)" if gardes else "") if cherche else "")
        self.scroll.verticalScrollBar().setValue(0)

    def chercher(self) -> None:
        """Ctrl+F : le curseur va dans la recherche."""
        self.recherche.setFocus()
        self.recherche.selectAll()

    # -- demarrage avec Windows -------------------------------------------
    def showEvent(self, event) -> None:              # noqa: N802 (API Qt)
        super().showEvent(event)
        self.lire_demarrage()        # coupe ailleurs (Gestionnaire des taches) : a jour

    def lire_demarrage(self) -> None:
        """L'etat se lit hors du fil de l'interface (le Store passe par
        Windows) ; la case reste grisee le temps de la reponse."""
        from ... import demarrage
        from ...core.tasks import Task
        t = Task(demarrage.etat)
        t.signals.finished.connect(self._poser_demarrage)
        t.start()

    def _poser_demarrage(self, etat) -> None:
        from ...i18n import t
        case = self.cb_demarrage
        case.blockSignals(True)
        case.setChecked(bool(etat.actif))
        case.blockSignals(False)
        case.setEnabled(bool(etat.modifiable))
        case.setToolTip(t(AIDE_DEMARRAGE) + (f"\n\n{t(etat.note)}" if etat.note else ""))

    def _demarrage_coche(self, actif: bool) -> None:
        from ... import demarrage
        from ...core.tasks import Task
        self.cb_demarrage.setEnabled(False)
        tache = Task(demarrage.regler, bool(actif))
        tache.signals.finished.connect(self._demarrage_regle)
        tache.signals.failed.connect(lambda _m: self.lire_demarrage())
        tache.start()

    def _demarrage_regle(self, resultat) -> None:
        reussi, etat = resultat
        self._poser_demarrage(etat)
        if not reussi:
            self.expliquer_demarrage(etat)

    def expliquer_demarrage(self, etat) -> None:
        """Windows a dit non : pourquoi, et ou le regler soi-meme."""
        from PySide6.QtWidgets import QMessageBox

        from ... import demarrage
        boite = QMessageBox(self)
        boite.setIcon(QMessageBox.Icon.Information)
        boite.setWindowTitle(APP_NAME)
        boite.setText(etat.note or "Windows a refuse le changement.")
        ouvrir = None
        if etat.parametres:
            ouvrir = boite.addButton("Ouvrir les Parametres de Windows",
                                     QMessageBox.ButtonRole.AcceptRole)
        boite.addButton("Fermer", QMessageBox.ButtonRole.RejectRole)
        boite.exec()
        if ouvrir is not None and boite.clickedButton() is ouvrir:
            demarrage.ouvrir_parametres()

    # ------------------------------------------------------------------
    def set_maj_etat(self, pub) -> None:
        if pub is None or not getattr(pub, "version", ""):
            return
        if pub.disponible:
            self.maj_etat.setText(f"Version installee : {APP_VERSION}  ·  "
                                  f"nouvelle version disponible : {pub.version}")
        else:
            self.maj_etat.setText(f"Version installee : {APP_VERSION}  ·  a jour")

    def _frequence_envies(self, heures: int) -> None:
        CONFIG.set("wishlist.check_hours", int(heures))
        self.frequence_envies_changee.emit()

    def _langue_changee(self) -> None:
        CONFIG.set("langue", self.langue.currentData() or "fr")
        self.langue_info.show()

    def _remplir_nuage(self) -> None:
        from ...nuage import emplacements
        self.nuage.blockSignals(True)
        self.nuage.clear()
        self.nuage.addItem("Desactivee", "")
        actuel = CONFIG.get("saves.cloud_dir", "") or ""
        vus = False
        for e in emplacements():
            self.nuage.addItem(e.libelle, e.chemin)
            if os.path.normcase(e.chemin) == os.path.normcase(actuel):
                vus = True
        if actuel and not vus:
            self.nuage.addItem(f"Dossier choisi — {actuel}", actuel)
        self.nuage.addItem("Choisir un autre dossier...", "__choisir__")
        for i in range(self.nuage.count()):
            if self.nuage.itemData(i) == actuel:
                self.nuage.setCurrentIndex(i)
        self.nuage.blockSignals(False)

    def _nuage_choisi(self) -> None:
        valeur = self.nuage.currentData() or ""
        if valeur == "__choisir__":
            dossier = QFileDialog.getExistingDirectory(
                self, "Dossier synchronise (OneDrive, Google Drive, Dropbox...)")
            valeur = dossier or (CONFIG.get("saves.cloud_dir", "") or "")
        CONFIG.set("saves.cloud_dir", valeur)
        self._remplir_nuage()

    def _check(self, layout, label: str, path: str) -> QCheckBox:
        """Case a cocher liee a un reglage. Un libelle long passe a la ligne :
        une case Qt ne coupe pas son texte, et une seule case de 1 600 points
        de large elargissait toute la page au-dela de la fenetre (les boutons
        de droite de chaque bloc sortaient de l'ecran)."""
        long = len(label) > LIBELLE_LONG
        box = QCheckBox("" if long else label)
        box.setChecked(bool(CONFIG.get(path, False)))
        box.stateChanged.connect(
            lambda state, p=path: CONFIG.set(p, bool(state)))
        if not long:
            layout.addWidget(box)
            return box
        box.setAccessibleName(label)
        ligne = QHBoxLayout()
        ligne.setContentsMargins(0, 0, 0, 0)
        ligne.setSpacing(1)                # la case porte deja son ecart (theme)
        ligne.addWidget(box, 0, Qt.AlignmentFlag.AlignTop)
        ligne.addWidget(_Libelle(label, box), 1)
        layout.addLayout(ligne)
        return box

    def set_perf_tool_state(self, text: str, busy: bool = False) -> None:
        self.perf_tool_state.setText(text)
        self.perf_tool_btn.setEnabled(not busy)

    def set_community_state(self, text: str) -> None:
        self.community_state.setText(text)

    def _ai_provider_changed(self) -> None:
        pid = self.ai_provider.currentData() or "anthropic"
        CONFIG.set("ai.provider", pid)
        provider = AI_PROVIDERS[pid]

        self.ai_model.blockSignals(True)
        self.ai_model.clear()
        self.ai_model.addItems(provider.models)
        current = CONFIG.get("ai.model") or provider.default_model
        if current not in provider.models:
            current = provider.default_model
        self.ai_model.setCurrentText(current)
        self.ai_model.blockSignals(False)
        CONFIG.set("ai.model", current)

        self.ai_key.setEnabled(provider.needs_key)
        self.ai_key.setPlaceholderText(
            "collez la cle ici" if provider.needs_key
            else "aucune cle necessaire avec Ollama")
        self.ai_tutorial.setText(provider.tutorial)
        self.ai_result.setText("")

    def _open_key_page(self) -> None:
        pid = self.ai_provider.currentData() or "anthropic"
        webbrowser.open(AI_PROVIDERS[pid].key_url)

    def _test_ai(self) -> None:
        from ...ai.client import AIClient
        from ...core.tasks import Task

        CONFIG.set("ai.api_key", self.ai_key.text().strip())
        CONFIG.set("ai.model", self.ai_model.currentText().strip())
        self.ai_result.setText("Test en cours...")
        self.ai_test.setEnabled(False)

        task = Task(AIClient().test)
        task.signals.finished.connect(self._test_done)
        task.signals.failed.connect(
            lambda err: self._test_done((False, err)))
        task.start()

    def _test_done(self, result) -> None:
        ok, text = result if isinstance(result, tuple) else (False, str(result))
        self.ai_result.setText(text)
        self.ai_test.setEnabled(True)
        CONFIG.set("ai.enabled", bool(ok))

    def _add_folder(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Choisir un dossier de jeux")
        if not folder:
            return
        current = list(CONFIG.get("scan.extra_folders", []) or [])
        if folder not in current:
            current.append(folder)
            CONFIG.set("scan.extra_folders", current)
            self.folders.addItem(folder)

    def _remove_folder(self) -> None:
        item = self.folders.currentItem()
        if item is None:
            return
        current = [f for f in (CONFIG.get("scan.extra_folders", []) or [])
                   if f != item.text()]
        CONFIG.set("scan.extra_folders", current)
        self.folders.takeItem(self.folders.row(item))

    @staticmethod
    def _open(folder: Path) -> None:
        try:
            folder.mkdir(parents=True, exist_ok=True)
            if is_windows():
                from ...core.lancement import startfile_propre
                startfile_propre(str(folder))
            else:
                subprocess.Popen(["xdg-open", str(folder)])
        except Exception:
            pass


    # ------------------------------------------------------------------
    def _background_saved(self) -> None:
        CONFIG.set("ui.background", self.background.text().strip())
        self.background_changed.emit()

    def _dim_changed(self, value: int) -> None:
        CONFIG.set("ui.background_dim", value)
        self.background_changed.emit()

    def _pick_background(self) -> None:
        from PySide6.QtWidgets import QFileDialog
        chosen, _ = QFileDialog.getOpenFileName(
            self, "Image de fond", self.background.text().strip() or "",
            "Images (*.jpg *.jpeg *.png *.bmp *.webp)")
        if chosen:
            self.background.setText(chosen)
            self._background_saved()
