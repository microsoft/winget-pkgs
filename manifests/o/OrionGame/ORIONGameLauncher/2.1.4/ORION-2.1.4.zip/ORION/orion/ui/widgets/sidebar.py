"""Navigation laterale : pages et filtres de sources."""
from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (QButtonGroup, QCheckBox, QLabel, QPushButton,
                               QSizePolicy, QVBoxLayout, QWidget)

from ...i18n import t
from ...version import APP_NAME, APP_TAGLINE
from .encart_version import EncartVersion
from .layouts import clear_layout
from .pastille import BoutonPastille
from ..defilement import ZoneDefilante

PAGES = [
    ("library", "Bibliotheque"),
    ("boutique", "Boutique"),
    ("sorties", "Sorties"),
    ("wishlist", "Envies"),
    ("hardware", "Ma machine"),
    ("storage", "Stockage"),
    ("comptes", "Comptes"),
    ("advice", "Conseils"),
    ("tutorial", "Tuto"),
    ("settings", "Reglages"),
]


class Sidebar(QWidget):
    page_changed = Signal(str)
    filters_changed = Signal(object)        # set de sources, ou None (tout)
    donate_requested = Signal()
    signaler_demande = Signal()
    avis_demande = Signal()
    version_cliquee = Signal(str)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("Sidebar")
        self.setFixedWidth(212)
        self._boxes: dict[str, QCheckBox] = {}
        self._dernier_filtre: set[str] | None = None

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 12)
        lay.setSpacing(0)

        brand = QLabel(APP_NAME)
        brand.setObjectName("Brand")
        lay.addWidget(brand)
        sub = QLabel(APP_TAGLINE)
        sub.setObjectName("BrandSub")
        lay.addWidget(sub)

        self.group = QButtonGroup(self)
        self.group.setExclusive(True)
        self._nav: dict[str, BoutonPastille] = {}
        for key, label in PAGES:
            # compteur eventuel cale a droite, dans la marge du style (10)
            btn = BoutonPastille(label, marge_texte=26, marge_droite=24)
            btn.setObjectName("NavButton")
            self._nav[key] = btn
            btn.setCheckable(True)
            btn.setProperty("page", key)
            btn.clicked.connect(lambda _=False, k=key: self.page_changed.emit(k))
            self.group.addButton(btn)
            lay.addWidget(btn)
            if key == "library":
                btn.setChecked(True)

        self.sources_title = QLabel("Sources")
        self.sources_title.setObjectName("NavSection")
        lay.addWidget(self.sources_title)

        self.sources_box = QWidget()
        self.sources_layout = QVBoxLayout(self.sources_box)
        self.sources_layout.setContentsMargins(0, 0, 0, 0)
        self.sources_layout.setSpacing(0)
        self.sources_layout.addStretch(1)
        # fenetre basse : la liste defile au lieu de s'ecraser
        from PySide6.QtWidgets import QFrame
        self.sources_zone = ZoneDefilante()
        self.sources_zone.setObjectName("SourcesZone")
        self.sources_zone.setWidgetResizable(True)
        self.sources_zone.setFrameShape(QFrame.Shape.NoFrame)
        self.sources_zone.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.sources_zone.setStyleSheet(
            "QScrollArea#SourcesZone { background: transparent; border: none; }")
        self.sources_box.setObjectName("SourcesBox")
        self.sources_box.setStyleSheet("QWidget#SourcesBox { background: transparent; }")
        self.sources_zone.viewport().setAutoFillBackground(False)
        self.sources_zone.setWidget(self.sources_box)
        self.sources_zone.setMinimumHeight(56)
        lay.addWidget(self.sources_zone, 1)

        self.donate = QPushButton("Soutenir ORION")
        self.donate.setObjectName("Donate")
        self.donate.setToolTip(
            "ORION est gratuit et le restera. Un don aide a le faire vivre.")
        self.donate.clicked.connect(self.donate_requested.emit)
        lay.addWidget(self.donate)

        self.signaler = QPushButton("Signaler un probleme")
        self.signaler.setObjectName("NavLink")
        self.signaler.setToolTip(
            "Un bug, un jeu mal detecte, une idee ? ORION prepare un rapport "
            "sans donnees personnelles et ouvre la page de signalement.")
        self.signaler.clicked.connect(self.signaler_demande.emit)
        lay.addWidget(self.signaler)

        self.hors_ligne = QLabel("● Hors ligne")
        self.hors_ligne.setObjectName("HorsLigne")
        self.hors_ligne.setContentsMargins(20, 4, 14, 0)
        self.hors_ligne.setToolTip("Pas de connexion Internet : prix, jaquettes et "
                                   "jeux gratuits seront actualises au retour du reseau.")
        self.hors_ligne.hide()
        lay.addWidget(self.hors_ligne)

        self.status = QLabel("")
        self.status.setObjectName("Faint")
        self.status.setWordWrap(True)
        self.status.setContentsMargins(20, 0, 14, 0)
        lay.addWidget(self.status)

        # version installee et nouvelle version disponible (bas gauche)
        self.version = EncartVersion()
        self.version.clique.connect(self.version_cliquee.emit)
        lay.addWidget(self.version)

        # discret, sous l'encart : jamais de fenetre qui s'ouvre d'elle-meme
        self.avis = QPushButton("Donnez votre avis")
        self.avis.setObjectName("AvisDiscret")
        self.avis.setCursor(Qt.CursorShape.PointingHandCursor)
        self.avis.setToolTip("Trois questions sur ORION : ce qui sert, ce qui gene, ce qui manque.")
        self.avis.clicked.connect(self.avis_demande.emit)
        lay.addWidget(self.avis, 0, Qt.AlignmentFlag.AlignLeft)

        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding)

    # ------------------------------------------------------------------
    def set_sources(self, counts: dict[str, int], labels: dict[str, str]) -> None:
        """Affiche une case par source detectee, avec le nombre de jeux.

        La liste est reconstruite a chaque rafraichissement de la
        bibliotheque : les cases gardent leur etat (une source decochee le
        reste), une source nouvelle arrive cochee, et le filtre est renvoye
        pour que la bibliotheque reste d'accord avec ce qui est affiche."""
        decochees = {s for s, b in self._boxes.items() if not b.isChecked()}
        clear_layout(self.sources_layout)
        self._boxes.clear()

        for src in sorted(counts, key=lambda s: -counts[s]):
            box = QCheckBox(f"{t(labels.get(src, src.capitalize()))}  ({counts[src]})")
            box.setObjectName("SourceFilter")
            box.setChecked(src not in decochees)
            box.setProperty("source", src)
            box.stateChanged.connect(self._emit_filters)
            self.sources_layout.addWidget(box)
            self._boxes[src] = box
        self.sources_layout.addStretch(1)
        self.sources_title.setVisible(bool(counts))
        if self.filtre_actif() != self._dernier_filtre:
            self._emit_filters()

    def active_sources(self) -> set[str]:
        return {s for s, b in self._boxes.items() if b.isChecked()}

    def filtre_actif(self) -> set[str] | None:
        """Sources a montrer, ou None quand tout est coche (aucun filtre :
        les jeux d'une source sans case, comme les non installes, restent
        visibles et la banniere revient)."""
        if all(b.isChecked() for b in self._boxes.values()):
            return None
        return self.active_sources()

    def _emit_filters(self) -> None:
        self._dernier_filtre = self.filtre_actif()
        self.filters_changed.emit(self._dernier_filtre)

    def set_donate(self, label: str, visible: bool) -> None:
        self.donate.setText(label or "Soutenir ORION")
        self.donate.setVisible(visible)

    def set_hors_ligne(self, oui: bool) -> None:
        self.hors_ligne.setVisible(oui)

    def set_version(self, etat: str, version: str = "", pourcentage: int = 0,
                    message: str = "") -> None:
        self.version.definir(etat, version, pourcentage, message)

    def afficher_version(self, oui: bool) -> None:
        self.version.setVisible(oui)

    def set_status(self, text: str) -> None:
        self.status.setText(text)

    def set_pastille(self, page: str, texte: str, couleur: str = "",
                     infobulle: str = "") -> None:
        """Compteur a cote d'une entree (ex. jeux gratuits sur « Boutique »)."""
        btn = self._nav.get(page)
        if btn is not None:
            btn.set_pastille(texte, couleur)
            btn.setToolTip(infobulle)

    def select_page(self, key: str) -> None:
        for btn in self.group.buttons():
            if btn.property("page") == key:
                btn.setChecked(True)
