"""Emplacements de fichiers utilises par ORION.

Tout ce qui est ecrit sur le disque passe par ce module : cela permet de
deplacer le stockage (ex. vers un autre disque) en changeant un seul endroit.
"""
from __future__ import annotations

import itertools
import os
import re
import sys
import threading
from pathlib import Path


def _local_appdata() -> Path:
    v = os.environ.get("LOCALAPPDATA")
    if v:
        return Path(v)
    return Path.home() / "AppData" / "Local"


def _root() -> Path:
    """Racine des fichiers livres avec l'application.

    En execution normale, c'est le dossier qui contient le paquet `orion`.
    Une fois l'application compilee en executable, PyInstaller depose ces
    memes fichiers dans un dossier temporaire designe par `sys._MEIPASS` :
    les recettes et les images doivent y etre cherchees, pas a cote de
    l'executable.
    """
    embarque = getattr(sys, "_MEIPASS", "")
    if embarque:
        return Path(embarque)
    return Path(__file__).resolve().parents[2]


#: Racine du code source (le dossier qui contient le paquet `orion`).
ROOT_DIR = _root()

#: Vrai quand l'application tourne depuis un executable compile.
FROZEN = bool(getattr(sys, "frozen", False))

#: Racine des donnees utilisateur (config, cache, sauvegardes, journaux).
DATA_DIR = Path(os.environ.get("ORION_DATA_DIR") or (_local_appdata() / "ORION"))

CONFIG_FILE = DATA_DIR / "config.json"
LIBRARY_FILE = DATA_DIR / "library.json"
STATS_FILE = DATA_DIR / "stats.json"
CACHE_DIR = DATA_DIR / "cache"
ART_DIR = CACHE_DIR / "art"
BACKUP_DIR = DATA_DIR / "backups"
LOG_DIR = DATA_DIR / "logs"
PLUGIN_USER_DIR = DATA_DIR / "plugins"
RECIPE_USER_DIR = DATA_DIR / "recipes"
RECIPE_COMMUNITY_DIR = DATA_DIR / "recipes" / "communaute"

#: Recettes d'optimisation livrees avec l'application.
RECIPE_BUILTIN_DIR = ROOT_DIR / "orion" / "plugins" / "tweaks" / "recipes"

#: Images livrees avec l'application (QR de don, etc.)
ASSETS_DIR = ROOT_DIR / "orion" / "ui" / "assets"


def ensure_dirs() -> None:
    """Cree l'arborescence de donnees si elle n'existe pas encore."""
    # ASSETS_DIR n'est pas cree : il est livre avec l'application, et en
    # version compilee il se trouve dans un dossier en lecture seule.
    for d in (DATA_DIR, CACHE_DIR, ART_DIR, BACKUP_DIR, LOG_DIR,
              PLUGIN_USER_DIR, RECIPE_USER_DIR, RECIPE_COMMUNITY_DIR):
        d.mkdir(parents=True, exist_ok=True)


def is_windows() -> bool:
    return sys.platform.startswith("win")


_WIN_VAR = re.compile(r"%([A-Za-z_][A-Za-z0-9_]*)%")


def expand(path: str) -> Path:
    """Developpe %VAR%, $VAR et ~ dans un chemin de recette ou de config.

    La forme %VAR% est resolue explicitement pour rester testable hors Windows.
    """
    raw = str(path)
    raw = _WIN_VAR.sub(lambda m: os.environ.get(m.group(1), m.group(0)), raw)
    raw = os.path.expandvars(os.path.expanduser(raw))
    if is_windows():
        raw = raw.replace("/", "\\")
    return Path(raw)


_compteur = itertools.count(1)


def _nom_provisoire(fichier: Path) -> Path:
    """Fichier voisin propre a cet appel : deux ecritures simultanees (deux
    fils, ou deux ORION) ne partagent jamais le meme fichier provisoire."""
    return fichier.with_name(f"{fichier.name}.{os.getpid()}-"
                             f"{threading.get_ident()}-{next(_compteur)}.tmp")


def ecrire_atomique(fichier: Path, texte: str) -> None:
    """Ecrit un fichier texte sans jamais laisser une version a moitie ecrite.

    Le contenu part d'abord dans un fichier voisin au nom unique, est force
    sur le disque (fsync), puis remplace l'original d'un coup : une coupure
    pendant l'ecriture laisse l'ancienne version intacte.
    """
    fichier = Path(fichier)
    fichier.parent.mkdir(parents=True, exist_ok=True)
    provisoire = _nom_provisoire(fichier)
    try:
        with open(provisoire, "w", encoding="utf-8") as f:
            f.write(texte)
            f.flush()
            try:
                os.fsync(f.fileno())
            except OSError:
                pass
        _remplacer(provisoire, fichier)
    except BaseException:
        try:
            provisoire.unlink()
        except OSError:
            pass
        raise


def _remplacer(source: Path, cible: Path, essais: int = 5) -> None:
    """`os.replace`, en reessayant brievement : sous Windows, un antivirus ou
    un indexeur qui lit le fichier au meme instant fait echouer le
    remplacement (PermissionError)."""
    import time
    for i in range(essais):
        try:
            os.replace(source, cible)
            return
        except PermissionError:
            if i == essais - 1:
                raise
            time.sleep(0.05 * (i + 1))
