"""Cartes de jeux de la Boutique, dessinees (et non construites en widgets).

Une rangee ou une grille de cent jeux reste un seul widget : chaque carte
est peinte a la demande, seulement si elle est visible, avec l'image deja
mise a la bonne taille par `ChargeurImages`. Le defilement reste fluide et
la memoire legere, meme avec tout le catalogue affiche.

* `RangeeCartes` : une ligne horizontale, fleches au survol, defilement
  anime (molette horizontale ou Maj + molette) ;
* `GrilleCartes` : une grille qui s'adapte a la largeur (resultats de
  recherche, catalogue filtre).

Les deux emettent `cliquee(fiche)` et `menu(fiche, position)`.
"""
from __future__ import annotations

from orion.core import region

import hashlib
import math
import time
from collections import OrderedDict

from PySide6.QtCore import (QEasingCurve, QPoint, QPointF, QRect, QRectF, QSize, Qt,
                            QVariantAnimation, Signal)
from PySide6.QtGui import (QBrush, QColor, QFont, QFontMetrics, QLinearGradient,
                           QPainter, QPainterPath, QPen, QPixmap)
from PySide6.QtWidgets import QSizePolicy, QToolTip, QWidget

from ...boutique import fige
from ...i18n import t
from ..theme import PALETTE, accent
from .boutique_images import ChargeurImages

RATIO = 1.75             # capsule Steam 616 x 353
RAYON = 12


#: libelle du bouton « Suivre » une fois le jeu dans les Envies (un second clic annule)
SUIVI = "✓  Suivi"


def euros(v: float) -> str:
    if v <= 0:
        return t("Gratuit")
    return region.prix(v)             # devise du pays choisi, format de la langue


def reste(fin: float) -> str:
    s = fin - time.time()
    if fin <= 0 or s <= 0:
        return ""
    if s < 3600:
        return f"Fin dans {int(s // 60)} min"
    if s < 48 * 3600:
        return f"Fin dans {int(s // 3600)} h"
    return f"Fin dans {int(s // 86400)} j"


def couleur(nom: str, alpha: int = 255) -> QColor:
    c = QColor(accent() if nom == "accent" else PALETTE.get(nom, nom))
    c.setAlpha(alpha)
    return c


def police(base: QFont, taille: float, poids: QFont.Weight = QFont.Weight.Normal,
           espacement: float = 0.0) -> QFont:
    f = QFont(base)
    f.setPixelSize(int(round(taille)))
    f.setWeight(poids)
    if espacement:
        f.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, espacement)
    return f


def teinte(graine: str) -> int:
    return int(hashlib.sha1((graine or "?").encode("utf-8", "ignore")).hexdigest()[:6], 16) % 360


def degrade(p: QPainter, rect: QRectF, graine: str, titre: str = "",
            base: QFont | None = None) -> None:
    """Visuel d'attente : degrade propre au jeu, titre en filigrane."""
    h = teinte(graine)
    g = QLinearGradient(rect.topLeft(), rect.bottomRight())
    g.setColorAt(0, QColor.fromHsl(h, 110, 62))
    g.setColorAt(0.55, QColor.fromHsl((h + 30) % 360, 120, 36))
    g.setColorAt(1, QColor.fromHsl((h + 60) % 360, 130, 18))
    p.fillRect(rect, QBrush(g))
    # halo lumineux, pour un rendu moins plat
    halo = QLinearGradient(rect.topLeft(), QPointF(rect.left(), rect.bottom()))
    halo.setColorAt(0, QColor(255, 255, 255, 34))
    halo.setColorAt(1, QColor(0, 0, 0, 60))
    p.fillRect(rect, QBrush(halo))
    if titre and base is not None and rect.width() > 80:
        f = police(base, max(13, min(28, rect.width() / 11)), QFont.Weight.Bold)
        p.setFont(f)
        p.setPen(QColor(255, 255, 255, 200))
        marge = rect.adjusted(14, 10, -14, -10)
        p.drawText(marge, Qt.AlignmentFlag.AlignCenter | Qt.TextFlag.TextWordWrap, titre)


def pilule(p: QPainter, x: float, y: float, texte: str, fond: QColor, encre: QColor,
           f: QFont, hauteur: float = 20, a_droite: bool = False) -> float:
    """Pastille arrondie ; rend sa largeur. `a_droite` : x est le bord droit."""
    p.setFont(f)
    largeur = QFontMetrics(f).horizontalAdvance(texte) + 14
    if a_droite:
        x -= largeur
    r = QRectF(x, y, largeur, hauteur)
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(fond)
    p.drawRoundedRect(r, hauteur / 2.6, hauteur / 2.6)
    p.setPen(encre)
    p.drawText(r, Qt.AlignmentFlag.AlignCenter, texte)
    return largeur


def bloc_prix(p: QPainter, droite: float, base_y: float, fiche, base: QFont,
              taille: float = 15, gauche: float = 0) -> None:
    """Remise, ancien prix barre et prix final, cales a droite."""
    m = fiche.meilleure
    if m is None:
        return
    x = droite
    fp = police(base, taille, QFont.Weight.Bold)
    prix = euros(m.prix)
    p.setFont(fp)
    w = QFontMetrics(fp).horizontalAdvance(prix)
    x -= w
    p.setPen(couleur("ok") if (fiche.remise or m.gratuit) else couleur("text"))
    p.drawText(QPointF(x, base_y), prix)
    if fiche.prix_normal and fiche.prix_normal > m.prix:
        fa = police(base, taille * 0.78)
        ancien = euros(fiche.prix_normal)
        p.setFont(fa)
        wa = QFontMetrics(fa).horizontalAdvance(ancien)
        x -= wa + 8
        if x > gauche:
            p.setPen(couleur("text_faint"))
            p.drawText(QPointF(x, base_y), ancien)
            p.setPen(QPen(couleur("text_faint"), 1))
            yb = base_y - QFontMetrics(fa).ascent() * 0.36
            p.drawLine(QPointF(x - 1, yb), QPointF(x + wa + 1, yb))
    if fiche.remise and not m.gratuit:
        fr = police(base, taille * 0.8, QFont.Weight.Bold)
        texte = f"-{fiche.remise} %"
        wr = QFontMetrics(fr).horizontalAdvance(texte) + 14
        x -= wr + 8
        if x > gauche:
            h = taille * 1.45
            pilule(p, x, base_y - h + QFontMetrics(fr).descent() + 3, texte,
                   QColor(61, 220, 151, 40), couleur("ok"), fr, h)


# ---------------------------------------------------------------------------
# Une carte
# ---------------------------------------------------------------------------
def hauteur_carte(largeur: int) -> int:
    return int(round(largeur / RATIO)) + 96


def dessiner_carte(p: QPainter, rect: QRectF, fiche, pix, survol: bool,
                   base: QFont, raison: str = "", possede: bool = False) -> None:
    ih = round(rect.width() / RATIO)
    chemin = QPainterPath()
    chemin.addRoundedRect(rect, RAYON, RAYON)

    # fond et image
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QColor(27, 34, 51, 236) if survol else QColor(20, 25, 38, 222))
    p.drawPath(chemin)
    image = QRectF(rect.left(), rect.top(), rect.width(), ih)
    p.save()
    p.setClipPath(chemin)
    if pix is not None:
        p.drawPixmap(image.topLeft(), pix)
    else:
        degrade(p, image, fiche.cle, fiche.titre, base)
    # fondu bas de l'image vers la carte
    fondu = QLinearGradient(QPointF(0, image.bottom() - 34), QPointF(0, image.bottom()))
    fondu.setColorAt(0, QColor(10, 13, 20, 0))
    fondu.setColorAt(1, QColor(10, 13, 20, 120))
    p.fillRect(QRectF(image.left(), image.bottom() - 34, image.width(), 34), QBrush(fondu))
    if survol:
        p.fillRect(image, QColor(255, 255, 255, 14))
    p.restore()

    # pastilles sur l'image
    fb = police(base, 9.5, QFont.Weight.Bold, 0.6)
    y_bas = image.bottom() - 26
    x = rect.left() + 10
    if possede:
        x += pilule(p, x, y_bas, t("DANS LA BIBLIOTHEQUE"), QColor(10, 13, 20, 200),
                    couleur("accent"), fb, 18) + 6
    elif fiche.au_plus_bas:
        x += pilule(p, x, y_bas, t("PLUS BAS HISTORIQUE"), QColor(10, 13, 20, 200),
                    couleur("ok"), fb, 18) + 6
    elif fiche.gratuit:
        x += pilule(p, x, y_bas, t("GRATUIT"), QColor(10, 13, 20, 200),
                    couleur("ok"), fb, 18) + 6
    # cle verifiee d'un revendeur, moins chere que les boutiques sures : une
    # mention a part en haut a gauche (couleur des revendeurs), jamais le
    # prix de la carte
    cle = getattr(fiche, "revendeur", None)
    if cle and not possede:
        pilule(p, rect.left() + 10, rect.top() + 10,
               f"{t('CLE')} {cle['boutique'].upper()}  {euros(cle['prix'])}",
               QColor(10, 13, 20, 215), couleur("warn"), fb, 18)
    fin = reste(fiche.fin_promo)
    if fin:
        urgent = fiche.fin_promo - time.time() < 86400
        pilule(p, rect.right() - 10, rect.top() + 10, t(fin).upper(),
               QColor(10, 13, 20, 200), couleur("warn" if urgent else "text_dim"),
               fb, 18, a_droite=True)

    # textes
    gauche, droite = rect.left() + 12, rect.right() - 12
    largeur = droite - gauche
    ft = police(base, 13.5, QFont.Weight.DemiBold)
    p.setFont(ft)
    p.setPen(couleur("text"))
    y = image.bottom() + 12
    titre = QFontMetrics(ft).elidedText(fiche.titre, Qt.TextElideMode.ElideRight, int(largeur))
    p.drawText(QRectF(gauche, y, largeur, 20), Qt.AlignmentFlag.AlignLeft |
               Qt.AlignmentFlag.AlignVCenter, titre)
    fs = police(base, 11.5)
    p.setFont(fs)
    if raison:
        p.setPen(couleur("accent", 230))
        ligne = t(raison)       # dessinee : aucune traduction automatique
    else:
        p.setPen(couleur("text_dim"))
        infos = [", ".join(fiche.etiquettes[:2])] if fiche.etiquettes else []
        if fiche.note:
            infos.append(f"{fiche.note} % " + t("positifs"))
        ligne = infos[0] if infos else (fiche.meilleure.boutique if fiche.meilleure else "")
        for info in infos[1:]:              # une information entiere ou rien
            if QFontMetrics(fs).horizontalAdvance(ligne + "  ·  " + info) > largeur:
                break
            ligne += "  ·  " + info
    p.drawText(QRectF(gauche, y + 21, largeur, 18),
               Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
               QFontMetrics(fs).elidedText(ligne, Qt.TextElideMode.ElideRight, int(largeur)))

    # boutique et prix
    base_y = rect.bottom() - 15
    m = fiche.meilleure
    if m is not None and not fiche.remise:
        p.setFont(police(base, 11))
        p.setPen(couleur("text_faint"))
        p.drawText(QPointF(gauche, base_y), t("chez") + f" {m.boutique}")
    bloc_prix(p, droite, base_y, fiche, base, 15, gauche - 2)

    # contour
    p.setBrush(Qt.BrushStyle.NoBrush)
    p.setPen(QPen(couleur("accent", 210) if survol else couleur("border"), 1.2 if survol else 1))
    p.drawPath(chemin)


# ---------------------------------------------------------------------------
# Cartes deja dessinees
# ---------------------------------------------------------------------------
#: Une carte dessinee est gardee en image et recopiee telle quelle tant que
#: rien de ce qu'elle montre ne change. Mesure du 7 octobre 2026 sur le
#: catalogue reel : chaque cran de molette redessinait une trentaine de cartes
#: en Python (degrades, textes, contours), soit 80 a 100 ms par cran, dix
#: images par seconde ; et chaque image de jeu qui arrivait redessinait toute
#: la page. Une carte gardee se recopie en une fraction de milliseconde.
_TAMPONS: "OrderedDict[tuple, QPixmap]" = OrderedDict()
_tampons_octets = 0
#: memoire accordee aux cartes gardees (les moins recentes partent d'abord)
TAMPONS_OCTETS = 64 * 1024 * 1024


def vider_tampons() -> None:
    """A appeler quand l'apparence generale change (theme, langue, devise)."""
    global _tampons_octets
    _TAMPONS.clear()
    _tampons_octets = 0


def signature_carte(fiche, pix, survol: bool, raison: str, possede: bool) -> tuple:
    """Tout ce que `dessiner_carte` montre de cette fiche : si rien n'a
    change, l'image gardee est encore exacte."""
    m = fiche.meilleure
    cle = getattr(fiche, "revendeur", None)
    fin = fiche.fin_promo
    return (fiche.cle, fiche.titre, pix.cacheKey() if pix is not None else 0,
            bool(survol), raison, bool(possede),
            (m.prix, m.boutique, m.gratuit) if m is not None else None,
            fiche.prix_normal, fiche.au_plus_bas, fiche.note,
            tuple(fiche.etiquettes[:2]),
            (cle.get("boutique"), cle.get("prix")) if cle else None,
            reste(fin), bool(fin and fin - time.time() < 86400))


def carte_gardee(rect: QRectF, fiche, pix, survol: bool, base: QFont, cle_police: str,
                 raison: str, possede: bool, dpr: float) -> QPixmap:
    """L'image de la carte (une marge d'un pixel autour), dessinee une fois."""
    global _tampons_octets
    largeur, hauteur = math.ceil(rect.width()) + 3, math.ceil(rect.height()) + 3
    cle = (largeur, hauteur, dpr, cle_police, accent(), t("chez"), region.pays()) \
        + signature_carte(fiche, pix, survol, raison, possede)
    image = _TAMPONS.get(cle)
    if image is not None:
        _TAMPONS.move_to_end(cle)
        return image
    image = QPixmap(QSize(max(1, round(largeur * dpr)), max(1, round(hauteur * dpr))))
    image.setDevicePixelRatio(dpr)
    image.fill(Qt.GlobalColor.transparent)
    p = QPainter(image)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
    p.setRenderHint(QPainter.RenderHint.TextAntialiasing)
    dessiner_carte(p, QRectF(1.5, 1.5, rect.width(), rect.height()), fiche, pix, survol,
                   base, raison, possede)
    p.end()
    _TAMPONS[cle] = image
    _tampons_octets += image.width() * image.height() * 4
    while _tampons_octets > TAMPONS_OCTETS and len(_TAMPONS) > 1:
        _, vieille = _TAMPONS.popitem(last=False)
        _tampons_octets -= vieille.width() * vieille.height() * 4
    return image


# ---------------------------------------------------------------------------
# Surface commune
# ---------------------------------------------------------------------------
class _Surface(QWidget):
    cliquee = Signal(object)
    menu = Signal(object, QPoint)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setMouseTracking(True)
        self.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent, False)
        self.fiches: list = []
        self.raisons: dict[str, str] = {}
        self.possede = lambda _f: False
        self._survol = -1
        self._voulues: set[str] = set()
        self._cles_avant: list[str] = []
        self._tampon: QPixmap | None = None
        self._tampon_cle: tuple | None = None
        self.chargeur = ChargeurImages.instance()
        self.chargeur.prete.connect(self._image_prete)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    # -- a fournir --------------------------------------------------------
    def rect_carte(self, i: int) -> QRectF:
        raise NotImplementedError

    def indices_visibles(self, zone: QRect) -> range:
        return range(len(self.fiches))

    # ------------------------------------------------------------------
    def set_fiches(self, fiches, raisons: dict[str, str] | None = None) -> None:
        """Nouvelles fiches : aucun widget n'est recree, seules les donnees
        changent (une actualisation ne fait que repeindre)."""
        self._cles_avant = [f.cle for f in self.fiches]
        self.fiches = list(fiches)
        self.raisons = dict(raisons or {})
        self._survol = -1
        self._apres_fiches()
        self.update()

    def memes_fiches(self) -> bool:
        """Vrai si la derniere mise a jour a garde les memes jeux, dans le
        meme ordre (actualisation des prix seulement)."""
        return self._cles_avant == [f.cle for f in self.fiches]

    def _apres_fiches(self) -> None:
        pass

    def _fondus(self) -> tuple[float, float]:
        """Largeur des fondus a gauche et a droite (jeux caches au-dela)."""
        return 0.0, 0.0

    def _image_prete(self, url: str) -> None:
        if url in self._voulues:
            self.update()

    def indice_a(self, pos) -> int:
        for i in self.indices_visibles(self.rect()):
            if self.rect_carte(i).contains(QPointF(pos)):
                return i
        return -1

    @fige
    def _a_recopier(self, zone: QRect, dpr: float) -> list[tuple[QPointF, QPixmap]]:
        """Les cartes visibles dans `zone` : (place, image gardee). La carte
        est recopiee, pas redessinee (voir `carte_gardee`) ; sa place est
        arrondie au pixel pour rester nette."""
        base = self.font()
        cle_police = base.key()
        out = []
        for i in self.indices_visibles(zone):
            r = self.rect_carte(i)
            if not r.intersects(QRectF(zone)):
                continue
            f = self.fiches[i]
            urls = f.visuels("carte")
            self._voulues.update(urls)
            taille = QSize(int(r.width()), int(round(r.width() / RATIO)))
            pix = self.chargeur.image(urls, taille)
            image = carte_gardee(r, f, pix, i == self._survol, base, cle_police,
                                 self.raisons.get(f.cle, ""), self.possede(f), dpr)
            out.append((QPointF(math.floor(r.left()) - 1, math.floor(r.top()) - 1), image))
        return out

    def _cartes(self, p: QPainter, zone: QRect) -> None:
        for place, image in self._a_recopier(zone, p.device().devicePixelRatioF()):
            p.drawPixmap(place, image)

    def paintEvent(self, event) -> None:
        self._voulues = set()
        gauche, droite = self._fondus()
        p = QPainter(self)
        if not (gauche or droite):
            self._cartes(p, event.rect())
        else:
            self._peindre_fondue(p, gauche, droite)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        self._apres_peinture(p)
        p.end()

    def _masquer_bords(self, t: QPainter, gauche: float, droite: float) -> None:
        """Attenue les bords d'un tampon transparent : les cartes coupees
        s'effacent en douceur, le decor de l'application reste visible."""
        w = float(self.width())
        masque = QLinearGradient(0, 0, w, 0)
        masque.setColorAt(0, QColor(0, 0, 0, 0 if gauche else 255))
        masque.setColorAt(min(0.49, gauche / w), QColor(0, 0, 0, 255))
        masque.setColorAt(max(0.51, 1 - droite / w), QColor(0, 0, 0, 255))
        masque.setColorAt(1, QColor(0, 0, 0, 0 if droite else 255))
        t.setCompositionMode(QPainter.CompositionMode.CompositionMode_DestinationIn)
        t.fillRect(self.rect(), QBrush(masque))

    def _tampon_neuf(self, dpr: float) -> QPixmap:
        taille = QSize(max(1, round(self.width() * dpr)), max(1, round(self.height() * dpr)))
        if self._tampon is None or self._tampon.size() != taille:
            self._tampon = QPixmap(taille)
        self._tampon.setDevicePixelRatio(dpr)
        self._tampon.fill(Qt.GlobalColor.transparent)
        return self._tampon

    def _peindre_fondue(self, p: QPainter, gauche: float, droite: float) -> None:
        """Les cartes coupees au bord s'effacent en douceur : peintes dans un
        tampon transparent dont on attenue les bords. Le tampon n'est refait
        que si ce qu'il montre a change : pendant un defilement de la page,
        la rangee se recopie d'un bloc."""
        dpr = self.devicePixelRatioF()
        cartes = self._a_recopier(self.rect(), dpr)
        taille = QSize(max(1, round(self.width() * dpr)), max(1, round(self.height() * dpr)))
        cle = (taille.width(), taille.height(), gauche, droite,
               tuple((c.x(), c.y(), image.cacheKey()) for c, image in cartes))
        if self._tampon is None or cle != self._tampon_cle:
            t = QPainter(self._tampon_neuf(dpr))
            for place, image in cartes:
                t.drawPixmap(place, image)
            self._masquer_bords(t, gauche, droite)
            t.end()
            self._tampon_cle = cle
        p.drawPixmap(0, 0, self._tampon)

    def _apres_peinture(self, p: QPainter) -> None:
        pass

    # -- souris -----------------------------------------------------------
    def mouseMoveEvent(self, event) -> None:
        i = self.indice_a(event.position().toPoint())
        if i != self._survol:
            self._survol = i
            self.update()
        super().mouseMoveEvent(event)

    def leaveEvent(self, event) -> None:
        self._survol = -1
        self.update()
        super().leaveEvent(event)

    def mouseReleaseEvent(self, event) -> None:
        i = self.indice_a(event.position().toPoint())
        if 0 <= i < len(self.fiches):
            if event.button() == Qt.MouseButton.LeftButton:
                self.cliquee.emit(self.fiches[i])
            elif event.button() == Qt.MouseButton.RightButton:
                self.menu.emit(self.fiches[i], event.globalPosition().toPoint())
        super().mouseReleaseEvent(event)

    def event(self, e) -> bool:
        if e.type() == e.Type.ToolTip:
            i = self.indice_a(e.pos())
            if 0 <= i < len(self.fiches):
                f = self.fiches[i]
                m = f.meilleure
                lignes = [f.titre]
                if m:
                    lignes.append(f"{euros(m.prix)}  ·  {t('chez')} {m.boutique}")
                if self.raisons.get(f.cle):
                    lignes.append(t(self.raisons[f.cle]))
                QToolTip.showText(e.globalPos(), "\n".join(lignes), self)
            else:
                QToolTip.hideText()
            return True
        return super().event(e)


# ---------------------------------------------------------------------------
# Rangee horizontale
# ---------------------------------------------------------------------------
class RangeeCartes(_Surface):
    LARGEUR = 236
    ECART = 14
    FLECHE = 40

    def __init__(self, parent=None, largeur: int = LARGEUR) -> None:
        super().__init__(parent)
        self.largeur = largeur
        self._decalage = 0.0
        self._survole = False
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(420)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim.valueChanged.connect(self._bouger)
        self.setFixedHeight(hauteur_carte(largeur) + 8)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

    def _apres_fiches(self) -> None:
        # simple actualisation des prix : la rangee reste ou elle etait
        if self.memes_fiches():
            self._decalage = min(self._decalage, self.maximum)
            return
        self._anim.stop()
        self._decalage = 0.0

    def _fondus(self) -> tuple[float, float]:
        return (48.0 if self._decalage > 1 else 0.0,
                64.0 if self._decalage < self.maximum - 1 else 0.0)

    @property
    def total(self) -> float:
        n = len(self.fiches)
        return n * self.largeur + max(0, n - 1) * self.ECART

    @property
    def maximum(self) -> float:
        return max(0.0, self.total - self.width())

    def rect_carte(self, i: int) -> QRectF:
        x = i * (self.largeur + self.ECART) - self._decalage
        return QRectF(x + 0.5, 4.5, self.largeur - 1, hauteur_carte(self.largeur) - 1)

    def indices_visibles(self, zone: QRect) -> range:
        pas = self.largeur + self.ECART
        debut = max(0, int((self._decalage + zone.left()) // pas))
        fin = min(len(self.fiches), int((self._decalage + zone.right()) // pas) + 1)
        return range(debut, fin)

    # -- defilement -------------------------------------------------------
    def defiler(self, sens: int) -> None:
        pas = max(self.largeur + self.ECART,
                  (self.width() // (self.largeur + self.ECART)) * (self.largeur + self.ECART))
        cible = self._anim.endValue() if self._anim.state() == \
            QVariantAnimation.State.Running else self._decalage
        self.aller_a(float(cible) + sens * pas)

    def aller_a(self, cible: float) -> None:
        cible = max(0.0, min(self.maximum, cible))
        self._anim.stop()
        self._anim.setStartValue(float(self._decalage))
        self._anim.setEndValue(float(cible))
        self._anim.start()

    def _bouger(self, v) -> None:
        self._decalage = float(v)
        self.update()

    def resizeEvent(self, event) -> None:
        self._decalage = min(self._decalage, self.maximum)
        super().resizeEvent(event)

    def wheelEvent(self, event) -> None:
        d = event.angleDelta()
        dx = d.x() or (d.y() if event.modifiers() & Qt.KeyboardModifier.ShiftModifier else 0)
        if dx and self.maximum > 0:
            cible = self._anim.endValue() if self._anim.state() == \
                QVariantAnimation.State.Running else self._decalage
            self.aller_a(float(cible) - dx * 1.6)
            event.accept()
            return
        event.ignore()              # la page defile normalement

    # -- fleches ----------------------------------------------------------
    def _fleches(self) -> list[tuple[int, QRectF]]:
        y = 4 + round(self.largeur / RATIO) / 2 - self.FLECHE / 2
        out = []
        if self._decalage > 1:
            out.append((-1, QRectF(8, y, self.FLECHE, self.FLECHE)))
        if self._decalage < self.maximum - 1:
            out.append((1, QRectF(self.width() - 8 - self.FLECHE, y, self.FLECHE,
                                  self.FLECHE)))
        return out

    def _apres_peinture(self, p: QPainter) -> None:
        if not self._survole:
            return
        for sens, r in self._fleches():
            p.setPen(QPen(QColor(255, 255, 255, 60), 1))
            p.setBrush(QColor(10, 13, 20, 215))
            p.drawEllipse(r)
            p.setPen(QPen(couleur("text"), 2.2, Qt.PenStyle.SolidLine,
                          Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
            c = r.center()
            k = 5.5 * sens
            p.drawPolyline([QPointF(c.x() - k * 0.6, c.y() - 7), QPointF(c.x() + k * 0.6, c.y()),
                            QPointF(c.x() - k * 0.6, c.y() + 7)])

    def enterEvent(self, event) -> None:
        self._survole = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:
        self._survole = False
        super().leaveEvent(event)

    def mousePressEvent(self, event) -> None:
        for sens, r in self._fleches():
            if r.contains(event.position()):
                self.defiler(sens)
                event.accept()
                self._fleche_pressee = True
                return
        self._fleche_pressee = False
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event) -> None:
        if getattr(self, "_fleche_pressee", False):
            self._fleche_pressee = False
            return
        super().mouseReleaseEvent(event)

    def indice_a(self, pos) -> int:
        if self._survole and any(r.contains(QPointF(pos)) for _s, r in self._fleches()):
            return -1
        return super().indice_a(pos)


# ---------------------------------------------------------------------------
# Grille adaptative
# ---------------------------------------------------------------------------
class GrilleCartes(_Surface):
    LARGEUR_MIN = 224
    ECART = 16

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self._colonnes, self._largeur = 1, self.LARGEUR_MIN

    def _geometrie(self, largeur: int) -> tuple[int, float]:
        cols = max(1, (largeur + self.ECART) // (self.LARGEUR_MIN + self.ECART))
        return cols, (largeur - self.ECART * (cols - 1)) / cols

    def hauteur_pour(self, largeur: int) -> int:
        cols, w = self._geometrie(largeur)
        lignes = (len(self.fiches) + cols - 1) // cols
        if not lignes:
            return 0
        return int(lignes * hauteur_carte(int(w)) + (lignes - 1) * self.ECART + 4)

    def _apres_fiches(self) -> None:
        self._ajuster()

    def _ajuster(self) -> None:
        self._colonnes, self._largeur = self._geometrie(max(1, self.width()))
        h = self.hauteur_pour(max(1, self.width()))
        if h != self.height():
            self.setFixedHeight(h)

    def resizeEvent(self, event) -> None:
        self._ajuster()
        super().resizeEvent(event)

    def rect_carte(self, i: int) -> QRectF:
        cols, w = self._colonnes, self._largeur
        ligne, col = divmod(i, cols)
        h = hauteur_carte(int(w))
        return QRectF(col * (w + self.ECART) + 0.5, ligne * (h + self.ECART) + 0.5,
                      int(w) - 1, h - 1)

    def indices_visibles(self, zone: QRect) -> range:
        cols = self._colonnes
        h = hauteur_carte(int(self._largeur)) + self.ECART
        debut = max(0, int(zone.top() // h) * cols)
        fin = min(len(self.fiches), (int(zone.bottom() // h) + 1) * cols)
        return range(debut, fin)
