"""Fond du jour et banniere de saison (2.0).

Deux decors changent tout seuls, sans rien telecharger :

* **le fond du jour** : une image livree avec ORION parmi plusieurs
  dizaines, choisie d'apres la date. Le site d'ORION fait le meme calcul :
  le meme jour, l'application et le site montrent la meme image ;
* **la banniere de saison** : peinte en haut de chaque page, derriere son
  titre. Elle change le jour meme de l'equinoxe ou du solstice, a la date
  ou il tombe pour l'horloge du PC, et il y en a une par saison et par an.

Les dates viennent du calcul astronomique (Jean Meeus, *Astronomical
Algorithms*, chapitre 27, valeur moyenne) : juste a une demi-heure pres,
pour n'importe quelle annee, sans table a tenir a jour.
"""
from __future__ import annotations

import datetime as dt
from pathlib import Path

from .core.logging_setup import get
from .core.paths import ASSETS_DIR

log = get("saisons")

FONDS = ASSETS_DIR / "fonds"
BANNIERES = ASSETS_DIR / "saisons"
SAISONS = ("printemps", "ete", "automne", "hiver")
NOMS = {"printemps": "Printemps", "ete": "Ete", "automne": "Automne", "hiver": "Hiver"}
#: annees pour lesquelles une banniere est livree ; ensuite, elles reviennent
PREMIERE_ANNEE, ANNEES = 2026, 5
#: 1er janvier 1970 dans le calendrier de Python (`date.toordinal`)
_EPOQUE = dt.date(1970, 1, 1).toordinal()
#: pays ou les saisons sont inversees (hemisphere sud)
SUD = frozenset({"AR", "AU", "BO", "BR", "BW", "CL", "FJ", "MG", "MU", "MZ", "NA", "NC", "NZ",
                 "PE", "PF", "PY", "RE", "UY", "ZA", "ZM", "ZW"})
_INVERSE = {"printemps": "automne", "ete": "hiver", "automne": "printemps", "hiver": "ete"}

#: jour julien moyen de chaque debut de saison, polynome en milliers d'annees
#: depuis l'an 2000 (Meeus, table 27.B : valable de l'an 1000 a l'an 3000)
_MEEUS = {
    "printemps": (2451623.80984, 365242.37404, 0.05169, -0.00411, -0.00057),
    "ete": (2451716.56767, 365241.62603, 0.00325, 0.00888, -0.00030),
    "automne": (2451810.21715, 365242.01767, -0.11575, 0.00337, 0.00078),
    "hiver": (2451900.05952, 365242.74049, -0.06223, -0.00823, 0.00032),
}


def instant(saison: str, annee: int) -> dt.datetime:
    """Debut astronomique de la saison (hemisphere nord), en temps universel."""
    y = (annee - 2000) / 1000
    a, b, c, d, e = _MEEUS[saison]
    jour_julien = a + b * y + c * y ** 2 + d * y ** 3 + e * y ** 4
    return dt.datetime(1970, 1, 1, tzinfo=dt.timezone.utc) + \
        dt.timedelta(days=jour_julien - 2440587.5)


def debuts(annee: int, fuseau=None) -> dict[str, dt.date]:
    """Jour ou commence chaque saison de l'annee, a l'heure du PC (ou du
    `fuseau` donne)."""
    return {s: instant(s, annee).astimezone(fuseau).date() for s in SAISONS}


def saison(jour: dt.date | None = None, sud: bool = False, fuseau=None) -> tuple[str, int]:
    """(saison, annee) du jour. L'hiver porte l'annee ou il commence : du 21
    decembre 2026 au 19 mars 2027, c'est « hiver 2026 ». `sud` : saisons
    inversees (hemisphere sud)."""
    jour = jour or dt.date.today()
    d = debuts(jour.year, fuseau)
    if jour < d["printemps"]:
        nom, annee = "hiver", jour.year - 1
    elif jour < d["ete"]:
        nom, annee = "printemps", jour.year
    elif jour < d["automne"]:
        nom, annee = "ete", jour.year
    elif jour < d["hiver"]:
        nom, annee = "automne", jour.year
    else:
        nom, annee = "hiver", jour.year
    return (_INVERSE[nom] if sud else nom), annee


def hemisphere_sud() -> bool:
    try:
        from .core import region
        return (region.pays() or "").upper()[:2] in SUD
    except Exception:
        return False


def banniere(jour: dt.date | None = None, dossier: Path | None = None) -> Path | None:
    """Image de la banniere du jour, ou None si elle n'est pas livree."""
    nom, annee = saison(jour, hemisphere_sud())
    dossier = dossier or BANNIERES
    # au-dela des annees livrees, les bannieres reviennent dans le meme ordre
    livree = PREMIERE_ANNEE + (annee - PREMIERE_ANNEE) % ANNEES
    for choix in (annee, livree):
        chemin = dossier / f"{nom}-{choix}.jpg"
        if chemin.is_file():
            return chemin
    restantes = sorted(dossier.glob(f"{nom}-*.jpg")) if dossier.is_dir() else []
    return restantes[0] if restantes else None


def numero_du_jour(jour: dt.date | None = None) -> int:
    """Nombre de jours depuis le 1er janvier 1970 : le site fait le meme
    compte pour choisir son fond."""
    return (jour or dt.date.today()).toordinal() - _EPOQUE


def fond_du_jour(jour: dt.date | None = None, dossier: Path | None = None) -> Path | None:
    """Le fond livre qui correspond a ce jour, ou None s'il n'y en a pas."""
    dossier = dossier or FONDS
    try:
        images = sorted(dossier.glob("*.jpg"))
    except OSError:
        images = []
    return images[numero_du_jour(jour) % len(images)] if images else None
