"""Precommandes des grosses sorties et sortie « a la une » (2.1.0).

Demande de l'auteur (9 octobre) : mettre en avant la sortie de Call of Duty:
Modern Warfare 4 avec le meilleur prix du moment, rafraichi, et vendre les
precommandes de toutes les sorties qui en ont.

* Chaque sortie de la page Sorties qui a une fiche Steam en precommande
  affiche son prix (un seul appel groupe a Steam, garde 12 heures).
* La sortie « a la une » (`une` dans `sorties.json`) a un bloc prix complet,
  relu toutes les 10 minutes tant que la page est ouverte :
  - le meilleur prix OFFICIEL (Steam : le seul releve sur pour une
    precommande) ;
  - dessous, a part, la cle Steam verifiee la moins chere chez un revendeur
    (Loaded, Kinguin), seulement si elle est moins chere, cle Steam du jeu
    lui-meme, activable dans le pays du joueur, jamais un compte ni un
    « Gift » (verifie par le service, voir `prix_revendeurs`). Elle n'est
    jamais presentee comme « le meilleur prix » ;
  - l'offre de fidelite de l'editeur quand elle existe et que la
    bibliotheque du joueur contient un jeu de la serie (`fidelite` dans
    `sorties.json`, texte de l'editeur, ORION ne promet rien : « vous etes
    peut-etre eligible »).

ORION ne fabrique aucun prix : il les releve, et dit d'ou ils viennent.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field

from .core.logging_setup import get

log = get("precommandes")

#: rafraichissement du bloc prix de la sortie a la une
RAFRAICHIR_UNE = 10 * 60
#: prix des cartes (simple indication, relue deux fois par jour)
GARDER_CARTES = 12 * 3600


@dataclass
class Offre:
    appid: str
    titre: str
    prix: float | None = None            # prix officiel actuel (Steam)
    normal: float | None = None          # prix hors promotion
    boutique: str = "Steam"
    url: str = ""
    cle: dict | None = None              # cle verifiee moins chere (revendeur), ou None
    fidelite: str = ""                   # offre de l'editeur, si le joueur y a peut-etre droit
    lu_le: float = field(default_factory=time.time)

    @property
    def precommande(self) -> bool:
        return self.prix is not None and self.prix > 0

    @staticmethod
    def montant(valeur: float) -> str:
        from .core import region
        try:
            return region.prix(valeur)
        except Exception:
            return f"{valeur:.2f} €".replace(".", ",")

    @property
    def texte_officiel(self) -> str:
        """« 69,99 € sur Steam » (avec la promo si elle existe)."""
        if not self.precommande:
            return ""
        t = f"{self.montant(self.prix)} sur {self.boutique}"
        if self.normal and self.normal > self.prix + 0.009:
            t += f" (au lieu de {self.montant(self.normal)})"
        return t

    @property
    def texte_cle(self) -> str:
        if not self.cle:
            return ""
        from .prix_revendeurs import libelle
        return f"{libelle(self.cle)} : {self.montant(self.cle['prix'])} chez {self.cle['boutique']}"


def _steam(appids: list[str], forcer: bool) -> dict:
    """{appid: (normal, actuel)} pour les jeux EN VENTE (precommande ouverte).
    Une fiche sans prix (pas encore en precommande) ne donne rien : Steam la
    rend comme un jeu gratuit, ce qu'elle n'est pas."""
    from . import valeur_catalogue
    try:
        prix, _partiel = valeur_catalogue._prix_steam(list(appids), forcer=forcer)
    except Exception as exc:
        log.info("Prix des precommandes indisponibles : %s", exc)
        return {}
    return {a: p for a, p in prix.items() if p and p[1] > 0}


def prix_cartes(liste) -> dict[str, str]:
    """{id de sortie: « Precommande : 69,99 € »} pour les sorties a venir
    qui ont une fiche Steam en precommande. Ne leve jamais."""
    from . import sorties
    futures = [s for s in liste if s.steam and (sorties.restant(s) is None
                                                  or sorties.restant(s).total_seconds() > 0)]
    if not futures:
        return {}
    prix = _steam([s.steam for s in futures], forcer=False)
    out = {}
    for s in futures:
        p = prix.get(s.steam)
        if p:
            out[s.id] = f"Precommande : {Offre.montant(p[1])}"
    return out


def _possede_la_serie(serie: str, jeux) -> bool:
    serie = (serie or "").lower().strip()
    if not serie:
        return False
    for g in jeux or []:
        titre = str(getattr(g, "title", "") or "").lower()
        if serie in titre and str(getattr(g, "source", "")) == "steam":
            return True
    return False


def offre_une(s, jeux=None, forcer: bool = False) -> Offre | None:
    """Le bloc prix de la sortie a la une. `jeux` : la bibliotheque (pour
    l'offre de fidelite). Ne leve jamais ; None sans fiche Steam."""
    if s is None or not getattr(s, "steam", ""):
        return None
    o = Offre(appid=s.steam, titre=s.titre,
              url=f"https://store.steampowered.com/app/{s.steam}/")
    p = _steam([s.steam], forcer=forcer).get(s.steam)
    if p:
        o.normal, o.prix = p
    if o.precommande:
        try:
            from . import prix_revendeurs
            offres = prix_revendeurs.offres(s.steam, s.titre, duree=RAFRAICHIR_UNE if forcer else None)
            o.cle = prix_revendeurs.meilleure_cle(
                {k: v for k, v in offres.items() if k in prix_revendeurs.HOTES},
                o.prix, o.normal or o.prix)
            if o.cle:
                o.cle["libelle"] = prix_revendeurs.libelle(o.cle, s)
        except Exception as exc:
            log.info("Cles verifiees indisponibles pour %s : %s", s.titre, exc)
    fid = getattr(s, "fidelite", None) or {}
    if isinstance(fid, dict) and fid.get("texte") and _possede_la_serie(fid.get("serie", ""), jeux):
        o.fidelite = str(fid["texte"])[:400]
    return o
