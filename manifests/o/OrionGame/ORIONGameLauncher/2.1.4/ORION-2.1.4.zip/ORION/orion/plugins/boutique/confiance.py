"""Qui a le droit de vendre ce jeu ? La politique de confiance de la Boutique.

Le prix le plus bas d'Internet est presque toujours sur une place de marche
de cles (G2A, Kinguin, Eneba...). Ces sites laissent n'importe qui revendre
des cles achetees a l'etranger, obtenues avec des cartes volees ou tirees de
lots presse : l'editeur peut les revoquer, le compte peut etre suspendu, et
l'argent ne va pas a ceux qui ont fait le jeu. ORION ne les classe donc
jamais comme « meilleur prix ».

Trois niveaux :

* **OFFICIEL** : la boutique de la plateforme ou de l'editeur (Steam, GOG,
  Epic, Ubisoft, EA, Battle.net, Microsoft).
* **AGREE** : revendeur autorise, qui achete ses cles directement aux
  editeurs (Fanatical, Humble, Green Man Gaming, Gamesplanet...). Meme jeu,
  meme cle, souvent moins cher.
* **EXCLU** : places de marche et revendeurs de cles gris. Jamais affiches
  comme bonne affaire.

Une boutique inconnue remontee par IsThereAnyDeal est traitee comme AGREE :
ce comparateur n'indexe par principe que des vendeurs autorises.
"""
from __future__ import annotations

import functools
import re
from dataclasses import dataclass

OFFICIEL = "officiel"
AGREE = "agree"
CADEAU = "cadeau"
EXCLU = "exclu"


@dataclass(frozen=True)
class Niveau:
    cle: str
    libelle: str
    explication: str

    @property
    def sur(self) -> bool:
        return self.cle in (OFFICIEL, AGREE, CADEAU)


NIVEAUX = {
    OFFICIEL: Niveau(OFFICIEL, "Boutique officielle",
                     "Vendu directement par la plateforme ou l'editeur."),
    AGREE: Niveau(AGREE, "Revendeur agree",
                  "Cles achetees directement aux editeurs : meme jeu, meme "
                  "cle officielle, souvent moins cher."),
    CADEAU: Niveau(CADEAU, "Cadeau verifie",
                   "Jeu offert par son editeur ou sa boutique, releve par la "
                   "veille des jeux gratuits d'ORION."),
    EXCLU: Niveau(EXCLU, "Place de marche non sure",
                  "Revente de cles entre particuliers ou de provenance "
                  "inconnue : risque de cle revoquee ou de compte suspendu."),
}

_OFFICIELS = re.compile(
    r"^(steam|gog(\.com)?|epic( games?)?( store)?|ubisoft( store| connect)?|"
    r"ea( app| store)?|origin|battle\.?net|blizzard|microsoft( store)?|xbox|"
    r"rockstar( store)?|bethesda|square enix( store)?|paradox( store)?|"
    r"nintendo|playstation|itch\.?io)$", re.I)

_AGREES = re.compile(
    r"(fanatical|humble|green ?man ?gaming|gmg|gamesplanet|gamersgate|"
    r"wingamestore|indiegala|2game|voidu|noctre|dlgamer|gamebillet|"
    r"dreamgame|allyouplay|gamesload|macgamestore|games ?republic|playsum|"
    r"chrono\.?gg|etail|newegg|joybuggy|game ?seal|nuuvem|gamesrocket|"
    r"digital river|amazon|cdon|jeuxvideo\.com|micromania|fnac)", re.I)

_EXCLUS = re.compile(
    r"(g2a|kinguin|eneba|gamivo|k4g|hrk|cdkeys|cd ?keys|instant ?gaming|"
    r"driffle|g2play|mmoga|gamesdeal|loaded|allkeyshop|keyforsteam|"
    r"difmark|yuplay|g2deal|punktid|royal ?cdkeys|mtcgame|kinguin)", re.I)


@functools.lru_cache(maxsize=2048)
def niveau(boutique: str, source: str = "") -> Niveau:
    """Niveau de confiance d'une boutique d'apres son nom.

    Garde en memoire : la Boutique le demande pour chaque offre a chaque
    affichage, et il n'y a que quelques dizaines de boutiques."""
    nom = (boutique or "").strip()
    if _EXCLUS.search(nom):
        return NIVEAUX[EXCLU]
    if _OFFICIELS.match(nom):
        return NIVEAUX[OFFICIEL]
    if _AGREES.search(nom):
        return NIVEAUX[AGREE]
    # IsThereAnyDeal ne reference que des vendeurs autorises
    if source == "itad":
        return NIVEAUX[AGREE]
    # la veille des jeux gratuits ne retient que des distributions officielles
    if source == "gratuits":
        return NIVEAUX[CADEAU]
    return NIVEAUX[EXCLU]

