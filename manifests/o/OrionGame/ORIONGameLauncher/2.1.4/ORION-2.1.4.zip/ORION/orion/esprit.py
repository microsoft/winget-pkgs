"""« Dans le meme esprit » : quand la recherche ne peut pas donner le jeu.

Un joueur tape « pokemon ». Aucune boutique PC ne le vend : repondre « rien »
ne l'aide pas. ORION dit pourquoi en une ligne, puis propose des jeux PC du
meme esprit, avec leurs prix du jour. Trois etages, du plus sur au plus large :

1. `TABLE` : les series les plus cherchees qui ne sont pas dans les boutiques
   PC (exclusivites de console, jeux mobiles), ou qui sont sur PC mais chez
   leur editeur (Fortnite, Minecraft...). Chaque entree donne la raison, des
   jeux choisis a la main (« graines ») et des etiquettes Steam qui
   completent la liste toute seule. Immediat, sans appel a un service.
2. Un jeu encore fiche sur Steam mais retire de la vente : ses propres
   etiquettes servent a trouver ses proches (voir `BoutiqueService`).
3. Tout le reste : le service d'ORION interroge un modele de langage, et
   garde la reponse pour tous les joueurs (`demander`).

Rien n'est affiche sur parole : une graine ou un titre propose n'apparait que
si Steam le vend vraiment aujourd'hui (il est cherche par son nom, et ecarte
s'il n'existe pas ou n'a pas de prix). Les etiquettes sont donnees par leur
nom anglais chez Steam et traduites en numeros a l'execution : une etiquette
inconnue est simplement ignoree.

Ce ne sont jamais « les memes jeux » : la page dit « Dans le meme esprit »,
a part des resultats.
"""
from __future__ import annotations

import re
import time
from dataclasses import dataclass

from . import partage
from .core.logging_setup import get
from .core.recherche import mots

log = get("esprit")

ADRESSE = partage.SERVICE + "/esprit"
#: une reponse du service est gardee sur le PC (le service garde la sienne un mois)
DUREE = 7 * 86400
#: jeux proposes au plus
MAXIMUM = 24

NINTENDO = "Exclusivite Nintendo : pas vendu sur PC."
PLAYSTATION = "Exclusivite PlayStation : pas vendu sur PC a ce jour."
MOBILE = "Jeu pour telephone : pas de version PC en boutique."
PAS_SUR_PC = "Pas vendu sur PC a ce jour."
AILLEURS = "Sur PC, mais pas dans les boutiques : il se prend chez son editeur."


@dataclass(frozen=True)
class Piste:
    """Pourquoi le jeu n'est pas la, et ou chercher ses proches."""
    raison: str
    graines: tuple = ()             # titres de jeux, tels que Steam les nomme
    etiquettes: tuple = ()          # noms anglais d'etiquettes Steam, ou numeros
    ou: tuple | None = None         # (libelle, adresse officielle) si le jeu est sur PC ailleurs
    nom: str = ""                   # nom du jeu ou de la serie, pour l'affichage


def _p(nom, raison, graines, etiquettes=(), ou=None) -> Piste:
    return Piste(raison, tuple(graines), tuple(etiquettes), ou, nom)


_PLATEFORME_3D = ("A Hat in Time", "Crash Bandicoot 4: It's About Time", "Spyro Reignited Trilogy",
                  "Psychonauts 2", "Sackboy: A Big Adventure", "It Takes Two", "Rayman Legends",
                  "Sonic Frontiers", "Penny's Big Breakaway", "Yooka-Laylee")
_SOULS = ("ELDEN RING", "DARK SOULS III", "Lies of P", "Sekiro: Shadows Die Twice - GOTY Edition",
          "Lords of the Fallen", "Nioh 2 - The Complete Edition", "Thymesia", "Remnant II")
_BATTLE_ROYALE = ("Apex Legends", "PUBG: BATTLEGROUNDS", "NARAKA: BLADEPOINT",
                  "THE FINALS", "Super Animal Royale")
_MOBA = ("Dota 2", "SMITE 2", "Predecessor")
_BLOCS = ("Terraria", "Minecraft Dungeons", "Minecraft Legends", "Core Keeper", "Valheim",
          "DRAGON QUEST BUILDERS 2", "7 Days to Die", "Trove", "Creativerse", "LEGO Worlds")
_MMO = ("FINAL FANTASY XIV Online", "The Elder Scrolls Online", "Guild Wars 2", "Lost Ark",
        "Black Desert")
_GACHA = ("Wuthering Waves", "Infinity Nikki", "Tower of Fantasy", "Immortals Fenyx Rising",
          "Tales of Arise", "Granblue Fantasy: Relink")

#: (mots-cles, piste). Un mot-cle est une suite de mots entiers de la
#: recherche ; le plus long l'emporte (« mario kart » avant « mario »).
TABLE: tuple = (
    # -- Nintendo -------------------------------------------------------------
    (("pokemon", "pocket monsters"), _p(
        "Pokemon", NINTENDO,
        ("Palworld", "Temtem", "Cassette Beasts", "Coromon", "Aniimo", "Nexomon: Extinction",
         "Monster Hunter Stories 2: Wings of Ruin", "Digimon Story Time Stranger",
         "Monster Sanctuary", "Siralim Ultimate"),
        ("Creature Collector",))),
    (("zelda", "breath of the wild", "tears of the kingdom", "botw", "totk"), _p(
        "The Legend of Zelda", NINTENDO,
        ("TUNIC", "Immortals Fenyx Rising", "Death's Door", "Hyper Light Drifter", "OKAMI HD",
         "Darksiders II Deathinitive Edition", "Sable", "Eastward", "Blossom Tales II: The Minotaur Prince",
         "Oceanhorn 2: Knights of the Lost Realm"),
        ("Action-Adventure", "Exploration", "Puzzle"))),
    (("mario kart",), _p(
        "Mario Kart", NINTENDO,
        ("Sonic Racing: CrossWorlds", "Team Sonic Racing", "Disney Speedstorm",
         "Nickelodeon Kart Racers 3: Slime Speedway", "Garfield Kart - Furious Racing",
         "DreamWorks All-Star Kart Racing"),
        ("Racing", "Arcade", "Local Multiplayer"))),
    (("mario party",), _p(
        "Mario Party", NINTENDO,
        ("Pummel Party", "Party Animals", "Ultimate Chicken Horse", "Overcooked! 2", "Gang Beasts",
         "Move or Die", "Stick Fight: The Game", "LEGO Party!", "Rubber Bandits"),
        ("Party Game", "Local Multiplayer"))),
    (("mario maker",), _p(
        "Super Mario Maker", NINTENDO,
        ("Levelhead", "Super Dungeon Maker", "Ultimate Chicken Horse", "BattleBlock Theater"),
        ("Level Editor", "Platformer"))),
    (("mario", "super mario"), _p(
        "Super Mario", NINTENDO, _PLATEFORME_3D + ("Celeste", "Pizza Tower", "Sonic Mania"),
        ("3D Platformer",))),
    (("donkey kong",), _p(
        "Donkey Kong", NINTENDO,
        ("Crash Bandicoot N. Sane Trilogy", "Rayman Legends", "Yooka-Laylee and the Impossible Lair",
         "Kaze and the Wild Masks", "Sonic Mania"),
        ("Platformer", "2D Platformer"))),
    (("smash bros", "super smash", "smash ultimate", "ssbu"), _p(
        "Super Smash Bros.", NINTENDO,
        ("Brawlhalla", "Rivals of Aether II", "Rivals of Aether", "Nickelodeon All-Star Brawl 2",
         "Lethal League Blaze", "Slap City"),
        ("2D Fighter", "Local Multiplayer"))),
    (("animal crossing",), _p(
        "Animal Crossing", NINTENDO,
        ("Stardew Valley", "Dinkum", "Disney Dreamlight Valley", "Cozy Grove", "My Time at Sandrock",
         "Palia", "Fae Farm", "Hokko Life", "Garden Paws"),
        ("Life Sim", "Cozy"))),
    (("splatoon",), _p(
        "Splatoon", NINTENDO,
        ("Plants vs. Zombies: Battle for Neighborville", "Plants vs. Zombies Garden Warfare 2: Deluxe Edition",
         "Marvel Rivals", "Overwatch"),
        ("Third-Person Shooter", "Team-Based", "Colorful"))),
    (("metroid",), _p(
        "Metroid", NINTENDO,
        ("Hollow Knight", "Hollow Knight: Silksong", "Axiom Verge", "Ori and the Will of the Wisps",
         "Prince of Persia The Lost Crown", "Blasphemous 2", "ANIMAL WELL", "Nine Sols"),
        ("Metroidvania",))),
    (("fire emblem",), _p(
        "Fire Emblem", NINTENDO,
        ("TRIANGLE STRATEGY", "Symphony of War: The Nephilim Saga", "Tactics Ogre: Reborn",
         "FINAL FANTASY TACTICS - The Ivalice Chronicles", "Dark Deity", "Wargroove 2",
         "Persona 5 Tactica"),
        ("Tactical RPG", "Turn-Based Tactics"))),
    (("xenoblade",), _p(
        "Xenoblade Chronicles", NINTENDO,
        ("Tales of Arise", "Granblue Fantasy: Relink", "Metaphor: ReFantazio",
         "Ni no Kuni Wrath of the White Witch Remastered", "SCARLET NEXUS", "FINAL FANTASY XVI"),
        ("JRPG", "Open World"))),
    (("kirby",), _p(
        "Kirby", NINTENDO,
        ("A Hat in Time", "Sackboy: A Big Adventure", "Pikuniku", "Unravel Two", "Rayman Legends"),
        ("Platformer", "Cute", "Family Friendly"))),
    (("pikmin",), _p(
        "Pikmin", NINTENDO, ("Tinykin", "The Wild at Heart", "Overlord II"),
        ("Exploration", "Cute", "Strategy"))),
    (("luigi's mansion", "luigi mansion"), _p(
        "Luigi's Mansion", NINTENDO,
        ("Ghostbusters: Spirits Unleashed Ecto Edition", "Little Nightmares II", "Pumpkin Jack"),
        ("Action-Adventure", "Family Friendly", "Horror"))),
    (("bayonetta 2", "bayonetta 3", "astral chain"), _p(
        "Bayonetta", NINTENDO,
        ("Bayonetta", "Devil May Cry 5", "NieR:Automata", "Hi-Fi RUSH", "METAL GEAR RISING: REVENGEANCE",
         "Stellar Blade"),
        ("Character Action Game", "Hack and Slash"))),
    # -- PlayStation ----------------------------------------------------------
    (("bloodborne",), _p("Bloodborne", PLAYSTATION, _SOULS, ("Souls-like",))),
    (("demon's souls", "demon souls"), _p(
        "Demon's Souls", PLAYSTATION, _SOULS, ("Souls-like",))),
    (("gran turismo", "gt7"), _p(
        "Gran Turismo", PLAYSTATION,
        ("Forza Motorsport", "Assetto Corsa Competizione", "Assetto Corsa EVO", "Forza Horizon 5",
         "Automobilista 2", "F1 25", "Le Mans Ultimate", "iRacing"),
        ("Automobile Sim", "Racing"))),
    (("astro bot", "astrobot", "astro's playroom"), _p(
        "Astro Bot", PLAYSTATION, _PLATEFORME_3D, ("3D Platformer",))),
    (("ghost of yotei",), _p(
        "Ghost of Yotei", PLAYSTATION,
        ("Ghost of Tsushima DIRECTOR'S CUT", "Sekiro: Shadows Die Twice - GOTY Edition",
         "Rise of the Ronin", "Assassin's Creed Shadows", "Nioh 2 - The Complete Edition"),
        ("Open World", "Ninja", "Action-Adventure"))),
    (("mlb the show", "mlb"), _p(
        "MLB The Show", PAS_SUR_PC,
        ("Super Mega Baseball 4", "Out of the Park Baseball 26"), ("Baseball", "Sports"))),
    # -- pas (encore) sur PC --------------------------------------------------
    (("gta 6", "gta vi", "gta6", "grand theft auto vi", "grand theft auto 6"), _p(
        "Grand Theft Auto VI", PAS_SUR_PC,
        ("Grand Theft Auto V Enhanced", "Red Dead Redemption 2", "Mafia: The Old Country",
         "Cyberpunk 2077", "Watch_Dogs 2", "Sleeping Dogs: Definitive Edition", "Just Cause 3",
         "Saints Row"),
        ("Open World", "Crime", "Action-Adventure"))),
    # -- telephone ------------------------------------------------------------
    (("clash royale",), _p(
        "Clash Royale", MOBILE,
        ("Minion Masters", "Mechabellum", "MARVEL SNAP", "Backpack Battles", "The Bazaar"),
        ("Card Battler", "PvP", "Strategy"))),
    (("clash of clans",), _p(
        "Clash of Clans", MOBILE,
        ("Age of Empires IV: Anniversary Edition", "They Are Billions", "Northgard: Definitive Edition",
         "Stronghold: Definitive Edition", "Kingdom Two Crowns"),
        ("Base Building", "Strategy", "Multiplayer"))),
    (("brawl stars",), _p(
        "Brawl Stars", MOBILE, ("Brawlhalla", "Marvel Rivals", "Overwatch"),
        ("Hero Shooter", "Team-Based", "Free to Play"))),
    (("mobile legends", "wild rift", "honor of kings"), _p(
        "Mobile Legends", MOBILE, _MOBA, ("MOBA",))),
    (("candy crush",), _p(
        "Candy Crush", MOBILE, ("Bejeweled 3", "Puzzle Quest 3", "10000000"),
        ("Match 3", "Casual"))),
    (("pokemon go",), _p(
        "Pokemon GO", MOBILE, ("Palworld", "Temtem", "Cassette Beasts", "Coromon", "Aniimo"),
        ("Creature Collector",))),
    # -- sur PC, chez l'editeur ----------------------------------------------
    (("fortnite",), _p(
        "Fortnite", AILLEURS, _BATTLE_ROYALE, ("Battle Royale", "Free to Play"),
        ("Fortnite chez Epic Games", "https://store.epicgames.com/fr/p/fortnite"))),
    (("valorant",), _p(
        "Valorant", AILLEURS,
        ("Counter-Strike 2", "Tom Clancy's Rainbow Six Siege", "Overwatch", "THE FINALS",
         "Marvel Rivals"),
        ("Hero Shooter", "Tactical", "FPS"),
        ("Valorant chez Riot Games", "https://playvalorant.com/fr-fr/"))),
    (("league of legends", "lol"), _p(
        "League of Legends", AILLEURS, _MOBA, ("MOBA",),
        ("League of Legends chez Riot Games", "https://www.leagueoflegends.com/fr-fr/"))),
    (("teamfight tactics", "tft"), _p(
        "Teamfight Tactics", AILLEURS,
        ("Mechabellum", "The Bazaar", "Backpack Battles", "Dota Underlords"),
        ("Auto Battler",),
        ("Teamfight Tactics chez Riot Games", "https://teamfighttactics.leagueoflegends.com/fr-fr/"))),
    (("minecraft",), _p(
        "Minecraft", AILLEURS, _BLOCS, ("Sandbox", "Building", "Crafting"),
        ("Minecraft sur son site", "https://www.minecraft.net/fr-fr"))),
    (("hytale",), _p(
        "Hytale", AILLEURS, _BLOCS, ("Sandbox", "Building", "Crafting"),
        ("Hytale sur son site", "https://hytale.com/"))),
    (("roblox",), _p(
        "Roblox", AILLEURS,
        ("Garry's Mod", "Trove", "LEGO Worlds", "VRChat", "Creativerse"),
        ("Sandbox", "Multiplayer", "Free to Play"),
        ("Roblox sur son site", "https://www.roblox.com/fr"))),
    (("genshin impact", "genshin"), _p(
        "Genshin Impact", AILLEURS, _GACHA, ("Anime", "Open World", "Action RPG"),
        ("Genshin Impact sur son site", "https://genshin.hoyoverse.com/fr/"))),
    (("honkai star rail", "honkai", "zenless zone zero", "zzz"), _p(
        "Honkai et Zenless Zone Zero", AILLEURS, _GACHA, ("Anime", "JRPG"),
        ("HoYoverse", "https://www.hoyoverse.com/fr-fr/"))),
    (("world of warcraft", "wow"), _p(
        "World of Warcraft", AILLEURS, _MMO, ("MMORPG",),
        ("World of Warcraft chez Blizzard", "https://worldofwarcraft.blizzard.com/fr-fr/"))),
    (("hearthstone",), _p(
        "Hearthstone", AILLEURS,
        ("MARVEL SNAP", "Magic: The Gathering Arena", "GWENT: The Witcher Card Game",
         "Slay the Spire", "Yu-Gi-Oh! Master Duel"),
        ("Card Battler", "Trading Card Game"),
        ("Hearthstone chez Blizzard", "https://hearthstone.blizzard.com/fr-fr"))),
    (("starcraft",), _p(
        "StarCraft", AILLEURS,
        ("Stormgate", "Age of Empires IV: Anniversary Edition", "Company of Heroes 3",
         "Tempest Rising", "Command & Conquer Remastered Collection"),
        ("RTS",),
        ("StarCraft II chez Blizzard", "https://starcraft2.blizzard.com/fr-fr/"))),
    (("star citizen",), _p(
        "Star Citizen", AILLEURS,
        ("Elite Dangerous", "No Man's Sky", "X4: Foundations", "Starfield", "EVE Online",
         "Everspace 2"),
        ("Space Sim",),
        ("Star Citizen sur son site", "https://robertsspaceindustries.com/"))),
    (("fall guys",), _p(
        "Fall Guys", AILLEURS,
        ("Stumble Guys", "Party Animals", "Pummel Party", "Ultimate Chicken Horse", "Gang Beasts"),
        ("Party Game", "Multiplayer"),
        ("Fall Guys chez Epic Games", "https://store.epicgames.com/fr/p/fall-guys"))),
    (("rocket league",), _p(
        "Rocket League", AILLEURS,
        ("REMATCH", "Turbo Golf Racing", "Trackmania"),
        ("Sports", "Racing", "Multiplayer"),
        ("Rocket League chez Epic Games", "https://store.epicgames.com/fr/p/rocket-league"))),
    (("alan wake 2", "alan wake ii"), _p(
        "Alan Wake 2", AILLEURS,
        ("Alan Wake", "Control Ultimate Edition", "SILENT HILL 2", "Resident Evil 4",
         "The Evil Within 2"),
        ("Psychological Horror", "Third Person"),
        ("Alan Wake 2 chez Epic Games", "https://store.epicgames.com/fr/p/alan-wake-2"))),
)

#: mots que le joueur ajoute pour dire « un jeu comme » : ils ne font pas partie du nom
_COMME = {"like", "likes", "style", "genre", "comme", "similaire", "similaires", "jeu", "jeux",
          "type", "pc", "sur", "un", "des", "du", "de", "a", "la", "le"}


def _plier(texte: str) -> list[str]:
    return [m for m in mots(texte or "")]


_INDEX: list | None = None


def _index() -> list:
    """[(mots du mot-cle, piste)], le mot-cle le plus long d'abord."""
    global _INDEX
    if _INDEX is None:
        lignes = [(tuple(_plier(cle)), piste) for cles, piste in TABLE for cle in cles]
        _INDEX = sorted((l for l in lignes if l[0]), key=lambda l: (-len(l[0]), -len("".join(l[0]))))
    return _INDEX


def chercher_piste(terme: str) -> Piste | None:
    """La piste de la table pour cette recherche, ou None. « pokemon rouge »,
    « pokemon like », « jeu comme zelda » trouvent leur serie."""
    demande = _plier(terme)
    if not demande or len(demande) > 8:
        return None
    for cle, piste in _index():
        n = len(cle)
        for i in range(len(demande) - n + 1):
            if tuple(demande[i:i + n]) != cle:
                continue
            reste = demande[:i] + demande[i + n:]
            # un mot-cle d'un seul mot tres court (« lol », « wow », « tft »,
            # « mlb ») doit etre toute la recherche, aux mots vides pres
            if n == 1 and len(cle[0]) <= 3 and any(m not in _COMME for m in reste):
                continue
            return piste
    return None


def connu(terme: str) -> bool:
    return chercher_piste(terme) is not None


# ---------------------------------------------------------------------------
# Etage 3 : le service d'ORION
# ---------------------------------------------------------------------------
#: ce que le service peut dire d'un jeu introuvable, et la phrase d'ORION
RAISONS = {
    "console": "« {nom} » ne semble pas vendu sur PC ({ou}).",
    "mobile": "« {nom} » semble etre un jeu pour telephone, sans version PC en boutique.",
    "ailleurs": "« {nom} » semble vendu ailleurs que dans les boutiques relevees par ORION.",
    "retire": "« {nom} » ne semble plus en vente.",
    "pas_sorti": "« {nom} » ne semble pas encore sorti sur PC.",
    "inconnu": "ORION ne trouve pas ce jeu dans les boutiques.",
}
_PROPRE = re.compile(r"[^0-9A-Za-zÀ-ÖØ-öø-ÿ '&:!.,+\-]")


def _texte(valeur, maximum: int) -> str:
    """Un texte venu du service, reduit a des lettres, chiffres et ponctuation
    courante : rien d'autre n'est affiche."""
    return " ".join(_PROPRE.sub(" ", str(valeur or "")).split())[:maximum]


def lire_reponse(brut) -> Piste | None:
    """La reponse du service, verifiee et reduite a ce qu'ORION sait montrer.
    Une reponse mal formee ou vide ne donne rien."""
    if not isinstance(brut, dict):
        return None
    titres = []
    for t in brut.get("titres") if isinstance(brut.get("titres"), list) else []:
        t = _texte(t, 80)
        if len(t) >= 2 and t.lower() not in {x.lower() for x in titres}:
            titres.append(t)
    etiquettes = [e for e in (_texte(e, 40) for e in (
        brut.get("etiquettes") if isinstance(brut.get("etiquettes"), list) else [])) if e][:3]
    if not titres and not etiquettes:
        return None
    code = str(brut.get("raison") or "inconnu")
    nom = _texte(brut.get("nom"), 60)
    if code not in RAISONS or not nom:
        code = "inconnu"
    ou = _texte(brut.get("plateformes"), 40)
    if code == "console" and not ou:
        code = "inconnu"
    return Piste(RAISONS[code].format(nom=nom, ou=ou), tuple(titres[:10]), tuple(etiquettes),
                 None, nom)


def demander(terme: str) -> Piste | None:
    """Ce que le service d'ORION sait d'un jeu introuvable : pourquoi, et des
    jeux PC du meme esprit. Garde une semaine sur le PC. Ne leve jamais ; sans
    service (ou service non configure), rien."""
    terme = " ".join((terme or "").split())[:60]
    if len(terme) < 3:
        return None
    from .core.base import Table
    table = Table("esprit", maximum=400)
    cle = " ".join(_plier(terme))
    if not cle:
        return None
    try:
        memo = table.get(cle)
    except Exception:
        memo = None
    if isinstance(memo, dict) and time.time() - float(memo.get("lu_le") or 0) < DUREE:
        return lire_reponse(memo.get("reponse"))
    try:
        from .core import reseau
        r = reseau.get(ADRESSE, params={"q": terme}, timeout=25)
        if r.status_code != 200:
            raise RuntimeError(f"reponse {r.status_code}")
        reponse = r.json()
        table.set(cle, {"lu_le": time.time(), "reponse": reponse if isinstance(reponse, dict) else {}})
        return lire_reponse(reponse)
    except Exception as exc:
        log.debug("Jeux du meme esprit indisponibles pour « %s » : %s", terme, exc)
        return None
