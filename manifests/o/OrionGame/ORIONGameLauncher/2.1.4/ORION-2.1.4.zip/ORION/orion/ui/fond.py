"""Comportements de fond de la fenetre principale (1.7).

Regroupe ce qui tourne autour de l'interface sans en etre une page :

* mise a jour automatique, encart « version » en bas a gauche (clic =
  installation et redemarrage) et fenetre « Quoi de neuf » ;
* signalement de probleme et interception des plantages ;
* mode discret pendant une partie (et temps de jeu hors ORION) ;
* jeux possedes non installes ;
* indicateur « hors ligne ».

`FondMixin` est melange a `MainWindow` : il utilise ses services
(`self.library`, `self.notify`...) sans alourdir le fichier principal.
"""
from __future__ import annotations

from .minuteur import plus_tard

from orion.affiliation import ouvreur  # liens de boutique (partenaires)

import sys
import threading
from pathlib import Path

from PySide6.QtCore import QObject, QTimer, Signal
from PySide6.QtWidgets import QApplication, QMessageBox

from .. import codes_promo, en_jeu, maj, nouveautes, signalement
from ..core.config import CONFIG
from ..core.events import BUS
from ..core.logging_setup import get
from ..core.tasks import Task
from ..optimizer import advisor
from ..version import APP_NAME, APP_VERSION

ouvrir_lien = ouvreur("fond")   # d'ou vient le clic (compteur anonyme)

log = get("ui.fond")

#: mise a jour prete pendant une partie
MESSAGE_FIN_PARTIE = "La mise a jour s'installera a la fin de votre partie"


class _Pont(QObject):
    """Ramene sur le fil de l'interface des evenements nes ailleurs."""
    erreur = Signal(str)
    reseau = Signal(bool)
    pilotes = Signal()                 # resultat de la recherche Windows Update arrive


class FondMixin:
    # ------------------------------------------------------------------
    # installation
    # ------------------------------------------------------------------
    def _init_fond(self) -> None:
        self.veille_jeu = en_jeu.Veille()
        self._differe: set[str] = set()
        self._veille_busy = False
        self._maj_proposee = ""
        self._maj_en_cours = False
        self._maj_pub = None          # derniere publication lue sur GitHub
        self._maj_en_attente = None   # installateur pret, installe en fin de partie
        self._hors_ligne = False
        from ..possedes import Possedes
        self.possedes = Possedes()

        self._pont = _Pont()
        self._pont.erreur.connect(self._erreur_imprevue)
        self._pont.reseau.connect(self._etat_reseau)
        signalement.installer_gestionnaires(lambda texte: self._pont.erreur.emit(texte))
        BUS.on("reseau.etat", lambda en_ligne=True, **_: self._pont.reseau.emit(bool(en_ligne)))
        BUS.on("pilotes.maj", lambda **_: self._pont.pilotes.emit())
        self._pont.pilotes.connect(self._pilotes_maj_recus)
        self._arret_brutal = signalement.ouvrir_session()

    def _boot_fond(self) -> None:
        # nettoyage des restes de mise a jour hors du fil de l'interface :
        # un dossier volumineux ou un fichier verrouille ne fige pas ORION
        threading.Thread(target=self._nettoyer_maj, name="orion-nettoyage-maj",
                         daemon=True).start()
        plus_tard(self, 1500, self._montrer_nouveautes)
        plus_tard(self, 9000, self._proposer_partage)
        plus_tard(self, 90000, self._proposer_note)
        plus_tard(self, 12000, self._compter_ouverture)
        plus_tard(self, 20000, self._lire_mesures_partagees)
        # codes promo des revendeurs partenaires (codes.json du site), hors
        # du fil graphique : la liste embarquee sert en attendant
        plus_tard(self, 25000, codes_promo.rafraichir_en_fond)
        if self._arret_brutal:
            plus_tard(self, 7000, self._proposer_signalement_arret)

        self._timer_jeu = QTimer(self)
        self._timer_jeu.timeout.connect(self._regarder_jeux)
        self._timer_jeu.start(en_jeu.INTERVALLE * 1000)
        plus_tard(self, 3000, self._regarder_jeux)

        self.sidebar.afficher_version(CONFIG.get("maj.afficher_version", True))
        self.sidebar.version_cliquee.connect(self._version_cliquee)
        if "--apres-maj" in sys.argv:
            plus_tard(self, 2500, lambda: self.notify(
                f"Mise a jour installee : {APP_NAME} {APP_VERSION}", 10))
        elif "--maj-echouee" in sys.argv:
            plus_tard(self, 2500, lambda: self.notify(
                "La mise a jour n'a pas pu s'installer : ORION est reste dans "
                "sa version actuelle. Cliquez en bas a gauche pour reessayer.", 12))
        plus_tard(self, 25000, self._verification_periodique)
        self._timer_maj = QTimer(self)
        self._timer_maj.timeout.connect(self._verification_periodique)
        self._timer_maj.start(3 * 3600 * 1000)

        self.library_view.set_possedes(self.possedes.tous())
        if CONFIG.get("bibliotheque.non_installes", True):
            plus_tard(self, 45000, self.actualiser_possedes)

    def _fermer_fond(self) -> None:
        try:
            from .. import compteur
            compteur.fermer()
        except Exception:
            pass
        signalement.fermer_session()
        try:
            from ..core import base
            base.fermer()
        except Exception:
            pass

    # ------------------------------------------------------------------
    # mode discret
    # ------------------------------------------------------------------
    @staticmethod
    def _nettoyer_maj() -> None:
        try:
            maj.nettoyer()
        except Exception:
            log.exception("Nettoyage des restes de mise a jour impossible")

    @staticmethod
    def _session_active(s) -> bool:
        """Une session lancee par ORION est-elle encore en cours ?
        `termine` fait foi ; a defaut (ancien objet), une duree encore nulle."""
        return not getattr(s, "termine", getattr(s, "seconds", 1) != 0)

    @property
    def en_partie(self) -> bool:
        return bool(getattr(self.veille_jeu, "actif", False)) or any(
            self._session_active(s) for s in getattr(self, "sessions", []))

    def _purger_sessions(self) -> None:
        """Oublie les sessions terminees (la liste ne grossit plus sans fin)."""
        sessions = getattr(self, "sessions", None)
        if sessions:
            sessions[:] = [s for s in sessions if self._session_active(s)]

    def _differer(self, nom: str) -> bool:
        """Vrai (et note la tache) si une partie est en cours : l'appelant
        doit alors s'abstenir. La tache sera relancee a la fin de la partie."""
        if CONFIG.get("jeu.discret", True) and self.en_partie:
            if nom not in self._differe:
                log.info("Mode discret : %s reporte apres la partie", nom)
            self._differe.add(nom)
            return True
        return False

    def _regarder_jeux(self) -> None:
        self._purger_sessions()
        # partie lancee par ORION terminee entre deux passages de la veille
        self._installer_maj_en_attente()
        if self._veille_busy:
            return
        self._veille_busy = True
        jeux = self.library.games(include_hidden=True)
        task = Task(self.veille_jeu.regarder, jeux)
        task.signals.finished.connect(self._jeux_regardes)
        task.signals.failed.connect(lambda _m: setattr(self, "_veille_busy", False))
        task.start()

    def _jeux_regardes(self, changements: list) -> None:
        self._veille_busy = False
        for ch in changements:
            game = self.library.get(ch[1])
            if game is None:
                continue
            if ch[0] == "debut":
                log.info("Partie detectee : %s", game.title)
                if CONFIG.get("jeu.discret", True) and len(self.veille_jeu.en_cours) == 1:
                    en_jeu.baisser_priorite(True)
                    self.notify(f"{game.title} en cours : ORION se met en retrait "
                                "jusqu'a la fin de la partie", 8)
            else:
                secondes = int(ch[2])
                log.info("Partie terminee : %s (%d s)", game.title, secondes)
                if (not ch[3]
                        and CONFIG.get("jeu.compter_hors_orion", True)
                        and secondes >= en_jeu.DUREE_MINI):
                    # partie lancee depuis Steam, Epic... : ORION la compte aussi
                    self.library.record_session(game, secondes, "hors-orion")
        if changements and not self.veille_jeu.actif:
            self._reprendre()
        if changements:
            self.refresh_library()

    def _reprendre(self) -> None:
        """Fin de partie : priorite normale, taches reportees relancees en
        decale pour ne pas tout demander au meme instant."""
        en_jeu.baisser_priorite(False)
        self._purger_sessions()
        revenir = getattr(self, "_revenir_apres_jeu", None)
        if revenir is not None:
            revenir()
        if self._installer_maj_en_attente():
            return              # ORION va redemarrer : rien d'autre a relancer
        actions = {
            "veille": self._watch_tick,
            "jaquettes": self.fetch_artwork,
            "boutique": self.refresh_boutique,
            "gratuits": self.refresh_free,
            "envies": self.refresh_wishlist,
            "recettes": self.sync_community,
            "possedes": self.actualiser_possedes,
            "maj": lambda: self.verifier_maj(silencieux=True),
            "comptes": lambda: [self.actualiser_compte(p) for p in ("steam", "gog", "xbox")],
            "puissance": self.analyser_puissance,
            "sorties": self._illustrer_sorties,
        }
        a_faire = [n for n in actions if n in self._differe]
        self._differe.clear()
        for i, nom in enumerate(a_faire):
            plus_tard(self, 5000 + i * 20000, actions[nom])
        if a_faire:
            log.info("Fin de partie : reprise de %s", ", ".join(a_faire))

    # ------------------------------------------------------------------
    # jeux possedes non installes
    # ------------------------------------------------------------------
    def actualiser_possedes(self) -> None:
        if not CONFIG.get("bibliotheque.non_installes", True):
            self.library_view.set_possedes([])
            return
        if self._differer("possedes"):
            return
        installes = self.library.games(include_hidden=True)
        task = Task(self.possedes.actualiser, installes)
        task.signals.finished.connect(self._possedes_actualises)
        task.start()

    def _possedes_actualises(self, nombre: int) -> None:
        self.library_view.set_possedes(self.possedes.tous())
        self._compter_locaux()             # page Comptes : jeux en double
        log.info("Jeux possedes non installes : %s", nombre)
        manquants = [g for g in self.possedes.tous() if not g.art_cover][:80]
        if manquants and CONFIG.get("artwork.enabled", True):
            def travail(progress_cb=None):
                n = self.artwork.ensure_many(manquants, None)
                self.possedes.enregistrer()
                return n
            task = Task(travail)
            task.signals.finished.connect(
                lambda _n: self.library_view.set_possedes(self.possedes.tous()))
            task.start()

    def jeu(self, uid: str):
        """Jeu de la bibliotheque, ou jeu possede non installe."""
        return self.library.get(uid) or self.possedes.get(uid)

    def installer_possede(self, uid: str) -> None:
        g = self.possedes.get(uid)
        if g is None:
            return
        if g.launch_uri:
            self._open_folder_path(g.launch_uri)
            self.notify(f"{g.title} : installation ouverte dans "
                        f"{g.source.capitalize()}", 8)
        elif g.store_url:
            ouvrir_lien(g.store_url)

    # ------------------------------------------------------------------
    # mises a jour
    # ------------------------------------------------------------------
    def _suivi_actif(self) -> bool:
        """Faut-il interroger GitHub de soi-meme ? Oui si l'utilisateur veut
        les propositions automatiques ou l'encart « version ».
        Jamais pour la version du Microsoft Store, qui se met a jour seule."""
        if maj.depuis_store():
            return False
        return bool(CONFIG.get("maj.auto", True)
                    or CONFIG.get("maj.afficher_version", True))

    def _verification_periodique(self) -> None:
        if self._suivi_actif() and not self._maj_en_cours:
            self.verifier_maj(silencieux=True)

    def verifier_maj(self, silencieux: bool = False, source: str = "") -> None:
        """Interroge GitHub. `silencieux` : verification automatique ;
        `source` = « encart » quand l'utilisateur clique en bas a gauche
        (le resultat s'affiche alors dans l'encart, sans fenetre)."""
        if self._maj_en_cours:
            return
        if maj.depuis_store():
            if not silencieux:
                self.notify("Les mises a jour passent par le Microsoft Store")
            return
        if silencieux and self._differer("maj"):
            return
        self.sidebar.set_version("verification")
        # verification demandee a la main : reponse fraiche (requete
        # conditionnelle, qui ne coute rien a GitHub si rien n'a change)
        task = Task(maj.verifier, 1800 if silencieux else 1)
        task.signals.finished.connect(lambda pub: self._maj_verifiee(pub, silencieux, source))
        task.signals.failed.connect(lambda m: self._maj_verif_echec(m, silencieux))
        task.start()

    def _maj_verif_echec(self, message: str, silencieux: bool) -> None:
        self._afficher_encart()
        if not silencieux:
            self.notify("Verification des mises a jour impossible : " + message[:120], 8)

    def _afficher_encart(self) -> None:
        """Remet l'encart dans l'etat de la derniere publication connue."""
        pub = self._maj_pub
        if pub is None or not pub.version:
            self.sidebar.set_version("inconnu")
        elif pub.disponible:
            self.sidebar.set_version("disponible", pub.version)
        else:
            self.sidebar.set_version("a_jour")

    def _maj_verifiee(self, pub, silencieux: bool, source: str = "") -> None:
        if pub is not None and getattr(pub, "version", ""):
            self._maj_pub = pub
        self._afficher_encart()
        if hasattr(self, "settings_view"):
            self.settings_view.set_maj_etat(pub)
        if not pub.disponible:
            if not silencieux:
                self.notify(f"{APP_NAME} {APP_VERSION} est a jour", 6)
            return
        encart = CONFIG.get("maj.afficher_version", True)
        if source == "encart":
            self.notify(f"{APP_NAME} {pub.version} est disponible : cliquez sur "
                        "l'encart en bas a gauche pour l'installer", 8)
            return
        if silencieux:
            deja_vue = (CONFIG.get("maj.ignoree", "") == pub.version
                        or self._maj_proposee == pub.version)
            if encart or deja_vue or not CONFIG.get("maj.auto", True):
                # l'encart en bas a gauche suffit : pas de fenetre a chaque
                # demarrage, un simple rappel
                if self._maj_proposee != pub.version:
                    self._maj_proposee = pub.version
                    self.notify(f"{APP_NAME} {pub.version} est disponible"
                                + (" : cliquez en bas a gauche pour l'installer"
                                   if encart else " (Reglages > Mises a jour)"), 10)
                return
        self._maj_proposee = pub.version
        from .widgets.dialogues import DialogueMiseAJour
        d = DialogueMiseAJour(pub, self)
        d.exec()
        if d.choix == d.IGNORER:
            CONFIG.set("maj.ignoree", pub.version)
        elif d.choix == d.INSTALLER:
            self.installer_maj(pub)

    def _version_visible(self, oui: bool) -> None:
        self.sidebar.afficher_version(oui)
        if oui and self._maj_pub is None:
            self.verifier_maj(silencieux=True)

    def _version_cliquee(self, etat: str) -> None:
        """Clic sur l'encart « version » en bas a gauche."""
        pub = self._maj_pub
        if etat in ("disponible", "erreur") and pub is not None and pub.disponible:
            self.installer_maj(pub)
        else:
            self.verifier_maj(silencieux=False, source="encart")

    def installer_maj(self, pub) -> None:
        """Telecharge, verifie, installe et redemarre ; sans empreinte
        verifiable, ouvre la page de telechargement a la place."""
        if getattr(self, "_maj_en_attente", None):
            # deja telechargee : installee tout de suite, ou en fin de partie
            if self.en_partie:
                self.notify(MESSAGE_FIN_PARTIE, 8)
            else:
                self._installer_maj_en_attente()
            return
        if pub.verifiable:
            self._lancer_maj(pub)
        else:
            self.notify("Empreinte de la version introuvable : ouverture de la "
                        "page de telechargement", 8)
            ouvrir_lien(pub.page)

    def _lancer_maj(self, pub) -> None:
        if self._maj_en_cours:
            return
        self._maj_en_cours = True
        self._maj_pub = pub
        self.sidebar.set_version("telechargement", pub.version, 0)
        self.notify(f"Telechargement de {APP_NAME} {pub.version}...", 30)
        task = Task(maj.telecharger, pub)
        task.signals.progress.connect(self._maj_progression)
        task.signals.finished.connect(self._maj_telechargee)
        task.signals.failed.connect(self._maj_echec)
        task.start()

    def _maj_progression(self, message: str, pourcentage: int) -> None:
        self.sidebar.set_version("telechargement", pourcentage=pourcentage)
        self.status_label.setText(f"{message} {pourcentage} %")

    def _maj_telechargee(self, chemin) -> None:
        if self.en_partie:
            # jamais de fermeture d'ORION en pleine partie : l'installateur
            # est garde et lance a la fin de la partie
            self._maj_en_attente = chemin
            log.info("Mise a jour prete, installee a la fin de la partie")
            pub = self._maj_pub
            self.sidebar.set_version("disponible", getattr(pub, "version", "") or "")
            self.notify(MESSAGE_FIN_PARTIE, 10)
            return
        self._installer_maj_maintenant(chemin)

    def _installer_maj_en_attente(self) -> bool:
        """Fin de partie : installe la mise a jour mise de cote. Vrai si
        l'installation (et donc le redemarrage) a ete lancee."""
        chemin = getattr(self, "_maj_en_attente", None)
        if not chemin or self.en_partie:
            return False
        self._maj_en_attente = None
        if not Path(chemin).exists():
            self._maj_echec("l'installateur telecharge a disparu, "
                            "il sera telecharge a nouveau")
            return False
        log.info("Fin de partie : installation de la mise a jour")
        return self._installer_maj_maintenant(chemin)

    def _installer_maj_maintenant(self, chemin) -> bool:
        self.sidebar.set_version("installation")
        QApplication.processEvents()
        if maj.installer(chemin):
            self.notify("Installation de la mise a jour : ORION va redemarrer", 10)
            # l'installateur peut fermer ORION de force : ce n'est pas un plantage
            signalement.marquer_fermeture()
            try:
                # `quit()` ne passe pas par `closeEvent` : tout est ecrit ici
                self.library.save(attendre=True)
                CONFIG.save()
            except Exception:
                log.exception("Sauvegarde avant la mise a jour impossible")
            plus_tard(self, 1200, self._quitter_pour_maj)
            return True
        self._maj_echec("lancement de l'installateur impossible")
        return False

    def _quitter_pour_maj(self) -> None:
        """Ferme ORION pour laisser l'installateur remplacer les fichiers.

        Le processus doit vraiment disparaitre : si une tache de fond
        (telechargement, traduction...) le retient apres la fermeture de la
        fenetre, il est arrete au bout de quelques secondes."""
        import os
        import threading

        def forcer():
            try:
                import logging
                logging.shutdown()
            finally:
                os._exit(0)
        garde = threading.Timer(6.0, forcer)
        garde.daemon = True
        garde.start()
        QApplication.quit()

    def _maj_echec(self, message: str) -> None:
        self._maj_en_cours = False
        self._maj_en_attente = None
        log.warning("Mise a jour impossible : %s", message)
        self.sidebar.set_version("erreur", message=message)
        QMessageBox.warning(self, "Mise a jour",
                            f"La mise a jour n'a pas pu etre installee :\n{message}\n\n"
                            "Cliquez a nouveau sur l'encart en bas a gauche pour "
                            "reessayer, ou telechargez-la depuis le site d'ORION.")

    def _lire_mesures_partagees(self) -> None:
        """Lit en arriere-plan ce que les autres joueurs obtiennent : le
        profil Recommande s'en sert pour les jeux pas encore mesures ici."""
        from .. import puissance
        Task(puissance.mesures_communaute).start()

    def _compter_ouverture(self) -> None:
        """Compteur anonyme, seulement si le joueur a dit oui."""
        try:
            from .. import compteur
            compteur.ouverture()
        except Exception:
            log.debug("Compteur indisponible", exc_info=True)

    def _proposer_partage(self) -> None:
        """Une seule fois : veut-on partager ses mesures, anonymement ?"""
        from .. import partage
        if not partage.a_demander():
            return
        from PySide6.QtWidgets import QApplication
        if QApplication.activeModalWidget() is not None:      # une fenetre est ouverte
            plus_tard(self, 60000, self._proposer_partage)
            return
        from .widgets.dialogues import DialoguePartage
        d = DialoguePartage(self)
        d.exec()
        partage.repondre(d.oui)
        # la question s'ouvre a 9 s, le compteur passe a 12 s : si le joueur
        # repond apres, l'ouverture de sa premiere session etait perdue
        # (controle des statistiques du 15 octobre)
        if d.oui:
            self._compter_ouverture()
        if d.oui and not CONFIG.get("perf.enabled", False):
            # partager suppose de mesurer : ORION installe l'outil et active
            # la mesure, sans autre demarche
            try:
                self._install_perf_tool()
            except Exception:
                log.exception("Outil de mesure non installe")
        if hasattr(self, "settings_view") and hasattr(self.settings_view, "cb_partage"):
            self.settings_view.cb_partage.setChecked(d.oui)

    # ------------------------------------------------------------------
    # votre avis (2.1.2) : sur demande seulement
    # ------------------------------------------------------------------
    def donner_avis(self) -> None:
        """Ouverte seulement par le lien « Donnez votre avis » : jamais
        d'elle-meme."""
        from .. import avis
        from .widgets.dialogues import DialogueAvis
        d = DialogueAvis(self)
        d.exec()
        if d.action != DialogueAvis.ENVOYER:
            return
        reponses, choix = d.valeurs()
        self.notify("Envoi de votre avis...")
        task = Task(avis.envoyer, reponses, choix)
        task.signals.finished.connect(lambda _n: self.notify("Avis envoye. Merci, il sera lu !", 10))
        task.signals.failed.connect(lambda _m: self._avis_par_courriel(reponses, choix))
        task.start()

    def _avis_par_courriel(self, reponses: dict, choix: str) -> None:
        """Envoi direct impossible : le message est prepare dans la messagerie."""
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QDesktopServices
        from .. import avis
        titre, texte = avis.message(reponses, choix)
        QDesktopServices.openUrl(QUrl(signalement.adresse_courriel(titre, texte, "", None)))
        self.notify("Envoi direct impossible : le message est pret dans votre "
                    "messagerie, il reste a cliquer sur Envoyer.", 12)

    def _proposer_note(self) -> None:
        """Une note sur le Store, une seule fois, au cinquieme lancement
        d'une installation venue du Store, jamais par-dessus une autre fenetre."""
        from .. import note_store
        try:
            note_store.compter_lancement()
            if not note_store.a_demander():
                return
            if QApplication.activeModalWidget() is not None:
                plus_tard(self, 120000, self._proposer_note_encore)
                return
            self._proposer_note_encore()
        except Exception:
            log.debug("Demande de note non posee", exc_info=True)

    def _proposer_note_encore(self) -> None:
        from .. import note_store
        if not note_store.a_demander() or QApplication.activeModalWidget() is not None:
            return
        from .widgets.dialogues import DialogueNote
        d = DialogueNote(self)
        d.exec()
        note_store.repondre(d.oui)

    def _montrer_nouveautes(self) -> None:
        vue = CONFIG.get("maj.derniere_vue", "") or ""
        if vue == APP_VERSION:
            return
        # premiere ouverture apres une mise a jour : un ancien utilisateur
        # (bibliotheque deja remplie) voit les nouveautes ; une toute
        # premiere installation, non
        deja_utilise = bool(vue) or bool(self.library.games(include_hidden=True))
        CONFIG.set("maj.derniere_vue", APP_VERSION)
        entrees = nouveautes.depuis(vue) if vue else nouveautes.JOURNAL[:1]
        if deja_utilise and entrees:
            self.montrer_nouveautes(entrees)

    def montrer_nouveautes(self, entrees: list | None = None) -> None:
        from .widgets.dialogues import DialogueNouveautes
        DialogueNouveautes(entrees or nouveautes.JOURNAL, self).exec()

    # ------------------------------------------------------------------
    # le bilan en une minute (2.0.2)
    # ------------------------------------------------------------------
    def _bilan_premier_lancement(self) -> None:
        """A la toute premiere installation, apres le premier scan : attend
        que l'analyse du PC et l'evaluation des jeux soient la (une minute au
        plus), puis montre le bilan. Une seule fois."""
        if CONFIG.get("bilan.montre", False):
            return
        self._bilan_attente = getattr(self, "_bilan_attente", 0) + 1
        pret = (getattr(self, "_puissance_resultats", None) is not None
                and bool(getattr(self.hw, "gpu", None) and self.hw.gpu.name))
        if (not pret and self._bilan_attente < 12) or QApplication.activeModalWidget() is not None:
            plus_tard(self, 5000, self._bilan_premier_lancement)
            return
        CONFIG.set("bilan.montre", True)
        self.montrer_bilan(premiere_fois=True)

    def calculer_bilan(self):
        from .. import bilan, valeur_catalogue
        jeux = list(self.library.games())
        resultats = getattr(self, "_puissance_resultats", None)
        try:
            conseils = advisor.for_system(self.hw, jeux) if getattr(self.hw, "gpu", None) else None
        except Exception:
            log.exception("Conseils non calcules pour le bilan")
            conseils = None
        return bilan.calculer(jeux, resultats, conseils, list(self.wishlist.items.values()),
                              valeur_catalogue.derniere())

    def montrer_bilan(self, premiere_fois: bool = False) -> None:
        from .widgets.dialogues import DialogueBilan
        b = self.calculer_bilan()
        d = DialogueBilan(b, self, premiere_fois)
        d.exec()
        if d.page_demandee == "partager":
            self.partager_carte(b)
            if premiere_fois:
                plus_tard(self, 400, lambda: self.montrer_bilan(False))
        elif d.page_demandee:
            self.show_page(d.page_demandee)

    def partager_carte(self, bilan=None) -> None:
        """L'image a poster, enregistree ou l'on veut (PNG)."""
        from PySide6.QtCore import QStandardPaths
        from PySide6.QtWidgets import QFileDialog
        from . import carte
        img = carte.dessiner(carte.depuis_bilan(bilan or self.calculer_bilan(), self.hw))
        # 11 octobre 2026 : la copie dans le presse-papiers ne donnait rien a
        # coller chez l'auteur ; l'image est seulement enregistree, la ou l'on veut
        images = QStandardPaths.writableLocation(QStandardPaths.StandardLocation.PicturesLocation) or str(Path.home())
        chemin, _f = QFileDialog.getSaveFileName(self, "Enregistrer l'image a partager",
                                                 str(Path(images) / "ORION-mon-pc.png"), "Image PNG (*.png)")
        if not chemin:
            return
        if not chemin.lower().endswith(".png"):
            chemin += ".png"
        if carte.enregistrer(img, chemin):
            self.notify(f"Image enregistree : {chemin}", 8)
        else:
            self.notify("L'image n'a pas pu etre enregistree a cet endroit : choisissez un autre dossier.", 8)

    # ------------------------------------------------------------------
    # signalement
    # ------------------------------------------------------------------
    def signaler_probleme(self, erreur: str = "", titre: str = "") -> None:
        from .widgets.dialogues import DialogueSignalement
        d = DialogueSignalement(self, erreur=erreur, titre=titre)
        d._rappel_rapport = lambda desc: signalement.rapport(
            desc, erreur, self.hw, self.library.games(include_hidden=True))
        if not d.exec():
            return
        titre, description, joindre = d.valeurs()
        technique = ""
        try:
            technique = signalement.rapport(
                description, erreur, self.hw, self.library.games(include_hidden=True))
            signalement.enregistrer(technique)        # copie locale, pour memoire
        except Exception:
            log.exception("Rapport technique non prepare")
        self.notify("Envoi du signalement...")
        task = Task(signalement.envoyer, titre, description, erreur,
                    technique if joindre else "")
        task.signals.finished.connect(lambda numero: self.notify(
            f"Signalement n° {numero} envoye. Merci !" if numero
            else "Signalement envoye. Merci !", 10))
        task.signals.failed.connect(
            lambda _m: self._signalement_par_courriel(titre, description, erreur))
        task.start()

    def _signalement_par_courriel(self, titre: str, description: str, erreur: str) -> None:
        """L'envoi direct a echoue (hors ligne, service indisponible) : le
        message est prepare dans la messagerie, il reste a cliquer sur Envoyer."""
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QDesktopServices
        QDesktopServices.openUrl(QUrl(
            signalement.adresse_courriel(titre, description, erreur, None)))
        self.notify("Envoi direct impossible : le message est pret dans votre "
                    "messagerie, il reste a cliquer sur Envoyer.", 12)

    def _erreur_imprevue(self, texte: str) -> None:
        from shiboken6 import isValid
        if not isValid(self) or not self.isVisible():
            return                      # fenetre fermee : rien a montrer
        self.notify("Une erreur imprevue a ete notee (Signaler un probleme pour l'envoyer)", 10)
        rep = QMessageBox.question(
            self, f"{APP_NAME} a rencontre une erreur",
            "Une erreur imprevue s'est produite. Elle a ete notee et ORION "
            "continue de fonctionner.\n\nVoulez-vous la signaler ? Un rapport "
            "sans donnees personnelles sera prepare.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if rep == QMessageBox.StandardButton.Yes:
            self.signaler_probleme(erreur=texte, titre="Erreur imprevue")

    def _pilotes_maj_recus(self) -> None:
        """Windows Update a repondu (fil de fond) : les conseils sur les
        pilotes se recomposent, tout de suite si la page est regardee."""
        hw = getattr(self, "hw", None)
        if hw is None:
            return
        self._pour_la_page("advice", lambda: self.advice_view.set_advice(
            advisor.for_system(hw, self.library.games())))

    def _proposer_signalement_arret(self) -> None:
        rep = QMessageBox.question(
            self, APP_NAME,
            "ORION s'est arrete brutalement lors de la derniere utilisation.\n\n"
            "Voulez-vous le signaler ? Le rapport contient la fin du journal, "
            "sans donnees personnelles.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if rep == QMessageBox.StandardButton.Yes:
            self.signaler_probleme(titre="Arret brutal d'ORION")

    # ------------------------------------------------------------------
    # reseau
    # ------------------------------------------------------------------
    def _etat_reseau(self, en_ligne: bool) -> None:
        self._hors_ligne = not en_ligne
        self.sidebar.set_hors_ligne(not en_ligne)
        self.notify("Connexion Internet retrouvee" if en_ligne else
                    "Hors ligne : prix, jaquettes et jeux gratuits attendront le retour du reseau",
                    8)
