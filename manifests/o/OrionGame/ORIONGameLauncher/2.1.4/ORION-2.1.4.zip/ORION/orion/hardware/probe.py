"""Sonde materielle : processeur, memoire, stockage, GPU et ecrans."""
from __future__ import annotations

import ctypes
import os
import platform
import re
import shutil
import threading
import time
from ctypes import wintypes

from ..core.logging_setup import get
from ..core.models import HardwareInfo
from ..core.paths import is_windows
from ..core.winutil import HKLM, reg_value
from .displays import enumerate_displays
from .gpu import detect_gpus
from .systeme import DELAI_MAX, collecter

log = get("hardware.sonde")

_CACHE: tuple[float, HardwareInfo] | None = None
CACHE_SECONDS = 120


class MEMORYSTATUSEX(ctypes.Structure):
    _fields_ = [
        ("dwLength", wintypes.DWORD), ("dwMemoryLoad", wintypes.DWORD),
        ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
        ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
        ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
        ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
    ]


def _ram_gb() -> float:
    if is_windows():
        try:
            st = MEMORYSTATUSEX()
            st.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(st))  # type: ignore
            return round(st.ullTotalPhys / (1024 ** 3), 1)
        except Exception:
            pass
    try:
        return round(os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / (1024 ** 3), 1)
    except Exception:
        return 0.0


def _cpu() -> tuple[str, int, int, float]:
    name = reg_value(
        HKLM, r"HARDWARE\DESCRIPTION\System\CentralProcessor\0",
        "ProcessorNameString") or platform.processor() or "Processeur inconnu"
    name = re.sub(r"\s+", " ", str(name)).strip()
    threads = os.cpu_count() or 0
    cores = threads
    try:
        import psutil
        cores = psutil.cpu_count(logical=False) or threads
    except Exception:
        pass
    ghz = 0.0
    m = re.search(r"([\d\.]+)\s*GHz", name, re.I)
    if m:
        ghz = float(m.group(1))
    else:
        mhz = reg_value(HKLM, r"HARDWARE\DESCRIPTION\System\CentralProcessor\0", "~MHz", 0)
        if mhz:
            ghz = round(int(mhz) / 1000, 1)
    return name, cores, threads, ghz


def _disks() -> list[dict]:
    out: list[dict] = []
    if is_windows():
        letters = "CDEFGHIJKLMNOPQRSTUVWXYZ"
        for letter in letters:
            root = f"{letter}:\\"
            try:
                if not os.path.exists(root):
                    continue
                usage = shutil.disk_usage(root)
            except OSError:
                continue
            if usage.total <= 0:            # lecteur de carte vide, etc.
                continue
            try:
                import ctypes
                genre = {2: "removable", 3: "fixed", 4: "network", 5: "cdrom",
                         6: "ramdisk"}.get(ctypes.windll.kernel32.GetDriveTypeW(root), "")
            except Exception:
                genre = ""
            out.append({
                "mount": root,
                "type": genre,
                "total_gb": round(usage.total / (1024 ** 3)),
                "free_gb": round(usage.free / (1024 ** 3)),
                "percent_used": round((usage.used / usage.total) * 100) if usage.total else 0,
            })
    else:
        try:
            u = shutil.disk_usage("/")
            out.append({"mount": "/", "total_gb": round(u.total / (1024 ** 3)),
                        "free_gb": round(u.free / (1024 ** 3)),
                        "percent_used": round(u.used / u.total * 100)})
        except Exception:
            pass
    return out


def _os_info() -> tuple[str, str]:
    if is_windows():
        base = r"SOFTWARE\Microsoft\Windows NT\CurrentVersion"
        name = str(reg_value(HKLM, base, "ProductName") or "Windows")
        build = str(reg_value(HKLM, base, "CurrentBuildNumber") or "")
        ubr = reg_value(HKLM, base, "UBR", "")
        display = str(reg_value(HKLM, base, "DisplayVersion") or "")
        if "11" not in name and build.isdigit() and int(build) >= 22000:
            name = name.replace("Windows 10", "Windows 11")
        if display:
            name = f"{name} {display}"
        return name, f"{build}.{ubr}" if ubr else build
    return platform.system(), platform.release()


def _score(hw: HardwareInfo) -> int:
    """Note de synthese 0-100, utilisee pour calibrer les profils."""
    gpu = hw.gpu
    g = {0: 25, 1: 45, 2: 70, 3: 90}.get(gpu.tier, 40)
    if gpu.vram_mb >= 16000:
        g += 6
    elif gpu.vram_mb and gpu.vram_mb < 8000:
        g -= 10
    c = min(hw.cpu_threads * 3.2, 30) + min(hw.cpu_ghz * 2.2, 10)
    r = 12 if hw.ram_gb >= 32 else 8 if hw.ram_gb >= 16 else 3
    return max(0, min(100, round(g * 0.62 + c * 0.26 + r * 1.0)))


def note(hw: HardwareInfo) -> int:
    """Note 0-100 affichee en tete de « Ma machine ».

    C'est celle du calculateur de puissance (RTX 4090 + Ryzen 7 9800X3D =
    100) des que la carte graphique est reconnue : la page affichait deux
    notes differentes pour le meme PC (« indice de configuration 74 » en
    haut, « Note 55 » dans le panneau), calculees de deux facons. L'ancienne
    estimation par gamme ne sert plus que pour une carte inconnue."""
    try:
        from ..puissance.estimation import machine_depuis
        calculee = machine_depuis(hw).score
        if calculee is not None:
            return max(0, min(100, int(calculee)))
    except Exception:
        log.exception("Note du calculateur indisponible")
    return _score(hw)


def _lire_systeme(sortie: dict, force: bool) -> None:
    try:
        sortie["valeur"] = collecter(force)
    except Exception:
        log.exception("Etat du systeme indisponible")


def probe(force: bool = False) -> HardwareInfo:
    """Analyse complete de la machine (resultat mis en cache 2 minutes)."""
    global _CACHE
    if _CACHE and not force and (time.time() - _CACHE[0]) < CACHE_SECONDS:
        return _CACHE[1]

    # l'etat du systeme (pilotes, reglages Windows, memoire) passe par une
    # requete PowerShell de plusieurs secondes : elle tourne en parallele
    # du reste de l'analyse (on est deja dans un fil de fond)
    etat: dict = {}
    fil = threading.Thread(target=_lire_systeme, args=(etat, force),
                           name="orion-etat-systeme", daemon=True)
    fil.start()

    name, cores, threads, ghz = _cpu()
    os_name, os_build = _os_info()
    hw = HardwareInfo(
        cpu_name=name, cpu_cores=cores, cpu_threads=threads, cpu_ghz=ghz,
        ram_gb=_ram_gb(), os_name=os_name, os_build=os_build,
        gpus=detect_gpus(), displays=enumerate_displays(), disks=_disks(),
    )
    hw.score = note(hw)
    fil.join(DELAI_MAX + 10)
    # lu par la page Conseils (optimizer/advisor.py) ; None hors Windows
    hw.systeme = etat.get("valeur")
    _CACHE = (time.time(), hw)
    try:
        # les pilotes facultatifs de Windows Update : recherche longue, en
        # fond, resultat garde un jour ; la page Conseils se recompose a
        # l'arrivee (`pilotes.maj`)
        from . import catalogues, maj_pilotes, pilotes_nvidia
        maj_pilotes.lancer(force)
        if hw.gpu.vendor == "nvidia":
            pilotes_nvidia.lancer(force)
        catalogues.lancer(hw.systeme, hw.os_build, force)
    except Exception:
        log.debug("Recherche Windows Update non lancee")
    log.info("Machine : %s / %s / %s Go / note %d",
             hw.cpu_name, hw.gpu.name, hw.ram_gb, hw.score)
    return hw
