"""Detection des jeux EA (EA Desktop / Origin)."""
from __future__ import annotations

from pathlib import Path

from ...core.logging_setup import get
from ...core.models import Game
from ...core.winutil import HKLM, dir_size, reg_subkeys, reg_value, reg_values
from .base import Scanner, detect_engine, pick_main_exe

log = get("scan.ea")

BASES = (
    r"SOFTWARE\WOW6432Node\EA Games",
    r"SOFTWARE\EA Games",
    r"SOFTWARE\WOW6432Node\Origin Games",
    r"SOFTWARE\Origin Games",
    r"SOFTWARE\WOW6432Node\Electronic Arts",
)


class EAScanner(Scanner):
    id = "ea"
    label = "EA"
    icon = "EA"
    priority = 65

    def _entries(self) -> list[tuple[str, str]]:
        out = []
        for base in BASES:
            for sub in reg_subkeys(HKLM, base):
                out.append((base, sub))
        return out

    def available(self) -> bool:
        return bool(self._entries())

    def scan(self) -> list[Game]:
        games: list[Game] = []
        seen: set[str] = set()
        for base, sub in self._entries():
            v = reg_values(HKLM, f"{base}\\{sub}")
            path = v.get("Install Dir") or v.get("InstallDir") or v.get("Install Location") \
                or reg_value(HKLM, f"{base}\\{sub}", "")
            if not path:
                continue
            p = Path(str(path).rstrip("\\"))
            if not p.is_dir() or str(p).lower() in seen:
                continue
            seen.add(str(p).lower())
            title = v.get("DisplayName") or p.name
            content_id = v.get("ContentID") or v.get("Content ID") or sub

            games.append(self._mk(
                title=title,
                source_id=str(content_id),
                install_dir=str(p),
                executable=pick_main_exe(p, title),
                launch_uri=f"origin2://game/launch?offerIds={content_id}"
                           if content_id else "",
                size_bytes=dir_size(p, 8000),
                engine=detect_engine(p),
            ))
        log.info("%d jeux EA", len(games))
        return games
