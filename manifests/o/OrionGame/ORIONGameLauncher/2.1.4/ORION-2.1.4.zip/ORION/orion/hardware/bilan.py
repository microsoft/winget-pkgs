"""Bilan de configuration : ou ca coince, et pourquoi.

Un joueur qui regarde sa fiche technique voit des chiffres ; ce qu'il veut
savoir tient en une phrase : « est-ce que ma machine est equilibree, et
sinon qu'est-ce qui freine ? »

Ce module repond sans reseau et sans cle : il croise le processeur, la
carte graphique, la memoire, les disques et les ecrans pour reperer les
desequilibres connus. L'assistant IA, quand il est configure, part de ce
bilan pour aller plus loin — il ne le remplace pas.

Le vocabulaire est explique en clair : « goulot d'etranglement » n'est pas
un mot que tout le monde emploie.
"""
from __future__ import annotations

import re
import time
from dataclasses import dataclass

from ..core.logging_setup import get
from ..core.models import HardwareInfo

log = get("materiel.bilan")

#: definition affichee en tete du bilan, une fois pour toutes
DEFINITION = (
    "Un « goulot d'etranglement » (bottleneck), c'est le composant le plus "
    "lent de la chaine : celui qui fixe la cadence pour tous les autres. "
    "Une carte graphique puissante bridee par un processeur trop juste "
    "tourne au rythme du processeur, et la moitie de sa puissance ne sert a "
    "rien. Ce n'est pas une panne : c'est un desequilibre, et il se corrige "
    "souvent par un reglage plutot que par un achat.")


@dataclass
class Point:
    """Un constat du bilan."""
    level: str            # "ok" | "conseil" | "attention"
    title: str
    detail: str

    @property
    def rank(self) -> int:
        return {"attention": 0, "conseil": 1, "ok": 2}.get(self.level, 3)


def _cpu_generation(name: str) -> int:
    """Annee approximative du processeur, devinee depuis son nom.

    Sert uniquement a reperer un ecart de generation franc entre le
    processeur et la carte graphique ; une estimation grossiere suffit.
    """
    texte = (name or "").lower()
    intel = re.search(r"i[3579][- ]?(\d{4,5})", texte)
    if intel:
        numero = intel.group(1)
        gen = int(numero[:2]) if len(numero) == 5 else int(numero[0])
        return 2008 + gen                      # i7-9700K -> 2017, approx.
    ryzen = re.search(r"ryzen\s+\d\s+(\d{4})", texte)
    if ryzen:
        serie = int(ryzen.group(1)[0])
        return {1: 2017, 2: 2018, 3: 2019, 5: 2020, 7: 2022, 9: 2023}.get(
            serie, 2020)
    return 0


def _screen_pixels(hw: HardwareInfo) -> int:
    ecran = hw.primary_display
    mode = (ecran.native or ecran.current) if ecran else None
    return mode.pixels if mode else 1920 * 1080


def analyse(hw: HardwareInfo) -> list[Point]:
    """Les desequilibres visibles sur cette machine."""
    points: list[Point] = []
    gpu = hw.gpu
    vram = (gpu.vram_mb or 0) / 1024
    pixels = _screen_pixels(hw)
    coeurs = hw.cpu_cores or hw.cpu_threads or 0

    # -- equilibre processeur / carte graphique -------------------------
    annee = _cpu_generation(hw.cpu_name)
    if gpu.tier >= 2 and coeurs and coeurs <= 8 and annee and annee <= 2018 \
            and pixels >= 2560 * 1440:
        # 10 octobre (test sur le PC de l'auteur, Core i9-9900K, RTX 3080,
        # ecran 2560x1440) : « le processeur freine la carte graphique » en
        # tete de Ma machine, alors que l'estimation jeu par jeu, juste
        # dessous, donnait la carte graphique comme premier frein. A cette
        # definition, c'est la carte qui travaille : un simple conseil.
        points.append(Point(
            "conseil", "Processeur plus ancien que la carte graphique",
            f"{hw.cpu_name} ({coeurs} coeurs) date d'avant 2019, {gpu.name} est "
            "du haut du panier. Sur votre ecran, c'est surtout la carte "
            "graphique qui fixe les images par seconde ; le processeur ne "
            "retient que les jeux qui calculent beaucoup (mondes ouverts, "
            "strategie, tir competitif a tres haute frequence)."))
    elif gpu.tier >= 2 and coeurs and coeurs <= 8 and annee and annee <= 2018:
        points.append(Point(
            "attention", "Le processeur freine la carte graphique",
            f"{hw.cpu_name} ({coeurs} coeurs) date d'avant 2019, alors que "
            f"{gpu.name} appartient au haut du panier. En 1080p et dans les "
            "jeux qui calculent beaucoup (mondes ouverts, strategie, tir "
            "competitif), c'est le processeur qui fixera le nombre "
            "d'images par seconde. Jouer dans une definition plus haute "
            "rend la main a la carte graphique : le desequilibre "
            "s'estompe."))
    elif gpu.tier >= 2 and coeurs and coeurs < 6:
        points.append(Point(
            "attention", "Trop peu de coeurs pour cette carte graphique",
            f"{coeurs} coeurs, c'est le minimum des jeux recents. La carte "
            "ne sera pas exploitee a fond, surtout en multijoueur."))
    elif gpu.tier <= 1 and coeurs >= 8:
        points.append(Point(
            "conseil", "La carte graphique est le maillon faible",
            f"{gpu.name or 'La carte graphique'} limite l'ensemble : le "
            "processeur a de la marge. C'est la situation la plus "
            "confortable a corriger, puisqu'une carte se remplace seule."))
    elif gpu.name and coeurs:
        points.append(Point(
            "ok", "Configuration equilibree",
            "Le processeur et la carte graphique sont de niveaux "
            "comparables : aucun des deux ne bride l'autre de facon "
            "systematique."))

    # -- memoire vive ---------------------------------------------------
    if hw.ram_gb and hw.ram_gb < 12:
        points.append(Point(
            "attention", "Memoire vive juste",
            f"{hw.ram_gb:.0f} Go : les jeux recents en demandent 16. En "
            "dessous, Windows compense sur le disque, ce qui provoque des "
            "saccades regulieres meme quand la carte graphique s'ennuie."))
    elif hw.ram_gb and hw.ram_gb < 16:
        points.append(Point(
            "conseil", "16 Go seraient plus confortables",
            f"{hw.ram_gb:.0f} Go suffisent encore, mais plus pour longtemps "
            "avec un navigateur ouvert a cote."))

    # -- memoire video contre definition d'ecran ------------------------
    if vram:
        besoin = 6 if pixels <= 1920 * 1080 else (8 if pixels <= 2560 * 1440
                                                  else 12)
        if vram + 0.4 < besoin:
            points.append(Point(
                "attention", "Memoire video juste pour cet ecran",
                f"{vram:.0f} Go de memoire video pour un ecran de "
                f"{int(pixels / 1_000_000)} millions de pixels : les "
                f"textures en qualite haute demandent plutot {besoin} Go. "
                "Baisser d'un cran la qualite des textures coute peu en "
                "image et supprime les a-coups."))
        else:
            points.append(Point(
                "ok", "Memoire video suffisante",
                f"{vram:.0f} Go couvrent la definition de votre ecran, "
                "textures comprises."))

    # -- ecran exploite ? -----------------------------------------------
    ecran = hw.primary_display
    if ecran is not None and ecran.current and ecran.native:
        if ecran.current.refresh + 5 < ecran.max_refresh_at_native:
            points.append(Point(
                "attention", "L'ecran ne tourne pas a sa frequence maximale",
                f"{ecran.name or 'Votre ecran'} est regle sur "
                f"{ecran.current.refresh} Hz alors qu'il accepte "
                f"{ecran.max_refresh_at_native} Hz dans sa definition "
                "native. C'est de la fluidite deja payee et non utilisee ; "
                "ORION peut la retablir au lancement d'un jeu."))
        if (ecran.current.width, ecran.current.height) != \
                (ecran.native.width, ecran.native.height):
            points.append(Point(
                "conseil", "L'ecran n'est pas dans sa definition native",
                f"Regle en {ecran.current.width}x{ecran.current.height} "
                f"pour une dalle {ecran.native.width}x{ecran.native.height} : "
                "l'image est interpolee, donc plus floue qu'elle ne devrait."))

    # -- pilote graphique -----------------------------------------------
    if gpu.driver_date:
        try:
            brut = re.sub(r"[^0-9]", "", gpu.driver_date)[:8]
            if len(brut) == 8:
                stamp = time.mktime(time.strptime(brut, "%Y%m%d"))
                mois = (time.time() - stamp) / (30 * 86400)
                if mois > 8:
                    points.append(Point(
                        "conseil", "Pilote graphique ancien",
                        f"Le pilote date d'il y a {mois:.0f} mois. Les jeux "
                        "sortis depuis n'ont pas leurs optimisations."))
        except Exception:
            pass

    # -- disques ---------------------------------------------------------
    for disque in hw.disks:
        total = disque.get("total_gb") or 0
        libre = disque.get("free_gb") or 0
        if total and libre / total < 0.08:
            points.append(Point(
                "attention", f"Disque {disque.get('mount', '?')} presque plein",
                f"{libre:.0f} Go libres sur {total:.0f}. En dessous de 10 %, "
                "Windows et les jeux perdent la place dont ils ont besoin "
                "pour leurs fichiers temporaires : mises a jour qui "
                "echouent, saccades au chargement."))

    # -- fonctions modernes disponibles ----------------------------------
    atouts = [f for f in ("dlss", "fsr", "xess", "framegen", "rt", "reflex")
              if f in (gpu.features or [])]
    if atouts:
        noms = {"dlss": "DLSS", "fsr": "FSR", "xess": "XeSS",
                "framegen": "generation d'images", "rt": "ray tracing",
                "reflex": "Reflex"}
        from ..i18n import t
        points.append(Point(
            "ok", "Technologies disponibles",
            t("Votre carte sait faire : ")
            + ", ".join(t(noms[a]) for a in atouts)
            + t(". ORION les active selon le profil choisi, ce qui permet de "
                "gagner des images par seconde sans perdre en nettete.")))

    points.sort(key=lambda p: p.rank)
    return points


def verdict(points: list[Point], hw: HardwareInfo) -> str:
    """Phrase de synthese, affichee en tete du bilan."""
    alertes = [p for p in points if p.level == "attention"]
    if not points:
        return ("Materiel non detecte : le bilan n'est disponible que sous "
                "Windows.")
    if not alertes:
        return (f"Machine coherente (indice {hw.score}/100) : aucun composant "
                "n'en bride un autre de facon marquee.")
    if len(alertes) == 1:
        return f"Un point freine cette machine : {alertes[0].title.lower()}."
    return (f"{len(alertes)} points freinent cette machine. Le premier : "
            f"{alertes[0].title.lower()}.")
