"""Boutons standard des boites de dialogue dans la langue de l'application.

Qt ecrit « Yes », « No », « Cancel », « Save »... sur ses boutons standard
tant que son propre catalogue de langue n'est pas charge, et ce catalogue
n'est pas livre avec ORION.

La cause est la meme pour TOUTES les boites : message, question, saisie de
texte, choix de fichier, ou boite ecrite demain. La reponse est donc posee a
un seul endroit : un filtre sur l'application, qui renomme les boutons de
toute fenetre au moment ou elle s'affiche. Seul un bouton qui porte encore le
libelle anglais de Qt est renomme : un libelle choisi par ORION (« Installer »,
« Quitter »...) n'est jamais ecrase.
"""
from __future__ import annotations

from PySide6.QtCore import QEvent, QObject
from PySide6.QtWidgets import (QAbstractButton, QApplication, QDialog,
                               QDialogButtonBox, QWidget)

from ..i18n import t

#: libelle anglais de Qt -> libelle ORION (cle sans accent, traduite par le
#: catalogue de la langue active)
LIBELLES = {
    "ok": "OK", "yes": "Oui", "no": "Non", "cancel": "Annuler",
    "close": "Fermer", "save": "Enregistrer", "save all": "Tout enregistrer",
    "discard": "Ne pas enregistrer", "don't save": "Ne pas enregistrer",
    "close without saving": "Ne pas enregistrer",
    "retry": "Reessayer", "ignore": "Ignorer", "abort": "Abandonner",
    "open": "Ouvrir", "apply": "Appliquer", "reset": "Reinitialiser",
    "restore defaults": "Valeurs par defaut", "help": "Aide",
    "yes to all": "Oui pour tout", "no to all": "Non pour tout",
    "show details...": "Afficher les details...",
    "hide details...": "Masquer les details...",
}


def _cle(texte: str) -> str:
    return (texte or "").replace("&", "").strip().lower()


def renommer(fenetre: QWidget) -> int:
    """Renomme les boutons standard d'une fenetre, quelle qu'elle soit.
    Retourne le nombre de boutons changes."""
    n = 0
    for boite in fenetre.findChildren(QDialogButtonBox):
        for bouton in boite.findChildren(QAbstractButton):
            libelle = LIBELLES.get(_cle(bouton.text()))
            if libelle:
                bouton.setText(t(libelle))
                n += 1
    return n


class BoutonsTraduits(QObject):
    def eventFilter(self, objet, event) -> bool:      # noqa: N802
        if event.type() == QEvent.Type.Show and isinstance(objet, QDialog):
            try:
                renommer(objet)
            except Exception:
                pass
        return False


def installer(app: QApplication) -> BoutonsTraduits:
    filtre = BoutonsTraduits(app)
    app.installEventFilter(filtre)
    return filtre
