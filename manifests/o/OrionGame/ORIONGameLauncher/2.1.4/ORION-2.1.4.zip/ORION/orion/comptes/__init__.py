"""Comptes des plateformes de jeu (1.8).

`PLATEFORMES` liste celles qu'ORION sait connecter ; `CATALOGUE` decrit
toutes les plateformes affichees dans la page Comptes, y compris celles
qui restent en lecture locale (Ubisoft, Rockstar, Battle.net...), pour
que le joueur sache exactement ce qui est possible et pourquoi.
"""
from __future__ import annotations

from .base import (NATURES, ConnexionRequise, JeuCompte, Plateforme, Profil,
                   Succes, resume_succes)
from .gog import GOG
from .steam import Steam
from .xbox import Xbox

PLATEFORMES: dict[str, Plateforme] = {p.id: p for p in (Steam(), GOG(), Xbox())}

#: plateformes sans connexion en 1.8 : (id, nom, nature, explication)
CATALOGUE_LOCAL = [
    ("epic", "Epic Games", "local",
     "Jeux installes et possedes lus sur le PC. La connexion du compte (succes) "
     "n'est pas encore proposee par ORION."),
    ("ea", "EA app", "local",
     "Jeux installes lus sur le PC. La connexion du compte n'est pas encore "
     "proposee par ORION."),
    ("ubisoft", "Ubisoft Connect", "local",
     "Ubisoft ne propose aucune connexion pour les applications tierces sans "
     "donner son mot de passe : ORION lit les jeux installes et lance Ubisoft Connect."),
    ("rockstar", "Rockstar Games", "local",
     "Rockstar n'a aucun acces pour les applications tierces : ORION detecte les "
     "jeux installes et ouvre le Rockstar Games Launcher."),
    ("battlenet", "Battle.net", "local",
     "Blizzard n'expose pas la bibliotheque des comptes : ORION detecte les jeux "
     "installes et lance Battle.net."),
]


def plateforme(pid: str) -> Plateforme | None:
    return PLATEFORMES.get(pid)


def doublons(par_plateforme: dict[str, list[str]]) -> list[tuple[str, list[str]]]:
    """Jeux presents sur plusieurs plateformes : [(titre, [plateformes])],
    par ordre alphabetique.

    `par_plateforme` : nom de la plateforme -> titres des jeux qu'elle
    porte (compte connecte, jeux installes, jeux possedes lus sur le PC).
    Deux titres sont le meme jeu s'ils se lisent pareil une fois
    normalises (casse, ponctuation, mentions d'edition : « Jeu » et « Jeu -
    Deluxe Edition » sont le meme jeu, comme dans la bibliotheque)."""
    from ..core.models import normalize_title
    vus: dict[str, tuple[str, list[str]]] = {}
    for nom, titres in par_plateforme.items():
        for titre in titres:
            cle = normalize_title(titre or "")
            if not cle:
                continue
            affiche, noms = vus.setdefault(cle, (titre, []))
            if nom not in noms:
                noms.append(nom)
    return sorted(((t, sorted(n)) for t, n in vus.values() if len(n) > 1),
                  key=lambda x: x[0].lower())


__all__ = ["PLATEFORMES", "CATALOGUE_LOCAL", "NATURES", "ConnexionRequise", "JeuCompte",
           "Plateforme", "Profil", "Succes", "plateforme", "resume_succes", "doublons"]
