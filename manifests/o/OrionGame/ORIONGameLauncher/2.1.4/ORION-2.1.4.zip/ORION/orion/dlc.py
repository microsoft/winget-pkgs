"""Contenus additionnels (DLC) d'un jeu Steam : lesquels existent, lesquels
le joueur a deja, et ou acheter les autres au meilleur prix (2.0).

Trois questions, trois sources :

* **Quels DLC existent ?** La fiche Steam du jeu (`appdetails`, champ `dlc`)
  donne leurs numeros ; un appel groupe (`GetItems`, cent par appel, hors du
  quota du magasin) donne leur nom, leur prix Steam et leur image.
* **Lesquels sont deja acquis ?** Le compte Steam en ligne ne le dit pas
  (l'API des jeux possedes ignore les DLC). Le client Steam, lui, le sait :
  ORION lit ses fichiers, sur ce PC, sans compte ni cle. `packageinfo.vdf`
  decrit chaque licence du compte (un lot = les numeros qu'il debloque) et
  les manifestes des jeux installes nomment les DLC installes.
* **Ou les acheter moins cher ?** Steam, et Gamesplanet quand il vend le DLC
  (meme numero Steam, cle Steam seulement : un DLC ne marche qu'avec le jeu
  de la meme plateforme).

Regle de prudence : « deja acquis » n'est affiche que pour un DLC trouve dans
les fichiers de Steam. Si ces fichiers sont illisibles, ORION le dit et
n'affirme rien : mieux vaut un doute affiche qu'un DLC rachete.
"""
from __future__ import annotations

import json
import struct
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

from .core.logging_setup import get

log = get("dlc")

DETAILS = "https://store.steampowered.com/api/appdetails"
ITEMS = "https://api.steampowered.com/IStoreBrowseService/GetItems/v1/"
ASSETS = "https://shared.akamai.steamstatic.com/store_item_assets/"
PAGE = "https://store.steampowered.com/app/{appid}"
PAGE_TOUS = "https://store.steampowered.com/dlc/{appid}"

#: la liste des DLC d'un jeu change rarement : relue tous les trois jours
GARDER_LISTE = 3 * 86400
#: leurs prix, eux, bougent : relus toutes les trois heures
GARDER_PRIX = 3 * 3600
#: un appel groupe : au-dela, la fiche renvoie vers la page Steam des DLC
MAXIMUM = 100
#: articles Steam montres : 4 = DLC, 11 = bande originale
_TYPES = {4: "dlc", 11: "musique"}


# ---------------------------------------------------------------------------
# Modele
# ---------------------------------------------------------------------------
@dataclass
class Dlc:
    appid: str
    nom: str
    prix: float = 0.0                 # prix Steam actuel (0 = gratuit ou inconnu)
    prix_normal: float = 0.0
    remise: int = 0
    gratuit: bool = False
    #: vendu seul sur Steam (sinon : seulement dans un lot, ou retire)
    vendu: bool = True
    a_venir: bool = False
    nature: str = "dlc"
    image: str = ""
    sortie: float = 0.0
    #: remplis par `pour_jeu`, jamais gardes en memoire d'une fois sur l'autre
    acquis: bool = False
    installe: bool = False
    offres: list = field(default_factory=list)

    @property
    def cle(self) -> str:
        return self.appid

    @property
    def titre(self) -> str:
        return self.nom

    @property
    def meilleure(self):
        """L'offre la moins chere (Steam ou Gamesplanet), ou None."""
        return min(self.offres, key=lambda o: o.prix) if self.offres else None

    def to_dict(self) -> dict:
        d = asdict(self)
        for cle in ("acquis", "installe", "offres"):
            d.pop(cle, None)
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "Dlc":
        champs = cls.__dataclass_fields__
        return cls(**{k: v for k, v in (d or {}).items()
                      if k in champs and k not in ("acquis", "installe", "offres")})


@dataclass
class Possession:
    """Ce que le client Steam de ce PC dit des DLC."""
    acquis: frozenset = frozenset()       # numeros debloques par une licence
    installes: frozenset = frozenset()    # numeros des DLC installes
    #: vrai quand les licences ont pu etre lues : sans cela, ORION ne sait
    #: pas ce qui manque et ne doit rien affirmer
    verifie: bool = False
    #: vrai quand un client Steam est installe sur ce PC
    client: bool = False
    #: comptes Steam deja connectes sur ce PC : le client garde les licences
    #: de tous, sans dire a qui elles sont (0 = inconnu)
    comptes: int = 0


@dataclass
class Resultat:
    """Les DLC d'un jeu, prets a afficher."""
    appid: str
    dlc: list = field(default_factory=list)
    #: DLC non montres (jeu a plus de cent DLC)
    autres: int = 0
    verifie: bool = False
    client: bool = False
    comptes: int = 0
    #: vrai quand Steam n'a pas repondu : rien a conclure, reessayer plus tard
    indisponible: bool = False

    @property
    def acquis(self) -> int:
        return sum(1 for d in self.dlc if d.acquis)


# ---------------------------------------------------------------------------
# 1) Quels DLC existent ?
# ---------------------------------------------------------------------------
def _table(nom: str):
    from .core.base import Table
    return Table(nom)


def _numeros(liste) -> list[str]:
    vus, out = set(), []
    for a in liste or []:
        a = str(a).strip()
        if a.isdigit() and a != "0" and a not in vus:
            vus.add(a)
            out.append(a)
    return out


def memoriser(appid, liste) -> None:
    """Retient la liste des DLC d'un jeu. Appele par tout module qui lit la
    fiche Steam complete d'un jeu : la fiche n'est pas demandee deux fois."""
    appid = str(appid or "").strip()
    if not appid.isdigit():
        return
    try:
        _table("dlc_jeu").set(appid, {"le": time.time(), "dlc": _numeros(liste)})
    except Exception:
        log.debug("Liste des DLC de %s non gardee", appid)


def liste(appid) -> list[str] | None:
    """Numeros des DLC d'un jeu, les plus recents d'abord. `None` quand Steam
    n'a pas repondu (a ne pas confondre avec « aucun DLC »)."""
    appid = str(appid or "").strip()
    if not appid.isdigit():
        return []
    memo = _table("dlc_jeu").get(appid) or {}
    if memo and time.time() - float(memo.get("le") or 0) < GARDER_LISTE:
        return _numeros(memo.get("dlc"))
    from .core import region, reseau, steam_limite
    if steam_limite.en_pause():
        return _numeros(memo.get("dlc")) if memo else None
    try:
        r = reseau.get(DETAILS, params={"appids": appid, "cc": region.cc(),
                                        "l": region.langue_steam(), "filters": "basic"},
                       headers=steam_limite.NAVIGATEUR, timeout=12)
        corps = r.json() if r.status_code == 200 else None
        if r.status_code in (403, 429) or corps is None:
            steam_limite.signaler_refus()
            raise ValueError(f"HTTP {r.status_code}")
        bloc = steam_limite.fiche(corps, appid)
    except Exception as exc:
        log.info("DLC de %s : fiche Steam indisponible (%s)", appid, exc)
        return _numeros(memo.get("dlc")) if memo else None
    # « success: false » : jeu sans fiche (retire de la vente) -> pas de DLC
    trouves = _numeros(((bloc.get("data") or {}).get("dlc")) if bloc.get("success") else [])
    memoriser(appid, trouves)
    return trouves


def _centimes(valeur) -> float:
    try:
        return round(int(str(valeur).strip()) / 100, 2)
    except (TypeError, ValueError):
        return 0.0


def lire_item(it: dict) -> Dlc | None:
    """Un article `GetItems` -> un `Dlc` (fonction pure, testee). `None` pour
    un article absent, cache, ou qui n'est ni un DLC ni une bande originale."""
    if not isinstance(it, dict) or it.get("success", 1) != 1 or it.get("visible") is False:
        return None
    appid = str(it.get("appid") or it.get("id") or "")
    nom = " ".join(str(it.get("name") or "").split())
    nature = _TYPES.get(it.get("type"))
    if not appid.isdigit() or not nom or nature is None:
        return None
    option = it.get("best_purchase_option") or {}
    prix = _centimes(option.get("final_price_in_cents"))
    normal = _centimes(option.get("original_price_in_cents")) or prix
    gratuit = bool(it.get("is_free")) or (bool(option) and prix <= 0)
    try:
        remise = int(option.get("discount_pct") or 0)
    except (TypeError, ValueError):
        remise = 0
    if not remise and normal > prix > 0:
        remise = int(round(100 - prix * 100 / normal))
    sortie = it.get("release") or {}
    assets = it.get("assets") or {}
    modele, fichier = assets.get("asset_url_format") or "", assets.get("header") or ""
    return Dlc(
        appid=appid, nom=nom[:160], prix=prix, prix_normal=max(normal, prix), remise=remise,
        gratuit=gratuit, vendu=bool(option) or gratuit,
        a_venir=bool(sortie.get("is_coming_soon")), nature=nature,
        image=(ASSETS + modele.replace("${FILENAME}", fichier)) if modele and fichier else "",
        sortie=float(sortie.get("steam_release_date") or 0))


def fiches(appids) -> dict[str, Dlc] | None:
    """{numero: Dlc} pour une liste de DLC (cent par appel, gardes trois
    heures). `None` quand rien n'a pu etre lu."""
    from .core import region, reseau, steam_limite
    table = _table("dlc_fiches")
    out: dict[str, Dlc] = {}
    a_demander = []
    for a in _numeros(appids):
        m = table.get(a) or {}
        if m and time.time() - float(m.get("le") or 0) < GARDER_PRIX:
            if m.get("fiche"):
                out[a] = Dlc.from_dict(m["fiche"])
        else:
            a_demander.append(a)
    echec = False
    for i in range(0, len(a_demander), 100):
        lot = a_demander[i:i + 100]
        requete = json.dumps({
            "ids": [{"appid": int(a)} for a in lot],
            "context": {"language": region.langue_steam(),
                        "country_code": (region.pays() or "FR").upper(), "steam_realm": 1},
            "data_request": {"include_all_purchase_options": True, "include_assets": True,
                             "include_release": True}})
        try:
            r = reseau.get(ITEMS, params={"input_json": requete},
                           headers=steam_limite.NAVIGATEUR, timeout=20)
            r.raise_for_status()
            items = ((r.json() or {}).get("response") or {}).get("store_items") or []
        except Exception as exc:
            log.info("Fiches des DLC indisponibles : %s", exc)
            echec = True
            # prix perimes plutot que rien : ils sont marques par leur date
            for a in lot:
                m = table.get(a) or {}
                if m.get("fiche"):
                    out[a] = Dlc.from_dict(m["fiche"])
            continue
        vus = set()
        for it in items:
            a = str((it or {}).get("appid") or (it or {}).get("id") or "")
            if a not in lot:
                continue
            vus.add(a)
            d = lire_item(it)
            table.set(a, {"le": time.time(), "fiche": d.to_dict() if d else None})
            if d:
                out[a] = d
        for a in lot:
            if a not in vus:
                table.set(a, {"le": time.time(), "fiche": None})
    return None if (echec and not out) else out


# ---------------------------------------------------------------------------
# 2) Lesquels sont deja acquis ? (fichiers du client Steam)
# ---------------------------------------------------------------------------
class FichierInattendu(ValueError):
    pass


def _chaine(donnees: bytes, i: int) -> tuple[str, int]:
    fin = donnees.find(b"\x00", i)
    if fin < 0:
        raise FichierInattendu("chaine sans fin")
    return donnees[i:fin].decode("utf-8", "replace"), fin + 1


def _cles_valeurs(donnees: bytes, i: int, profondeur: int = 0) -> tuple[dict, int]:
    """Lit un dictionnaire « KeyValues » binaire de Valve a partir de `i`."""
    if profondeur > 24:
        raise FichierInattendu("imbrication trop profonde")
    out: dict = {}
    while True:
        if i >= len(donnees):
            raise FichierInattendu("fin de fichier dans un dictionnaire")
        genre = donnees[i]
        i += 1
        if genre in (0x08, 0x0B):                    # fin du dictionnaire
            return out, i
        cle, i = _chaine(donnees, i)
        if genre == 0x00:                            # sous-dictionnaire
            out[cle], i = _cles_valeurs(donnees, i, profondeur + 1)
        elif genre == 0x01:                          # chaine
            out[cle], i = _chaine(donnees, i)
        elif genre in (0x02, 0x04, 0x06):            # entier 32 bits, pointeur, couleur
            out[cle] = struct.unpack_from("<i", donnees, i)[0]
            i += 4
        elif genre == 0x03:                          # flottant
            out[cle] = struct.unpack_from("<f", donnees, i)[0]
            i += 4
        elif genre in (0x07, 0x0A):                  # entiers 64 bits
            out[cle] = struct.unpack_from("<q", donnees, i)[0]
            i += 8
        elif genre == 0x05:                          # chaine large (UTF-16)
            fin = i
            while donnees[fin:fin + 2] not in (b"\x00\x00", b""):
                fin += 2
            out[cle] = donnees[i:fin].decode("utf-16-le", "replace")
            i = fin + 2
        else:
            raise FichierInattendu(f"type {genre:#x} inconnu")


def lire_packageinfo(donnees: bytes) -> dict[int, set[str]]:
    """`appcache/packageinfo.vdf` -> {numero de lot: numeros debloques}.

    Format : en-tete (version sur un octet + « UV\\x06 », puis l'univers),
    puis pour chaque lot : son numero, une empreinte de 20 octets, un numero
    de modification, un jeton (8 octets, a partir de la version 0x28) et ses
    donnees en « KeyValues » binaire ; le numero 0xFFFFFFFF termine la liste.
    Tout ecart leve `FichierInattendu` : un fichier a moitie compris ne doit
    jamais servir a dire « vous n'avez pas ce DLC ».
    """
    if len(donnees) < 8 or donnees[1:4] != b"UV\x06" or donnees[0] not in (0x27, 0x28):
        raise FichierInattendu("en-tete de packageinfo inconnu")
    try:
        return _lots(donnees, avec_jeton=donnees[0] >= 0x28)
    except (struct.error, IndexError, RecursionError) as exc:
        # fichier coupe au milieu d'une valeur : meme prudence
        raise FichierInattendu(f"packageinfo tronque ({exc})") from None


def _lots(donnees: bytes, avec_jeton: bool) -> dict[int, set[str]]:
    i = 8
    lots: dict[int, set[str]] = {}
    while True:
        if i + 4 > len(donnees):
            raise FichierInattendu("liste des lots tronquee")
        numero = struct.unpack_from("<I", donnees, i)[0]
        i += 4
        if numero == 0xFFFFFFFF:
            return lots
        i += 20 + 4 + (8 if avec_jeton else 0)
        racine, i = _cles_valeurs(donnees, i)
        lot = next((v for v in racine.values() if isinstance(v, dict)), racine)
        if lot.get("packageid") not in (None, numero) and len(racine) == 1:
            raise FichierInattendu(f"lot {numero} : donnees d'un autre lot")
        apps = lot.get("appids")
        lots[numero] = {str(v) for v in apps.values() if isinstance(v, int) and v > 0} \
            if isinstance(apps, dict) else set()


def dlc_installes(manifeste: dict) -> set[str]:
    """DLC installes d'apres un manifeste de jeu (`appmanifest_*.acf` deja
    lu) : chaque depot installe d'un DLC porte son numero (`dlcappid`)."""
    etat = manifeste.get("AppState") or manifeste.get("appstate") or {}
    depots = etat.get("InstalledDepots") or etat.get("installeddepots") or {}
    out = set()
    for depot in depots.values() if isinstance(depots, dict) else ():
        if isinstance(depot, dict):
            a = str(depot.get("dlcappid") or depot.get("DlcAppId") or "").strip()
            if a.isdigit() and a != "0":
                out.add(a)
    return out


def comptes_steam(racine: Path) -> int:
    """Nombre de comptes Steam deja connectes sur ce PC (0 si inconnu)."""
    try:
        from .core.winutil import read_vdf
        donnees = read_vdf(Path(racine) / "config" / "loginusers.vdf")
        comptes = donnees.get("users") or donnees.get("Users") or {}
        return sum(1 for k, v in comptes.items() if str(k).isdigit() and isinstance(v, dict))
    except Exception:
        return 0


_memo_possession: dict = {"cle": None, "valeur": Possession()}


def possession(racine: Path | None = None) -> Possession:
    """Ce que le client Steam de ce PC sait des DLC. Ne leve jamais ; relu
    seulement quand les fichiers de Steam ont change."""
    try:
        from .core.winutil import read_vdf
        from .plugins.scanners.steam import steam_libraries, steam_root
        racine = racine or steam_root()
        if racine is None:
            return Possession()
        paquets = Path(racine) / "appcache" / "packageinfo.vdf"
        manifestes = []
        for bib in steam_libraries(Path(racine)):
            dossier = bib / "steamapps"
            if dossier.is_dir():
                manifestes += sorted(dossier.glob("appmanifest_*.acf"))

        def empreinte(p: Path):
            try:
                s = p.stat()
                return (str(p), s.st_mtime_ns, s.st_size)
            except OSError:
                return (str(p), 0, 0)
        connexions = Path(racine) / "config" / "loginusers.vdf"
        cle = (empreinte(paquets), empreinte(connexions),
               tuple(empreinte(m) for m in manifestes))
        if _memo_possession["cle"] == cle:
            return _memo_possession["valeur"]

        installes: set[str] = set()
        for m in manifestes:
            try:
                installes |= dlc_installes(read_vdf(m))
            except Exception:
                log.debug("Manifeste illisible : %s", m)
        acquis, verifie = set(installes), False
        try:
            lots = lire_packageinfo(paquets.read_bytes())
            sous_licence = set().union(*lots.values()) if lots else set()
            # des lots mais aucun numero : le format a change, rien a conclure
            if lots and not sous_licence:
                raise FichierInattendu("aucun numero dans les lots")
            acquis |= sous_licence
            verifie = bool(sous_licence)
        except FileNotFoundError:
            log.info("DLC : packageinfo.vdf absent, licences Steam non verifiees")
        except Exception as exc:
            log.warning("DLC : licences Steam illisibles (%s)", exc)
        valeur = Possession(frozenset(acquis), frozenset(installes), verifie, client=True,
                            comptes=comptes_steam(Path(racine)))
        _memo_possession.update(cle=cle, valeur=valeur)
        log.info("DLC : %d numeros sous licence, %d DLC installes, verifie=%s",
                 len(acquis), len(installes), verifie)
        return valeur
    except Exception:
        log.exception("Lecture des DLC possedes impossible")
        return Possession()


# ---------------------------------------------------------------------------
# 3) Tout ensemble : les DLC d'un jeu, acquis ou a acheter au meilleur prix
# ---------------------------------------------------------------------------
def _offres(d: Dlc) -> list:
    from .plugins.boutique.base import Offre
    out = []
    if d.vendu and not d.gratuit and d.prix > 0 and not d.a_venir:
        out.append(Offre(titre=d.nom, boutique="Steam", prix=d.prix, prix_normal=d.prix_normal,
                         remise=d.remise, url=PAGE.format(appid=d.appid), source="steam",
                         steam_appid=d.appid, drm="Steam", type_article="dlc"))
        try:
            from . import prix_gamesplanet
            o = prix_gamesplanet.offre(d.appid, d.nom, d.prix_normal)
            # cle Steam seulement : un DLC d'une autre plateforme ne
            # s'ajouterait pas au jeu Steam du joueur
            if o is not None and o.drm == "Cle Steam":
                o.type_article = "dlc"
                out.append(o)
        except Exception:
            log.debug("Offre Gamesplanet ignoree pour le DLC %s", d.appid)
    return sorted(out, key=lambda o: o.prix)


def _rang(d: Dlc) -> int:
    """Ordre d'affichage : les DLC a acheter, ceux deja acquis, puis ce qui
    compte moins (bandes originales, DLC gratuits, a venir ou vendus en lot)."""
    if d.acquis:
        return 1
    if d.meilleure is None:
        return 3
    return 2 if d.nature == "musique" else 0


def pour_jeu(appid, racine: Path | None = None) -> Resultat:
    """Les DLC d'un jeu Steam : ceux a acheter d'abord (les plus recents en
    tete), puis ceux deja acquis, puis le reste (voir `_rang`). Ne leve jamais."""
    appid = str(appid or "").strip()
    res = Resultat(appid=appid)
    if not appid.isdigit():
        return res
    try:
        numeros = liste(appid)
        if numeros is None:
            res.indisponible = True
            return res
        if not numeros:
            return res
        res.autres = max(0, len(numeros) - MAXIMUM)
        montres = numeros[:MAXIMUM]
        connus = fiches(montres)
        if connus is None:
            res.indisponible = True
            return res
        try:
            from . import prix_gamesplanet
            prix_gamesplanet.actualiser()
        except Exception:
            pass
        etat = possession(racine)
        res.verifie, res.client, res.comptes = etat.verifie, etat.client, etat.comptes
        for a in montres:
            d = connus.get(a)
            if d is None:
                continue
            d.installe = a in etat.installes
            d.acquis = d.installe or a in etat.acquis
            d.offres = [] if d.acquis else _offres(d)
            res.dlc.append(d)
        # l'ordre de Steam (recents d'abord) est garde dans chaque groupe
        res.dlc.sort(key=_rang)
    except Exception:
        log.exception("DLC du jeu %s illisibles", appid)
        res.indisponible = True
    return res
