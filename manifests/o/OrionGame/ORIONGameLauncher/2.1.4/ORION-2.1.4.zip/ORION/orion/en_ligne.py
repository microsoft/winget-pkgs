"""Joueurs en ligne en ce moment (1.8.1).

Pour un jeu en ligne vendu sur Steam, Steam publie le nombre de joueurs
connectes a l'instant (API publique, sans cle). ORION l'affiche sur la
fiche du jeu, en disant d'ou vient le chiffre : seuls les joueurs Steam
sont comptes (pas ceux d'Epic, du Xbox, des consoles...). Les autres
editeurs ne publient pas ce chiffre : ORION n'en invente pas.

« Jeu en ligne » : categories Steam multijoueur en ligne (MMO, JcJ ou
coop en ligne, multijoueur multiplateforme), ou « Multijoueur » seul
quand rien n'indique qu'il ne se joue qu'en local.
"""
from __future__ import annotations

import time

from .core.logging_setup import get

log = get("en_ligne")

URL = "https://api.steampowered.com/ISteamUserStats/GetNumberOfCurrentPlayers/v1/"

#: categories Steam
MULTIJOUEUR = 1
EN_LIGNE = {20, 27, 36, 38}            # MMO, multiplateforme, JcJ en ligne, coop en ligne
LOCAL = {24, 37, 39, 47, 48}           # ecran partage, reseau local
GARDER = 300                           # un releve sert 5 minutes
#: le releve est rafraichi un peu AVANT 5 minutes : la fiche redemande le
#: chiffre toutes les 5 minutes, et un releve vieux de 299,9 s servirait
#: sinon 5 minutes de plus
MARGE = 15


def est_en_ligne(categories) -> bool:
    cats = {int(c) for c in categories or []}
    if cats & EN_LIGNE:
        return True
    return MULTIJOUEUR in cats and not cats & LOCAL


_memo: dict[str, tuple[float, int | None]] = {}


def joueurs(appid: str, maintenant: float | None = None) -> int | None:
    """Joueurs Steam connectes a ce jeu en ce moment (None si inconnu)."""
    appid = str(appid or "").strip()
    if not appid.isdigit():
        return None
    t = time.time() if maintenant is None else maintenant
    deja = _memo.get(appid)
    if deja and 0 <= t - deja[0] < GARDER - MARGE:
        return deja[1]
    from .core import reseau
    try:
        r = reseau.get(URL, params={"appid": appid}, timeout=10)
        corps = r.json() if r.status_code == 200 else {}
        rep = (corps or {}).get("response") or {}
        n = int(rep["player_count"]) if rep.get("result") == 1 else None
    except Exception as exc:
        log.info("Joueurs en ligne %s indisponibles : %s", appid, exc)
        return deja[1] if deja else None
    _memo[appid] = (t, n)
    return n


def texte(n: int | None) -> str:
    """« 12 345 joueurs en ligne sur Steam en ce moment »."""
    if n is None:
        return ""
    if n == 0:
        return "Personne en ligne sur Steam en ce moment"
    nombre = f"{n:,}".replace(",", " ")
    return (f"{nombre} joueur en ligne sur Steam en ce moment" if n == 1 else
            f"{nombre} joueurs en ligne sur Steam en ce moment")
