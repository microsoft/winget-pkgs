"""Lancement de programmes externes « propres » (jeux, plateformes, installateur).

Une application compilee avec PyInstaller transmet a tout ce qu'elle lance :

* son chemin de recherche des DLL (`SetDllDirectoryW(_MEIPASS)`) : un jeu ou
  un Steam demarre par ORION chargeait alors `VCRUNTIME140.dll`,
  `d3dcompiler_47.dll`... depuis le dossier d'ORION et les verrouillait ;
* son dossier courant (le dossier d'installation d'ORION) : Windows refuse
  de renommer un dossier qui est le dossier courant d'un processus ;
* des variables posees par PyInstaller (`_PYI_*`, `QT_PLUGIN_PATH`,
  `QML2_IMPORT_PATH`, `_MEIPASS` en tete de `PATH`).

Tant qu'un de ces programmes tournait, la mise a jour d'ORION echouait
(« la version precedente est encore utilisee »). Les fonctions ci-dessous
lancent un programme sans rien de tout cela.
"""
from __future__ import annotations

import os
import subprocess
import sys
import threading
from contextlib import contextmanager
from pathlib import Path

#: variables posees par le crochet PySide6 de PyInstaller
_VARIABLES_QT = ("QT_PLUGIN_PATH", "QML2_IMPORT_PATH")

#: une seule modification a la fois du chemin des DLL et de l'environnement
_verrou = threading.RLock()


def _meipass() -> str:
    return str(getattr(sys, "_MEIPASS", "") or "")


def _dans(chemin: str, dossier: str) -> bool:
    """Vrai si `chemin` est `dossier` ou se trouve dessous."""
    if not chemin or not dossier:
        return False
    c = os.path.normcase(os.path.normpath(chemin))
    d = os.path.normcase(os.path.normpath(dossier))
    return c == d or c.startswith(d.rstrip("\\/") + os.sep)


def environnement_propre(base: dict | None = None) -> dict:
    """Variables d'environnement sans les marqueurs internes de PyInstaller :
    le programme lance se comporte comme un lancement tout neuf (et non
    comme la suite du programme qui le lance)."""
    source = dict(os.environ if base is None else base)
    meipass = _meipass()
    env = {k: v for k, v in source.items()
           if not k.upper().startswith(("_PYI_", "_MEIPASS"))}
    for nom in list(env):
        if nom.upper() in _VARIABLES_QT and (getattr(sys, "frozen", False)
                                             or _dans(env[nom], meipass)):
            del env[nom]
    if meipass:
        for nom in list(env):
            if nom.upper() == "PATH":
                morceaux = [m for m in env[nom].split(os.pathsep)
                            if m and not _dans(m, meipass)]
                env[nom] = os.pathsep.join(morceaux)
    env["PYINSTALLER_RESET_ENVIRONMENT"] = "1"
    return env


def reinitialiser_dll() -> None:
    """Rend a Windows son chemin de recherche des DLL par defaut."""
    if sys.platform.startswith("win"):
        try:
            import ctypes
            ctypes.windll.kernel32.SetDllDirectoryW(None)
        except Exception:
            pass


def _restaurer_dll() -> None:
    """Remet le chemin des DLL d'ORION (celui pose par PyInstaller)."""
    meipass = _meipass()
    if sys.platform.startswith("win") and meipass:
        try:
            import ctypes
            ctypes.windll.kernel32.SetDllDirectoryW(meipass)
        except Exception:
            pass


def dossier_neutre() -> str:
    """Dossier courant donne aux programmes lances sans dossier precis."""
    try:
        from .paths import DATA_DIR
        if DATA_DIR.is_dir():
            return str(DATA_DIR)
    except Exception:
        pass
    return str(Path.home())


@contextmanager
def contexte_propre(environnement: bool = False):
    """Le temps d'un lancement : chemin des DLL par defaut et, si demande,
    environnement du processus nettoye (ShellExecute ne prend pas
    d'environnement en parametre, il transmet celui du processus)."""
    with _verrou:
        reinitialiser_dll()
        sauve: dict[str, str | None] = {}
        if environnement:
            propre = environnement_propre()
            propre.pop("PYINSTALLER_RESET_ENVIRONMENT", None)
            for nom in set(os.environ) | set(propre):
                avant = os.environ.get(nom)
                apres = propre.get(nom)
                if avant != apres:
                    sauve[nom] = avant
                    try:
                        if apres is None:
                            del os.environ[nom]
                        else:
                            os.environ[nom] = apres
                    except Exception:
                        sauve.pop(nom, None)
        try:
            yield
        finally:
            for nom, valeur in sauve.items():
                try:
                    if valeur is None:
                        os.environ.pop(nom, None)
                    else:
                        os.environ[nom] = valeur
                except Exception:
                    pass
            _restaurer_dll()


def popen_propre(args, cwd: str | os.PathLike | None = None, **kwargs) -> subprocess.Popen:
    """`subprocess.Popen` sans heritage de DLL, de dossier ni de variables
    PyInstaller. Les exceptions de Popen (dont WinError 740) remontent telles
    quelles."""
    kwargs.setdefault("env", environnement_propre())
    kwargs.setdefault("close_fds", True)
    with contexte_propre():
        return subprocess.Popen(args, cwd=str(cwd or dossier_neutre()), **kwargs)


def shell_execute(cible: str, parametres: str | None = None,
                  dossier: str | None = None, verbe: str | None = None) -> int:
    """ShellExecuteW avec un dossier courant explicite et un environnement
    propre. Rend le code de ShellExecute (> 32 : reussite)."""
    import ctypes
    with contexte_propre(environnement=True):
        return int(ctypes.windll.shell32.ShellExecuteW(   # type: ignore[attr-defined]
            None, verbe, str(cible), parametres, str(dossier or dossier_neutre()), 1))


def startfile_propre(cible: str, dossier: str | None = None) -> None:
    """Equivalent de `os.startfile` (adresse steam://, fichier, dossier),
    sans rien transmettre d'ORION. Leve OSError en cas d'echec."""
    if sys.platform.startswith("win"):
        code = shell_execute(str(cible), None, dossier)
        if code <= 32:
            raise OSError(code, f"ShellExecute a echoue ({code})", str(cible))
        return
    popen_propre(["xdg-open", str(cible)], cwd=dossier)
