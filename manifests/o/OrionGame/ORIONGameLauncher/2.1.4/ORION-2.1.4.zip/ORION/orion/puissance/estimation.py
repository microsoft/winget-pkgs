"""Moteur du calculateur de puissance (1.8).

Regle d'or : ne jamais promettre plus que ce qu'on sait. Chaque resultat
porte sa source :

* MESURE      — images par seconde relevees sur CE PC (PresentMon). Seule
                source qui autorise « Ultra ».
* COMMUNAUTE  — mesures partagees par au moins 3 joueurs ORION ayant une
                carte graphique proche (+-15 %), ramenees a votre materiel.
* ESTIME      — deduit des configurations minimale/recommandee du jeu :
                fourchette prudente, valeur basse mise en avant, jamais
                classe « Ultra ».
* INCONNU     — pas assez d'informations : on le dit plutot que d'inventer.

Hypotheses de l'estimation (conventions des editeurs, verifiees ensuite
par les mesures reelles) : la configuration recommandee vise environ
60 i/s en 1080p et reglages eleves, la minimale environ 30 i/s en 1080p et
reglages bas. Le cout de la definition suit (pixels)^0.75, la puissance
graphique (indice)^0.9. Un processeur trop faible plafonne le resultat
(« limite par le processeur »), une memoire video insuffisante interdit
les textures elevees.
"""
from __future__ import annotations

import statistics
from dataclasses import dataclass, field

from .exigences import Exigences
from .references import indice_cpu, indice_gpu, ray_tracing_materiel

PX_1080 = 1920 * 1080
SEUIL_FLUIDE = 55          # bas de fourchette pour annoncer « 60 i/s »
SEUIL_JOUABLE = 30
MARGE_BASSE, MARGE_HAUTE = 0.8, 1.1

#: ce que le processeur RECOMMANDE par un jeu sait tenir, en multiple de 60
#: images par seconde. Les editeurs recommandent le processeur de milieu de
#: gamme du moment, qui depasse largement 60 i/s : 1,3 (jusqu'a la 1.9.8)
#: classait « Basse » tout PC dont le processeur valait moins de 88 % du
#: recommande, meme quand il tient 70 i/s en jeu (Core i9-9900K dans
#: Cyberpunk 2077). Avec 1,5 le seuil passe a 77 %.
PLAFOND_CPU = 1.5

PRESETS = ("ultra", "haute", "moyenne", "basse")
NOMS = {"ultra": "Ultra", "haute": "Haute", "moyenne": "Moyenne", "basse": "Basse",
        "insuffisant": "Insuffisant"}
#: profils ORION -> niveau de reglages equivalent
PROFIL_PRESET = {"photo": "ultra", "detente": "haute", "esport": "moyenne"}

MESURE, COMMUNAUTE, ESTIME, INCONNU = "mesure", "communaute", "estime", "inconnu"
SOURCES = {MESURE: "Mesure sur votre PC", COMMUNAUTE: "Mesures de la communaute",
           ESTIME: "Estimation", INCONNU: "Pas assez d'informations"}


@dataclass
class Machine:
    gpu: float | None = None
    gpu_nom: str = ""
    cpu: float | None = None
    cpu_nom: str = ""
    vram_go: float = 0.0
    ram_go: float = 0.0
    pixels: int = PX_1080
    definition: str = "1920x1080"
    hz: int = 60
    #: mise a l'echelle que cette carte sait faire (« DLSS », « FSR »,
    #: « XeSS »), ou « » si la carte n'est pas reconnue
    mise_a_l_echelle: str = ""
    #: la carte calcule le ray tracing elle-meme ; None : d'apres son nom
    #: (`references.ray_tracing_materiel`)
    ray_tracing: bool | None = None

    @property
    def score(self) -> int | None:
        """Note globale 0-100 (100 = RTX 4090 + Ryzen 7 9800X3D)."""
        if self.gpu is None:
            return None
        g = min(self.gpu, 100)
        c = min(self.cpu if self.cpu is not None else 50, 100)
        r = min(self.ram_go / 32, 1) * 100 if self.ram_go else 50
        return round(0.65 * g + 0.28 * c + 0.07 * r)


def machine_depuis(hw) -> Machine:
    m = Machine()
    gpu = getattr(hw, "gpu", None)
    if gpu is not None and gpu.name:
        trouve = indice_gpu(gpu.name)
        if trouve:
            m.gpu, m.gpu_nom = trouve[1], gpu.name
        m.vram_go = round((gpu.vram_mb or 0) / 1024, 1)
        capacites = set(getattr(gpu, "features", None) or [])
        # FSR fonctionne sur toutes les cartes : c'est le choix par defaut
        m.mise_a_l_echelle = ("DLSS" if "dlss" in capacites
                              else "XeSS" if "xess" in capacites else "FSR")
    trouve = indice_cpu(getattr(hw, "cpu_name", "") or "")
    if trouve:
        m.cpu, m.cpu_nom = trouve[1], hw.cpu_name
    m.ram_go = float(getattr(hw, "ram_gb", 0) or 0)
    ecran = hw.primary_display if hasattr(hw, "primary_display") else None
    if ecran is not None:
        # definition a laquelle on joue : le mode natif de l'ecran (sinon le mode actuel)
        mode = getattr(ecran, "native", None) or getattr(ecran, "current", None)
        if mode is not None and mode.width and mode.height:
            m.pixels, m.definition = mode.width * mode.height, f"{mode.width}x{mode.height}"
            m.hz = int(getattr(ecran, "max_refresh_at_native", 0) or mode.refresh or 60)
    return m


@dataclass
class Evaluation:
    titre: str
    appid: str = ""
    uid: str = ""
    source: str = INCONNU
    niveau: str = ""                         # meilleur preset fluide (ou « insuffisant »)
    fps: dict[str, tuple[int, int]] = field(default_factory=dict)   # preset -> (bas, haut)
    limite: str = ""                         # gpu, cpu, vram, ram
    notes: list[str] = field(default_factory=list)
    installe: bool = False
    #: ce qui retient le jeu sous « Haute » (gpu, cpu, vram, ram ; « » : rien
    #: ou inconnu). A ne pas confondre avec `limite`, qui dit seulement que le
    #: processeur plafonne les images au niveau retenu.
    frein: str = ""
    #: le niveau retenu tient environ 60 images/s. Faux pour un jeu « jouable
    #: sans plus » (estimation) : le niveau dit alors quels reglages choisir,
    #: pas que le jeu est fluide.
    fluide: bool = True
    #: l'estimation part de la configuration « recommandee » ou « minimale »
    base: str = ""
    #: correction appliquee aux estimations de CE PC (voir `calibrer`)
    calibration: float = 1.0
    #: ce qui rend le jeu jouable un niveau au-dessus sans rien acheter
    #: (« Moyenne avec DLSS »), et ce niveau ; vides si rien ne l'ameliore
    piste: str = ""
    niveau_piste: str = ""
    #: le jeu ne se lance pas sur cette machine, quels que soient les
    #: reglages (« ray_tracing » : il exige une carte avec ray tracing
    #: materiel) ; « » sinon
    bloque: str = ""

    @property
    def fps_niveau(self) -> tuple[int, int] | None:
        return self.fps.get(self.niveau)

    @property
    def fps_affiche(self) -> tuple[tuple[int, int], str] | None:
        """Fourchette a afficher et le niveau auquel elle correspond : celle
        du niveau retenu, sinon (niveau jamais mesure, ex. « Basse » deduit
        d'une mesure en Ultra) la mesure du niveau le plus eleve disponible."""
        if self.niveau in self.fps:
            return self.fps[self.niveau], self.niveau
        if not self.niveau:
            return None
        # insuffisant : le niveau le plus bas connu montre l'ecart ; sinon
        # le plus eleve mesure
        ordre = reversed(PRESETS) if self.niveau == "insuffisant" else PRESETS
        for p in ordre:
            if p in self.fps:
                return self.fps[p], p
        return None


def _res(machine: Machine, reference: int = PX_1080) -> float:
    """Cout de la definition du joueur par rapport a celle de reference."""
    return min((reference / max(machine.pixels, 1)) ** 0.75, 1.3)


#: images/s d'un niveau rapportees au niveau « haute » (meme rapport que
#: `valeurs` dans `estimer`) : un objectif donne en « Moyen » vaut des
#: reglages eleves 1,3 fois plus lents
FACTEUR_NIVEAU = {"basse": 1.75, "moyenne": 1.3, "haute": 1.0, "ultra": 1.0}


#: gain de la generation d'images en jeu : NVIDIA et AMD annoncent « jusqu'a
#: 2 fois », les essais de la presse donnent 1,5 a 2 ; 1,7 au milieu
GAIN_GENERATION = 1.7


def _images_editeur(c, defaut: int) -> float:
    """Images/s que la carte de cette configuration calcule vraiment pour
    l'objectif de l'editeur : avec la generation d'images, environ six sur
    dix des images affichees (13 octobre 2026, Monster Hunter Wilds)."""
    ips = float(c.cible_fps or defaut)
    return ips / GAIN_GENERATION if getattr(c, "generation_images", False) else ips


#: le jeu exige une carte avec ray tracing materiel et celle-ci n'en a pas
RAY_TRACING = "ray_tracing"
NOTE_RAY_TRACING = ("Le jeu exige une carte graphique avec ray tracing materiel (GeForce RTX, Radeon RX 6000 "
                    "ou plus recente, Intel Arc) : il ne se lance pas sur la votre, quels que soient les reglages.")


def blocage(exig: Exigences | None, machine: Machine) -> str:
    """Ce qui empeche le jeu de demarrer sur cette machine, quelle que soit sa
    puissance (« ray_tracing »), ou « » (rien, ou on ne sait pas : une carte
    non reconnue n'est jamais declaree incapable)."""
    if exig is None or not getattr(exig, "ray_tracing", False):
        return ""
    rt = machine.ray_tracing if machine.ray_tracing is not None else ray_tracing_materiel(machine.gpu_nom)
    return RAY_TRACING if rt is False else ""


def _fourchette(v: float) -> tuple[int, int]:
    return int(v * MARGE_BASSE), int(v * MARGE_HAUTE)


def estimer(titre: str, exig: Exigences | None, machine: Machine,
            calibration: float = 1.0) -> Evaluation:
    ev = Evaluation(titre=titre, appid=exig.appid if exig else "")
    if machine.gpu is None:
        ev.notes.append("Carte graphique non reconnue : estimation impossible.")
        return ev
    if exig is None or not exig.exploitable:
        ev.notes.append("Configurations du jeu inconnues.")
        return ev
    rec, mini = exig.recommandee, exig.minimum
    cause = blocage(exig, machine)
    if cause:
        # 13 octobre 2026 : DOOM: The Dark Ages annonce « Bas, 42 a 58 i/s »
        # sur une GTX 1660 Super, ou il ne demarre pas. Aucune fourchette :
        # il n'y a pas d'images a promettre.
        ev.source, ev.niveau, ev.bloque = ESTIME, "insuffisant", cause
        ev.frein, ev.limite, ev.fluide = "gpu", "rt", False
        ev.base = "recommandee" if rec and rec.gpu else "minimale"
        ev.notes.append(NOTE_RAY_TRACING)
        return ev
    if rec and rec.gpu:
        ref = rec
        haute = _images_editeur(rec, 60) / FACTEUR_NIVEAU.get(rec.cible_niveau or "haute", 1.0) \
            * (machine.gpu / rec.gpu) ** 0.9
        base = "recommandee"
    else:
        ref = mini
        # sans precision, la configuration minimale vaut pour les reglages
        # bas ; 1,9 (et non 1,75) : un peu de prudence en plus
        diviseur = 1.9 if not mini.cible_niveau else FACTEUR_NIVEAU[mini.cible_niveau] * 1.9 / 1.75
        haute = _images_editeur(mini, 30) * (machine.gpu / mini.gpu) ** 0.9 / diviseur
        base = "minimale"
    haute *= _res(machine, ref.rendu_px or ref.cible_px or PX_1080) * calibration
    valeurs = {"haute": haute, "moyenne": haute * 1.3, "basse": haute * 1.75}

    # plafond processeur (ne depend pas de la definition)
    ref_cpu = (rec.cpu if rec and rec.cpu else
               (mini.cpu * 1.4 if mini and mini.cpu else None))
    plafonnes: set[str] = set()
    if ref_cpu and machine.cpu:
        # objectif tenu grace a la generation d'images : le processeur
        # recommande n'en prepare que la moitie
        ips_cpu = 60 / GAIN_GENERATION if rec and rec.cpu and getattr(rec, "generation_images", False) else 60
        plafond = ips_cpu * (machine.cpu / ref_cpu) * PLAFOND_CPU
        for k, v in valeurs.items():
            if v > plafond:
                valeurs[k] = plafond
                plafonnes.add(k)
    ev.fps = {k: _fourchette(v) for k, v in valeurs.items()}
    # jeu bloque a 60 images/s (Elden Ring...) : la fourchette s'arrete a la
    # limite, et une carte qui la depasse largement la tient en entier
    from .plafonds import limite
    maxi = limite(ev.appid)
    if maxi:
        ev.fps = {k: (min(b, maxi), min(h, maxi)) for k, (b, h) in ev.fps.items()}
        ev.notes.append(f"Le jeu est limite a {maxi} images par seconde.")
    ev.source = ESTIME

    ev.base = base
    plus_haut = "haute"
    memoire = ""                       # memoire qui interdit le niveau Haute
    if rec and rec.vram_go and machine.vram_go and machine.vram_go < rec.vram_go:
        plus_haut = "moyenne"
        memoire = "vram"
        ev.limite = ev.limite or "vram"
        ev.notes.append(f"Memoire video ({machine.vram_go:g} Go) sous la recommandation "
                        f"({rec.vram_go:g} Go) : textures elevees deconseillees.")
    if rec and rec.ram_go and machine.ram_go and machine.ram_go + 0.5 < rec.ram_go:
        plus_haut = "moyenne"
        memoire = memoire or "ram"
        ev.limite = ev.limite or "ram"
        ev.notes.append(f"Memoire vive ({machine.ram_go:g} Go) sous la recommandation "
                        f"({rec.ram_go:g} Go).")
    if mini and mini.ram_go and machine.ram_go and machine.ram_go + 0.5 < mini.ram_go:
        ev.niveau = "insuffisant"
        ev.limite = ev.frein = "ram"
        ev.notes.append("Memoire vive sous le minimum demande.")
        return ev

    ordre = ["haute", "moyenne", "basse"]
    ordre = ordre[ordre.index(plus_haut):]
    ev.niveau = next((p for p in ordre if ev.fps[p][0] >= SEUIL_FLUIDE), "")
    #: le processeur seul empeche les 60 images/s, a tous les niveaux
    bride = "basse" in plafonnes and ev.fps["basse"][0] < SEUIL_FLUIDE
    if not ev.niveau:
        if ev.fps["basse"][0] < SEUIL_JOUABLE:
            ev.niveau = "insuffisant"
        elif bride:
            # jouable sans tenir 60 images/s, et c'est le processeur qui
            # plafonne : baisser les reglages graphiques ne rend pas d'images.
            # Le bon niveau est le plus beau qui atteint ce plafond (meme
            # regle que le profil « Recommande », `recommande.SOMMET`) ;
            # « Basse » ferait baisser les reglages pour rien.
            ev.niveau = next((p for p in ordre if valeurs[p] >= valeurs["basse"] * 0.97),
                             "basse")
        else:
            ev.niveau = "basse"
    ev.fluide = ev.niveau in ev.fps and ev.fps[ev.niveau][0] >= SEUIL_FLUIDE
    if ev.niveau != "haute" or not ev.fluide:
        # pourquoi pas « Haute » a 60 images/s : assez d'images mais pas assez
        # de memoire, sinon le processeur s'il plafonne, sinon la carte
        if ev.fps["haute"][0] >= SEUIL_FLUIDE:
            ev.frein = memoire or "gpu"
        else:
            ev.frein = "cpu" if ("haute" in plafonnes or bride) else "gpu"
    if ev.niveau in plafonnes or (ev.frein == "cpu" and bride):
        ev.limite = "cpu"
        ev.notes.append("Limite par le processeur : baisser les reglages graphiques "
                        "n'apportera pas beaucoup plus d'images.")
    if base == "recommandee":
        ev.notes.append(f"Calcule depuis la configuration recommandee du jeu, pour "
                        f"{machine.definition}. Fourchette prudente.")
    else:
        ev.notes.append(f"Calcule depuis la configuration minimale du jeu, pour "
                        f"{machine.definition}. Fourchette prudente.")
    return ev


def depuis_mesures(titre: str, runs: dict[str, dict]) -> Evaluation | None:
    """`runs` : meilleure mesure par profil ORION (PerfStore.by_profile)."""
    fps: dict[str, tuple[int, int]] = {}
    fluide: list[str] = []
    for profil, run in runs.items():
        # le niveau reellement applique est note avec la mesure (profil
        # « Recommande », dont le niveau depend du jeu et du PC)
        preset = run.get("preset") if run.get("preset") in PRESETS \
            else PROFIL_PRESET.get(profil)
        if not preset or not run.get("fps_avg"):
            continue
        moy, bas = float(run["fps_avg"]), float(run.get("fps_low_1") or 0)
        fps[preset] = (int(bas or moy * 0.7), int(moy))
        if moy >= 60 and bas >= 40:
            fluide.append(preset)
    if not fps:
        return None
    ev = Evaluation(titre=titre, source=MESURE, fps=fps)
    # meilleur niveau fluide ; sinon « basse » (jouable en baissant les
    # reglages) : la mesure reelle reste affichee, voir `fps_affiche`
    ev.niveau = next((p for p in PRESETS if p in fluide), "") or (
        "basse" if max(v[1] for v in fps.values()) >= SEUIL_JOUABLE else "insuffisant")
    if ev.niveau not in fps:
        p = next(p for p in PRESETS if p in fps)
        ev.notes.append(f"Aucune mesure fluide : {fps[p][1]} i/s en moyenne releves en "
                        f"{NOMS[p]}, reglages plus bas conseilles.")
    ev.notes.append("Mesure reelle sur votre PC (moyenne et 1 % des images les plus lentes).")
    return ev


def depuis_communaute(titre: str, appid: str, machine: Machine,
                      mesures: list[dict]) -> Evaluation | None:
    """Mesures partagees : {appid, gpu, pixels, preset, fps}. Au moins 3
    mesures proches (carte a +-15 %) par niveau de reglages."""
    if machine.gpu is None:
        return None
    par_preset: dict[str, list[float]] = {}
    for m in mesures:
        # donnees distantes, ecrites par des tiers : une entree mal formee
        # est ignoree, elle ne doit pas casser tout le calculateur
        if not isinstance(m, dict) or str(m.get("appid")) != str(appid):
            continue
        try:
            gpu, ips = float(m.get("gpu") or 0), float(m.get("fps") or 0)
            pixels = max(int(float(m.get("pixels") or PX_1080)), 1)
        except (TypeError, ValueError):
            continue
        if gpu <= 0 or ips <= 0:
            continue
        if abs(gpu - machine.gpu) / machine.gpu > 0.15:
            continue
        facteur = ((machine.gpu / gpu) ** 0.9
                   * (pixels / max(machine.pixels, 1)) ** 0.75)
        # une entree peut regrouper plusieurs joueurs : {fps: mediane, n,
        # min, max}. Elle compte alors pour n mesures.
        try:
            n = max(1, min(int(m.get("n") or 1), 500))
            bas = float(m.get("min") or ips)
            haut = float(m.get("max") or ips)
        except (TypeError, ValueError):
            n, bas, haut = 1, ips, ips
        valeurs = [ips * facteur] * n
        if n >= 2 and 0 < bas <= ips <= haut:
            valeurs[0], valeurs[-1] = bas * facteur, haut * facteur
        par_preset.setdefault(str(m.get("preset", "")), []).extend(valeurs)
    fps = {p: (int(min(v)), int(max(v))) for p, v in par_preset.items()
           if p in PRESETS and len(v) >= 3}
    if not fps:
        return None
    medianes = {p: statistics.median(par_preset[p]) for p in fps}
    ev = Evaluation(titre=titre, appid=str(appid), source=COMMUNAUTE, fps=fps)
    ev.niveau = next((p for p in PRESETS if p in fps and fps[p][0] >= SEUIL_FLUIDE), "") or (
        next((p for p in reversed(PRESETS) if p in medianes
              and medianes[p] >= SEUIL_JOUABLE), "insuffisant"))
    ev.notes.append(f"{sum(len(par_preset[p]) for p in fps)} mesures de joueurs ORION avec "
                    "une carte graphique proche, ramenees a votre materiel.")
    return ev


#: bornes de la correction : le 9 octobre, Baldur's Gate 3 (RTX 3080, 1440p,
#: Ultra) tournait a 130 i/s pour 55 estimees (x 2,4) ; l'ancienne borne
#: (x 1,3) empechait d'apprendre un tel ecart
CALIBRATION_MIN, CALIBRATION_MAX = 0.5, 2.5
#: une seule partie mesuree peut relever les estimations autant qu'il faut
#: (9 octobre : Baldur's Gate 3, x 2,4), mais ne les abaisse que jusqu'ici :
#: une partie moins bonne que prevu est presque toujours une partie genee
#: (15 octobre : Sparking ZERO a 47 i/s de moyenne pendant un enregistrement
#: d'ecran divisait toutes les estimations par deux). Il faut deux jeux qui
#: s'accordent pour descendre plus bas.
CALIBRATION_SEUL_MIN = 0.75
#: un 0,1 % le plus bas sous cette part de la moyenne : partie hachee (autre
#: fenetre, enregistrement, chargements pris pour du jeu), pas la puissance du PC
HACHEE = 0.15


def calibrer(paires: list[tuple[float, float]]) -> float:
    """Facteur de correction de VOS estimations d'apres vos mesures reelles.
    `paires` : (mesure, estimation centrale, au meme niveau). Une seule
    mesure corrige deja ; seule, elle ne descend pas sous CALIBRATION_SEUL_MIN."""
    ratios = [m / e for m, e in paires if m and e]
    if not ratios:
        return 1.0
    bas = CALIBRATION_MIN if len(ratios) >= 2 else CALIBRATION_SEUL_MIN
    return round(min(max(statistics.median(ratios), bas), CALIBRATION_MAX), 2)


def mesure_hachee(run: dict) -> bool:
    """Vrai pour une partie dont le 0,1 % le plus bas s'effondre loin sous la
    moyenne : elle ne dit rien de ce que le PC peut faire."""
    try:
        moy, bas = float(run.get("fps_avg") or 0), float(run.get("fps_low_01") or 0)
    except (TypeError, ValueError):
        return False
    return moy > 0 and bas > 0 and bas < moy * HACHEE


def paires_du_pc(runs: list[dict], machine: Machine, exig_de=None) -> list[tuple[float, float]]:
    """(images/s mesurees, images/s estimees) pour chaque partie mesuree sur
    ce PC dont on connait la fiche Steam et le niveau. Avant la 2.1.0, seules
    les mesures du profil « Detente » comptaient : ce profil a disparu, plus
    rien ne corrigeait les estimations. Une partie bridee (limite d'images,
    synchronisation : 1 % le plus bas colle a la moyenne) ne dit pas ce que
    le PC peut faire : elle est ignoree."""
    from ..optimizer.recommande import COUT, MODES
    if exig_de is None:
        from . import exigences
        exig_de = exigences.en_cache
    from ..perf.store import fiable
    dernier: dict[tuple[str, str], dict] = {}
    for run in runs or []:
        if not isinstance(run, dict) or not run.get("appid") or run.get("preset") not in COUT:
            continue
        if not fiable(run) or mesure_hachee(run):
            continue                      # douteuse ou hachee : jamais une reference
        cle = (str(run["appid"]), run["preset"])
        if cle not in dernier or run.get("at", 0) >= dernier[cle].get("at", 0):
            dernier[cle] = run
    paires = []
    for (appid, niveau), run in dernier.items():
        try:
            moy = float(run.get("fps_avg") or 0)
            bas = float(run.get("fps_low_1") or 0)
        except (TypeError, ValueError):
            continue
        if moy <= 0 or (bas and bas >= moy * 0.85):
            continue
        gain = MODES.get(run.get("upscaler_mode") or "off", MODES["off"])[0]
        try:
            e = estimer("", exig_de(appid), machine)
        except Exception:
            continue
        if e.source != ESTIME or "haute" not in e.fps:
            continue
        haute = sum(e.fps["haute"]) / 2 / ((MARGE_BASSE + MARGE_HAUTE) / 2)
        paires.append((moy / gain, haute * COUT[niveau] / COUT["haute"]))
    return paires


def calibration_du_pc(runs: list[dict], machine: Machine, exig_de=None) -> float:
    """La correction a appliquer aux estimations de ce PC (1.0 sans mesure)."""
    try:
        return calibrer(paires_du_pc(runs, machine, exig_de))
    except Exception:
        return 1.0


def evaluer(titre: str, machine: Machine, exig: Exigences | None = None,
            runs: dict | None = None, mesures_communaute: list | None = None,
            calibration: float = 1.0, appid: str = "", uid: str = "") -> Evaluation:
    """Meilleure source disponible : mesure, puis communaute, puis estimation."""
    ev = None
    if runs:
        ev = depuis_mesures(titre, runs)
    if ev is None and appid and mesures_communaute:
        ev = depuis_communaute(titre, appid, machine, mesures_communaute)
    if ev is None:
        ev = estimer(titre, exig, machine, calibration)
    ev.appid = ev.appid or appid
    ev.uid = uid
    return ev
