"""Ecrivains de reglages : traduisent une operation abstraite en ecriture reelle.

Un `TweakWriter` sait lire et ecrire un format (fichier INI, base de registre,
fichier de commandes console...). Les recettes JSON designent le format par
son identifiant ; le registre de plugins fait le lien.

Ajouter un format = deposer un module ici avec une classe `TweakWriter`.
"""
from __future__ import annotations

from ...core.logging_setup import get
from ...core.models import TweakOp

log = get("tweaks")


class TweakWriter:
    abstract = True
    id: str = ""            # "ini", "registry", "cfg", "json"
    label: str = ""
    priority: int = 50

    def available(self) -> bool:
        return True

    def read(self, op: TweakOp) -> str | None:
        """Valeur actuelle, ou None si absente."""
        return None

    def write(self, ops: list[TweakOp]) -> tuple[int, str]:
        """Applique les operations. Retourne (nombre ecrit, message)."""
        return 0, "Non implemente"

