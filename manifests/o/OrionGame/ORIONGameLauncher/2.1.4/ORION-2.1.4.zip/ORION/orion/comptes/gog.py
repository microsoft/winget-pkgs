"""Compte GOG (non officiel, tolere).

GOG ne publie pas d'acces pour les applications tierces. La methode
utilisee ici est celle de GOG Galaxy lui-meme, reprise depuis des annees
par les outils libres (lgogdownloader, Heroic, Playnite) : la page de
connexion officielle de GOG rend un code, echange contre un jeton de
session (renouvele automatiquement). Aucun mot de passe ne transite par
ORION.

Donnees : profil, liste complete des jeux possedes, temps de jeu et succes
(ceux-ci via la base locale de GOG Galaxy quand elle existe, sinon via le
service de jeu de GOG).
"""
from __future__ import annotations

import sqlite3
import time
from pathlib import Path
from urllib.parse import parse_qs, urlencode, urlparse

from ..core.logging_setup import get
from .base import ConnexionRequise, JeuCompte, Plateforme, Profil, Succes

log = get("comptes.gog")

CLIENT_ID = "46899977096215655"
CLIENT_SECRET = "9d85c43b1482497dbbce61f6e4aa173a433796eeae2ca8c5f6129f2dc4de46d9"
RETOUR = "https://embed.gog.com/on_login_success?origin=client"
AUTH = "https://auth.gog.com/auth"
JETON = "https://auth.gog.com/token"


def _base_galaxy() -> Path:
    import os
    racine = os.environ.get("PROGRAMDATA") or "C:\\ProgramData"
    return Path(racine) / "GOG.com" / "Galaxy" / "storage" / "galaxy-2.0.db"


class GOG(Plateforme):
    id = "gog"
    nom = "GOG"
    nature = "tolere"
    apport = ("Tous vos jeux GOG (installes ou non), temps de jeu et succes ; "
              "installation directe des jeux sans DRM.")
    #: la connexion peut se finir dans le navigateur du joueur (adresse collee)
    connexion_navigateur = True
    aide_refus_google = (
        "Google refuse les fenetres integrees : connectez-vous a GOG avec e-mail et "
        "mot de passe, ou liez Google dans votre compte GOG. ORION ne contourne pas "
        "cette protection : fermez la fenetre Google et utilisez le formulaire GOG. "
        "Compte cree avec Google, sans mot de passe GOG ? Sur la page de connexion GOG, "
        "choisissez « Mot de passe oublie ? » avec l'adresse e-mail de votre compte "
        "Google : GOG vous envoie un lien pour en creer un.")

    # ------------------------------------------------------------------
    # connexion
    # ------------------------------------------------------------------
    def adresse_connexion(self) -> str:
        return f"{AUTH}?" + urlencode({"client_id": CLIENT_ID, "redirect_uri": RETOUR,
                                       "response_type": "code", "layout": "client2"})

    def est_retour(self, adresse: str) -> bool:
        return adresse.startswith("https://embed.gog.com/on_login_success")

    def retour_connexion(self, adresse: str) -> dict:
        code = (parse_qs(urlparse(adresse).query).get("code") or [""])[0]
        if not code:
            raise ValueError("connexion annulee")
        return self._jeton(grant_type="authorization_code", code=code,
                           redirect_uri=RETOUR)

    def _jeton(self, **params) -> dict:
        from ..core import reseau
        params.update(client_id=CLIENT_ID, client_secret=CLIENT_SECRET)
        r = reseau.get(JETON, params=params, timeout=20)
        if r.status_code >= 400:
            raise ValueError("GOG a refuse la connexion")
        d = r.json()
        return {"access_token": d["access_token"],
                "refresh_token": d.get("refresh_token", ""),
                "expire": time.time() + int(d.get("expires_in") or 3600) - 120,
                "user_id": str(d.get("user_id", ""))}

    def _entetes(self) -> dict:
        s = self.secret()
        if time.time() >= float(s.get("expire") or 0):
            if not s.get("refresh_token"):
                raise ConnexionRequise(self.nom)
            try:
                neuf = self._jeton(grant_type="refresh_token",
                                   refresh_token=s["refresh_token"])
            except Exception as exc:
                raise ConnexionRequise(self.nom) from exc
            neuf["user_id"] = neuf.get("user_id") or s.get("user_id", "")
            self.maj_secret(**neuf)
            s = neuf
        return {"Authorization": f"Bearer {s['access_token']}"}

    def _get(self, url: str, **params) -> dict:
        from ..core import reseau
        r = reseau.get(url, params=params or None, headers=self._entetes(), timeout=20)
        if r.status_code == 401:
            raise ConnexionRequise(self.nom)
        r.raise_for_status()
        return r.json() or {}

    # ------------------------------------------------------------------
    # donnees
    # ------------------------------------------------------------------
    def _lire_profil(self) -> Profil:
        d = self._get("https://embed.gog.com/userData.json")
        uid = str(d.get("galaxyUserId") or d.get("userId") or self.secret().get("user_id", ""))
        avatars = d.get("avatars") or {}
        nom = d.get("username", "")
        return Profil(plateforme=self.id, id=uid, pseudo=nom,
                      avatar=avatars.get("medium2x") or avatars.get("medium") or "",
                      adresse=f"https://www.gog.com/u/{nom}" if nom else "",
                      pays=d.get("country", ""))

    def _lire_jeux(self) -> list[JeuCompte]:
        temps = self._temps_galaxy()
        jeux: list[JeuCompte] = []
        page, pages = 1, 1
        while page <= pages and page <= 60:
            d = self._get("https://embed.gog.com/account/getFilteredProducts",
                          mediaType=1, page=page)
            pages = int(d.get("totalPages") or 1)
            for p in d.get("products") or []:
                gid = str(p.get("id"))
                image = p.get("image") or ""
                if image.startswith("//"):
                    image = "https:" + image
                jeux.append(JeuCompte(plateforme=self.id, id=gid,
                                      titre=p.get("title") or gid,
                                      minutes=temps.get(gid, 0),
                                      image=f"{image}_196.jpg" if image else ""))
            page += 1
        log.info("GOG : %d jeux sur le compte", len(jeux))
        return jeux

    @staticmethod
    def _temps_galaxy() -> dict[str, int]:
        """Temps de jeu note par GOG Galaxy (base locale), si installe."""
        base = _base_galaxy()
        if not base.exists():
            return {}
        try:
            cx = sqlite3.connect(f"file:{base}?mode=ro&immutable=1", uri=True, timeout=5)
            try:
                lignes = cx.execute("SELECT releaseKey, minutesInGame FROM GameTimes").fetchall()
            finally:
                cx.close()
        except Exception:
            return {}
        temps = {}
        for cle, minutes in lignes:
            if str(cle).startswith("gog_"):
                temps[str(cle)[4:]] = int(minutes or 0)
        return temps

    def succes(self, jeu_id: str) -> list[Succes]:
        """Succes d'un jeu GOG (service de jeu de GOG Galaxy)."""
        uid = self.secret().get("user_id") or (self.profil_garde() or Profil("gog")).id
        try:
            d = self._get(f"https://gameplay.gog.com/clients/{jeu_id}/users/{uid}/achievements")
        except ConnexionRequise:
            raise
        except Exception as exc:
            log.info("Succes GOG %s indisponibles : %s", jeu_id, exc)
            return []
        liste = []
        for a in d.get("items") or []:
            debloque = a.get("date_unlocked")
            liste.append(Succes(
                id=str(a.get("achievement_key") or a.get("achievement_id")),
                nom=a.get("name", ""), description=a.get("description", ""),
                obtenu=bool(debloque), date=_date_iso(debloque),
                rarete=a.get("rarity"), icone=a.get("image_url_unlocked", ""),
                icone_grise=a.get("image_url_locked", ""),
                cache=not a.get("visible", True)))
        return liste


def _date_iso(texte) -> float:
    if not texte:
        return 0.0
    from datetime import datetime
    try:
        return datetime.fromisoformat(str(texte).replace("Z", "+00:00")).timestamp()
    except ValueError:
        return 0.0
