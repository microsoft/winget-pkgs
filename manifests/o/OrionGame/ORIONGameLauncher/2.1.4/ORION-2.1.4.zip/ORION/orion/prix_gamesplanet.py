"""Prix de Gamesplanet, distributeur officiel et partenaire d'ORION (2.0).

Gamesplanet publie tous ses prix dans un flux d'une douzaine de mega-octets
et autorise ORION a le garder en cache pour le redistribuer (courriel du 5
octobre 2026). Le flux est releve toutes les vingt minutes par une tache
planifiee du depot public d'ORION (`service/gamesplanet/`), qui en tire un
fichier compact. ORION ne lit que ce fichier : aucun PC de joueur n'interroge
Gamesplanet, et la lecture ne transmet rien sur le joueur ni sur ses jeux
(le meme fichier pour tout le monde).

Chaque produit du flux porte le numero Steam du jeu : la correspondance avec
une fiche d'ORION est exacte. Restent les editions (« Deluxe », « Gold »...)
vendues sous le meme numero : seule celle qui porte le nom du jeu, ou le meme
prix normal que lui, est retenue.
"""
from __future__ import annotations

import re
import time

from .core.logging_setup import get

log = get("prix.gamesplanet")

ADRESSE = ("https://raw.githubusercontent.com/Sikher-kisa/orion-game-launcher/"
           "donnees/gamesplanet-fr.json")
BOUTIQUE = "Gamesplanet"
SOURCE = "gamesplanet"
FICHE = "https://fr.gamesplanet.com/game/"
#: le fichier est relu au plus toutes les deux heures (avec son ETag)
RELIRE = 2 * 3600
#: un releve plus vieux que cela n'est plus affiche : mieux vaut pas de prix
#: qu'un prix faux (tache planifiee en panne, PC longtemps hors ligne)
PERIME = 8 * 3600
#: une edition n'est prise pour le jeu que si son prix normal est celui du jeu
MEME_PRIX = (0.85, 1.15)
TYPES = {"steam": "Steam", "gog": "GOG", "uplay": "Ubisoft Connect", "epic": "Epic Games",
         "msstore": "Microsoft Store", "rockstarsocial": "Rockstar", "zenimax": "Bethesda",
         "arenanet": "ArenaNet"}
_FICHE = re.compile(r"^[a-z0-9_-]{3,200}$")
#: offres Gamesplanet venues d'un comparateur : remplacees par la notre
_MEME_BOUTIQUE = re.compile(r"^games ?planet( fr)?$", re.I)
#: Gamesplanet tient quatre vitrines (FR, DE, UK, US), une par region. Un
#: comparateur les donne toutes : la fiche de Tropico 6 montrait quatre lignes
#: « Gamesplanet » (7 octobre 2026). Seule celle du joueur le concerne.
_VITRINE = re.compile(r"^games ?planet(?: (fr|de|uk|us))?$", re.I)
_VITRINE_DU_PAYS = {"FR": "fr", "DE": "de", "GB": "uk", "UK": "uk", "US": "us"}


def _vitrine_du_joueur() -> str:
    """« fr », « de », « uk » ou « us » ; vide pour un pays sans vitrine a
    lui (toutes sont alors gardees)."""
    try:
        from .core import region
        return _VITRINE_DU_PAYS.get((region.pays() or "").upper()[:2], "")
    except Exception:
        return ""


def _autre_region(boutique: str, mienne: str) -> bool:
    m = _VITRINE.match(boutique or "")
    return bool(m and mienne and (m.group(1) or "fr").lower() != mienne)

_memo: dict = {"releve": 0.0, "jeux": {}}


def _plat(texte: str) -> str:
    return re.sub(r"[^a-z0-9]", "", (texte or "").lower())


def actualiser() -> bool:
    """Relit le fichier des prix s'il a plus de deux heures. Ne leve jamais.
    Rend vrai quand un catalogue encore valable est en memoire."""
    try:
        from .core import reseau
        d = reseau.get_json(ADRESSE, garder=RELIRE, timeout=30)
        jeux = d.get("jeux") if isinstance(d, dict) else None
        if not isinstance(jeux, dict) or d.get("v") != 1 or d.get("devise") != "EUR":
            raise ValueError("fichier inattendu")
        _memo["releve"], _memo["jeux"] = float(d.get("releve") or 0), jeux
        # l'index des noms est prepare ici, dans la tache de fond : construit
        # a la premiere fiche ouverte, il figeait la fenetre (0,2 s)
        _indexer_noms()
    except Exception as exc:
        log.debug("Prix Gamesplanet indisponibles : %s", exc)
    return valable()


def _indexer_noms() -> None:
    """Noms de tout le catalogue, une fois par fichier (voir `vendu`)."""
    if _memo.get("noms_de") == _memo["releve"]:
        return
    from .core.recherche import sans_bruit
    noms = set()
    for produits in _memo["jeux"].values():
        for p in produits or []:
            try:
                noms.add(sans_bruit(str(p[0])))
            except Exception:
                continue
    noms.discard("")
    _memo["noms"], _memo["noms_de"] = noms, _memo["releve"]


def valable() -> bool:
    return bool(_memo["jeux"]) and 0 <= time.time() - _memo["releve"] < PERIME


def vendu(appid, titre: str = ""):
    """Gamesplanet vend-il ce jeu ? Vrai, faux, ou None quand on ne peut pas
    le savoir (fichier des prix absent ou trop ancien).

    Le fichier contient tout son catalogue : un jeu qui n'y est pas, ni sous
    son numero Steam ni sous son nom, n'est pas vendu chez lui. ORION ne
    propose alors pas « Chercher sur Gamesplanet » : la recherche du site
    rendrait des jeux sans rapport (constate le 7 octobre 2026 sur Call of
    Duty: Black Ops III, qu'il ne vend pas)."""
    if not valable():
        return None
    appid = str(appid or "").strip()
    if appid.isdigit() and _memo["jeux"].get(appid):
        return True
    _indexer_noms()                 # deja fait par `actualiser` ; ici par securite
    from .core.recherche import sans_bruit
    return bool(titre) and sans_bruit(titre) in _memo.get("noms", ())


def _produits(appid: str, pays: str) -> list[dict]:
    out = []
    for p in _memo["jeux"].get(str(appid)) or []:
        try:
            nom, prix, normal, fiche, type_cle, autorises, exclus = p[:7]
            prix, normal = float(prix), float(normal)
        except (TypeError, ValueError):
            continue
        if not (0 < prix <= normal < 1000) or not _FICHE.match(str(fiche)):
            continue
        if autorises and pays not in str(autorises).split(","):
            continue
        if exclus and pays in str(exclus).split(","):
            continue
        out.append({"nom": str(nom), "prix": round(prix, 2), "normal": round(normal, 2),
                    "url": FICHE + str(fiche), "type": str(type_cle)})
    return out


def offre(appid, titre: str, prix_normal: float = 0.0):
    """L'offre Gamesplanet pour ce jeu (une `Offre`), ou None."""
    from .core import region
    appid = str(appid or "").strip()
    if not appid.isdigit() or not valable() or region.devise() != "EUR":
        return None
    pays = (region.pays() or "FR").upper()[:2]
    produits = _produits(appid, pays)
    cible = _plat(titre)
    choisis = [p for p in produits if cible and _plat(p["nom"]) == cible]
    if not choisis and prix_normal > 0:
        # nom ecrit autrement : meme jeu seulement si c'est le meme prix normal
        from .core.recherche import sans_bruit
        base = sans_bruit(titre)
        choisis = [p for p in produits if base and sans_bruit(p["nom"]) == base
                   and MEME_PRIX[0] <= p["normal"] / prix_normal <= MEME_PRIX[1]]
    if not choisis:
        return None
    p = min(choisis, key=lambda x: x["prix"])
    from .plugins.boutique.base import Offre
    remise = int(round(100 - p["prix"] * 100 / p["normal"])) if p["prix"] < p["normal"] else 0
    return Offre(titre=titre, boutique=BOUTIQUE, prix=p["prix"], prix_normal=p["normal"],
                 remise=remise, url=p["url"], source=SOURCE, steam_appid=appid,
                 drm="Cle " + TYPES.get(p["type"], p["type"].capitalize() or "PC"),
                 releve_le=_memo["releve"])


def completer(fiches) -> int:
    """Ajoute (ou retire) l'offre Gamesplanet de chaque fiche. Rend le nombre
    d'offres posees. Sans catalogue valable, les anciennes sont retirees :
    jamais un prix dont on ne sait plus s'il est vrai."""
    poses = 0
    mienne = _vitrine_du_joueur()
    for f in fiches or []:
        try:
            f.offres[:] = [o for o in f.offres
                           if o.source == SOURCE or not _autre_region(o.boutique, mienne)]
            appid = f.steam_appid
            normal = max((o.prix_normal or 0 for o in f.offres
                          if o.source != SOURCE and o.sure), default=0)
            gratuit = any(o.gratuit for o in f.offres if o.source != SOURCE and o.sure)
            nouvelle = None if gratuit else offre(appid, f.titre, normal)
            f.offres[:] = [o for o in f.offres if o.source != SOURCE
                           and not (nouvelle is not None and _MEME_BOUTIQUE.match(o.boutique or ""))]
            if nouvelle is not None:
                f.offres.append(nouvelle)
                poses += 1
        except Exception:
            log.debug("Offre Gamesplanet ignoree pour %r", getattr(f, "titre", "?"))
    return poses
