"""Rattrapage : jeux presents dans la liste des programmes installes.

Ce scanner est volontairement prudent — il ne retient une entree que si elle
porte un indice serieux (moteur de jeu detecte, chemin de jeu, editeur connu).
Les resultats sont marques `low_confidence` pour que l'interface permette de
les filtrer d'un clic.
"""
from __future__ import annotations

import re
from pathlib import Path

from ...core.doublons import cle_native

from ...core.logging_setup import get
from ...core.models import Game
from ...core.winutil import HKCU, HKLM, dir_size, reg_subkeys, reg_values
from .base import Scanner, detect_engine, pick_main_exe

log = get("scan.registre")

PATHS = (
    (HKLM, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
    (HKLM, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"),
    (HKCU, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
)

PUBLISHER_OK = re.compile(
    r"(ubisoft|electronic arts|ea games|bethesda|square enix|capcom|bandai|"
    r"sega|rockstar|take-?two|2k|activision|blizzard|cd projekt|paradox|"
    r"devolver|focus|deep silver|koei|fromsoftware|larian|warner bros|"
    r"valve|epic games|gearbox|id software|techland|frontier|team17|"
    r"private division|annapurna|thq|nacon|plaion|"
    # editeurs de jeux en ligne, souvent installes hors des grandes boutiques
    r"ankama|wargaming|gaijin|riot games|grinding gear|digital extremes|"
    r"hoyoverse|mihoyo|cognosphere|kuro games|pearl abyss|smilegate|nexon|"
    r"ncsoft|krafton|bohemia|crytek|embark|facepunch|mojang|gameforge|"
    r"jagex|my\.games|netease|perfect world|garena|konami|505 games|"
    r"coffee stain|re-logic|innersloth|playway|tencent|level infinite|"
    r"square|bandai namco|spike chunsoft|atlus|nexon|kakao)", re.I)

PUBLISHER_NO = re.compile(
    r"(microsoft corp|adobe|nvidia|intel|realtek|amd|logitech|corsair|"
    r"steelseries|razer|google|mozilla|oracle|python|jetbrains|docker|"
    r"vmware|malwarebytes|avast|ccleaner|7-zip|winrar|autodesk|"
    r"opera|brave software|vivaldi|discord|spotify|telegram|whatsapp|zoom|slack|"
    r"obs project|videolan|overwolf|notepad\+\+|piriform|bitdefender|kaspersky|norton)", re.I)

NAME_NO = re.compile(
    r"(redistributable|runtime|driver|sdk|framework|update for|"
    r"visual c\+\+|\.net|directx|java|python|node\.js|toolkit|"
    r"vulkan|physx|geforce|control panel|service|agent|"
    r"browser|navigateur|opera|chrome|chromium|firefox|vivaldi|brave|edge|"
    r"discord|spotify|telegram|whatsapp|skype|zoom|slack|teams|obs studio|vlc)", re.I)

PATH_GAME = re.compile(r"(steamapps|\\games?\\|\\jeux\\|gog galaxy\\games|"
                       r"xboxgames|epic games\\)", re.I)


class RegistryScanner(Scanner):
    id = "registre"
    label = "Programmes installes"
    icon = "REG"
    priority = 10

    def available(self) -> bool:
        return any(reg_subkeys(r, p) for r, p in PATHS)

    def scan(self) -> list[Game]:
        games: list[Game] = []
        seen: set[str] = set()

        for root, base in PATHS:
            for sub in reg_subkeys(root, base):
                try:
                    v = reg_values(root, f"{base}\\{sub}")
                except Exception:
                    continue
                name = str(v.get("DisplayName") or "").strip()
                loc = str(v.get("InstallLocation") or "").strip().rstrip("\\")
                if not name or not loc or v.get("SystemComponent"):
                    continue
                if NAME_NO.search(name) or PUBLISHER_NO.search(str(v.get("Publisher", ""))):
                    continue
                low = loc.lower()
                if low in seen or "common files" in low or "windowsapps" in low:
                    continue
                p = Path(loc)
                if not p.is_dir():
                    continue

                engine = detect_engine(p)
                confident = bool(engine) or bool(PATH_GAME.search(loc)) or \
                    bool(PUBLISHER_OK.search(str(v.get("Publisher", ""))))
                if not confident:
                    continue
                seen.add(low)

                exe = pick_main_exe(p, name)
                if not exe:
                    continue
                games.append(self._mk(
                    title=name,
                    source_id=sub,
                    install_dir=loc,
                    executable=exe,
                    working_dir=str(Path(exe).parent),
                    size_bytes=int(v.get("EstimatedSize", 0) or 0) * 1024
                    or dir_size(p, 4000),
                    engine=engine,
                    extra={"publisher": v.get("Publisher", ""),
                           "native": cle_native(sub),
                           "version": v.get("DisplayVersion", ""),
                           "low_confidence": not (engine or PATH_GAME.search(loc))},
                ))
        log.info("%d jeux via le registre", len(games))
        return games
