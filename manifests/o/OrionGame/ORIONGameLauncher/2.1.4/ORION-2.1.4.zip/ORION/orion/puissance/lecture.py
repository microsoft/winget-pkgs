"""Lecture du PC (2.0) : ce qui freine, ce qu'il manque, comment jouer quand meme.

Le calculateur dit, jeu par jeu, quel niveau de reglages reste fluide. Ce
module en tire ce que le joueur veut vraiment savoir :

* **par composant** : lequel freine le plus de jeux (`freins`, `composants`),
  et a quoi il se compare (`equivalents`) ;
* **par jeu** : sa configuration demandee face a la machine, composant par
  composant (`expliquer`) ; ce qu'il faudrait pour monter d'un niveau
  (`manque`) ; et surtout ce qui le rend jouable sans rien acheter
  (`pistes` : DLSS/FSR/XeSS en mode Qualite, definition d'affichage
  inferieure).

Tout repose sur `estimation.estimer`, rejoue avec une machine modifiee :
aucune formule n'est recopiee ici, une correction du moteur profite donc a
toutes ces lectures. Comme le moteur, ce module ne promet rien : ce sont
des estimations, dites comme telles.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field, replace

from .estimation import ESTIME, NOMS, Evaluation, Machine, estimer
from .exigences import Config, Exigences
from .references import CPU_AMD, CPU_INTEL, GPU, HORS_VENTE, ray_tracing_materiel

#: du meilleur au moins bon
RANG = {"ultra": 0, "haute": 1, "moyenne": 2, "basse": 3, "insuffisant": 4, "": 5}

NOMS_COMPOSANTS = {"gpu": "carte graphique", "cpu": "processeur",
                   "vram": "memoire video", "ram": "memoire vive"}

#: mise a l'echelle « Qualite » : le jeu calcule 67 % de la definition sur
#: chaque axe (44 % des points), puis l'image est agrandie
PART_QUALITE = 0.444
#: ce que coute l'agrandissement lui-meme
COUT_ECHELLE = 0.92

#: definitions d'affichage courantes, de la plus fine a la plus legere
DEFINITIONS = ((3840, 2160), (2560, 1440), (1920, 1080), (1600, 900), (1280, 720))

# --------------------------------------------------------------------------
# Noms lisibles des references
# --------------------------------------------------------------------------
def nom_propre(nom: str) -> str:
    """Le nom que Windows donne a un composant, sans ses mentions de marque :
    « Intel(R) Core(TM) i9-9900K CPU @ 3.60GHz » -> « Intel Core i9-9900K »,
    « AMD Ryzen 7 7735HS with Radeon Graphics » -> « AMD Ryzen 7 7735HS »."""
    t = re.sub(r"\((?:R|TM)\)|[®™]", "", nom or "", flags=re.I)
    t = re.sub(r"\s+CPU\b|\s*@\s*[\d.,]+\s*GHz", "", t, flags=re.I)
    t = re.sub(r"\s+\d+-Core Processor\b|\s+(?:with|w/)\s+Radeon.*$", "", t, flags=re.I)
    t = re.sub(r"^\d+(?:th|rd|nd|st) Gen\s+", "", t, flags=re.I)
    return re.sub(r"\s+", " ", t).strip()


def joli_gpu(cle: str) -> str:
    """« rtx 4060 ti » -> « RTX 4060 Ti », « arc b580 » -> « Arc B580 »."""
    mots = []
    for m in (cle or "").split():
        if m in ("rtx", "gtx", "rx", "gt", "hd", "uhd", "xt", "xtx", "gre", "vii"):
            mots.append(m.upper())
        elif re.fullmatch(r"\d+gb", m):
            mots.append(m[:-2] + " Go")
        elif re.fullmatch(r"[a-z]\d+", m) or re.fullmatch(r"\d+[a-z]", m):
            mots.append(m.upper())
        else:
            mots.append(m.capitalize())
    return " ".join(mots)


def joli_cpu(cle: str, amd: bool) -> str:
    """« 5800x3d » -> « Ryzen 7 5800X3D », « 12400 » -> « Core i5-12400 »."""
    c = (cle or "").strip()
    if c.startswith("fx"):
        return "FX-" + c.split()[-1]
    numero = re.match(r"\d+", c)
    if not numero:
        return c.upper()
    chiffres = numero.group(0)
    suffixe = c[len(chiffres):].upper()
    if amd:
        second = int(chiffres[1]) if len(chiffres) > 1 else 0
        gamme = 9 if second >= 9 else 7 if second >= 7 else 5 if second >= 4 else 3
        return f"Ryzen {gamme} {chiffres}{suffixe}"
    if len(chiffres) == 3:                         # Core Ultra 285K, 265K, 245K
        gamme = {"8": 9, "6": 7, "4": 5}.get(chiffres[1], 5)
        return f"Core Ultra {gamme} {chiffres}{suffixe}"
    fin = int(chiffres[-3:])
    gamme = 9 if fin >= 900 else 7 if fin >= 700 else 5 if fin >= 400 else 3
    if chiffres == "2600":                         # i7-2600, pas i5
        gamme = 7
    return f"Core i{gamme}-{chiffres}{suffixe}"


def _gpu_achetables() -> list[tuple[float, str]]:
    return sorted((v, k) for k, v in GPU.items() if k not in HORS_VENTE)


def _cpu_tous() -> list[tuple[float, str, bool]]:
    """(indice, cle, amd) ; a numero egal dans les deux tables, les deux
    processeurs existent et sont gardes."""
    return sorted([(v, k, True) for k, v in CPU_AMD.items()]
                  + [(v, k, False) for k, v in CPU_INTEL.items()])


def equivalents_gpu(indice: float | None, sauf: str = "", combien: int = 2) -> str:
    """Cartes de puissance voisine : « RTX 4070, RX 6800 XT »."""
    if not indice:
        return ""
    sauf = (sauf or "").lower()
    proches = sorted((abs(v - indice), -v, k) for v, k in _gpu_achetables()
                     if k not in sauf and abs(v - indice) <= max(2.0, indice * 0.08))
    return ", ".join(joli_gpu(k) for _e, _v, k in proches[:combien])


def equivalents_cpu(indice: float | None, sauf: str = "", combien: int = 2) -> str:
    if not indice:
        return ""
    sauf = (sauf or "").lower()
    proches = sorted((abs(v - indice), -v, k, amd) for v, k, amd in _cpu_tous()
                     if k not in sauf and abs(v - indice) <= max(2.0, indice * 0.06))
    return ", ".join(joli_cpu(k, amd) for _e, _v, k, amd in proches[:combien])


# --------------------------------------------------------------------------
# Par composant : ce qui freine
# --------------------------------------------------------------------------
def frein(e: Evaluation) -> str:
    """Composant qui retient ce jeu sous le niveau « Haute » (« » : rien, ou
    on ne sait pas). Seules les estimations le disent : une mesure donne un
    resultat, pas sa cause."""
    if getattr(e, "source", "") != ESTIME or e.niveau in ("ultra", ""):
        return ""
    if e.niveau == "haute":
        # « Haute » sans tenir 60 images/s : le processeur plafonne
        return getattr(e, "frein", "")
    return getattr(e, "frein", "") or e.limite or "gpu"


def rang(e: Evaluation) -> float:
    """Rang d'un resultat, du meilleur au moins bon : un niveau qui ne tient
    pas 60 images/s vaut moins que le meme niveau fluide."""
    return RANG.get(e.niveau or "", 5) + (0 if getattr(e, "fluide", True) else 0.5)


def freins(resultats, seulement_mes: bool = False) -> dict:
    """Bilan des estimations : combien de jeux sont fluides en « Haute », et
    quel composant retient les autres."""
    bilan = {"evalues": 0, "fluides": 0, "gpu": 0, "cpu": 0, "vram": 0, "ram": 0}
    for c, e in resultats:
        if seulement_mes and not (c.installe or c.possede):
            continue
        if getattr(e, "source", "") != ESTIME or not e.niveau:
            continue
        bilan["evalues"] += 1
        f = frein(e)
        if not f:
            bilan["fluides"] += 1
        elif f in bilan:
            bilan[f] += 1
    return bilan


def premier_frein(bilan: dict) -> str:
    """Composant qui retient le plus de jeux (« » si aucun)."""
    cle = max(("gpu", "cpu", "vram", "ram"), key=lambda k: bilan.get(k, 0))
    return cle if bilan.get(cle, 0) else ""


@dataclass
class Composant:
    cle: str                 # gpu | cpu | vram | ram
    nom: str                 # « Carte graphique »
    valeur: str              # « NVIDIA GeForce RTX 3080 »
    indice: float | None     # 0-100+ (None : pas d'indice pour ce composant)
    proches: str             # « du niveau d'une RTX 4070, RX 6800 XT »
    retenus: int             # jeux qu'il retient sous « Haute »
    verdict: str             # phrase courte
    etat: str                # ok | conseil | attention | inconnu


def composants(machine: Machine, resultats) -> list[Composant]:
    """Les quatre composants qui comptent en jeu, chacun avec son verdict tire
    des jeux evalues."""
    bilan = freins(resultats)
    n = bilan["evalues"]

    def verdict(cle: str, reconnu: bool) -> tuple[str, str]:
        if not reconnu:
            return "non reconnu : ses jeux ne peuvent pas etre evalues", "inconnu"
        if not n:
            return "aucun jeu evalue pour l'instant", "inconnu"
        k = bilan[cle]
        if not k:
            return f"ne retient aucun des {n} jeux evalues", "ok"
        part = k / n
        etat = "attention" if part >= 0.25 else "conseil"
        return f"retient {k} jeu(x) sur {n} sous le niveau Haute", etat

    sortie = []
    v, etat = verdict("gpu", machine.gpu is not None)
    sortie.append(Composant(
        "gpu", "Carte graphique", nom_propre(machine.gpu_nom) or "non reconnue", machine.gpu,
        equivalents_gpu(machine.gpu, machine.gpu_nom), bilan["gpu"], v, etat))
    v, etat = verdict("cpu", machine.cpu is not None)
    sortie.append(Composant(
        "cpu", "Processeur", nom_propre(machine.cpu_nom) or "non reconnu", machine.cpu,
        equivalents_cpu(machine.cpu, machine.cpu_nom), bilan["cpu"], v, etat))
    v, etat = verdict("vram", bool(machine.vram_go))
    sortie.append(Composant(
        "vram", "Memoire video", f"{machine.vram_go:g} Go" if machine.vram_go else "inconnue",
        None, "", bilan["vram"], v, etat))
    v, etat = verdict("ram", bool(machine.ram_go))
    sortie.append(Composant(
        "ram", "Memoire vive", f"{machine.ram_go:.0f} Go" if machine.ram_go else "inconnue",
        None, "", bilan["ram"], v, etat))
    return sortie


def phrase_frein(bilan: dict) -> str:
    """Une phrase de synthese : « Premier frein de ce PC : ... »."""
    n = bilan.get("evalues", 0)
    if not n:
        return ""
    fluides = bilan["fluides"]
    cle = premier_frein(bilan)
    debut = f"Jeux estimes fluides en Haute : {fluides} sur {n}."
    if not cle:
        return debut + " Aucun composant ne retient les autres."
    return (f"{debut} Premier frein de ce PC : {NOMS_COMPOSANTS[cle]}, "
            f"pour {bilan[cle]} jeu(x).")


# --------------------------------------------------------------------------
# Par jeu : pistes pour le rendre jouable
# --------------------------------------------------------------------------
@dataclass
class Piste:
    genre: str               # « echelle » | « definition »
    libelle: str             # « DLSS en mode Qualite », « en 1600x900 »
    niveau: str              # niveau obtenu
    fps: tuple[int, int] | None
    #: meme niveau qu'aujourd'hui, mais a 60 images/s : la colonne dit
    #: « Basse fluide avec DLSS » (« Basse → Basse avec DLSS » ne dirait rien)
    meme_niveau: bool = False

    @property
    def texte(self) -> str:
        nom = NOMS.get(self.niveau, self.niveau)
        if self.fps:
            if self.fps[0] >= self.fps[1]:                 # jeu bloque a sa limite
                return f"{self.libelle} : {nom}, {self.fps[1]} i/s"
            return f"{self.libelle} : {nom}, environ {self.fps[0]} a {self.fps[1]} i/s"
        return f"{self.libelle} : {nom}"

    @property
    def court(self) -> str:
        """Pour la colonne du tableau : « Haute avec DLSS », « Moyenne en 1600x900 »."""
        nom = NOMS.get(self.niveau, self.niveau)
        if self.meme_niveau:
            nom += " fluide"
        if self.genre == "echelle":
            return f"{nom} avec {self.libelle.split(' en mode')[0]}"
        return f"{nom} {self.libelle}"


def definitions_inferieures(machine: Machine) -> list[tuple[int, int]]:
    return [(largeur, hauteur) for largeur, hauteur in DEFINITIONS
            if largeur * hauteur < machine.pixels * 0.95]


def pistes(titre: str, exig: Exigences | None, machine: Machine,
           calibration: float = 1.0, actuel: Evaluation | None = None) -> list[Piste]:
    """Ce qui ferait monter ce jeu d'au moins un niveau SANS rien acheter,
    de la moins genante a la plus genante. Vide si le jeu est deja en
    « Haute », si c'est le processeur ou la memoire qui retient (changer la
    definition n'y fait rien), ou si le resultat ne vient pas d'une
    estimation."""
    if exig is None or machine.gpu is None:
        return []
    actuel = actuel or estimer(titre, exig, machine, calibration)
    if actuel.source != ESTIME or not actuel.niveau or rang(actuel) <= RANG["haute"]:
        return []
    if getattr(actuel, "bloque", ""):
        return []                     # aucun reglage ne le fait demarrer
    essais: list[tuple[Piste, float]] = []
    techno = machine.mise_a_l_echelle
    if techno:
        m = replace(machine, pixels=max(int(machine.pixels * PART_QUALITE), 1))
        e = estimer(titre, exig, m, calibration * COUT_ECHELLE)
        essais.append((Piste("echelle", f"{techno} en mode Qualite", e.niveau,
                             e.fps.get(e.niveau)), rang(e)))
    for largeur, hauteur in definitions_inferieures(machine)[:2]:
        m = replace(machine, pixels=largeur * hauteur, definition=f"{largeur}x{hauteur}")
        e = estimer(titre, exig, m, calibration)
        essais.append((Piste("definition", f"en {largeur}x{hauteur}", e.niveau,
                             e.fps.get(e.niveau)), rang(e)))
    gardees: list[Piste] = []
    meilleur = rang(actuel)
    for p, r in essais:
        # une piste n'est citee que si elle fait mieux que les precedentes,
        # moins genantes
        if r < meilleur:
            p.meme_niveau = p.niveau == actuel.niveau
            gardees.append(p)
            meilleur = r
    return gardees


# --------------------------------------------------------------------------
# Par jeu : ce qu'il manque
# --------------------------------------------------------------------------
def _plus_petit(valeurs: list[float], convient) -> float | None:
    """Plus petite valeur qui convient (les valeurs sont croissantes et
    « convient » ne redevient pas faux quand la valeur monte)."""
    bas, haut = 0, len(valeurs) - 1
    if haut < 0 or not convient(valeurs[haut]):
        return None
    while bas < haut:
        milieu = (bas + haut) // 2
        if convient(valeurs[milieu]):
            haut = milieu
        else:
            bas = milieu + 1
    return valeurs[bas]


def _marque_gpu(cle: str) -> str:
    if cle.startswith(("rtx", "gtx", "gt ")):
        return "nvidia"
    return "intel" if cle.startswith("arc") else "amd"


def _exemples_gpu(indice: float, combien: int = 2, ray_tracing: bool = False) -> str:
    """Cartes juste suffisantes : la plus recente de chaque marque (une
    NVIDIA et une AMD quand les deux existent a ce niveau) ; avec
    `ray_tracing`, seulement des cartes qui le calculent."""
    cartes = [(v, k) for v, k in _gpu_achetables() if v >= indice
              and (not ray_tracing or ray_tracing_materiel(k))]
    proches = [k for v, k in cartes if v <= indice * 1.12] or [k for _v, k in cartes[:1]]
    choisies: list[str] = []
    for marque in ("nvidia", "amd", "intel"):
        de_la_marque = sorted((k for k in proches if _marque_gpu(k) == marque),
                              key=lambda k: (-_generation(k), GPU[k]))
        if de_la_marque:
            choisies.append(de_la_marque[0])
    return " ou ".join(joli_gpu(k) for k in choisies[:combien])


def _generation(cle: str) -> int:
    m = re.search(r"\d{3,4}", cle)
    return int(m.group(0)) // 1000 * 1000 if m and len(m.group(0)) == 4 else 0


def _exemples_cpu(indice: float, combien: int = 2) -> str:
    tous = [(v, k, amd) for v, k, amd in _cpu_tous() if v >= indice]
    proches = [(k, amd) for v, k, amd in tous if v <= indice * 1.08][:8] \
        or [(k, amd) for _v, k, amd in tous[:1]]
    choisis: list[str] = []
    for marque in (True, False):                 # un AMD et un Intel
        for k, amd in proches:
            if amd is marque:
                choisis.append(joli_cpu(k, amd))
                break
    return " ou ".join(choisis[:combien])


@dataclass
class Besoin:
    """Ce qu'il faudrait pour un objectif (« jouable », « Haute ») : des
    indices de puissance a atteindre, pas des produits. `materiel` en tire,
    quand c'est possible, des pieces neuves compatibles."""
    cible: str               # basse | haute
    debut: str               # « Pour le niveau Haute »
    gpu: float | None = None  # indice de carte a atteindre
    cpu: float | None = None  # indice de processeur a atteindre
    ram_go: float = 0.0       # memoire vive demandee (0 : la votre suffit)
    vram_go: float = 0.0      # memoire video demandee (0 : la votre suffit)
    #: la carte doit calculer le ray tracing (le jeu l'exige)
    ray_tracing: bool = False

    @property
    def elements(self) -> list[str]:
        """Les morceaux de la phrase « Pour le niveau Haute : ... »."""
        morceaux: list[str] = []
        if self.cpu is not None:
            morceaux.append(f"un processeur du niveau d'un {_exemples_cpu(self.cpu)}")
        if self.gpu is not None:
            carte = (f"une carte graphique avec ray tracing materiel du niveau d'une "
                     f"{_exemples_gpu(self.gpu, ray_tracing=True)}" if self.ray_tracing
                     else f"une carte graphique du niveau d'une {_exemples_gpu(self.gpu)}")
            if self.vram_go:
                carte += f" ({self.vram_go:g} Go de memoire video)"
            morceaux.append(carte)
        if self.ram_go:
            morceaux.append(f"{self.ram_go:g} Go de memoire vive")
        if self.vram_go and self.gpu is None:
            morceaux.append(f"une carte graphique avec {self.vram_go:g} Go de memoire video")
        return morceaux

    @property
    def phrase(self) -> str:
        return f"{self.debut} : " + ", ".join(self.elements) + "."


def besoins(titre: str, exig: Exigences | None, machine: Machine,
            calibration: float = 1.0, actuel: Evaluation | None = None) -> list[Besoin]:
    """Ce qu'il faudrait changer pour jouer mieux : un besoin par objectif
    (« jouable », puis « Haute »). Les indices visent le composant juste
    suffisant."""
    if exig is None or not exig.exploitable or machine.gpu is None:
        return []
    actuel = actuel or estimer(titre, exig, machine, calibration)
    if actuel.source != ESTIME or not actuel.niveau or rang(actuel) <= RANG["haute"]:
        return []
    rec, mini = exig.recommandee, exig.minimum
    if not (rec and rec.gpu):
        # seule la configuration minimale est connue : l'estimation est trop
        # prudente pour en tirer un composant a viser
        return []
    # deja en « Haute » mais sous les 60 images/s : l'objectif est la fluidite
    haute = "Pour 60 images par seconde en Haute" if actuel.niveau == "haute" \
        else "Pour le niveau Haute"
    cibles = [("basse", "Pour qu'il soit jouable"), ("haute", haute)] \
        if actuel.niveau == "insuffisant" else [("haute", haute)]
    bloque = bool(getattr(actuel, "bloque", ""))
    # jeu qui exige le ray tracing materiel : il faut une autre carte, qui le
    # calcule ; elle peut etre moins puissante que celle d'aujourd'hui
    indices_gpu = sorted({v for v, k in _gpu_achetables()
                          if (ray_tracing_materiel(k) if bloque else v >= machine.gpu)})
    indices_cpu = sorted({v for v, _k, _a in _cpu_tous() if v >= (machine.cpu or 0)})
    resultat: list[Besoin] = []
    for cible, debut in cibles:
        b = Besoin(cible=cible, debut=debut, ray_tracing=bloque)
        essai = replace(machine, ray_tracing=True) if bloque else replace(machine)
        ref = rec if cible == "haute" else mini
        if ref and ref.ram_go and machine.ram_go and machine.ram_go + 0.5 < ref.ram_go:
            essai.ram_go = b.ram_go = float(ref.ram_go)
        if cible == "haute" and rec and rec.vram_go and machine.vram_go \
                and machine.vram_go < rec.vram_go:
            essai.vram_go = b.vram_go = float(rec.vram_go)

        def atteint(m: Machine) -> bool:
            e = estimer(titre, exig, m, calibration)
            if cible == "haute":
                return rang(e) <= RANG["haute"]              # « Haute », et fluide
            return RANG.get(e.niveau, 5) <= RANG[cible]      # jouable suffit

        if bloque:
            g = _plus_petit(indices_gpu, lambda v: atteint(replace(essai, gpu=v)))
            if g is None:
                continue
            b.gpu = g
        elif not atteint(essai):
            g = _plus_petit(indices_gpu, lambda v: atteint(replace(essai, gpu=v)))
            if g is not None:
                b.gpu = g
            elif machine.cpu is not None:
                c = _plus_petit(indices_cpu, lambda v: atteint(replace(essai, cpu=v)))
                if c is not None:
                    b.cpu = c
                elif indices_gpu and indices_cpu:
                    fort = replace(essai, gpu=indices_gpu[-1])
                    c = _plus_petit(indices_cpu, lambda v: atteint(replace(fort, cpu=v)))
                    if c is not None:
                        b.cpu = c
                        g = _plus_petit(indices_gpu,
                                        lambda v: atteint(replace(essai, cpu=c, gpu=v)))
                        if g is not None and g > machine.gpu:
                            b.gpu = g
            if b.gpu is None and b.cpu is None:
                continue                          # hors de portee : on ne dit rien
        if b.elements:
            resultat.append(b)
    return resultat


def manque(titre: str, exig: Exigences | None, machine: Machine,
           calibration: float = 1.0, actuel: Evaluation | None = None) -> list[str]:
    """Les besoins en phrases, une par objectif. Les composants cites sont
    des exemples du niveau requis, pas des recommandations d'achat."""
    return [b.phrase for b in besoins(titre, exig, machine, calibration, actuel)]


# --------------------------------------------------------------------------
# Par jeu : la configuration demandee face a la machine
# --------------------------------------------------------------------------
@dataclass
class Ligne:
    cle: str                 # gpu | cpu | vram | ram
    nom: str
    vous: str
    demande: str
    rapport: float | None    # votre composant / celui demande
    etat: str                # ok | juste | manque | inconnu


@dataclass
class Explication:
    titre: str
    base: str = ""           # « recommandee » | « minimale » | « »
    lignes: list[Ligne] = field(default_factory=list)
    #: ce que le jeu promet lui-meme avec cette configuration, quand ce n'est
    #: pas l'usage (60 images/s en 1920x1080 pour la recommandee)
    contexte: str = ""
    resume: str = ""
    #: quand des composants retiennent le jeu : le debut de la phrase et un
    #: morceau par composant (`resume` les assemble ; l'interface les traduit
    #: un a un)
    debut: str = ""
    retenus: list[str] = field(default_factory=list)
    manque: list[str] = field(default_factory=list)
    besoins: list[Besoin] = field(default_factory=list)
    pistes: list[Piste] = field(default_factory=list)


def _etat(rapport: float | None) -> str:
    if rapport is None:
        return "inconnu"
    return "ok" if rapport >= 1.0 else "juste" if rapport >= 0.8 else "manque"


def _lignes(ref: Config, machine: Machine) -> list[Ligne]:
    lignes: list[Ligne] = []
    if ref.gpu:
        r = machine.gpu / ref.gpu if machine.gpu else None
        lignes.append(Ligne("gpu", "Carte graphique",
                            f"{nom_propre(machine.gpu_nom) or 'non reconnue'}"
                            + (f" (indice {machine.gpu:g})" if machine.gpu else ""),
                            f"{joli_gpu(ref.gpu_nom.lower())} (indice {ref.gpu:g})",
                            r, _etat(r)))
    if ref.cpu:
        r = machine.cpu / ref.cpu if machine.cpu else None
        cle = (ref.cpu_nom or "").lower()
        # « 7700 » existe chez Intel et chez AMD : l'indice dit lequel
        amd = CPU_AMD.get(cle) == ref.cpu or cle not in CPU_INTEL
        lignes.append(Ligne("cpu", "Processeur",
                            f"{nom_propre(machine.cpu_nom) or 'non reconnu'}"
                            + (f" (indice {machine.cpu:g})" if machine.cpu else ""),
                            f"{joli_cpu(cle, amd)} (indice {ref.cpu:g})", r, _etat(r)))
    if ref.vram_go:
        r = machine.vram_go / ref.vram_go if machine.vram_go else None
        lignes.append(Ligne("vram", "Memoire video",
                            f"{machine.vram_go:g} Go" if machine.vram_go else "inconnue",
                            f"{ref.vram_go:g} Go", r, _etat(r)))
    if ref.ram_go:
        r = (machine.ram_go + 0.5) / ref.ram_go if machine.ram_go else None
        lignes.append(Ligne("ram", "Memoire vive",
                            f"{machine.ram_go:.0f} Go" if machine.ram_go else "inconnue",
                            f"{ref.ram_go:g} Go", r, _etat(r)))
    return lignes


def _definition(points: int) -> str:
    return {3840 * 2160: "3840x2160", 2560 * 1440: "2560x1440", 1920 * 1080: "1920x1080",
            1280 * 720: "1280x720"}.get(points, "une definition plus petite")


NOMS_NIVEAUX = {"basse": "Basse", "moyenne": "Moyenne", "haute": "Haute", "ultra": "Ultra"}
#: jeu qui exige le ray tracing materiel, sur une carte qui ne le calcule pas
RESUME_RAY_TRACING = ("Ne se lance pas sur ce PC : le jeu exige une carte graphique avec ray tracing materiel "
                      "(GeForce RTX, Radeon RX 6000 ou plus recente, Intel Arc).")
#: ce que l'objectif de l'editeur suppose (13 octobre 2026), une phrase par fait
SUPPOSE_GENERATION = ("Son objectif suppose la generation d'images : la carte n'en calcule qu'environ "
                      "six sur dix, l'estimation en tient compte.")
SUPPOSE_MISE_A_L_ECHELLE = ("Son objectif passe par une mise a l'echelle de l'image (DLSS, FSR) : la carte "
                            "calcule moins de points qu'elle n'en affiche, l'estimation en tient compte.")


def _contexte(ref: Config, base: str) -> str:
    """« Le jeu donne cette configuration pour 30 images par seconde » : sans
    cette precision, un PC deux fois plus fort que la configuration
    recommandee et pourtant classe « Basse » parait une erreur. Depuis le
    13 octobre 2026, une phrase de plus par fait que l'editeur ecrit :
    prereglage, generation d'images, mise a l'echelle."""
    usage = 60 if base == "recommandee" else 30
    defaut_niveau = "haute" if base == "recommandee" else "basse"
    ips = ref.cible_fps if ref.cible_fps and ref.cible_fps != usage else None
    points = ref.cible_px if ref.cible_px and ref.cible_px != 1920 * 1080 else None
    phrases = []
    definition = {3840 * 2160: "3840x2160", 2560 * 1440: "2560x1440",
                  1280 * 720: "1280x720"}.get(points or 0, "")
    morceaux = []
    if ips:
        morceaux.append(f"{ips} images par seconde")
    if definition:
        morceaux.append(f"un affichage en {definition}")
    if morceaux:
        phrases.append(f"Le jeu donne sa configuration {base} pour " + " et ".join(morceaux)
                       + f" (l'usage est {usage} images par seconde en 1920x1080).")
    niveau = getattr(ref, "cible_niveau", None)
    if niveau and niveau != defaut_niveau and niveau in NOMS_NIVEAUX:
        phrases.append(f"La configuration {base} de ce jeu vaut pour des reglages {NOMS_NIVEAUX[niveau]}.")
    if getattr(ref, "generation_images", False):
        phrases.append(SUPPOSE_GENERATION)
    if getattr(ref, "rendu_px", None):
        phrases.append(SUPPOSE_MISE_A_L_ECHELLE)
    return " ".join(phrases)


def expliquer(titre: str, evaluation: Evaluation, exig: Exigences | None,
              machine: Machine, calibration: float = 1.0) -> Explication:
    """Tout ce qu'ORION sait dire d'un jeu sur cette machine."""
    x = Explication(titre=titre)
    if exig is not None and exig.exploitable:
        rec, mini = exig.recommandee, exig.minimum
        ref = rec if (rec and rec.gpu) else mini
        x.base = "recommandee" if ref is rec else "minimale"
        x.lignes = _lignes(ref, machine)
        x.contexte = _contexte(ref, x.base)
    niveau = NOMS.get(evaluation.niveau, "")
    if evaluation.source != ESTIME:
        x.resume = {
            "mesure": f"Mesure sur votre PC : niveau {niveau}." if niveau else "",
            "communaute": f"D'apres les joueurs equipes comme vous : niveau {niveau}."
            if niveau else "",
        }.get(evaluation.source, "Pas assez d'informations pour evaluer ce jeu.")
        return x
    if getattr(evaluation, "bloque", ""):
        x.resume = RESUME_RAY_TRACING
        x.besoins = besoins(titre, exig, machine, calibration, evaluation)
        x.manque = [b.phrase for b in x.besoins]
        return x
    f = frein(evaluation)
    if not f:
        # niveau « Haute » atteint : ne pas dire que le PC « depasse » la
        # configuration si un composant est en dessous (processeur a 77 % de
        # la demande, compense par la carte graphique)
        sous = [li for li in x.lignes if li.rapport is not None and li.rapport < 1]
        if sous and x.base:
            x.debut = f"Niveau {niveau} attendu. Sous la configuration {x.base} : "
            x.retenus = [f"{NOMS_COMPOSANTS[li.cle]} ({round(li.rapport * 100)} % de la demande)"
                         for li in sous]
            x.resume = x.debut + " · ".join(x.retenus) + "."
        else:
            x.resume = (f"Votre PC depasse la configuration {x.base} : niveau {niveau} attendu."
                        if x.base else f"Niveau {niveau} attendu.")
        return x
    x.pistes = pistes(titre, exig, machine, calibration, evaluation)
    if x.base == "minimale":
        # le jeu ne publie que son minimum : on ne designe pas de coupable
        x.resume = ((f"Niveau {niveau}" if evaluation.niveau != "insuffisant"
                     else "Trop juste en l'etat")
                    + ", estimation tres prudente : le jeu ne publie que sa configuration "
                      "minimale. Une mesure en jeu dira mieux.")
        return x
    # le frein d'abord, puis les autres composants sous la configuration demandee
    courts = [f] + [li.cle for li in x.lignes
                    if li.cle != f and li.rapport is not None and li.rapport < 1]
    carte = next((li for li in x.lignes if li.cle == "gpu" and li.rapport is not None), None)
    voulue = (ref.cible_px or 1920 * 1080) if carte is not None else 0
    if f == "gpu" and carte is not None and carte.rapport >= 1 and machine.pixels > voulue * 1.2:
        # la carte vaut celle demandee, mais pour une definition plus petite
        # que l'ecran du joueur : c'est l'ecran qui retient le jeu, et la
        # piste « Haute en 1920x1080 » le confirme
        x.retenus.append(f"definition de l'ecran ({machine.definition} : la configuration "
                         f"demandee vaut pour {_definition(voulue)})")
        courts = courts[1:]
    for cle in courts:
        ligne = next((li for li in x.lignes if li.cle == cle and li.rapport is not None), None)
        part = ""
        if ligne is not None and ligne.rapport < 1:
            part = f" ({round(ligne.rapport * 100)} % de la demande)"
        elif ligne is not None and cle == f and ligne.rapport < 1.2:
            # au niveau demande, mais l'estimation garde une marge : sans
            # cette precision, « 105 % et pourtant retenu » parait une erreur
            part = " (au niveau de la demande, sans marge)"
        x.retenus.append(NOMS_COMPOSANTS[cle] + part)
    if evaluation.niveau == "insuffisant":
        x.debut = "Trop juste en l'etat. Ce qui manque : "
    elif not getattr(evaluation, "fluide", True):
        x.debut = f"Niveau {niveau}, sous les 60 images par seconde. Ce qui le retient : "
    else:
        x.debut = f"Niveau {niveau}. Ce qui le retient : "
    x.resume = x.debut + " · ".join(x.retenus) + "."
    x.besoins = besoins(titre, exig, machine, calibration, evaluation)
    x.manque = [b.phrase for b in x.besoins]
    return x
