"""Garder en image un dessin couteux qui ne change pas a chaque image (2.0).

Un widget dessine en Python (degrades, formes arrondies, textes mesures) est
redessine en entier a chaque rafraichissement : pendant un defilement, une
animation, ou chaque seconde pour un compte a rebours. Quand ce qu'il montre
n'a pas change, c'est du travail perdu, et c'est lui qui fait accrocher la
fenetre (page Sorties, mesure du 7 octobre 2026 : 100 a 160 ms par image).

    self._fond = Tampon()
    def paintEvent(self, _e):
        p = QPainter(self)
        self._fond.peindre(self, p, (self.titre, self.survol), self._dessiner_fixe)
        self._dessiner_ce_qui_bouge(p)

`cle` dit tout ce dont le dessin fixe depend : tant qu'elle ne change pas (et
que la taille du widget non plus), l'image gardee est recopiee.
"""
from __future__ import annotations

from PySide6.QtCore import QSize, Qt
from PySide6.QtGui import QPainter, QPixmap


class Tampon:
    def __init__(self) -> None:
        self._image: QPixmap | None = None
        self._cle = None
        #: ce que le dernier dessin a rendu (une position utile a la suite, par exemple)
        self.rendu = None

    def oublier(self) -> None:
        self._image, self._cle = None, None

    def peindre(self, widget, p: QPainter, cle, dessiner) -> None:
        """Recopie l'image gardee dans `p` ; la redessine d'abord avec
        `dessiner(peintre)` si `cle` ou la taille du widget a change."""
        dpr = widget.devicePixelRatioF()
        taille = QSize(max(1, round(widget.width() * dpr)), max(1, round(widget.height() * dpr)))
        cle = (cle, taille.width(), taille.height())
        if self._image is None or cle != self._cle:
            image = QPixmap(taille)
            image.setDevicePixelRatio(dpr)
            image.fill(Qt.GlobalColor.transparent)
            q = QPainter(image)
            try:
                self.rendu = dessiner(q)
            finally:
                if q.isActive():
                    q.end()
            self._image, self._cle = image, cle
        p.drawPixmap(0, 0, self._image)
