"""Defilement a la molette, plus ample et glisse, dans toute l'application.

La molette de Windows avance de trois lignes par cran : sur les longues
pages d'ORION (bibliotheque, reglages, tuto) il fallait beaucoup de crans
pour descendre. Un filtre unique, pose sur l'application, remplace ce pas
par une fraction de la hauteur visible et anime le deplacement. Les crans
successifs s'ajoutent : rouler vite fait descendre vite.

Ne sont pas touches : les paves tactiles (deja fluides), Ctrl+molette, les
barres de defilement elles-memes, les pages web integrees, et les zones qui
gerent elles-memes leur molette.

Listes deroulantes, champs numeriques et curseurs (2.0) : la molette ne
change JAMAIS leur valeur. Qt la leur donne des que le pointeur passe
dessus, meme sans clic ; sur une longue page (Reglages), la page glisse sous
le pointeur et le cran suivant tombait sur « Pays », « Langue » ou « Largeur
des tuiles » : le reglage changeait sans que le joueur l'ait voulu, ni vu.
Ici la molette fait defiler la page qui les porte ; la valeur se change au
clic ou au clavier.
"""
from __future__ import annotations

import time

from PySide6.QtCore import QEasingCurve, QEvent, QObject, QPropertyAnimation, Qt
from PySide6.QtWidgets import (QAbstractScrollArea, QAbstractSlider, QAbstractSpinBox,
                               QApplication, QComboBox, QScrollArea, QScrollBar,
                               QWidget)

from . import repos

#: ce que fait le joueur : pendant ces gestes, aucune mise a jour de fond
_GESTES = frozenset({QEvent.Type.Wheel, QEvent.Type.KeyPress, QEvent.Type.MouseMove,
                     QEvent.Type.MouseButtonPress, QEvent.Type.MouseButtonRelease})

#: part de la hauteur visible parcourue par cran de molette
PART = 0.42
PAS_MINI, PAS_MAXI = 160, 520
DUREE = 260


#: instant de la derniere touche Tab (voir `ZoneDefilante`)
_dernier_tab = 0.0


class ZoneDefilante(QScrollArea):
    """Zone de defilement qui ne saute pas toute seule.

    Quand l'element qui a le focus disparait (une page qui se reconstruit,
    un bouton qu'on masque), Qt donne le focus a l'element suivant, et
    `QScrollArea` fait alors defiler la page jusqu'a lui : la fiche d'un jeu
    s'ouvrait au milieu, sans que personne n'ait touche a rien. Ici la page
    ne suit le focus que si le joueur vient d'appuyer sur Tab."""

    def focusNextPrevChild(self, suivant: bool) -> bool:      # noqa: N802
        fait = QWidget.focusNextPrevChild(self, suivant)
        if fait and time.monotonic() - _dernier_tab < 0.6:
            cible = self.focusWidget()
            if cible is not None and self.widget() is not None \
                    and self.widget().isAncestorOf(cible):
                self.ensureWidgetVisible(cible)
        return fait


class DefilementGlisse(QObject):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._anims: dict[int, tuple[QPropertyAnimation, int]] = {}

    # ------------------------------------------------------------------
    @staticmethod
    def _reglage(widget) -> QWidget | None:
        """Liste deroulante, champ numerique ou curseur sous la molette, ou
        None. La liste OUVERTE d'une liste deroulante est une fenetre a part
        (on s'arrete a la fenetre) : elle defile normalement."""
        w = widget
        while w is not None:
            if isinstance(w, QScrollBar):
                return None
            if isinstance(w, (QComboBox, QAbstractSpinBox, QAbstractSlider)):
                return w
            if w.isWindow():
                return None
            w = w.parentWidget()
        return None

    @staticmethod
    def _zone(widget) -> QAbstractScrollArea | None:
        """Premiere zone de defilement, au-dessus du widget, qui peut encore
        bouger verticalement."""
        w = widget
        while w is not None:
            if isinstance(w, (QComboBox, QAbstractSpinBox, QAbstractSlider)):
                return None
            if w.metaObject().className().startswith("QWebEngine"):
                return None
            if isinstance(w, QAbstractScrollArea):
                barre = w.verticalScrollBar()
                if barre.maximum() > barre.minimum():
                    return w
            w = w.parentWidget()
        return None

    def eventFilter(self, objet, event) -> bool:      # noqa: N802
        if event.type() == QEvent.Type.Polish and isinstance(
                objet, (QComboBox, QAbstractSpinBox, QAbstractSlider)) \
                and not isinstance(objet, QScrollBar) \
                and objet.focusPolicy() == Qt.FocusPolicy.WheelFocus:
            # un reglage ne prend plus le focus parce que la molette passe
            # dessus (Qt le lui donne avant meme de livrer la molette) : le
            # clic et la touche Tab suffisent
            objet.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
            return False
        if event.type() in _GESTES:
            repos.geste()            # les mises a jour de fond attendront
        if event.type() == QEvent.Type.KeyPress and event.key() in (
                Qt.Key.Key_Tab, Qt.Key.Key_Backtab):
            global _dernier_tab
            _dernier_tab = time.monotonic()
            return False
        if event.type() != QEvent.Type.Wheel or not objet.isWidgetType():
            return False
        reglage = self._reglage(objet)
        if reglage is not None:
            # la molette (ou le pave tactile) ne change pas un reglage : elle
            # est rendue a la page qui le porte, et ne fait rien s'il n'y a
            # rien a faire defiler
            zone = self._zone(reglage.parentWidget())
            if zone is not None:
                QApplication.sendEvent(zone.viewport(), event)
            # la molette s'arrete ici : sans cela Qt la proposerait au
            # parent du reglage, et la page avancerait deux fois
            event.accept()
            return True
        dy = event.angleDelta().y()
        if (not dy or event.angleDelta().x() or not event.pixelDelta().isNull()
                or event.modifiers() & (Qt.KeyboardModifier.ControlModifier
                                        | Qt.KeyboardModifier.ShiftModifier)):
            return False
        zone = self._zone(objet)
        if zone is None:
            return False
        barre = zone.verticalScrollBar()
        cle = id(barre)
        anim, cible = self._anims.get(cle, (None, barre.value()))
        if anim is None:
            anim = QPropertyAnimation(barre, b"value", self)
            anim.setEasingCurve(QEasingCurve.Type.OutCubic)
            barre.destroyed.connect(lambda *_: self._anims.pop(cle, None))
        depart = cible if anim.state() == QPropertyAnimation.State.Running else barre.value()
        pas = max(PAS_MINI, min(PAS_MAXI, int(zone.viewport().height() * PART)))
        cible = max(barre.minimum(), min(barre.maximum(),
                                         int(depart - dy / 120.0 * pas)))
        if cible == barre.value() and anim.state() != QPropertyAnimation.State.Running:
            return False                     # en butee : la zone parente prend le relais
        anim.stop()
        anim.setDuration(DUREE)
        anim.setStartValue(barre.value())
        anim.setEndValue(cible)
        anim.start()
        self._anims[cle] = (anim, cible)
        return True


def installer(app: QApplication) -> DefilementGlisse:
    filtre = DefilementGlisse(app)
    app.installEventFilter(filtre)
    return filtre
