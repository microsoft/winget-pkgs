"""Bouton portant une pastille de compteur (« Gratuits  4 »).

Qt ne sait pas mettre de texte riche dans un QPushButton : la pastille est
donc dessinee par le bouton lui-meme, a droite de son libelle, et la place
qu'elle occupe est ajoutee a la taille demandee par le bouton. Aucun widget
enfant : le clic, le survol et la navigation au clavier restent ceux d'un
bouton ordinaire.
"""
from __future__ import annotations

from PySide6.QtCore import QRectF, QSize, Qt
from PySide6.QtGui import QColor, QFont, QFontMetrics, QPainter
from PySide6.QtWidgets import QPushButton

from ..theme import PALETTE


class BoutonPastille(QPushButton):
    """QPushButton + pastille de compteur dessinee a droite du texte."""

    MARGE = 8          # entre le texte et la pastille
    HAUTEUR = 18

    def __init__(self, texte: str = "", parent=None, marge_texte: int = 16,
                 marge_droite: int = -1) -> None:
        super().__init__(texte, parent)
        #: >= 0 : pastille calee a droite du bouton, a cette distance du bord
        #: (barre laterale : les compteurs s'alignent en colonne)
        self.marge_droite = marge_droite
        #: abscisse du texte : le style du bouton doit l'aligner a gauche
        #: (« text-align: left ») avec ce retrait (marge + padding)
        self.marge_texte = marge_texte
        self._pastille = ""
        self._couleur = PALETTE["ok"]

    # ------------------------------------------------------------------
    def set_pastille(self, texte: str, couleur: str = "") -> None:
        """Texte de la pastille (vide = pas de pastille)."""
        texte = str(texte or "")
        if couleur:
            self._couleur = couleur
        if texte == self._pastille:
            self.update()
            return
        self._pastille = texte
        self.updateGeometry()
        self.update()

    def pastille(self) -> str:
        return self._pastille

    # ------------------------------------------------------------------
    def _police(self) -> QFont:
        f = QFont(self.font())
        f.setPixelSize(11)
        f.setBold(True)
        return f

    def _largeur_pastille(self) -> int:
        if not self._pastille:
            return 0
        largeur = QFontMetrics(self._police()).horizontalAdvance(self._pastille)
        return max(self.HAUTEUR, largeur + 12)

    def sizeHint(self) -> QSize:                    # noqa: N802
        base = super().sizeHint()
        if self.marge_droite >= 0:
            return base                 # la pastille se loge dans la largeur fixe
        extra = self._largeur_pastille()
        return QSize(base.width() + (extra + self.MARGE if extra else 0), base.height())

    def minimumSizeHint(self) -> QSize:             # noqa: N802
        return self.sizeHint()

    def paintEvent(self, event) -> None:            # noqa: N802
        super().paintEvent(event)
        if not self._pastille:
            return
        largeur = self._largeur_pastille()
        # la pastille suit le texte, cale a gauche par le style du bouton
        if self.marge_droite >= 0:
            x = self.width() - self.marge_droite - largeur
        else:
            texte = QFontMetrics(self.font()).horizontalAdvance(self.text())
            x = min(self.width() - largeur - 6, self.marge_texte + texte + self.MARGE)
        y = (self.height() - self.HAUTEUR) / 2
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        fond = QColor(self._couleur)
        if not self.isEnabled():
            fond.setAlpha(90)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(fond)
        rect = QRectF(x, y, largeur, self.HAUTEUR)
        p.drawRoundedRect(rect, self.HAUTEUR / 2, self.HAUTEUR / 2)
        p.setPen(QColor("#04121A"))
        p.setFont(self._police())
        p.drawText(rect, Qt.AlignmentFlag.AlignCenter, self._pastille)
        p.end()
