"""Page « Stockage » : ce qu'occupent les jeux, disque par disque.

La question posee ici est « qu'est-ce qui remplit mes disques ? ». La page
montre donc tout ce qui est installe, un disque a la fois, et signale au
passage ce qui dort depuis longtemps. Elle ne supprime jamais un jeu
elle-meme : elle archive la sauvegarde puis ouvre le desinstalleur de la
plateforme concernee.

Depuis la 1.9, elle sauvegarde aussi un jeu sur un autre disque (copie
complete et verifiee, sans toucher au jeu installe), montre ces
sauvegardes jeu par jeu et disque par disque, et permet de les restaurer
ou de les supprimer. L'ancien « Deplacer » (jonction) n'est plus propose ;
« Ramener » reste pour les jeux deja deplaces.
"""
from __future__ import annotations

import os
import threading
import time

from PySide6.QtCore import QObject, Qt, Signal
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (QButtonGroup, QFrame, QHBoxLayout, QHeaderView,
                               QLabel, QLineEdit, QProgressBar, QPushButton,
                               QSizePolicy, QTableWidget,
                               QTableWidgetItem, QVBoxLayout, QWidget)

from ...core.models import HardwareInfo
from ...i18n import t
from ...storage import disk_letter
from ..theme import PALETTE, accent
from ..widgets.layouts import clear_layout

#: valeur utilisee pour « tous les disques »
TOUS = "*"

COLONNES = ["Jeu", "Disque", "Taille", "Temps de jeu", "Derniere partie",
            "Sauvegarde", "Etat"]
COL_JEU, COL_DISQUE, COL_TAILLE, COL_TEMPS, COL_DERNIERE, COL_SAUVEGARDE, COL_ETAT = range(7)

#: tri de la liste : colonne -> (cle, sens au premier clic). Le premier clic
#: va dans le sens utile : les plus gros, les plus joues, les parties les
#: plus anciennes, ce qui dort d'abord.
TRIS = {
    COL_JEU: (lambda e: e.game.title.lower(), False),
    COL_DISQUE: (lambda e: (e.disk.upper(), -e.game.size_bytes), False),
    COL_TAILLE: (lambda e: e.game.size_bytes, True),
    COL_TEMPS: (lambda e: e.game.total_play_seconds, True),
    COL_DERNIERE: (lambda e: e.game.last_played or 0, False),
    COL_SAUVEGARDE: (lambda e: (len(e.sauvegardes), (e.sauvegardes[0].get("date") or 0)
                                if e.sauvegardes else 0), True),
    COL_ETAT: (lambda e: (e.dormant, e.score), True),
}

#: filtres de la liste (cle, libelle)
FILTRES = (("tout", "Tout"), ("dormants", "Ce qui dort"), ("sauvegardes", "Sauvegardes"))


def trier(entrees: list, colonne: int, decroissant: bool) -> list:
    """Entrees triees ; les jeux installes restent devant ceux qui ne sont
    plus la que pour leur sauvegarde."""
    cle = TRIS.get(colonne, TRIS[COL_TAILLE])[0]
    triees = sorted(entrees, key=cle, reverse=decroissant)
    return sorted(triees, key=lambda e: not e.installe)


class Presences(QObject):
    """Une sauvegarde est-elle joignable ? La question est posee hors du fil
    d'affichage : sur un disque externe en veille ou un lecteur reseau
    debranche, `os.path.isdir` peut attendre plusieurs secondes, et la
    fenetre se figeait a la selection d'un jeu."""

    connue = Signal(str, bool)
    GARDER = 20.0                      # secondes avant de reposer la question

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._memo: dict[str, tuple[bool, float]] = {}
        self._en_cours: set[str] = set()
        self.connue.connect(self._noter)

    def lire(self, chemin: str) -> bool | None:
        """Vrai / faux, ou None si on ne sait pas encore (la reponse arrive
        par `connue`). Une reponse ancienne est rendue en attendant la
        nouvelle."""
        memo = self._memo.get(chemin)
        if memo is not None and time.monotonic() - memo[1] < self.GARDER:
            return memo[0]
        if chemin not in self._en_cours:
            self._en_cours.add(chemin)
            threading.Thread(target=self._verifier, args=(chemin,),
                             name="orion-presence", daemon=True).start()
        return memo[0] if memo is not None else None

    def _verifier(self, chemin: str) -> None:
        try:
            presente = os.path.isdir(chemin)
        except OSError:
            presente = False
        try:
            self.connue.emit(chemin, presente)
        except RuntimeError:
            pass                        # page fermee entre-temps

    def _noter(self, chemin: str, presente: bool) -> None:
        self._memo[chemin] = (presente, time.monotonic())
        self._en_cours.discard(chemin)


def _taille(octets: float) -> str:
    from ...deplacement import taille_lisible
    return taille_lisible(octets)


def _qss() -> str:
    """Styles propres a la page, tires de la palette du theme."""
    p = dict(PALETTE)
    p["accent"] = accent()
    return """
QFrame#CopieCarte {{
    background: rgba(20, 25, 38, 225); border: 1px solid {accent_dim};
    border-left: 3px solid {accent}; border-radius: 12px;
}}
QLabel#CopieTitre {{ font-size: 14px; font-weight: 600; }}
QLabel#CopieDetail {{ color: {text_dim}; font-size: 12px; }}
QLabel#CopieFichier {{ color: {text_faint}; font-size: 11px; }}
QLabel#CopiePourcent {{ color: {accent}; font-size: 22px; font-weight: 700; }}
QProgressBar#CopieBarre {{
    background: {bg}; border: 1px solid {border}; border-radius: 5px;
    min-height: 10px; max-height: 10px;
}}
QProgressBar#CopieBarre::chunk {{
    border-radius: 4px;
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                stop:0 {accent_dim}, stop:1 {accent});
}}
QFrame#DiskCard[absent="oui"] {{ border-style: dashed; }}
QFrame#SauvegardesCarte {{
    background: rgba(14, 18, 28, 200); border: 1px solid {border};
    border-radius: 12px;
}}
QLabel#SauvegardesTitre {{ font-size: 13px; font-weight: 600; }}
QFrame#SauvegardeLigne {{
    background: {surface}; border: 1px solid {border};
    border-left: 3px solid {ok}; border-radius: 9px;
}}
QFrame#SauvegardeLigne[etat="absente"] {{ border-left: 3px solid {warn}; }}
QLabel#SauvegardeEtat {{
    color: {ok}; border: 1px solid {ok}; border-radius: 8px;
    padding: 1px 8px; font-size: 10px; font-weight: 600;
}}
QLabel#SauvegardeEtat[etat="absente"] {{ color: {warn}; border-color: {warn}; }}
QLabel#SauvegardeEtat[etat="inconnue"] {{ color: {text_faint}; border-color: {border}; }}
QFrame#SauvegardeLigne[etat="inconnue"] {{ border-left: 3px solid {border}; }}
QLabel#DiskSauvegardes {{ color: {ok}; font-size: 11px; }}
QLabel#DiskSauvegardes[vide="oui"] {{ color: {text_faint}; }}
QPushButton#Sauvegarder {{
    background: rgba(56, 225, 255, 28); border: 1px solid {accent_dim};
    color: {text}; font-weight: 600;
}}
QPushButton#Sauvegarder:hover {{ border-color: {accent}; color: {accent}; }}
QPushButton#Sauvegarder:disabled {{
    background: {bg_alt}; border-color: {border}; color: {text_faint};
}}
QPushButton#Danger {{ background: transparent; border: 1px solid {border}; }}
QPushButton#Danger:hover {{ border-color: {danger}; color: {danger}; }}
QPushButton#Danger:disabled {{ color: {text_faint}; }}
QLabel#CalculInfo {{ color: {text_faint}; font-size: 11px; }}
QLabel#CalculInfo[etat="frais"] {{ color: {ok}; }}
""".format(**p)


class DiskCard(QFrame):
    """Carte d'un disque, cliquable : elle filtre la liste en dessous."""

    clicked = Signal(str)

    def __init__(self, disk: dict, parent=None) -> None:
        super().__init__(parent)
        self.key = str(disk.get("mount", "?")).rstrip("\\/").upper()
        self.setObjectName("DiskCard")
        # cinq disques ou plus tiennent dans la largeur de la fenetre
        self.setMinimumWidth(190)
        self.setMaximumWidth(270)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 12, 14, 12)
        lay.setSpacing(6)

        titre = QHBoxLayout()
        name = QLabel(f"Disque {self.key or '?'}")
        name.setObjectName("Value")
        titre.addWidget(name)
        titre.addStretch(1)
        n_jeux = int(disk.get("jeux", 0) or 0)
        jeux = QLabel(f"{n_jeux} jeu{'x' if n_jeux > 1 else ''}")
        jeux.setObjectName("Faint")
        titre.addWidget(jeux)
        lay.addLayout(titre)

        used = disk.get("percent_used")
        if used is None and disk.get("total_gb"):
            used = round((disk["total_gb"] - disk.get("free_gb", 0))
                         / disk["total_gb"] * 100)
        bar = QProgressBar()
        bar.setRange(0, 100)
        bar.setValue(int(used or 0))
        bar.setTextVisible(False)
        bar.setFixedHeight(6)
        if (used or 0) >= 92:
            bar.setStyleSheet(f"QProgressBar::chunk {{ background:{PALETTE['danger']}; }}")
        elif (used or 0) >= 80:
            bar.setStyleSheet(f"QProgressBar::chunk {{ background:{PALETTE['warn']}; }}")
        lay.addWidget(bar)

        if disk.get("total_gb"):
            detail = (f"{disk.get('free_gb', 0)} Go libres sur "
                      f"{disk.get('total_gb', 0)} Go")
        elif disk.get("absent"):
            detail = "non detecte (debranche ?)"
            self.setProperty("absent", "oui")
        else:
            detail = "capacite inconnue"
        libre = QLabel(detail)
        libre.setObjectName("Faint")
        lay.addWidget(libre)

        occupe = QLabel((f"{disk.get('jeux_go', 0):.0f} Go de jeux" if n_jeux
                         else "aucun jeu installe")
                        + (f"  ·  {disk.get('dormants_go', 0):.0f} Go dorment"
                           if disk.get("dormants_go") else ""))
        occupe.setObjectName("Dim")
        lay.addWidget(occupe)

        n = int(disk.get("sauvegardes", 0) or 0)
        if n:
            texte = (f"{n} sauvegarde{'s' if n > 1 else ''}  ·  "
                     f"{disk.get('sauvegardes_go', 0):.0f} Go")
        else:
            texte = "aucune sauvegarde"
        self.sauvegardes = QLabel(texte)
        self.sauvegardes.setObjectName("DiskSauvegardes")
        self.sauvegardes.setProperty("vide", "non" if n else "oui")
        lay.addWidget(self.sauvegardes)

    def set_active(self, active: bool) -> None:
        self.setProperty("actif", "oui" if active else "non")
        self.style().unpolish(self)
        self.style().polish(self)

    def mouseReleaseEvent(self, event) -> None:      # noqa: N802 (API Qt)
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit(self.key)
        super().mouseReleaseEvent(event)


class CopieCarte(QFrame):
    """Avancement d'une copie (sauvegarde, restauration, retour) : titre,
    pourcentage, taille copiee et temps restant, fichier en cours, et le
    bouton « Annuler »."""

    annuler = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("CopieCarte")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(16, 12, 16, 12)
        lay.setSpacing(7)

        haut = QHBoxLayout()
        haut.setSpacing(14)
        textes = QVBoxLayout()
        textes.setSpacing(2)
        self.titre = QLabel("")
        self.titre.setObjectName("CopieTitre")
        textes.addWidget(self.titre)
        self.detail = QLabel("")
        self.detail.setObjectName("CopieDetail")
        textes.addWidget(self.detail)
        haut.addLayout(textes, 1)
        self.pourcent = QLabel("")
        self.pourcent.setObjectName("CopiePourcent")
        self.pourcent.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        haut.addWidget(self.pourcent)
        self.bouton = QPushButton("Annuler")
        self.bouton.setObjectName("Danger")
        self.bouton.setToolTip("Arrete la copie et supprime ce qui a deja ete copie. "
                               "Le jeu installe n'est pas touche.")
        self.bouton.clicked.connect(self._annuler)
        haut.addWidget(self.bouton)
        lay.addLayout(haut)

        self.barre = QProgressBar()
        self.barre.setObjectName("CopieBarre")
        self.barre.setRange(0, 100)
        self.barre.setTextVisible(False)
        lay.addWidget(self.barre)

        self.fichier = QLabel("")
        self.fichier.setObjectName("CopieFichier")
        self._fichier_brut = ""
        lay.addWidget(self.fichier)
        self.hide()

    def debut(self, titre: str, sous_titre: str, annulable: bool,
              indetermine: bool = False) -> None:
        """`indetermine` : operation sans pourcentage (suppression)."""
        self.titre.setText(titre)
        self.detail.setText(sous_titre)
        self.pourcent.setText("" if indetermine else "0 %")
        self.barre.setRange(0, 0 if indetermine else 100)
        self.barre.setValue(0)
        self._set_fichier("")
        self.bouton.setText("Annuler")
        self.bouton.setVisible(annulable)
        self.bouton.setEnabled(annulable)
        self.show()

    def progression(self, message: str, pourcent: int) -> None:
        ligne, _, fichier = (message or "").partition("\n")
        if ligne.startswith("Verification"):
            self.barre.setRange(0, 0)                    # barre animee
            self.pourcent.setText("100 %")
            self.bouton.setEnabled(False)
        else:
            self.barre.setRange(0, 100)
            if pourcent is not None and pourcent >= 0:
                self.barre.setValue(int(pourcent))
                self.pourcent.setText(f"{int(pourcent)} %")
        if self.bouton.text() == "Annuler" and ligne:
            self.detail.setText(ligne)
        self._set_fichier(fichier)

    def _set_fichier(self, texte: str) -> None:
        self._fichier_brut = texte
        largeur = max(self.fichier.width(), 420)
        self.fichier.setText(self.fichier.fontMetrics().elidedText(
            texte, Qt.TextElideMode.ElideMiddle, largeur) if texte else "")
        self.fichier.setToolTip(texte)

    def _annuler(self) -> None:
        self.bouton.setEnabled(False)
        self.bouton.setText("Annulation...")
        self.detail.setText("Arret en cours : la copie partielle va etre supprimee...")
        self.annuler.emit()


class StorageView(QWidget):
    refresh_requested = Signal()            # recharge l'affichage (sans mesurer)
    recalcul_requested = Signal()           # bouton « Recalculer » : remesure
    uninstall_requested = Signal(str)       # uid
    open_folder_requested = Signal(str)     # uid
    sauvegarder_requested = Signal(str)     # uid
    restaurer_requested = Signal(str, str)  # uid, dossier de la sauvegarde
    supprimer_sauvegarde_requested = Signal(str, str)   # uid, dossier
    ouvrir_sauvegarde_requested = Signal(str)           # dossier
    annuler_requested = Signal()            # arreter la copie en cours
    ramener_requested = Signal(str)         # uid (jeux deplaces en 1.8)
    ouvrir_fiche_requested = Signal(str)    # uid : double-clic sur une ligne

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._all: list = []                # toutes les entrees
        self._entries: list = []            # entrees affichees (filtrees)
        self._cards: list[DiskCard] = []
        self.disk = TOUS
        self.filtre = "tout"
        self._tri = (COL_TAILLE, True)      # colonne, decroissant
        self._occupe = False                # copie en cours
        self._calcul = False                # recalcul en cours
        self.presences = Presences(self)
        self.presences.connue.connect(self._presence_connue)
        self.setStyleSheet(_qss())

        root = QVBoxLayout(self)
        root.setContentsMargins(24, 18, 24, 18)
        root.setSpacing(12)

        bar = QHBoxLayout()
        title = QLabel("Stockage")
        title.setObjectName("PageTitle")
        bar.addWidget(title)
        self.summary = QLabel("")
        self.summary.setObjectName("PageHint")
        bar.addWidget(self.summary)
        bar.addStretch(1)
        self.calcul_info = QLabel("tailles annoncees par les launchers")
        self.calcul_info.setObjectName("CalculInfo")
        bar.addWidget(self.calcul_info)
        self.refresh = QPushButton("Recalculer")
        self.refresh.setObjectName("Ghost")
        self.refresh.setMinimumWidth(130)
        self.refresh.setToolTip("Remesure la taille reelle de chaque jeu installe et "
                                "la place libre de chaque disque.")
        self.refresh.clicked.connect(self.recalcul_requested.emit)
        bar.addWidget(self.refresh)
        root.addLayout(bar)

        # -- disques, cliquables ---------------------------------------
        self.disks_box = QHBoxLayout()
        self.disks_box.setSpacing(12)
        root.addLayout(self.disks_box)

        # -- choix du disque -------------------------------------------
        choix = QHBoxLayout()
        choix.setSpacing(8)
        self.all_button = QPushButton("Tous les disques")
        self.all_button.setObjectName("Ghost")
        self.all_button.setMinimumWidth(160)
        self.all_button.setCheckable(True)
        self.all_button.setChecked(True)
        self.all_button.clicked.connect(lambda: self._choose(TOUS))
        choix.addWidget(self.all_button)
        # -- filtres de la liste ---------------------------------------
        self._groupe_filtres = QButtonGroup(self)
        self._groupe_filtres.setExclusive(True)
        self.filtres: dict[str, QPushButton] = {}
        for cle, texte in FILTRES:
            b = QPushButton(texte)
            b.setObjectName("Chip")
            b.setCheckable(True)
            b.setChecked(cle == self.filtre)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.clicked.connect(lambda _=False, c=cle: self.filtrer(c))
            self._groupe_filtres.addButton(b)
            choix.addWidget(b)
            self.filtres[cle] = b
        self.filtres["dormants"].setToolTip(
            "Jeux installes jamais vraiment joues, ou sans partie depuis plus de "
            "trois mois : la place la plus facile a recuperer.")
        self.filtres["sauvegardes"].setToolTip(
            "Jeux dont une copie complete existe sur un autre disque.")
        self.scope = QLabel("")
        self.scope.setObjectName("Faint")
        choix.addWidget(self.scope)
        choix.addStretch(1)
        self.recherche = QLineEdit()
        self.recherche.setObjectName("Search")
        self.recherche.setPlaceholderText("Rechercher un jeu...")
        self.recherche.setClearButtonEnabled(True)
        self.recherche.setFixedWidth(210)
        self.recherche.textChanged.connect(lambda _t: self._apply(self._selected_uid()))
        choix.addWidget(self.recherche)
        root.addLayout(choix)

        # -- copie en cours --------------------------------------------
        self.copie = CopieCarte()
        self.copie.annuler.connect(self.annuler_requested.emit)
        root.addWidget(self.copie)

        self.table = QTableWidget(0, len(COLONNES))
        self.table.setHorizontalHeaderLabels(COLONNES)
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(
            QTableWidget.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        header = self.table.horizontalHeader()
        header.setStretchLastSection(True)
        for i, w in enumerate((280, 70, 100, 110, 140, 170)):
            header.resizeSection(i, w)
        header.setSectionResizeMode(COL_ETAT, QHeaderView.ResizeMode.Stretch)
        # tri en cliquant un en-tete (la liste n'etait triable d'aucune facon)
        header.setSectionsClickable(True)
        header.setSortIndicatorShown(True)
        header.setSortIndicator(COL_TAILLE, Qt.SortOrder.DescendingOrder)
        header.sectionClicked.connect(self.trier_par)
        header.setToolTip("Cliquez un en-tete pour trier ; un second clic inverse l'ordre.")
        self.table.cellDoubleClicked.connect(self._double_clic)
        self.table.viewport().setToolTip("Double-clic : ouvrir la fiche du jeu")
        root.addWidget(self.table, 1)

        # -- sauvegardes du jeu choisi ---------------------------------
        self.carte_sauvegardes = QFrame()
        self.carte_sauvegardes.setObjectName("SauvegardesCarte")
        cs = QVBoxLayout(self.carte_sauvegardes)
        cs.setContentsMargins(14, 10, 14, 10)
        cs.setSpacing(8)
        tete = QHBoxLayout()
        self.sauvegardes_titre = QLabel("Sauvegardes")
        self.sauvegardes_titre.setObjectName("SauvegardesTitre")
        tete.addWidget(self.sauvegardes_titre)
        tete.addStretch(1)
        explication = QLabel("copie complete et verifiee sur un autre disque  ·  "
                             "le jeu installe n'est jamais modifie")
        explication.setObjectName("Faint")
        tete.addWidget(explication)
        cs.addLayout(tete)
        self.lignes_sauvegardes = QVBoxLayout()
        self.lignes_sauvegardes.setSpacing(6)
        cs.addLayout(self.lignes_sauvegardes)
        root.addWidget(self.carte_sauvegardes)

        row = QHBoxLayout()
        row.setSpacing(10)
        self.uninstall = QPushButton("Desinstaller le jeu selectionne")
        self.uninstall.clicked.connect(self._uninstall)
        row.addWidget(self.uninstall)

        self.sauvegarder = QPushButton("Sauvegarder sur un autre disque")
        self.sauvegarder.setObjectName("Sauvegarder")
        self.sauvegarder.setToolTip(
            "Copie complete du jeu dans « Sauvegardes ORION » sur le disque choisi, "
            "verifiee fichier par fichier. Le jeu installe reste a sa place et n'est "
            "pas modifie : Steam, Epic et les autres launchers continuent de l'utiliser.")
        self.sauvegarder.clicked.connect(
            lambda: self._selected_uid() and self.sauvegarder_requested.emit(
                self._selected_uid()))
        row.addWidget(self.sauvegarder)

        self.ramener = QPushButton("Ramener sur le disque d'origine")
        self.ramener.setObjectName("Ghost")
        self.ramener.setToolTip("Ce jeu a ete deplace par une ancienne version d'ORION "
                                "(jonction) : le ramener le remet a son emplacement "
                                "d'origine.")
        self.ramener.clicked.connect(
            lambda: self._selected_uid() and self.ramener_requested.emit(self._selected_uid()))
        self.ramener.hide()
        row.addWidget(self.ramener)

        self.open_folder = QPushButton("Ouvrir le dossier")
        self.open_folder.setObjectName("Ghost")
        self.open_folder.clicked.connect(self._open_folder)
        row.addWidget(self.open_folder)
        row.addStretch(1)
        root.addLayout(row)

        hint = QLabel(
            "ORION ne supprime jamais un jeu lui-meme : il ouvre le "
            "desinstalleur de la plateforme concernee, et propose d'archiver "
            "la sauvegarde avant.")
        hint.setObjectName("Faint")
        hint.setWordWrap(True)
        root.addWidget(hint)

        self.table.itemSelectionChanged.connect(self._selection)
        self._selection()

    # ------------------------------------------------------------------
    def set_data(self, entries: list, disks: list[dict],
                 hw: HardwareInfo) -> None:
        """`entries` : tous les jeux (installes, ou sauvegardes) ; `disks` :
        les disques qui portent des jeux ou des sauvegardes."""
        self._all = entries
        choisi = self._selected_uid()

        clear_layout(self.disks_box)
        self._cards = []
        for disk in disks:
            card = DiskCard(disk)
            card.clicked.connect(self._choose)
            self.disks_box.addWidget(card)
            self._cards.append(card)
        self.disks_box.addStretch(1)

        # le disque choisi precedemment peut avoir disparu
        if self.disk != TOUS and self.disk not in {c.key for c in self._cards}:
            self.disk = TOUS
        self._apply(choisi)

    def _choose(self, key: str) -> None:
        self.disk = key
        self._apply(self._selected_uid())

    def filtrer(self, cle: str) -> None:
        """« Tout », « Ce qui dort » ou « Sauvegardes »."""
        self.filtre = cle if cle in self.filtres else "tout"
        self.filtres[self.filtre].setChecked(True)
        self._apply(self._selected_uid())

    def trier_par(self, colonne: int) -> None:
        """Clic sur un en-tete : trie par cette colonne ; un second clic sur
        la meme inverse l'ordre."""
        if colonne not in TRIS:
            return
        actuelle, decroissant = self._tri
        self._tri = (colonne, (not decroissant) if colonne == actuelle
                     else TRIS[colonne][1])
        self.table.horizontalHeader().setSortIndicator(
            colonne, Qt.SortOrder.DescendingOrder if self._tri[1]
            else Qt.SortOrder.AscendingOrder)
        self._apply(self._selected_uid())

    def _du_disque(self) -> list:
        return [e for e in self._all
                if self.disk == TOUS or e.disk.upper() == self.disk
                or self.disk in e.disques_sauvegarde]

    def _apply(self, garder: str = "") -> None:
        du_disque = self._du_disque()
        # les compteurs des filtres portent sur le disque choisi
        nombres = {"tout": len(du_disque),
                   "dormants": sum(1 for e in du_disque if e.dormant),
                   "sauvegardes": sum(1 for e in du_disque if e.sauvegardes)}
        for cle, texte in FILTRES:
            self.filtres[cle].setText(f"{t(texte)}  {nombres[cle]}")
        entries = du_disque
        if self.filtre == "dormants":
            entries = [e for e in entries if e.dormant]
        elif self.filtre == "sauvegardes":
            entries = [e for e in entries if e.sauvegardes]
        cherche = self.recherche.text().strip()
        if cherche:
            from ...core.recherche import correspond
            bas = cherche.lower()
            entries = [e for e in entries
                       if bas in e.game.title.lower() or correspond(cherche, e.game.title)]
        entries = trier(entries, *self._tri)
        self._entries = entries

        for card in self._cards:
            card.set_active(card.key == self.disk)
        self.all_button.setChecked(self.disk == TOUS)

        warn, ok, faint = (QColor(PALETTE["warn"]), QColor(PALETTE["ok"]),
                           QColor(PALETTE["text_faint"]))
        self.table.blockSignals(True)
        self.table.setRowCount(len(entries))
        ligne_gardee = -1
        for r, e in enumerate(entries):
            valeurs = (e.game.title, e.disk, e.size_label, e.played_label,
                       e.last_label, e.sauvegarde_label, e.state_label)
            for col, texte in enumerate(valeurs):
                # (le titre du jeu ne se traduit pas ; le reste, si)
                cellule = QTableWidgetItem(texte if col == COL_JEU else t(texte))
                if not e.installe:
                    cellule.setForeground(faint)
                if col == COL_SAUVEGARDE:
                    cellule.setForeground(ok if e.sauvegardes else faint)
                elif col == COL_ETAT and e.dormant:
                    cellule.setForeground(warn)
                elif col == COL_ETAT and not e.installe:
                    cellule.setForeground(ok)
                self.table.setItem(r, col, cellule)
            if garder and e.game.uid == garder:
                ligne_gardee = r
        if ligne_gardee >= 0:
            self.table.setCurrentCell(ligne_gardee, 0)
        elif self.table.currentRow() >= 0:
            # la ligne choisie n'est plus affichee (filtre, recherche) : plus
            # de selection, plutot qu'un autre jeu selectionne a sa place
            self.table.setCurrentCell(-1, -1)
        self.table.blockSignals(False)

        # jeux reellement installes sur le disque choisi (les autres lignes
        # n'y sont que pour leur sauvegarde)
        installes = [e for e in entries if e.installe
                     and (self.disk == TOUS or e.disk.upper() == self.disk)]
        total = sum(e.size_gb for e in installes)
        dormants = [e for e in installes if e.dormant]
        recuperable = sum(e.size_gb for e in dormants)
        sauves = [s for e in entries for s in e.sauvegardes
                  if self.disk == TOUS or disk_letter(s["chemin"]).upper() == self.disk]
        ou = ("tous disques confondus" if self.disk == TOUS
              else f"sur le disque {self.disk}")
        filtre_actif = self.filtre != "tout" or bool(cherche)
        self.scope.setText(
            f"{len(installes)} jeu(x) {ou}"
            + (f"  ·  {len(sauves)} sauvegarde(s)" if sauves else "")
            + ("  ·  cliquez un disque pour le filtrer"
               if self.disk == TOUS and not filtre_actif else ""))
        if filtre_actif:
            # le resume dit ce que la selection affichee represente
            self.summary.setText(
                f"{total:.0f} Go affiches ({len(installes)} "
                f"jeu{'x' if len(installes) > 1 else ''})"
                + (f"  ·  {recuperable:.0f} Go dorment" if dormants
                   and self.filtre != "dormants" else ""))
        else:
            self.summary.setText(
                f"{total:.0f} Go de jeux"
                + (f"  ·  {recuperable:.0f} Go dorment ({len(dormants)} "
                   f"jeu{'x' if len(dormants) > 1 else ''})"
                   if dormants else "  ·  rien ne dort"))
        # les lignes ont pu changer sous la selection (tri, jeu deplace) :
        # les boutons suivent la ligne reellement choisie
        self._selection()

    def set_occupe(self, occupe: bool) -> None:
        """Pendant une copie, les boutons qui en lanceraient une autre sont
        coupes."""
        self._occupe = occupe
        self._selection()

    # -- recalcul -----------------------------------------------------
    def set_calcul(self, en_cours: bool, texte: str = "") -> None:
        """Etat du bouton « Recalculer » : occupe pendant la mesure, puis
        « calcule a HH:MM »."""
        self._calcul = en_cours
        self.refresh.setEnabled(not en_cours)
        self.refresh.setText("Calcul en cours..." if en_cours else "Recalculer")
        if texte:
            self.calcul_info.setText(texte)
        self.calcul_info.setProperty("etat", "frais" if (texte and not en_cours) else "")
        self.calcul_info.style().unpolish(self.calcul_info)
        self.calcul_info.style().polish(self.calcul_info)

    def progression_calcul(self, message: str, pourcent: int) -> None:
        if self._calcul and pourcent is not None and pourcent >= 0:
            self.refresh.setText(f"Calcul... {int(pourcent)} %")
            self.calcul_info.setText(message)

    # -- copie en cours -----------------------------------------------
    def debut_copie(self, titre: str, sous_titre: str, annulable: bool = True,
                    indetermine: bool = False) -> None:
        self.copie.debut(titre, sous_titre, annulable, indetermine)

    def progression_copie(self, message: str, pourcent: int) -> None:
        self.copie.progression(message, pourcent)

    def fin_copie(self) -> None:
        self.copie.hide()

    # ------------------------------------------------------------------
    def _entree_choisie(self):
        row = self.table.currentRow()
        if 0 <= row < len(self._entries):
            return self._entries[row]
        return None

    def _selection(self) -> None:
        e = self._entree_choisie()
        deplace = bool(e and e.game.extra.get("deplace"))
        installe = bool(e and e.installe)
        self.sauvegarder.setVisible(not deplace)
        self.ramener.setVisible(deplace)
        self.sauvegarder.setEnabled(installe and not self._occupe)
        self.ramener.setEnabled(e is not None and not self._occupe)
        self.uninstall.setEnabled(installe and not self._occupe)
        self.open_folder.setEnabled(installe)
        self._maj_sauvegardes(e)

    def _maj_sauvegardes(self, e) -> None:
        clear_layout(self.lignes_sauvegardes)
        if e is None:
            self.sauvegardes_titre.setText("Sauvegardes")
            self._ligne_vide("Selectionnez un jeu pour voir ses sauvegardes.")
            return
        self.sauvegardes_titre.setText(f"Sauvegardes de {e.game.title}")
        if not e.sauvegardes:
            self._ligne_vide("Aucune sauvegarde de ce jeu pour l'instant.  "
                             "« Sauvegarder sur un autre disque » en cree une.")
            return
        for s in e.sauvegardes:
            self.lignes_sauvegardes.addWidget(self._ligne(e, s))

    def _ligne_vide(self, texte: str) -> None:
        vide = QLabel(texte)
        vide.setObjectName("Faint")
        self.lignes_sauvegardes.addWidget(vide)

    def _presence_connue(self, chemin: str, _presente: bool) -> None:
        """Reponse arrivee pour une sauvegarde : les lignes du jeu choisi
        sont refaites si elle le concerne."""
        e = self._entree_choisie()
        if e is not None and any(str(s["chemin"]) == chemin for s in e.sauvegardes):
            self._maj_sauvegardes(e)

    def _ligne(self, e, s: dict) -> QFrame:
        chemin = str(s["chemin"])
        connue = self.presences.lire(chemin)        # None : question en cours
        presente = bool(connue)
        nom_etat = "inconnue" if connue is None else (
            "presente" if presente else "absente")
        ligne = QFrame()
        ligne.setObjectName("SauvegardeLigne")
        ligne.setProperty("etat", nom_etat)
        lay = QHBoxLayout(ligne)
        lay.setContentsMargins(12, 7, 8, 7)
        lay.setSpacing(10)

        textes = QVBoxLayout()
        textes.setSpacing(1)
        lieu = QLabel(chemin)
        lieu.setObjectName("Value")
        lieu.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        textes.addWidget(lieu)
        details = []
        if s.get("date"):
            details.append(time.strftime("%d/%m/%Y a %H:%M", time.localtime(s["date"])))
        if s.get("octets"):
            details.append(_taille(s["octets"]))
        if s.get("fichiers"):
            details.append(f"{s['fichiers']} fichiers")
        if s.get("version"):
            details.append(f"version {s['version']}")
        meta = QLabel("  ·  ".join(details) or "date inconnue")
        meta.setObjectName("Faint")
        textes.addWidget(meta)
        lay.addLayout(textes, 1)

        etat = QLabel("verification..." if connue is None else "disponible" if presente
                      else "introuvable (disque debranche ?)")
        etat.setObjectName("SauvegardeEtat")
        etat.setProperty("etat", nom_etat)
        etat.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        lay.addWidget(etat, 0, Qt.AlignmentFlag.AlignVCenter)

        uid = e.game.uid
        restaurer = QPushButton("Restaurer la sauvegarde")
        restaurer.setObjectName("Ghost")
        restaurer.setToolTip("Recopie cette sauvegarde a l'emplacement du jeu "
                             f"({e.game.install_dir}).")
        restaurer.setEnabled(presente and not self._occupe)
        restaurer.clicked.connect(lambda: self.restaurer_requested.emit(uid, chemin))
        lay.addWidget(restaurer)
        ouvrir = QPushButton("Ouvrir")
        ouvrir.setObjectName("Ghost")
        ouvrir.setToolTip("Ouvre le dossier de la sauvegarde dans l'Explorateur.")
        ouvrir.setEnabled(presente)
        ouvrir.clicked.connect(lambda: self.ouvrir_sauvegarde_requested.emit(chemin))
        lay.addWidget(ouvrir)
        supprimer = QPushButton("Supprimer la sauvegarde")
        supprimer.setObjectName("Danger")
        supprimer.setEnabled(not self._occupe)
        supprimer.clicked.connect(
            lambda: self.supprimer_sauvegarde_requested.emit(uid, chemin))
        lay.addWidget(supprimer)
        return ligne

    def _selected_uid(self) -> str:
        e = self._entree_choisie()
        return e.game.uid if e is not None else ""

    def _double_clic(self, ligne: int, _colonne: int) -> None:
        if 0 <= ligne < len(self._entries) and self._entries[ligne].installe:
            self.ouvrir_fiche_requested.emit(self._entries[ligne].game.uid)

    def chercher(self) -> None:
        """Ctrl+F : le curseur va dans la recherche."""
        self.recherche.setFocus()
        self.recherche.selectAll()

    def _uninstall(self) -> None:
        uid = self._selected_uid()
        if uid:
            self.uninstall_requested.emit(uid)

    def _open_folder(self) -> None:
        uid = self._selected_uid()
        if uid:
            self.open_folder_requested.emit(uid)
