"""Un reglage change s'applique tout de suite (2.0).

Chaque option de la page Reglages ecrit dans `CONFIG`. Avant, ce qui en
dependait ne la relisait qu'a son prochain passage : la largeur des tuiles
ne bougeait qu'au rafraichissement suivant de la bibliotheque, « Afficher
les jeux masques » de meme, la manette et la frequence de la veille
attendaient le redemarrage d'ORION, et un changement de pays laissait
jusqu'a un quart d'heure des prix en euros affiches avec le signe du dollar.

Ici la fenetre ecoute `CONFIG` (voir `Config.ecouter`) et une seule table,
`EFFETS`, dit quel reglage declenche quoi. Les changements sont regroupes
(un champ numerique en envoie un par cran) puis appliques une fois.
"""
from __future__ import annotations

from PySide6.QtCore import QObject, QTimer, Signal

from ..core.config import CONFIG
from ..core.logging_setup import get

log = get("ui.reglages")

#: delai de regroupement des changements, en millisecondes
REGROUPER = 300
#: un changement de pays relance des releves en ligne : on attend que le
#: joueur ait fini de parcourir la liste
REGROUPER_PAYS = 1500

#: (reglages concernes, methode de la fenetre a appeler une fois)
EFFETS: tuple[tuple[tuple[str, ...], str], ...] = (
    (("ui.card_width", "ui.show_hidden", "ui.hero"), "refresh_library"),
    (("ui.gamepad",), "_appliquer_manette"),
    (("scan.watch_interval_min", "scan.watch_enabled"), "_appliquer_veille"),
    (("free.enabled", "free.refresh_hours"), "_appliquer_frequence_gratuits"),
    (("free.hide_demos",), "refresh_free_view"),
    (("boutique.refresh_minutes",), "_appliquer_frequence_boutique"),
    (("market.country",), "_pays_change"),
    (("ai.provider", "ai.api_key"), "_ia_changee"),
)


def effets_de(chemins) -> list[str]:
    """Methodes a appeler pour ces reglages, sans doublon, dans l'ordre de
    la table."""
    voulus = set(chemins)
    return [methode for cles, methode in EFFETS if voulus & set(cles)]


class _PontReglages(QObject):
    """Ramene « reglage change » (parfois ecrit depuis un fil de fond) dans
    le fil d'affichage."""
    change = Signal(str)

    def prevenir(self, chemin: str) -> None:
        self.change.emit(chemin)


class ReglagesMixin:
    def _init_reglages(self) -> None:
        self._reglages_changes: set[str] = set()
        self._reglages_actifs = False          # vrai une fois ORION demarre
        self._reglages_timer = QTimer(self)
        self._reglages_timer.setSingleShot(True)
        self._reglages_timer.timeout.connect(self._appliquer_reglages)
        self._pont_reglages = _PontReglages(self)
        self._pont_reglages.change.connect(self._reglage_change)
        CONFIG.ecouter(self._pont_reglages.prevenir)

    def _reglage_change(self, chemin: str) -> None:
        if not self._reglages_actifs or not effets_de([chemin]):
            return
        self._reglages_changes.add(chemin)
        attente = REGROUPER_PAYS if chemin == "market.country" else REGROUPER
        if not self._reglages_timer.isActive() or \
                self._reglages_timer.remainingTime() < attente:
            self._reglages_timer.start(attente)

    def _appliquer_reglages(self) -> None:
        chemins, self._reglages_changes = self._reglages_changes, set()
        for methode in effets_de(chemins):
            try:
                getattr(self, methode)()
            except Exception:
                log.exception("Reglage non applique (%s)", methode)

    # -- effets ------------------------------------------------------------
    def _appliquer_manette(self) -> None:
        voulu = bool(CONFIG.get("ui.gamepad", True))
        if voulu and self.gamepad is None:
            self._setup_gamepad()
        elif voulu and self.gamepad is not None:
            self.gamepad.start()
        elif not voulu and self.gamepad is not None:
            self.gamepad.stop()

    def _appliquer_veille(self) -> None:
        """Minuterie de la veille des installations, a la frequence des
        Reglages (0 = jamais)."""
        minutes = int(CONFIG.get("scan.watch_interval_min", 10) or 0)
        minuterie = getattr(self, "_watch_timer", None)
        if minuterie is None:
            minuterie = self._watch_timer = QTimer(self)
            minuterie.timeout.connect(self._watch_tick)
        if minutes > 0 and CONFIG.get("scan.watch_enabled", True):
            if not minuterie.isActive() or minuterie.interval() != minutes * 60_000:
                minuterie.start(minutes * 60_000)
        else:
            minuterie.stop()

    def _appliquer_frequence_gratuits(self) -> None:
        """Minuterie des jeux gratuits : creee meme si la surveillance etait
        coupee au demarrage (la cocher ensuite doit suffire)."""
        minuterie = getattr(self, "_free_timer", None)
        if minuterie is None:
            minuterie = self._free_timer = QTimer(self)
            minuterie.timeout.connect(lambda: self.refresh_free())
        if not CONFIG.get("free.enabled", True):
            minuterie.stop()
            return
        heures = float(CONFIG.get("free.refresh_hours", 6) or 6)
        intervalle = int(max(heures, 0.1) * 3600 * 1000)
        etait_arretee = not minuterie.isActive()
        if etait_arretee or minuterie.interval() != intervalle:
            minuterie.start(intervalle)
        if etait_arretee and self._reglages_actifs:
            self.refresh_free()            # la surveillance vient d'etre cochee

    def _appliquer_frequence_boutique(self) -> None:
        minuterie = getattr(self, "_boutique_timer", None)
        if minuterie is not None:
            intervalle = self.boutique.intervalle_minutes() * 60_000
            if minuterie.interval() != intervalle:
                minuterie.setInterval(intervalle)

    def _pays_change(self) -> None:
        """Nouveau pays : les prix affiches sont ceux de l'ancien. Tout ce
        qui porte un prix est relu maintenant."""
        from ..core import region
        self.notify(f"Pays des prix : {region.pays()}. Boutique, jeux gratuits et "
                    "envies sont relus dans la nouvelle devise.", 10)
        self.refresh_boutique(force=True)
        self.refresh_free(force=True)
        self.refresh_wishlist(force=True)
        minuterie = getattr(self, "_valeur_timer", None)
        if minuterie is not None:
            minuterie.start(8000)
        jeu = getattr(self.detail_view, "game", None)
        if jeu is not None:
            self._load_market(jeu.uid)

    def _ia_changee(self) -> None:
        """Cle d'IA ajoutee ou retiree : « Approfondir avec l'IA » (Ma
        machine) suit sans attendre une nouvelle analyse du materiel."""
        if getattr(self, "_bilan_points", None) is not None:
            self._refresh_bilan()
