"""Compteur anonyme : combien de PC ouvrent ORION, quelles pages servent,
quelles boutiques sont ouvertes depuis ORION.

Seulement si le joueur a dit oui a la question du partage (`partage`), posee
avec le texte qui decrit ce compteur. Sans accord, rien n'est note et rien
n'est envoye.

Ce qui part, regroupe en un envoi toutes les quelques minutes :

* ouverture : la version d'ORION et sa provenance (Microsoft Store ou
  installateur), avec l'identifiant de poste tire au hasard deja utilise
  pour les mesures. Il ne sert qu'a ne compter chaque PC qu'une fois par
  jour ; le service le hache avant de le ranger ;
* page : le nom d'une page d'ORION ouverte (« boutique », « sorties »...) ;
* clic : le nom de la boutique ouverte (« steam », « instant-gaming »...) et
  la page d'ou vient le clic.

Le service note en plus le pays et la region d'ou vient l'envoi (deduits par
l'hebergeur, sans garder l'adresse IP), jamais la ville : la question posee
au joueur l'annonce, et un envoi d'une version plus ancienne n'est pas situe.

A la fermeture d'ORION (2.0.1, question n° 4), le dernier envoi porte aussi
le bilan de fluidite de la session (`core.fluidite.bilan_envoi`) : combien de
fois l'affichage s'est fige, quelle fonction d'ORION etait en cause (son nom,
jamais un chemin ni un jeu), le temps de demarrage et le nombre d'erreurs du
journal. Le service additionne ces bilans par jour et par version.

Ce qui ne part jamais : le jeu concerne, l'adresse du lien, un nom, un
compte, un fichier. Pages et clics sont additionnes par le service sans
aucun identifiant : il ne sait pas quel PC a clique.
"""
from __future__ import annotations

import threading
import urllib.parse

from . import partage
from .core.config import CONFIG
from .core.logging_setup import get
from .version import APP_VERSION

log = get("compteur")

ENVOI = partage.SERVICE + "/compteur"

#: version du texte de la question a partir de laquelle le compteur y figure
QUESTION = partage.QUESTION
#: version de l'envoi. 2 : le joueur a accepte la question qui annonce que le
#: service note le pays et la region d'ou vient l'envoi (jamais la ville).
#: 3 : la question annonce aussi le bilan de fluidite (2.0.1).
VERSION_ENVOI = 3
#: delai avant l'envoi groupe, en secondes
ATTENTE = 300.0
#: evenements differents gardes en attente (au-dela, les nouveaux sont ignores)
MAXIMUM = 60

#: pages comptees : celles de la barre laterale, la fiche d'un jeu, les gratuits
PAGES = frozenset({"library", "boutique", "sorties", "wishlist", "hardware", "storage",
                   "comptes", "advice", "tutorial", "settings", "detail", "free"})

#: d'ou vient un clic
ORIGINES = frozenset({"bibliotheque", "boutique", "fiche", "envies", "gratuits",
                      "sorties", "machine", "video", "fond", ""})

#: boutiques sans programme partenaire, reconnues a leur domaine
BOUTIQUES = {
    "steampowered.com": "steam", "steamcommunity.com": "steam",
    "gog.com": "gog", "epicgames.com": "epic", "xbox.com": "xbox",
    "microsoft.com": "microsoft", "ubisoft.com": "ubisoft", "ea.com": "ea",
    "battle.net": "battlenet", "blizzard.com": "battlenet",
    "rockstargames.com": "rockstar", "itch.io": "itch", "amazon.com": "amazon",
    "isthereanydeal.com": "itad", "itad.link": "itad",
    "github.com": "",          # page d'une version d'ORION : pas une boutique
}

_verrou = threading.Lock()
_attente: dict[tuple[str, str, str], int] = {}
_minuteur: threading.Timer | None = None
_ouverture_envoyee = False


# --------------------------------------------------------------------------
# Accord
# --------------------------------------------------------------------------
def autorise() -> bool:
    """Le joueur a dit oui, et a la question qui decrit ce compteur."""
    try:
        return partage.actif() and int(CONFIG.get("partage.question", 0) or 0) >= QUESTION
    except Exception:
        return False


def canal() -> str:
    try:
        from . import maj
        return "store" if maj.depuis_store() else "installateur"
    except Exception:
        return "installateur"


def boutique_de(url: str) -> str:
    """Nom court de la boutique d'un lien : jamais l'adresse elle-meme."""
    hote = (urllib.parse.urlparse(url or "").hostname or "").lower()
    if not hote:
        return ""
    try:
        from .affiliation import programme_de
        p = programme_de(url)
        if p is not None:
            return p.id
    except Exception:
        pass
    for domaine, nom in BOUTIQUES.items():
        if hote == domaine or hote.endswith("." + domaine):
            return nom
    return "autre"


# --------------------------------------------------------------------------
# Noter
# --------------------------------------------------------------------------
def _noter(nom: str, detail: str = "", origine: str = "") -> None:
    global _minuteur
    if not autorise():
        return
    with _verrou:
        cle = (nom, detail, origine)
        if cle not in _attente and len(_attente) >= MAXIMUM:
            return
        _attente[cle] = min(_attente.get(cle, 0) + 1, 500)
        if _minuteur is None:
            _minuteur = threading.Timer(ATTENTE, envoyer)
            _minuteur.daemon = True
            _minuteur.start()


def ouverture() -> None:
    """ORION vient de demarrer (une fois par lancement)."""
    global _ouverture_envoyee
    if _ouverture_envoyee or not autorise():
        return
    _ouverture_envoyee = True
    _noter("ouverture")
    fil = threading.Thread(target=envoyer, name="compteur", daemon=True)
    fil.start()


def page(cle: str) -> None:
    if cle in PAGES:
        _noter("page", cle)


def clic(url: str, origine: str = "") -> None:
    """Un lien de boutique vient d'etre ouvert depuis ORION."""
    try:
        nom = boutique_de(url)
        if nom:
            _noter("clic", nom, origine if origine in ORIGINES else "")
    except Exception:
        pass


# --------------------------------------------------------------------------
# Envoyer
# --------------------------------------------------------------------------
def _vider() -> list[dict]:
    global _minuteur
    with _verrou:
        lot = [{"nom": n, "detail": d, "origine": o, "n": v}
               for (n, d, o), v in _attente.items()]
        _attente.clear()
        if _minuteur is not None:
            _minuteur.cancel()
            _minuteur = None
    return lot


def corps(lot: list[dict], sante: dict | None = None) -> dict:
    c = {"v": VERSION_ENVOI, "app": APP_VERSION, "canal": canal(), "poste": partage.poste(),
         "evenements": lot}
    if sante is not None:
        c["sante"] = sante
    return c


def bilan_session() -> dict | None:
    """Le bilan de fluidite de la session, s'il existe (vigie en marche)."""
    try:
        from .core import fluidite
        return fluidite.bilan_envoi()
    except Exception:
        return None


def envoyer(delai: float = 10.0, sante: dict | None = None) -> bool:
    """Envoie ce qui attend. Ne leve jamais : le compteur ne doit rien casser.
    Ce qui n'a pas pu partir (hors ligne) est abandonne, jamais garde."""
    lot = _vider()
    if (not lot and sante is None) or not autorise():
        return False
    try:
        from .core import reseau
        r = reseau.post(ENVOI, json=corps(lot, sante), timeout=delai)
        ok = 200 <= r.status_code < 300
        log.debug("Compteur : %d ligne(s) %s", len(lot),
                  "recues" if ok else f"refusees ({r.status_code})")
        return ok
    except Exception as exc:
        log.debug("Compteur non envoye : %s", exc)
        return False


_fil_fin: threading.Thread | None = None


def fermer() -> None:
    """Fermeture d'ORION : dernier envoi, avec le bilan de fluidite de la
    session, en fond. La fenetre ne l'attend pas (7 octobre : 1 018 ms de
    fermeture mesurees) ; c'est le programme, une fois la fenetre disparue,
    qui lui laisse jusqu'a deux secondes (`attendre`)."""
    global _fil_fin
    if not autorise():
        _vider()
        return
    _fil_fin = threading.Thread(target=envoyer, args=(4.0, bilan_session()), name="compteur-fin", daemon=True)
    _fil_fin.start()


def attendre(delai: float = 2.0) -> bool:
    """Apres la fermeture de la fenetre : laisse le dernier envoi finir
    (au plus `delai` secondes). Vrai s'il a fini."""
    fil = _fil_fin
    if fil is None:
        return True
    fil.join(delai)
    return not fil.is_alive()
