"""Jeux Ankama (Wakfu, Dofus, Dofus Retro, Waven...) installes par l'Ankama Launcher.

Pourquoi un scanner dedie : l'Ankama Launcher (« zaap ») installe les jeux
dans `%LOCALAPPDATA%\\Ankama\\<Jeu>`, que le scan de dossiers ignore
volontairement (AppData regorge d'outils). Il ne les declare pas toujours
dans « Programmes et fonctionnalites », et Wakfu tourne sur Java : aucun
moteur reconnaissable. Sans ce scanner, le jeu est installe mais invisible.

Les jeux Ankama exigent que le lanceur soit ouvert (connexion au compte) :
ORION lance donc l'Ankama Launcher plutot que l'executable du jeu.
"""
from __future__ import annotations

import os
import re
from pathlib import Path

from ...core.logging_setup import get
from ...core.models import Game
from ...core.paths import is_windows
from ...core.winutil import dir_size
from .base import Scanner, pick_main_exe

log = get("scan.ankama")

#: nom de dossier (normalise) -> titre affiche
JEUX = {
    "wakfu": "Wakfu",
    "dofus": "Dofus",
    "dofus3": "Dofus",
    "dofusunity": "Dofus",
    "retro": "Dofus Retro",
    "dofusretro": "Dofus Retro",
    "waven": "Waven",
    "krosmaga": "Krosmaga",
    "dofusbeta": "Dofus (beta)",
    "wakfubeta": "Wakfu (beta)",
}

_CHEMIN = re.compile(r"[A-Za-z]:\\\\?(?:[^\"<>|:*?\r\n]+)")


def _env(nom: str) -> Path | None:
    v = os.environ.get(nom)
    return Path(v) if v else None


def _cle(nom: str) -> str:
    return re.sub(r"[^a-z0-9]", "", nom.lower())


def racines() -> list[Path]:
    """Dossiers ou l'Ankama Launcher range ses jeux par defaut."""
    out: list[Path] = []
    for base, sous in (("LOCALAPPDATA", "Ankama"), ("PROGRAMFILES(X86)", "Ankama"),
                       ("PROGRAMFILES", "Ankama"), ("APPDATA", "Ankama")):
        b = _env(base)
        if b and (b / sous).is_dir():
            out.append(b / sous)
    return out


def lanceur() -> str:
    for base, rel in (("LOCALAPPDATA", r"Programs\zaap\Ankama Launcher.exe"),
                      ("PROGRAMFILES", r"Ankama\Ankama Launcher\Ankama Launcher.exe"),
                      ("PROGRAMFILES(X86)", r"Ankama\Ankama Launcher\Ankama Launcher.exe")):
        b = _env(base)
        if b and (b / rel).is_file():
            return str(b / rel)
    return ""


def emplacements_perso() -> list[Path]:
    """Dossiers choisis par le joueur, lus dans la configuration du lanceur."""
    base = _env("APPDATA")
    zaap = base / "zaap" if base else None
    if not zaap or not zaap.is_dir():
        return []
    vus: list[Path] = []
    for fichier in list(zaap.rglob("*.json"))[:400]:
        try:
            if fichier.stat().st_size > 2_000_000:
                continue
            texte = fichier.read_text("utf-8", errors="ignore")
        except OSError:
            continue
        for brut in _CHEMIN.findall(texte):
            brut = brut.replace("\\\\", "\\").rstrip("\\ ")
            p = Path(brut)
            if _cle(p.name) in JEUX and p not in vus:
                try:
                    if p.is_dir():
                        vus.append(p)
                except OSError:
                    continue
    return vus


class AnkamaScanner(Scanner):
    id = "ankama"
    label = "Ankama Launcher"
    icon = "ANK"
    priority = 58

    def available(self) -> bool:
        return is_windows() and bool(racines() or lanceur())

    def scan(self) -> list[Game]:
        dossiers: list[Path] = []
        for racine in racines():
            try:
                dossiers += [p for p in racine.iterdir() if p.is_dir()]
            except OSError:
                continue
        dossiers += emplacements_perso()

        exe_lanceur = lanceur()
        games: list[Game] = []
        vus: set[str] = set()
        for d in dossiers:
            titre = JEUX.get(_cle(d.name))
            if not titre or str(d).lower() in vus:
                continue
            exe = pick_main_exe(d, d.name, min_mb=0.2)
            if not exe and not exe_lanceur:
                continue
            vus.add(str(d).lower())
            games.append(self._mk(
                title=titre,
                source_id=_cle(d.name),
                install_dir=str(d),
                executable=exe_lanceur or exe,
                working_dir=str(Path(exe_lanceur or exe).parent),
                size_bytes=dir_size(d, 6000),
                engine="",
                store_url="https://www.ankama.com/fr/games",
                extra={"publisher": "Ankama", "game_exe": exe,
                       "via_launcher": bool(exe_lanceur)},
            ))
        log.info("%d jeux Ankama", len(games))
        return games
