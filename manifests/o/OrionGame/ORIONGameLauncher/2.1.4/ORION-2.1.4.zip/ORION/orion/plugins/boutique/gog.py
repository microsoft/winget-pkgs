"""GOG : catalogue public en euros, jeux sans DRM. Aucune cle."""
from __future__ import annotations

from orion.core import region

import re

from ...core.config import CONFIG
from .base import Offre, SourceBoutique, SourceUnavailable, fetch_json, lire_prix, log

CATALOG = "https://catalog.gog.com/v1/catalog"
_REMISE = re.compile(r"(\d+)")


from ...contenu_adulte import produit_adulte

def _offres(produits) -> list[Offre]:
    out: list[Offre] = []
    for p in produits or []:
        prix = p.get("price") or {}
        if not isinstance(prix, dict):
            continue

        final = (prix.get("finalMoney") or {}).get("amount")
        base = (prix.get("baseMoney") or {}).get("amount")
        final = lire_prix(final if final is not None else prix.get("final"))
        base = lire_prix(base if base is not None else prix.get("base")) or final
        m = _REMISE.search(str(prix.get("discount") or ""))
        remise = int(m.group(1)) if m else (
            round(100 - final * 100 / base) if base and final < base else 0)
        sortie = str(p.get("releaseDate") or p.get("storeReleaseDate") or "")
        note = int(p.get("reviewsRating") or 0)
        out.append(Offre(
            titre=p.get("title", ""), boutique="GOG", prix=final,
            prix_normal=base, remise=remise, url=p.get("storeLink") or
            f"https://www.gog.com/fr/game/{p.get('slug', '')}",
            source="gog", image=p.get("coverHorizontal") or "",
            genres=[g.get("name", "") for g in p.get("genres") or []][:3],
            sortie=sortie.replace(".", "-")[:10],
            type_article=str(p.get("productType") or ""),
            note=note * 2 if 0 < note <= 50 else note, drm="Sans DRM",
            adulte=produit_adulte(p)))
    return out


class GOGBoutique(SourceBoutique):
    id = "gog"
    label = "GOG"
    priority = 80
    filtre_adulte = "etiquettes du catalogue GOG (« nsfw ») lues par produit_adulte"

    @staticmethod
    def _params(**kw) -> dict:
        return {"limit": 48, "productType": "in:game,pack",
                "countryCode": str(CONFIG.get("market.country") or "FR"),
                "locale": region.locale_gog(), "currencyCode": region.devise(), **kw}

    def vitrine(self) -> list[Offre]:
        out: list[Offre] = []
        erreurs = 0
        for kw in ({"order": "desc:discount", "discounted": "eq:true"},
                   {"order": "desc:trending", "discounted": "eq:true"},
                   {"order": "desc:bestselling"}):
            try:
                out += _offres(fetch_json(CATALOG, self._params(**kw)).get("products"))
            except SourceUnavailable as exc:
                erreurs += 1
                log.debug("GOG : %s", exc)
        if erreurs == 3:
            raise SourceUnavailable("Catalogue GOG injoignable")
        return out

    def chercher(self, terme: str) -> list[Offre]:
        data = fetch_json(CATALOG, self._params(query=f"like:{terme}",
                                                order="desc:score", limit=20))
        return _offres(data.get("products"))
