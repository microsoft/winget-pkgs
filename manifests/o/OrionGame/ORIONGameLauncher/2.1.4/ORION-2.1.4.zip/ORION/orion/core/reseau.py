"""Toutes les connexions d'ORION passent par ici.

Chaque service en ligne a ses limites : Steam refuse les fiches au-dela
d'environ 200 demandes en 5 minutes, Google Traduction bloque une adresse
qui insiste, MyMemory a un quota quotidien, GitHub compte les appels.
Jusqu'a la 1.6, chaque module gerait (ou ignorait) ces limites a sa facon.

Ce module centralise :

* **l'espacement** des appels par site (`POLITIQUES`) ;
* **la pause automatique** apres un refus (HTTP 429, et 403 pour Steam),
  en respectant l'en-tete `Retry-After` quand le site en donne un. Pendant
  la pause, un appel vers ce site leve `HoteEnPause` immediatement au lieu
  de prolonger le blocage ;
* **les nouvelles tentatives** en cas de coupure breve (erreur de connexion,
  502/503/504), avec un delai croissant ;
* **l'etat hors ligne** : apres plusieurs echecs de connexion vers des sites
  differents, sans aucun succes, ORION se sait hors ligne et le signale
  (evenement `reseau.etat`) ;
* **une memoire des reponses** (`get_json(..., garder=...)`) avec validation
  par ETag : un index qui n'a pas change ne se retelecharge pas.

`get()` et `post()` s'utilisent exactement comme `requests.get/post` et
rendent un `requests.Response` : les modules existants n'ont eu qu'a
changer le nom de la fonction appelee.
"""
from __future__ import annotations

import email.utils
import threading
import time
from dataclasses import dataclass
from urllib.parse import urlparse

from .logging_setup import get as _journal

log = _journal("reseau")


@dataclass(frozen=True)
class Politique:
    ecart: float = 0.0          # secondes minimum entre deux appels
    pause_refus: int = 120      # secondes de pause apres un 429
    refus_403: bool = False     # 403 compte aussi comme un refus


#: suffixe de nom d'hote -> politique (le suffixe le plus long l'emporte)
POLITIQUES: dict[str, Politique] = {
    "steampowered.com": Politique(ecart=1.2, pause_refus=300, refus_403=True),
    "steamcommunity.com": Politique(ecart=1.2, pause_refus=300, refus_403=True),
    # API Web de Steam (joueurs en ligne...) : quotas distincts de la boutique
    "api.steampowered.com": Politique(ecart=0.2, pause_refus=120),
    "translate.googleapis.com": Politique(ecart=0.3, pause_refus=1800),
    "mymemory.translated.net": Politique(ecart=0.5, pause_refus=3600),
    "api.github.com": Politique(ecart=0.2, pause_refus=900, refus_403=True),
    "steamgriddb.com": Politique(ecart=0.25, pause_refus=300),
    "isthereanydeal.com": Politique(ecart=0.3, pause_refus=300),
    "gamerpower.com": Politique(ecart=0.3, pause_refus=600),
}
DEFAUT = Politique()

AGENT = "ORION-Launcher (+https://orion-launcher.com)"


class HoteEnPause(Exception):
    """Le site a refuse des demandes recemment : on attend avant de reessayer."""


try:                                        # sous-classe de l'erreur requests,
    import requests as _rq                   # pour les `except` existants
    HoteEnPause = type("HoteEnPause", (_rq.RequestException,),   # noqa: F811
                       {"__doc__": HoteEnPause.__doc__})
except Exception:                           # pragma: no cover
    _rq = None


_verrou = threading.Lock()
_dernier_appel: dict[str, float] = {}
_pause: dict[str, float] = {}
_local = threading.local()

# etat hors ligne
_echecs: dict[str, float] = {}            # hote -> date du dernier echec
_dernier_succes = 0.0
_hors_ligne = False


# --------------------------------------------------------------------------
def hote(url: str) -> str:
    return (urlparse(url).hostname or "").lower()


def _cle(nom: str) -> tuple[str, Politique]:
    """Groupe de limitation d'un hote : le suffixe connu le plus long."""
    meilleur = ""
    for suffixe in POLITIQUES:
        if (nom == suffixe or nom.endswith("." + suffixe)) and len(suffixe) > len(meilleur):
            meilleur = suffixe
    return (meilleur or nom), POLITIQUES.get(meilleur, DEFAUT)


def en_pause(url_ou_hote: str) -> bool:
    nom = hote(url_ou_hote) if "://" in url_ou_hote else url_ou_hote.lower()
    cle, _ = _cle(nom)
    return time.time() < _pause.get(cle, 0.0)


def reste_pause(url_ou_hote: str) -> int:
    nom = hote(url_ou_hote) if "://" in url_ou_hote else url_ou_hote.lower()
    cle, _ = _cle(nom)
    return max(0, int(_pause.get(cle, 0.0) - time.time()))


def mettre_en_pause(url_ou_hote: str, secondes: float) -> None:
    nom = hote(url_ou_hote) if "://" in url_ou_hote else url_ou_hote.lower()
    cle, _ = _cle(nom)
    fin = time.time() + max(1.0, float(secondes))
    with _verrou:
        deja = time.time() < _pause.get(cle, 0.0)
        _pause[cle] = max(fin, _pause.get(cle, 0.0))
    if not deja:
        log.warning("%s refuse les demandes : pause de %d min", cle,
                    max(1, int(secondes) // 60))


def lever_pauses() -> None:
    """Remet tous les compteurs a zero (tests, ou « Reessayer » explicite)."""
    with _verrou:
        _pause.clear()
        _dernier_appel.clear()


def _espacer(cle: str, politique: Politique) -> None:
    if politique.ecart <= 0:
        return
    with _verrou:
        maintenant = time.time()
        prochain = max(maintenant, _dernier_appel.get(cle, 0.0) + politique.ecart)
        _dernier_appel[cle] = prochain
    attente = prochain - time.time()
    if attente > 0:
        time.sleep(attente)


def _duree_retry_after(reponse, defaut: int) -> int:
    valeur = (reponse.headers or {}).get("Retry-After", "")
    if valeur:
        try:
            return max(5, min(int(float(valeur)), 6 * 3600))
        except ValueError:
            try:
                date = email.utils.parsedate_to_datetime(valeur)
                return max(5, min(int(date.timestamp() - time.time()), 6 * 3600))
            except Exception:
                pass
    reset = (reponse.headers or {}).get("X-RateLimit-Reset", "")
    if reset.isdigit() and (reponse.headers or {}).get("X-RateLimit-Remaining") == "0":
        return max(5, min(int(reset) - int(time.time()), 6 * 3600))
    return defaut


# --------------------------------------------------------------------------
def _session():
    """Une session par fil d'execution : connexions reutilisees, et
    nouvelles tentatives automatiques sur les coupures breves."""
    s = getattr(_local, "session", None)
    if s is not None:
        return s
    import requests
    from requests.adapters import HTTPAdapter
    s = requests.Session()
    try:
        from urllib3.util.retry import Retry
        essais = Retry(total=2, connect=2, read=1, status=2,
                       backoff_factor=0.6,
                       status_forcelist=(502, 503, 504),
                       allowed_methods=frozenset({"GET", "HEAD"}),
                       respect_retry_after_header=False,
                       raise_on_status=False)
        adaptateur = HTTPAdapter(max_retries=essais, pool_maxsize=8)
    except Exception:                       # pragma: no cover
        adaptateur = HTTPAdapter(max_retries=1, pool_maxsize=8)
    s.mount("https://", adaptateur)
    s.mount("http://", adaptateur)
    _local.session = s
    return s


def requete(methode: str, url: str, **kwargs):
    """Appel HTTP poli. Memes arguments et meme retour que `requests.request`."""
    nom = hote(url)
    cle, politique = _cle(nom)
    if time.time() < _pause.get(cle, 0.0):
        raise HoteEnPause(f"{cle} en pause encore {reste_pause(nom)} s apres un refus")
    _espacer(cle, politique)

    entetes = dict(kwargs.pop("headers", None) or {})
    if not any(k.lower() == "user-agent" for k in entetes):
        entetes["User-Agent"] = AGENT
    kwargs.setdefault("timeout", 15)
    try:
        reponse = _session().request(methode, url, headers=entetes, **kwargs)
    except Exception as exc:
        if _rq is not None and isinstance(exc, (_rq.ConnectionError, _rq.Timeout)):
            _noter_echec(nom)
        raise
    _noter_succes()

    code = reponse.status_code
    if code == 429 or (code == 403 and politique.refus_403):
        mettre_en_pause(nom, _duree_retry_after(reponse, politique.pause_refus))
    return reponse


def get(url: str, **kwargs):
    return requete("GET", url, **kwargs)


def post(url: str, **kwargs):
    return requete("POST", url, **kwargs)


def head(url: str, **kwargs):
    return requete("HEAD", url, **kwargs)


# --------------------------------------------------------------------------
def _noter_echec(nom: str) -> None:
    global _hors_ligne
    maintenant = time.time()
    with _verrou:
        _echecs[nom] = maintenant
        recents = [h for h, t in _echecs.items() if maintenant - t < 90]
        devient = (len(recents) >= 2 and maintenant - _dernier_succes > 60)
        change = devient and not _hors_ligne
        if devient:
            _hors_ligne = True
    if change:
        log.warning("Connexion Internet perdue")
        _publier(False)


def _noter_succes() -> None:
    global _hors_ligne, _dernier_succes
    _dernier_succes = time.time()
    if _hors_ligne:
        with _verrou:
            _hors_ligne = False
            _echecs.clear()
        log.info("Connexion Internet retrouvee")
        _publier(True)


def _publier(en_ligne: bool) -> None:
    try:
        from .events import BUS
        BUS.emit("reseau.etat", en_ligne=en_ligne)
    except Exception:
        pass


def hors_ligne() -> bool:
    return _hors_ligne


def etat() -> dict:
    """Resume pour l'interface et le rapport de probleme."""
    maintenant = time.time()
    return {
        "hors_ligne": _hors_ligne,
        "pauses": {h: int(t - maintenant) for h, t in _pause.items() if t > maintenant},
    }


# --------------------------------------------------------------------------
def get_json(url: str, garder: int = 0, **kwargs):
    """JSON d'une adresse, avec memoire optionnelle.

    `garder` (secondes) : une reponse plus recente est rendue sans appel.
    Au-dela, l'appel se fait avec l'ETag de la reponse gardee : si le site
    repond « 304 non modifie », la version gardee sert encore. En cas
    d'echec reseau, la version gardee (meme ancienne) est rendue plutot
    que rien.
    """
    if garder <= 0:
        r = get(url, **kwargs)
        r.raise_for_status()
        return r.json()

    from .base import Table
    table = Table("http")
    cle = url + ("?" + repr(sorted((kwargs.get("params") or {}).items()))
                 if kwargs.get("params") else "")
    memo = table.get(cle) or {}
    if memo and time.time() - float(memo.get("le", 0)) < garder:
        return memo.get("json")

    entetes = dict(kwargs.pop("headers", None) or {})
    if memo.get("etag"):
        entetes["If-None-Match"] = memo["etag"]
    try:
        r = get(url, headers=entetes, **kwargs)
        if r.status_code == 304 and memo:
            memo["le"] = time.time()
            table.set(cle, memo)
            return memo.get("json")
        r.raise_for_status()
        donnees = r.json()
    except Exception:
        if memo:
            log.info("%s injoignable, version gardee utilisee", hote(url))
            return memo.get("json")
        raise
    table.set(cle, {"le": time.time(), "etag": r.headers.get("ETag", ""),
                    "json": donnees})
    return donnees


def telecharger(url: str, destination, progression=None, timeout: int = 60,
                **kwargs) -> int:
    """Telecharge un fichier par morceaux. Rend le nombre d'octets ecrits.

    Le fichier est ecrit a cote puis renomme : un telechargement coupe ne
    laisse jamais un fichier incomplet sous le nom attendu.
    """
    from contextlib import closing
    from pathlib import Path
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    partiel = destination.with_name(destination.name + ".partiel")
    ecrit = 0
    try:
        # la reponse est fermee dans tous les cas : sinon la connexion reste
        # prise dans le groupe de la session jusqu'au ramasse-miettes
        with closing(requete("GET", url, stream=True, timeout=timeout, **kwargs)) as r:
            r.raise_for_status()
            total = int(r.headers.get("Content-Length") or 0)
            with open(partiel, "wb") as f:
                for morceau in r.iter_content(chunk_size=256 * 1024):
                    if not morceau:
                        continue
                    f.write(morceau)
                    ecrit += len(morceau)
                    if progression and total:
                        progression(ecrit, total)
        if total and ecrit != total:
            raise IOError(f"telechargement incomplet ({ecrit}/{total} octets)")
        partiel.replace(destination)
    except BaseException:
        # coupure, erreur HTTP, disque plein, annulation... : pas de reste
        try:
            partiel.unlink(missing_ok=True)
        except OSError:
            pass
        raise
    return ecrit
