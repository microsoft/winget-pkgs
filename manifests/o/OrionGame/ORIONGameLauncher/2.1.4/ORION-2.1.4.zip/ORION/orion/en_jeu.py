"""Detection des parties en cours, meme lancees hors d'ORION.

Toutes les 15 secondes, ORION regarde quels programmes tournent depuis le
dossier d'un jeu de la bibliotheque. Cela sert a deux choses :

* **le mode discret** : pendant une partie, ORION suspend ce qui travaille
  en arriere-plan (actualisation de la Boutique, veille des installations,
  jeux gratuits, envies, jaquettes, traductions, recettes) et baisse sa
  propre priorite. Tout reprend, echelonne, a la fin de la partie ;
* **le temps de jeu hors d'ORION** : un jeu lance depuis Steam ou Epic est
  quand meme compte.

La lecture de la liste des processus ne demande aucun droit particulier et
ne touche pas au jeu (aucune injection, rien que l'anti-triche puisse
reprocher).
"""
from __future__ import annotations

import os
import re
import time
from dataclasses import dataclass

from .core.logging_setup import get

log = get("en_jeu")

INTERVALLE = 15          # secondes entre deux regards
DUREE_MINI = 60          # une session plus courte n'est pas comptee

#: programmes qui vivent dans le dossier d'un jeu sans etre le jeu
_PAS_UN_JEU = re.compile(
    r"(crash|report|launcher|updater|update|setup|install|unins|redist|"
    r"vc_?redist|directx|dxsetup|easyanticheat|eac_|battleye|be_service|"
    r"anticheat|helper|service|webhelper|cefprocess|overlay|uploader|"
    r"prereq|dotnet|ue4prereq|unitycrashhandler|epicwebhelper|"
    # navigateur integre d'un lanceur (Larian, 9 octobre : ORION a mesure
    # « CefSharp.BrowserSubprocess.exe » au lieu de Baldur's Gate 3)
    r"cefsharp|browsersubprocess|webengineprocess|webview|cef_?subprocess|"
    # petits outils du lanceur de Larian (10 octobre : ORION a suivi
    # « DriverVersionChecker.exe » et cru la partie finie au bout de 6 s)
    r"driverversion|versionchecker|systemcheck)", re.I)

#: lanceurs de plateformes : jamais consideres comme une partie
_LANCEURS = {
    "steam.exe", "steamwebhelper.exe", "epicgameslauncher.exe",
    "galaxyclient.exe", "goggalaxy.exe", "upc.exe", "ubisoftconnect.exe",
    "eadesktop.exe", "origin.exe", "battle.net.exe", "agent.exe",
    "xboxpcapp.exe", "gamingservices.exe", "zaap.exe", "ankama launcher.exe",
    "orion.exe",
    # navigateurs et logiciels toujours ouverts : jamais une partie, meme si
    # leur dossier a ete pris pour celui d'un jeu (signalement n° 4, Opera)
    "opera.exe", "opera_gx.exe", "launcher.exe", "chrome.exe", "msedge.exe", "firefox.exe",
    "brave.exe", "vivaldi.exe", "chromium.exe", "discord.exe", "spotify.exe", "telegram.exe",
    "whatsapp.exe", "slack.exe", "zoom.exe", "teams.exe", "ms-teams.exe", "obs64.exe",
    "vlc.exe", "explorer.exe", "code.exe", "notepad++.exe", "overwolf.exe",
}


@dataclass
class Processus:
    pid: int
    nom: str
    exe: str
    debut: float = 0.0


def _normal(chemin: str) -> str:
    return os.path.normcase(os.path.normpath(chemin or "")).rstrip("\\/")


def auxiliaire(nom: str) -> bool:
    """Lanceur, rapporteur de plantage, anti-triche, installation... : un
    programme qui vit dans le dossier d'un jeu sans etre le jeu."""
    return bool(_PAS_UN_JEU.search(os.path.splitext(nom or "")[0]))


def est_un_jeu(p: Processus) -> bool:
    nom = (p.nom or os.path.basename(p.exe)).lower()
    if nom in _LANCEURS:
        return False
    return not _PAS_UN_JEU.search(os.path.splitext(nom)[0])


def jeux_en_cours(jeux: list, processus: list[Processus]) -> dict[str, Processus]:
    """{uid du jeu: processus} pour chaque jeu dont un programme tourne.

    Fonction pure (testee) : un programme compte pour un jeu s'il se trouve
    dans le dossier d'installation de ce jeu. Quand deux dossiers
    s'emboitent (un jeu range dans le dossier d'un autre), le plus profond
    l'emporte.
    """
    dossiers = []
    for g in jeux:
        d = _normal(getattr(g, "install_dir", "") or "")
        # un dossier trop court (racine d'un disque) ne dit rien
        if len(d) > 6 and not getattr(g, "extra", {}).get("non_installe"):
            dossiers.append((d, g.uid))
    dossiers.sort(key=lambda x: len(x[0]), reverse=True)

    trouves: dict[str, Processus] = {}
    for p in processus:
        if not p.exe or not est_un_jeu(p):
            continue
        exe = _normal(p.exe)
        for dossier, uid in dossiers:
            if exe.startswith(dossier + os.sep) or exe.startswith(dossier + "\\"):
                deja = trouves.get(uid)
                if deja is None or (p.debut and p.debut < (deja.debut or 1e18)):
                    trouves[uid] = p
                break
    return trouves


def lister_processus() -> list[Processus]:
    try:
        import psutil
    except Exception:
        return []
    sortie = []
    for proc in psutil.process_iter(["pid", "name", "exe", "create_time"]):
        info = proc.info
        exe = info.get("exe") or ""
        if exe:
            sortie.append(Processus(info.get("pid") or 0, info.get("name") or "",
                                    exe, float(info.get("create_time") or 0)))
    return sortie


class Veille:
    """Etat « en jeu », mis a jour par `regarder()` (appele en tache de fond).

    `regarder()` rend la liste des changements : [("debut", uid),
    ("fin", uid, secondes, lance_par_orion), ...]. Un jeu lance par ORION
    (a inscrire dans `par_orion` au lancement) a deja son temps compte par
    sa session : l'appelant ne le recompte pas.
    """

    def __init__(self) -> None:
        self.en_cours: dict[str, float] = {}     # uid -> debut de la partie
        self.par_orion: set[str] = set()

    @property
    def actif(self) -> bool:
        return bool(self.en_cours)

    def regarder(self, jeux: list, processus: list[Processus] | None = None) -> list[tuple]:
        vus = jeux_en_cours(jeux, lister_processus() if processus is None else processus)
        changements: list[tuple] = []
        maintenant = time.time()
        for uid, p in vus.items():
            if uid not in self.en_cours:
                self.en_cours[uid] = p.debut or maintenant
                changements.append(("debut", uid))
        for uid in list(self.en_cours):
            if uid not in vus:
                debut = self.en_cours.pop(uid)
                changements.append(("fin", uid, int(maintenant - debut),
                                    uid in self.par_orion))
                self.par_orion.discard(uid)
        return changements


def baisser_priorite(oui: bool) -> None:
    """ORION passe en priorite basse pendant une partie (et revient ensuite)."""
    try:
        import psutil
        moi = psutil.Process()
        if hasattr(psutil, "BELOW_NORMAL_PRIORITY_CLASS"):
            moi.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS if oui
                     else psutil.NORMAL_PRIORITY_CLASS)
        else:                                          # hors Windows (tests)
            pass
    except Exception:
        log.debug("Priorite inchangee")
