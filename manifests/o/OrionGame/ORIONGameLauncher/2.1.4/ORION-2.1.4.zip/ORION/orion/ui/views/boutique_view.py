"""Onglet « Offres » de la Boutique : une barre fixe, des pages.

**La barre** (recherche, filtres, tri) reste a l'ecran et agit sur la page
en cours. **L'accueil** est une vitrine :

1. **A la une** : les gros jeux du moment (notoriete, prix de base, note,
   qualite de la promotion), en grand carrousel ;
2. **Pour vous** : des jeux proches de ceux de la bibliotheque, chacun avec
   sa raison (« Parce que vous jouez a Hades »), jamais un jeu possede ;
3. **Promos Gamesplanet**, **Grosses promos**, **Au plus bas historique**,
   **Gratuits en ce moment** (ce dernier mene a l'onglet des gratuits) ;
4. une rangee par **type de jeu** (ceux du joueur d'abord), les petits prix,
   les mieux notes ; puis les offres du moment, en grille paginee.

Un type de jeu, un filtre, « Tout voir » ou une recherche ouvre une **page**
qui remplace la vitrine (rien a faire defiler) : la page d'un type montre ses
promotions et ses gratuits, puis tous ses jeux. La recherche dans toutes les
boutiques part d'elle-meme quand la saisie se pose.

Les cartes sont dessinees (voir `widgets/boutique_cartes.py`) et leurs
images chargees en arriere-plan : la page reste fluide avec des centaines
de jeux. Un clic ouvre la fiche du jeu : meilleure offre *sure* et
comparatif de toutes les boutiques, y compris celles qu'ORION ecarte,
grisees, avec la raison. Les liens passent par `affiliation.ouvrir`.
"""
from __future__ import annotations

from orion.core import region

from orion.affiliation import ouvreur  # liens de boutique (partenaires)
from orion.affiliation import est_partenaire
from orion import codes_promo
from orion.marche_gris import consigne, lien_gamesplanet, liens_revendeurs

import random
import time

from PySide6.QtCore import (QEasingCurve, QEvent, QPropertyAnimation, QRectF, QSize, Qt,
                            QTimer, Signal)
from PySide6.QtGui import QColor, QFont, QLinearGradient, QPainter, QPainterPath
from PySide6.QtWidgets import (QButtonGroup, QCheckBox, QComboBox, QDialog, QFrame,
                               QHBoxLayout, QLabel, QLineEdit, QMenu, QMessageBox,
                               QProgressBar, QPushButton, QVBoxLayout, QWidget)

from ...boutique import MEMO, Fiche, fige
from ...core.config import CONFIG
from ...core.recherche import classer_variantes, correspond, normaliser, variantes
from ...plugins.boutique.confiance import OFFICIEL
from ... import genres
from ... import suggestions as sugg
from ..theme import PALETTE, accent
from ..widgets.boutique_cartes import (SUIVI, GrilleCartes, RangeeCartes, couleur, degrade,
                                       euros, police)
from ..widgets.boutique_cartes import reste as _reste
from ..widgets.boutique_images import ChargeurImages
from ..widgets.recherche_popup import PanneauRecherche
from ..widgets.cartes_animees import RangeePromos
from ..widgets.boutique_une import CarrouselUne
from ..widgets.layouts import clear_layout
from ..defilement import ZoneDefilante
from ..minuteur import plus_tard

ouvrir_lien = ouvreur("boutique")   # d'ou vient le clic (compteur anonyme)

IMAGE = QSize(200, 94)
PAR_PAGE = 40            # cartes par page de la grille
#: rangees « un type de jeu » sur l'accueil (les types que le joueur possede
#: le plus viennent d'abord)
NB_TYPES_ACCUEIL = 6
#: trop larges pour une rangee de l'accueil (ils gardent leur page)
TYPES_LARGES = frozenset({"action", "aventure", "inde", "coop"})
#: la recherche dans toutes les boutiques part d'elle-meme quand la saisie
#: se pose (millisecondes) : au moment d'appuyer sur Entree, elle est faite
DEVANCE = 700
INVITE = "Chercher n'importe quel jeu (fautes et sigles acceptes : gta, bg3, cyberpounk)..."

#: les filtres agissent sur la page en cours (accueil, type de jeu, liste,
#: recherche). Sur l'accueil, les gratuits ont leur propre onglet.
FILTRES = (
    ("affaires", "Meilleures affaires"),
    ("gamesplanet", "Promos Gamesplanet"),
    ("historique", "Au plus bas historique"),
    ("5", "Moins de 5 €"),
    ("15", "Moins de 15 €"),
    ("gratuit", "Gratuits"),
    ("tout", "Tout"),
)

#: « Recommande » : le tri qui convient a la page (pertinence pour une
#: recherche, remise pour les promotions, notoriete ailleurs)
TRIS = (
    ("auto", "Recommande"),
    ("populaires", "Les plus populaires"),
    ("remise", "Plus grosse remise"),
    ("prix", "Prix croissant"),
    ("prix_desc", "Prix decroissant"),
    ("economie", "Plus grosse economie"),
    ("note", "Mieux notes"),
    ("fin", "Fin de promotion proche"),
    ("titre", "Titre"),
    ("hasard", "Decouverte (au hasard)"),
)

POLITIQUE = (
    "ORION ne retient comme « meilleur prix » que des boutiques sures :\n\n"
    "• Boutiques officielles : Steam, GOG, Epic, Ubisoft, EA, Battle.net, "
    "Microsoft...\n"
    "• Revendeurs agrees : Fanatical, Humble, Green Man Gaming, Gamesplanet, "
    "GamersGate, WinGameStore, IndieGala... Ils achetent leurs cles "
    "directement aux editeurs : c'est le meme jeu, la meme cle officielle, "
    "souvent moins cher.\n\n"
    "Les revendeurs de cles ne sont jamais retenus comme meilleur prix. "
    "Trois sont proposes a part, apres les boutiques officielles, si "
    "l'option est active : Instant Gaming, Kinguin et Loaded, pour une cle "
    "Steam du jeu lui-meme, jamais un cadeau (« Gift ») ni un compte. G2A, "
    "Gamivo, Eneba et les autres places de marche sont ecartees : n'importe "
    "qui peut y revendre des cles achetees a l'etranger ou avec des cartes "
    "volees, l'editeur peut les annuler, le compte peut etre suspendu, et "
    "l'argent ne revient pas a ceux qui font les jeux.\n\n"
    "Sources : Steam, GOG et, grace aux donnees IsThereAnyDeal, plus de "
    "trente boutiques agreees, sans rien configurer.")

#: ce qu'ORION a verifie avant d'afficher le prix d'un revendeur de cles
VERIFIE = ("Verifie par ORION : la fiche du jeu lui-meme (ni edition, ni DLC, ni "
           "compte, ni « Gift »), en cle Steam pour PC, activable dans votre pays, "
           "et moins chere que les boutiques officielles. Prix releve il y a moins "
           "de six heures : il peut avoir change. Un revendeur de cles n'est pas "
           "une boutique officielle.")
#: fiche choisie a la main (worker.js, KINGUIN_CHOISIS) : pas forcement une cle Steam
VERIFIE_CHOISIE = ("Fiche choisie a la main par ORION : le jeu lui-meme (ni compte, ni « Gift »), "
                   "cle activable en Europe, moins chere que les boutiques officielles. Prix "
                   "releve recemment : il peut avoir change. Un revendeur de cles n'est pas "
                   "une boutique officielle.")
PARTENAIRE = ("Lien partenaire : votre prix ne change pas, une petite "
              "commission finance ORION.")
INDICE_POUR_VOUS = (
    "Les suggestions s'affinent a mesure qu'ORION connait vos jeux "
    "(genres, studios, series). Ouvrez quelques fiches de jeux ou "
    "lancez une analyse de la bibliotheque.")
INDICE_SANS_JEUX = (
    "Analysez votre bibliotheque (ou reliez vos comptes de jeux) : ORION "
    "vous proposera ici des jeux proches de ceux que vous aimez, sans "
    "jamais vous montrer un jeu que vous avez deja.")
OFFICIEL_GP = ("Chercher ce jeu sur Gamesplanet, revendeur officiel : "
               "cles fournies par les editeurs.")
OFFRE_GP = ("Ouvrir ce jeu chez Gamesplanet, revendeur officiel : "
            "cles fournies par les editeurs.")


def offre_gamesplanet(fiche):
    """L'offre Gamesplanet relevee pour cette fiche (prix reel), ou None."""
    return next((o for o in fiche.offres if o.source == "gamesplanet" and o.url), None)


def _pastille(texte: str, couleur_: str) -> QLabel:
    lab = QLabel(texte)
    lab.setStyleSheet(
        f"color:{couleur_}; font-size:10.5px; font-weight:700; letter-spacing:.5px;"
        f" border:1px solid {couleur_}; border-radius:4px; padding:2px 7px;")
    return lab


# ---------------------------------------------------------------------------
# Fiche detaillee : meilleure offre et comparatif
# ---------------------------------------------------------------------------
class OffreLigne(QFrame):
    """Une boutique dans le comparatif deplie."""

    def __init__(self, offre, meilleure: bool, parent=None) -> None:
        super().__init__(parent)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(10, 4, 6, 4)
        lay.setSpacing(12)
        niveau = offre.confiance
        coul = (PALETTE["ok"] if niveau.cle == OFFICIEL else
                PALETTE["accent"] if niveau.sur else PALETTE["text_faint"])

        nom = QLabel(offre.boutique)
        nom.setMinimumWidth(170)
        nom.setStyleSheet(f"font-weight:600; color:{PALETTE['text'] if niveau.sur else PALETTE['text_faint']};")
        lay.addWidget(nom)
        from ...i18n import t
        conf = QLabel(("● " if niveau.sur else "⊘ ") + t(niveau.libelle))
        conf.setToolTip(niveau.explication)
        conf.setMinimumWidth(190)
        conf.setStyleSheet(f"color:{coul}; font-size:11.5px;")
        lay.addWidget(conf)
        if offre.drm:
            drm = QLabel(offre.drm)
            drm.setObjectName("Faint")
            lay.addWidget(drm)
        lay.addStretch(1)
        if offre.remise:
            lay.addWidget(_pastille(f"-{offre.remise} %", PALETTE["warn"]),
                          0, Qt.AlignmentFlag.AlignVCenter)
        prix = QLabel(euros(offre.prix))
        prix.setMinimumWidth(90)
        prix.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        prix.setStyleSheet(
            f"font-size:14px; font-weight:{'800' if meilleure else '600'};"
            f" color:{PALETTE['ok'] if meilleure else (PALETTE['text'] if niveau.sur else PALETTE['text_faint'])};"
            + ("" if niveau.sur else " text-decoration: line-through;"))
        lay.addWidget(prix)
        ouvrir = QPushButton("Ouvrir" if niveau.sur else "Non sur")
        ouvrir.setObjectName("Ghost")
        ouvrir.setCursor(Qt.CursorShape.PointingHandCursor)
        ouvrir.setEnabled(niveau.sur and bool(offre.url))
        ouvrir.clicked.connect(lambda: ouvrir_lien(offre.url))
        if est_partenaire(offre.url):
            ouvrir.setToolTip(PARTENAIRE)
        lay.addWidget(ouvrir)


def _entete_bloc(texte: str, couleur_trait: str) -> QLabel:
    """Titre d'un bloc du comparatif : officielles d'un cote, revendeurs de
    cles de l'autre, chacun sa couleur."""
    from ...i18n import t
    e = QLabel(t(texte).upper())
    e.setContentsMargins(10, 6, 6, 2)
    e.setStyleSheet(f"color:{couleur_trait}; font-size:10.5px; font-weight:700;"
                    " letter-spacing:1.5px;")
    return e


class RevendeurLigne(QWidget):
    """Un revendeur de cles dans le comparatif : non officiel, sans prix
    connu d'ORION, lien vers la recherche du jeu."""

    def __init__(self, site, url: str, parent=None) -> None:
        super().__init__(parent)
        self.site, self.url = site, url
        lay = QHBoxLayout(self)
        lay.setContentsMargins(10, 4, 6, 4)
        lay.setSpacing(12)
        nom = QLabel(site.nom)
        nom.setMinimumWidth(170)
        nom.setStyleSheet(f"font-weight:600; color:{PALETTE['text']};")
        lay.addWidget(nom)
        from ...i18n import t
        genre = QLabel("◆ " + t(site.genre))
        genre.setMinimumWidth(190)
        genre.setToolTip(site.note)
        genre.setStyleSheet(f"color:{PALETTE['warn']}; font-size:11.5px;")
        lay.addWidget(genre)
        self.vendeur = QLabel("")
        self.vendeur.setObjectName("Faint")
        self.vendeur.hide()
        lay.addWidget(self.vendeur)
        lay.addStretch(1)
        self.economie = _pastille("", PALETTE["warn"])
        self.economie.hide()
        lay.addWidget(self.economie, 0, Qt.AlignmentFlag.AlignVCenter)
        # sans prix verifie, ORION ne sait pas si le site vend le jeu : le
        # lien ouvre sa recherche, et le dit
        self.prix = QLabel("Chercher sur le site")
        self.prix.setObjectName("Faint")
        self.prix.setMinimumWidth(90)
        self.prix.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        lay.addWidget(self.prix)
        self.bouton = QPushButton("Ouvrir")
        self.bouton.setObjectName("Ghost")
        self.bouton.setCursor(Qt.CursorShape.PointingHandCursor)
        self.bouton.setToolTip(site.note + ("\n" + PARTENAIRE if est_partenaire(url) else ""))
        self.bouton.clicked.connect(lambda: ouvrir_lien(self.url))
        lay.addWidget(self.bouton)

    def montrer_prix(self, offre: dict, prix_officiel: float) -> None:
        """Affiche le prix sur releve par le service : fiche du jeu en cle
        Steam, vendeur tres bien note. Le bouton ouvre alors cette fiche."""
        from ...i18n import t
        self.url = offre["url"]
        self.prix.setObjectName("")
        self.prix.setText(euros(offre["prix"]))
        self.prix.setStyleSheet(f"font-size:14px; font-weight:700; color:{PALETTE['ok']};")
        if prix_officiel > 0:
            self.economie.setText(f"-{round(100 - offre['prix'] * 100 / prix_officiel)} %")
            self.economie.show()
        if "ventes" in offre:
            ventes = f"{offre['ventes']:,}".replace(",", " ")
            self.vendeur.setText(t(f"vendeur note {offre['note']:.0f} % · {ventes} ventes"))
        else:
            self.vendeur.setText(t("vendeur unique"))
        self.vendeur.show()
        self.prix.setToolTip(t("Cle Steam activable chez vous, prix releve il y a "
                               "moins de six heures : il peut avoir change."))


class FicheLigne(QFrame):
    """Un jeu : visuel, meilleure offre sure, et comparatif depliable."""

    comparer_demande = Signal(object)
    suivre_demande = Signal(str, str)        # appid, titre
    ne_plus_suivre_demande = Signal(str, str)    # appid, titre
    contenu_change = Signal()                # la fiche a grandi ou retreci

    def __init__(self, fiche: Fiche, suivis: set[str], parent=None,
                 avec_image: bool = True) -> None:
        super().__init__(parent)
        self.fiche = fiche
        self.setObjectName("Panel")
        racine = QVBoxLayout(self)
        racine.setContentsMargins(14, 12, 14, 12)
        racine.setSpacing(8)

        lay = QHBoxLayout()
        lay.setSpacing(16)
        racine.addLayout(lay)

        self.image = QLabel()
        self.image.setFixedSize(IMAGE)
        self.image.setVisible(avec_image)
        lay.addWidget(self.image, 0, Qt.AlignmentFlag.AlignTop)
        self.maj_image()

        # -- centre : titre, badges, infos --------------------------------
        centre = QVBoxLayout()
        centre.setSpacing(6)
        titre = QLabel(fiche.titre)
        titre.setStyleSheet("font-size:16px; font-weight:700;")
        titre.setWordWrap(True)
        titre.setVisible(avec_image)          # la fiche detaillee a son bandeau
        centre.addWidget(titre)

        badges = QHBoxLayout()
        badges.setSpacing(6)
        if fiche.gratuit:
            badges.addWidget(_pastille("GRATUIT", PALETTE["ok"]))
        elif fiche.remise:
            badges.addWidget(_pastille(f"-{fiche.remise} %", PALETTE["warn"]))
        if fiche.au_plus_bas:
            badges.addWidget(_pastille("PLUS BAS HISTORIQUE", PALETTE["ok"]))
        fin = _reste(fiche.fin_promo)
        if fin:
            badges.addWidget(_pastille(fin.upper(), PALETTE["esport"]
                                       if fiche.fin_promo - time.time() < 86400
                                       else PALETTE["text_dim"]))
        badges.addStretch(1)
        centre.addLayout(badges)

        infos = []
        if fiche.etiquettes:
            infos.append(", ".join(fiche.etiquettes[:3]))
        if fiche.sortie:
            infos.append(f"Sortie {fiche.sortie}")
        if fiche.note:
            infos.append(f"{fiche.note} % d'avis positifs")
        if fiche.plus_bas_historique and not fiche.gratuit:
            infos.append(f"Plus bas historique {euros(fiche.plus_bas_historique)}")
        if infos:
            ligne = QLabel("   ·   ".join(infos))
            ligne.setObjectName("Faint")
            ligne.setWordWrap(True)
            centre.addWidget(ligne)
        centre.addStretch(1)
        lay.addLayout(centre, 1)

        # -- droite : prix et actions ---------------------------------------
        droite = QVBoxLayout()
        droite.setSpacing(4)
        m = fiche.meilleure
        prix = QLabel(euros(m.prix) if m else "—")
        prix.setAlignment(Qt.AlignmentFlag.AlignRight)
        prix.setStyleSheet(
            f"font-size:24px; font-weight:800; color:{PALETTE['ok'] if m and (fiche.remise or m.gratuit) else PALETTE['text']};")
        droite.addWidget(prix)
        if m and fiche.prix_normal and fiche.prix_normal > m.prix:
            barre = QLabel(f"<s>{euros(fiche.prix_normal)}</s>  ·  "
                           f"{euros(fiche.economie)} d'economie")
            barre.setAlignment(Qt.AlignmentFlag.AlignRight)
            barre.setObjectName("Faint")
            droite.addWidget(barre)
        if m:
            from ...i18n import t
            chez = QLabel(f"{t('chez')} <b>{m.boutique}</b>  ·  {t(m.confiance.libelle)}")
            chez.setAlignment(Qt.AlignmentFlag.AlignRight)
            chez.setToolTip(m.confiance.explication)
            chez.setStyleSheet(f"color:{PALETTE['text_dim']}; font-size:11.5px;")
            droite.addWidget(chez)

        # actions sur toute la largeur : les infos gardent la place a gauche
        actions = QHBoxLayout()
        actions.setSpacing(6)
        # les liens vers les boutiques ont leur propre ligne : avec les
        # actions sur la meme ligne, la fiche devenait plus large que sa
        # fenetre et les prix sortaient de l'ecran
        liens_boutiques = QHBoxLayout()
        liens_boutiques.setSpacing(6)
        self.bouton_officiel = None
        # Gamesplanet : son vrai prix quand il vend le jeu (bouton vers la
        # fiche), sinon la recherche du jeu chez lui
        offre_gp = offre_gamesplanet(fiche)
        lien_gp = offre_gp.url if offre_gp else lien_gamesplanet(fiche.titre, fiche.steam_appid)
        if lien_gp and not (m and "gamesplanet" in m.boutique.lower()):
            gp = QPushButton(f"Gamesplanet  ·  {euros(offre_gp.prix)}" if offre_gp
                             else "Chercher sur Gamesplanet")
            gp.setObjectName("Ghost")
            gp.setCursor(Qt.CursorShape.PointingHandCursor)
            from ...i18n import t
            gp.setToolTip(t(OFFRE_GP if offre_gp else OFFICIEL_GP)
                          + ("\n" + t(PARTENAIRE) if est_partenaire(lien_gp) else ""))
            gp.clicked.connect(lambda: ouvrir_lien(lien_gp))
            liens_boutiques.addWidget(gp)
            self.bouton_officiel = gp
        # Les revendeurs de cles n'ont plus de bouton ici : ils ont leur
        # propre bloc dans le comparatif, sous les boutiques officielles et
        # bien separes d'elles (`remplir_comparatif`).
        liens_boutiques.addStretch(1)
        actions.addStretch(1)
        # Suivre : un clic ajoute aux Envies, un second retire (un clic de
        # travers ne doit pas obliger a aller defaire le suivi ailleurs)
        self.bouton_suivre = None
        self.suivi = bool(fiche.steam_appid and fiche.steam_appid in suivis)
        if fiche.steam_appid:
            self.bouton_suivre = QPushButton("")
            self.bouton_suivre.setObjectName("Ghost")
            self.bouton_suivre.setCursor(Qt.CursorShape.PointingHandCursor)
            self.bouton_suivre.clicked.connect(self._basculer_suivi)
            actions.addWidget(self.bouton_suivre)
            self._maj_suivi()
        # DLC du jeu (version Steam) : deja acquis ou au meilleur prix
        self.bouton_dlc = None
        if fiche.steam_appid and not fiche.est_application:
            self.bouton_dlc = QPushButton("DLC")
            self.bouton_dlc.setObjectName("Ghost")
            self.bouton_dlc.setCheckable(True)
            self.bouton_dlc.setToolTip("Contenus additionnels du jeu : ceux que vous avez "
                                       "deja, et les autres au meilleur prix")
            self.bouton_dlc.toggled.connect(self._deplier_dlc)
            actions.addWidget(self.bouton_dlc)
        self.bouton_comparer = QPushButton(self._libelle_comparer())
        self.bouton_comparer.setObjectName("Ghost")
        self.bouton_comparer.setCheckable(True)
        self.bouton_comparer.toggled.connect(self._deplier)
        actions.addWidget(self.bouton_comparer)
        if m:
            acheter = QPushButton("Obtenir" if m.gratuit else "Acheter")
            acheter.setObjectName("Primary")
            acheter.setStyleSheet("padding: 8px 20px; font-size: 13px;")
            acheter.setToolTip(f"Ouvrir la page du jeu chez {m.boutique}")
            acheter.clicked.connect(lambda: ouvrir_lien(m.url))
            if est_partenaire(m.url):
                acheter.setToolTip(PARTENAIRE)
            actions.addWidget(acheter)
        droite.addStretch(1)
        lay.addLayout(droite)
        if liens_boutiques.count() > 1:
            racine.addLayout(liens_boutiques)
        racine.addLayout(actions)
        self._actions, self.bouton_cle, self._url_cle = actions, None, ""

        # -- comparatif ------------------------------------------------------
        self.comparatif = QFrame()
        self.comparatif.setObjectName("PanelFlat")
        self.comparatif_lay = QVBoxLayout(self.comparatif)
        self.comparatif_lay.setContentsMargins(6, 6, 6, 6)
        self.comparatif_lay.setSpacing(2)
        self.comparatif.hide()
        racine.addWidget(self.comparatif)
        # -- DLC (cree a la premiere ouverture) ------------------------------
        self.dlc = None
        self._racine = racine
        racine.addStretch(1)            # contenu tasse en haut dans la fiche
        self._charge = False

    def _basculer_suivi(self) -> None:
        self.suivi = not self.suivi
        signal = self.suivre_demande if self.suivi else self.ne_plus_suivre_demande
        signal.emit(self.fiche.steam_appid, self.fiche.titre)
        self._maj_suivi()

    def _maj_suivi(self) -> None:
        if self.bouton_suivre is None:
            return
        from ...i18n import t
        self.bouton_suivre.setText(SUIVI if self.suivi else "Suivre")
        self.bouton_suivre.setToolTip(t(
            "Dans vos Envies. Cliquez pour ne plus suivre ce jeu." if self.suivi
            else "Ajouter a vos Envies pour etre prevenu d'une baisse"))

    def _libelle_comparer(self) -> str:
        n = self.fiche.nb_boutiques
        return f"Comparer ({n} boutique{'s' if n > 1 else ''})" if n > 1 \
            else "Comparer les boutiques"

    def maj_image(self) -> None:
        if not self.image.isVisible() and self.image.isHidden():
            return
        f = self.fiche
        pix = ChargeurImages.instance().image(f.visuels("carte"), IMAGE)
        if pix is None:
            from ..widgets.game_card import placeholder
            pix = placeholder(f.titre, IMAGE, f.cle)
        self.image.setPixmap(pix)

    def _dlc_ouverts(self) -> bool:
        return bool(self.bouton_dlc is not None and self.bouton_dlc.isChecked())

    def _deplier(self, ouvert: bool) -> None:
        if ouvert and self._dlc_ouverts():
            self.bouton_dlc.setChecked(False)       # l'un ou l'autre, jamais empiles
        self.comparatif.setVisible(ouvert and not self._dlc_ouverts())
        if ouvert and not self._charge:
            self._charge = True
            self.remplir_comparatif(chargement=True)
            self.comparer_demande.emit(self.fiche)
            self._demander_prix_revendeurs()
        self.contenu_change.emit()

    def _deplier_dlc(self, ouvert: bool) -> None:
        if self.dlc is None:
            if not ouvert:
                return
            from ..widgets.dlc_panel import PanneauDlc
            self.dlc = PanneauDlc(cadre=False, origine="boutique")
            self.dlc.contenu_change.connect(self.contenu_change)
            # juste avant l'espace elastique qui tasse la fiche en haut
            self._racine.insertWidget(self._racine.count() - 1, self.dlc)
            self.dlc.definir_jeu(self.fiche.steam_appid)
        self.dlc.setVisible(ouvert)
        # les DLC prennent la place des offres du jeu : qui les demande ne
        # veut pas d'abord relire le jeu, puis defiler jusqu'a eux
        self.comparatif.setVisible(not ouvert and self.bouton_comparer.isChecked())
        self.bouton_dlc.setText("Offres du jeu" if ouvert else "DLC")
        self.bouton_dlc.setToolTip(
            "Revenir aux offres du jeu" if ouvert else
            "Contenus additionnels du jeu : ceux que vous avez deja, et les autres "
            "au meilleur prix")
        self.contenu_change.emit()

    # -- prix des revendeurs de cles ------------------------------------
    def _demander_prix_revendeurs(self) -> None:
        """Demande au service d'ORION le prix sur du jeu chez les revendeurs
        (une fois par fiche, en arriere-plan). Sans reponse sure, la ligne
        garde « Prix sur le site »."""
        if getattr(self, "_prix_demandes", False) or not self.fiche.steam_appid \
                or self.fiche.gratuit or not liens_revendeurs(self.fiche.titre):
            return
        self._prix_demandes = True
        from ... import prix_revendeurs
        from ...core.tasks import Task
        tache = Task(prix_revendeurs.offres, self.fiche.steam_appid, self.fiche.titre)
        tache.signals.finished.connect(self._prix_revendeur_recu)
        tache.start()

    def _prix_revendeur_recu(self, offres) -> None:
        """`offres` : {revendeur: offre ou None} ; une offre seule (celle de
        Kinguin, forme d'avant la 2.0) est acceptee aussi."""
        if isinstance(offres, dict) and "prix" in offres:
            offres = {"kinguin": offres}
        self._revendeurs_repondu = bool(isinstance(offres, dict) and offres.get("repondu"))
        self._offres_revendeurs = {k: v for k, v in (offres or {}).items()
                                   if isinstance(v, dict)} if isinstance(offres, dict) else {}
        self._montrer_prix_revendeurs()

    def _montrer_prix_revendeurs(self) -> None:
        """Le prix d'un revendeur n'est montre que s'il est moins cher que la
        meilleure boutique officielle, et s'il s'agit bien du meme jeu."""
        from ...prix_revendeurs import meme_jeu
        m = self.fiche.meilleure
        offres = getattr(self, "_offres_revendeurs", {})
        normal = max((o.prix_normal or 0 for o in self.fiche.offres_sures), default=0)
        repondu = getattr(self, "_revendeurs_repondu", False)
        for ligne in getattr(self, "lignes_revendeurs", []):
            offre = offres.get(ligne.site.id)
            if offre and m is not None and offre["prix"] < m.prix and meme_jeu(offre, normal):
                ligne.montrer_prix(offre, m.prix)
            elif ligne.site.id == "loaded" and repondu:
                # Loaded : son catalogue est connu. Une cle Steam en stock,
                # plus chere que les boutiques officielles : le lien ouvre sa
                # fiche. Aucune : pas de lien vers une recherche qui montrerait
                # d'autres jeux.
                if offre and meme_jeu(offre, normal):
                    ligne.url = offre["url"]
                else:
                    ligne.hide()
        self._montrer_cle_verifiee(offres, m.prix if m is not None else 0, normal)
        self.contenu_change.emit()

    def _montrer_cle_verifiee(self, offres: dict, prix_officiel: float, normal: float) -> None:
        """La cle verifiee la moins chere, en vue a cote de « Acheter » : le
        joueur n'a pas a descendre jusqu'au bloc des revendeurs pour la voir.
        ORION dit ce qu'il a verifie ; ce n'est jamais « la meilleure offre »."""
        from ...i18n import t
        from ...prix_revendeurs import meilleure_cle
        cle = meilleure_cle(offres, prix_officiel, normal)
        if cle is None:
            if self.bouton_cle is not None:
                self.bouton_cle.hide()
            return
        if self.bouton_cle is None:
            self.bouton_cle = QPushButton("")
            self.bouton_cle.setObjectName("Ghost")
            self.bouton_cle.setCursor(Qt.CursorShape.PointingHandCursor)
            self.bouton_cle.setStyleSheet(
                f"color:{PALETTE['warn']}; border-color:{PALETTE['warn']}; font-weight:600;")
            self.bouton_cle.clicked.connect(lambda: ouvrir_lien(self._url_cle))
            self._actions.insertWidget(max(0, self._actions.count() - 1), self.bouton_cle)
        self._url_cle = cle["url"]
        from ...prix_revendeurs import libelle
        self.bouton_cle.setText(t(libelle(cle)) + f"  ·  {cle['boutique']}  {euros(cle['prix'])}")
        if "ventes" in cle:
            ventes = f"{cle['ventes']:,}".replace(",", " ")
            vendeur = t(f"vendeur note {cle['note']:.0f} % · {ventes} ventes")
        else:
            vendeur = t("vendeur unique")
        self.bouton_cle.setToolTip(
            t(VERIFIE_CHOISIE if cle.get("choisi") else VERIFIE) + "\n" + vendeur
            + ("\n" + t(PARTENAIRE) if est_partenaire(cle["url"]) else ""))
        self.bouton_cle.show()

    def remplir_comparatif(self, chargement: bool = False) -> None:
        """Deux blocs bien separes : les boutiques officielles (prix connus,
        compares), puis les revendeurs de cles, non officiels (lien de
        recherche, regle d'achat). Jamais melanges."""
        clear_layout(self.comparatif_lay)
        self.lignes_revendeurs: list[RevendeurLigne] = []
        meilleure = self.fiche.meilleure
        offres = self.fiche.offres_sures + sorted(
            (o for o in self.fiche.offres if not o.sure), key=lambda o: o.prix)
        self.comparatif_lay.addWidget(_entete_bloc("Boutiques officielles", PALETTE["ok"]))
        for o in offres:
            self.comparatif_lay.addWidget(OffreLigne(o, o is meilleure))
        note = QLabel("Recherche des autres boutiques..." if chargement else
                      f"{self.fiche.nb_boutiques} boutique(s) sure(s) comparee(s).")
        note.setObjectName("Faint")
        note.setContentsMargins(10, 4, 0, 2)
        self.comparatif_lay.addWidget(note)
        if any(o.source == "itad" for o in offres):
            # la source est nommee, comme le demande IsThereAnyDeal
            source = QLabel("Prix des boutiques agreees : donnees IsThereAnyDeal.")
        elif self.fiche.plus_bas_historique:
            source = QLabel("Plus bas historique : donnees IsThereAnyDeal.")
        else:
            source = None
        if source is not None:
            source.setObjectName("Faint")
            source.setContentsMargins(10, 0, 0, 2)
            self.comparatif_lay.addWidget(source)

        revendeurs = liens_revendeurs(self.fiche.titre)
        if revendeurs and not self.fiche.gratuit:
            self.comparatif_lay.addSpacing(10)
            self.comparatif_lay.addWidget(
                _entete_bloc("Revendeurs de cles, non officiels", PALETTE["warn"]))
            explication = QLabel(
                "Souvent moins chers, mais leurs cles ne viennent pas des editeurs. "
                "Un prix n'est affiche que pour une cle Steam, chez un vendeur unique "
                "ou tres bien note, et s'il bat les boutiques officielles ; sinon le "
                "lien ouvre la recherche du jeu sur leur site.")
            explication.setObjectName("Faint")
            explication.setWordWrap(True)
            explication.setContentsMargins(10, 0, 6, 2)
            self.comparatif_lay.addWidget(explication)
            for site, url in revendeurs:
                ligne = RevendeurLigne(site, url)
                self.lignes_revendeurs.append(ligne)
                self.comparatif_lay.addWidget(ligne)
                for code in codes_promo.actifs(site.id):
                    # code promo du partenaire, sous son lien, tant qu'il est
                    # valable ; le joueur le saisit lui-meme sur le site
                    promo = QLabel(codes_promo.texte(code))
                    promo.setWordWrap(True)
                    promo.setContentsMargins(26, 0, 6, 4)
                    promo.setStyleSheet(f"color:{PALETTE['ok']}; font-size:11.5px;")
                    self.comparatif_lay.addWidget(promo)
            regle = QLabel(consigne())
            regle.setWordWrap(True)
            regle.setContentsMargins(10, 4, 6, 2)
            regle.setStyleSheet(f"color:{PALETTE['warn']}; font-size:11.5px;")
            self.comparatif_lay.addWidget(regle)
        self.bouton_comparer.setText(self._libelle_comparer())
        self._montrer_prix_revendeurs()       # prix deja recus : les lignes sont neuves


class BandeauFiche(QWidget):
    """Grande image en tete de la fiche detaillee, titre en surimpression."""

    def __init__(self, fiche: Fiche, raison: str = "", parent=None) -> None:
        super().__init__(parent)
        self.fiche, self.raison = fiche, raison
        self.setFixedHeight(260)
        self._urls = fiche.visuels("une")
        ChargeurImages.instance().prete.connect(
            lambda url: url in self._urls and self.update())

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = QRectF(self.rect())
        chemin = QPainterPath()
        chemin.addRoundedRect(r, 14, 14)
        p.setClipPath(chemin)
        pix = ChargeurImages.instance().image(self._urls, self.size())
        if pix is not None:
            p.drawPixmap(0, 0, pix)
        else:
            degrade(p, r, self.fiche.cle)
        voile = QLinearGradient(0, r.height() * 0.3, 0, r.height())
        voile.setColorAt(0, QColor(10, 13, 20, 0))
        voile.setColorAt(1, QColor(10, 13, 20, 235))
        p.fillRect(r, voile)
        base = self.font()
        p.setPen(QColor(255, 255, 255))
        p.setFont(police(base, 26, QFont.Weight.Bold))
        bas = r.bottom() - (44 if self.raison else 20)
        p.drawText(QRectF(24, bas - 40, r.width() - 48, 40),
                   Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignBottom, self.fiche.titre)
        if self.raison:
            p.setFont(police(base, 12.5))
            p.setPen(couleur("accent"))
            p.drawText(QRectF(24, bas + 4, r.width() - 48, 22),
                       Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, self.raison)
        p.end()


class FicheDialogue(QDialog):
    """La fiche d'un jeu : bandeau, meilleure offre et comparatif."""

    def __init__(self, fiche: Fiche, suivis: set[str], raison: str = "",
                 parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle(fiche.titre)
        self.setModal(True)
        self.resize(820, 680)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(18, 18, 18, 18)
        lay.setSpacing(12)
        lay.addWidget(BandeauFiche(fiche, raison))
        self.ligne = FicheLigne(fiche, suivis, avec_image=False)
        defile = self.defile = ZoneDefilante()
        defile.setWidgetResizable(True)
        defile.setFrameShape(QFrame.Shape.NoFrame)
        defile.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        defile.setWidget(self.ligne)
        lay.addWidget(defile, 1)
        # la fenetre n'est jamais plus etroite que son contenu : rien de coupe
        self.setMinimumWidth(self.ligne.minimumSizeHint().width() + 60)
        fermer = QPushButton("Fermer")
        fermer.setObjectName("Ghost")
        fermer.clicked.connect(self.accept)
        bas = self.bas = QHBoxLayout()
        bas.addStretch(1)
        bas.addWidget(fermer)
        lay.addLayout(bas)
        self.ligne.contenu_change.connect(self._ajuster_bientot)

    #: hauteur de depart : la fenetre ne descend jamais en dessous
    HAUTEUR_MIN = 680

    def showEvent(self, event) -> None:               # noqa: N802
        super().showEvent(event)
        self._ajuster_bientot()

    def manque(self) -> int:
        """Hauteur qui manque pour lire toute la fiche sans defiler (negative
        s'il reste de la place). Elle est MESUREE sur la fiche telle qu'elle
        est mise en page, a sa largeur reelle : aucune hauteur de bandeau, de
        marge ou de ligne n'est supposee, donc un texte qui passe sur deux
        lignes ou un bloc de plus sont comptes d'office."""
        vue = self.defile.viewport()
        largeur = max(1, vue.width())
        if self.ligne.hasHeightForWidth():
            contenu = self.ligne.heightForWidth(largeur)
        else:
            contenu = self.ligne.sizeHint().height()
        return max(contenu, self.ligne.minimumSizeHint().height()) - vue.height()

    def hauteur_voulue(self, limite: int) -> int:
        """Hauteur qui montre toute la fiche, bornee par la place a l'ecran."""
        return max(self.HAUTEUR_MIN, min(self.height() + self.manque(), int(limite)))

    def limite(self) -> int:
        """Hauteur maximale : celle de l'ecran, moins la barre de titre."""
        ecran = self.screen().availableGeometry() if self.screen() is not None else None
        return ecran.height() - 60 if ecran is not None else 900

    def _ajuster_bientot(self) -> None:
        """Mesure une fois la mise en page faite : a l'instant ou le contenu
        change, la zone de defilement n'a pas encore sa taille."""
        plus_tard(self, 0, self._ajuster)

    def _ajuster(self) -> None:
        """La fenetre grandit avec le nombre de boutiques et de revendeurs :
        toutes les lignes se lisent sans defiler, tant que l'ecran le permet.
        Au-dela, la fiche defile comme avant."""
        self.setMinimumWidth(self.ligne.minimumSizeHint().width() + 60)
        if not self.isVisible():
            return
        self.layout().activate()
        ecran = self.screen().availableGeometry() if self.screen() is not None else None
        hauteur = self.hauteur_voulue(self.limite())
        if abs(hauteur - self.height()) < 4:
            return
        self.resize(self.width(), hauteur)
        if ecran is not None:
            # la fenetre agrandie reste entierement a l'ecran
            haut = min(self.y(), ecran.bottom() - self.frameGeometry().height())
            self.move(self.x(), max(ecran.top(), haut))


# ---------------------------------------------------------------------------
# Elements de la vitrine
# ---------------------------------------------------------------------------
class DefilementFluide(ZoneDefilante):
    """Zone de defilement a la molette animee (les pavés tactiles, deja
    fluides, gardent leur comportement)."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._anim = QPropertyAnimation(self.verticalScrollBar(), b"value", self)
        self._anim.setDuration(280)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._cible = 0

    def wheelEvent(self, event) -> None:
        dy = event.angleDelta().y()
        if not dy or not event.pixelDelta().isNull() or \
                event.modifiers() & Qt.KeyboardModifier.ControlModifier:
            return super().wheelEvent(event)
        barre = self.verticalScrollBar()
        depart = self._cible if self._anim.state() == QPropertyAnimation.State.Running \
            else barre.value()
        self._cible = max(barre.minimum(), min(barre.maximum(), int(depart - dy * 1.2)))
        self.glisser(self._cible)
        event.accept()

    def aller(self, valeur: int = 0) -> None:
        """Position immediate (changement de page : rien a faire defiler)."""
        self._anim.stop()
        barre = self.verticalScrollBar()
        self._cible = max(barre.minimum(), min(barre.maximum(), int(valeur)))
        barre.setValue(self._cible)

    def glisser(self, valeur: int, duree: int = 280) -> None:
        barre = self.verticalScrollBar()
        valeur = max(barre.minimum(), min(barre.maximum(), int(valeur)))
        self._cible = valeur
        self._anim.stop()
        self._anim.setDuration(duree)
        self._anim.setStartValue(barre.value())
        self._anim.setEndValue(valeur)
        self._anim.start()


class Section(QWidget):
    """Titre de rangee, sous-titre et lien « Tout voir »."""

    def __init__(self, titre: str, sous_titre: str = "", lien: str = "",
                 parent=None) -> None:
        super().__init__(parent)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(2, 0, 2, 0)
        lay.setSpacing(12)
        textes = QVBoxLayout()
        textes.setSpacing(1)
        ligne = QHBoxLayout()
        ligne.setSpacing(10)
        barre = QFrame()
        barre.setFixedSize(4, 20)
        barre.setStyleSheet(f"background: {accent()}; border-radius: 2px;")
        ligne.addWidget(barre, 0, Qt.AlignmentFlag.AlignVCenter)
        self.titre = QLabel(titre)
        self.titre.setStyleSheet("font-size: 19px; font-weight: 700;")
        ligne.addWidget(self.titre, 1)
        textes.addLayout(ligne)
        self.sous_titre = QLabel(sous_titre)
        self.sous_titre.setObjectName("PageHint")
        self.sous_titre.setContentsMargins(14, 0, 0, 0)     # aligne sur le titre
        self.sous_titre.setVisible(bool(sous_titre))
        textes.addWidget(self.sous_titre)
        lay.addLayout(textes, 1)
        self.lien = QPushButton(lien + "  ›" if lien else "")
        self.lien.setCursor(Qt.CursorShape.PointingHandCursor)
        self.lien.setVisible(bool(lien))
        self.lien.setStyleSheet(
            f"QPushButton {{ background: transparent; border: none; color: {accent()};"
            f" font-weight: 600; padding: 4px 2px; }}"
            f"QPushButton:hover {{ color: {PALETTE['text']}; }}")
        lay.addWidget(self.lien, 0, Qt.AlignmentFlag.AlignBottom)

    def set_sous_titre(self, texte: str) -> None:
        self.sous_titre.setText(texte)
        self.sous_titre.setVisible(bool(texte))


class Pagination(QWidget):
    """Numeros de page sous la grille : « ‹ 1 2 3 … 9 › », puis « Plus de
    jeux » tant que le magasin en a d'autres a donner."""
    choisie = Signal(int)
    plus = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._lay = QHBoxLayout(self)
        self._lay.setContentsMargins(0, 8, 0, 8)
        self._lay.setSpacing(6)
        self.page, self.total = 0, 1
        self.hide()

    @staticmethod
    def numeros(page: int, total: int) -> list:
        """Pages proposees : toutes s'il y en a peu, sinon la premiere, la
        derniere et les voisines de la page courante (None = « … »)."""
        if total <= 7:
            return list(range(total))
        gardees = sorted({0, total - 1, page - 1, page, page + 1} & set(range(total)))
        out: list = []
        for n in gardees:
            if out and n - out[-1] > 1:
                out.append(None)
            out.append(n)
        return out

    def regler(self, page: int, total: int, encore: bool = False,
               en_cours: bool = False) -> None:
        """`encore` : le magasin a d'autres jeux pour cette page ;
        `en_cours` : ils sont en train d'arriver."""
        self.page, self.total = page, total
        self.bouton_plus = None
        clear_layout(self._lay)
        self.setVisible(total > 1 or encore)
        if total <= 1 and not encore:
            return
        self._lay.addStretch(1)
        if total > 1:
            self._bouton("‹", page - 1, page > 0)
            for n in self.numeros(page, total):
                if n is None:
                    points = QLabel("…")
                    points.setObjectName("Faint")
                    self._lay.addWidget(points)
                else:
                    self._bouton(str(n + 1), n, True, n == page)
            self._bouton("›", page + 1, page < total - 1)
        if encore:
            from ...i18n import t
            b = self.bouton_plus = QPushButton(t("Chargement...") if en_cours else t("Plus de jeux"))
            b.setObjectName("Chip")
            b.setEnabled(not en_cours)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.setToolTip(t("Charger les jeux suivants du magasin"))
            b.clicked.connect(self.plus)
            self._lay.addWidget(b)
        self._lay.addStretch(1)

    def _bouton(self, texte: str, cible: int, actif: bool, coche: bool = False) -> None:
        b = QPushButton(texte)
        b.setObjectName("Chip")
        b.setCheckable(True)
        b.setChecked(coche)
        b.setEnabled(actif)
        b.setMinimumWidth(36)
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.clicked.connect(lambda _=False, c=cible: self.choisie.emit(c))
        self._lay.addWidget(b)


# ---------------------------------------------------------------------------
# La vue
# ---------------------------------------------------------------------------
class BoutiqueView(QWidget):
    actualiser_demande = Signal()
    recherche_demandee = Signal(str)
    comparer_demande = Signal(object)
    suivre_demande = Signal(str, str)
    ne_plus_suivre_demande = Signal(str, str)
    #: la suite du magasin pour un type de jeu (« » : tout le magasin)
    suite_demandee = Signal(str)
    #: cles verifiees des revendeurs pour les jeux de la page affichee
    cles_demandees = Signal(list)
    #: jeu introuvable : demander des jeux du meme esprit (terme, recherche vide ?)
    esprit_demande = Signal(str, bool)
    cle_demandee = Signal()
    #: jeu deja possede : l'ouvrir dans la bibliotheque (appid Steam, titre)
    bibliotheque_demandee = Signal(str, str)
    #: n'est plus emis : les images sont chargees par `ChargeurImages`
    #: « Voir les gratuits » : la page Boutique bascule sur l'onglet Gratuits
    voir_gratuits = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._catalogue: list[Fiche] = []
        self._resultats: list[Fiche] | None = None     # recherche en cours
        self._suite_en_cours: set[str] = set()         # types dont la suite arrive
        self._suite_finie: set[str] = set()            # types arrives au bout du magasin
        #: `differer(cle, fonction)` : remet un travail au prochain moment de
        #: calme (pose par la fenetre principale ; sans lui, tout est immediat)
        self.differer = None
        self._suite_auto = None                        # derniere page qui a demande seule
        self._suite_voulue: set[str] = set()           # suites demandees par « Plus de jeux »
        #: rang d'arrivee des jeux venus de la suite du magasin (0 : la
        #: vitrine). « Recommande » range par arrivee : une page deja vue ne
        #: change plus, les jeux nouveaux forment de nouvelles pages.
        self._lots: dict[str, int] = {}
        self._lot_suivant = 1
        self._cles_vues: set[str] = set()              # jeux dont la cle a deja ete demandee
        self._terme = ""
        self._page = 0                # page de la grille (PAR_PAGE cartes)
        self._liste = False           # « Tout voir » ou filtre choisi sur l'accueil
        self._demande = ""            # derniere recherche lancee dans les boutiques
        self._texte_avant = ""
        self._types_accueil: list[str] = []
        self._lignes: dict[str, FicheLigne] = {}
        self._suivis: set[str] = set()
        self._actualise_le = 0.0
        self._intervalle = 12
        self._apps_masquees = 0
        # bibliotheque : jeux possedes et ce qu'ORION sait d'eux
        self._jeux: list | None = None
        self._infos: dict = {}
        self._auto = True             # bibliotheque lue sur la fenetre principale
        self._signature: tuple | None = None
        self._possedes = sugg.Possedes()
        self._profil: sugg.Profil | None = None
        self._raisons: dict[str, str] = {}
        self._suggestions: list[sugg.Suggestion] = []
        self._genre = ""              # type de jeu choisi dans la colonne (« fps »...)

        root = QVBoxLayout(self)
        root.setContentsMargins(28, 22, 28, 0)
        root.setSpacing(10)
        self._racine = root

        # -- en-tete -----------------------------------------------------
        tete = QHBoxLayout()
        titres = QVBoxLayout()
        titres.setSpacing(2)
        t = QLabel("Boutique")
        t.setObjectName("PageTitle")
        titres.addWidget(t)
        self.titre_page = t
        self.sous_titre = QLabel(
            "Tous les jeux, toutes les boutiques sures, le prix le plus bas.")
        self.sous_titre.setObjectName("PageHint")
        titres.addWidget(self.sous_titre)
        tete.addLayout(titres, 1)
        self.etat = QLabel("")
        self.etat.setObjectName("Faint")
        self.etat.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        tete.addWidget(self.etat)
        pourquoi = QPushButton("Sites retenus")
        pourquoi.setObjectName("Ghost")
        pourquoi.setToolTip("Pourquoi certains sites ne sont jamais le meilleur prix")
        pourquoi.clicked.connect(self._politique)
        tete.addWidget(pourquoi)
        self.bouton_actualiser = QPushButton("Actualiser")
        self.bouton_actualiser.setObjectName("Ghost")
        self.bouton_actualiser.clicked.connect(self.actualiser_demande.emit)
        tete.addWidget(self.bouton_actualiser)
        root.addLayout(tete)

        self.progression = QProgressBar()
        self.progression.setTextVisible(False)
        self.progression.setFixedHeight(3)
        self.progression.setRange(0, 0)
        self.progression.hide()
        root.addWidget(self.progression)

        # -- barre d'outils : toujours a l'ecran. Recherche, filtres et tri
        # agissent sur la page en cours (accueil, type de jeu, liste) --------
        self.barre = QWidget()
        self.barre.setObjectName("Transparent")
        outils = QVBoxLayout(self.barre)
        outils.setContentsMargins(0, 2, 0, 2)
        outils.setSpacing(8)
        rech = QHBoxLayout()
        rech.setSpacing(10)
        self.retour = QPushButton("‹  Accueil de la boutique")
        self.retour.setObjectName("Ghost")
        self.retour.setCursor(Qt.CursorShape.PointingHandCursor)
        self.retour.setToolTip("Revenir a la vitrine")
        self.retour.clicked.connect(self.accueil)
        self.retour.hide()
        rech.addWidget(self.retour)
        self.fil = QLabel("")
        self.fil.setStyleSheet("font-size: 17px; font-weight: 700;")
        self.fil.hide()
        rech.addWidget(self.fil)
        self.recherche = QLineEdit()
        self.recherche.setObjectName("Search")
        self.recherche.setPlaceholderText(INVITE)
        self.recherche.setClearButtonEnabled(True)
        self.recherche.returnPressed.connect(self._chercher)
        self.recherche.textChanged.connect(self._saisie)
        # la grille suit la frappe, mais une fois la saisie posee
        self._delai_saisie = QTimer(self)
        self._delai_saisie.setSingleShot(True)
        self._delai_saisie.setInterval(220)
        self._delai_saisie.timeout.connect(lambda: self._rendre(True))
        self._delai_partout = QTimer(self)
        self._delai_partout.setSingleShot(True)
        self._delai_partout.setInterval(DEVANCE)
        self._delai_partout.timeout.connect(self._devancer)
        rech.addWidget(self.recherche, 1)
        # la liste qui s'ouvre sous la barre, comme sur les sites de vente de
        # jeux (demande de l'auteur, 14 octobre : Instant Gaming, Kinguin,
        # DLCompare) : jeux trouves avec leur prix, types de jeux, « Voir les
        # resultats » ; champ vide : vus recemment ou tendances
        self.panneau = PanneauRecherche(self, possede=lambda f: self._possedes.contient(f))
        self.panneau.fiche_choisie.connect(self._panneau_fiche)
        self.panneau.type_choisi.connect(self._panneau_type)
        self.panneau.tout_voir.connect(self._panneau_tout)
        self.recherche.installEventFilter(self)
        self._delai_panneau = QTimer(self)
        self._delai_panneau.setSingleShot(True)
        self._delai_panneau.setInterval(110)
        self._delai_panneau.timeout.connect(self._maj_panneau)
        self.bouton_chercher = QPushButton("Chercher partout")
        self.bouton_chercher.setObjectName("Primary")
        self.bouton_chercher.setStyleSheet("padding: 8px 18px; font-size: 13px;")
        self.bouton_chercher.setToolTip(
            "Interroger toutes les boutiques sures, en promotion ou non")
        self.bouton_chercher.clicked.connect(self._chercher)
        rech.addWidget(self.bouton_chercher)
        outils.addLayout(rech)

        filtres = QHBoxLayout()
        filtres.setSpacing(6)
        self.groupe = QButtonGroup(self)
        self.groupe.setExclusive(True)
        for cle, libelle in FILTRES:
            if cle in ("5", "15"):         # seuil dans la devise du pays choisi
                libelle = "Moins de " + region.prix(float(cle), decimales=False)
            b = QPushButton(libelle)
            b.setObjectName("Chip")
            b.setCheckable(True)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.setProperty("cle", cle)
            b.setProperty("libelle", libelle)
            self.groupe.addButton(b)
            filtres.addWidget(b)
            if cle == "affaires":
                b.setChecked(True)
        self.groupe.buttonClicked.connect(self._filtre_choisi)
        filtres.addStretch(1)
        trier = QLabel("Trier")
        trier.setObjectName("Faint")
        filtres.addWidget(trier)
        self.tri = QComboBox()
        for cle, libelle in TRIS:
            self.tri.addItem(libelle, cle)
        self.tri.currentIndexChanged.connect(lambda _i: self._rendre(True))
        filtres.addWidget(self.tri)
        # logiciels, formations, bandes originales... : toujours masques (la
        # case « Afficher les applications » a ete jugee inutile par l'auteur,
        # 7 octobre) ; le resume dit combien le sont (« 12 applications masquees »)
        self.voir_applications = QCheckBox("Afficher les applications")
        self.voir_applications.setChecked(False)
        self.voir_applications.hide()
        outils.addLayout(filtres)
        self.resume = QLabel("")
        self.resume.setObjectName("Faint")
        outils.addWidget(self.resume)
        root.addWidget(self.barre)

        # -- la page (tout defile ensemble, sous la barre) ------------------
        self.defile = DefilementFluide()
        self.defile.setWidgetResizable(True)
        self.defile.setFrameShape(QFrame.Shape.NoFrame)
        self.defile.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        conteneur = QWidget()
        conteneur.setObjectName("Transparent")
        self.vitrine = QVBoxLayout(conteneur)
        self.vitrine.setContentsMargins(0, 6, 10, 28)
        self.vitrine.setSpacing(12)
        self.defile.setWidget(conteneur)
        # colonne des types de jeux (FPS, MOBA, RTS...) a gauche de la vitrine
        corps = QHBoxLayout()
        corps.setSpacing(14)
        self.colonne_types = ZoneDefilante()
        self.colonne_types.setWidgetResizable(True)
        self.colonne_types.setFrameShape(QFrame.Shape.NoFrame)
        self.colonne_types.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.colonne_types.setFixedWidth(158)
        boite = QWidget()
        boite.setObjectName("Transparent")
        self._types_lay = QVBoxLayout(boite)
        self._types_lay.setContentsMargins(0, 6, 6, 20)
        self._types_lay.setSpacing(4)
        self.colonne_types.setWidget(boite)
        self.groupe_types = QButtonGroup(self)
        self.groupe_types.setExclusive(True)
        self.boutons_types: dict[str, QPushButton] = {}
        self.colonne_types.hide()
        corps.addWidget(self.colonne_types)
        corps.addWidget(self.defile, 1)
        root.addLayout(corps, 1)

        # -- accueil : la vitrine. Elle s'efface des qu'une liste occupe la
        # page (type de jeu, recherche, « Tout voir ») : rien a faire defiler
        self.bloc_accueil = QWidget()
        self.bloc_accueil.setObjectName("Transparent")
        self.rangees = QVBoxLayout(self.bloc_accueil)
        self.rangees.setContentsMargins(0, 0, 0, 0)
        self.rangees.setSpacing(12)
        self.vitrine.addWidget(self.bloc_accueil)

        # 1. a la une
        self.une = CarrouselUne()
        self.une.ouvrir.connect(self.ouvrir_fiche)
        self.une.voir.connect(self._voir_offre)
        self.une.suivre.connect(self._suivre_fiche)
        self.une.ne_plus_suivre.connect(self._ne_plus_suivre_fiche)
        self.une.hide()
        self.rangees.addWidget(self.une)
        self.rangees.addSpacing(14)

        # 2. pour vous, 3. rangees thematiques
        self.sections: dict[str, tuple[Section, RangeeCartes]] = {}
        self._rangee("pour_vous", "Pour vous",
                     "Choisis d'apres les jeux de votre bibliotheque")
        self.indice_pour_vous = QLabel(INDICE_POUR_VOUS)
        self.indice_pour_vous.setObjectName("Faint")
        self.indice_pour_vous.setWordWrap(True)
        self.indice_pour_vous.hide()
        self.rangees.addWidget(self.indice_pour_vous)
        # promos du distributeur partenaire, la ou il est le moins cher
        self._rangee("gamesplanet", "Promos Gamesplanet",
                     "Des cles officielles au meilleur prix du moment. "
                     "Gamesplanet est partenaire d'ORION.",
                     "Tout voir", lambda: self.voir_tout("gamesplanet", "remise"),
                     classe=RangeePromos)
        self._rangee("promos", "Grosses promos", "-50 % et plus sur des jeux connus",
                     "Tout voir", lambda: self.voir_tout("affaires", "remise"))
        self._rangee("historique", "Au plus bas historique",
                     "Jamais ces jeux n'ont ete moins chers",
                     "Tout voir", lambda: self.voir_tout("historique", "populaires"))
        self._rangee("gratuits", "Gratuits en ce moment",
                     "A recuperer avant la fin de l'offre",
                     "Voir les gratuits", self.voir_gratuits.emit)
        # 4. l'abondance : une rangee par type de jeu, puis les petits prix
        # et les mieux notes. Chaque « Tout voir » ouvre sa page.
        for i in range(NB_TYPES_ACCUEIL):
            self._rangee(f"type{i}", "", "Les plus connus du genre", "Tout voir",
                         lambda _=False, n=i: self._ouvrir_type(n))
        self._rangee("petits_prix", "Moins de " + region.prix(5.0, decimales=False),
                     "Des jeux connus a petit prix",
                     "Tout voir", lambda: self.voir_tout("5", "populaires"))
        self._rangee("notes", "Les mieux notes",
                     "Les avis les plus favorables parmi les jeux connus",
                     "Tout voir", lambda: self.voir_tout("tout", "note"))

        # -- invitation a la cle IsThereAnyDeal ----------------------------
        self.bandeau_cle = QFrame()
        self.bandeau_cle.setObjectName("Notice")
        bl = QHBoxLayout(self.bandeau_cle)
        bl.setContentsMargins(14, 10, 10, 10)
        texte = QLabel(
            "Comparaison limitee a Steam et GOG. Avec une cle gratuite "
            "IsThereAnyDeal, ORION compare plus de trente boutiques agreees "
            "(Fanatical, Humble, Green Man Gaming, Epic, Gamesplanet...).")
        texte.setWordWrap(True)
        texte.setObjectName("Dim")
        bl.addWidget(texte, 1)
        ajouter = QPushButton("Ajouter la cle")
        ajouter.clicked.connect(self.cle_demandee.emit)
        bl.addWidget(ajouter)
        self.bandeau_cle.hide()
        self.rangees.addSpacing(10)
        self.rangees.addWidget(self.bandeau_cle)

        # -- la page en cours : sur l'accueil, les offres du moment sous la
        # vitrine ; ailleurs, la liste seule ---------------------------------
        self.section_recherche = Section("Meilleures affaires")
        self.vitrine.addSpacing(6)
        self.vitrine.addWidget(self.section_recherche)
        # page d'un type : ses promotions et ses jeux gratuits d'abord
        self.sections_type: dict[str, tuple[Section, RangeeCartes]] = {}
        for cle, filtre in (("promo", "affaires"), ("gratuit", "gratuit")):
            section = Section("", "", "Tout voir")
            section.lien.clicked.connect(lambda _=False, f=filtre: self.voir_tout(f))
            rangee = RangeeCartes()
            rangee.cliquee.connect(self.ouvrir_fiche)
            rangee.menu.connect(self._menu_fiche)
            rangee.possede = lambda f: self._possedes.contient(f)
            self.vitrine.addWidget(section)
            self.vitrine.addWidget(rangee)
            section.hide()
            rangee.hide()
            self.sections_type[cle] = (section, rangee)
        self.titre_gros = QLabel("")
        self.titre_gros.setObjectName("PanelTitle")
        self.titre_gros.hide()
        self.vitrine.addWidget(self.titre_gros)
        # jeu introuvable : pourquoi, et des jeux du meme esprit (au-dessus
        # des resultats, bien a part)
        self._esprit: dict | None = None
        self.esprit_cadre = QFrame()
        self.esprit_cadre.setObjectName("Panel")
        cadre = QVBoxLayout(self.esprit_cadre)
        cadre.setContentsMargins(16, 12, 16, 12)
        cadre.setSpacing(8)
        ligne_esprit = QHBoxLayout()
        ligne_esprit.setSpacing(12)
        self.esprit_raison = QLabel("")
        self.esprit_raison.setWordWrap(True)
        self.esprit_raison.setStyleSheet("font-size:14px; font-weight:600;")
        ligne_esprit.addWidget(self.esprit_raison, 1)
        self.esprit_lien = QPushButton("")
        self.esprit_lien.setObjectName("Ghost")
        self.esprit_lien.setCursor(Qt.CursorShape.PointingHandCursor)
        self.esprit_lien.clicked.connect(self._ouvrir_esprit)
        ligne_esprit.addWidget(self.esprit_lien, 0, Qt.AlignmentFlag.AlignTop)
        cadre.addLayout(ligne_esprit)
        self.esprit_titre = QLabel("Dans le meme esprit")
        self.esprit_titre.setObjectName("PanelTitle")
        cadre.addWidget(self.esprit_titre)
        self.grille_esprit = GrilleCartes()
        self.grille_esprit.cliquee.connect(self.ouvrir_fiche)
        self.grille_esprit.menu.connect(self._menu_fiche)
        cadre.addWidget(self.grille_esprit)
        self.esprit_cadre.hide()
        self.vitrine.addWidget(self.esprit_cadre)

        self.grille = GrilleCartes()
        self.grille.cliquee.connect(self.ouvrir_fiche)
        self.grille.menu.connect(self._menu_fiche)
        self.vitrine.addWidget(self.grille)
        self.pages = Pagination()
        self.pages.choisie.connect(self.aller_page)
        self.pages.plus.connect(lambda: self._demander_suite(True))
        self.vitrine.addWidget(self.pages)
        # page d'un type : ce que la recherche trouve en dehors du type
        self.titre_ailleurs = QLabel("Dans toutes les boutiques")
        self.titre_ailleurs.setObjectName("PanelTitle")
        self.titre_ailleurs.hide()
        self.vitrine.addWidget(self.titre_ailleurs)
        self.grille_ailleurs = GrilleCartes()
        self.grille_ailleurs.cliquee.connect(self.ouvrir_fiche)
        self.grille_ailleurs.menu.connect(self._menu_fiche)
        self.grille_ailleurs.hide()
        self.vitrine.addWidget(self.grille_ailleurs)
        self.vide = QLabel("")
        self.vide.setObjectName("Dim")
        self.vide.setWordWrap(True)
        self.vide.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.vide.setContentsMargins(0, 30, 0, 30)
        self.vide.hide()
        self.vitrine.addWidget(self.vide)
        self.vitrine.addStretch(1)

        self._horloge = QTimer(self)
        self._horloge.timeout.connect(self._maj_etat)
        self._horloge.start(30_000)
        self._rendre(False)

    def _rangee(self, cle: str, titre: str, sous_titre: str = "", lien: str = "",
                action=None, classe=RangeeCartes) -> None:
        section = Section(titre, sous_titre, lien)
        if action is not None:
            section.lien.clicked.connect(action)
        rangee = classe()
        rangee.cliquee.connect(self.ouvrir_fiche)
        rangee.menu.connect(self._menu_fiche)
        rangee.possede = lambda f: self._possedes.contient(f)
        self.rangees.addSpacing(8)
        self.rangees.addWidget(section)
        self.rangees.addWidget(rangee)
        section.hide()
        rangee.hide()
        self.sections[cle] = (section, rangee)

    # ------------------------------------------------------------------
    # Donnees
    # ------------------------------------------------------------------
    @fige
    def set_catalogue(self, fiches: list[Fiche], actualise_le: float,
                      intervalle: int, comparateur: bool,
                      etat_sources: dict | None = None) -> None:
        self._catalogue = list(fiches)
        # le service dira de nouveau, a la prochaine demande, s'il reste des jeux
        self._suite_finie.clear()
        self._actualise_le = actualise_le
        self._intervalle = intervalle
        self.bandeau_cle.setVisible(not comparateur)
        self._sources = dict(etat_sources or {})
        ChargeurImages.instance().oublier_echecs()
        if self._auto:
            self._bibliotheque_auto()
        self._profil = None            # le catalogue complete les genres connus
        self._maj_types()
        self._maj_etat()
        self._vitrine()
        if self._resultats is None:
            self._rendre(False)

    @fige
    def set_bibliotheque(self, jeux, infos: dict | None = None) -> None:
        """Jeux possedes (bibliotheque et non installes) et leurs fiches
        `MarketInfo` deja en cache ({uid: info}) : base des suggestions.

        Peut etre appele a chaque rafraichissement de la bibliotheque : rien
        n'est recalcule si les jeux (et ce qui pese dans le profil) n'ont
        pas change."""
        jeux = list(jeux or [])
        infos = {k: v for k, v in (infos or {}).items() if v is not None}
        signature = (tuple(sorted(
            (j.uid, int(getattr(j, "total_play_seconds", 0) or 0) // 1800,
             bool(getattr(j, "favorite", False)), bool(getattr(j, "hidden", False)))
            for j in jeux)), tuple(sorted(infos)))
        if not self._auto and signature == self._signature:
            return
        self._signature = signature
        self._auto = False
        self._jeux = jeux
        self._infos = infos
        self._possedes = sugg.Possedes.depuis(self._jeux)
        self._profil = None
        self._vitrine()
        self._rendre(False)

    def _bibliotheque_auto(self) -> None:
        """Sans `set_bibliotheque`, lit la bibliotheque sur la fenetre
        principale (memes services, aucun appel reseau)."""
        fen = self.window()
        library = getattr(fen, "library", None)
        if fen is self or library is None:
            return
        try:
            jeux = list(library.games(include_hidden=True))
            possedes = getattr(fen, "possedes", None)
            if possedes is not None:
                jeux += list(possedes.tous())
            market = getattr(fen, "market", None)
            infos = {}
            if market is not None:
                for g in jeux:
                    info = market.en_cache(g, meme_perime=True)
                    if info is not None:
                        infos[g.uid] = info
            service = getattr(fen, "boutique", None)
            if service is not None and hasattr(service, "appids_bibliotheque"):
                service.appids_bibliotheque = {a for a in map(sugg.appid_steam, jeux) if a}
        except Exception:
            return
        self._jeux, self._infos = jeux, infos
        self._possedes = sugg.Possedes.depuis(jeux)
        self._profil = None

    def set_suivis(self, appids: set[str]) -> None:
        self._suivis = set(appids)
        self.une.set_suivis(self._suivis)

    @fige
    def set_resultats(self, terme: str, fiches: list[Fiche], muettes=()) -> None:
        """`muettes` : noms des boutiques qui n'ont pas repondu a cette
        recherche (Steam en maintenance...) ; la page le dit."""
        self.occupe(False)
        if terme != self.recherche.text().strip():
            return          # l'utilisateur a deja change de recherche
        self._resultats = fiches
        self._muettes = [str(m) for m in muettes or ()]
        self._terme = terme
        if not fiches and not self._muettes and (self._esprit or {}).get("terme") != terme:
            # rien nulle part : ORION cherche pourquoi, et des jeux du meme esprit
            self.esprit_demande.emit(terme, True)
        self._rendre(True)
        if self.panneau.isVisible():
            self._maj_panneau()

    def maj_fiche(self, fiche: Fiche) -> None:
        ligne = self._lignes.get(fiche.cle)
        if ligne is not None:
            ligne.fiche = fiche
            ligne.remplir_comparatif()

    def maj_images(self) -> None:
        for w in [self.une, self.grille, self.grille_ailleurs, self.grille_esprit] \
                + [r for _s, r in self.sections.values()] \
                + [r for _s, r in self.sections_type.values()]:
            w.update()
        for ligne in self._lignes.values():
            ligne.maj_image()

    def occupe(self, oui: bool, texte: str = "") -> None:
        self.progression.setVisible(oui)
        self.bouton_actualiser.setEnabled(not oui)
        if texte:
            self.etat.setText(texte)
        elif not oui:
            self._maj_etat()

    # ------------------------------------------------------------------
    # Vitrine
    # ------------------------------------------------------------------
    def _base(self) -> list[Fiche]:
        """Le catalogue montrable : avec une offre sure, applications masquees
        sauf demande."""
        fiches = [f for f in self._catalogue if f.meilleure]
        if not self.voir_applications.isChecked():
            fiches = [f for f in fiches if not f.est_application]
        return fiches

    def profil(self) -> sugg.Profil:
        if self._profil is None:
            self._profil = sugg.profil(self._jeux or [], self._infos, MEMO.tout(),
                                       self._catalogue)
        return self._profil

    @fige
    def _vitrine(self) -> None:
        base = self._base()
        payants = [f for f in base if not f.gratuit]
        une = sugg.a_la_une(payants, self._possedes, 6)
        self.une.set_fiches(une, self._suivis)
        # « Pour vous » note tout le catalogue contre le profil du joueur : a
        # part aussi (voir plus bas)
        if self.differer is not None:
            self.differer("boutique:pour_vous", lambda: self._pour_vous(payants, une))
        else:
            self._pour_vous(payants, une)

        # les rangees de la vitrine ne montrent pas les jeux deja possedes
        # (la grille de recherche les garde, marques « dans la bibliotheque »)
        neufs = [f for f in payants if not self._possedes.contient(f)]
        # une rangee de trois cartes ferait vide : le partenaire a sa rangee
        # quand il a de quoi la remplir
        partenaire = sugg.promos_partenaire(neufs)
        partenaire = partenaire if len(partenaire) >= 4 else []
        self._remplir("gamesplanet", partenaire)
        # pas deux fois les memes jeux d'une rangee a l'autre, tant qu'il en
        # reste assez pour remplir la suivante
        deja = {f.cle for f in partenaire}
        toutes = sugg.grosses_promos(neufs, 18 + len(deja))
        promos = [f for f in toutes if f.cle not in deja]
        promos = (promos if len(promos) >= 6 else toutes)[:18]
        self._remplir("promos", promos)
        deja |= {f.cle for f in promos}
        historique = sugg.plus_bas(neufs, 40)
        autres = [f for f in historique if f.cle not in deja]
        self._remplir("historique", (autres if len(autres) >= 6 else historique)[:18])
        gratuits = sorted((f for f in base if f.gratuit),
                          key=lambda f: (f.fin_promo or 1e12, -sugg.notoriete(f)))
        self._remplir("gratuits", gratuits)
        # le bas de l'accueil (une rangee par type, petits prix, mieux notes)
        # relit tout le catalogue : a part, pour ne pas allonger d'autant
        # l'arret de l'affichage (263 ms releves chez l'auteur le 7 octobre)
        if self.differer is not None:
            self.differer("boutique:abondance", lambda: self._abondance(neufs, base))
        else:
            self._abondance(neufs, base)

    @fige
    def _pour_vous(self, payants: list[Fiche], une: list[Fiche]) -> None:
        prof = self.profil()
        # un jeu deja a la une n'est pas repete dans « Pour vous », sauf si
        # le catalogue est trop maigre pour remplir la rangee autrement
        tous = sugg.suggerer(payants, prof, self._possedes, 16 + len(une))
        deja_une = {f.cle for f in une}
        autres = [s for s in tous if s.fiche.cle not in deja_une]
        self._suggestions = (autres if len(autres) >= 4 else tous)[:16]
        self._raisons = {s.fiche.cle: s.raison for s in self._suggestions}
        section, rangee = self.sections["pour_vous"]
        a_bibli = bool(self._jeux)
        if prof.nb_jeux:
            section.set_sous_titre(
                f"D'apres {prof.nb_jeux} jeu{'x' if prof.nb_jeux > 1 else ''} "
                "de votre bibliotheque")
        self._remplir("pour_vous", [s.fiche for s in self._suggestions], self._raisons,
                      montrer_vide=bool(payants))
        if not a_bibli:
            section.set_sous_titre("Choisis d'apres les jeux de votre bibliotheque")
        self.indice_pour_vous.setText(INDICE_POUR_VOUS if a_bibli else INDICE_SANS_JEUX)
        self.indice_pour_vous.setVisible(bool(payants) and not self._suggestions)

    @fige
    def _abondance(self, neufs: list[Fiche], base: list[Fiche] | None = None) -> None:
        """Bas de l'accueil : une rangee par type de jeu (ceux que le joueur
        possede le plus d'abord), les petits prix, les mieux notes."""
        from ...i18n import t
        par_type: dict[str, list[Fiche]] = {}
        possedes: dict[str, int] = {}
        for f in (base if base is not None else self._base()):
            a_lui = self._possedes.contient(f)
            for cle in genres.types_de(getattr(f, "etiquettes", []) or []):
                if cle in TYPES_LARGES:
                    continue
                possedes[cle] = possedes.get(cle, 0) + bool(a_lui)
                if not a_lui:
                    par_type.setdefault(cle, []).append(f)
        choisis = sorted((c for c, fs in par_type.items() if len(fs) >= 6),
                         key=lambda c: (-possedes.get(c, 0), -len(par_type[c]), c))
        self._types_accueil = choisis[:NB_TYPES_ACCUEIL]
        deja: set[str] = set()
        for i in range(NB_TYPES_ACCUEIL):
            cle = self._types_accueil[i] if i < len(self._types_accueil) else ""
            if cle:
                self.sections[f"type{i}"][0].titre.setText(t(genres.LIBELLES[cle]))
            connus = sorted(par_type.get(cle, []), key=lambda f: -sugg.notoriete(f))
            # un jeu ne revient pas d'une rangee de type a la suivante, tant
            # qu'il en reste assez pour remplir celle-ci
            neufs_ici = [f for f in connus if f.cle not in deja]
            choix = (neufs_ici if len(neufs_ici) >= 6 else connus)[:16]
            deja |= {f.cle for f in choix}
            self._remplir(f"type{i}", choix)
        payants = [f for f in neufs if f.meilleure and f.meilleure.prix > 0]
        petits = sorted((f for f in payants if f.meilleure.prix < 5),
                        key=lambda f: -sugg.notoriete(f))[:18]
        self._remplir("petits_prix", petits if len(petits) >= 6 else [])
        # les mieux notes parmi les plus connus : une note sur dix avis ne dit rien
        connus = sorted(neufs, key=lambda f: -sugg.notoriete(f))[:max(40, len(neufs) // 3)]
        notes = sorted((f for f in connus if f.note > 0), key=lambda f: -f.note)[:18]
        self._remplir("notes", notes if len(notes) >= 6 else [])

    def _ouvrir_type(self, rang: int) -> None:
        if rang < len(self._types_accueil):
            self.choisir_type(self._types_accueil[rang])

    def _remplir(self, cle: str, fiches, raisons: dict | None = None,
                 montrer_vide: bool = False) -> None:
        section, rangee = self.sections[cle]
        rangee.set_fiches(fiches, raisons)
        section.setVisible(bool(fiches) or montrer_vide)
        rangee.setVisible(bool(fiches))

    def suggestions(self) -> list[sugg.Suggestion]:
        return list(self._suggestions)

    # ------------------------------------------------------------------
    # Interaction
    # ------------------------------------------------------------------
    def ouvrir_fiche(self, fiche: Fiche) -> FicheDialogue:
        self._noter_vu(fiche)
        dlg = FicheDialogue(fiche, self._suivis, self._raisons.get(fiche.cle, ""), self)
        dlg.ligne.comparer_demande.connect(self.comparer_demande.emit)
        dlg.ligne.suivre_demande.connect(self._suivi)
        dlg.ligne.ne_plus_suivre_demande.connect(self._plus_suivi)
        self._lignes[fiche.cle] = dlg.ligne
        dlg.finished.connect(lambda _r, c=fiche.cle, l=dlg.ligne:
                             self._lignes.get(c) is l and self._lignes.pop(c, None))
        # le comparatif complet est lance des l'ouverture, et il reste
        # ouvert : dans cette fenetre le bouton ne servirait qu'a le refermer
        # (les prix « disparaissaient » au clic)
        dlg.ligne.bouton_comparer.setChecked(True)
        dlg.ligne.bouton_comparer.hide()
        # deja dans la bibliotheque (10 octobre, demande de l'auteur) : un lien
        # vers sa fiche, au lieu de seulement l'etiquette sur la carte
        if self._possedes.contient(fiche):
            voir = QPushButton("Voir dans ma bibliotheque")
            voir.setObjectName("Primary")
            voir.setCursor(Qt.CursorShape.PointingHandCursor)

            def ouvrir_bibliotheque(_=False, f=fiche, d=dlg) -> None:
                d.accept()
                self.bibliotheque_demandee.emit(f.steam_appid or "", f.titre)
            voir.clicked.connect(ouvrir_bibliotheque)
            dlg.bas.insertWidget(0, voir)
        dlg.open()
        return dlg

    def _voir_offre(self, fiche: Fiche) -> None:
        if fiche.meilleure and fiche.meilleure.url:
            ouvrir_lien(fiche.meilleure.url)

    def _suivre_fiche(self, fiche: Fiche) -> None:
        if fiche.steam_appid:
            self._suivi(fiche.steam_appid, fiche.titre)

    def _ne_plus_suivre_fiche(self, fiche: Fiche) -> None:
        if fiche.steam_appid:
            self._plus_suivi(fiche.steam_appid, fiche.titre)

    def _suivi(self, appid: str, titre: str) -> None:
        self._suivis.add(appid)
        self.une.set_suivis(self._suivis)
        self.suivre_demande.emit(appid, titre)

    def _plus_suivi(self, appid: str, titre: str) -> None:
        self._suivis.discard(appid)
        self.une.set_suivis(self._suivis)
        self.ne_plus_suivre_demande.emit(appid, titre)

    def _menu_fiche(self, fiche: Fiche, position) -> None:
        menu = QMenu(self)
        m = fiche.meilleure
        if m is not None and m.url:
            menu.addAction(f"Voir l'offre chez {m.boutique}  ({euros(m.prix)})",
                           lambda: ouvrir_lien(m.url))
        menu.addAction("Comparer les boutiques", lambda: self.ouvrir_fiche(fiche))
        offre_gp = offre_gamesplanet(fiche)
        lien_gp = offre_gp.url if offre_gp else lien_gamesplanet(fiche.titre, fiche.steam_appid)
        if offre_gp and not (m is not None and m is offre_gp):
            menu.addAction(f"Gamesplanet  ·  {euros(offre_gp.prix)}", lambda: ouvrir_lien(lien_gp))
        elif lien_gp and not offre_gp:
            menu.addAction("Chercher sur Gamesplanet (boutique officielle)",
                           lambda: ouvrir_lien(lien_gp))
        for site, url in liens_revendeurs(fiche.titre):
            menu.addAction(f"Cle Steam chez {site.nom}", lambda u=url: ouvrir_lien(u))
        if fiche.steam_appid and fiche.steam_appid not in self._suivis:
            menu.addAction("Suivre le prix", lambda: self._suivre_fiche(fiche))
        elif fiche.steam_appid:
            menu.addAction("Ne plus suivre le prix", lambda: self._ne_plus_suivre_fiche(fiche))
        menu.popup(position)

    def voir_tout(self, filtre: str, tri: str = "") -> None:
        """« Tout voir » d'une rangee : sa liste occupe la page, sans rien
        faire defiler. Sur la page d'un type, on reste dans ce type."""
        self._vider_recherche()
        self._liste = True
        self._cocher(filtre)
        self._trier(tri or "auto")
        self._rendre(True)


    def en_liste(self) -> bool:
        """Une liste occupe la page : type de jeu, recherche, « Tout voir »
        ou filtre choisi. La vitrine d'accueil s'efface alors."""
        return bool(self._genre or self._liste or self.recherche.text().strip())

    def accueil(self) -> None:
        """Retour a la vitrine : ni type, ni recherche, ni filtre."""
        self._genre, self._liste = "", False
        self._vider_recherche()
        self._cocher("affaires")
        self._trier("auto")
        b = self.boutons_types.get("")
        if b is not None:
            b.setChecked(True)
        self._rendre(True)

    # -- la suite du magasin ------------------------------------------------
    def _cle_suite(self):
        """Le type dont la page en cours peut recevoir la suite du magasin
        (« » : tout le magasin), ou None : accueil, recherche par nom."""
        if not self.en_liste() or self.recherche.text().strip():
            return None
        if not self._genre and self._filtre() in ("affaires", "historique"):
            return "promos"         # ces listes ne montrent que des promotions
        return self._genre or ""

    def _demander_suite(self, voulu: bool = False) -> None:
        """Demande les jeux suivants de la page en cours. `voulu` : le joueur
        a clique « Plus de jeux » ; sinon la demande part d'elle-meme, une
        seule fois par page atteinte (jamais de demandes en chaine)."""
        cle = self._cle_suite()
        if cle is None or cle in self._suite_en_cours or cle in self._suite_finie:
            return
        if not voulu:
            ici = (cle, self._filtre(), self.tri_applique(), self._page)
            if self._suite_auto == ici:
                return
            self._suite_auto = ici
        if voulu:
            self._suite_voulue.add(cle)
        self._suite_en_cours.add(cle)
        self.suite_demandee.emit(cle)
        self._maj_pagination()

    @fige
    def suite_recue(self, cle: str, nouvelles: list[Fiche], encore: bool) -> None:
        """Les jeux suivants sont arrives (ou pas : Steam muet, bout du
        magasin). Les pages deja vues ne bougent pas : les jeux nouveaux se
        rangent a la suite (voir `_lots`). Si le joueur a clique « Plus de
        jeux », ORION l'emmene a la premiere page qui en montre ; si la suite
        est partie d'elle-meme, la page garde sa place.

        Vu dans la version compilee du 7 octobre : apres « Plus de jeux », la
        page 1 se recomposait sous les yeux du joueur (tri par notoriete sur
        l'ensemble) et rien ne disait ou etaient les jeux arrives."""
        voulue = cle in self._suite_voulue
        self._suite_voulue.discard(cle)
        self._suite_en_cours.discard(cle)
        if not encore:
            self._suite_finie.add(cle)
        connus = {f.cle for f in self._catalogue}
        ajout = [f for f in nouvelles or [] if f.cle not in connus]
        if not ajout:
            self._maj_pagination()
            return
        for f in ajout:
            self._lots.setdefault(f.cle, self._lot_suivant)
        self._lot_suivant += 1
        self._catalogue = self._catalogue + ajout
        if voulue and cle == self._cle_suite():
            neuves = {f.cle for f in ajout}
            rang = next((i for i, f in enumerate(self.visibles()) if f.cle in neuves), None)
            if rang is not None and rang // PAR_PAGE != self._page:
                self.aller_page(rang // PAR_PAGE)
                return
        self._rendre(False)

    # -- jeu introuvable : « dans le meme esprit » --------------------------
    @fige
    def set_esprit(self, resultat: dict | None) -> None:
        """Pourquoi le jeu cherche n'est pas la, et des jeux du meme esprit
        (`BoutiqueService.dans_l_esprit`). Ignore si le joueur cherche deja
        autre chose."""
        if resultat is not None and resultat.get("terme") != self.recherche.text().strip():
            return
        self._esprit = resultat
        self._maj_esprit()

    def _ouvrir_esprit(self) -> None:
        ou = (self._esprit or {}).get("ou")
        if ou:
            ouvrir_lien(ou[1])

    def _maj_esprit(self) -> None:
        from ...i18n import t
        e = self._esprit
        texte = self.recherche.text().strip()
        montrer = bool(e and texte and e.get("terme") == texte and not self._genre)
        self.esprit_cadre.setVisible(montrer)
        if not montrer:
            return
        self.esprit_raison.setText(t(e.get("raison") or ""))
        ou = e.get("ou")
        self.esprit_lien.setVisible(bool(ou))
        if ou:
            self.esprit_lien.setText(t(ou[0]))
            self.esprit_lien.setToolTip(ou[1])
        fiches = list(e.get("fiches") or [])
        self.esprit_titre.setVisible(bool(fiches))
        self.grille_esprit.setVisible(bool(fiches))
        self.grille_esprit.possede = self._possedes.contient
        self.grille_esprit.set_fiches(fiches, self._raisons)
        if fiches:
            self._demander_cles(fiches)

    def _demander_cles(self, fiches: list[Fiche]) -> None:
        """Demande, une fois par jeu et par session, la cle verifiee des
        revendeurs pour les cartes affichees (en tache de fond)."""
        nouvelles = [f for f in fiches if f.steam_appid and not f.gratuit
                     and f.cle not in self._cles_vues]
        if nouvelles:
            self._cles_vues.update(f.cle for f in nouvelles)
            self.cles_demandees.emit(nouvelles)

    def cles_recues(self) -> None:
        """Les cles verifiees sont posees sur les fiches : les cartes se redessinent."""
        self.grille.update()
        self.grille_ailleurs.update()
        self.grille_esprit.update()

    def _maj_pagination(self) -> None:
        cle = self._cle_suite()
        encore = cle is not None and cle not in self._suite_finie
        self.pages.regler(self._page, getattr(self, "_nb_pages", 1), encore,
                          cle in self._suite_en_cours)

    def aller_page(self, page: int) -> None:
        self._page = max(0, int(page))
        self._rendre(False)
        self.defile.aller(self.grille.y() - 10 if self.en_liste() else self.section_recherche.y() - 8)

    def _vider_recherche(self) -> None:
        self._resultats, self._terme, self._demande = None, "", ""
        self._texte_avant = ""
        self._delai_partout.stop()
        if self.recherche.text():
            self.recherche.blockSignals(True)
            self.recherche.clear()
            self.recherche.blockSignals(False)

    def _cocher(self, filtre: str) -> None:
        for b in self.groupe.buttons():
            if b.property("cle") == filtre:
                b.setChecked(True)

    def _trier(self, tri: str) -> None:
        i = self.tri.findData(tri)
        if i >= 0 and i != self.tri.currentIndex():
            self.tri.blockSignals(True)
            self.tri.setCurrentIndex(i)
            self.tri.blockSignals(False)

    def _filtre_choisi(self, _bouton=None) -> None:
        """Un filtre choisi sur l'accueil ouvre sa liste ; ailleurs il
        s'applique a la page en cours."""
        if not self.en_liste():
            self._liste = True
        self._rendre(True)

    def _politique(self) -> None:
        box = QMessageBox(self)
        box.setWindowTitle("Boutiques retenues")
        box.setText(POLITIQUE)
        box.exec()

    def _saisie(self, texte: str) -> None:
        propre = texte.strip()
        ailleurs = bool(self._genre or self._liste)
        if not propre:
            self._resultats, self._terme, self._demande = None, "", ""
            self._delai_partout.stop()
            if not ailleurs:
                self._cocher("affaires")       # retour a l'accueil
        else:
            # une recherche lancee de l'accueil montre tout ce qu'elle trouve,
            # pas seulement les promotions
            if not ailleurs and not self._texte_avant and self._filtre() == "affaires":
                self._cocher("tout")
            if len(propre) >= 3:
                self._delai_partout.start()
            else:
                self._delai_partout.stop()
        self._texte_avant = propre
        self._delai_saisie.start()
        self._delai_panneau.start()

    def _devancer(self) -> None:
        """La saisie s'est posee : la recherche dans toutes les boutiques
        part sans attendre Entree."""
        terme = self.recherche.text().strip()
        if len(terme) < 3 or terme in (self._terme, self._demande):
            return
        self._demande = terme
        self.progression.show()
        self.recherche_demandee.emit(terme)

    def _applications_changees(self, oui: bool) -> None:
        CONFIG.set("boutique.afficher_applications", bool(oui))
        self._maj_types()
        self._vitrine()
        self._rendre(True)

    def integrer(self) -> None:
        """Vue placee sous l'en-tete commun de la page Boutique : pas de
        second titre, marges alignees sur celles de l'en-tete."""
        self.titre_page.hide()
        self._racine.setContentsMargins(28, 8, 28, 0)

    def _chercher(self) -> None:
        terme = self.recherche.text().strip()
        if len(terme) < 2:
            return
        self._delai_partout.stop()
        if terme == self._terme and self._resultats is not None:
            self._rendre(True)          # deja la : la recherche a ete devancee
            return
        self.occupe(True, f"Recherche de « {terme} » sur toutes les boutiques...")
        if terme != self._demande:
            self._demande = terme
            self.recherche_demandee.emit(terme)

    def _filtre(self) -> str:
        b = self.groupe.checkedButton()
        return b.property("cle") if b else "tout"

    # -- types de jeux (colonne de gauche) ------------------------------
    def _jeux_du_catalogue(self) -> list[Fiche]:
        fiches = [f for f in self._catalogue if f.meilleure]
        if not self.voir_applications.isChecked():
            fiches = [f for f in fiches if not f.est_application]
        return fiches

    @fige
    def _maj_types(self) -> None:
        """Reconstruit la colonne : « Tous », puis les types de jeu. Sans
        nombre : la page d'un type n'a pas de fin, la suite du magasin vient
        a la demande (un nombre ne dirait que ce qui est deja charge)."""
        from ...i18n import t
        from ...plugins.boutique.steam import ETIQUETTES_TYPES
        # un type que le magasin sait lister a toujours son bouton ; le
        # catalogue n'est compte que pour les autres, s'il y en a
        a_compter = [cle for cle, _l, _m in genres.TYPES if cle not in ETIQUETTES_TYPES]
        nombres = genres.compter(self._jeux_du_catalogue()) if a_compter else {}
        presents = [(cle, libelle) for cle, libelle, _ in genres.TYPES
                    if nombres.get(cle) or cle in ETIQUETTES_TYPES]
        self.colonne_types.setVisible(bool(presents))
        if self._genre and self._genre not in dict(presents):
            self._genre = ""
        # memes boutons qu'avant : rien a reconstruire (la colonne etait
        # detruite et refaite a chaque actualisation des prix)
        etat = (tuple(presents), t("Tous"))
        if etat == getattr(self, "_types_presents", None) and self.boutons_types:
            b = self.boutons_types.get(self._genre)
            if b is not None:
                b.setChecked(True)
            return
        self._types_presents = etat
        clear_layout(self._types_lay)
        for b in list(self.groupe_types.buttons()):
            self.groupe_types.removeButton(b)
        self.boutons_types = {}
        titre = QLabel("TYPES DE JEUX")
        titre.setObjectName("Faint")
        self._types_lay.addWidget(titre)
        for cle, libelle in [("", "Tous")] + presents:
            b = QPushButton(t(libelle))
            b.setObjectName("Chip")
            b.setCheckable(True)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.setChecked(cle == self._genre)
            b.clicked.connect(lambda _=False, c=cle: self.choisir_type(c))
            self.groupe_types.addButton(b)
            self._types_lay.addWidget(b)
            self.boutons_types[cle] = b
        self._types_lay.addStretch(1)

    def choisir_type(self, cle: str) -> None:
        """Ouvre la page d'un type de jeu : ses promotions, ses gratuits,
        puis tous ses jeux, les plus connus d'abord."""
        cle = cle if cle in genres.LIBELLES else ""
        if not cle:
            self.accueil()
            return
        self._genre, self._liste = cle, False
        b = self.boutons_types.get(cle)
        if b is not None:
            b.setChecked(True)
        self._vider_recherche()
        self._cocher("tout")
        self._trier("auto")
        self._rendre(True)

    # -- la page en cours : portee, recherche, filtre, tri ---------------
    def _masquer_applications(self, fiches: list[Fiche]) -> list[Fiche]:
        self._apps_masquees = 0
        if self.voir_applications.isChecked():
            return fiches
        jeux = [f for f in fiches if not f.est_application]
        self._apps_masquees = len(fiches) - len(jeux)
        return jeux

    def _partout(self) -> bool:
        """La recherche dans toutes les boutiques a repondu pour ce texte."""
        texte = self.recherche.text().strip()
        return bool(texte) and self._resultats is not None and texte == self._terme

    def _candidats(self) -> list[Fiche]:
        """Les jeux de la page en cours, avant filtre et tri : le type choisi
        ou tout le catalogue, reduits au texte saisi (ordre de pertinence)."""
        if self._partout() and not self._genre:
            return self._masquer_applications(list(self._resultats))
        fiches = [f for f in self._catalogue if f.meilleure]
        if self._genre:
            fiches = [f for f in fiches if genres.du_type(f, self._genre)]
        fiches = self._masquer_applications(fiches)
        texte = self.recherche.text().strip()
        if texte:
            # memes lectures que la recherche partout : « cod bo3 » filtre aussi
            fiches = classer_variantes(variantes(texte), fiches, cle=lambda f: f.titre)
        return fiches

    def _filtrer(self, fiches: list[Fiche], filtre: str) -> list[Fiche]:
        if filtre == "gratuit":
            return [f for f in fiches if f.gratuit]
        if not self._genre and not self.recherche.text().strip():
            # accueil et listes : les gratuits ont leur onglet
            fiches = [f for f in fiches if not f.gratuit]
        if filtre == "affaires":
            return [f for f in fiches if f.remise >= 20 and not f.gratuit]
        if filtre == "gamesplanet":
            return [f for f in fiches if sugg.promo_partenaire(f)]
        if filtre == "historique":
            return [f for f in fiches if f.au_plus_bas]
        if filtre in ("5", "15"):
            plafond = float(filtre)
            return [f for f in fiches if f.meilleure and 0 < f.meilleure.prix < plafond]
        return list(fiches)

    def tri_applique(self) -> str:
        """Le tri choisi, ou celui qui convient a la page (« Recommande »)."""
        tri = self.tri.currentData() or "auto"
        if tri != "auto":
            return tri
        if self.recherche.text().strip():
            return "pertinence"
        return "remise" if self._filtre() in ("affaires", "gamesplanet") else "populaires"

    def _ordonner(self, fiches: list[Fiche]) -> list[Fiche]:
        tri = self.tri_applique()
        if tri == "pertinence":
            return fiches
        if tri == "hasard":            # meme tirage tant qu'ORION reste ouvert
            melange = sorted(fiches, key=lambda f: f.titre.lower())
            random.Random(genres.GRAINE).shuffle(melange)
            return melange
        prix = lambda f: f.meilleure.prix if f.meilleure else 1e9      # noqa: E731
        cles = {
            "remise": lambda f: (-(100 if f.gratuit else f.remise), -f.economie),
            "prix": prix,
            "prix_desc": lambda f: -(f.meilleure.prix if f.meilleure else 0),
            "economie": lambda f: -f.economie,
            "note": lambda f: -f.note,
            # par arrivee, puis par notoriete : voir `_lots`
            "populaires": lambda f: (self._lots.get(f.cle, 0), -sugg.notoriete(f)),
            "fin": lambda f: (f.fin_promo or 1e12),
            "titre": lambda f: f.titre.lower(),
        }
        return sorted(fiches, key=cles.get(tri, cles["populaires"]))

    @fige
    def visibles(self) -> list[Fiche]:
        """Tout ce que montre la page en cours (toutes pages confondues) :
        recherche, filtre et tri appliques."""
        return self._ordonner(self._filtrer(self._candidats(), self._filtre()))

    @fige
    def ailleurs(self) -> list[Fiche]:
        """Sur la page d'un type : ce que la recherche dans toutes les
        boutiques trouve en dehors de ce type."""
        if not (self._genre and self._partout()):
            return []
        ici = {f.cle for f in self._candidats()}
        masquees = self._apps_masquees
        dehors = self._masquer_applications([f for f in self._resultats if f.cle not in ici])
        self._apps_masquees = masquees
        return self._filtrer(dehors, self._filtre())

    @fige
    def _maj_puces(self, candidats: list[Fiche]) -> None:
        """Un filtre qui ne garderait rien dans la page en cours s'efface.
        Aucun nombre affiche : la page grandit avec la suite du magasin."""
        from ...i18n import t
        accueil = not self._genre and not self.recherche.text().strip()
        for b in self.groupe.buttons():
            cle = b.property("cle")
            n = len(self._filtrer(candidats, cle))
            # une rangee de trois promos ferait vide : meme regle pour le filtre
            utile = n >= (4 if cle == "gamesplanet" else 1)
            if cle == "gratuit" and accueil:
                utile = False                  # l'onglet « Gratuits » est la pour ca
            b.setVisible(cle == "tout" or b.isChecked() or utile)
            b.setText(t(str(b.property("libelle"))))

    def _rangees_du_type(self, nom: str, candidats: list[Fiche], montrer: bool) -> None:
        """En tete de la page d'un type : ses promotions et ses gratuits."""
        from ...i18n import t
        lots = {"promo": [], "gratuit": []}
        if montrer:
            lots["promo"] = sorted((f for f in candidats if f.remise >= 20 and not f.gratuit),
                                   key=lambda f: (-f.remise, -sugg.notoriete(f)))[:18]
            lots["gratuit"] = sorted((f for f in candidats if f.gratuit),
                                     key=lambda f: -sugg.notoriete(f))[:18]
        titres = {"promo": "En promo", "gratuit": "Gratuits"}
        montrees = 0
        for cle, (section, rangee) in self.sections_type.items():
            fiches = lots[cle] if len(lots[cle]) >= 4 else []
            rangee.possede = self._possedes.contient
            rangee.set_fiches(fiches, self._raisons)
            section.titre.setText(f"{t(titres[cle])}  ·  {nom}")
            section.setVisible(bool(fiches))
            rangee.setVisible(bool(fiches))
            montrees += bool(fiches)
        self.titre_gros.setText(f"{nom}  ·  " + t("tous les jeux"))
        self.titre_gros.setVisible(bool(montrees))

    @fige
    def _rendre(self, depuis_debut: bool) -> None:
        from ...i18n import t
        if depuis_debut:
            self._page = 0
        liste = self.en_liste()
        texte = self.recherche.text().strip()
        nom = t(genres.LIBELLES[self._genre]) if self._genre else ""
        self.bloc_accueil.setVisible(not liste)
        self.retour.setVisible(liste)
        self.recherche.setPlaceholderText(t("Chercher dans") + f" {nom}..." if nom else INVITE)

        candidats = self._candidats()
        self._maj_puces(candidats)
        fiches = self._ordonner(self._filtrer(candidats, self._filtre()))
        pages = max(1, -(-len(fiches) // PAR_PAGE))
        self._page = max(0, min(self._page, pages - 1))
        debut = self._page * PAR_PAGE
        self.grille.possede = self.grille_ailleurs.possede = self._possedes.contient
        self.grille.set_fiches(fiches[debut:debut + PAR_PAGE], self._raisons)
        self._nb_pages = pages
        self._maj_pagination()
        self._demander_cles(fiches[debut:debut + PAR_PAGE])
        # au bout de ce qui est charge : la suite du magasin est demandee
        if self._page >= pages - 1:
            self._demander_suite()
        dehors = self.ailleurs()[:PAR_PAGE]
        self.grille_ailleurs.set_fiches(dehors, self._raisons)
        self.titre_ailleurs.setVisible(bool(dehors))
        self.grille_ailleurs.setVisible(bool(dehors))
        self._maj_esprit()
        # la raison donnee par « dans le meme esprit » remplace « aucune boutique... »
        self.vide.setVisible(not fiches and not dehors and self.esprit_cadre.isHidden())
        if not fiches:
            self.vide.setText(self._message_vide())

        # ou l'on est : « FPS · Moins de 15 € », « "doom" », « Promos Gamesplanet »
        filtre = self._filtre()
        bouton = self.groupe.checkedButton()
        libelle = t(str(bouton.property("libelle"))) if bouton else ""
        fil = [nom] if nom else []
        if texte:
            fil.append(f"« {texte} »")
        if filtre != "tout" or not fil:
            fil.append(libelle)
        self.fil.setText("  ·  ".join(fil))
        self.fil.setVisible(liste)
        self.section_recherche.titre.setText(libelle)
        self.section_recherche.setVisible(not liste and bool(fiches))
        self._rangees_du_type(nom, candidats, bool(self._genre) and not texte
                              and filtre == "tout" and self._page == 0
                              and self.tri_applique() == "populaires")

        n = len(fiches)
        if self._genre and not texte:
            resume = nom
        elif self._partout() and not self._genre:
            resume = (f"{n} jeu{'x' if n > 1 else ''} trouve"
                      f"{'s' if n > 1 else ''} pour « {self._terme} »")
        else:
            n_boutiques = len({o.boutique for f in self._catalogue for o in f.offres_sures})
            resume = (f"Prix releves dans {n_boutiques} "
                      f"boutique{'s' if n_boutiques > 1 else ''} "
                      f"sure{'s' if n_boutiques > 1 else ''}")
        if self._apps_masquees:
            resume += f"  ·  {self._apps_masquees} application(s) masquee(s)"
        if self._partout() and not self._genre and getattr(self, "_muettes", None):
            # resultats partiels : une boutique n'a pas repondu (maintenance...)
            resume += f"  ·  sans reponse : {', '.join(self._muettes)}"
        self.resume.setText(resume)
        if depuis_debut and liste:
            self.defile.aller(0)

    def _message_vide(self) -> str:
        texte = self.recherche.text().strip()
        if not self._catalogue and not texte:
            return ("La boutique se remplit a la premiere actualisation. "
                    "Verifiez la connexion si rien n'apparait.")
        if texte and self._resultats is None:
            return (f"Rien de « {texte} » dans la vitrine du moment. Appuyez "
                    "sur Entree ou « Chercher partout » pour interroger toutes "
                    "les boutiques.")
        if texte and getattr(self, "_muettes", None):
            # dire « personne ne le vend » serait faux : on n'a pas pu demander
            return (f"{', '.join(self._muettes)} : pas de reponse pour le moment (maintenance "
                    "ou coupure). Relancez la recherche dans quelques minutes.")
        if texte:
            return (f"Aucune boutique sure ne vend « {texte} » en ce moment. Essayez le nom "
                    "complet du jeu : certains ne sont vendus que par leur editeur "
                    "(Battle.net, EA app, Ubisoft Connect) ou ont quitte la vente.")
        return "Aucun jeu ne correspond a ce filtre pour le moment."

    def _maj_etat(self) -> None:
        if not self._actualise_le:
            self.etat.setText("Jamais actualisee")
            return
        depuis = int((time.time() - self._actualise_le) // 60)
        reste = max(0, self._intervalle - depuis)
        quand = "a l'instant" if depuis < 1 else f"il y a {depuis} min"
        if depuis > self._intervalle + 5:
            # les dernieres tentatives ont echoue : on le dit
            self.etat.setText(f"Prix du {time.strftime('%d/%m a %H:%M', time.localtime(self._actualise_le))}"
                              "  ·  boutiques injoignables, nouvel essai bientot")
            return
        self.etat.setText(f"Actualisee {quand}  ·  prochaine dans {reste} min")
        sources = getattr(self, "_sources", {})
        if sources:
            self.etat.setToolTip("\n".join(f"{k} : {v}" for k, v in sources.items()))

    # -- la liste sous la barre de recherche ------------------------------
    def eventFilter(self, objet, event) -> bool:      # noqa: N802
        if objet is self.recherche:
            genre = event.type()
            if genre == QEvent.Type.FocusIn:
                self._maj_panneau()
            elif genre == QEvent.Type.FocusOut:
                plus_tard(self, 160, self._fermer_panneau_si_perdu)
            elif genre == QEvent.Type.KeyPress:
                touche = event.key()
                if touche in (Qt.Key.Key_Down, Qt.Key.Key_Up):
                    if not self.panneau.isVisible():
                        self._maj_panneau()
                    self.panneau.deplacer(1 if touche == Qt.Key.Key_Down else -1)
                    return True
                if touche == Qt.Key.Key_Escape and self.panneau.isVisible():
                    self.panneau.hide()
                    return True
                if touche in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
                    if self.panneau.isVisible() and self.panneau.activer():
                        return True
                    self.panneau.hide()        # Entree : la page des resultats
        return super().eventFilter(objet, event)

    def _fermer_panneau_si_perdu(self) -> None:
        if not self.recherche.hasFocus() and not self.panneau.underMouse():
            self.panneau.hide()

    def _vus(self) -> list[Fiche]:
        """Fiches ouvertes recemment (les plus recentes d'abord), encore au catalogue."""
        connues = {f.cle: f for f in (self._resultats or [])}
        connues.update({f.cle: f for f in self._catalogue})
        out = []
        for c in CONFIG.get("boutique.vus_recemment") or []:
            f = connues.get(c)
            if f is not None and f.meilleure:
                out.append(f)
        return out

    def _noter_vu(self, fiche: Fiche) -> None:
        vus = [c for c in (CONFIG.get("boutique.vus_recemment") or []) if c != fiche.cle]
        CONFIG.set("boutique.vus_recemment", ([fiche.cle] + vus)[:12])

    def _types_trouves(self, texte: str) -> list[tuple[str, str]]:
        from ...i18n import t
        if len(normaliser(texte)) < 2:
            return []
        presents = dict(getattr(self, "_types_presents", ((), ""))[0] or ())
        out = []
        for cle, libelle, _m in genres.TYPES:
            if presents and cle not in presents:
                continue
            nom = t(libelle)
            if normaliser(texte) in normaliser(nom) or correspond(texte, nom):
                out.append((cle, nom))
        return out

    @fige
    def _maj_panneau(self) -> None:
        """Remplit et pose la liste sous la barre (champ ayant le clavier)."""
        if not self.recherche.hasFocus() or not self.isVisible():
            return
        hote = self.recherche.window()
        if self.panneau.parentWidget() is not hote:
            self.panneau.setParent(hote)
        texte = self.recherche.text().strip()
        if not texte:
            vus = self._vus()
            if len(vus) >= 2:
                self.panneau.remplir("", tuiles=vus, titre_tuiles="Vus recemment")
            else:
                payants = [f for f in self._base() if not f.gratuit]
                une = sugg.a_la_une(payants, self._possedes, 6)
                if not une:
                    self.panneau.hide()
                    return
                self.panneau.remplir("", tuiles=une, titre_tuiles="Tendances")
        else:
            base = self._base()
            if self._partout():
                vus_cles = {f.cle for f in self._resultats}
                base = list(self._resultats) + [f for f in base if f.cle not in vus_cles]
            trouves = classer_variantes(variantes(texte), base, cle=lambda f: f.titre)
            en_cours = bool(self._demande == texte and not self._partout())
            self.panneau.remplir(texte, jeux=trouves, types=self._types_trouves(texte),
                                 total=len(trouves), en_cours=en_cours)
        self.panneau.placer(self.recherche)
        self.panneau.show()
        self.panneau.raise_()

    def _panneau_fiche(self, fiche: Fiche) -> None:
        self.panneau.hide()
        self.ouvrir_fiche(fiche)

    def _panneau_type(self, cle: str) -> None:
        self.panneau.hide()
        self.choisir_type(cle)

    def _panneau_tout(self) -> None:
        self.panneau.hide()
        self._chercher()
        self._rendre(True)

    def resizeEvent(self, event) -> None:            # noqa: N802
        super().resizeEvent(event)
        if self.panneau.isVisible():
            self.panneau.placer(self.recherche)

    def hideEvent(self, event) -> None:              # noqa: N802
        self.panneau.hide()
        super().hideEvent(event)

    def showEvent(self, event) -> None:
        # la bibliotheque a pu changer (analyse, installation) depuis
        if self._auto and self._catalogue:
            avant = len(self._jeux or [])
            self._bibliotheque_auto()
            if len(self._jeux or []) != avant:
                self._vitrine()
        super().showEvent(event)
