"""Reconnaitre qu'un meme jeu a ete vu par deux sources.

Un jeu Steam est aussi declare dans « Programmes et fonctionnalites »
(cle « Steam App 1091500 »), un jeu GOG sous « 1207658924_is1 », un jeu Ubisoft
sous « Uplay Install 5271 ». Le scanner du registre et le scanner du dossier
de jeux le retrouvent donc une seconde fois. Tant que les deux fiches ne sont
pas reconnues comme un seul jeu, la bibliotheque l'affiche en double.

Quatre indices, du plus sur au moins sur :

1. **meme identifiant natif** : l'appid Steam lu dans la cle du registre est
   celui du scanner Steam. Aucune ambiguite.
2. **meme dossier** une fois les chemins normalises (casse, barres obliques,
   doubles antislashs des fichiers VDF, noms courts 8.3, jonctions).
3. **dossiers imbriques et titres proches** : le registre pointe parfois sur
   le dossier parent ou sur un sous-dossier « Binaries ».
4. **meme titre**, quand l'une des deux fiches vient d'une source generique
   (registre, dossier). Deux vraies plateformes avec le meme titre restent
   separees : c'est une vraie double installation (Steam et Epic, par exemple).
"""
from __future__ import annotations

import os
import re
from typing import Iterable

from .models import Game, normalize_title

#: sources qui ne connaissent pas le jeu, elles le devinent
GENERIQUES = frozenset({"registre", "dossier", "folders", "manuel", "manual"})

#: cle de registre -> (plateforme, identifiant natif)
_CLES_NATIVES = (
    (re.compile(r"^steam app (\d+)$", re.I), "steam"),
    (re.compile(r"^uplay install (\d+)$", re.I), "ubisoft"),
    (re.compile(r"^(\d{6,})_is1$", re.I), "gog"),
)

_PLUSIEURS_SEP = re.compile(r"\\{2,}")


def cle_native(sous_cle: str) -> tuple[str, str] | None:
    """(plateforme, id) si la cle de desinstallation trahit sa plateforme."""
    for motif, plateforme in _CLES_NATIVES:
        m = motif.match((sous_cle or "").strip())
        if m:
            return plateforme, m.group(1)
    return None


def chemin_cle(chemin: str) -> str:
    """Forme canonique d'un dossier, comparable d'une source a l'autre."""
    brut = (chemin or "").strip().strip('"')
    if not brut:
        return ""
    brut = brut.replace("/", "\\")
    # « \\\\?\\C:\\... » (chemins longs) et doubles antislashs des VDF
    if brut.startswith("\\\\?\\"):
        brut = brut[4:]
    tete, reste = ("\\\\", brut[2:]) if brut.startswith("\\\\") else ("", brut)
    brut = tete + _PLUSIEURS_SEP.sub("\\\\", reste)
    if os.name == "nt":
        try:
            # noms courts (PROGRA~2), jonctions et liens symboliques
            if os.path.exists(brut):
                brut = os.path.realpath(brut)
        except OSError:
            pass
    return brut.rstrip("\\").casefold()


def ids_natifs(game: Game) -> set[tuple[str, str]]:
    ids: set[tuple[str, str]] = set()
    if game.source not in GENERIQUES and game.source_id:
        ids.add((game.source, str(game.source_id).casefold()))
    natif = game.extra.get("native") if isinstance(game.extra, dict) else None
    if isinstance(natif, (list, tuple)) and len(natif) == 2:
        ids.add((str(natif[0]), str(natif[1]).casefold()))
    return ids


def _imbrique(a: str, b: str) -> bool:
    if not a or not b or a == b:
        return False
    court, long_ = (a, b) if len(a) < len(b) else (b, a)
    # « D:\Games » contient tous les jeux : un dossier trop haut ne prouve rien
    if court.count("\\") < 2:
        return False
    return long_.startswith(court + "\\")


def _titres_proches(a: Game, b: Game) -> bool:
    ka, kb = a.key, b.key
    if not ka or not kb:
        return False
    if ka == kb:
        return True
    from .recherche import score
    return score(a.title, b.title) >= 0.9 or score(b.title, a.title) >= 0.9


def meme_jeu(a: Game, b: Game) -> bool:
    if a.uid == b.uid:
        return True
    if ids_natifs(a) & ids_natifs(b):
        return True
    ca, cb = chemin_cle(a.install_dir), chemin_cle(b.install_dir)
    if ca and ca == cb:
        return True
    if _imbrique(ca, cb) and _titres_proches(a, b):
        return True
    generique = a.source in GENERIQUES or b.source in GENERIQUES
    if generique and a.key and a.key == normalize_title(b.title):
        return True
    return False


def fusionner(garde: Game, autre: Game) -> Game:
    """Complete `garde` avec ce que `autre` sait, sans rien perdre.

    Les donnees de l'utilisateur (temps joue dans ORION, favori, profil,
    notes) viennent parfois de la fiche qu'on retire : un joueur a pu lancer
    le jeu depuis l'entree « registre » pendant des semaines.
    """
    for champ in ("executable", "working_dir", "launch_uri", "store_url",
                  "engine", "art_cover", "art_hero", "art_logo", "art_icon",
                  "accent_color"):
        if hasattr(garde, champ) and not getattr(garde, champ) \
                and getattr(autre, champ, ""):
            setattr(garde, champ, getattr(autre, champ))
    if not garde.size_bytes:
        garde.size_bytes = autre.size_bytes
    if not garde.external_seconds:
        garde.external_seconds = autre.external_seconds

    garde.favorite = bool(garde.favorite or autre.favorite)
    garde.play_seconds = int(garde.play_seconds or 0) + int(autre.play_seconds or 0)
    garde.last_played = max(garde.last_played or 0, autre.last_played or 0)
    for champ in ("preferred_profile", "preferred_display", "notes"):
        if not getattr(garde, champ) and getattr(autre, champ):
            setattr(garde, champ, getattr(autre, champ))

    vus = garde.extra.setdefault("also_in", [])
    for src in [autre.source, *autre.extra.get("also_in", [])]:
        if src and src != garde.source and src not in vus:
            vus.append(src)
    fusions = garde.extra.setdefault("merged_uids", [])
    for uid in [autre.uid, *autre.extra.get("merged_uids", [])]:
        if uid and uid != garde.uid and uid not in fusions:
            fusions.append(uid)
    return garde


def rang(game: Game, priorites: dict[str, int]) -> tuple:
    """Plus petit = meilleure fiche a conserver."""
    return (game.source in GENERIQUES,
            -priorites.get(game.source, 0),
            not game.executable and not game.launch_uri)


def dedoublonner(games: Iterable[Game],
                 priorites: dict[str, int] | None = None) -> list[Game]:
    """Une fiche par jeu. L'ordre d'entree est conserve pour les survivants."""
    priorites = priorites or {}
    liste = list(games)
    ordre = {id(g): i for i, g in enumerate(liste)}
    tries = sorted(liste, key=lambda g: (rang(g, priorites), ordre[id(g)]))
    gardes: list[Game] = []
    for g in tries:
        jumeau = next((k for k in gardes if meme_jeu(k, g)), None)
        if jumeau is None:
            gardes.append(g)
        else:
            fusionner(jumeau, g)
    gardes.sort(key=lambda g: ordre[id(g)])
    return gardes
