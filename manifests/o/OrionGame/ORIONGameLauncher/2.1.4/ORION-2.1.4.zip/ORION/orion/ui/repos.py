"""Les mises a jour de fond attendent que le joueur ait fini son geste (2.0).

Prix releves, jeux gratuits, analyse de la machine, images arrivees : tout
cela finit dans le fil d'affichage, a un moment que le joueur ne choisit pas.
S'il est en train de faire defiler une page ou de taper un nom, la fenetre
se fige un instant : c'est l'accrochage « de temps en temps », sans cause
visible (mesure du 7 octobre 2026 : 0,2 a 0,6 s selon la mise a jour).

Ici une mise a jour de fond n'est appliquee que lorsque souris, molette et
clavier sont au repos depuis `CALME` secondes. Elle ne se perd jamais : apres
`PATIENCE` secondes elle part quand meme, et la page concernee la reclame
tout de suite quand le joueur l'ouvre (`faire`).

    repos.differer("boutique", lambda: vue.set_catalogue(...))
    repos.faire("boutique")        # dans showEvent : la page doit etre a jour

Une meme cle ne garde que la derniere mise a jour demandee. Deux mises a
jour differentes d'une meme page prennent donc deux cles : « hardware » et
« hardware:puissance » ; `faire("hardware")` applique les deux.
"""
from __future__ import annotations

import time
from collections import OrderedDict

from PySide6.QtCore import QObject, QTimer

from ..core.logging_setup import get

log = get("ui.repos")

#: secondes sans geste avant d'appliquer une mise a jour
CALME = 0.6
#: au-dela, elle est appliquee meme si le joueur ne s'arrete pas
PATIENCE = 12.0

_dernier_geste = 0.0


def geste() -> None:
    """Le joueur vient de bouger la souris, la molette ou une touche."""
    global _dernier_geste
    _dernier_geste = time.monotonic()


def calme(depuis: float = CALME) -> bool:
    return time.monotonic() - _dernier_geste >= depuis


class _Repos(QObject):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.travaux: "OrderedDict[str, tuple]" = OrderedDict()   # cle -> (fonction, depuis)
        self._minuteur = QTimer(self)
        self._minuteur.setInterval(120)
        self._minuteur.timeout.connect(self._tic)

    def differer(self, cle: str, fonction) -> None:
        depuis = self.travaux[cle][1] if cle in self.travaux else time.monotonic()
        self.travaux[cle] = (fonction, depuis)
        if not self._minuteur.isActive():
            self._minuteur.start()

    def faire(self, cle: str) -> bool:
        """Applique ce qui attend pour `cle` et pour ses sous-cles
        (« hardware » applique aussi « hardware:puissance ») : une page peut
        attendre plusieurs mises a jour distinctes."""
        voulues = [c for c in self.travaux if c == cle or c.startswith(cle + ":")]
        for c in voulues:
            travail = self.travaux.pop(c, None)
            if travail is not None:
                self._lancer(c, travail[0])
        return bool(voulues)

    def _tic(self) -> None:
        if not self.travaux:
            self._minuteur.stop()
            return
        maintenant = time.monotonic()
        cle, (fonction, depuis) = next(iter(self.travaux.items()))
        if calme() or maintenant - depuis >= PATIENCE:
            del self.travaux[cle]
            self._lancer(cle, fonction)
            # un seul travail par passage : l'affichage respire entre deux
        if not self.travaux:
            self._minuteur.stop()

    @staticmethod
    def _lancer(cle: str, fonction) -> None:
        try:
            fonction()
        except RuntimeError:
            pass                    # vue detruite entre-temps (fermeture)
        except Exception:
            log.exception("Mise a jour differee en echec (%s)", cle)


_instance: _Repos | None = None


def _repos() -> _Repos:
    global _instance
    if _instance is None:
        from PySide6.QtWidgets import QApplication
        _instance = _Repos(QApplication.instance())
    return _instance


def differer(cle: str, fonction) -> None:
    """Applique `fonction` au prochain moment de calme (voir le module)."""
    _repos().differer(cle, fonction)


def faire(cle: str) -> bool:
    """Applique tout de suite la mise a jour en attente pour `cle`, s'il y en
    a une. Rend vrai si quelque chose a ete fait."""
    return _instance.faire(cle) if _instance is not None else False


def en_attente(cle: str) -> bool:
    return _instance is not None and cle in _instance.travaux


def tout_faire() -> None:
    """Applique tout ce qui attend (fermeture, essais)."""
    if _instance is not None:
        for cle in list(_instance.travaux):
            _instance.faire(cle)
