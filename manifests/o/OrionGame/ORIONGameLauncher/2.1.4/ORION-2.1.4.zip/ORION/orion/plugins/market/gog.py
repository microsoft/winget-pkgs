"""Prix GOG : catalogue public, aucune cle necessaire.

Complete Steam pour donner un vrai comparatif des le premier lancement,
sans que l'utilisateur ait quoi que ce soit a configurer.
"""
from __future__ import annotations

from orion.core import region

from ...core.config import CONFIG
from ...core.logging_setup import get
from ...core.models import Game
from .base import MarketInfo, MarketProvider, Offer

log = get("market.gog")

CATALOG = "https://catalog.gog.com/v1/catalog"
HEADERS = {"User-Agent": "ORION-Launcher/1.0 (+local)"}


class GOGProvider(MarketProvider):
    id = "gog_catalog"
    label = "GOG"
    priority = 70
    filtre_adulte = "etiquettes du catalogue GOG (« nsfw ») lues par produit_adulte"

    def fetch(self, game: Game, info: MarketInfo) -> None:
        from orion.core import reseau

        from ...core.recherche import titre_recherche
        country = str(CONFIG.get("market.country") or "FR")
        # titre sans separateurs ni marques : « RuneScape - Dragonwilds »
        # cherche « RuneScape Dragonwilds »
        terme = titre_recherche(game.title) or game.title
        try:
            r = reseau.get(CATALOG, headers=HEADERS, timeout=12, params={
                "limit": 8,
                "query": f"like:{terme}",
                "order": "desc:score",
                "productType": "in:game,pack",
                "countryCode": country,
                "locale": region.locale_gog(),
                "currencyCode": region.devise(),
            })
            if r.status_code != 200:
                return
            products = (r.json() or {}).get("products") or []
        except Exception:
            log.debug("Catalogue GOG indisponible pour %s", game.title)
            return

        # meme jeu a la ponctuation, aux mentions d'edition et aux chiffres
        # romains pres ; jamais un DLC, une bande originale ou un autre numero
        from ...core.recherche import meilleur_candidat
        product = meilleur_candidat(
            game.title, [p for p in products if isinstance(p, dict)],
            nom=lambda p: p.get("title", ""), genre=lambda p: p.get("productType"))
        for product in [product] if product is not None else []:
            info.adulte = info.adulte or self.adulte(product)
            price = product.get("price") or {}
            final = price.get("finalMoney") or {}
            base = price.get("baseMoney") or {}
            amount = final.get("amount")
            if amount is None:
                continue
            try:
                value = round(float(amount), 2)
                base_value = round(float(base.get("amount") or amount), 2)
            except (TypeError, ValueError):
                continue

            cut = int(round((1 - value / base_value) * 100)) if base_value else 0
            slug = product.get("slug") or ""
            offer = Offer(
                shop="GOG",
                price=value,
                currency=final.get("currency", "EUR"),
                cut=max(cut, 0),
                url=f"https://www.gog.com/fr/game/{slug}" if slug
                    else "https://www.gog.com/",
                drm="sans DRM",
            )
            if not any(o.shop == "GOG" for o in info.offers):
                info.offers.append(offer)
            info.offers.sort(key=lambda o: o.price)
            if not info.best or offer.price < info.best.price:
                info.best = info.offers[0]
            if self.id not in info.sources:
                info.sources.append(self.id)
            break
