"""Compte Xbox / Microsoft (Game Pass, Microsoft Store, jeux Xbox sur PC).

Connexion sur la page officielle de Microsoft (login.live.com). Le code
rendu est echange contre un jeton Microsoft, puis contre les jetons Xbox
Live (XBL puis XSTS), comme le font l'application Xbox et les launchers
libres. Methode non officielle pour une application tierce (tolere) :
Microsoft reserve son acces documente aux editeurs de jeux.

Donnees : gamertag, Gamerscore, tous les jeux lances sur le compte (PC et
consoles), succes obtenus et manquants avec leur rarete.
"""
from __future__ import annotations

import time
from datetime import datetime
from urllib.parse import parse_qs, urlencode, urlparse

from ..core.logging_setup import get
from .base import ConnexionRequise, JeuCompte, Plateforme, Profil, Succes

log = get("comptes.xbox")

CLIENT_ID = "000000004C12AE6F"          # application Xbox (public)
RETOUR = "https://login.live.com/oauth20_desktop.srf"
PORTEE = "service::user.auth.xboxlive.com::MBI_SSL"
AUTORISER = "https://login.live.com/oauth20_authorize.srf"
JETON = "https://login.live.com/oauth20_token.srf"


class Xbox(Plateforme):
    id = "xbox"
    nom = "Xbox / Microsoft"
    nature = "tolere"
    apport = ("Jeux Game Pass, Microsoft Store et Xbox sur PC : Gamerscore, "
              "succes obtenus et manquants avec leur rarete.")
    # la fenetre integree ne gere pas les cles de securite : masquees sur les
    # pages de Microsoft, qui proposent alors le mot de passe ou un code
    domaines_sans_cle = ("login.live.com", "login.microsoftonline.com",
                         "login.microsoft.com", "account.live.com")
    conseil_connexion = ("Si Microsoft propose une cle de securite : « Autres facons "
                         "de se connecter » puis « Mot de passe » (ou un code recu "
                         "par e-mail ou SMS).")

    # ------------------------------------------------------------------
    # connexion
    # ------------------------------------------------------------------
    def adresse_connexion(self) -> str:
        return f"{AUTORISER}?" + urlencode({
            "client_id": CLIENT_ID, "redirect_uri": RETOUR, "response_type": "code",
            "scope": PORTEE, "display": "touch", "locale": "fr-FR"})

    def est_retour(self, adresse: str) -> bool:
        return adresse.startswith(RETOUR)

    def retour_connexion(self, adresse: str) -> dict:
        q = parse_qs(urlparse(adresse).query)
        if q.get("error"):
            raise ValueError("connexion annulee")
        code = (q.get("code") or [""])[0]
        if not code:
            raise ValueError("connexion annulee")
        ms = self._jeton_microsoft(grant_type="authorization_code", code=code)
        return self._jetons_xbox(ms)

    def _jeton_microsoft(self, **donnees) -> dict:
        from ..core import reseau
        donnees.update(client_id=CLIENT_ID, redirect_uri=RETOUR, scope=PORTEE)
        r = reseau.post(JETON, data=donnees, timeout=20)
        if r.status_code >= 400:
            raise ValueError("Microsoft a refuse la connexion")
        d = r.json()
        return {"ms_access": d["access_token"], "ms_refresh": d.get("refresh_token", "")}

    def _jetons_xbox(self, ms: dict) -> dict:
        from ..core import reseau
        entetes = {"x-xbl-contract-version": "1", "Accept": "application/json"}
        r = reseau.post("https://user.auth.xboxlive.com/user/authenticate", json={
            "RelyingParty": "http://auth.xboxlive.com", "TokenType": "JWT",
            "Properties": {"AuthMethod": "RPS", "SiteName": "user.auth.xboxlive.com",
                           "RpsTicket": ms["ms_access"]}}, headers=entetes, timeout=20)
        r.raise_for_status()
        xbl = r.json()["Token"]
        r = reseau.post("https://xsts.auth.xboxlive.com/xsts/authorize", json={
            "RelyingParty": "http://xboxlive.com", "TokenType": "JWT",
            "Properties": {"UserTokens": [xbl], "SandboxId": "RETAIL"}},
            headers=entetes, timeout=20)
        if r.status_code == 401:
            raise ValueError("ce compte Microsoft n'a pas de profil Xbox")
        r.raise_for_status()
        d = r.json()
        claims = (d.get("DisplayClaims") or {}).get("xui", [{}])[0]
        return dict(ms, xsts=d["Token"], uhs=claims.get("uhs", ""),
                    xuid=claims.get("xid", ""), gamertag=claims.get("gtg", ""),
                    expire=_date(d.get("NotAfter")) - 300)

    def _entetes(self, contrat: str = "2") -> dict:
        s = self.secret()
        if time.time() >= float(s.get("expire") or 0):
            if not s.get("ms_refresh"):
                raise ConnexionRequise(self.nom)
            try:
                s = self._jetons_xbox(self._jeton_microsoft(
                    grant_type="refresh_token", refresh_token=s["ms_refresh"]))
            except Exception as exc:
                raise ConnexionRequise(self.nom) from exc
            self.maj_secret(**s)
        return {"Authorization": f"XBL3.0 x={s['uhs']};{s['xsts']}",
                "x-xbl-contract-version": contrat, "Accept-Language": "fr-FR",
                "Accept": "application/json"}

    def _get(self, url: str, contrat: str = "2", **params) -> dict:
        from ..core import reseau
        r = reseau.get(url, params=params or None, headers=self._entetes(contrat),
                       timeout=25)
        if r.status_code == 401:
            raise ConnexionRequise(self.nom)
        r.raise_for_status()
        return r.json() or {}

    # ------------------------------------------------------------------
    # donnees
    # ------------------------------------------------------------------
    def _lire_profil(self) -> Profil:
        s = self.secret()
        xuid = s.get("xuid", "")
        d = self._get(f"https://profile.xboxlive.com/users/xuid({xuid})/profile/settings",
                      contrat="3", settings="Gamertag,Gamerscore,GameDisplayPicRaw,"
                                            "AccountTier,TenureLevel")
        reglages = {x["id"]: x.get("value") for x in
                    ((d.get("profileUsers") or [{}])[0].get("settings") or [])}
        tag = reglages.get("Gamertag") or s.get("gamertag", "")
        return Profil(plateforme=self.id, id=xuid, pseudo=tag,
                      avatar=reglages.get("GameDisplayPicRaw", ""),
                      adresse=f"https://www.xbox.com/fr-FR/play/user/{tag}" if tag else "",
                      score=int(reglages.get("Gamerscore") or 0),
                      niveau=int(reglages.get("TenureLevel") or 0) or None,
                      extra={"abonnement": reglages.get("AccountTier", "")})

    def _lire_jeux(self) -> list[JeuCompte]:
        xuid = self.secret().get("xuid", "")
        d = self._get(f"https://titlehub.xboxlive.com/users/xuid({xuid})/titles/titlehistory/"
                      "decoration/achievement,image,detail", contrat="2")
        jeux = []
        for t in d.get("titles") or []:
            if t.get("type") not in (None, "Game"):
                continue
            a = t.get("achievement") or {}
            jeux.append(JeuCompte(
                plateforme=self.id, id=str(t.get("titleId")), titre=t.get("name", ""),
                derniere_partie=_date((t.get("titleHistory") or {}).get("lastTimePlayed")),
                succes_total=int(a.get("totalAchievements") or 0),
                succes_obtenus=int(a.get("currentAchievements") or 0),
                image=t.get("displayImage", "")))
        log.info("Xbox : %d jeux sur le compte", len(jeux))
        return jeux

    def succes(self, jeu_id: str) -> list[Succes]:
        xuid = self.secret().get("xuid", "")
        d = self._get(f"https://achievements.xboxlive.com/users/xuid({xuid})/achievements",
                      contrat="2", titleId=jeu_id, maxItems=1000)
        liste = []
        for a in d.get("achievements") or []:
            obtenu = a.get("progressState") == "Achieved"
            rarete = (a.get("rarity") or {}).get("currentPercentage")
            images = [m.get("url") for m in a.get("mediaAssets") or [] if m.get("url")]
            liste.append(Succes(
                id=str(a.get("id")), nom=a.get("name", ""),
                description=a.get("description") if obtenu else
                (a.get("lockedDescription") or a.get("description", "")),
                obtenu=obtenu,
                date=_date((a.get("progression") or {}).get("timeUnlocked")) if obtenu else 0,
                rarete=float(rarete) if rarete is not None else None,
                icone=images[0] if images else "", cache=bool(a.get("isSecret"))))
        return liste


def _date(texte) -> float:
    if not texte:
        return 0.0
    try:
        t = str(texte).replace("Z", "+00:00")
        if "." in t:                       # fractions trop longues pour Python
            tete, reste = t.split(".", 1)
            fuseau = reste[reste.find("+"):] if "+" in reste else ""
            t = tete + fuseau
        ts = datetime.fromisoformat(t).timestamp()
        return 0.0 if ts < 86400 else ts   # 0001-01-01 = jamais
    except (ValueError, OverflowError):
        return 0.0
