"""Fiche d'un jeu : profils, apercu des reglages, lancement."""
from __future__ import annotations

from ..minuteur import plus_tard

from orion.affiliation import ouvreur  # liens de boutique (partenaires)

import time
from pathlib import Path

from PySide6.QtCore import QPoint, QSize, Qt, Signal
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (QComboBox, QFrame, QGridLayout, QHBoxLayout,
                               QLabel, QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget)

from ...core.models import Display, Game, HardwareInfo, OptimizationPlan
from ...i18n import t
from ...core.paths import is_windows
from ...optimizer.advisor import Advice
from ...plugins.market.base import MarketInfo
from ..widgets.advice_card import AdviceCard
from ..widgets.game_card import placeholder, rounded
from ..widgets.profile_card import ChoixGraphismes
from ..widgets.layouts import clear_layout
from ..defilement import ZoneDefilante

ouvrir_lien = ouvreur("fiche")   # d'ou vient le clic (compteur anonyme)


#: a quel point la recette utilisee correspond au jeu (`Recipe.confidence`)
CORRESPONDANCES = {"exact": "correspondance exacte", "moteur": "correspondance par moteur",
                   "generique": "recette generique", "appris": "fichier appris, cles sures seulement"}


class DetailView(QWidget):
    back_requested = Signal()
    play_requested = Signal(str, str)          # uid, profil
    apply_requested = Signal(str, str)         # uid, profil
    profile_changed = Signal(str, str)
    choix_requested = Signal(str, str, int)  # uid, niveau, objectif d'images/s (« Votre ecran » : "", 0) : ecrire
    cible_requested = Signal(str, str, int)  # uid, niveau, objectif essayes dans « Mon choix » : apercu
    sr_requested = Signal(str, str, bool)    # uid, carte, case DLSS / FSR / XeSS cochee
    apprendre_requested = Signal(str)        # uid : apprendre les niveaux du jeu par l'exemple
    defaut_requested = Signal(str)          # uid : redefinir les parametres par defaut
    favorite_toggled = Signal(str)
    restore_requested = Signal(str)
    market_refresh_requested = Signal(str)
    share_recipe_requested = Signal(str)
    tuning_requested = Signal(str, str)      # uid, action (apply | reset)
    save_backup_requested = Signal(str, str)    # uid, dossier
    save_restore_requested = Signal(str, int)   # uid, index de l'archive
    ai_requested = Signal(str, str)        # uid, tache

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.game: Game | None = None
        self.plan: OptimizationPlan | None = None
        self.profile_id = "recommande"

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)

        scroll = ZoneDefilante()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        outer.addWidget(scroll)

        body = QWidget()
        scroll.setWidget(body)
        self.root = QVBoxLayout(body)
        self.root.setContentsMargins(24, 16, 24, 24)
        self.root.setSpacing(16)

        # 1) le jeu : visuel, titre, boutons, infos et succes ;
        # 2) captures d'ecran ; 3) videos ; puis le reste de la fiche
        self._build_header()
        self._build_media()
        self._build_news()
        self._build_dlc()
        self._build_saves()
        self._build_perf()
        self._build_ai()
        self._build_profiles()
        self._build_settings()
        self._build_changes()
        self._build_advice()
        self.root.addStretch(1)

        # le lecteur video ne demande rien au reseau tant qu'il n'est pas a
        # l'ecran : on le previent quand on fait defiler la fiche jusqu'a lui
        self.scroll = scroll
        scroll.verticalScrollBar().valueChanged.connect(self._lecteur_visible)

    # ------------------------------------------------------------------
    def _build_header(self) -> None:
        top = QHBoxLayout()
        back = QPushButton("< Bibliotheque")
        back.setObjectName("Ghost")
        back.setMaximumWidth(150)
        back.clicked.connect(self.back_requested.emit)
        top.addWidget(back)
        top.addStretch(1)
        self.fav = QPushButton("Favori")
        self.fav.setObjectName("Ghost")
        self.fav.setCheckable(True)
        self.fav.clicked.connect(
            lambda: self.game and self.favorite_toggled.emit(self.game.uid))
        top.addWidget(self.fav)
        self.store_btn = QPushButton("Boutique")
        self.store_btn.setObjectName("Ghost")
        self.store_btn.setToolTip("Ouvrir la page du jeu sur sa boutique")
        self.store_btn.clicked.connect(self._open_store)
        top.addWidget(self.store_btn)

        self.folder_btn = QPushButton("Ouvrir le dossier")
        self.folder_btn.setObjectName("Ghost")
        self.folder_btn.clicked.connect(self._open_folder)
        top.addWidget(self.folder_btn)
        self.root.addLayout(top)

        rang = QHBoxLayout()
        rang.setSpacing(16)
        hero = FicheBandeau()
        hero.setMinimumHeight(230)
        self.hero = hero
        hl = QHBoxLayout(hero)
        hl.setContentsMargins(22, 22, 22, 22)
        hl.setSpacing(22)

        self.cover = QLabel()
        self.cover.setFixedSize(QSize(144, 216))
        hl.addWidget(self.cover, 0, Qt.AlignmentFlag.AlignTop)

        info = QVBoxLayout()
        info.setSpacing(6)
        self.title = QLabel("-")
        self.title.setObjectName("HeroTitle")
        self.title.setWordWrap(True)
        info.addWidget(self.title)

        self.subtitle = QLabel("")
        self.subtitle.setObjectName("Dim")
        info.addWidget(self.subtitle)

        # joueurs en ligne en ce moment (jeux en ligne vendus sur Steam, 1.8.1)
        self.en_ligne = QLabel("")
        self.en_ligne.setObjectName("EnLigne")
        self.en_ligne.setToolTip(
            "Chiffre publie par Steam, actualise toutes les 5 minutes. Seuls les "
            "joueurs connectes via Steam sont comptes : ceux d'autres boutiques "
            "ou des consoles ne sont pas inclus.")
        self.en_ligne.hide()
        info.addWidget(self.en_ligne)
        info.addSpacing(4)

        self.meta_grid = QGridLayout()
        self.meta_grid.setHorizontalSpacing(18)
        self.meta_grid.setVerticalSpacing(4)
        self.meta_grid.setColumnMinimumWidth(0, 110)
        self.meta_grid.setColumnStretch(1, 1)
        info.addLayout(self.meta_grid)
        info.addStretch(1)

        actions = QHBoxLayout()
        actions.setSpacing(10)
        self.play = QPushButton("Jouer")
        self.play.setObjectName("Primary")
        self.play.setMinimumWidth(140)
        self.play.clicked.connect(
            lambda: self.game and self.play_requested.emit(self.game.uid, self.profile_id))
        actions.addWidget(self.play)

        self.restore = QPushButton("Restaurer")
        self.restore.setObjectName("Ghost")
        self.restore.setToolTip("Revenir aux reglages sauvegardes avant la "
                                "derniere application")
        self.restore.clicked.connect(
            lambda: self.game and self.restore_requested.emit(self.game.uid))
        actions.addWidget(self.restore)

        actions.addStretch(1)
        info.addLayout(actions)
        hl.addLayout(info, 1)
        rang.addWidget(hero, 1)

        self._build_infos()
        rang.addWidget(self.infos_panel)
        self.root.addLayout(rang)

        # succes du compte connecte (1.8, compact en 1.9)
        from ..widgets.succes_panel import SuccesPanel
        self.succes = SuccesPanel()
        self.succes.resume_change.connect(self._succes_resume)
        self.root.addWidget(self.succes)

    # ------------------------------------------------------------------
    def _build_infos(self) -> None:
        """Panneau « Infos » : studio, sortie, genres, evaluation, succes."""
        panel = QFrame()
        panel.setObjectName("Panel")
        panel.setFixedWidth(360)
        lay = QVBoxLayout(panel)
        lay.setContentsMargins(18, 16, 18, 16)
        lay.setSpacing(10)

        head = QHBoxLayout()
        title = QLabel("Infos")
        title.setObjectName("PanelTitle")
        head.addWidget(title)
        head.addStretch(1)
        self.market_refresh = QPushButton("Actualiser")
        self.market_refresh.setObjectName("Ghost")
        self.market_refresh.setToolTip("Relire les informations du jeu (Steam...)")
        self.market_refresh.setStyleSheet("padding:4px 10px; font-size:12px;")
        self.market_refresh.clicked.connect(
            lambda: self.game and self.market_refresh_requested.emit(self.game.uid))
        head.addWidget(self.market_refresh)
        lay.addLayout(head)

        self.infos_grid = QGridLayout()
        self.infos_grid.setHorizontalSpacing(14)
        self.infos_grid.setVerticalSpacing(8)
        self.infos_grid.setColumnMinimumWidth(0, 82)
        self.infos_grid.setColumnStretch(1, 1)
        lay.addLayout(self.infos_grid)
        lay.addStretch(1)

        self.market_note = QLabel("")
        self.market_note.setObjectName("Faint")
        self.market_note.setWordWrap(True)
        lay.addWidget(self.market_note)

        self.infos_panel = panel
        self.market_panel = panel          # nom historique
        self.market = None
        self._resume_succes: dict = {}

    def _remplir_infos(self) -> None:
        """(Re)dessine le panneau Infos d'apres le releve et les succes."""
        from ..theme import PALETTE
        clear_layout(self.infos_grid)
        info = self.market
        rows: list[tuple[str, str, str]] = []        # cle, valeur, couleur
        if info is not None:
            if info.developer:
                rows.append(("Studio", info.developer, ""))
            if info.publisher and info.publisher != info.developer:
                rows.append(("Editeur", info.publisher, ""))
            if info.release_date:
                rows.append(("Sortie", info.release_date, ""))
            if info.genres:
                rows.append(("Genres", ", ".join(info.genres[:4]), ""))
            if info.review_count:
                score = int(info.review_score or 0)
                couleur = (PALETTE["ok"] if score >= 80 else
                           PALETTE["warn"] if score >= 50 else PALETTE["danger"])
                texte = f"{score} % positifs"
                if info.review_label:
                    texte += f" · {info.review_label}"
                rows.append(("Avis Steam", texte, couleur))
            if info.metacritic:
                m = int(info.metacritic)
                couleur = (PALETTE["ok"] if m >= 75 else
                           PALETTE["warn"] if m >= 50 else PALETTE["danger"])
                rows.append(("Metacritic", f"{m} / 100", couleur))
        r = self._resume_succes
        if r and r.get("total"):
            texte = f"{r['obtenus']}/{r['total']} · {r['pourcentage']} %"
            n = int(r.get("rares_obtenus") or 0)
            if n:
                texte += f" · {n} rare" + ("s" if n > 1 else "")
            rows.append(("Succes", texte, PALETTE["accent"] if r["pourcentage"] >= 100 else ""))
        for i, (k, v, couleur) in enumerate(rows):
            kl = QLabel(k)
            kl.setObjectName("Key")
            vl = QLabel(v)
            vl.setObjectName("Value")
            vl.setWordWrap(True)
            vl.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            if couleur:
                vl.setStyleSheet(f"color:{couleur};")
            if k == "Avis Steam" and info is not None:
                vl.setToolTip(f"{info.review_count:,} avis de joueurs sur Steam".replace(",", " "))
            self.infos_grid.addWidget(kl, i, 0, Qt.AlignmentFlag.AlignTop)
            self.infos_grid.addWidget(vl, i, 1)
        if rows:
            if info is not None and info.note and not info.developer:
                self.market_note.setText(info.note)
                self.market_note.setVisible(True)
            elif info is not None:
                self.market_note.setVisible(False)
        elif info is not None:
            self.market_note.setText(info.note or "Aucune information trouvee pour ce jeu.")
            self.market_note.setVisible(True)

    def _succes_resume(self, resume: dict) -> None:
        self._resume_succes = dict(resume or {})
        self._remplir_infos()

    # ------------------------------------------------------------------
    def _build_media(self) -> None:
        """Captures d'ecran puis lecteur video (gameplay, live, bande-annonce)."""
        from ..widgets.captures import BandeauCaptures
        shots = QFrame()
        shots.setObjectName("Panel")
        sl = QVBoxLayout(shots)
        sl.setContentsMargins(18, 16, 18, 14)
        sl.setSpacing(10)
        tete = QHBoxLayout()
        st = QLabel("Captures d'ecran")
        st.setObjectName("PanelTitle")
        tete.addWidget(st)
        tete.addStretch(1)
        self.shots_hint = QLabel("Cliquez pour agrandir  ·  fleches pour defiler")
        self.shots_hint.setObjectName("Faint")
        tete.addWidget(self.shots_hint)
        sl.addLayout(tete)
        self.shots = BandeauCaptures()
        sl.addWidget(self.shots)
        self.shots_panel = shots
        shots.setVisible(False)
        self.root.addWidget(shots)

        from ..widgets.lecteur_video import LecteurVideo
        self.lecteur = LecteurVideo()
        self.root.addWidget(self.lecteur)

    def _rester_en_haut(self) -> None:
        """Nouvelle fiche : on part du haut, et on y reste pendant que la
        page se construit (panneaux qui apparaissent, lecteur video qui se
        charge). Des que le joueur fait defiler lui-meme, on n'y touche plus."""
        barre = self.scroll.verticalScrollBar()
        if not getattr(self, "_haut_branche", False):
            self._haut_branche = True
            barre.actionTriggered.connect(lambda *_: setattr(self, "_haut_jeton", None))
            barre.sliderPressed.connect(lambda: setattr(self, "_haut_jeton", None))
            self.scroll.viewport().installEventFilter(self)
        jeton = self._haut_jeton = object()
        barre.setValue(0)

        delais = (0, 120, 400, 1000, 2500)

        def remonter(j=jeton, dernier=False) -> None:
            if getattr(self, "_haut_jeton", None) is j:
                barre.setValue(0)
                if dernier:
                    # page posee : l'ancrage des cartes (`_ancrer`) redevient
                    # possible meme si le joueur n'a pas encore fait defiler
                    self._haut_jeton = None
        for delai in delais:
            plus_tard(self, delai, lambda d=delai: remonter(dernier=d == delais[-1]))

    def eventFilter(self, objet, evenement):
        from PySide6.QtCore import QEvent
        if evenement.type() in (QEvent.Type.Wheel, QEvent.Type.MouseButtonPress,
                                QEvent.Type.KeyPress, QEvent.Type.TouchBegin):
            self._haut_jeton = None       # le joueur a pris la main
        return super().eventFilter(objet, evenement)

    def _lecteur_visible(self, *_args) -> None:
        """Le lecteur arrive a l'ecran : il peut chercher ses videos."""
        lecteur = getattr(self, "lecteur", None)
        if lecteur is None or lecteur._actif or lecteur.game is None or not self.isVisible():
            return
        zone = self.scroll.viewport()
        haut = lecteur.mapTo(zone, lecteur.rect().topLeft()).y()
        if haut < zone.height():
            lecteur.activer()

    def showEvent(self, event) -> None:             # noqa: N802
        super().showEvent(event)
        plus_tard(self, 0, self._lecteur_visible)

    def hideEvent(self, event) -> None:             # noqa: N802
        # fiche quittee (autre page) : la video s'arrete ; pas quand la
        # fenetre est seulement reduite (masquage « spontane » du systeme)
        lecteur = getattr(self, "lecteur", None)
        if lecteur is not None and not event.spontaneous():
            lecteur.arreter()
        super().hideEvent(event)

    def arreter_videos(self) -> None:
        self.lecteur.arreter()

    # ------------------------------------------------------------------
    def _build_saves(self) -> None:
        panel = QFrame()
        panel.setObjectName("Panel")
        lay = QVBoxLayout(panel)
        lay.setContentsMargins(18, 16, 18, 16)
        lay.setSpacing(10)

        head = QHBoxLayout()
        title = QLabel("Sauvegardes de parties")
        title.setObjectName("PanelTitle")
        head.addWidget(title)
        head.addStretch(1)
        self.save_state = QLabel("")
        self.save_state.setObjectName("Faint")
        head.addWidget(self.save_state)
        lay.addLayout(head)

        row = QHBoxLayout()
        row.setSpacing(10)
        row.addWidget(QLabel("Emplacement"))
        self.save_combo = QComboBox()
        self.save_combo.setMinimumWidth(420)
        row.addWidget(self.save_combo, 1)

        self.save_now = QPushButton("Archiver maintenant")
        self.save_now.clicked.connect(
            lambda: self.game and self.save_backup_requested.emit(
                self.game.uid, self.save_combo.currentData() or ""))
        row.addWidget(self.save_now)
        lay.addLayout(row)

        self.save_table = QTableWidget(0, 3)
        self.save_table.setHorizontalHeaderLabels(
            ["Archive", "Taille", "Emplacement d'origine"])
        self.save_table.verticalHeader().setVisible(False)
        self.save_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.save_table.setSelectionBehavior(
            QTableWidget.SelectionBehavior.SelectRows)
        self.save_table.horizontalHeader().setStretchLastSection(True)
        self.save_table.horizontalHeader().resizeSection(0, 220)
        self.save_table.horizontalHeader().resizeSection(1, 100)
        self.save_table.setMaximumHeight(170)
        lay.addWidget(self.save_table)

        row = QHBoxLayout()
        self.restore_btn = QPushButton("Restaurer la sauvegarde selectionnee")
        self.restore_btn.setObjectName("Ghost")
        self.restore_btn.clicked.connect(self._restore_selected)
        row.addWidget(self.restore_btn)
        row.addStretch(1)
        lay.addLayout(row)

        self.saves_panel = panel
        panel.setVisible(False)
        self.root.addWidget(panel)

    def set_saves(self, locations: list, archives: list,
                  chosen: str = "") -> None:
        """Affiche les emplacements detectes et les archives existantes."""
        self.archives = archives
        self.save_combo.clear()
        for loc in locations:
            label = (f"{loc.path}   ·   {loc.files} fichiers   ·   "
                     f"{loc.size_mb} Mo")
            self.save_combo.addItem(label, loc.path)
        if chosen:
            index = self.save_combo.findData(chosen)
            if index >= 0:
                self.save_combo.setCurrentIndex(index)
            else:
                self.save_combo.addItem(chosen, chosen)
                self.save_combo.setCurrentIndex(self.save_combo.count() - 1)

        self.save_table.setRowCount(len(archives))
        for r, archive in enumerate(archives):
            for c, text in enumerate((archive.when, f"{archive.size_mb} Mo",
                                      archive.source)):
                self.save_table.setItem(r, c, QTableWidgetItem(text))
        self.save_table.setVisible(bool(archives))
        self.restore_btn.setVisible(bool(archives))
        if archives:
            self.save_table.setFixedHeight(min(38 + 31 * len(archives), 170))

        has_location = self.save_combo.count() > 0
        self.save_now.setEnabled(has_location)
        self.save_state.setText(
            f"{len(archives)} archive(s)" if archives
            else ("aucune archive" if has_location
                  else "aucun emplacement detecte"))
        self.saves_panel.setVisible(has_location or bool(archives))

    def vider_saves(self) -> None:
        """Oublie les emplacements et archives affiches (jeu precedent)."""
        self.archives = []
        self.save_combo.clear()
        self.save_table.setRowCount(0)
        self.save_now.setEnabled(False)
        self.save_state.setText("")
        self.saves_panel.setVisible(False)

    def _restore_selected(self) -> None:
        row = self.save_table.currentRow()
        if row < 0 or not self.game:
            return
        self.save_restore_requested.emit(self.game.uid, row)

    def _build_perf(self) -> None:
        panel = QFrame()
        panel.setObjectName("Panel")
        lay = QVBoxLayout(panel)
        lay.setContentsMargins(18, 16, 18, 16)
        lay.setSpacing(10)

        head = QHBoxLayout()
        title = QLabel("Performances mesurees")
        title.setObjectName("PanelTitle")
        head.addWidget(title)
        head.addStretch(1)
        self.perf_hint = QLabel("")
        self.perf_hint.setObjectName("Faint")
        head.addWidget(self.perf_hint)
        lay.addLayout(head)

        self.perf_table = QTableWidget(0, 5)
        self.perf_table.setHorizontalHeaderLabels(
            ["Profil", "Images / s", "1 % bas", "0,1 % bas", "Mesure"])
        self.perf_table.verticalHeader().setVisible(False)
        self.perf_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.perf_table.horizontalHeader().setStretchLastSection(True)
        for i, w in enumerate((170, 110, 100, 100)):
            self.perf_table.horizontalHeader().resizeSection(i, w)
        lay.addWidget(self.perf_table)

        self.perf_advice = QLabel("")
        self.perf_advice.setObjectName("Dim")
        self.perf_advice.setWordWrap(True)
        lay.addWidget(self.perf_advice)

        row = QHBoxLayout()
        row.setSpacing(10)
        self.tune_btn = QPushButton("Appliquer ces ajustements")
        self.tune_btn.setObjectName("Ghost")
        self.tune_btn.setToolTip(
            "Memorise les ajustements proposes pour ce jeu et ce profil")
        self.tune_btn.clicked.connect(
            lambda: self.game and self.tuning_requested.emit(self.game.uid,
                                                             "apply"))
        self.tune_btn.setVisible(False)
        row.addWidget(self.tune_btn)

        self.tune_reset = QPushButton("Revenir au profil d'origine")
        self.tune_reset.setObjectName("Ghost")
        self.tune_reset.clicked.connect(
            lambda: self.game and self.tuning_requested.emit(self.game.uid,
                                                             "reset"))
        self.tune_reset.setVisible(False)
        row.addWidget(self.tune_reset)
        row.addStretch(1)
        lay.addLayout(row)

        self.perf_panel = panel
        panel.setVisible(False)
        self.root.addWidget(panel)

    def set_perf(self, by_profile: dict, advice: str = "", hint: str = "",
                 can_tune: bool = False, tuned: bool = False) -> None:
        """Affiche les mesures d'images par seconde relevees par ORION."""
        import time as _time
        # anciens profils (jusqu'a la 2.0.2) : leurs mesures restent lisibles
        labels = {"esport": "Esport (ancien)", "detente": "Detente (ancien)",
                  "photo": "Photorealiste (ancien)", "recommande": "Choix de la fiche"}
        rows = sorted(by_profile.items())
        self.perf_table.setRowCount(len(rows))
        for r, (profile, run) in enumerate(rows):
            when = _time.strftime("%d/%m", _time.localtime(run.get("at", 0)))
            minutes = int(run.get("seconds", 0) // 60)
            values = (t(labels.get(profile, profile)),
                      f"{run.get('fps_avg', 0):.0f}",
                      f"{run.get('fps_low_1', 0):.0f}",
                      f"{run.get('fps_low_01', 0):.0f}",
                      f"{when} · {minutes} min")
            for c, text in enumerate(values):
                self.perf_table.setItem(r, c, QTableWidgetItem(text))
        self.perf_table.setVisible(bool(rows))
        if rows:
            self.perf_table.setFixedHeight(min(38 + 31 * len(rows), 180))
        self.perf_advice.setText(advice)
        self.perf_advice.setVisible(bool(advice))
        self.perf_hint.setText(hint)
        self.tune_btn.setVisible(can_tune)
        self.tune_reset.setVisible(tuned)
        self.perf_panel.setVisible(bool(rows) or bool(advice))

    def _build_news(self) -> None:
        # -- actualites -------------------------------------------------------
        panel = QFrame()
        panel.setObjectName("Panel")
        lay = QVBoxLayout(panel)
        lay.setContentsMargins(18, 16, 18, 16)
        lay.setSpacing(8)

        title = QLabel("Actualites et mises a jour")
        title.setObjectName("PanelTitle")
        lay.addWidget(title)

        self.news_box = QVBoxLayout()
        self.news_box.setSpacing(8)
        lay.addLayout(self.news_box)

        self.news_panel = panel
        panel.setVisible(False)
        self.root.addWidget(panel)

    def _build_dlc(self) -> None:
        """DLC du jeu : ceux deja acquis, les autres au meilleur prix. Le
        panneau n'apparait que si le jeu a des DLC."""
        from ..widgets.dlc_panel import PanneauDlc
        self.dlc = PanneauDlc(cacher_si_vide=True, origine="fiche", cartes=True)
        self.root.addWidget(self.dlc)

    def _charger_dlc(self) -> None:
        """Seulement pour un jeu Steam : un DLC achete pour Steam ne s'ajoute
        pas a un jeu Epic, GOG ou Xbox."""
        g = self.game
        if g is None or g.source != "steam":
            return
        from ...core.liens import appid_steam
        self.dlc.definir_jeu(appid_steam(g))

    def _build_ai(self) -> None:
        panel = QFrame()
        panel.setObjectName("Panel")
        lay = QVBoxLayout(panel)
        lay.setContentsMargins(18, 16, 18, 16)
        lay.setSpacing(10)

        head = QHBoxLayout()
        title = QLabel("Assistant IA")
        title.setObjectName("PanelTitle")
        head.addWidget(title)
        head.addStretch(1)
        self.ai_state = QLabel("")
        self.ai_state.setObjectName("Faint")
        head.addWidget(self.ai_state)
        lay.addLayout(head)

        row = QHBoxLayout()
        row.setSpacing(10)
        for label, task, tip in (
            ("Conseils pour ce jeu", "advise",
             "Options du menu a regler pour l'objectif choisi"),
            ("Apprendre ce jeu a ORION", "recipe",
             "L'IA analyse les fichiers de configuration du jeu et ecrit la "
             "recette qui permettra a ORION de le regler tout seul"),
            ("Pourquoi ca rame ?", "diagnose",
             "Diagnostic a partir de votre materiel"),
        ):
            btn = QPushButton(label)
            btn.setObjectName("Ghost")
            btn.setToolTip(tip)
            btn.clicked.connect(
                lambda _=False, t=task: self.game and self.ai_requested.emit(
                    self.game.uid, t))
            row.addWidget(btn)
        row.addStretch(1)
        lay.addLayout(row)

        self.ai_output = QLabel("")
        self.ai_output.setObjectName("Dim")
        self.ai_output.setWordWrap(True)
        self.ai_output.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextSelectableByMouse)
        self.ai_output.setVisible(False)
        lay.addWidget(self.ai_output)

        self.ai_panel = panel
        self.root.addWidget(panel)

    def _build_profiles(self) -> None:
        # Bandeau affiche a la place des profils quand le jeu n'expose aucun
        # reglage : mieux vaut le dire que proposer des boutons sans effet.
        self.untunable = QFrame()
        self.untunable.setObjectName("Notice")
        notice = QVBoxLayout(self.untunable)
        notice.setContentsMargins(18, 14, 18, 14)
        notice.setSpacing(6)
        titre = QLabel("Ce jeu ne se regle pas depuis ORION")
        titre.setObjectName("PanelTitle")
        notice.addWidget(titre)
        self.untunable_text = QLabel("")
        self.untunable_text.setObjectName("Dim")
        self.untunable_text.setWordWrap(True)
        notice.addWidget(self.untunable_text)
        self.untunable.setVisible(False)
        self.root.addWidget(self.untunable)

        head = QHBoxLayout()
        lbl = QLabel("Graphismes")
        lbl.setObjectName("PanelTitle")
        head.addWidget(lbl)
        head.addStretch(1)
        head.addWidget(QLabel("Ecran"))
        self.display_combo = QComboBox()
        self.display_combo.setMinimumWidth(240)
        self.display_combo.currentIndexChanged.connect(self._emit_profile)
        head.addWidget(self.display_combo)
        self.root.addLayout(head)

        self.profiles_head = head
        # Recommande en grand, les autres profils en alternatives, l'etat
        # des reglages (« Reglages appliques : 12 sur 14 ») en dessous
        self.choix = ChoixGraphismes()
        self._ancrer_apres_clic = False
        self.choix.choix_fait.connect(self._choix_fait)
        self.choix.apercu_demande.connect(
            lambda niveau, cible: self.game and self.cible_requested.emit(self.game.uid, str(niveau), int(cible)))
        self.choix.apprendre_demande.connect(
            lambda: self.game and self.apprendre_requested.emit(self.game.uid))
        self.choix.sr_demande.connect(self._sr_cliquee)
        self.choix.defaut_demande.connect(self._defaut_cliquee)
        self.root.addWidget(self.choix)

    def _build_settings(self) -> None:
        panel = self.settings_panel = QFrame()
        panel.setObjectName("Panel")
        lay = QVBoxLayout(panel)
        lay.setContentsMargins(18, 16, 18, 16)
        lay.setSpacing(10)

        head = QHBoxLayout()
        t = QLabel("Reglages calcules pour votre configuration")
        t.setObjectName("PanelTitle")
        head.addWidget(t)
        head.addStretch(1)
        self.recipe_label = QLabel("")
        self.recipe_label.setObjectName("Faint")
        head.addWidget(self.recipe_label)
        self.share_btn = QPushButton("Partager cette recette")
        self.share_btn.setObjectName("Ghost")
        self.share_btn.setToolTip(
            "Prepare votre recette pour le depot communautaire : les autres "
            "utilisateurs pourront regler ce jeu automatiquement")
        self.share_btn.setVisible(False)
        self.share_btn.clicked.connect(
            lambda: self.game and self.share_recipe_requested.emit(self.game.uid))
        head.addWidget(self.share_btn)
        lay.addLayout(head)

        self.settings_grid = QGridLayout()
        self.settings_grid.setHorizontalSpacing(30)
        self.settings_grid.setVerticalSpacing(7)
        lay.addLayout(self.settings_grid)
        self.root.addWidget(panel)

    def _build_changes(self) -> None:
        self.changes_panel = QFrame()
        self.changes_panel.setObjectName("Panel")
        lay = QVBoxLayout(self.changes_panel)
        lay.setContentsMargins(18, 16, 18, 16)
        lay.setSpacing(10)

        self.changes_title = QLabel("Modifications prevues dans le jeu")
        self.changes_title.setObjectName("PanelTitle")
        lay.addWidget(self.changes_title)

        self.changes_hint = QLabel("")
        self.changes_hint.setObjectName("Faint")
        self.changes_hint.setWordWrap(True)
        lay.addWidget(self.changes_hint)

        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(
            ["Reglage", "Actuel", "Applique", "Fichier"])
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSelectionMode(QTableWidget.SelectionMode.NoSelection)
        self.table.setMaximumHeight(280)
        header = self.table.horizontalHeader()
        header.setStretchLastSection(True)
        header.resizeSection(0, 230)
        header.resizeSection(1, 110)
        header.resizeSection(2, 110)
        lay.addWidget(self.table)
        self.root.addWidget(self.changes_panel)

    def _build_advice(self) -> None:
        self.advice_box = QWidget()
        self.advice_layout = QVBoxLayout(self.advice_box)
        self.advice_layout.setContentsMargins(0, 0, 0, 0)
        self.advice_layout.setSpacing(8)
        self.root.addWidget(self.advice_box)

    # ------------------------------------------------------------------
    def set_displays(self, displays: list[Display], preferred: str = "") -> None:
        self.display_combo.blockSignals(True)
        self.display_combo.clear()
        for d in displays:
            label = f"{d.name}"
            if d.current:
                label += f"  -  {d.current}"
            if d.primary:
                label += "  (principal)"
            self.display_combo.addItem(label, d.device)
        if preferred:
            idx = self.display_combo.findData(preferred)
            if idx >= 0:
                self.display_combo.setCurrentIndex(idx)
        self.display_combo.blockSignals(False)

    def selected_display(self) -> str:
        return self.display_combo.currentData() or ""

    def set_joueurs(self, texte: str) -> None:
        """Ligne « ● 12 345 joueurs en ligne sur Steam en ce moment »."""
        self.en_ligne.setText(f"●  {texte}" if texte else "")
        self.en_ligne.setVisible(bool(texte))

    def set_game(self, game: Game, hw: HardwareInfo) -> None:
        self.game = game
        # rien du jeu precedent ne doit survivre : son plan (sinon « Appliquer »
        # ecrirait ses reglages), ses sauvegardes, ses mesures
        self.plan = None
        self._ancrer_apres_clic = False
        self.dlc.vider()
        self.vider_saves()
        self.set_perf({})
        self.set_joueurs("")
        # meme profil que celui du plan demande par la fenetre (et non celui
        # du jeu precedent)
        from ...optimizer.profiles import profil_valide
        self.profile_id = profil_valide(game.preferred_profile)
        self.title.setText(game.title)

        bits = [game.source.upper()]
        if game.engine:
            bits.append(f"moteur {game.engine}")
        if game.size_gb:
            bits.append(f"{game.size_gb} Go")
        self.subtitle.setText("  ·  ".join(bits))

        clear_layout(self.meta_grid)
        self.store_btn.setVisible(bool(self._store_url(game)))
        rows = [
            ("Temps de jeu", self._playtime(game)),
            ("Derniere partie", self._last_played(game)),
            ("Etat", "Mise a jour en attente" if game.update_pending
             else ("Fichiers manquants" if game.extra.get("missing") else "Pret")),
            ("Emplacement", game.install_dir or "-"),
        ]
        from ..widgets.succes_panel import _Coupe
        for i, (k, v) in enumerate(rows):
            kl = QLabel(k)
            kl.setObjectName("Key")
            if k == "Emplacement":
                # coupe a la largeur disponible : la fiche ne deborde jamais
                vl = _Coupe(v)
                vl.setToolTip(v)
            else:
                vl = QLabel(v)
            vl.setObjectName("Value")
            vl.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            self.meta_grid.addWidget(kl, i, 0)
            self.meta_grid.addWidget(vl, i, 1)

        size = self.cover.size()
        path = game.art_cover or ""
        pix = QPixmap(path) if path and Path(path).exists() else QPixmap()
        self.cover.setPixmap(rounded(pix, size) if not pix.isNull()
                             else placeholder(game.title, size, game.uid))

        self.hero.set_image(game.art_hero or game.art_cover or "")
        # infos, captures, actualites et succes du jeu precedent : effaces
        self.set_market_loading()
        self._resume_succes = {}
        self.succes.vider()
        self._remplir_infos()
        from ...core.liens import appid_steam
        appid = appid_steam(game)
        if not appid:
            # jeu installe hors Steam : la recherche des visuels a souvent
            # deja trouve sa fiche Steam. On s'en sert tout de suite, sans
            # attendre le releve complet du jeu (qui peut prendre une minute).
            try:
                from ...plugins.artwork.steam_cdn import appid_deja_trouve
                appid = appid_deja_trouve(game.title)
                if appid:
                    game.extra["steam_appid"] = appid
            except Exception:
                appid = ""
        from ...plugins.market.steam_store import SteamStoreProvider
        self.lecteur.definir_jeu(
            game, appid,
            en_recherche=not appid and not game.extra.get(SteamStoreProvider.MARQUEUR))
        self._rester_en_haut()                             # haut de la fiche
        if self.isVisible():
            self._lecteur_visible()
        self.fav.setChecked(game.favorite)
        self.fav.setText("Favori" if game.favorite else "Ajouter aux favoris")

    def _ancrer(self) -> None:
        """Garde les cartes de graphismes a la meme place a l'ecran pendant
        que la fiche se met a jour. 10 octobre (video de l'auteur) : un clic
        sur une carte faisait sauter la page, les blocs du dessous changeant
        de hauteur une fois les reglages ecrits.

        Seulement apres un clic sur les cartes (`_ancrer_apres_clic`). 15
        octobre (video de l'auteur, 0:05) : a l'ouverture d'une fiche, le plan
        arrive avant les captures et les videos ; les cartes, alors en haut
        d'une page encore courte, etaient ancrees la, et la page sautait
        jusqu'a elles des que les panneaux du dessus se remplissaient."""
        ancre = getattr(self, "choix", None)
        if not getattr(self, "_ancrer_apres_clic", False):
            return                                   # fiche qui se construit : rien a garder
        self._ancrer_apres_clic = False
        if ancre is None or not self.isVisible() or getattr(self, "_haut_jeton", None) is not None:
            return                                   # nouvelle fiche : elle reste en haut
        zone, barre = self.scroll.viewport(), self.scroll.verticalScrollBar()
        y0 = ancre.mapTo(zone, QPoint(0, 0)).y()
        if not (-ancre.height() < y0 < zone.height()):
            return                                   # cartes hors de l'ecran : rien a garder
        jeton = self._ancre_jeton = object()

        def recaler(j=jeton) -> None:
            if getattr(self, "_ancre_jeton", None) is not j:
                return
            ecart = ancre.mapTo(zone, QPoint(0, 0)).y() - y0
            if ecart:
                barre.setValue(barre.value() + ecart)
        for delai in (0, 60, 250):
            plus_tard(self, delai, recaler)

    def set_plan(self, plan: OptimizationPlan, settings: list[tuple[str, str]],
                 advice: list[Advice]) -> None:
        self._ancrer()
        self.plan = plan

        clear_layout(self.settings_grid)
        half = (len(settings) + 1) // 2
        for i, (k, v) in enumerate(settings):
            col = 0 if i < half else 2
            row = i if i < half else i - half
            kl = QLabel(k)
            kl.setObjectName("Key")
            vl = QLabel(v)
            vl.setObjectName("Value")
            self.settings_grid.addWidget(kl, row, col)
            self.settings_grid.addWidget(vl, row, col + 1)

        self.recipe_label.setText(
            f"{plan.recipe_name} · " + t(CORRESPONDANCES.get(plan.confidence,
                                                              "recette generique"))
            if plan.recipe_name else "")
        self.share_btn.setVisible(
            plan.confidence in ("exact", "moteur") and "la votre" in
            (plan.recipe_name or ""))

        changes = [o for o in plan.ops if o.changed]
        self.table.setRowCount(len(changes))
        from ...plugins.tweaks.xml_writer import ABSENT

        def lisible(v):
            if v is None:
                return t("absent")
            return t("par defaut du jeu") if str(v) == ABSENT else str(v)
        for r, op in enumerate(changes):
            for c, text in enumerate((t(op.label or op.key), lisible(op.current),
                                      lisible(op.value), Path(op.target).name)):
                item = QTableWidgetItem(text)
                if c == 3:
                    item.setToolTip(op.target)
                self.table.setItem(r, c, item)

        if changes:
            self.changes_title.setText(
                f"Modifications prevues dans le jeu ({len(changes)})")
            self.changes_hint.setText(
                "Une sauvegarde des fichiers concernes est creee avant toute "
                "ecriture ; « Redefinir les parametres par defaut » remet le jeu "
                "comme avant ORION.")
        else:
            self.changes_title.setText("Modifications prevues dans le jeu")
            self.changes_hint.setText(
                "Aucun fichier de configuration a modifier : ORION se limite au "
                "reglage de l'ecran et aux conseils ci-dessous.")
        self.table.setVisible(bool(changes))
        self._set_tunable(plan.tunable)

        clear_layout(self.advice_layout)
        if plan.guide:
            self.advice_layout.addWidget(self._carte_guide())
        for a in advice:
            self.advice_layout.addWidget(AdviceCard(a))
        for text in plan.advice:
            self.advice_layout.addWidget(
                AdviceCard(Advice("info", "A savoir", text)))

    def _carte_guide(self) -> QFrame:
        """ORION ne peut rien ecrire dans ce jeu : il propose la liste des
        reglages a faire soi-meme, en un clic."""
        carte = QFrame()
        carte.setObjectName("Panel")
        lay = QHBoxLayout(carte)
        lay.setContentsMargins(18, 14, 18, 14)
        lay.setSpacing(14)
        col = QVBoxLayout()
        col.setSpacing(4)
        titre = QLabel("Reglages a faire dans le jeu, car ORION n'y a pas acces")
        titre.setObjectName("PanelTitle")
        titre.setWordWrap(True)
        col.addWidget(titre)
        texte = QLabel("Ce jeu garde ses reglages pour lui. ORION vous montre "
                       "quoi choisir dans ses menus, ligne par ligne.")
        texte.setObjectName("Dim")
        texte.setWordWrap(True)
        col.addWidget(texte)
        lay.addLayout(col, 1)
        bouton = QPushButton("Voir les reglages")
        bouton.setObjectName("Primary")
        bouton.setCursor(Qt.CursorShape.PointingHandCursor)
        bouton.clicked.connect(self.ouvrir_guide)
        lay.addWidget(bouton)
        return carte

    def ouvrir_guide(self) -> None:
        if not self.plan or not self.plan.guide or not self.game:
            return
        from ..widgets.dialogues import DialogueGuide
        d = DialogueGuide(self.game.title, self.plan.guide, self)
        self.game.extra["guide_vu"] = True       # plus de rappel avant de jouer
        d.exec()
        if d.jouer:
            self.play_requested.emit(self.game.uid, self.profile_id)

    def _set_tunable(self, tunable: bool) -> None:
        """Affiche ou retire tout ce qui promet une optimisation du jeu.

        Un jeu qu'ORION ne sait pas regler reste entierement utilisable :
        il garde sa jaquette, son visuel et son bouton Jouer. Ce sont les
        profils graphiques, l'apercu des modifications et le bouton
        « Appliquer » qui disparaissent, parce qu'ils n'auraient rien a
        faire.
        """
        # l'etat du bloc Graphismes le dit deja (« pas encore pris en charge »)
        self.untunable.setVisible(False)
        if not tunable:
            self.untunable_text.setText(
                "ORION n'a trouve aucun fichier de reglages pour ce jeu : "
                "moteur maison, reglages stockes en ligne, ou configuration "
                "creee seulement apres une premiere partie.\n\n"
                "Le jeu se lance normalement, sans qu'ORION touche a quoi que "
                "ce soit. Lancez-le une fois, puis revenez ici : si le jeu a "
                "ecrit sa configuration entre-temps, les profils "
                "reapparaitront. L'assistant IA peut aussi tenter d'ecrire la "
                "recette a votre place.")
        for i in range(self.profiles_head.count()):
            widget = self.profiles_head.itemAt(i).widget()
            if widget is not None:
                widget.setVisible(tunable)
        # le bloc Graphismes reste visible : le niveau conseille sert aussi a
        # regler le jeu a la main (voir set_graphismes)
        self.settings_panel.setVisible(tunable)
        self.changes_panel.setVisible(tunable)

    # ------------------------------------------------------------------
    def set_graphismes(self, donnees: dict) -> None:
        """`donnees` : `optimizer.profiles.donnees_fiche(game, hw, ecran, plan)`."""
        self._ancrer()
        self.choix.set_donnees(donnees)

    def _choix_fait(self, niveau: str, cible: int) -> None:
        """Une carte cliquee : la fenetre ecrit les reglages de ce choix."""
        self.profile_id = "recommande"
        self._haut_jeton = None       # un clic sur une carte : le joueur a pris la main
        self._ancrer_apres_clic = True
        if self.game:
            self.choix_requested.emit(self.game.uid, str(niveau), int(cible))

    def _sr_cliquee(self, carte: str, coche: bool) -> None:
        self._haut_jeton = None       # un clic sur une carte : le joueur a pris la main
        self._ancrer_apres_clic = True
        if self.game:
            self.sr_requested.emit(self.game.uid, str(carte), bool(coche))

    def _defaut_cliquee(self) -> None:
        self._haut_jeton = None       # un clic sur une carte : le joueur a pris la main
        self._ancrer_apres_clic = True
        if self.game:
            self.defaut_requested.emit(self.game.uid)

    def _emit_profile(self) -> None:
        if self.game:
            self.profile_changed.emit(self.game.uid, self.profile_id)

    @staticmethod
    def _store_url(game: Game) -> str:
        """Adresse de la fiche boutique du jeu, selon sa plateforme."""
        from ...core.liens import page_magasin
        return page_magasin(game)

    def _open_store(self) -> None:
        if not self.game:
            return
        url = self._store_url(self.game)
        if url:
            ouvrir_lien(url)

    # -- infos du jeu (releve « marche ») -------------------------------
    def set_market(self, info: MarketInfo) -> None:
        """Affiche les infos du jeu (studio, sortie, avis...), ses captures et
        ses actualites. Les prix ne sont plus montres : le jeu est possede."""
        self.market = info
        self._remplir_infos()
        self._fill_news(info)
        # identifiant Steam retrouve par le releve (jeu installe hors Steam)
        if self.game is not None:
            from ...core.liens import appid_steam
            from ...plugins.market.steam_store import SteamStoreProvider
            self.lecteur.definir_appid(
                appid_steam(self.game),
                cherche=bool(self.game.extra.get(SteamStoreProvider.MARQUEUR)))
            # apres le releve : la fiche Steam vient de nommer les DLC du jeu
            self._charger_dlc()

    def _fill_news(self, info: MarketInfo) -> None:
        clear_layout(self.news_box)
        for entry in (info.news or [])[:5]:
            self.news_box.addWidget(ActuCarte(entry))
        self.news_panel.setVisible(bool(info.news))

        captures = list(getattr(info, "screenshots", None) or [])
        self.shots.set_captures(captures)
        # pas de captures : on dit pourquoi (jeu absent de Steam...) au lieu
        # de laisser un vide
        note = getattr(info, "captures_note", "") or ""
        self.shots.setVisible(bool(captures))
        self.shots_hint.setText("Cliquez pour agrandir  ·  fleches pour defiler"
                                if captures else note)
        self.shots_panel.setVisible(bool(captures or note))

    def set_market_loading(self) -> None:
        """Vide tout ce qui appartient au jeu precedent."""
        self.market = None
        clear_layout(self.infos_grid)
        clear_layout(self.news_box)
        self.news_panel.setVisible(False)
        self.shots.set_captures([])
        self.shots_panel.setVisible(False)
        self.market_note.setText("Recuperation des informations du jeu...")
        self.market_note.setVisible(True)
        if self._resume_succes:
            self._remplir_infos()

    def set_ai_output(self, text: str, busy: bool = False) -> None:
        self.ai_output.setText(text)
        self.ai_output.setVisible(bool(text))
        self.ai_state.setText("Interrogation en cours..." if busy else "")

    def _open_folder(self) -> None:
        if not self.game:
            return
        target = self.game.install_dir or str(Path(self.game.executable).parent)
        if not target or not Path(target).exists():
            return
        try:
            if is_windows():
                from ...core.lancement import startfile_propre
                startfile_propre(target)
            else:
                import subprocess
                subprocess.Popen(["xdg-open", target])
        except Exception:
            pass

    @staticmethod
    def _format_duration(seconds: int) -> str:
        if seconds < 60:
            return "moins d'une minute"
        if seconds < 3600:
            return f"{seconds // 60} minutes"
        return f"{seconds // 3600} h {(seconds % 3600) // 60:02d}"

    @classmethod
    def _playtime(cls, game: Game) -> str:
        total = game.total_play_seconds
        if total < 60:
            return "Aucune partie enregistree"
        text = cls._format_duration(total)
        if game.external_seconds and game.play_seconds >= 60:
            text += (f"   (dont {cls._format_duration(game.play_seconds)} "
                     "via ORION)")
        elif game.external_seconds:
            source = {"steam": "Steam"}.get(game.source, game.source.capitalize())
            text += f"   (releve {source})"
        return text

    @staticmethod
    def _last_played(game: Game) -> str:
        if not game.last_played:
            return "-"
        return time.strftime("%d/%m/%Y a %H:%M", time.localtime(game.last_played))


class FicheBandeau(QFrame):
    """Bandeau du haut de la fiche : le visuel du jeu en fond, assombri
    vers la gauche pour que le titre et les boutons restent lisibles."""

    RAYON = 14

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("FicheBandeau")
        self._pix = QPixmap()
        self._chemin = ""
        self._cache: tuple = ()

    def set_image(self, chemin: str) -> None:
        if chemin == self._chemin:
            return
        self._chemin = chemin
        pix = QPixmap(chemin) if chemin and Path(chemin).exists() else QPixmap()
        self._pix = pix
        self._cache = ()
        self.update()

    def paintEvent(self, _event) -> None:           # noqa: N802
        from PySide6.QtCore import QRectF
        from PySide6.QtGui import QColor, QLinearGradient, QPainter, QPainterPath
        from ..theme import PALETTE
        w, h = self.width(), self.height()
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        cadre = QPainterPath()
        cadre.addRoundedRect(QRectF(0, 0, w, h), self.RAYON, self.RAYON)
        p.setClipPath(cadre)
        p.fillRect(self.rect(), QColor(PALETTE["bg_alt"]))
        if not self._pix.isNull():
            if not self._cache or self._cache[0] != (w, h):
                image = self._pix.scaled(QSize(w, h), Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                                         Qt.TransformationMode.SmoothTransformation)
                self._cache = ((w, h), image)
            image = self._cache[1]
            # cadrage sur le haut-droit : c'est la que se trouvent les visuels
            p.setOpacity(0.75)
            p.drawPixmap(w - image.width(), int((h - image.height()) * 0.35), image)
            p.setOpacity(1.0)
        voile = QLinearGradient(0, 0, w, 0)
        voile.setColorAt(0.0, QColor(10, 13, 20, 248))
        voile.setColorAt(0.4, QColor(10, 13, 20, 205))
        voile.setColorAt(1.0, QColor(10, 13, 20, 70))
        p.fillRect(self.rect(), voile)
        bas = QLinearGradient(0, 0, 0, h)
        bas.setColorAt(0.6, QColor(10, 13, 20, 0))
        bas.setColorAt(1.0, QColor(10, 13, 20, 140))
        p.fillRect(self.rect(), bas)
        p.setClipping(False)
        p.setPen(QColor(255, 255, 255, 20))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRoundedRect(QRectF(0.5, 0.5, w - 1, h - 1), self.RAYON, self.RAYON)
        p.end()


class ActuCarte(QFrame):
    """Une actualite : traduite en francais, repliee sur quelques lignes,
    depliable en entier, avec l'original a portee de clic."""

    APERCU = 420          # caracteres montres replies

    def __init__(self, entry: dict, parent=None) -> None:
        super().__init__(parent)
        self.entry = entry
        self.deplie = False
        self.original = False
        self.setObjectName("Advice")
        self.setProperty("level", "info")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(16, 12, 16, 12)
        lay.setSpacing(6)

        tete = QHBoxLayout()
        self.titre = QLabel()
        self.titre.setObjectName("Value")
        self.titre.setWordWrap(True)
        self.titre.setStyleSheet("font-size:14px; font-weight:700;")
        tete.addWidget(self.titre, 1)
        infos = []
        if entry.get("date"):
            infos.append(time.strftime("%d/%m/%Y", time.localtime(entry["date"])))
        if entry.get("source"):
            infos.append(str(entry["source"]))
        date = QLabel("  ·  ".join(infos))
        date.setObjectName("Faint")
        tete.addWidget(date, 0, Qt.AlignmentFlag.AlignTop)
        lay.addLayout(tete)

        self.corps = QLabel()
        self.corps.setObjectName("Dim")
        self.corps.setWordWrap(True)
        self.corps.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        lay.addWidget(self.corps)

        bas = QHBoxLayout()
        bas.setSpacing(8)
        self.bouton_tout = QPushButton("Afficher tout")
        self.bouton_tout.setObjectName("Ghost")
        self.bouton_tout.clicked.connect(self._basculer)
        bas.addWidget(self.bouton_tout)
        self.bouton_vo = QPushButton("Voir l'original")
        self.bouton_vo.setObjectName("Ghost")
        self.bouton_vo.setToolTip("Texte tel que publie par le studio")
        self.bouton_vo.clicked.connect(self._langue)
        self.bouton_vo.setVisible(bool(entry.get("traduit")))
        bas.addWidget(self.bouton_vo)
        bas.addStretch(1)
        if entry.get("traduit"):
            note = QLabel("Traduit automatiquement")
            note.setObjectName("Faint")
            bas.addWidget(note)
        if entry.get("url"):
            lien = QPushButton("Ouvrir sur Steam")
            lien.setObjectName("Ghost")
            lien.clicked.connect(lambda _=False, u=entry["url"]: ouvrir_lien(u))
            bas.addWidget(lien)
        lay.addLayout(bas)
        self._rendre()

    def _texte(self) -> tuple[str, str]:
        e = self.entry
        if self.original or not e.get("traduit"):
            return e.get("title", ""), e.get("body") or e.get("summary", "")
        return (e.get("title_fr") or e.get("title", ""),
                e.get("body_fr") or e.get("body") or e.get("summary", ""))

    def _rendre(self) -> None:
        titre, corps = self._texte()
        # les studios repetent souvent le titre en premiere ligne du texte
        premiere, _, reste = corps.partition("\n")
        if premiere.strip().casefold() == titre.strip().casefold() and reste:
            corps = reste.strip()
        self.titre.setText(titre)
        long_ = len(corps) > self.APERCU
        if long_ and not self.deplie:
            coupe = corps.rfind(" ", 0, self.APERCU)
            corps = corps[:coupe if coupe > 0 else self.APERCU].rstrip() + " …"
        self.corps.setText(corps)
        self.bouton_tout.setVisible(long_)
        self.bouton_tout.setText("Reduire" if self.deplie else "Afficher tout")
        self.bouton_vo.setText("Voir en francais" if self.original
                               else "Voir l'original")

    def _basculer(self) -> None:
        self.deplie = not self.deplie
        self._rendre()

    def _langue(self) -> None:
        self.original = not self.original
        self._rendre()
