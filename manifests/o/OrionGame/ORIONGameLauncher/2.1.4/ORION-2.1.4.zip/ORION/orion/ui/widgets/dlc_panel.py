"""Panneau des DLC d'un jeu : ceux deja acquis, et les autres au meilleur prix.

Le meme panneau sert dans la fiche d'un jeu de la Boutique et dans la page
d'un jeu de la bibliotheque. Il se charge en arriere-plan (`dlc.pour_jeu`) et
n'affirme « deja acquis » que pour un DLC trouve dans les fichiers du client
Steam de ce PC ; quand ces fichiers sont illisibles, il le dit.
"""
from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (QFrame, QHBoxLayout, QLabel, QPushButton, QSizePolicy,
                               QVBoxLayout)

from ... import dlc as service
from ...affiliation import est_partenaire, ouvreur
from ...i18n import t
from ..theme import PALETTE
from .boutique_cartes import euros
from .layouts import clear_layout

TITRE = "Contenus additionnels (DLC)"
PARTENAIRE = ("Lien partenaire : votre prix ne change pas, une petite "
              "commission finance ORION.")
#: les licences sont celles que Steam connaissait a son dernier lancement sur
#: ce PC : un DLC achete depuis ailleurs n'y figure qu'apres avoir ouvert Steam
NOTE = ("DLC de la version Steam du jeu. « Deja acquis » : d'apres le client "
        "Steam de ce PC, a son dernier lancement.")
#: plusieurs comptes Steam ont servi sur ce PC : le client Steam garde les
#: licences de tous, ORION ne peut pas dire a qui elles sont
NOTE_COMPTES = ("DLC de la version Steam du jeu. « Deja acquis » : d'apres le client "
                "Steam de ce PC a son dernier lancement, tous comptes Steam confondus.")
NON_VERIFIE = ("ORION n'a pas pu lire vos licences Steam sur ce PC : verifiez "
               "dans Steam avant d'acheter un DLC.")
NOTE_SANS_STEAM = "DLC de la version Steam du jeu."
INDISPONIBLE = "Steam ne repond pas pour le moment : reessayez plus tard."
AUCUN = "Ce jeu n'a pas de DLC sur Steam."
#: au-dela, les DLC suivants sont replies derriere un bouton
VISIBLES = 8


def chercher_dlc(appid: str):
    """Recherche lancee en arriere-plan par le panneau (remplacee par les
    tests : jamais d'appel a Steam pendant les tests)."""
    return service.pour_jeu(appid)


def _pastille(texte: str, couleur: str) -> QLabel:
    lab = QLabel(texte)
    lab.setStyleSheet(
        f"color:{couleur}; font-size:10.5px; font-weight:700; letter-spacing:.5px;"
        f" border:1px solid {couleur}; border-radius:4px; padding:2px 7px;")
    return lab


class DlcLigne(QFrame):
    """Un DLC : son nom, puis « deja acquis » ou son meilleur prix."""

    def __init__(self, d, ouvrir=None, parent=None) -> None:
        super().__init__(parent)
        self.dlc = d
        self._ouvrir = ouvrir or ouvreur("boutique")
        lay = QHBoxLayout(self)
        lay.setContentsMargins(10, 4, 6, 4)
        lay.setSpacing(12)

        nom = QLabel(d.nom)
        nom.setWordWrap(True)
        nom.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        nom.setMinimumWidth(180)
        nom.setStyleSheet(
            f"font-weight:600; color:{PALETTE['text_dim'] if d.acquis else PALETTE['text']};")
        lay.addWidget(nom, 1)
        if d.nature == "musique":
            genre = QLabel("Bande originale")
            genre.setObjectName("Faint")
            lay.addWidget(genre)

        self.etat = ""                      # lu par les tests
        self.bouton = None
        m = d.meilleure
        if d.acquis:
            self.etat = "Installe" if d.installe else "Deja acquis"
            lay.addWidget(_pastille(t(self.etat).upper(), PALETTE["ok"]),
                          0, Qt.AlignmentFlag.AlignVCenter)
            return
        if d.a_venir:
            self.etat = "A venir"
        elif d.gratuit:
            self.etat = "Gratuit"
        elif m is None:
            self.etat = "Non vendu seul"
        if self.etat:
            lab = QLabel(self.etat)
            lab.setObjectName("Faint")
            if self.etat == "Non vendu seul":
                lab.setToolTip("Ce DLC n'est vendu que dans un lot ou une edition du jeu.")
            lay.addWidget(lab)
            self._bouton(lay, "Obtenir" if d.gratuit and not d.a_venir else "Voir sur Steam",
                         service.PAGE.format(appid=d.appid), principal=False)
            return

        if m.remise:
            lay.addWidget(_pastille(f"-{m.remise} %", PALETTE["warn"]),
                          0, Qt.AlignmentFlag.AlignVCenter)
        chez = QLabel(f"chez {m.boutique}")
        chez.setObjectName("Faint")
        autres = [o for o in d.offres if o is not m]
        if autres:
            chez.setToolTip("\n".join(f"{o.boutique} : {euros(o.prix)}" for o in autres))
        lay.addWidget(chez)
        prix = QLabel(euros(m.prix))
        prix.setMinimumWidth(70)
        prix.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        prix.setStyleSheet(f"font-size:14px; font-weight:700; color:{PALETTE['ok']};")
        lay.addWidget(prix)
        self.etat = "A acheter"
        self._bouton(lay, "Acheter", m.url, principal=False)

    def _bouton(self, lay, texte: str, url: str, principal: bool) -> None:
        b = QPushButton(texte)
        b.setObjectName("Primary" if principal else "Ghost")
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        if est_partenaire(url):
            b.setToolTip(PARTENAIRE)
        b.clicked.connect(lambda: self._ouvrir(url))
        lay.addWidget(b)
        self.bouton, self.url = b, url


class PanneauDlc(QFrame):
    """Les DLC d'un jeu. `definir_jeu(appid)` lance la recherche."""

    contenu_change = Signal()            # le panneau a grandi ou retreci

    def __init__(self, parent=None, cadre: bool = True, cacher_si_vide: bool = False,
                 origine: str = "boutique", cartes: bool = False) -> None:
        super().__init__(parent)
        #: page d'un jeu : un encart de cartes illustrees (sinon : une liste)
        self.cartes = cartes
        self.setObjectName("Panel" if cadre else "PanelFlat")
        #: page d'ou viennent les clics (compteur anonyme des liens ouverts)
        self._ouvrir = ouvreur(origine)
        #: page d'un jeu de la bibliotheque : sans DLC, le panneau disparait
        self.cacher_si_vide = cacher_si_vide
        self.appid = ""
        self.resultat = None
        self._jeton = 0
        self._tout = False
        racine = QVBoxLayout(self)
        marge = (18, 16, 18, 16) if cadre else (6, 6, 6, 6)
        racine.setContentsMargins(*marge)
        racine.setSpacing(6)

        tete = QHBoxLayout()
        titre = QLabel(TITRE)
        titre.setObjectName("PanelTitle")
        tete.addWidget(titre)
        tete.addStretch(1)
        self.resume = QLabel("")
        self.resume.setObjectName("Faint")
        tete.addWidget(self.resume)
        racine.addLayout(tete)

        self.lignes = QVBoxLayout()
        self.lignes.setSpacing(2)
        racine.addLayout(self.lignes)
        self.rangee = None
        if cartes:
            from .cartes_animees import RangeeDlc
            self.rangee = RangeeDlc()
            self.rangee.cliquee.connect(self._carte_cliquee)
            self.rangee.hide()
            racine.addWidget(self.rangee)

        self.message = QLabel("")
        self.message.setObjectName("Faint")
        self.message.setWordWrap(True)
        racine.addWidget(self.message)
        self.alerte = QLabel(NON_VERIFIE)
        self.alerte.setWordWrap(True)
        self.alerte.setStyleSheet(f"color:{PALETTE['warn']}; font-size:11.5px;")
        self.alerte.hide()
        racine.addWidget(self.alerte)

        bas = QHBoxLayout()
        self.plus = QPushButton("")
        self.plus.setObjectName("Ghost")
        self.plus.clicked.connect(self._tout_montrer)
        self.plus.hide()
        bas.addWidget(self.plus)
        self.steam = QPushButton("")
        self.steam.setObjectName("Ghost")
        self.steam.clicked.connect(
            lambda: self.appid and self._ouvrir(service.PAGE_TOUS.format(appid=self.appid)))
        self.steam.hide()
        bas.addWidget(self.steam)
        bas.addStretch(1)
        racine.addLayout(bas)
        if cacher_si_vide:
            self.hide()

    # ------------------------------------------------------------------
    def vider(self) -> None:
        """Rien du jeu precedent ne doit rester a l'ecran."""
        self._jeton += 1
        self.appid, self.resultat, self._tout = "", None, False
        clear_layout(self.lignes)
        if self.rangee is not None:
            self.rangee.set_fiches([])
            self.rangee.hide()
        self.resume.setText("")
        self.message.setText("")
        self.alerte.hide()
        self.plus.hide()
        self.steam.hide()
        if self.cacher_si_vide:
            self.hide()
        self.contenu_change.emit()

    def definir_jeu(self, appid: str) -> None:
        """Cherche les DLC de ce jeu Steam (en arriere-plan). Redemander le
        meme jeu ne relance rien."""
        appid = str(appid or "").strip()
        if appid == self.appid and (self.resultat is not None or self._en_cours):
            return
        self.vider()
        if not appid.isdigit():
            return
        self.appid = appid
        self._en_cours = True
        self.message.setText("Recherche des DLC...")
        jeton = self._jeton
        from ...core.tasks import Task
        tache = Task(chercher_dlc, appid)
        tache.signals.finished.connect(lambda res, j=jeton: self._recu(res, j))
        tache.signals.failed.connect(lambda _e, j=jeton: self._recu(None, j))
        tache.start()

    _en_cours = False

    def _recu(self, res, jeton: int) -> None:
        if jeton != self._jeton:
            return                          # reponse d'un jeu deja quitte
        self._en_cours = False
        self.montrer(res)

    # ------------------------------------------------------------------
    def montrer(self, res) -> None:
        """Affiche un `dlc.Resultat` (aussi appele directement par les tests)."""
        self.resultat = res
        clear_layout(self.lignes)
        if self.rangee is not None:
            self.rangee.hide()
        self.plus.hide()
        self.steam.hide()
        self.alerte.hide()
        if res is None or res.indisponible:
            self.resume.setText("")
            self.message.setText(INDISPONIBLE)
            self._apparaitre(False)
            self.contenu_change.emit()
            return
        if not res.dlc:
            self.resume.setText("")
            self.message.setText(AUCUN)
            self._apparaitre(False)
            self.contenu_change.emit()
            return
        self._apparaitre(True)
        n, acquis = len(res.dlc) + res.autres, res.acquis
        self.resume.setText(f"{n} DLC  ·  {acquis} deja acquis" if acquis else f"{n} DLC")
        if self.rangee is not None:
            # encart illustre : toutes les cartes, la rangee defile
            self.rangee.set_fiches(res.dlc)
            self.rangee.show()
            montres = res.dlc
        else:
            montres = res.dlc if self._tout else res.dlc[:VISIBLES]
            for d in montres:
                self.lignes.addWidget(DlcLigne(d, self._ouvrir))
        caches = len(res.dlc) - len(montres)
        if caches > 0:
            self.plus.setText(f"Afficher les {caches} autres DLC")
            self.plus.show()
        if res.autres > 0:
            self.steam.setText(f"Voir les {res.autres} autres sur Steam")
            self.steam.show()
        # sans client Steam sur ce PC, il n'y a pas de licence a lire : rien
        # d'inquietant a signaler
        note = NOTE_COMPTES if getattr(res, "comptes", 0) > 1 else NOTE
        self.message.setText(note if res.verifie else ("" if res.client else NOTE_SANS_STEAM))
        self.alerte.setVisible(res.client and not res.verifie)
        self.contenu_change.emit()

    def _apparaitre(self, oui: bool) -> None:
        """Dans la page d'un jeu, le panneau n'existe que s'il a des DLC a
        montrer ; dans la Boutique, c'est le bouton « DLC » qui l'ouvre."""
        if self.cacher_si_vide:
            self.setVisible(oui)

    @staticmethod
    def lien(d) -> str:
        """Ou mene un clic sur ce DLC : sa meilleure offre, sinon sa page
        Steam ; nulle part s'il est deja acquis."""
        if d.acquis:
            return ""
        m = d.meilleure
        return m.url if m is not None else service.PAGE.format(appid=d.appid)

    def _carte_cliquee(self, d) -> None:
        url = self.lien(d)
        if url:
            self._ouvrir(url)

    def _tout_montrer(self) -> None:
        self._tout = True
        self.montrer(self.resultat)
