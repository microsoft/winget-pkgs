"""Client IA multi-fournisseur, entierement optionnel.

ORION fonctionne sans IA. Si l'utilisateur colle une cle dans les reglages,
l'assistant devient disponible pour les taches ou une IA apporte vraiment
quelque chose : apprendre a regler un jeu inconnu, expliquer une contre-
performance, conseiller un achat.

Ajouter un fournisseur = ajouter une entree dans `PROVIDERS` et une methode
de requete : rien d'autre dans l'application n'a besoin de changer.
"""
from __future__ import annotations

import json
from dataclasses import dataclass

from ..core.config import CONFIG
from ..core.logging_setup import get

log = get("ia")


@dataclass
class Provider:
    id: str
    label: str
    default_model: str
    models: list[str]
    key_url: str
    needs_key: bool = True
    tutorial: str = ""


PROVIDERS: dict[str, Provider] = {
    "anthropic": Provider(
        id="anthropic", label="Claude (Anthropic)",
        default_model="claude-sonnet-4-5",
        models=["claude-opus-4-1", "claude-sonnet-4-5", "claude-haiku-4-5"],
        key_url="https://console.anthropic.com/settings/keys",
        tutorial=(
            "1. Ouvrez console.anthropic.com et creez un compte.\n"
            "2. Menu Settings puis API keys, bouton Create Key.\n"
            "3. Donnez-lui un nom (ORION) et copiez la cle : elle commence "
            "par sk-ant- et ne sera plus affichee ensuite.\n"
            "4. Ajoutez quelques euros de credit dans Billing : la facturation "
            "est a l'usage, quelques centimes suffisent pour des centaines de "
            "conseils.\n"
            "5. Collez la cle ci-dessous et cliquez sur Tester."),
    ),
    "openai": Provider(
        id="openai", label="ChatGPT (OpenAI)",
        default_model="gpt-4.1-mini",
        models=["gpt-4.1", "gpt-4.1-mini", "gpt-4o-mini"],
        key_url="https://platform.openai.com/api-keys",
        tutorial=(
            "1. Ouvrez platform.openai.com et connectez-vous.\n"
            "2. Menu API keys puis Create new secret key.\n"
            "3. Copiez la cle (elle commence par sk-) : elle n'est montree "
            "qu'une fois.\n"
            "4. Onglet Billing : ajoutez un moyen de paiement et un petit "
            "credit, sinon les appels sont refuses.\n"
            "5. Collez la cle ci-dessous et cliquez sur Tester."),
    ),
    "google": Provider(
        id="google", label="Gemini (Google)",
        default_model="gemini-2.5-flash",
        models=["gemini-2.5-pro", "gemini-2.5-flash"],
        key_url="https://aistudio.google.com/app/apikey",
        tutorial=(
            "1. Ouvrez aistudio.google.com/app/apikey avec un compte Google.\n"
            "2. Cliquez sur Create API key, puis choisissez un projet.\n"
            "3. Copiez la cle affichee.\n"
            "4. Le niveau gratuit suffit largement pour ORION (quelques "
            "requetes par minute).\n"
            "5. Collez la cle ci-dessous et cliquez sur Tester."),
    ),
    "mistral": Provider(
        id="mistral", label="Mistral (France)",
        default_model="mistral-small-latest",
        models=["mistral-large-latest", "mistral-small-latest"],
        key_url="https://console.mistral.ai/api-keys/",
        tutorial=(
            "1. Ouvrez console.mistral.ai et creez un compte.\n"
            "2. Menu API Keys puis Create new key.\n"
            "3. Copiez la cle.\n"
            "4. Le plan gratuit Experiment permet de tester sans carte "
            "bancaire.\n"
            "5. Collez la cle ci-dessous et cliquez sur Tester."),
    ),
    "ollama": Provider(
        id="ollama", label="Ollama (modele local, sans cle)",
        default_model="llama3.1",
        models=["llama3.1", "qwen2.5", "mistral", "phi4"],
        key_url="https://ollama.com/download",
        needs_key=False,
        tutorial=(
            "1. Installez Ollama depuis ollama.com/download.\n"
            "2. Dans un terminal : ollama pull llama3.1\n"
            "3. Laissez Ollama tourner en arriere-plan (icone dans la barre "
            "des taches).\n"
            "4. Aucune cle n'est necessaire : tout reste sur votre PC, "
            "gratuitement et hors ligne.\n"
            "5. Indiquez simplement le nom du modele ci-dessous puis Tester."),
    ),
}

ORDER = ["anthropic", "openai", "google", "mistral", "ollama"]

SYSTEM_PROMPT = (
    "Tu es l'assistant technique integre a ORION, un launcher de jeux PC. "
    "Tu reponds en francais, de maniere concise et concrete, sans formule de "
    "politesse inutile. Tu t'adresses a un joueur qui connait son materiel. "
    "Quand on te demande un fichier ou du JSON, tu ne renvoies que ce contenu, "
    "sans commentaire autour."
)


class AIClient:
    """Envoie une requete au fournisseur configure."""

    def __init__(self) -> None:
        self.provider_id = str(CONFIG.get("ai.provider") or "anthropic")
        self.api_key = str(CONFIG.get("ai.api_key") or "").strip()
        self.model = str(CONFIG.get("ai.model") or "").strip()
        self.endpoint = str(CONFIG.get("ai.ollama_url")
                            or "http://localhost:11434").rstrip("/")

    # ------------------------------------------------------------------
    @property
    def provider(self) -> Provider:
        return PROVIDERS.get(self.provider_id, PROVIDERS["anthropic"])

    def configured(self) -> bool:
        p = self.provider
        return bool(self.api_key) or not p.needs_key

    def ask(self, prompt: str, max_tokens: int = 1200) -> tuple[bool, str]:
        """Retourne (succes, reponse ou message d'erreur)."""
        if not self.configured():
            return False, ("Aucune cle d'IA enregistree : ouvrez Reglages puis "
                           "Assistant IA.")
        model = self.model or self.provider.default_model
        try:
            method = getattr(self, f"_ask_{self.provider.id}")
            return method(prompt, model, max_tokens)
        except Exception as exc:
            log.exception("Appel IA en echec")
            return False, f"Appel impossible : {exc}"

    # -- implementations par fournisseur --------------------------------
    def _ask_anthropic(self, prompt: str, model: str, max_tokens: int):
        from orion.core import reseau
        r = reseau.post(
            "https://api.anthropic.com/v1/messages",
            headers={"x-api-key": self.api_key,
                     "anthropic-version": "2023-06-01",
                     "content-type": "application/json"},
            json={"model": model, "max_tokens": max_tokens,
                  "system": SYSTEM_PROMPT,
                  "messages": [{"role": "user", "content": prompt}]},
            timeout=90)
        if r.status_code != 200:
            return False, self._http_error(r)
        blocks = (r.json() or {}).get("content") or []
        text = "".join(b.get("text", "") for b in blocks if b.get("type") == "text")
        return bool(text), text or "Reponse vide."

    def _ask_openai(self, prompt: str, model: str, max_tokens: int):
        from orion.core import reseau
        r = reseau.post(
            "https://api.openai.com/v1/chat/completions",
            headers={"Authorization": f"Bearer {self.api_key}",
                     "Content-Type": "application/json"},
            json={"model": model, "max_tokens": max_tokens,
                  "messages": [{"role": "system", "content": SYSTEM_PROMPT},
                               {"role": "user", "content": prompt}]},
            timeout=90)
        if r.status_code != 200:
            return False, self._http_error(r)
        choices = (r.json() or {}).get("choices") or []
        text = (choices[0].get("message") or {}).get("content", "") if choices else ""
        return bool(text), text or "Reponse vide."

    def _ask_google(self, prompt: str, model: str, max_tokens: int):
        from orion.core import reseau
        url = (f"https://generativelanguage.googleapis.com/v1beta/models/"
               f"{model}:generateContent")
        r = reseau.post(
            url, params={"key": self.api_key},
            json={"system_instruction": {"parts": [{"text": SYSTEM_PROMPT}]},
                  "contents": [{"parts": [{"text": prompt}]}],
                  "generationConfig": {"maxOutputTokens": max_tokens}},
            timeout=90)
        if r.status_code != 200:
            return False, self._http_error(r)
        cands = (r.json() or {}).get("candidates") or []
        parts = ((cands[0].get("content") or {}).get("parts") or []) if cands else []
        text = "".join(p.get("text", "") for p in parts)
        return bool(text), text or "Reponse vide."

    def _ask_mistral(self, prompt: str, model: str, max_tokens: int):
        from orion.core import reseau
        r = reseau.post(
            "https://api.mistral.ai/v1/chat/completions",
            headers={"Authorization": f"Bearer {self.api_key}",
                     "Content-Type": "application/json"},
            json={"model": model, "max_tokens": max_tokens,
                  "messages": [{"role": "system", "content": SYSTEM_PROMPT},
                               {"role": "user", "content": prompt}]},
            timeout=90)
        if r.status_code != 200:
            return False, self._http_error(r)
        choices = (r.json() or {}).get("choices") or []
        text = (choices[0].get("message") or {}).get("content", "") if choices else ""
        return bool(text), text or "Reponse vide."

    def _ask_ollama(self, prompt: str, model: str, max_tokens: int):
        from orion.core import reseau
        r = reseau.post(
            f"{self.endpoint}/api/chat",
            json={"model": model, "stream": False,
                  "options": {"num_predict": max_tokens},
                  "messages": [{"role": "system", "content": SYSTEM_PROMPT},
                               {"role": "user", "content": prompt}]},
            timeout=180)
        if r.status_code != 200:
            return False, (f"Ollama a repondu {r.status_code}. Verifiez qu'il "
                           "tourne et que le modele est telecharge.")
        text = ((r.json() or {}).get("message") or {}).get("content", "")
        return bool(text), text or "Reponse vide."

    # ------------------------------------------------------------------
    @staticmethod
    def _http_error(response) -> str:
        try:
            data = response.json()
            message = (data.get("error") or {}).get("message") or json.dumps(data)[:300]
        except Exception:
            message = (response.text or "")[:300]
        hints = {
            401: "cle refusee : verifiez qu'elle est complete et active",
            403: "acces refuse : la cle n'a pas les droits necessaires",
            404: "modele inconnu : choisissez-en un autre dans la liste",
            429: "trop de requetes ou credit epuise",
        }
        hint = hints.get(response.status_code, "")
        return f"Erreur {response.status_code}" + (f" ({hint})" if hint else "") \
            + f" : {message}"

    def test(self) -> tuple[bool, str]:
        ok, text = self.ask("Reponds exactement : liaison etablie.", 40)
        if ok:
            return True, f"Connexion reussie ({self.provider.label}) : {text.strip()[:80]}"
        return False, text
