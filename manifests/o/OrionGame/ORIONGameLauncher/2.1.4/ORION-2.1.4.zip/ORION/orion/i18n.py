"""Traduction de l'interface (anglais), sans toucher au code des pages.

Le francais reste la langue du code et la langue par defaut. Le code est
ecrit sans accents : le catalogue `langues/fr.json` les remet a l'ecran
(textes exacts, modeles, puis mots sans ambiguite pour le reste). Quand une
autre langue est choisie (Reglages > Langue), `activer()` intercepte les
fonctions de Qt qui posent un texte a l'ecran (libelles, boutons, cases,
infobulles, menus, listes, titres de fenetre, boites de dialogue...) et
remplace le texte francais par sa traduction :

* **correspondance exacte** : `langues/<code>.json`, rubrique « exact » ;
* **modeles** : pour les textes construits a la volee (« 12 jeux
  detectes »), la rubrique « modeles » associe « {0} jeux detectes » a
  « {0} games detected ». Les morceaux variables sont eux-memes traduits
  s'ils figurent au catalogue (noms de pages, de profils...) ;
* **par lignes** : un texte de plusieurs paragraphes absent du catalogue
  est traduit paragraphe par paragraphe.

Un texte inconnu reste en francais : rien ne casse, il manque seulement
une traduction. `manquants()` liste ces textes (journal de debogage).

Le catalogue est genere a partir du code (outil `outils/extraire_textes.py`)
puis traduit : ajouter une langue, c'est ajouter un fichier JSON.
"""
from __future__ import annotations

import json
import re
from functools import lru_cache
from pathlib import Path

from .core.logging_setup import get

log = get("i18n")

def _dossier() -> Path:
    from .core.paths import ROOT_DIR
    return ROOT_DIR / "orion" / "langues"


DOSSIER = _dossier()
LANGUES = {"fr": "Français", "en": "English"}

_exact: dict[str, str] = {}
_modeles: list[tuple[re.Pattern, str, int, bool]] = []
#: francais : mots sans ambiguite a accentuer dans un texte absent du catalogue
_mots: dict[str, str] = {}
_MOT = re.compile(r"(?<![A-Za-zÀ-ÿ])[A-Za-z]{3,}(?![A-Za-zÀ-ÿ])")
_actif = False
_manquants: set[str] = set()


def langue() -> str:
    try:
        from .core.config import CONFIG
        return str(CONFIG.get("langue", "fr") or "fr")
    except Exception:
        return "fr"


def charger(code: str) -> bool:
    """Charge le catalogue d'une langue. Faux si absent."""
    global _exact, _modeles, _mots
    fichier = DOSSIER / f"{code}.json"
    try:
        donnees = json.loads(fichier.read_text("utf-8"))
    except Exception:
        log.warning("Catalogue de langue introuvable : %s", fichier.name)
        return False
    _exact = {k: v for k, v in (donnees.get("exact") or {}).items() if v}
    _mots = {k: v for k, v in (donnees.get("mots") or {}).items() if v}
    # titres affiches en capitales (rubriques du Tuto...)
    for fr, en in list(_exact.items()):
        _exact.setdefault(fr.upper(), en.upper())
    _modeles = []
    for fr, en in (donnees.get("modeles") or {}).items():
        if not en:
            continue
        morceaux = re.split(r"(\{\d+\})", fr)
        motif = "".join(f"(?P<g{m[1:-1]}>.+?)" if re.fullmatch(r"\{\d+\}", m)
                        else re.escape(m) for m in morceaux)
        fixe = re.sub(r"\{\d+\}", "", fr)
        lettres = re.sub(r"[^A-Za-zÀ-ÿ0-9]", "", fixe)
        # modele d'un ou deux caracteres (« {0} a {1} » pour « 72 a 99 ») :
        # il ne vaut que pour des valeurs chiffrees, voir `traduire`
        chiffres_seuls = 0 < len(lettres) <= 2 and bool(re.search(r"[A-Za-zÀ-ÿ]", lettres))
        try:
            _modeles.append((re.compile(f"^{motif}$", re.S), en, len(fixe), chiffres_seuls,
                             morceaux[0] if not re.fullmatch(r"\{\d+\}", morceaux[0]) else ""))
        except re.error:
            continue
    # le modele le plus precis (le plus de texte fixe) est essaye en premier
    _modeles.sort(key=lambda m: -m[2])
    _indexer_modeles()
    traduire.cache_clear()
    return True


#: modeles ranges par leurs deux premiers caracteres fixes : un texte
#: n'est confronte qu'aux modeles qui peuvent commencer comme lui. Sans cet
#: index, chaque texte inconnu etait essaye contre les six cents modeles
#: (quatre-vingts millisecondes pour trente lignes de jeux gratuits).
_PREFIXE = 2
_par_prefixe: dict[str, list] = {}
_generiques: list = []


def _indexer_modeles() -> None:
    global _par_prefixe, _generiques
    _par_prefixe, _generiques = {}, []
    for rang, modele in enumerate(_modeles):
        debut = modele[4]
        if len(debut) >= _PREFIXE:
            _par_prefixe.setdefault(debut[:_PREFIXE], []).append((rang, modele))
        else:
            _generiques.append((rang, modele))


def _candidats(texte: str):
    """Les modeles qui peuvent correspondre a `texte`, du plus precis au
    moins precis."""
    if not _modeles:
        return []
    cibles = _par_prefixe.get(texte[:_PREFIXE])
    if not cibles:
        return [m for _r, m in _generiques]
    import heapq
    return [m for _r, m in heapq.merge(cibles, _generiques, key=lambda x: x[0])]


@lru_cache(maxsize=8000)
def traduire(texte: str) -> str:
    """Traduction d'un texte d'interface (inchange si inconnu)."""
    if not texte or not _exact and not _modeles:
        return texte
    trouve = _exact.get(texte)
    if trouve is not None:
        return trouve
    nu = texte.strip()
    if nu != texte and nu:
        t = _exact.get(nu)
        if t is not None:
            debut = texte[:len(texte) - len(texte.lstrip())]
            fin = texte[len(texte.rstrip()):]
            return debut + t + fin
    multiligne = "\n" in texte
    for motif, en, _, chiffres_seuls, _debut in _candidats(texte):
        # un texte de plusieurs lignes n'est confie qu'a un modele qui en a
        # lui-meme plusieurs ; sinon il est traduit ligne par ligne (plus bas)
        if multiligne and "\n" not in en:
            continue
        m = motif.match(texte)
        if m and chiffres_seuls and not all(
                len(v) <= 16 and re.search(r"\d", v) for v in m.groupdict().values()):
            # « {0} a {1} » lit « 72 a 99 », pas une phrase : sans cette garde,
            # un texte anglais deja traduit et repasse ici (« Add a game »)
            # devenait « Add to game », et en francais le verbe « a » prenait
            # un accent
            continue
        if m and any(_PHRASES.search(v) and m.end(nom) < len(texte)
                     for nom, v in m.groupdict().items()):
            # un « {0} » en tete ou au milieu ne doit pas avaler plusieurs
            # phrases (« {0} publie la derniere version... » happait tout le
            # detail d'un conseil) ; seul un dernier groupe peut porter la
            # suite du texte, traduite ensuite phrase par phrase
            continue
        if m:
            sortie = en
            for nom, valeur in m.groupdict().items():
                if valeur in _exact:
                    valeur = _exact[valeur]
                elif valeur != texte and len(valeur) < 200:
                    valeur = traduire(valeur)
                elif valeur != texte:
                    valeur = _par_phrases(valeur)     # un long reste : phrase par phrase
                sortie = sortie.replace("{" + nom[1:] + "}", valeur)
            return sortie
    if "\n" in texte:
        lignes = texte.split("\n")
        traduites = [traduire(l) if l.strip() else l for l in lignes]
        if traduites != lignes:
            return "\n".join(traduites)
    if " · " in texte or "  ·  " in texte:
        sep = "  ·  " if "  ·  " in texte else " · "
        bouts = texte.split(sep)
        tr = [traduire(b) for b in bouts]
        if tr != bouts:
            return sep.join(tr)
    phrases = _par_phrases(texte)
    if phrases != texte:
        return phrases
    if _mots:
        # francais : le code est ecrit sans accents ; un texte absent du
        # catalogue recoit au moins ceux de ses mots sans ambiguite. Seules
        # les phrases y ont droit : un titre de jeu (« Element 4 ») ou un
        # chemin de fichier ne doit jamais etre modifie.
        if _phrase(texte):
            return _MOT.sub(_accent, texte)
        return texte
    if len(_manquants) < 3000 and re.search(r"[A-Za-z]{3}", texte):
        _manquants.add(texte)
    return texte


_PHRASES = re.compile(r"(?<=[.!?]) (?=[A-ZÀ-Ü«(])")


def _par_phrases(texte: str) -> str:
    """Un texte compose de plusieurs phrases (le detail d'un conseil, bati
    de morceaux selon la machine) est traduit phrase par phrase : chaque
    phrase a son entree au catalogue, leurs combinaisons non."""
    if ". " not in texte and "! " not in texte and "? " not in texte:
        return texte
    parts = _PHRASES.split(texte)
    if len(parts) < 2:
        return texte
    tr = [traduire(p) if p.strip() else p for p in parts]
    return " ".join(tr) if tr != parts else texte


_OUTILS = re.compile(r"(?<![A-Za-zÀ-ÿ])(le|la|les|des|du|un|une|est|sont|pour|sur|dans|avec|"
                     r"vous|votre|vos|ce|cette|ces|pas|ne|que|qui|au|aux|en|et|ou)"
                     r"(?![A-Za-zÀ-ÿ])", re.I)


def _phrase(texte: str) -> bool:
    """Vrai pour une phrase francaise de l'interface (au moins quatre mots,
    dont deux mots-outils), faux pour un titre, un nom ou un chemin."""
    if "\\" in texte or "/" in texte or len(texte) > 600:
        return False
    if len(texte.split()) < 4:
        return False
    return len(_OUTILS.findall(texte)) >= 2


def _accent(m: re.Match) -> str:
    mot = m.group(0)
    trouve = _mots.get(mot.lower())
    if trouve is None:
        return mot
    if mot.isupper():
        return trouve.upper()
    if mot[0].isupper():
        return trouve[0].upper() + trouve[1:]
    return trouve


def t(texte: str) -> str:
    """A utiliser dans le code pour un texte hors des widgets Qt."""
    return traduire(texte) if _actif else texte


def manquants() -> list[str]:
    return sorted(_manquants)


def actif() -> bool:
    return _actif


# --------------------------------------------------------------------------
def _enrober_init(classe, position: int = 0) -> None:
    origine = classe.__init__

    def init(self, *args, **kwargs):
        if len(args) > position and isinstance(args[position], str):
            args = list(args)
            args[position] = traduire(args[position])
        elif "text" in kwargs and isinstance(kwargs["text"], str):
            kwargs["text"] = traduire(kwargs["text"])
        origine(self, *args, **kwargs)

    classe.__init__ = init


def _enrober_methode(classe, nom: str, positions: tuple[int, ...] = (0,)) -> None:
    origine = getattr(classe, nom, None)
    if origine is None:
        return

    def methode(self, *args, **kwargs):
        if args:
            args = list(args)
            for p in positions:
                if len(args) > p and isinstance(args[p], str):
                    args[p] = traduire(args[p])
        return origine(self, *args, **kwargs)

    setattr(classe, nom, methode)


def _enrober_statique(classe, nom: str, positions: tuple[int, ...]) -> None:
    origine = getattr(classe, nom, None)
    if origine is None:
        return

    def fonction(*args, **kwargs):
        args = list(args)
        for p in positions:
            if len(args) > p and isinstance(args[p], str):
                args[p] = traduire(args[p])
        return origine(*args, **kwargs)

    setattr(classe, nom, staticmethod(fonction))


def activer() -> bool:
    """Installe le catalogue de la langue choisie. En francais, il remet les
    accents : le code est ecrit sans, l'ecran les affiche."""
    global _actif
    code = langue()
    if _actif:
        return _actif
    if not charger(code):
        return False
    from PySide6.QtGui import QAction
    from PySide6.QtWidgets import (QAbstractButton, QCheckBox, QComboBox,
                                   QFileDialog, QGroupBox, QLabel, QLineEdit,
                                   QMenu, QMessageBox, QPlainTextEdit,
                                   QPushButton, QRadioButton, QTabWidget,
                                   QTableWidget, QTextEdit, QToolButton,
                                   QTreeWidget, QWidget, QProgressBar,
                                   QInputDialog)

    for classe in (QLabel, QPushButton, QCheckBox, QRadioButton, QGroupBox, QToolButton):
        _enrober_init(classe, 0)
    _enrober_init(QAction, 0)
    _enrober_init(QMenu, 0)
    _enrober_methode(QLabel, "setText")
    _enrober_methode(QAbstractButton, "setText")
    _enrober_methode(QGroupBox, "setTitle")
    _enrober_methode(QAction, "setText")
    _enrober_methode(QAction, "setToolTip")
    _enrober_methode(QMenu, "addAction")
    _enrober_methode(QMenu, "addMenu")
    _enrober_methode(QMenu, "setTitle")
    _enrober_methode(QWidget, "setToolTip")
    _enrober_methode(QWidget, "setWindowTitle")
    _enrober_methode(QLineEdit, "setPlaceholderText")
    _enrober_methode(QPlainTextEdit, "setPlaceholderText")
    _enrober_methode(QTextEdit, "setPlaceholderText")
    _enrober_methode(QComboBox, "addItem", (0, 1))
    _enrober_methode(QComboBox, "setItemText", (1,))
    _enrober_methode(QTabWidget, "addTab", (1, 2))
    _enrober_methode(QTabWidget, "setTabText", (1,))
    _enrober_methode(QProgressBar, "setFormat")
    _enrober_methode(QMessageBox, "setText")
    _enrober_methode(QMessageBox, "setInformativeText")

    origine_items = QComboBox.addItems
    QComboBox.addItems = lambda self, textes: origine_items(self, [traduire(x) for x in textes])
    for classe, nom in ((QTableWidget, "setHorizontalHeaderLabels"),
                        (QTreeWidget, "setHeaderLabels")):
        origine = getattr(classe, nom)
        setattr(classe, nom, (lambda o: lambda self, textes: o(
            self, [traduire(x) for x in textes]))(origine))

    for nom in ("question", "information", "warning", "critical"):
        _enrober_statique(QMessageBox, nom, (1, 2))
    for nom in ("getExistingDirectory", "getOpenFileName", "getSaveFileName"):
        _enrober_statique(QFileDialog, nom, (1,))
    for nom in ("getText", "getItem", "getInt"):
        _enrober_statique(QInputDialog, nom, (1, 2))

    _actif = True
    log.info("Interface traduite : %s (%d textes, %d modeles)",
             LANGUES.get(code, code), len(_exact), len(_modeles))
    return True
