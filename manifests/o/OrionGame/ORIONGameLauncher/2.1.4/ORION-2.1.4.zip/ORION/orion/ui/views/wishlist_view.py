"""Page « Envies » : les jeux suivis, leur prix, et le seuil qui alerte.

La recherche s'affiche en panneau sous le champ, jamais en menu surgissant :
un menu bloque la saisie, se peint avec le theme du systeme — donc en blanc
sur blanc ici — et ne montre ni jaquette ni prix. Le panneau, lui, reste
dans l'application, garde la main a l'utilisateur, et montre ce qu'il va
ajouter.
"""
from __future__ import annotations

from orion.core import region

from orion.affiliation import ouvreur  # liens de boutique (partenaires)

import time
from pathlib import Path

from PySide6.QtCore import QSize, Qt, QTimer, Signal
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (QDoubleSpinBox, QFrame, QHBoxLayout, QLabel,
                               QLineEdit, QProgressBar, QPushButton,
                               QVBoxLayout, QWidget)

from ...core.recherche import classer
from ...wishlist import WishItem
from ...i18n import t
from ..theme import PALETTE
from ..widgets.game_card import placeholder, rounded
from ..widgets.layouts import clear_layout
from ..defilement import ZoneDefilante

ouvrir_lien = ouvreur("envies")   # d'ou vient le clic (compteur anonyme)

COVER = QSize(76, 114)
SHOT = QSize(150, 70)


def _pastille(texte: str, couleur: str, fort: bool = False) -> QLabel:
    lab = QLabel(texte)
    lab.setStyleSheet(
        f"color:{couleur}; font-size:10.5px; font-weight:{'700' if fort else '600'};"
        f" letter-spacing:.5px; border:1px solid {couleur}; border-radius:4px;"
        " padding:2px 8px;")
    return lab


def _cover(chemin: str, titre: str, graine: str, taille: QSize) -> QLabel:
    vignette = QLabel()
    vignette.setFixedSize(taille)
    pix = QPixmap(chemin) if chemin and Path(chemin).exists() else QPixmap()
    vignette.setPixmap(rounded(pix, taille) if not pix.isNull()
                       else placeholder(titre, taille, graine))
    return vignette


class WishRow(QFrame):
    """Une ligne de la liste d'envies : visuel, prix, seuil, actions."""

    target_changed = Signal(str, float)
    remove_requested = Signal(str)

    def __init__(self, item: WishItem, parent=None) -> None:
        super().__init__(parent)
        self.item = item
        self.setObjectName("Panel")

        lay = QHBoxLayout(self)
        lay.setContentsMargins(16, 14, 16, 14)
        lay.setSpacing(18)

        from ...contenu_adulte import est_marque
        lay.addWidget(_cover("" if est_marque(item.appid) else item.art_cover,
                             item.title, item.appid, COVER))

        # -- identite et prix -------------------------------------------
        info = QVBoxLayout()
        info.setSpacing(7)

        tete = QHBoxLayout()
        tete.setSpacing(9)
        titre = QLabel(item.title)
        titre.setObjectName("Value")
        titre.setStyleSheet("font-size:16px;")
        tete.addWidget(titre)
        if item.cut:
            tete.addWidget(_pastille(f"-{item.cut} %", PALETTE["ok"], fort=True))
        if item.reached:
            tete.addWidget(_pastille("SEUIL ATTEINT", PALETTE["ok"], fort=True))
        tete.addStretch(1)
        info.addLayout(tete)

        # ligne des prix : le prix du moment est ce qu'on lit en premier
        prix = QHBoxLayout()
        prix.setSpacing(16)
        prix.addWidget(self._bloc_prix(
            region.prix(item.current_price) if item.current_price
            else ("A venir" if not item.last_check or not item.historical_low
                  else "—"),
            f"chez {item.best_shop}" if item.best_shop
            else ("pas encore en vente" if not item.historical_low
                  else "prix non releve"),
            PALETTE["ok"] if item.reached else PALETTE["text"], grand=True))
        if item.historical_low:
            prix.addWidget(self._bloc_prix(
                region.prix(item.historical_low), "plus bas connu",
                PALETTE["text_dim"]))
        if item.review_score:
            prix.addWidget(self._bloc_prix(
                f"{item.review_score} %", "d'avis positifs",
                PALETTE["text_dim"]))
        prix.addStretch(1)
        info.addLayout(prix)

        if item.last_check:
            verif = QLabel(t("verifie le {0}").format(time.strftime(
                "%d/%m a %H:%M", time.localtime(item.last_check))))
            verif.setObjectName("Faint")
            info.addWidget(verif)
        info.addStretch(1)
        lay.addLayout(info, 1)

        # -- seuil d'alerte ---------------------------------------------
        seuil = QVBoxLayout()
        seuil.setSpacing(4)
        etiquette = QLabel("Me prevenir sous")
        etiquette.setObjectName("Faint")
        seuil.addWidget(etiquette)
        self.target = QDoubleSpinBox()
        self.target.setRange(0, 999)
        self.target.setDecimals(2)
        self.target.setSuffix(" " + region.symbole())
        self.target.setSpecialValueText("aucune alerte")
        self.target.setValue(item.target_price)
        self.target.setFixedWidth(146)
        # `editingFinished` part aussi quand le champ perd le focus, y
        # compris pendant la destruction de la ligne. N'annoncer que les
        # vrais changements evite de relancer la reconstruction en boucle.
        self.target.editingFinished.connect(self._target_edited)
        seuil.addWidget(self.target)
        seuil.addStretch(1)
        lay.addLayout(seuil)

        # -- actions -----------------------------------------------------
        actions = QVBoxLayout()
        actions.setSpacing(7)
        voir = QPushButton("Voir l'offre")
        voir.clicked.connect(self._open)
        actions.addWidget(voir)
        fiche = QPushButton("Fiche boutique")
        fiche.setObjectName("Ghost")
        fiche.clicked.connect(lambda: ouvrir_lien(
            f"https://store.steampowered.com/app/{self.item.appid}"))
        actions.addWidget(fiche)
        retirer = QPushButton("Retirer")
        retirer.setObjectName("Ghost")
        retirer.clicked.connect(
            lambda: self.remove_requested.emit(self.item.appid))
        actions.addWidget(retirer)
        actions.addStretch(1)
        lay.addLayout(actions)

    @staticmethod
    def _bloc_prix(valeur: str, legende: str, couleur: str,
                   grand: bool = False) -> QWidget:
        bloc = QWidget()
        col = QVBoxLayout(bloc)
        col.setContentsMargins(0, 0, 0, 0)
        col.setSpacing(1)
        v = QLabel(valeur)
        v.setStyleSheet(f"color:{couleur}; font-size:{'21' if grand else '15'}px;"
                        f" font-weight:{'700' if grand else '600'};")
        col.addWidget(v)
        l = QLabel(legende)
        l.setObjectName("Faint")
        col.addWidget(l)
        return bloc

    def _target_edited(self) -> None:
        voulu = round(self.target.value(), 2)
        if abs(voulu - round(float(self.item.target_price or 0), 2)) < 0.005:
            return
        self.item.target_price = voulu
        self.target_changed.emit(self.item.appid, voulu)

    def _open(self) -> None:
        url = self.item.best_url or (
            f"https://store.steampowered.com/app/{self.item.appid}")
        ouvrir_lien(url)


class ResultRow(QFrame):
    """Un resultat de recherche, pret a etre ajoute."""

    add_requested = Signal(str, str)

    def __init__(self, entry: dict, parent=None) -> None:
        super().__init__(parent)
        self.entry = entry
        self.setObjectName("Panel")
        lay = QHBoxLayout(self)
        lay.setContentsMargins(12, 10, 12, 10)
        lay.setSpacing(14)

        lay.addWidget(_cover(entry.get("cover", ""), entry.get("title", ""),
                             entry.get("appid", ""), SHOT))

        col = QVBoxLayout()
        col.setSpacing(3)
        titre = QLabel(entry.get("title", ""))
        titre.setObjectName("Value")
        col.addWidget(titre)
        bits = []
        if entry.get("price"):
            bits.append(region.prix(entry['price']))
        elif entry.get("price") == 0:
            bits.append("gratuit")
        if entry.get("release"):
            bits.append(str(entry["release"]))
        detail = QLabel("   ·   ".join(bits) or "prix inconnu")
        detail.setObjectName("Faint")
        col.addWidget(detail)
        col.addStretch(1)
        lay.addLayout(col, 1)

        ajouter = QPushButton("Suivre ce jeu")
        ajouter.clicked.connect(
            lambda: self.add_requested.emit(self.entry.get("appid", ""),
                                            self.entry.get("title", "")))
        lay.addWidget(ajouter)


class WishlistView(QWidget):
    refresh_requested = Signal()
    import_requested = Signal()
    add_requested = Signal(str, str)         # appid, titre
    target_changed = Signal(str, float)
    remove_requested = Signal(str)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._items: list[WishItem] = []

        root = QVBoxLayout(self)
        root.setContentsMargins(24, 18, 24, 18)
        root.setSpacing(14)

        bar = QHBoxLayout()
        title = QLabel("Envies")
        title.setObjectName("PageTitle")
        bar.addWidget(title)
        self.count = QLabel("")
        self.count.setObjectName("PageHint")
        bar.addWidget(self.count)
        bar.addStretch(1)

        self.search = QLineEdit()
        self.search.setObjectName("Search")
        self.search.setPlaceholderText("Chercher un jeu a suivre...")
        self.search.setFixedWidth(300)
        self.search.setClearButtonEnabled(True)
        self.search.returnPressed.connect(self._search)
        # la page attend la fin de la frappe avant de se reconstruire
        self._frappe = QTimer(self)
        self._frappe.setSingleShot(True)
        self._frappe.setInterval(180)
        self._frappe.timeout.connect(lambda: self._filter(self.search.text()))
        self.search.textChanged.connect(lambda _t: self._frappe.start())
        bar.addWidget(self.search)

        self.find = QPushButton("Chercher")
        self.find.setObjectName("Ghost")
        self.find.clicked.connect(self._search)
        bar.addWidget(self.find)

        imp = QPushButton("Importer depuis Steam")
        imp.setObjectName("Ghost")
        imp.clicked.connect(self.import_requested.emit)
        bar.addWidget(imp)

        refresh = QPushButton("Verifier les prix")
        refresh.clicked.connect(self.refresh_requested.emit)
        bar.addWidget(refresh)
        root.addLayout(bar)

        self.progress = QProgressBar()
        self.progress.setVisible(False)
        self.progress.setTextVisible(False)
        root.addWidget(self.progress)

        # -- panneau de resultats ---------------------------------------
        self.results_panel = QFrame()
        self.results_panel.setObjectName("Notice")
        panneau = QVBoxLayout(self.results_panel)
        panneau.setContentsMargins(16, 12, 16, 14)
        panneau.setSpacing(9)
        entete = QHBoxLayout()
        self.results_title = QLabel("")
        self.results_title.setObjectName("PanelTitle")
        entete.addWidget(self.results_title)
        entete.addStretch(1)
        fermer = QPushButton("Fermer")
        fermer.setObjectName("Ghost")
        fermer.clicked.connect(self.hide_results)
        entete.addWidget(fermer)
        panneau.addLayout(entete)
        self.results_box = QVBoxLayout()
        self.results_box.setSpacing(8)
        panneau.addLayout(self.results_box)
        self.results_panel.setVisible(False)
        root.addWidget(self.results_panel)

        # -- liste --------------------------------------------------------
        scroll = ZoneDefilante()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        root.addWidget(scroll, 1)
        body = QWidget()
        scroll.setWidget(body)
        self.rows = QVBoxLayout(body)
        self.rows.setContentsMargins(0, 0, 8, 0)
        self.rows.setSpacing(10)

        self.empty = QLabel(
            "Aucune envie suivie.\n\n"
            "Importez votre liste de souhaits Steam, ou cherchez un jeu "
            "ci-dessus : ORION surveillera son prix et vous previendra quand "
            "il passe sous le seuil que vous aurez fixe.")
        self.empty.setObjectName("Dim")
        self.empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.rows.addWidget(self.empty)

    # ------------------------------------------------------------------
    def set_items(self, items: list[WishItem]) -> None:
        self._items = list(items)
        self._render(self._items)

        reached = sum(1 for i in items if i.reached)
        self.count.setText(
            f"{len(items)} jeu(x) suivi(s)"
            + (f"  ·  {reached} au prix voulu" if reached else ""))

    #: message affiche quand il n'y a rien a montrer
    VIDE = ("Aucune envie suivie.\n\n"
            "Importez votre liste de souhaits Steam, ou cherchez un jeu "
            "ci-dessus : ORION surveillera son prix et vous previendra quand "
            "il passe sous le seuil que vous aurez fixe.")

    def _render(self, items: list[WishItem], filtre: str = "") -> None:
        clear_layout(self.rows, keep=(self.empty,))
        for item in items:
            row = WishRow(item)
            row.target_changed.connect(self.target_changed.emit)
            row.remove_requested.connect(self.remove_requested.emit)
            self.rows.addWidget(row)
        if not items:
            # distinguer « rien de suivi » de « rien ne correspond » : la
            # premiere invite a ajouter, la seconde a chercher en ligne.
            self.empty.setText(
                self.VIDE if not filtre else
                f"Aucun jeu suivi ne correspond a « {filtre} ».\n\n"
                "Le bouton « Chercher » interroge la boutique pour ajouter "
                "ce jeu a vos envies.")
            self.rows.addWidget(self.empty)
            self.empty.setVisible(True)
        self.rows.addStretch(1)

    def _filter(self, texte: str) -> None:
        """Filtre la liste suivie pendant la frappe, sans rien interroger."""
        if not texte.strip():
            self._render(self._items)
            return
        self._render(classer(texte, self._items, cle=lambda i: i.title),
                     filtre=texte.strip())

    def set_progress(self, message: str, percent: int) -> None:
        visible = 0 <= percent < 100
        self.progress.setVisible(visible)
        if visible:
            self.progress.setValue(max(percent, 1))

    # ------------------------------------------------------------------
    def set_results(self, results: list[dict]) -> None:
        """Affiche les resultats en panneau, sous la barre de recherche."""
        clear_layout(self.results_box)
        terme = self.search.text().strip()
        if not results:
            self.results_title.setText(f"Aucun jeu trouve pour « {terme} »")
            vide = QLabel("Essayez un titre plus court, ou son sigle "
                          "(« gta », « bg3 »).")
            vide.setObjectName("Faint")
            self.results_box.addWidget(vide)
        else:
            # memes lectures que la recherche : « bo3 » est « black ops 3 »,
            # « F1 202 » retombe sur « F1 »
            from ...core.recherche import classer_variantes, variantes
            classe = classer_variantes(variantes(terme, raccourcie=True), results,
                                       cle=lambda e: e.get("title", ""), seuil=0.55)
            self.results_title.setText(
                f"{len(classe)} resultat(s) pour « {terme} »")
            for entry in classe[:8]:
                ligne = ResultRow(entry)
                ligne.add_requested.connect(self._chosen)
                self.results_box.addWidget(ligne)
        self.results_panel.setVisible(True)
        self.find.setEnabled(True)
        self.find.setText("Chercher")

    def hide_results(self) -> None:
        self.results_panel.setVisible(False)
        clear_layout(self.results_box)

    def _chosen(self, appid: str, titre: str) -> None:
        self.add_requested.emit(appid, titre)
        self.search.clear()
        self.hide_results()

    def _search(self) -> None:
        terme = self.search.text().strip()
        if not terme:
            self.search.setFocus()
            return
        self.find.setEnabled(False)
        self.find.setText("Recherche...")
        self.add_requested.emit("", terme)
