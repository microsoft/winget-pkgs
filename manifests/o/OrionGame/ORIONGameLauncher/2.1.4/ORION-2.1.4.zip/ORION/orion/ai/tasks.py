"""Ce que l'assistant IA sait faire dans ORION.

Chaque fonction construit un contexte precis (materiel reel, ecran reel,
fichiers de configuration reellement presents) et renvoie du texte pret a
afficher, ou un fichier de recette pret a etre enregistre.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from ..core.logging_setup import get
from ..core.models import Display, Game, HardwareInfo, OptimizationPlan
from ..core.paths import RECIPE_USER_DIR, ensure_dirs
from ..optimizer.discovery import context_for
from ..optimizer.profiles import PROFILES
from .client import AIClient

log = get("ia.taches")


def _machine(hw: HardwareInfo, display: Display | None) -> str:
    gpu = hw.gpu
    lines = [
        f"Processeur : {hw.cpu_name} ({hw.cpu_cores} coeurs / {hw.cpu_threads} fils)",
        f"Memoire vive : {hw.ram_gb} Go",
        f"Carte graphique : {gpu.name}, {gpu.vram_mb} Mo de VRAM, "
        f"pilote {gpu.driver_version}",
        f"Technologies disponibles : {', '.join(gpu.features) or 'aucune'}",
        f"Systeme : {hw.os_name}",
    ]
    if display and display.native:
        lines.append(
            f"Ecran vise : {display.name}, definition native "
            f"{display.native.width}x{display.native.height}, "
            f"jusqu'a {display.max_refresh_at_native} Hz")
    for d in hw.disks[:4]:
        lines.append(f"Disque {d['mount']} : {d['free_gb']} Go libres sur "
                     f"{d['total_gb']} Go")
    return "\n".join(lines)


def _game_context(game: Game) -> str:
    ctx = context_for(game)
    lines = [
        f"Jeu : {game.title}",
        f"Plateforme : {game.source}",
        f"Dossier : {game.install_dir or 'inconnu'}",
        f"Executable : {game.executable or 'inconnu'}",
        f"Moteur detecte : {game.engine or 'inconnu'}",
        f"Taille : {game.size_gb} Go",
    ]
    if ctx.get("ue_project"):
        lines.append(f"Projet Unreal : {ctx['ue_project']}")
    if ctx.get("unity_product"):
        lines.append(f"Produit Unity : {ctx.get('unity_company')} / "
                     f"{ctx['unity_product']}")
    return "\n".join(lines)


def _config_files(game: Game, limit: int = 25) -> list[str]:
    """Fichiers de configuration plausibles pour ce jeu."""
    found: list[str] = []
    candidates: list[Path] = []
    ctx = context_for(game)

    for base in (ctx.get("localappdata"), ctx.get("appdata"),
                 ctx.get("documents"), ctx.get("saved_games")):
        if not base:
            continue
        root = Path(base)
        if not root.is_dir():
            continue
        key = re.sub(r"[^a-z0-9]", "", game.title.lower())[:10]
        try:
            for child in root.iterdir():
                if not child.is_dir():
                    continue
                name = re.sub(r"[^a-z0-9]", "", child.name.lower())
                if key and (key in name or name in key):
                    candidates.append(child)
        except Exception:
            continue

    if game.install_dir:
        candidates.append(Path(game.install_dir))

    patterns = ("*.ini", "*.cfg", "*.json", "*.xml", "*.settings")
    for folder in candidates[:6]:
        for pattern in patterns:
            try:
                for f in list(folder.rglob(pattern))[:40]:
                    if f.stat().st_size < 400_000:
                        found.append(str(f))
                    if len(found) >= limit:
                        return found
            except Exception:
                continue
    return found


# --------------------------------------------------------------------------
# Usages
# --------------------------------------------------------------------------

def advise_game(game: Game, hw: HardwareInfo, display: Display | None,
                profile_id: str, plan: OptimizationPlan | None = None) -> tuple[bool, str]:
    """Conseils de reglages precis pour ce jeu sur cette machine."""
    profile = PROFILES.get(profile_id) or PROFILES["recommande"]
    applied = ""
    if plan and plan.ops:
        applied = "\n".join(
            f"- {o.label or o.key} : {o.current} -> {o.value}"
            for o in plan.ops if o.changed)[:1500]

    prompt = f"""Voici une machine de jeu et un jeu precis.

MACHINE
{_machine(hw, display)}

JEU
{_game_context(game)}

OBJECTIF DU JOUEUR
Profil « {profile.label} » : {profile.description}

REGLAGES QU'ORION S'APPRETE A ECRIRE
{applied or "aucun (ORION ne connait pas encore les fichiers de ce jeu)"}

Donne au joueur, en 6 a 10 points courts :
1. les options du menu de ce jeu precis qui pesent le plus sur les images par
   seconde, et la valeur a choisir pour cet objectif ;
2. les options a laisser hautes parce qu'elles coutent peu ;
3. les pieges connus de ce jeu sur cette configuration ;
4. un ordre de grandeur realiste d'images par seconde attendu.
Pas d'introduction, pas de conclusion : uniquement la liste."""
    return AIClient().ask(prompt, 1400)


def diagnose(game: Game, hw: HardwareInfo, display: Display | None,
             symptom: str) -> tuple[bool, str]:
    """Explique une contre-performance decrite par le joueur."""
    prompt = f"""MACHINE
{_machine(hw, display)}

JEU
{_game_context(game)}

PROBLEME DECRIT PAR LE JOUEUR
{symptom}

Donne les causes les plus probables classees par probabilite, et pour chacune
le test concret a faire et le correctif. Sois precis et technique, maximum
huit points."""
    return AIClient().ask(prompt, 1400)


def buying_advice(game: Game, market_summary: str) -> tuple[bool, str]:
    """Conseil d'achat a partir des prix releves."""
    prompt = f"""JEU : {game.title}

DONNEES DE MARCHE RELEVEES PAR ORION
{market_summary}

En cinq lignes maximum : est-ce le bon moment pour acheter, a quel prix il est
raisonnable d'attendre, et les pieges d'achat a eviter pour ce jeu (cles grises,
editions incompletes, region lock). Pas de bla-bla."""
    return AIClient().ask(prompt, 700)


RECIPE_RULES = """Tu dois produire UNIQUEMENT un objet JSON valide, sans texte
autour et sans balises de code, au format de recette ORION :

{
  "id": "identifiant_court",
  "name": "Nom lisible",
  "match": {"appid": ["123456"]},
  "confidence": "exact",
  "derive": {
    "nom_variable": {"from": "window_mode", "map": {"fullscreen": "0", "borderless": "1"}}
  },
  "targets": [
    {
      "format": "ini",
      "paths": ["%LOCALAPPDATA%/Dossier/Saved/Config/Windows/GameUserSettings.ini"],
      "entries": [
        {"section": "NomSection", "key": "CleDuJeu", "value": "{resolution_w}",
         "label": "Libelle lisible en francais"}
      ]
    }
  ],
  "advice": ["conseil court"]
}

Formats acceptes pour "format" : ini, registry, cfg, json.
Pour registry, "paths" contient une cle du type "HKCU/Software/Editeur/Jeu"
et les entrees n'ont pas de "section".
Variables utilisables dans "value" : resolution_w, resolution_h, refresh,
fps_cap, window_mode, vsync, quality, q_textures, q_shadows, q_effects,
q_postprocess, q_view_distance, q_foliage, q_antialiasing, q_reflections,
upscaler, frame_gen, ray_tracing, reflex, fx_motion_blur, fx_bloom,
fx_depth_of_field, fx_film_grain.
Variables utilisables dans "paths" : install_dir, exe_dir, localappdata,
appdata, documents, saved_games, ue_project, unity_company, unity_product.
N'invente aucun chemin : utilise uniquement ceux de la liste fournie."""


def generate_recipe(game: Game, hw: HardwareInfo) -> tuple[bool, str]:
    """Fait ecrire par l'IA une recette de reglages pour un jeu inconnu.

    C'est l'apport le plus concret de l'IA dans ORION : elle transforme un
    jeu « non reconnu » en jeu reglable automatiquement, et le resultat est
    un simple fichier JSON, relisible et modifiable a la main.
    """
    files = _config_files(game)
    samples = []
    for path in files[:6]:
        try:
            text = Path(path).read_text("utf-8", errors="ignore")[:1800]
            samples.append(f"--- {path} ---\n{text}")
        except Exception:
            continue

    prompt = f"""{RECIPE_RULES}

JEU CIBLE
{_game_context(game)}
Identifiant Steam eventuel : {game.extra.get('steam_appid') or game.source_id or 'inconnu'}

FICHIERS DE CONFIGURATION TROUVES SUR CETTE MACHINE
{chr(10).join(files[:25]) or "aucun"}

EXTRAITS DE CES FICHIERS
{chr(10).join(samples)[:7000] or "aucun"}

Ecris la recette ORION qui permet de regler ce jeu : definition, frequence,
mode d'affichage, limite d'images et principales options de qualite.
Ne garde que les cles reellement presentes dans les extraits ci-dessus."""

    ok, text = AIClient().ask(prompt, 2500)
    if not ok:
        return False, text

    raw = text.strip()
    raw = re.sub(r"^```(?:json)?|```$", "", raw, flags=re.M).strip()
    start, end = raw.find("{"), raw.rfind("}")
    if start < 0 or end <= start:
        return False, "La reponse ne contient pas de JSON exploitable."
    try:
        data = json.loads(raw[start:end + 1])
    except Exception as exc:
        return False, f"JSON invalide renvoye par l'IA : {exc}"

    if not data.get("targets"):
        return False, ("L'IA n'a trouve aucun fichier de configuration a "
                       "modifier pour ce jeu.")

    ensure_dirs()
    safe = re.sub(r"[^a-z0-9_]+", "_", (data.get("id") or game.title).lower())[:40]
    data.setdefault("id", safe)
    data.setdefault("name", game.title)
    data.setdefault("confidence", "exact")
    if not data.get("match"):
        appid = game.extra.get("steam_appid") or (
            game.source_id if game.source == "steam" else "")
        data["match"] = {"appid": [str(appid)]} if appid else \
            {"title": [game.title]}
    data.setdefault("advice", [])
    data["advice"].append("Recette generee par l'assistant IA : verifiez le "
                          "resultat au premier lancement.")

    dest = RECIPE_USER_DIR / f"{safe}.json"
    dest.write_text(json.dumps(data, indent=2, ensure_ascii=False), "utf-8")
    log.info("Recette generee : %s", dest)

    count = sum(len(t.get("entries") or []) for t in data["targets"])
    return True, (f"Recette enregistree : {dest.name}\n"
                  f"{len(data['targets'])} fichier(s), {count} reglage(s).\n"
                  "Elle est active immediatement ; rouvrez la fiche du jeu "
                  "pour voir les modifications proposees.")


def analyse_machine(hw: HardwareInfo, display: Display | None,
                    bilan: str) -> tuple[bool, str]:
    """Lecture detaillee de la configuration, a partir du bilan local.

    ORION a deja repere les desequilibres sans reseau ; l'IA part de ce
    constat pour expliquer, hierarchiser et proposer des suites concretes.
    Lui donner le bilan evite qu'elle redecouvre la machine de travers.
    """
    prompt = f"""Voici une machine de jeu Windows et le bilan qu'un outil
local en a deja tire.

MACHINE
{_machine(hw, display)}

BILAN LOCAL
{bilan}

Reponds en francais, sans introduction ni conclusion, en quatre parties
courtes et titrees :
1. GOULOT D'ETRANGLEMENT : quel composant limite les autres, dans quelles
   situations precises (definition, type de jeu), et de combien environ.
   Si la machine est equilibree, dis-le franchement.
2. CE QUI CLOCHE : les points de configuration a corriger, du plus genant
   au plus anodin, avec la correction exacte.
3. GRATUIT TOUT DE SUITE : ce qui s'ameliore par un reglage, sans rien
   acheter.
4. SI VOUS CHANGEZ UNE PIECE : le composant a remplacer en premier et
   pourquoi, sans citer de modele precis ni de prix.
Reste factuel : pas de superlatifs, pas de promesse chiffree invraisemblable."""
    return AIClient().ask(prompt, 1600)

