"""Controle des recettes, en particulier celles venues de la communaute.

Une recette decrit des fichiers de reglages a modifier. Une recette
malveillante pourrait tenter d'ecrire ailleurs : dans un script de
demarrage, dans la base de registre de Windows, ou injecter des lignes
supplementaires dans un fichier INI. Trois barrieres l'en empechent :

1. **A la reception** (`verifier_recette`) : structure attendue, formats
   connus, extensions de fichiers de reglages uniquement, aucune remontee
   de dossier (« .. »), aucun chemin absolu vers le systeme, aucune valeur
   multiligne, registre limite a HKCU\\Software pour les recettes partagees.
   Une recette refusee n'est pas enregistree.
2. **A la construction du plan** (`chemin_autorise`) : chaque fichier reel
   vise doit se trouver dans le dossier du jeu ou dans les dossiers de
   donnees de l'utilisateur (AppData, Documents, Saved Games), jamais dans
   Windows ou Program Files (hors dossier du jeu), jamais un executable.
3. **Jamais pendant une partie** (`jeu_ouvert`, 2.1.0) : tant qu'un
   programme du jeu tourne (son lanceur compris), ORION n'ecrit rien. Un
   anti-triche surveille le jeu pendant qu'il tourne ; et le jeu
   reecrirait de toute facon ses reglages en se fermant.
4. **Empreinte** (`empreinte`) : l'index du depot peut publier le SHA-256
   de chaque recette ; une recette qui ne correspond pas est ignoree, et
   une recette deja telechargee puis modifiee sur le disque aussi.

Les recettes livrees avec ORION et les recettes personnelles passent les
memes controles de structure (une faute de frappe ne doit pas ecrire
n'importe ou), avec une tolerance plus large sur le registre.
"""
from __future__ import annotations

import hashlib
import os
import re
from pathlib import Path

FORMATS = {"ini", "cfg", "json", "registry", "xml", "keyvalues", "texte"}

#: extensions de fichiers de reglages acceptees
EXTENSIONS = {".ini", ".cfg", ".json", ".xml", ".txt", ".conf", ".config",
              ".settings", ".sav", ".prefs", ".yaml", ".yml", ".toml", ".vdf",
              ".dat", ".lsx", ""}

#: extensions jamais ecrites, quelle que soit l'origine de la recette
INTERDITES = {".exe", ".dll", ".sys", ".bat", ".cmd", ".ps1", ".psm1", ".vbs",
              ".vbe", ".js", ".jse", ".wsf", ".wsh", ".msi", ".scr", ".com",
              ".lnk", ".url", ".reg", ".hta", ".cpl", ".jar", ".py", ".pyw",
              ".lua", ".asi"}

_ID = re.compile(r"^[A-Za-z0-9_.-]{1,80}$")
_CONTROLE = re.compile(r"[\x00-\x08\x0a-\x1f\x7f]")

#: variables d'environnement autorisees en tete d'un chemin de recette
_RACINES_VAR = ("%LOCALAPPDATA%", "%APPDATA%", "%USERPROFILE%", "%DOCUMENTS%",
                "%SAVEDGAMES%", "{install_dir}", "{documents}",
                "{saved_games}", "{localappdata}", "{appdata}", "~")

#: cles de registre sensibles, meme sous HKCU
_REGISTRE_INTERDIT = re.compile(
    r"(\\run(once)?\b|\\policies\\|\\winlogon|\\explorer\\shell|"
    r"\\image file execution|\\environment\b|\\classes\\|\\services\\|"
    r"\\currentversion\\(run|policies)|\\appinit|\\shell\\open)", re.I)


def _texte(v, maxi: int) -> bool:
    return isinstance(v, (str, int, float, bool)) and len(str(v)) <= maxi \
        and not _CONTROLE.search(str(v))


def verifier_recette(data, partagee: bool = True) -> tuple[bool, list[str]]:
    """(acceptable, raisons du refus). Fonction pure, testee."""
    raisons: list[str] = []
    if not isinstance(data, dict):
        return False, ["la recette n'est pas un objet JSON"]
    rid = str(data.get("id") or "")
    if rid and not _ID.match(rid):
        raisons.append("identifiant invalide")
    if not _texte(data.get("name", ""), 120):
        raisons.append("nom invalide")

    advice = data.get("advice") or []
    if not isinstance(advice, list) or len(advice) > 30 or \
            any(not isinstance(a, str) or len(a) > 600 for a in advice):
        raisons.append("conseils invalides")

    targets = data.get("targets") or []
    if not isinstance(targets, list) or len(targets) > 20:
        return False, raisons + ["liste de cibles invalide"]

    for i, t in enumerate(targets):
        if not isinstance(t, dict):
            raisons.append(f"cible {i + 1} invalide")
            continue
        fmt = t.get("format", "ini")
        if fmt not in FORMATS:
            raisons.append(f"format inconnu : {fmt}")
            continue
        chemins = t.get("paths") or []
        if not isinstance(chemins, list) or not chemins or len(chemins) > 12:
            raisons.append(f"cible {i + 1} : chemins invalides")
            continue
        for c in chemins:
            probleme = (_probleme_registre(c, partagee) if fmt == "registry"
                        else _probleme_chemin(c, partagee))
            if probleme:
                raisons.append(f"cible {i + 1} : {probleme}")
        entrees = t.get("entries") or []
        if not isinstance(entrees, list) or len(entrees) > 250:
            raisons.append(f"cible {i + 1} : entrees invalides")
            continue
        for e in entrees:
            if not isinstance(e, dict):
                raisons.append(f"cible {i + 1} : entree invalide")
                break
            if not _texte(e.get("key", ""), 200) or not str(e.get("key", "")).strip():
                raisons.append(f"cible {i + 1} : cle invalide")
                break
            if not _texte(e.get("value", ""), 500):
                raisons.append(f"cible {i + 1} : valeur invalide ou multiligne")
                break
            if not _texte(e.get("section", ""), 200):
                raisons.append(f"cible {i + 1} : section invalide")
                break
    return (not raisons), raisons


def _probleme_chemin(chemin, partagee: bool) -> str:
    if not isinstance(chemin, str) or not chemin.strip() or len(chemin) > 400:
        return "chemin vide ou trop long"
    if _CONTROLE.search(chemin):
        return "caractere interdit dans un chemin"
    normal = chemin.replace("\\", "/")
    if "/../" in f"/{normal}/" or normal.startswith("../"):
        return "remontee de dossier interdite"
    ext = os.path.splitext(normal.rstrip("*"))[1].lower()
    if ext in INTERDITES:
        return f"type de fichier interdit ({ext})"
    if partagee:
        if ext and ext not in EXTENSIONS:
            return f"type de fichier non pris en charge ({ext})"
        if normal.startswith("//") or not normal.upper().startswith(
                tuple(r.upper() for r in _RACINES_VAR)):
            return "chemin hors des dossiers du jeu et de l'utilisateur"
    return ""


def _probleme_registre(cle, partagee: bool) -> str:
    if not isinstance(cle, str) or not cle.strip() or len(cle) > 300:
        return "cle de registre invalide"
    c = cle.replace("/", "\\")
    haut = c.upper()
    if _REGISTRE_INTERDIT.search(c):
        return "cle de registre sensible"
    if partagee and not (haut.startswith("HKCU\\SOFTWARE\\") or
                         haut.startswith("HKEY_CURRENT_USER\\SOFTWARE\\")):
        return "registre limite a HKCU\\Software pour une recette partagee"
    return ""


# --------------------------------------------------------------------------
def _dossiers_utilisateur() -> list[str]:
    maison = Path.home()
    sortie = [os.environ.get("LOCALAPPDATA", ""), os.environ.get("APPDATA", ""),
              str(maison / "Documents"), str(maison / "Saved Games"),
              str(maison / "OneDrive" / "Documents")]
    try:
        from ..core.winutil import documents_dir          # type: ignore
        sortie.append(str(documents_dir()))
    except Exception:
        pass
    return [os.path.normcase(os.path.normpath(s)) for s in sortie if s]


def chemin_autorise(chemin: str, dossier_jeu: str = "", partagee: bool = True) -> bool:
    """Le fichier reel vise par une recette peut-il etre modifie ?"""
    p = os.path.normcase(os.path.normpath(str(chemin)))
    ext = os.path.splitext(p)[1].lower()
    if ext in INTERDITES:
        return False
    if partagee and ext and ext not in EXTENSIONS:
        return False
    racines = _dossiers_utilisateur()
    if dossier_jeu:
        racines.append(os.path.normcase(os.path.normpath(dossier_jeu)))
    for r in racines:
        if r and (p == r or p.startswith(r.rstrip("\\/") + os.sep)):
            # %LOCALAPPDATA%\Microsoft\Windows (menu Demarrer...) exclu
            if os.sep + "microsoft" + os.sep + "windows" + os.sep in p:
                return False
            return True
    return False


def empreinte(contenu: bytes) -> str:
    return hashlib.sha256(contenu).hexdigest()


#: noms d'executables trop generiques pour reconnaitre un jeu a son seul nom
_NOMS_GENERIQUES = {"launcher.exe", "game.exe", "start.exe", "play.exe", "setup.exe",
                    "client.exe", "app.exe", "main.exe", "run.exe"}


def jeu_ouvert(game) -> bool:
    """Un programme du jeu tourne-t-il (le jeu ou son lanceur) ?

    * par son chemin : un programme lance depuis le dossier du jeu ;
    * par son nom, seulement si son chemin est illisible (jeu protege par
      un anti-triche, ou lance en administrateur) et que ce nom n'est pas
      generique (« launcher.exe »...).
    Ne leve jamais : faux si rien ne permet de le dire."""
    racine = str(getattr(game, "install_dir", "") or "")
    exe = str(getattr(game, "executable", "") or "")
    if not racine and exe:
        racine = str(Path(exe).parent)
    racine = os.path.normpath(racine).lower() if racine else ""
    if len(Path(racine).parts) < 2:          # racine d'un disque : trop large
        racine = ""
    else:
        racine = racine.rstrip("\\/") + os.sep
    nom = Path(exe).name.lower() if exe else ""
    if nom in _NOMS_GENERIQUES:
        nom = ""
    if not racine and not nom:
        return False
    try:
        import psutil
        for proc in psutil.process_iter(["name", "exe"]):
            info = proc.info
            chemin = os.path.normpath(info.get("exe") or "").lower() if info.get("exe") else ""
            if racine and chemin and chemin.startswith(racine):
                return True
            if nom and not chemin and (info.get("name") or "").lower() == nom:
                return True
    except Exception:
        return False
    return False
