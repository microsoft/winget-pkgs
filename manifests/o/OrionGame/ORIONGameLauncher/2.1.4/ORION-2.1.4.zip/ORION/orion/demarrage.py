"""Lancer ORION au demarrage de Windows (2.1.2, demande de l'auteur le
12 octobre 2026 : une case en tete des Reglages, et la meme dans
l'installateur).

Deux mecanismes, selon la provenance d'ORION :

* **installateur du site** : une valeur « ORION » dans
  `HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run`, la cle que Windows
  lit a l'ouverture de session. C'est elle que montre le Gestionnaire des
  taches (onglet « Applications de demarrage »). ORION y reste inscrit une
  fois installe ; couper se fait comme le Gestionnaire des taches le fait,
  par une marque a part (`Explorer\\StartupApproved\\Run`) : ORION reste
  dans la liste, « Desactive », et se rallume d'un clic, dans ORION ou dans
  le Gestionnaire. Rien dans HKEY_LOCAL_MACHINE, aucun droit administrateur.
* **Microsoft Store** : un paquet MSIX ne peut pas ecrire dans cette cle
  (Windows detourne l'ecriture vers une copie privee du paquet, qu'il ne lit
  jamais a l'ouverture de session : la case aurait ete cochee pour rien). Le
  paquet declare donc une tache de demarrage (`windows.startupTask`, voir
  `outils/msix/construire.py`) qu'ORION allume ou coupe par l'API de Windows
  (`StartupTask`, module `winrt`).

Allume par defaut (decision de l'auteur, 12 octobre 2026, 20 h 58 : ORION
« doit etre dans Applications au demarrage ») : case cochee d'office dans
l'installateur, tache `Enabled="true"` dans le paquet du Store (Windows
l'allume des que l'application a ete ouverte une fois). Un « non » deja dit
est toujours respecte.

Lance par Windows, ORION s'ouvre reduit dans la barre des taches et sans
ecran de demarrage : il ne passe pas devant ce que l'on ouvre en arrivant
(voir `app.main`).
"""
from __future__ import annotations

import sys
import threading
from dataclasses import dataclass
from pathlib import Path

from .core.logging_setup import get
from .version import APP_NAME

log = get("demarrage")

#: argument ajoute par la cle « Run » : ORION sait qu'il est lance par Windows
ARGUMENT = "--demarrage-windows"
RUN = r"Software\Microsoft\Windows\CurrentVersion\Run"
APPROUVE = r"Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run"
NOM = APP_NAME
#: identifiant de la tache de demarrage du paquet du Store (manifeste)
TACHE = "ORIONDemarrage"
#: meme temoin que `maj.MARQUE_STORE` (non importe : l'installateur n'embarque
#: pas le module des mises a jour)
MARQUE_STORE = "store.txt"
#: Windows.ApplicationModel.Activation.ActivationKind.StartupTask
ACTIVATION_DEMARRAGE = 1020
#: page des Parametres de Windows qui liste les applications de demarrage
PARAMETRES_WINDOWS = "ms-settings:startupapps"

#: StartupTaskState
DESACTIVEE, COUPEE_PAR_L_UTILISATEUR, ACTIVEE, INTERDITE, IMPOSEE = 0, 1, 2, 3, 4

COUPEE_DANS_WINDOWS = (
    "Le lancement au demarrage a ete coupe dans les Parametres de Windows, et "
    "Windows ne laisse pas une application du Store le remettre elle-meme. "
    "Rallumez ORION dans Parametres > Applications > Demarrage.")
INTERDIT = ("L'administrateur de ce PC interdit le lancement des applications "
            "au demarrage.")
IMPOSE = "L'administrateur de ce PC impose le lancement d'ORION au demarrage."
HORS_INSTALLATION = "Disponible dans la version installee d'ORION."
SANS_API = ("Windows n'a pas repondu. Vous pouvez allumer ou couper ORION dans "
            "Parametres > Applications > Demarrage.")


@dataclass
class Etat:
    actif: bool = False
    modifiable: bool = True       # la case peut etre changee depuis ORION
    note: str = ""                # pourquoi elle ne l'est pas, ou ce qu'il faut savoir
    parametres: bool = False      # la note renvoie aux Parametres de Windows


# ---------------------------------------------------------------------------
# Registre de l'utilisateur (remplace par un faux dans les essais)
# ---------------------------------------------------------------------------
class _Registre:
    def lire(self, cle: str, nom: str):
        import winreg
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, cle) as k:
                return winreg.QueryValueEx(k, nom)[0]
        except OSError:
            return None

    def ecrire(self, cle: str, nom: str, valeur) -> None:
        import winreg
        genre = winreg.REG_BINARY if isinstance(valeur, (bytes, bytearray)) else winreg.REG_SZ
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, cle) as k:
            winreg.SetValueEx(k, nom, 0, genre, valeur)

    def effacer(self, cle: str, nom: str) -> None:
        import winreg
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, cle, 0,
                                winreg.KEY_SET_VALUE) as k:
                winreg.DeleteValue(k, nom)
        except FileNotFoundError:
            pass


registre = _Registre()


def commande(exe) -> str:
    """Ce que Windows lance a l'ouverture de session."""
    return f'"{Path(exe)}" {ARGUMENT}'


def inscrit() -> str | None:
    """Commande inscrite dans la cle « Run », s'il y en a une."""
    valeur = registre.lire(RUN, NOM)
    return str(valeur) if valeur else None


def coupe_dans_le_gestionnaire() -> bool:
    """Le Gestionnaire des taches a coupe ORION : premier octet impair
    (02 ou 06 : allume ; 03 ou 07 : coupe)."""
    donnees = registre.lire(APPROUVE, NOM)
    return isinstance(donnees, (bytes, bytearray)) and len(donnees) > 0 \
        and bool(donnees[0] & 1)


def activer_cle(exe) -> None:
    """Inscrit ORION. Une coupure ancienne faite dans le Gestionnaire des
    taches est retiree : c'est l'utilisateur qui vient de demander."""
    registre.ecrire(RUN, NOM, commande(exe))
    registre.effacer(APPROUVE, NOM)


def marque_coupee(quand: float | None = None) -> bytes:
    """Marque ecrite par le Gestionnaire des taches quand on y coupe une
    application : 03 00 00 00 puis la date (FILETIME, 100 ns depuis 1601)."""
    import time
    filetime = int(((quand if quand is not None else time.time()) + 11644473600) * 10**7)
    return bytes([3, 0, 0, 0]) + filetime.to_bytes(8, "little")


def couper_cle(exe) -> None:
    """Coupe sans desinscrire : ORION reste dans « Applications de
    demarrage », Desactive, comme apres une coupure dans le Gestionnaire
    des taches. Le « non » est ainsi garde (une mise a jour ne le rallume
    pas)."""
    registre.ecrire(RUN, NOM, commande(exe))
    registre.ecrire(APPROUVE, NOM, marque_coupee())


def suivre_installation(exe) -> bool:
    """Mise a jour ou reinstallation sans choix exprime : l'inscription
    existante suit le programme (nouveau chemin), allumee ou coupee comme
    avant. Vrai si ORION etait deja inscrit."""
    if not inscrit():
        return False
    registre.ecrire(RUN, NOM, commande(exe))
    return True


def retirer_cle() -> None:
    registre.effacer(RUN, NOM)
    registre.effacer(APPROUVE, NOM)


# ---------------------------------------------------------------------------
# Paquet du Microsoft Store : tache de demarrage
# ---------------------------------------------------------------------------
def depuis_store() -> bool:
    try:
        return (Path(sys.executable).resolve().parent / MARQUE_STORE).is_file()
    except OSError:
        return False


def _dans_un_fil(fonction, delai: float = 10.0):
    """Les appels a Windows se font dans un fil a part : le fil de
    l'interface appartient a Qt (« STA »), ou Windows interdit d'attendre une
    reponse en bloquant. Le fil a part est en « MTA »."""
    resultat: dict = {}

    def corps() -> None:
        try:
            try:
                from winrt.runtime import ApartmentType, init_apartment
                init_apartment(ApartmentType.MULTI_THREADED)
            except Exception:
                pass          # deja initialise, ou winrt absent : `fonction` le dira
            resultat["ok"] = fonction()
        except BaseException as exc:        # transmis a l'appelant
            resultat["erreur"] = exc

    fil = threading.Thread(target=corps, name="orion-demarrage", daemon=True)
    fil.start()
    fil.join(delai)
    if fil.is_alive():
        raise TimeoutError("Windows ne repond pas")
    if "erreur" in resultat:
        raise resultat["erreur"]
    return resultat.get("ok")


def _tache_store(action: str = "lire") -> int:
    """Etat de la tache de demarrage apres `action` (lire, allumer, couper)."""
    def faire() -> int:
        from winrt.windows.applicationmodel import StartupTask
        tache = StartupTask.get_async(TACHE).get()
        if action == "allumer":
            return int(tache.request_enable_async().get())
        if action == "couper":
            tache.disable()
        return int(tache.state)
    return int(_dans_un_fil(faire))


def etat_store(code: int) -> Etat:
    if code == ACTIVEE:
        return Etat(True)
    if code == IMPOSEE:
        return Etat(True, False, IMPOSE)
    if code == COUPEE_PAR_L_UTILISATEUR:
        return Etat(False, True, COUPEE_DANS_WINDOWS, parametres=True)
    if code == INTERDITE:
        return Etat(False, False, INTERDIT)
    return Etat(False)


# ---------------------------------------------------------------------------
# Ce que l'application utilise
# ---------------------------------------------------------------------------
def disponible() -> bool:
    """Seul ORION installe (compile, sous Windows) peut s'inscrire : depuis
    les sources, Windows lancerait Python et non ORION."""
    return sys.platform.startswith("win") and bool(getattr(sys, "frozen", False))


def etat() -> Etat:
    if not disponible():
        return Etat(False, False, HORS_INSTALLATION)
    try:
        if depuis_store():
            return etat_store(_tache_store("lire"))
        return Etat(bool(inscrit()) and not coupe_dans_le_gestionnaire())
    except Exception:
        log.exception("Etat du lancement au demarrage illisible")
        return Etat(False, True, SANS_API if depuis_store() else "", depuis_store())


def regler(actif: bool) -> tuple[bool, Etat]:
    """Allume ou coupe le lancement au demarrage. Rend (reussi, nouvel etat)."""
    if not disponible():
        return False, Etat(False, False, HORS_INSTALLATION)
    try:
        if depuis_store():
            nouvel = etat_store(_tache_store("allumer" if actif else "couper"))
        else:
            if actif:
                activer_cle(sys.executable)
            else:
                couper_cle(sys.executable)
            nouvel = etat()
        log.info("Lancement au demarrage de Windows : %s",
                 "allume" if nouvel.actif else "coupe")
        return nouvel.actif == actif, nouvel
    except Exception:
        log.exception("Lancement au demarrage : reglage impossible")
        store = depuis_store()
        return False, Etat(not actif, True,
                           SANS_API if store else
                           "Windows a refuse le changement (detail dans le journal).",
                           store)


def lance_par_windows(argv: list[str] | None = None) -> bool:
    """ORION vient-il d'etre lance par Windows a l'ouverture de session ?"""
    args = sys.argv if argv is None else argv
    if ARGUMENT in args:
        return True
    if not (disponible() and depuis_store()):
        return False
    try:
        def faire() -> int:
            from winrt.windows.applicationmodel import AppInstance
            return int(AppInstance.get_activated_event_args().kind)
        return _dans_un_fil(faire, 5.0) == ACTIVATION_DEMARRAGE
    except Exception:
        log.debug("Mode de lancement illisible", exc_info=True)
        return False


def interroger(argv: list[str] | None = None):
    """Pose la question `lance_par_windows` tout de suite et rend une
    fonction qui lit la reponse (en l'attendant au plus `delai` secondes).
    Pour le paquet du Store, Windows repond pendant que Qt demarre."""
    args = list(sys.argv if argv is None else argv)
    if ARGUMENT in args:
        return lambda delai=0.0: True
    if not (disponible() and depuis_store()):
        return lambda delai=0.0: False
    boite: dict = {}

    def corps() -> None:
        boite["oui"] = lance_par_windows(args)

    fil = threading.Thread(target=corps, name="orion-demarrage-question", daemon=True)
    fil.start()

    def reponse(delai: float = 2.0) -> bool:
        fil.join(delai)
        return bool(boite.get("oui", False))
    return reponse


def ouvrir_parametres() -> bool:
    """Ouvre la page « Applications de demarrage » des Parametres de Windows."""
    try:
        import os
        os.startfile(PARAMETRES_WINDOWS)          # type: ignore[attr-defined]
        return True
    except Exception:
        log.debug("Parametres de Windows inaccessibles", exc_info=True)
        return False
