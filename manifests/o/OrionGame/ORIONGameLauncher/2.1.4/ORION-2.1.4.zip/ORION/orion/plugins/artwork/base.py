"""Contrat commun aux fournisseurs de visuels.

Un fournisseur recoit un `Game` et renvoie un dictionnaire de chemins locaux :
    {"cover": "...", "hero": "...", "logo": "...", "icon": "..."}
Les cles absentes sont simplement ignorees, et le service passe au fournisseur
suivant pour completer ce qui manque.
"""
from __future__ import annotations

import hashlib
import re
from pathlib import Path

from ...core.logging_setup import get
from ...core.models import Game
from ...core.paths import ART_DIR, ensure_dirs

log = get("artwork")

KINDS = ("cover", "hero", "logo", "icon")


def cache_path(game: Game, kind: str, ext: str = "jpg") -> Path:
    ensure_dirs()
    safe = re.sub(r"[^a-z0-9]+", "-", game.title.lower())[:40].strip("-")
    stamp = hashlib.sha1(game.uid.encode()).hexdigest()[:8]
    return ART_DIR / f"{safe}-{stamp}-{kind}.{ext}"


class ArtworkProvider:
    """Sous-classer et implementer `fetch`. Decouverte automatique."""

    abstract = True
    id: str = ""
    label: str = ""
    priority: int = 50           # teste du plus grand au plus petit
    needs_network: bool = True

    def available(self) -> bool:
        return True

    def fetch(self, game: Game, want: set[str]) -> dict[str, str]:
        """Retourne les visuels trouves. Ne doit jamais lever d'exception."""
        return {}


# --------------------------------------------------------------------------

def _composantes_jpeg(data: bytes) -> int:
    """Nombre de canaux d'un JPEG (1 = niveaux de gris), 0 si inconnu."""
    i = 2
    while i + 9 < len(data):
        if data[i] != 0xFF:
            return 0
        marqueur = data[i + 1]
        longueur = int.from_bytes(data[i + 2:i + 4], "big")
        if marqueur in (0xC0, 0xC1, 0xC2):        # debut de trame
            return data[i + 9]
        i += 2 + longueur
    return 0


def image_vide(chemin_ou_octets) -> bool:
    """Vrai pour l'image grise unie que Steam renvoie a la place d'un visuel
    manquant (tres legere et en niveaux de gris). Une jaquette ainsi « trouvee »
    s'affichait comme un rectangle gris (cas de Battlefield 6)."""
    try:
        data = chemin_ou_octets if isinstance(chemin_ou_octets, bytes) \
            else Path(chemin_ou_octets).read_bytes()
    except OSError:
        return False
    if data[:2] != b"\xff\xd8":
        return False                     # PNG : logos et icones, pas concernes
    return len(data) < 15000 and _composantes_jpeg(data) == 1


def download(url: str, dest: Path, timeout: float = 12.0) -> bool:
    """Telecharge une image si elle n'est pas deja en cache."""
    from orion.core import reseau

    if dest.exists() and dest.stat().st_size > 1024:
        if not image_vide(dest):
            return True
        dest.unlink(missing_ok=True)
    try:
        r = reseau.get(url, timeout=timeout, headers={
            "User-Agent": "ORION-Launcher/1.0 (+local)"} )
        if r.status_code != 200 or len(r.content) < 1024:
            return False
        ctype = r.headers.get("content-type", "")
        if "image" not in ctype or image_vide(r.content):
            return False
        dest.parent.mkdir(parents=True, exist_ok=True)
        # ecrit a cote puis renomme : une image coupee (PC eteint) n'est
        # jamais prise pour une jaquette en cache
        provisoire = dest.with_name(dest.name + ".partiel")
        try:
            provisoire.write_bytes(r.content)
            provisoire.replace(dest)
        except OSError:
            provisoire.unlink(missing_ok=True)
            raise
        return True
    except Exception:
        log.debug("Telechargement impossible : %s", url)
        return False
