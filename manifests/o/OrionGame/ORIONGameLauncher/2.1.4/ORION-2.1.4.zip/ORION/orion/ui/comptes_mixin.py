"""Comptes des plateformes cote fenetre principale (1.8).

Relie la page Comptes, la fenetre de connexion integree et le panneau
« Succes » des fiches de jeu aux plateformes (`orion.comptes`). Tout ce
qui passe par le reseau tourne en tache de fond ; en partie, les
actualisations automatiques attendent la fin du jeu (mode discret).
"""
from __future__ import annotations

from .minuteur import plus_tard

from PySide6.QtWidgets import QMessageBox

from ..comptes import PLATEFORMES, ConnexionRequise
from ..core.doublons import GENERIQUES
from ..core.models import normalize_title
from ..core.logging_setup import get
from ..core.tasks import Task

log = get("ui.comptes")


class ComptesMixin:
    # ------------------------------------------------------------------
    # installation
    # ------------------------------------------------------------------
    def _init_comptes(self) -> None:
        v = self.comptes_view
        v.connecter.connect(self.connecter_compte)
        v.deconnecter.connect(self.deconnecter_compte)
        v.actualiser.connect(lambda pid: self.actualiser_compte(pid, auto=False))
        v.cle.connect(self.ajouter_cle_steam)
        v.tout_actualiser.connect(self.actualiser_tous_les_comptes)
        self.detail_view.succes.connexion_demandee.connect(self.connecter_compte)
        self._comptes_occupes: set[str] = set()
        for pid in PLATEFORMES:
            self._afficher_compte(pid)

    def _boot_comptes(self) -> None:
        self._compter_locaux()
        connectes = [pid for pid, p in PLATEFORMES.items() if p.connecte()]
        for i, pid in enumerate(connectes):
            plus_tard(self, 20000 + i * 15000, lambda p=pid: self.actualiser_compte(p))

    def _compter_locaux(self) -> None:
        compte: dict[str, int] = {}
        titres: dict[str, list[str]] = {}
        noms = {s.id: s.label for s in self.library.scanners}
        noms.update({pid: p.nom for pid, p in PLATEFORMES.items()})
        jeux = list(self.library.games(include_hidden=True))
        for g in jeux:
            compte[g.source] = compte.get(g.source, 0) + 1
        possedes = getattr(self, "possedes", None)
        if possedes is not None:
            jeux += list(possedes.tous())
        noms["msstore"] = noms.get("xbox", "Xbox")
        for g in jeux:
            if g.source in GENERIQUES:
                continue                 # un dossier n'est pas une plateforme
            titres.setdefault(noms.get(g.source, g.source.capitalize()), []).append(g.title)
        self.comptes_view.set_locales(compte)
        # jeux connus hors comptes : ils comptent pour les jeux en double
        self.comptes_view.set_bibliotheque(titres)

    def actualiser_tous_les_comptes(self) -> None:
        """Bouton « Tout actualiser » : chaque compte connecte est relu."""
        for pid, p in PLATEFORMES.items():
            if p.connecte():
                self.actualiser_compte(pid, auto=False)

    def _afficher_compte(self, pid: str, erreur: str = "") -> None:
        p = PLATEFORMES[pid]
        profil = p.profil_garde() if p.connecte() else None
        self.comptes_view.set_compte(pid, profil, p.jeux_gardes() if profil else [],
                                     erreur, pid in self._comptes_occupes)

    # ------------------------------------------------------------------
    # connexion / deconnexion
    # ------------------------------------------------------------------
    def connecter_compte(self, pid: str) -> None:
        p = PLATEFORMES.get(pid)
        if p is None:
            return
        from .widgets.connexion import FenetreConnexion, web_disponible
        if not web_disponible():
            QMessageBox.warning(self, "Connexion", "Le navigateur integre n'est pas "
                                "disponible dans cette installation d'ORION.")
            return
        d = FenetreConnexion(p, self)
        try:
            ok = d.exec()
            resultat, cle = d.resultat, d.cle
        finally:
            d.deleteLater()          # libere le navigateur integre et son processus
        if not ok or not resultat:
            return
        self._terminer_connexion(pid, resultat, cle)

    def ajouter_cle_steam(self, pid: str = "steam") -> None:
        from ..comptes.steam import PAGE_CLE
        from .widgets.connexion import FenetreConnexion
        p = PLATEFORMES["steam"]
        suite = p.etape_apres_connexion()
        d = FenetreConnexion(p, self, adresse=PAGE_CLE, consigne=suite[1] if suite else "")
        try:
            ok = d.exec()
            cle = d.cle
        finally:
            d.deleteLater()          # libere le navigateur integre et son processus
        if ok and cle:
            self._terminer_connexion("steam", "-", cle)

    def _terminer_connexion(self, pid: str, adresse: str, cle: str = "") -> None:
        p = PLATEFORMES[pid]
        self._comptes_occupes.add(pid)
        self._afficher_compte(pid)

        def travail():
            profil = p.connecter(adresse, cle=cle)
            jeux = []
            try:
                jeux = p.jeux(forcer=True)
            except Exception:
                log.exception("Jeux %s non lus", pid)
            return profil, jeux

        t = Task(travail)
        t.signals.finished.connect(lambda r: self._connexion_ok(pid, r))
        t.signals.failed.connect(lambda m: self._connexion_echec(pid, m))
        t.start()

    def _connexion_ok(self, pid: str, resultat) -> None:
        self._comptes_occupes.discard(pid)
        if not PLATEFORMES[pid].connecte():          # deconnecte entre-temps
            self._afficher_compte(pid)
            return
        profil, jeux = resultat
        self._afficher_compte(pid)
        self.notify(f"{PLATEFORMES[pid].nom} connecte : "
                    f"{profil.pseudo or profil.id} · {len(jeux)} jeux", 8)
        self._comptes_vers_bibliotheque(pid)

    def _connexion_echec(self, pid: str, message: str) -> None:
        self._comptes_occupes.discard(pid)
        log.warning("Connexion %s echouee : %s", pid, message)
        self._afficher_compte(pid, f"Connexion impossible : {message[:160]}")

    def deconnecter_compte(self, pid: str) -> None:
        p = PLATEFORMES[pid]
        if pid in self._comptes_occupes:
            # une tache lit le compte : la deconnexion attend sa fin (le bouton
            # est d'ailleurs desactive pendant ce temps)
            QMessageBox.information(self, f"Deconnecter {p.nom}",
                                    "Actualisation en cours : reessayez dans un instant.")
            return
        rep = QMessageBox.question(
            self, f"Deconnecter {p.nom}",
            f"Effacer la connexion {p.nom} de ce PC ?\n\nLe jeton chiffre et les "
            "donnees du compte gardees par ORION seront supprimes. Vos jeux installes "
            "ne sont pas touches.")
        if rep != QMessageBox.StandardButton.Yes:
            return
        p.deconnecter()
        self._afficher_compte(pid)
        self.actualiser_possedes()

    # ------------------------------------------------------------------
    # actualisation
    # ------------------------------------------------------------------
    def actualiser_compte(self, pid: str, auto: bool = True) -> None:
        p = PLATEFORMES[pid]
        if not p.connecte() or pid in self._comptes_occupes:
            return
        if auto and self._differer("comptes"):
            return
        self._comptes_occupes.add(pid)
        self._afficher_compte(pid)

        def travail():
            profil = p.profil(forcer=not auto)
            jeux = p.jeux(forcer=not auto)
            return profil, jeux

        t = Task(travail)
        t.signals.finished.connect(lambda _r: self._actualise(pid))
        t.signals.failed.connect(lambda m: self._actualise(pid, m))
        t.start()

    def _actualise(self, pid: str, erreur: str = "") -> None:
        self._comptes_occupes.discard(pid)
        if not PLATEFORMES[pid].connecte():          # deconnecte entre-temps
            self._afficher_compte(pid)
            return
        if erreur:
            log.warning("Actualisation %s impossible : %s", pid, erreur)
            texte = ("La connexion a expire : reconnectez-vous."
                     if ConnexionRequise.MARQUE in erreur
                     else f"Actualisation impossible : {erreur[:140]}")
            self._afficher_compte(pid, texte)
            return
        self._afficher_compte(pid)
        self._comptes_vers_bibliotheque(pid)

    def _comptes_vers_bibliotheque(self, pid: str) -> None:
        """Temps de jeu de la plateforme reporte sur les jeux installes, et
        jeux du compte ajoutes aux « non installes »."""
        jeux = {j.id: j for j in PLATEFORMES[pid].jeux_gardes()}
        par_titre = {normalize_title(j.titre): j for j in jeux.values()}
        change = False
        for g in self.library.games(include_hidden=True):
            j = None
            if g.source == pid and str(g.source_id) in jeux:
                j = jeux[str(g.source_id)]
            elif pid == "xbox" and g.source in ("xbox", "msstore"):
                j = par_titre.get(normalize_title(g.title))
            if j is not None and j.minutes * 60 > g.external_seconds:
                g.external_seconds = j.minutes * 60
                change = True
        if change:
            self.library.save()
            self.refresh_library()
        self.actualiser_possedes()

    # ------------------------------------------------------------------
    # succes dans la fiche d'un jeu
    # ------------------------------------------------------------------
    def _plateforme_du_jeu(self, game):
        """(plateforme, identifiant du jeu sur cette plateforme) ou (None, "")."""
        if game.source in ("steam", "gog") and game.source_id:
            return PLATEFORMES[game.source], str(game.source_id)
        if game.source in ("xbox", "msstore"):
            x = PLATEFORMES["xbox"]
            cible = normalize_title(game.title)
            for j in x.jeux_gardes():
                if normalize_title(j.titre) == cible:
                    return x, j.id
            return x, ""
        return None, ""

    def charger_succes(self, game) -> None:
        panneau = self.detail_view.succes
        p, jeu_id = self._plateforme_du_jeu(game)
        if p is None:
            panneau.vider()
            return
        if not p.connecte():
            panneau.non_connecte(p.id, p.nom)
            return
        if p.id == "steam" and not p.a_une_cle():
            panneau.erreur("Ajoutez votre cle Web API Steam (page Comptes) pour voir "
                           "vos succes.", p.nom)
            return
        if not jeu_id:
            panneau.erreur("Ce jeu n'apparait pas encore sur votre compte.", p.nom)
            return
        panneau.chargement(p.nom)
        uid = game.uid
        t = Task(p.succes, jeu_id)
        t.signals.finished.connect(lambda liste: self._succes_lus(uid, liste, p.nom))
        t.signals.failed.connect(lambda m: self._succes_echec(uid, m, p))
        t.start()

    def _succes_lus(self, uid: str, liste, nom: str) -> None:
        if getattr(self.detail_view, "game", None) is None or self.detail_view.game.uid != uid:
            return                                   # le joueur a change de jeu
        self.detail_view.succes.definir(liste, nom)

    def _succes_echec(self, uid: str, message: str, p) -> None:
        if getattr(self.detail_view, "game", None) is None or self.detail_view.game.uid != uid:
            return
        if ConnexionRequise.MARQUE in message:
            self.detail_view.succes.non_connecte(p.id, p.nom)
        else:
            self.detail_view.succes.erreur(f"Succes indisponibles : {message[:120]}", p.nom)


class StockageMixin:
    """Page Stockage cote fenetre : recalcul, sauvegarde d'un jeu sur un autre
    disque, restauration et suppression des sauvegardes (1.9), et retour des
    jeux deplaces par jonction en 1.8 (« Ramener »).

    Une seule copie a la fois. `_deplacement_en_cours` (nom historique, lu
    par la fenetre a la fermeture) vaut vrai pendant toute copie ; le jeu
    concerne ne peut pas etre lance pendant ce temps.
    """

    def _init_stockage(self) -> None:
        v = self.storage_view
        v.recalcul_requested.connect(self.recalculer_stockage)
        v.sauvegarder_requested.connect(self.sauvegarder_jeu)
        v.restaurer_requested.connect(self.restaurer_sauvegarde)
        v.supprimer_sauvegarde_requested.connect(self.supprimer_sauvegarde)
        v.ouvrir_sauvegarde_requested.connect(self._ouvrir_dossier_stockage)
        v.annuler_requested.connect(self.annuler_copie_stockage)
        v.ramener_requested.connect(self.ramener_jeu)
        self._deplacement_en_cours = False
        self._deplacement_uid = ""
        self._annulation = None
        self._calcul_stockage = False

    # ------------------------------------------------------------------
    # garde-fous
    # ------------------------------------------------------------------
    def _lancement_bloque(self, game) -> bool:
        """Vrai (avec un message) si ce jeu est en cours de copie : le lancer
        pendant la copie fausserait la sauvegarde (ou ferait perdre ce qu'il
        ecrit pendant une restauration ou un retour)."""
        if self._deplacement_en_cours and game is not None \
                and game.uid == self._deplacement_uid:
            QMessageBox.information(self, "Copie en cours",
                                    f"{game.title} est en cours de copie (sauvegarde, "
                                    "restauration ou retour) : attendez la fin de "
                                    "l'operation pour le lancer.")
            return True
        return False

    def _stockage_fermeture_permise(self) -> bool:
        """A appeler avant de fermer ORION : demande confirmation pendant une
        copie et, si le joueur ferme quand meme, annule la copie (la copie
        partielle est supprimee, ou nettoyee au prochain demarrage)."""
        if not self._deplacement_en_cours:
            return True
        rep = QMessageBox.question(
            self, "Copie en cours",
            "Une copie de jeu est en cours (sauvegarde, restauration ou retour).\n\n"
            "Fermer ORION maintenant l'interrompt : la copie partielle sera "
            "supprimee, le jeu installe n'est pas touche. Fermer quand meme ?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No)
        if rep != QMessageBox.StandardButton.Yes:
            return False
        self.annuler_copie_stockage()
        return True

    def _jeu_en_cours(self, game) -> bool:
        return game.uid in getattr(self.veille_jeu, "en_cours", {}) or any(
            getattr(s, "uid", "") == game.uid and getattr(s, "seconds", 1) == 0
            for s in getattr(self, "sessions", []))

    def _ouvrir_dossier_stockage(self, chemin: str) -> None:
        from ..core.lancement import startfile_propre
        try:
            startfile_propre(chemin)
        except OSError as exc:
            QMessageBox.warning(self, "Ouvrir le dossier",
                                f"Impossible d'ouvrir « {chemin} » : {exc}")

    # ------------------------------------------------------------------
    # remise en ordre au demarrage
    # ------------------------------------------------------------------
    def _reparer_deplacements(self) -> None:
        """Au demarrage : remet en ordre ce qu'un arret brutal pendant un
        deplacement, une sauvegarde ou une restauration aurait laisse."""
        jeux = self.library.games(include_hidden=True)
        racines = [str(d.get("mount", "")) for d in (self.hw.disks or [])]
        t = Task(_reparer_tout, jeux, racines)
        t.signals.finished.connect(self._deplacements_repares)
        t.signals.failed.connect(lambda m: log.warning("Remise en ordre impossible : %s", m))
        t.start()

    def _deplacements_repares(self, r) -> None:
        if r.modifie:
            self.library.save()
            self.refresh_storage()
        if r.actions:
            self.notify("Copie interrompue remise en ordre : " + r.actions[0], 12)
        absents = getattr(r, "absents", [])
        if absents:
            # un disque externe debranche : une notification discrete, pas une
            # boite d'alerte a chaque lancement (16 octobre)
            noms = ", ".join(a.split(" : ", 1)[0] for a in absents[:4])
            self.notify(f"Disque absent pour le moment : {noms}"
                        + (f" (+{len(absents) - 4})" if len(absents) > 4 else ""), 10)
        if r.restes:
            QMessageBox.warning(self, "Copie de jeu interrompue",
                                "Une copie de jeu (deplacement, sauvegarde ou "
                                "restauration) a ete interrompue. ORION a remis en "
                                "ordre ce qu'il pouvait ; reste a verifier :\n\n"
                                + "\n\n".join(r.restes[:8]))

    # ------------------------------------------------------------------
    # Recalculer
    # ------------------------------------------------------------------
    def recalculer_stockage(self) -> None:
        """Remesure en tache de fond la taille reelle des jeux et la place
        libre des disques. L'ancien bouton se contentait de reafficher les
        tailles annoncees par les launchers : rien ne changeait a l'ecran."""
        if self._calcul_stockage:
            return
        from ..storage import mesurer_stockage
        jeux = [(g.uid, g.install_dir) for g in self.library.games(include_hidden=True)
                if g.install_dir and not g.extra.get("missing")]
        montages = [str(d.get("mount", "")) for d in (self.hw.disks or []) if d.get("mount")]
        self._calcul_stockage = True
        self.storage_view.set_calcul(True, "mesure en cours...")
        from ..core.paths import is_windows
        t = Task(mesurer_stockage, jeux, montages, detecter=is_windows())
        t.signals.progress.connect(self.storage_view.progression_calcul)
        t.signals.finished.connect(self._stockage_recalcule)
        t.signals.failed.connect(self._stockage_recalcul_echec)
        t.start()

    def _stockage_recalcule(self, res: dict) -> None:
        import time
        self._calcul_stockage = False
        change = False
        for uid, octets in (res.get("tailles") or {}).items():
            g = self.library.get(uid)
            if g is not None and octets and g.size_bytes != octets:
                g.size_bytes = octets
                change = True
        if change:
            self.library.save()
        for d in self.hw.disks or []:
            neuf = (res.get("disques") or {}).get(str(d.get("mount", "")))
            if neuf:
                d.update(neuf)
        if res.get("liste_disques"):
            # disque externe branche (ou retire) depuis la derniere analyse ;
            # la liste est modifiee sur place : les autres pages la partagent
            self.hw.disks[:] = res["liste_disques"]
        self.refresh_storage()
        heure = time.strftime("%H:%M", time.localtime(res.get("heure") or time.time()))
        self.storage_view.set_calcul(False, f"calcule a {heure}")
        self.notify(f"Stockage recalcule ({len(res.get('tailles') or {})} jeux mesures)", 6)

    def _stockage_recalcul_echec(self, message: str) -> None:
        self._calcul_stockage = False
        self.storage_view.set_calcul(False, "calcul impossible")
        self.notify(f"Recalcul du stockage impossible : {message}", 10)

    # ------------------------------------------------------------------
    # Sauvegarder sur un autre disque
    # ------------------------------------------------------------------
    def sauvegarder_jeu(self, uid: str) -> None:
        from PySide6.QtWidgets import QInputDialog
        from .. import sauvegarde_disque as sd
        game = self.library.get(uid)
        if game is None or self._deplacement_en_cours:
            return
        titre_boite = "Sauvegarder sur un autre disque"
        if game.extra.get("deplace"):
            QMessageBox.information(self, titre_boite,
                                    "Ce jeu a ete deplace par une ancienne version d'ORION : "
                                    "ramenez-le d'abord sur son disque d'origine.")
            return
        if self._jeu_en_cours(game):
            QMessageBox.information(self, titre_boite,
                                    "Quittez le jeu avant de le sauvegarder : ses fichiers "
                                    "changeraient pendant la copie.")
            return
        cibles = sd.disques_sauvegarde(self.hw.disks, game.install_dir)
        if not cibles:
            QMessageBox.information(self, titre_boite,
                                    "Aucun autre disque n'a ete trouve sur ce PC. "
                                    "Branchez un disque externe puis cliquez « Recalculer ».")
            return
        nom = sd.nom_dossier(game.title, game.install_dir)
        existantes = {c["lettre"].upper() for c in cibles
                      if any(sd.dep._meme_chemin(s["chemin"], sd.destination(c["lettre"], nom))
                             for s in sd.liste(game))}
        choix = []
        for c in cibles:
            texte = f"{c['lettre']}  —  {c['libre_go']} Go libres sur {c['total_go']} Go"
            if c.get("amovible"):
                texte += "  (disque amovible)"
            if c["lettre"].upper() in existantes:
                texte += "  ·  sauvegarde existante, sera mise a jour"
            choix.append(texte)
        taille = f"{game.size_gb:.1f} Go".replace(".", ",") if game.size_bytes \
            else "taille inconnue"
        texte, ok = QInputDialog.getItem(
            self, f"Sauvegarder {game.title}",
            f"ORION va copier {game.title} ({taille}) dans « Sauvegardes ORION\\{nom} » "
            "sur le disque choisi, puis verifier la copie fichier par fichier.\n\n"
            "Le jeu installe n'est pas touche : il reste a sa place et Steam (ou Epic, "
            "GOG...) continue de l'utiliser normalement. Evitez de lancer le jeu ou de "
            "le mettre a jour pendant la copie.\n\nDisque de destination :",
            choix, 0, False)
        if not ok or texte not in choix:
            return
        cible = cibles[choix.index(texte)]
        disque = cible["lettre"]
        # controle rapide de la place (la copie le refait, au plus juste)
        if game.size_bytes and cible.get("libre_go") is not None \
                and cible["libre_go"] * 1024 ** 3 < game.size_bytes * sd.dep.MARGE:
            QMessageBox.warning(self, titre_boite,
                                f"Place insuffisante sur {disque} : {taille} necessaires, "
                                f"{cible['libre_go']} Go libres.")
            return
        remplacer = False
        if disque.upper() in existantes or sd.destination(disque, nom).exists():
            rep = QMessageBox.question(
                self, titre_boite,
                f"Une sauvegarde de {game.title} existe deja sur {disque}.\n\n"
                "La mettre a jour ? L'ancienne sauvegarde n'est supprimee qu'une fois "
                "la nouvelle complete et verifiee.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No)
            if rep != QMessageBox.StandardButton.Yes:
                return
            remplacer = True
        self._annulation = sd.Annulation()
        self._lancer_copie(
            game, "sauvegarder", f"Sauvegarde de {game.title}",
            f"vers {sd.destination(disque, nom)}",
            Task(sd.sauvegarder, game.install_dir, disque, nom,
                 annulation=self._annulation, remplacer=remplacer,
                 version=sd.version_du_jeu(game)))

    def restaurer_sauvegarde(self, uid: str, chemin: str) -> None:
        import os
        import time
        from .. import sauvegarde_disque as sd
        game = self.library.get(uid)
        if game is None or self._deplacement_en_cours:
            return
        titre_boite = "Restaurer la sauvegarde"
        if self._jeu_en_cours(game):
            QMessageBox.information(self, titre_boite,
                                    "Quittez le jeu avant de restaurer sa sauvegarde.")
            return
        if game.extra.get("deplace"):
            QMessageBox.information(self, titre_boite,
                                    "Ce jeu a ete deplace par une ancienne version d'ORION : "
                                    "ramenez-le d'abord sur son disque d'origine.")
            return
        if not os.path.isdir(chemin):
            QMessageBox.warning(self, titre_boite,
                                f"La sauvegarde « {chemin} » est introuvable (disque "
                                "debranche ?).")
            return
        fiche = next((s for s in sd.liste(game) if sd.dep._meme_chemin(s["chemin"], chemin)), {})
        quand = (time.strftime("du %d/%m/%Y a %H:%M", time.localtime(fiche["date"]))
                 if fiche.get("date") else "")
        remplacer = os.path.exists(game.install_dir)
        boite = QMessageBox(self)
        boite.setWindowTitle(titre_boite)
        if remplacer:
            boite.setIcon(QMessageBox.Icon.Warning)
            boite.setText(f"Remplacer les fichiers actuels de {game.title} ?")
            boite.setInformativeText(
                f"Les fichiers presents dans « {game.install_dir} » seront remplaces par "
                f"la sauvegarde {quand} (« {chemin} »).\n\n"
                "Tout ce qui a change depuis la sauvegarde (mises a jour, fichiers "
                "ajoutes) sera perdu. Les fichiers actuels ne sont supprimes qu'une fois "
                "la restauration complete et verifiee.")
            oui = boite.addButton("Remplacer les fichiers actuels",
                                  QMessageBox.ButtonRole.DestructiveRole)
        else:
            boite.setIcon(QMessageBox.Icon.Question)
            boite.setText(f"Restaurer {game.title} ?")
            boite.setInformativeText(
                f"La sauvegarde {quand} sera recopiee dans « {game.install_dir} », puis "
                "verifiee fichier par fichier.")
            oui = boite.addButton("Restaurer", QMessageBox.ButtonRole.AcceptRole)
        non = boite.addButton("Annuler", QMessageBox.ButtonRole.RejectRole)
        boite.setDefaultButton(non)
        boite.exec()
        if boite.clickedButton() is not oui:
            return
        self._annulation = sd.Annulation()
        self._lancer_copie(
            game, "restaurer", f"Restauration de {game.title}",
            f"depuis {chemin}",
            Task(sd.restaurer, chemin, game.install_dir, annulation=self._annulation,
                 remplacer=remplacer))

    def supprimer_sauvegarde(self, uid: str, chemin: str) -> None:
        import os
        from .. import sauvegarde_disque as sd
        game = self.library.get(uid)
        if game is None or self._deplacement_en_cours:
            return
        titre_boite = "Supprimer la sauvegarde"
        if not os.path.exists(chemin):
            rep = QMessageBox.question(
                self, titre_boite,
                f"La sauvegarde « {chemin} » est introuvable (disque debranche ?).\n\n"
                "La retirer de la liste ? Rien n'est supprime sur le disque.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No)
            if rep == QMessageBox.StandardButton.Yes:
                sd.oublier(game, chemin)
                self.library.save()
                self.refresh_storage()
            return
        rep = QMessageBox.question(
            self, titre_boite,
            f"Supprimer definitivement la sauvegarde de {game.title} ?\n\n« {chemin} »\n\n"
            "Le jeu installe n'est pas touche.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No)
        if rep != QMessageBox.StandardButton.Yes:
            return
        self._annulation = None
        self._lancer_copie(game, "supprimer", f"Suppression de la sauvegarde de {game.title}",
                           chemin, Task(sd.supprimer_sauvegarde, chemin), annulable=False,
                           contexte={"chemin": chemin})

    def annuler_copie_stockage(self) -> None:
        if self._annulation is not None:
            self._annulation.annuler()
            self.notify("Annulation demandee : la copie s'arrete...", 8)

    # ------------------------------------------------------------------
    # Ramener (jeux deplaces par jonction en 1.8)
    # ------------------------------------------------------------------
    def ramener_jeu(self, uid: str) -> None:
        from .. import deplacement
        game = self.library.get(uid)
        if game is None or self._deplacement_en_cours:
            return
        if self._jeu_en_cours(game):
            # la jonction se retire meme si le jeu tourne : ce qu'il ecrirait
            # ensuite dans l'ancienne destination serait perdu
            QMessageBox.information(self, "Ramener", "Quittez le jeu avant de le ramener.")
            return
        rep = QMessageBox.question(
            self, "Ramener", f"Ramener {game.title} sur son disque d'origine ?\n\n"
            "Fermez le launcher du jeu (Steam, Epic...) pendant l'operation.")
        if rep != QMessageBox.StandardButton.Yes:
            return
        restes: list[str] = []
        attendu = (game.extra.get("deplace") or {}).get("vers", "")
        self._annulation = None
        self._lancer_copie(game, "ramener", f"Retour de {game.title}",
                           f"vers {game.install_dir}",
                           Task(deplacement.ramener, game.install_dir, attendu=attendu,
                                restes=restes),
                           annulable=False, contexte={"restes": restes})

    # ------------------------------------------------------------------
    # copie en tache de fond
    # ------------------------------------------------------------------
    def _lancer_copie(self, game, action: str, titre: str, sous_titre: str, tache,
                      annulable: bool = True, contexte: dict | None = None) -> None:
        import time
        self._deplacement_en_cours = True
        self._deplacement_uid = game.uid
        self.storage_view.set_occupe(True)
        self.storage_view.debut_copie(titre, sous_titre, annulable,
                                      indetermine=action == "supprimer")
        self.notify(f"{titre} en cours...", 10)
        uid, nom, debut = game.uid, game.title, time.monotonic()
        contexte = dict(contexte or {})

        def avance(message: str, pourcent: int) -> None:
            self.storage_view.progression_copie(message, pourcent)
            if pourcent is not None and pourcent >= 0:
                self.status_label.setText(f"{titre} : {pourcent} %")
        tache.signals.progress.connect(avance)
        tache.signals.finished.connect(
            lambda r: self._copie_finie(uid, action, r, contexte, time.monotonic() - debut))
        tache.signals.failed.connect(lambda m: self._copie_echec(uid, nom, action, m))
        tache.start()

    def _fin_operation(self) -> None:
        self._deplacement_en_cours = False
        self._deplacement_uid = ""
        self._annulation = None
        self.storage_view.set_occupe(False)
        self.storage_view.fin_copie()

    def _copie_finie(self, uid: str, action: str, resultat, contexte: dict,
                     duree: float) -> None:
        from .. import sauvegarde_disque as sd
        from ..deplacement import duree_lisible, taille_lisible
        self._fin_operation()
        game = self.library.get(uid)
        titre = game.title if game else "Le jeu"
        if action == "sauvegarder":
            if game is not None:
                sd.noter(game, resultat)
                self.library.save()
            self.refresh_storage()
            self.notify(f"{titre} sauvegarde sur {resultat['chemin'][:2]}", 10)
            self._dialogue_fin(
                "Sauvegarde terminee", f"{titre} est sauvegarde.",
                f"Emplacement : {resultat['chemin']}\n"
                f"Taille : {taille_lisible(resultat['octets'])} "
                f"({resultat['fichiers']} fichiers, verifies un par un)\n"
                f"Duree : {duree_lisible(resultat.get('duree') or duree)}\n\n"
                "Le jeu installe n'a pas ete modifie.",
                resultat["chemin"], resultat.get("restes") or [])
        elif action == "restaurer":
            if game is not None:
                game.extra.pop("missing", None)
                self.library.save()
            self.refresh_storage()
            self.notify(f"{titre} restaure", 10)
            self._dialogue_fin(
                "Restauration terminee", f"{titre} est restaure.",
                f"Emplacement : {resultat['chemin']}\n"
                f"Taille : {taille_lisible(resultat['octets'])} "
                f"({resultat['fichiers']} fichiers, verifies un par un)\n"
                f"Duree : {duree_lisible(resultat.get('duree') or duree)}\n\n"
                "Si le launcher indique que le jeu n'est pas installe, lancez son "
                "installation vers le meme dossier : Steam, Epic et GOG retrouvent les "
                "fichiers presents et ne telechargent que ce qui manque.",
                resultat["chemin"], resultat.get("restes") or [])
        elif action == "supprimer":
            if game is not None:
                sd.oublier(game, contexte.get("chemin", ""))
                self.library.save()
            self.refresh_storage()
            self.notify(f"Sauvegarde de {titre} supprimee", 8)
            if resultat:
                QMessageBox.warning(self, "Suppression incomplete",
                                    "Des fichiers de la sauvegarde n'ont pas pu etre "
                                    "supprimes :\n\n" + "\n".join(resultat[:10]))
        else:                                            # ramener
            self._deplacement_fini(uid, "ramener", resultat, contexte.get("restes") or [])

    def _copie_echec(self, uid: str, titre: str, action: str, message: str) -> None:
        from .. import sauvegarde_disque as sd
        if action == "ramener":
            self._deplacement_echec(uid, action, message)
            self.storage_view.fin_copie()
            return
        self._fin_operation()
        self.refresh_storage()
        quoi = {"sauvegarder": "La sauvegarde", "restaurer": "La restauration",
                "supprimer": "La suppression de la sauvegarde"}[action]
        if "annulee" in message.split("\n", 1)[0]:
            self.notify(f"{quoi} de {titre} a ete annulee", 8)
            QMessageBox.information(self, "Operation annulee",
                                    f"{quoi} de {titre} a ete annulee.\n\n{message}")
            return
        etat = {"sauvegarder": sd.ORIGINAL_INTACT, "restaurer": "", "supprimer": ""}[action]
        if etat and etat not in message:
            message += f"\n\n{etat}"
        QMessageBox.warning(self, "Operation impossible",
                            f"{quoi} de {titre} a echoue :\n{message}")

    def _dialogue_fin(self, titre: str, texte: str, details: str, dossier: str,
                      restes: list) -> None:
        """Bilan clair d'une copie reussie, avec « Ouvrir le dossier »."""
        boite = QMessageBox(self)
        boite.setIcon(QMessageBox.Icon.Information)
        boite.setWindowTitle(titre)
        boite.setText(texte)
        if restes:
            details += "\n\nA nettoyer a la main :\n" + "\n".join(restes)
        boite.setInformativeText(details)
        ouvrir = boite.addButton("Ouvrir le dossier", QMessageBox.ButtonRole.ActionRole)
        fermer = boite.addButton("Fermer", QMessageBox.ButtonRole.AcceptRole)
        boite.setDefaultButton(fermer)
        boite.exec()
        if boite.clickedButton() is ouvrir:
            self._ouvrir_dossier_stockage(dossier)

    def _deplacement_fini(self, uid: str, action: str, resultat, restes=()) -> None:
        """Fin d'un « Ramener » (ou d'un ancien deplacement)."""
        import time
        self._deplacement_en_cours = False
        self._deplacement_uid = ""
        self.storage_view.set_occupe(False)
        self.storage_view.fin_copie()
        game = self.library.get(uid)
        if game is not None:
            if action == "deplacer":
                game.extra["deplace"] = {"vers": resultat, "le": time.time()}
            else:
                game.extra.pop("deplace", None)
            self.library.save()
        self.notify(f"{game.title if game else 'Jeu'} "
                    f"{'deplace vers ' + str(resultat) if action == 'deplacer' else 'ramene sur son disque'}", 10)
        self.refresh_storage()
        if restes:
            QMessageBox.warning(self, "Nettoyage incomplet",
                                "L'operation a reussi, mais des fichiers n'ont pas pu etre "
                                "supprimes :\n\n" + "\n\n".join(restes))

    def _deplacement_echec(self, uid: str, action: str, message: str) -> None:
        from ..deplacement import ETAT
        self._deplacement_en_cours = False
        self._deplacement_uid = ""
        self.storage_view.set_occupe(False)
        game = self.library.get(uid)
        titre = game.title if game else "Le jeu"
        if ETAT not in message:
            # erreur inattendue : on ne pretend pas savoir ou en est le jeu
            dossier = game.install_dir if game else ""
            message += (f"\n\n{ETAT} inconnu — verifiez le dossier « {dossier} » et le "
                        "dossier « Jeux ORION » du disque de destination.")
        grave = "A REPARER" in message or "inconnu" in message
        boite = QMessageBox.critical if grave else QMessageBox.warning
        boite(self, "Deplacement" if action == "deplacer" else "Retour",
              f"{titre} n'a pas ete {'deplace' if action == 'deplacer' else 'ramene'} :"
              f"\n{message}")
        self.refresh_storage()


def _reparer_tout(jeux, racines):
    """Remise en ordre au demarrage : deplacements (1.8) puis sauvegardes."""
    from ..deplacement import reparer_restes
    from ..sauvegarde_disque import reparer_restes as reparer_sauvegardes
    r = reparer_restes(jeux, racines)
    r2 = reparer_sauvegardes(jeux, racines)
    r.actions += r2.actions
    r.restes += r2.restes
    r.absents += getattr(r2, "absents", [])
    r.modifie = r.modifie or r2.modifie
    return r
