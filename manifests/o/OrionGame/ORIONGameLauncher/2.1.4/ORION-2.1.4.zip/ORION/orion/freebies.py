"""Veille des jeux gratuits.

ORION interroge en direct les boutiques et les agregateurs publics, fusionne
ce qu'ils annoncent, puis complete chaque jeu avec ce qui compte vraiment
avant de cliquer : solo ou multijoueur, cooperation, jeu en ligne, jeu
multiplateforme, note des joueurs, prix habituel, et un lien direct vers la
page de recuperation.

La question decisive est la nature de la gratuite (voir
`plugins/freebies/base.py`). Elle commande ce qui se passe ensuite :

* gratuit pour toujours ou cadeau garde a vie : rien n'expire, ORION propose
  simplement la suppression complete du jeu si on n'en veut plus ;
* gratuit temporairement (week-end gratuit, essai) : passee la date, le jeu
  n'est plus jouable. ORION le signale, propose de le desinstaller et ouvre
  la page d'achat pour ceux qui veulent continuer.

Aucune information n'est envoyee : la veille est en lecture seule.
"""
from __future__ import annotations

from orion.core import region

import hashlib
import time
from pathlib import Path

from .core.config import CONFIG
from .core.logging_setup import get
from .core.models import Game, normalize_title
from .core.paths import ART_DIR, DATA_DIR, ensure_dirs
from .core.registry import available as only_available
from .core.registry import discover
from .plugins.artwork.base import download
from .plugins.freebies.base import (A_GARDER, DEFINITIF, TEMPORAIRE, Freebie,
                                    FreebieSource, SourceUnavailable,
                                    is_demo, is_extra)

log = get("gratuits")

FREE_FILE = DATA_DIR / "gratuits.json"
FREE_ART = ART_DIR / "gratuits"

DETAILS = "https://store.steampowered.com/api/appdetails"
REVIEWS = "https://store.steampowered.com/appreviews/{appid}"
STORE_SEARCH = "https://store.steampowered.com/api/storesearch/"
from .core.steam_limite import NAVIGATEUR as HEADERS  # noqa: E402

#: categories Steam traduites en modes de jeu lisibles
MODES = {
    2: "Solo",
    1: "Multijoueur",
    49: "Joueur contre joueur",
    36: "Joueur contre joueur en ligne",
    37: "Joueur contre joueur en ecran partage",
    9: "Cooperation",
    38: "Cooperation en ligne",
    39: "Cooperation en ecran partage",
    20: "Jeu en ligne massivement multijoueur",
    27: "Multijoueur multiplateforme",
    47: "Joueur contre joueur en reseau local",
    48: "Cooperation en reseau local",
}

#: modes qui impliquent une connexion
ONLINE = {1, 36, 38, 20, 27}

#: ordre d'affichage des etiquettes
MODE_ORDER = [2, 9, 38, 39, 1, 36, 37, 49, 20, 27, 47, 48]


#: une offre est « du jour » quand elle a commence il y a moins d'un jour
DU_JOUR = 24 * 3600


def annonce_du_jour(offres, maintenant: float | None = None,
                    premiere_fois: bool = False) -> tuple[str, str] | None:
    """La notification a envoyer pour les jeux gratuits du jour : (titre,
    message), ou `None` s'il n'y a rien a annoncer.

    Une seule notification par releve, quel que soit le nombre de jeux, et
    chaque offre n'est annoncee qu'une fois (`Freebie.annonce`). Seules les
    offres du jour comptent : un jeu a recuperer, ou jouable gratuitement
    quelques jours, qui a commence il y a moins d'un jour. Une offre a venir
    attend son jour. Ne sont jamais annonces : les jeux gratuits en
    permanence, les offres terminees, celles commencees depuis plus d'un jour
    (ORION etait ferme) et, au tout premier releve, celles dont la date de
    debut est inconnue (toute la liste serait « nouvelle »)."""
    maintenant = maintenant or time.time()
    du_jour = []
    for fb in offres or []:
        if fb.annonce:
            continue
        if fb.starts_at and fb.starts_at > maintenant:
            continue                         # a venir : annoncee le jour venu
        fb.annonce = True                    # son sort est regle, annoncee ou non
        if fb.adulte or fb.dismissed or fb.claimed or fb.kind == DEFINITIF:
            continue
        if fb.ends_at and fb.ends_at <= maintenant:
            continue
        if fb.starts_at:
            if maintenant - fb.starts_at >= DU_JOUR:
                continue
        elif premiere_fois:
            continue
        du_jour.append(fb)
    if not du_jour:
        return None
    if len(du_jour) == 1:
        fb = du_jour[0]
        boutique = fb.shop or "la boutique"
        fin = time.strftime("%d/%m", time.localtime(fb.ends_at)) if fb.ends_at else ""
        # (2.1.2) « Sans DRM » n'est pas une boutique : « offert sans DRM », jamais
        # « offert sur Sans DRM » (meme correction que le flux RSS du service)
        sans_drm = fb.shop == "Sans DRM"
        if fb.kind == TEMPORAIRE and fin:
            message = (f"Jouable gratuitement, sans DRM, jusqu'au {fin} : {fb.title}" if sans_drm
                       else f"Jouable gratuitement sur {boutique} jusqu'au {fin} : {fb.title}")
        elif fin:
            message = (f"Offert sans DRM jusqu'au {fin} : {fb.title}" if sans_drm
                       else f"Offert sur {boutique} jusqu'au {fin} : {fb.title}")
        else:
            message = (f"Offert en ce moment, sans DRM : {fb.title}" if sans_drm
                       else f"Offert en ce moment sur {boutique} : {fb.title}")
        return "Jeu gratuit du jour", message
    noms = ", ".join(fb.title for fb in du_jour[:3])
    if len(du_jour) > 3:
        noms += f" (+{len(du_jour) - 3})"
    return "Jeux gratuits du jour", f"{len(du_jour)} jeux gratuits aujourd'hui : {noms}"


def _art_path(key: str) -> Path:
    FREE_ART.mkdir(parents=True, exist_ok=True)
    return FREE_ART / (hashlib.sha1(key.encode()).hexdigest()[:16] + ".jpg")


class FreebiesService:
    """Collecte, fusionne et conserve les offres gratuites du moment."""

    def __init__(self) -> None:
        ensure_dirs()
        self.items: dict[str, Freebie] = {}
        self.last_refresh: float = 0.0
        self.errors: list[str] = []
        self._sources: list[FreebieSource] | None = None
        self.load()

    # -- plugins --------------------------------------------------------
    def sources(self) -> list[FreebieSource]:
        if self._sources is None:
            found = discover(FreebieSource, "orion.plugins.freebies", "freebies")
            self._sources = only_available(found)
        return self._sources

    def reload_plugins(self) -> None:
        self._sources = None

    def enabled_sources(self) -> list[FreebieSource]:
        wanted = set(CONFIG.get("free.sources") or [])
        sources = self.sources()
        if not wanted:
            return sources
        return [s for s in sources if s.id in wanted]

    # -- persistance ----------------------------------------------------
    def load(self) -> None:
        from .core.base import Document
        self._doc = Document("gratuits", FREE_FILE)
        try:
            raw = self._doc.lire(None)
            if raw:
                self.last_refresh = float(raw.get("last_refresh") or 0)
                for d in raw.get("items") or []:
                    fb = Freebie.from_dict(d)
                    self.items[fb.key] = fb
        except Exception:
            log.exception("Liste des jeux gratuits illisible")

    def save(self) -> None:
        self._doc.ecrire({"last_refresh": self.last_refresh,
                          "items": [f.to_dict() for f in self.items.values()]})

    def should_refresh(self) -> bool:
        if not CONFIG.get("free.enabled", True):
            return False
        hours = float(CONFIG.get("free.refresh_hours", 6) or 6)
        return (time.time() - self.last_refresh) > hours * 3600

    # -- consultation ---------------------------------------------------
    def all(self, kind: str = "", query: str = "",
            include_expired: bool = False) -> list[Freebie]:
        """Offres visibles, les plus urgentes d'abord."""
        needle = normalize_title(query) if query else ""
        from .core.recherche import correspond
        out = []
        for fb in self.items.values():
            if fb.dismissed or fb.adulte:      # decision centrale (contenu_adulte)
                continue
            if not include_expired and fb.expired:
                continue
            if kind and kind != fb.kind:
                continue
            if needle and needle not in fb.norm \
                    and not correspond(query, fb.title):
                continue
            out.append(fb)

        def rank(f: Freebie) -> tuple:
            # a venir en dernier, puis le plus pressant en premier
            return (f.upcoming,
                    0 if f.ends_at else 1,
                    f.ends_at or 0,
                    -f.seen_at)

        return sorted(out, key=rank)

    def counts(self) -> dict[str, int]:
        out = {DEFINITIF: 0, A_GARDER: 0, TEMPORAIRE: 0}
        for fb in self.all():
            out[fb.kind] = out.get(fb.kind, 0) + 1
        return out

    def get(self, key: str) -> Freebie | None:
        return self.items.get(key)

    def mark_claimed(self, key: str) -> None:
        fb = self.items.get(key)
        if fb is not None:
            fb.claimed_at = time.time()
            self.save()

    def dismiss(self, key: str) -> None:
        fb = self.items.get(key)
        if fb is not None:
            fb.dismissed = True
            self.save()

    def art(self, fb: Freebie) -> str:
        path = _art_path(fb.key)
        return str(path) if path.exists() else ""

    # -- correspondance avec la bibliotheque ----------------------------
    def installed(self, games: list[Game]) -> dict[str, Game]:
        """Offres dont le jeu est present sur le disque : cle -> jeu.

        Le rapprochement se fait d'abord par identifiant Steam, qui ne ment
        pas, puis par titre normalise pour les boutiques qui n'en publient
        pas.
        """
        by_norm: dict[str, Game] = {}
        by_appid: dict[str, Game] = {}
        for g in games:
            if g.extra.get("missing"):
                continue
            by_norm.setdefault(normalize_title(g.title), g)
            if g.source == "steam" and g.source_id:
                by_appid.setdefault(str(g.source_id), g)

        out: dict[str, Game] = {}
        for fb in self.items.values():
            game = (by_appid.get(fb.steam_appid) if fb.steam_appid else None)
            if game is None:
                game = by_norm.get(fb.norm)
            if game is not None:
                out[fb.key] = game
        return out

    # -- expiration -----------------------------------------------------
    def expired_temporaries(self, games: list[Game]) -> list[tuple[Freebie, Game]]:
        """Jeux pris pendant une gratuite temporaire, desormais terminee.

        Ce sont les seuls cas ou ORION alerte de lui-meme : le jeu etait
        prete, il ne l'est plus. Les cadeaux gardes a vie ne declenchent
        jamais d'alerte ; leur suppression reste proposee, sans urgence,
        sur la ligne de l'offre.
        """
        found = self.installed(games)
        out: list[tuple[Freebie, Game]] = []
        for key, game in found.items():
            fb = self.items.get(key)
            if fb is not None and fb.temporary and fb.expired:
                out.append((fb, game))
        return out

    def pending_alerts(self, games: list[Game]) -> list[tuple[Freebie, Game]]:
        """Gratuites temporaires terminees dont il faut prevenir maintenant.

        Une offre n'est annoncee qu'une fois : le bandeau de la page reste
        ensuite visible tant que le jeu est sur le disque, mais ORION ne
        revient pas a la charge a chaque demarrage.
        """
        out = []
        for fb, game in self.expired_temporaries(games):
            if fb.alerted_at:
                continue
            fb.alerted_at = time.time()
            out.append((fb, game))
        if out:
            self.save()
        return out

    def removal_notice(self, fb: Freebie) -> str:
        """Ce que l'utilisateur perd — ou ne perd pas — en desinstallant."""
        if fb.kind == DEFINITIF:
            return ("Ce jeu est gratuit en permanence : vous pourrez le "
                    "reinstaller quand vous voulez, sans rien payer.")
        if fb.kind == A_GARDER:
            shop = fb.shop or "la boutique"
            return (f"Le jeu reste acquis sur votre compte {shop} : le "
                    "desinstaller libere seulement de la place, vous pourrez "
                    "le retelecharger plus tard.")
        return ("La periode gratuite est terminee : le jeu n'est plus "
                "jouable sans l'acheter.")

    def purge(self, days: int = 45) -> int:
        """Oublie les offres terminees depuis longtemps."""
        limit = time.time() - days * 86400
        dead = [k for k, f in self.items.items()
                if f.ends_at and f.ends_at < limit and not f.claimed]
        for k in dead:
            self.items.pop(k, None)
        return len(dead)

    # -- rafraichissement ----------------------------------------------
    def refresh(self, progress_cb=None, force: bool = False) -> dict:
        """Interroge toutes les sources et met la liste a jour."""
        result = {"new": 0, "updated": 0, "removed": 0, "total": 0,
                  "sources": 0, "errors": [], "arrivals": [],
                  # premier releve : toute la liste est « nouvelle »
                  "premiere": not self.items}
        if not CONFIG.get("free.enabled", True) and not force:
            return result

        def step(message: str, percent: int) -> None:
            if progress_cb:
                progress_cb(message, percent)

        sources = self.enabled_sources()
        if not sources:
            result["errors"].append("Aucune source de jeux gratuits active.")
            return result

        collected: list[Freebie] = []
        answered: set[str] = set()
        for i, source in enumerate(sources):
            step(f"{source.label}...", int(5 + i * 45 / max(len(sources), 1)))
            try:
                found = source.fetch() or []
            except SourceUnavailable as exc:
                # panne reseau ou service indisponible : la source n'a rien
                # dit. Elle n'entre pas dans `answered`, donc ce qu'elle
                # avait deja trouve reste affiche.
                log.warning("Source injoignable : %s (%s)", source.id, exc)
                result["errors"].append(source.label)
                continue
            except Exception:
                log.exception("Source de gratuites en echec : %s", source.id)
                result["errors"].append(source.label)
                continue
            result["sources"] += 1
            answered.add(source.id)
            collected.extend(found)

        merged = self._merge(collected)
        step("Details des jeux...", 55)
        self._enrich(merged, step)

        seen_now = set()
        for fb in merged.values():
            seen_now.add(fb.key)
            old = self.items.get(fb.key)
            if old is None:
                self.items[fb.key] = fb
                result["new"] += 1
                result["arrivals"].append(fb)
            else:
                # ce que l'utilisateur a decide ne doit jamais etre ecrase
                fb.claimed_at = old.claimed_at
                fb.alerted_at = old.alerted_at
                fb.dismissed = old.dismissed
                fb.annonce = old.annonce
                fb.seen_at = old.seen_at
                self.items[fb.key] = fb
                result["updated"] += 1

        result["removed"] = self._drop_gone(seen_now, answered)
        self.purge()
        # avant l'enregistrement : ce qui est annonce ne le sera plus
        result["annonce"] = annonce_du_jour(list(self.items.values()),
                                            premiere_fois=result["premiere"])
        self.last_refresh = time.time()
        self.save()
        result["total"] = len(self.all())
        step("", 100)
        log.info("Jeux gratuits : %s", {k: v for k, v in result.items()
                                        if k not in ("arrivals", "annonce")})
        return result

    def _drop_gone(self, seen: set[str], answered: set[str]) -> int:
        """Retire les offres que leur source n'annonce plus.

        Sans cela, une offre terminee, ou fusionnee avec l'annonce officielle
        d'une boutique, resterait affichee indefiniment. Seules les sources
        qui ont repondu sont concernees : une source injoignable ne fait
        jamais disparaitre ce qu'elle avait deja trouve. Ce que
        l'utilisateur a recupere est conserve dans tous les cas.
        """
        now = time.time()
        gone = [key for key, fb in self.items.items()
                if key not in seen and fb.source in answered and not fb.claimed]
        removed = 0
        for key in gone:
            fb = self.items.get(key)
            # Un week-end gratuit sans date de fin publiee s'arrete le jour ou
            # la boutique cesse de l'annoncer : c'est precisement l'instant ou
            # le jeu redevient payant. L'offre est donc datee plutot que
            # supprimee, pour que l'alerte de desinstallation puisse partir.
            if fb is not None and fb.temporary and not fb.ends_at:
                fb.ends_at = now
                log.info("Gratuite temporaire terminee : %s", fb.title)
                continue
            self.items.pop(key, None)
            removed += 1
        if removed:
            log.info("%d offre(s) retiree(s) : plus annoncee(s)", removed)
        return removed

    # ------------------------------------------------------------------
    @staticmethod
    def _merge(found: list[Freebie]) -> dict[str, Freebie]:
        """Fusionne les annonces d'un meme jeu sur une meme boutique."""
        hide_demos = bool(CONFIG.get("free.hide_demos", True))
        by_ident: dict[tuple, Freebie] = {}
        for fb in found:
            if not fb.title:
                continue
            # une demo n'est pas un jeu gratuit : c'est un extrait d'un jeu
            # payant. Les catalogues en publient des dizaines, qui noient
            # les vraies offres. Une bande-son ou un artbook ne sont pas
            # davantage des jeux : la page repond a « a quoi puis-je jouer
            # gratuitement ? ».
            if hide_demos and (is_demo(fb.title) or is_extra(fb.title)):
                continue
            ident = (fb.norm, fb.shop.lower())
            kept = by_ident.get(ident)
            if kept is None:
                by_ident[ident] = fb
                continue
            # on garde l'entree la plus informative, en completant les trous
            best, other = (kept, fb) if _score(kept) >= _score(fb) else (fb, kept)
            for field_name in ("ends_at", "starts_at", "worth", "image",
                               "description", "steam_appid", "buy_url", "url"):
                if not getattr(best, field_name, None):
                    setattr(best, field_name, getattr(other, field_name, None)
                            or getattr(best, field_name))
            # une annonce de week-end gratuit l'emporte : elle engage le joueur
            if other.kind == TEMPORAIRE:
                best.kind = TEMPORAIRE
            by_ident[ident] = best
        return {fb.key: fb for fb in by_ident.values()}

    def _enrich(self, merged: dict[str, Freebie], step) -> None:
        """Complete les details depuis Steam, et telecharge les visuels."""
        # les offres qui expirent passent en premier : ce sont celles pour
        # lesquelles les details changent une decision.
        entries = sorted(merged.values(),
                         key=lambda f: (not f.ends_at, f.ends_at or 0))
        budget = int(CONFIG.get("free.detail_budget", 40) or 40)
        done = 0
        for i, fb in enumerate(entries):
            step(f"Details : {fb.title}", 55 + int(i * 40 / max(len(entries), 1)))
            old = self.items.get(fb.key)
            if old is not None and old.modes and old.title == fb.title:
                # deja detaille lors d'un passage precedent
                for name in ("steam_appid", "modes", "platforms", "genres",
                             "review_score", "review_label", "metacritic",
                             "release_date", "developer", "screenshots",
                             "shots_local", "price_before"):
                    setattr(fb, name, getattr(old, name))
                if not fb.buy_url:
                    fb.buy_url = old.buy_url
            elif done < budget:
                done += 1
                try:
                    self._from_steam(fb)
                except Exception:
                    log.debug("Details indisponibles pour %s", fb.title)
            self._cover(fb)
            # conditions d'obtention en francais (GamerPower les donne en
            # anglais) ; la traduction est gardee en cache, donc gratuite
            # aux passages suivants
            if fb.conditions and CONFIG.get("market.translate_news", True):
                try:
                    from .core.traduction import traduire
                    from .plugins.freebies.consignes import traduire_consignes
                    fr, complet = traduire_consignes(fb.conditions)
                    # phrases types traduites localement ; le service en
                    # ligne n'est sollicite que pour les consignes inedites
                    fb.conditions = fr if complet else traduire(fb.conditions)
                except Exception:
                    log.debug("Conditions non traduites pour %s", fb.title)

    def _from_steam(self, fb: Freebie) -> None:
        from orion.core import reseau
        from .core import steam_limite
        if steam_limite.en_pause():
            return
        appid = fb.steam_appid or self._resolve_appid(fb.title)
        if not appid:
            return
        fb.steam_appid = appid
        steam_limite.attendre()
        try:
            r = reseau.get(DETAILS, params={"appids": appid, "cc": region.cc(),
                                              "l": region.langue_steam()},
                             headers=HEADERS, timeout=9)
            payload = steam_limite.fiche(r.json(), appid)
            if not payload.get("success"):
                return
            data = payload.get("data") or {}
        except Exception:
            return

        ids = {int(c.get("id")) for c in data.get("categories") or []
               if str(c.get("id") or "").isdigit()}
        fb.modes = [MODES[i] for i in MODE_ORDER if i in ids and i in MODES]
        if ids & ONLINE and "Jeu en ligne" not in fb.modes:
            fb.modes.append("Jeu en ligne")

        plats = data.get("platforms") or {}
        fb.platforms = [name for key, name in
                        (("windows", "Windows"), ("mac", "macOS"),
                         ("linux", "Linux")) if plats.get(key)]

        fb.genres = [str(g.get("description") or "")
                     for g in data.get("genres") or []][:4]
        fb.release_date = (data.get("release_date") or {}).get("date", "")
        # quelques images valent mieux qu'une description : on garde les
        # miniatures, assez legeres pour etre mises en cache.
        from . import contenu_adulte
        adulte = contenu_adulte.fiche_adulte(data)
        contenu_adulte.marquer(appid, adulte)
        fb.adulte = fb.adulte or adulte
        fb.screenshots = [] if adulte else [
            str(s.get("path_thumbnail") or "")
            for s in (data.get("screenshots") or [])[:4]
            if s.get("path_thumbnail")]
        fb.developer = ", ".join(data.get("developers") or [])[:80]
        meta = data.get("metacritic") or {}
        if meta.get("score"):
            fb.metacritic = int(meta["score"])
        price = data.get("price_overview") or {}
        if price.get("initial"):
            # prix Steam dans la devise du pays configure : la devise de
            # l'annonce d'origine ne vaut plus, on la remplace.
            if not fb.worth:
                fb.worth = round(int(price["initial"]) / 100, 2)
            fb.currency = str(price.get("currency") or "EUR")
            # « final » est le prix affiche juste avant la gratuite : c'est
            # ce que le jeu coutait encore hier, et ce qu'il recoutera.
            fb.price_before = round(int(price.get("final")
                                        or price["initial"]) / 100, 2)
        elif data.get("is_free") and not fb.price_before:
            fb.price_before = 0.0
        if not fb.buy_url:
            fb.buy_url = f"https://store.steampowered.com/app/{appid}"

        self._reviews(appid, fb)

    @staticmethod
    def _reviews(appid: str, fb: Freebie) -> None:
        from orion.core import reseau
        try:
            r = reseau.get(REVIEWS.format(appid=appid),
                             params={"json": 1, "language": "all",
                                     "purchase_type": "all", "num_per_page": 0},
                             headers=HEADERS, timeout=9)
            summary = (r.json() or {}).get("query_summary") or {}
        except Exception:
            return
        total = int(summary.get("total_reviews") or 0)
        if not total:
            return
        fb.review_count = total
        fb.review_score = round(int(summary.get("total_positive") or 0)
                                / total * 100)
        fb.review_label = _FR_REVIEWS.get(
            str(summary.get("review_score_desc") or ""),
            str(summary.get("review_score_desc") or ""))

    @staticmethod
    def _resolve_appid(title: str) -> str:
        from orion.core import reseau
        try:
            r = reseau.get(STORE_SEARCH, params={"term": title, "cc": region.cc(),
                                                   "l": region.langue_steam()},
                             headers=HEADERS, timeout=9)
            items = (r.json() or {}).get("items") or []
        except Exception:
            return ""
        key = normalize_title(title)
        for item in items[:5]:
            if normalize_title(str(item.get("name") or "")) == key:
                return str(item.get("id") or "")
        return ""

    @staticmethod
    def _cover(fb: Freebie) -> None:
        if fb.image:
            path = _art_path(fb.key)
            if not path.exists():
                try:
                    download(fb.image, path)
                except Exception:
                    log.debug("Visuel indisponible pour %s", fb.title)

        # miniatures du jeu : trois suffisent a se faire une idee
        locaux: list[str] = []
        for i, adresse in enumerate(fb.screenshots[:3]):
            cible = _art_path(f"{fb.key}:shot{i}")
            if not cible.exists():
                try:
                    download(adresse, cible)
                except Exception:
                    continue
            if cible.exists():
                locaux.append(str(cible))
        if locaux:
            fb.shots_local = locaux


def _score(fb: Freebie) -> int:
    """Richesse d'une annonce, pour choisir laquelle garder en cas de doublon."""
    return (bool(fb.ends_at) * 4 + bool(fb.worth) * 2 + bool(fb.image)
            + bool(fb.description) + bool(fb.steam_appid) * 2)


_FR_REVIEWS = {
    "Overwhelmingly Positive": "Extremement positives",
    "Very Positive": "Tres positives",
    "Positive": "Positives",
    "Mostly Positive": "Plutot positives",
    "Mixed": "Moyennes",
    "Mostly Negative": "Plutot negatives",
    "Negative": "Negatives",
    "Very Negative": "Tres negatives",
    "Overwhelmingly Negative": "Extremement negatives",
}
