"""Tuile d'un jeu dans la bibliotheque."""
from __future__ import annotations

import hashlib
from pathlib import Path

from PySide6.QtCore import QRectF, QSize, Qt, Signal
from PySide6.QtGui import (QBrush, QColor, QFont, QImage, QImageReader,
                           QLinearGradient, QPainter, QPainterPath, QPixmap)
from PySide6.QtWidgets import (QFrame, QLabel, QMenu, QSizePolicy, QToolButton,
                               QVBoxLayout)

from ...core.models import Game

RATIO = 1.5          # jaquette 2:3


def placeholder(title: str, size: QSize, seed: str = "") -> QPixmap:
    """Visuel de repli : degrade colore + initiales, toujours lisible."""
    pix = QPixmap(size)
    pix.fill(Qt.GlobalColor.transparent)
    h = int(hashlib.sha1((seed or title).encode("utf-8", "ignore")).hexdigest()[:6], 16)
    hue = h % 360
    c1 = QColor.fromHsl(hue, 120, 58)
    c2 = QColor.fromHsl((hue + 40) % 360, 130, 26)

    p = QPainter(pix)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    grad = QLinearGradient(0, 0, size.width(), size.height())
    grad.setColorAt(0, c1)
    grad.setColorAt(1, c2)
    path = QPainterPath()
    path.addRoundedRect(QRectF(0, 0, size.width(), size.height()), 10, 10)
    p.fillPath(path, QBrush(grad))

    initials = "".join(w[0] for w in title.split()[:3] if w and w[0].isalnum()).upper()
    f = QFont("Segoe UI", max(size.width() // 5, 14))
    f.setBold(True)
    p.setFont(f)
    p.setPen(QColor(255, 255, 255, 220))
    p.drawText(pix.rect(), Qt.AlignmentFlag.AlignCenter, initials or "?")
    p.end()
    return pix


_MEMO: dict[tuple, QPixmap] = {}


def miniature(chemin: str, size: QSize) -> QPixmap:
    """Jaquette recadree et arrondie a la taille de la tuile.

    Une jaquette fait 1200x1800 pour une tuile de 190 pixels : la decoder en
    entier a chaque affichage coutait 20 ms par jeu. Elle est donc lue
    directement a la bonne taille, gardee en memoire, et sa miniature est
    ecrite sur le disque pour les lancements suivants."""
    try:
        date = Path(chemin).stat().st_mtime
    except OSError:
        return QPixmap()
    cle = (chemin, date, size.width(), size.height())
    pix = _MEMO.get(cle)
    if pix is not None:
        return pix
    import hashlib
    from ...core.paths import ART_DIR
    nom = hashlib.sha1(chemin.encode("utf-8", "replace")).hexdigest()[:16]
    base = ART_DIR / "mini" / f"{nom}-{size.width()}x{size.height()}"
    img = QImage()
    for ext in ("jpg", "png"):
        mini = base.with_suffix("." + ext)
        try:
            if mini.exists() and mini.stat().st_mtime >= date:
                img = QImage(str(mini))
                if not img.isNull():
                    break
        except OSError:
            pass
    if img.isNull():
        lecteur = QImageReader(chemin)
        lecteur.setAutoTransform(True)
        taille = lecteur.size()
        if taille.isValid() and taille.width() > size.width() * 1.5:
            lecteur.setScaledSize(taille.scaled(
                size, Qt.AspectRatioMode.KeepAspectRatioByExpanding))
        img = lecteur.read()
        if img.isNull():
            return QPixmap()
        try:
            base.parent.mkdir(parents=True, exist_ok=True)
            if img.hasAlphaChannel():
                img.save(str(base.with_suffix(".png")), "PNG")
            else:
                img.save(str(base.with_suffix(".jpg")), "JPG", 90)
        except Exception:
            pass
    pix = rounded(QPixmap.fromImage(img), size)
    if len(_MEMO) > 2000:
        _MEMO.clear()
    _MEMO[cle] = pix
    return pix


def attenuer(pix: QPixmap, opacite: float) -> QPixmap:
    """Copie semi-transparente (jeu non installe ou introuvable)."""
    out = QPixmap(pix.size())
    out.fill(Qt.GlobalColor.transparent)
    p = QPainter(out)
    p.setOpacity(opacite)
    p.drawPixmap(0, 0, pix)
    p.end()
    return out


def rounded(pix: QPixmap, size: QSize, radius: int = 10) -> QPixmap:
    """Redimensionne en recadrant au centre et arrondit les coins."""
    scaled = pix.scaled(size, Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                        Qt.TransformationMode.SmoothTransformation)
    x = max(0, (scaled.width() - size.width()) // 2)
    y = max(0, (scaled.height() - size.height()) // 2)
    cropped = scaled.copy(x, y, size.width(), size.height())

    out = QPixmap(size)
    out.fill(Qt.GlobalColor.transparent)
    p = QPainter(out)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    path = QPainterPath()
    path.addRoundedRect(QRectF(0, 0, size.width(), size.height()), radius, radius)
    p.setClipPath(path)
    p.drawPixmap(0, 0, cropped)
    p.end()
    return out


#: actions du menu ⋮ : (cle, libelle). None = separateur.
#: La vue ne fait que relayer la cle ; c'est la fenetre principale qui agit.
def menu_actions(game: Game) -> list[tuple[str, str] | None]:
    from ...core.liens import fiche_lanceur
    if game.extra.get("non_installe"):
        # jeu possede mais pas sur ce PC : l'installer, ou le voir en magasin
        return [("installer", f"Installer avec {game.source.capitalize()}"),
                ("magasin", "Page du magasin"), None,
                ("masquer", "Ne plus afficher ce jeu")]
    missing = bool(game.extra.get("missing"))
    out: list[tuple[str, str] | None] = []
    if not missing:
        out.append(("jouer", "Jouer"))
    out.append(("fiche", "Ouvrir la fiche du jeu"))
    out.append(None)
    out.append(("magasin", "Page du magasin"))
    uri, libelle = fiche_lanceur(game)
    if uri:
        out.append(("lanceur", libelle))
    if game.install_dir and not missing:
        out.append(("dossier", "Ouvrir le dossier du jeu"))
    out.append(None)
    out.append(("favori", "Retirer des favoris" if game.favorite
                else "Ajouter aux favoris"))
    out.append(("masquer", "Ne plus masquer" if game.hidden
                else "Masquer de la bibliotheque"))
    if not missing:
        out.append(None)
        out.append(("desinstaller", "Desinstaller..."))
    return out


def texte_meta(g: Game) -> str:
    """Ligne d'informations sous le titre d'une tuile."""
    if g.extra.get("non_installe"):
        joue = g.total_play_seconds
        temps = (f"  ·  {joue // 3600} h" if joue >= 3600 else "")
        return f"{g.source.upper()}  ·  non installe{temps}"
    if g.extra.get("missing"):
        return f"{g.source.upper()}  ·  fichiers introuvables"
    bits = [g.source.upper()]
    if g.size_gb:
        bits.append(f"{g.size_gb} Go")
    played = g.total_play_seconds
    if played >= 60:
        bits.append(f"{played // 3600} h" if played >= 3600
                    else f"{played // 60} min")
    if g.update_pending:
        bits.append("MAJ")
    return "  ·  ".join(bits)


def signature(g: Game) -> tuple:
    """Tout ce qu'une tuile affiche : si rien n'a change, la tuile existante
    peut etre reutilisee telle quelle (sans relire ni redimensionner sa
    jaquette)."""
    return (g.title, g.source, g.art_cover, _date_fichier(g.art_cover), g.art_icon,
            bool(g.extra.get("missing")), bool(g.extra.get("non_installe")),
            g.install_dir, texte_meta(g))


def _date_fichier(chemin: str) -> float:
    """Date de modification (une jaquette retelechargee garde son nom)."""
    if not chemin:
        return 0.0
    try:
        return Path(chemin).stat().st_mtime
    except OSError:
        return 0.0


class GameCard(QFrame):
    clicked = Signal(str)
    play_requested = Signal(str)
    action_requested = Signal(str, str)     # uid, cle d'action

    def __init__(self, game: Game, width: int = 190, parent=None) -> None:
        super().__init__(parent)
        self.game = game
        self.card_width = width
        self.setObjectName("GameCard")
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        # focusable : indispensable pour la navigation au clavier et a la manette
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

        art_size = QSize(width - 16, int((width - 16) * RATIO))
        self.setFixedSize(width, art_size.height() + 62)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(8, 8, 8, 8)
        lay.setSpacing(7)

        self.art = QLabel()
        self.art.setFixedSize(art_size)
        self.art.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(self.art)

        self.title = QLabel(game.title)
        self.title.setObjectName("CardTitle")
        self.title.setWordWrap(False)
        self.title.setTextFormat(Qt.TextFormat.PlainText)
        lay.addWidget(self.title)

        self.meta = QLabel(self._meta_text())
        self.meta.setObjectName("CardMeta")
        lay.addWidget(self.meta)
        lay.addStretch(1)

        # bouton ⋮ pose sur la jaquette, en haut a droite
        self.more = QToolButton(self)
        self.more.setObjectName("CardMore")
        self.more.setText("\u22ee")
        self.more.setToolTip("Actions rapides")
        self.more.setCursor(Qt.CursorShape.PointingHandCursor)
        self.more.setFixedSize(30, 30)
        self.more.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.more.move(width - 8 - 30 - 6, 8 + 6)
        # clicked envoie un booleen : il ne doit pas devenir la position du menu
        self.more.clicked.connect(lambda _=False: self.show_menu())
        self.more.hide()

        self.refresh_art()
        tip = f"{game.title}\n{game.install_dir or ''}"
        if game.extra.get("non_installe"):
            tip = (f"{game.title}\n\nPossede sur {game.source.capitalize()}, "
                   "non installe sur ce PC. Cliquez pour l'installer.")
        if game.extra.get("missing"):
            tip += ("\n\nCe jeu est declare par sa plateforme mais son dossier "
                    "est introuvable : il a sans doute ete desinstalle.")
            self.setGraphicsEffect(None)
            self.setWindowOpacity(0.5)
        self.setToolTip(tip)

    # ------------------------------------------------------------------
    def _meta_text(self) -> str:
        return texte_meta(self.game)

    def refresh_art(self) -> None:
        size = self.art.size()
        path = self.game.art_cover or ""
        pix = miniature(path, size) if path else QPixmap()
        if pix.isNull():
            icon_path = self.game.art_icon
            base = placeholder(self.game.title, size, self.game.uid)
            if icon_path and Path(icon_path).exists():
                icon = QPixmap(icon_path)
                if not icon.isNull():
                    p = QPainter(base)
                    p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
                    side = int(size.width() * 0.46)
                    icon = icon.scaled(side, side, Qt.AspectRatioMode.KeepAspectRatio,
                                       Qt.TransformationMode.SmoothTransformation)
                    p.drawPixmap((size.width() - icon.width()) // 2,
                                 (size.height() - icon.height()) // 2 - 8, icon)
                    p.end()
            pix = base
        # l'attenuation est cuite dans l'image : un effet graphique par tuile
        # doublait le cout de chaque defilement
        if self.game.extra.get("missing") or self.game.extra.get("non_installe"):
            pix = attenuer(pix, 0.38 if self.game.extra.get("missing") else 0.5)
        self.art.setGraphicsEffect(None)
        self.art.setPixmap(pix)

        elided = self.title.fontMetrics().elidedText(
            self.game.title, Qt.TextElideMode.ElideRight, self.card_width - 20)
        self.title.setText(elided)
        self.meta.setText(self._meta_text())

    # -- menu ⋮ ----------------------------------------------------------
    def show_menu(self, pos=None) -> None:
        menu = QMenu(self)
        for item in menu_actions(self.game):
            if item is None:
                menu.addSeparator()
                continue
            cle, libelle = item
            act = menu.addAction(libelle)
            act.setData(cle)
            if cle == "jouer":
                f = act.font(); f.setBold(True); act.setFont(f)
        if pos is None:
            pos = self.more.mapToGlobal(self.more.rect().bottomLeft())
        self.more.show()
        choisi = menu.exec(pos)
        if not self.underMouse():
            self.more.hide()
        if choisi is not None and choisi.data():
            self.action_requested.emit(self.game.uid, str(choisi.data()))

    def contextMenuEvent(self, event) -> None:     # noqa: N802
        """Clic droit : le meme menu que le bouton ⋮."""
        self.show_menu(event.globalPos())

    def enterEvent(self, event) -> None:            # noqa: N802
        self.more.show()
        self.more.raise_()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:            # noqa: N802
        if not self.hasFocus():
            self.more.hide()
        super().leaveEvent(event)

    def focusOutEvent(self, event) -> None:         # noqa: N802
        if not self.underMouse():
            self.more.hide()
        super().focusOutEvent(event)

    # ------------------------------------------------------------------
    def keyPressEvent(self, event) -> None:         # noqa: N802
        """Entree ouvre la fiche, Espace lance le jeu, Menu ouvre le menu ⋮."""
        if event.key() == Qt.Key.Key_Menu:
            self.show_menu()
            return
        if event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            self.clicked.emit(self.game.uid)
            return
        if event.key() == Qt.Key.Key_Space:
            self.play_requested.emit(self.game.uid)
            return
        super().keyPressEvent(event)

    def focusInEvent(self, event) -> None:          # noqa: N802
        super().focusInEvent(event)
        self.more.show()
        self.more.raise_()
        parent = self.parentWidget()
        while parent is not None:
            if hasattr(parent, "ensureWidgetVisible"):
                try:
                    parent.ensureWidgetVisible(self, 40, 60)
                except Exception:
                    pass
                break
            parent = parent.parentWidget()

    def mousePressEvent(self, event) -> None:       # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton:
            if self.game.extra.get("non_installe"):
                self.action_requested.emit(self.game.uid, "installer")
            else:
                self.clicked.emit(self.game.uid)
        super().mousePressEvent(event)

    def mouseDoubleClickEvent(self, event) -> None:  # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton and \
                not self.game.extra.get("non_installe"):
            self.play_requested.emit(self.game.uid)
        super().mouseDoubleClickEvent(event)
