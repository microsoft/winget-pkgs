"""Codes promo des revendeurs partenaires, affiches a cote de leur lien.

Un partenaire envoie parfois un code de reduction (15 octobre 2026 : Kinguin,
« SPOOK5 », -5 % jusqu'au 31 octobre). ORION le montre sous le lien du
revendeur, dans la fiche d'un jeu, tant qu'il est valable, puis l'efface
seul a la date de fin : rien a republier.

Deux sources, comme pour les sorties (`sorties.py`) :

* la liste **embarquee** ci-dessous, livree avec l'application et ecrite
  sur le site en `codes.json` par le generateur (`service/site/assembler.py`),
  qui l'inscrit aussi dans `comparatif.js` ;
* la liste **en ligne** (`orion-launcher.com/codes.json`), relue au plus une
  fois par six heures : un code annonce apres la sortie d'une version arrive
  quand meme. Sans reseau, la liste embarquee ou la derniere lue sert.

Regles : seuls les revendeurs retenus (`marche_gris.RETENUS`), jamais un
code qui ferait passer un revendeur devant les boutiques officielles ; le
texte ne promet rien d'autre que ce que le partenaire a ecrit.
"""
from __future__ import annotations

import datetime as dt
import threading

FORMAT = 1
URL = "https://orion-launcher.com/codes.json"
GARDER = 6 * 3600          # secondes entre deux lectures en ligne

#: codes connus a la sortie de cette version. `fin` est le dernier jour
#: valable, inclus (heure locale du joueur).
EMBARQUES: list[dict] = [
    {"site": "kinguin", "code": "SPOOK5", "remise": "-5 %", "debut": "2026-10-01", "fin": "2026-10-31",
     "quoi": "jeux, logiciels et objets en jeu",
     "limites": "panier de 150 € au plus, 2 utilisations par client",
     "source": "Kinguin, October Partner Update, lu le 15 octobre 2026"},
]

MOIS = ("janvier", "fevrier", "mars", "avril", "mai", "juin", "juillet", "aout", "septembre", "octobre",
        "novembre", "decembre")
MONTHS = ("January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
          "November", "December")
_distants: list[dict] | None = None
_verrou = threading.Lock()


def valide(c: dict) -> bool:
    """Un code lisible : site, code, remise et dates au bon format."""
    try:
        return (isinstance(c, dict) and bool(c.get("site")) and bool(c.get("code")) and bool(c.get("remise"))
                and len(str(c["code"])) <= 20 and str(c["code"]).replace("-", "").isalnum()
                and dt.date.fromisoformat(str(c["debut"])) <= dt.date.fromisoformat(str(c["fin"])))
    except (KeyError, TypeError, ValueError):
        return False


def actifs(site: str | None = None, quand: dt.date | None = None) -> list[dict]:
    """Les codes valables aujourd'hui (ou a la date `quand`), pour un
    revendeur ou pour tous. La liste en ligne, si elle a ete lue, remplace
    l'embarquee ; aucun appel reseau ici."""
    from .marche_gris import RETENUS
    jour = quand or dt.date.today()
    with _verrou:
        liste = _distants if _distants is not None else EMBARQUES
    return [c for c in liste if valide(c) and c["site"] in RETENUS and (site is None or c["site"] == site)
            and dt.date.fromisoformat(str(c["debut"])) <= jour <= dt.date.fromisoformat(str(c["fin"]))]


def texte(c: dict, anglais: bool | None = None) -> str:
    """« Code SPOOK5 : -5 % jusqu'au 31 octobre (jeux, logiciels et objets en
    jeu ; panier de 150 € au plus, 2 utilisations par client). » En anglais
    quand l'interface l'est (les details passent par le catalogue i18n)."""
    fin = dt.date.fromisoformat(str(c["fin"]))
    if anglais is None:
        from .sorties import anglais as _anglais
        anglais = _anglais()
    details = " ; ".join(str(c[k]) for k in ("quoi", "limites") if c.get(k))
    if anglais:
        from .i18n import t
        details = "; ".join(t(str(c[k])) for k in ("quoi", "limites") if c.get(k))
        return (f"Code {c['code']}: {c['remise'].replace(' %', '%')} until {fin.day} {MONTHS[fin.month - 1]}"
                + (f" ({details})." if details else "."))
    jour = "1er" if fin.day == 1 else str(fin.day)
    return (f"Code {c['code']} : {c['remise']} jusqu'au {jour} {MOIS[fin.month - 1]}"
            + (f" ({details})." if details else "."))


def rafraichir() -> bool:
    """Lit la liste en ligne (au plus une fois par `GARDER`), a appeler hors
    du fil graphique. Vrai si une liste valable a ete retenue."""
    global _distants
    try:
        from .core import reseau
        corps = reseau.get_json(URL, garder=GARDER, timeout=8)
    except Exception:
        return False
    if not isinstance(corps, dict) or corps.get("format") != FORMAT or not isinstance(corps.get("codes"), list):
        return False
    codes = [c for c in corps["codes"] if valide(c)]
    with _verrou:
        _distants = codes
    return True


def rafraichir_en_fond() -> None:
    """`rafraichir` dans un fil a part : l'interface ne l'attend jamais."""
    threading.Thread(target=rafraichir, name="codes-promo", daemon=True).start()


def pour_le_site() -> dict:
    """Le contenu de `codes.json` ecrit par le generateur du site."""
    return {"format": FORMAT, "maj": dt.date.today().isoformat(), "codes": [c for c in EMBARQUES if valide(c)]}
