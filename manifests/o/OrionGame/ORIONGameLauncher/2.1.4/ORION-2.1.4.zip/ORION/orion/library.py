"""Service de bibliotheque : orchestre les scanners et la persistance."""
from __future__ import annotations

import time
from typing import Callable

from .core import registry
from .core.doublons import dedoublonner
from .core.config import CONFIG
from .core.events import BUS, SCAN_FINISHED, SCAN_SOURCE_DONE, SCAN_STARTED
from .core.fichiers import est_dossier, existe
from .core.logging_setup import get
from .core.models import Game
from .core.store import LibraryStore, StatsStore
from .plugins.scanners._filters import is_game
from .plugins.scanners.base import Scanner

log = get("library")


class LibraryService:
    """Point d'entree unique pour tout ce qui touche a la liste des jeux."""

    def __init__(self) -> None:
        self.store = LibraryStore()
        self.stats = StatsStore()
        self._scanners: list[Scanner] | None = None

    # -- plugins --------------------------------------------------------
    @property
    def scanners(self) -> list[Scanner]:
        if self._scanners is None:
            found = registry.discover(Scanner, "orion.plugins.scanners", "scanners")
            self._scanners = registry.available(found)
            log.info("Sources actives : %s", [s.id for s in self._scanners])
        return self._scanners

    def reload_plugins(self) -> None:
        self._scanners = None

    def enabled_scanners(self) -> list[Scanner]:
        wanted = CONFIG.get("scan.enabled_sources") or []
        if not wanted:
            return self.scanners
        return [s for s in self.scanners if s.id in wanted]

    # -- scan -----------------------------------------------------------
    #: sources assez rapides pour etre interrogees en continu
    QUICK_SOURCES = ("steam", "epic", "gog", "ubisoft", "ea", "battlenet",
                     "ankama")

    def scan(self, progress_cb: Callable[[str, int], None] | None = None,
             quick: bool = False) -> dict:
        """Analyse complete, ou rapide pour la veille des installations."""
        scanners = self.enabled_scanners()
        if quick:
            scanners = [s for s in scanners if s.id in self.QUICK_SOURCES]
        BUS.emit(SCAN_STARTED, sources=[s.id for s in scanners])
        started = time.time()
        found: list[Game] = []
        #: nombre de jeux rendus par chaque source qui a repondu sans erreur
        reponses: dict[str, int] = {}

        for i, sc in enumerate(scanners):
            if progress_cb:
                progress_cb(f"Analyse de {sc.label}...",
                            int(i / max(len(scanners), 1) * 100))
            t0 = time.time()
            try:
                games = sc.scan() or []
            except Exception:
                log.exception("Scanner en echec : %s", sc.id)
                games = None
            if games is not None:
                reponses[sc.id] = len(games)
            found.extend(games or [])
            BUS.emit(SCAN_SOURCE_DONE, source=sc.id, count=len(games or []),
                     seconds=round(time.time() - t0, 2))

        ignored = [g for g in found if not is_game(g.title)]
        if ignored:
            log.info("Entrees ecartees (lanceurs, outils) : %s",
                     sorted({g.title for g in ignored})[:20])
        found = self._dedupe([g for g in found if is_game(g.title)])

        if quick:
            # une veille ne doit jamais supprimer ce que le scan complet
            # a trouve : on se contente d'ajouter les nouveautes.
            known = {g.uid for g in self.store.games.values()}
            fresh = [g for g in found if g.uid not in known]
            # ce qu'ORION deduit des fichiers (le moteur) suit toujours le
            # dernier scan : sans cela, une detection corrigee par une mise
            # a jour d'ORION n'arrivait qu'au prochain scan complet
            rafraichis = 0
            for g in found:
                ancien = self.store.games.get(g.uid)
                if ancien is not None and ancien.engine != g.engine \
                        and g.install_dir and est_dossier(g.install_dir):
                    ancien.engine = g.engine
                    rafraichis += 1
            added = 0
            for g in fresh:
                self.store.games[g.uid] = g
                added += 1
            if added:
                # un jeu Steam fraichement detecte peut avoir un jumeau
                # « registre » deja enregistre
                self.store.dedoublonner(self._priorites(),
                                        {g.uid for g in fresh})
                self._suivre_fusions()
            removed, missing = self._desinstallations(found, reponses)
            if added or removed or missing or rafraichis:
                self.store.save()
            result = {"total": len(found), "added": added, "updated": 0,
                      "ignored": 0, "missing": missing, "removed": removed,
                      "quick": True,
                      "seconds": round(time.time() - started, 1),
                      "sources": {s.id: s.label for s in scanners}}
            BUS.emit(SCAN_FINISHED, **result)
            return result

        # Un jeu peut rester declare par sa plateforme alors que ses fichiers
        # ont disparu (desinstallation incomplete, disque debranche).
        missing = 0
        for g in found:
            absent = bool(g.install_dir) and not existe(g.install_dir)
            if absent:
                g.extra["missing"] = True
                missing += 1
            else:
                g.extra.pop("missing", None)
        if missing:
            log.info("%d jeux declares mais absents du disque", missing)

        # nettoyage : une entree deja enregistree qui s'avere etre un
        # lanceur ou un outil est retiree de la bibliotheque.
        for uid, g in list(self.store.games.items()):
            if not g.extra.get("manual") and not is_game(g.title):
                self.store.games.pop(uid, None)
        added, updated = self.store.merge_scan(found)
        if self.store.dedoublonner(self._priorites(), {g.uid for g in found}):
            self.store.save()
        self._suivre_fusions()
        result = {
            "total": len(found), "added": added, "updated": updated,
            "ignored": len(ignored),
            "missing": missing,
            "seconds": round(time.time() - started, 1),
            "sources": {s.id: s.label for s in scanners},
        }
        if progress_cb:
            progress_cb("Analyse terminee", 100)
        BUS.emit(SCAN_FINISHED, **result)
        log.info("Scan termine : %s", result)
        return result

    def _desinstallations(self, found: list[Game],
                          reponses: dict[str, int]) -> tuple[int, int]:
        """Jeux que leur plateforme ne declare plus : desinstalles.

        Appele par la veille rapide, qui sinon ne voyait que les ajouts : un
        jeu desinstalle restait affiche jusqu'a une analyse complete.

        * dossier disparu -> la fiche est retiree ;
        * dossier encore present (Steam laisse parfois des fichiers, comme
          Wallpaper Engine avec ses fonds telecharges) -> marque introuvable,
          donc masque par defaut, mais rien n'est perdu s'il revient.

        Une source en erreur, ou qui ne rend soudain plus aucun jeu (disque
        debranche, fichier de config illisible), ne retire rien.
        """
        vus = {g.uid for g in found}
        par_source: dict[str, int] = {}
        for g in self.store.games.values():
            par_source[g.source] = par_source.get(g.source, 0) + 1
        removed = missing = 0
        for uid, g in list(self.store.games.items()):
            if g.source not in reponses or g.extra.get("manual"):
                continue
            if uid in vus:
                if g.extra.pop("missing", None) and g.install_dir \
                        and not existe(g.install_dir):
                    g.extra["missing"] = True
                continue
            if reponses[g.source] == 0 and par_source.get(g.source, 0) > 1:
                continue            # source muette : prudence
            if not g.install_dir or not existe(g.install_dir):
                self.store.games.pop(uid, None)
                log.info("Jeu desinstalle retire : %s", g.title)
                removed += 1
            elif not g.extra.get("missing"):
                g.extra["missing"] = True
                log.info("Jeu desinstalle (fichiers restants) : %s", g.title)
                missing += 1
        return removed, missing

    def _priorites(self) -> dict[str, int]:
        return {sc.id: getattr(sc, "priority", 50) for sc in self.scanners}

    def _dedupe(self, games: list[Game]) -> list[Game]:
        """Un meme jeu vu par plusieurs sources : une seule fiche.

        Voir `orion.core.doublons` : identifiant natif, dossier normalise,
        dossiers imbriques, puis titre face a une source generique.
        """
        return dedoublonner(games, self._priorites())

    def _suivre_fusions(self) -> None:
        """Les sessions des fiches fusionnees suivent la fiche conservee."""
        correspondances = {
            ancien: g.uid for g in self.store.games.values()
            for ancien in g.extra.get("merged_uids", [])}
        if correspondances:
            self.stats.renommer(correspondances)

    # -- acces ----------------------------------------------------------
    def games(self, include_hidden: bool = False) -> list[Game]:
        return self.store.all(include_hidden)

    def get(self, uid: str) -> Game | None:
        return self.store.get(uid)

    def save(self, attendre: bool = False) -> None:
        self.store.save(attendre)

    def record_session(self, game: Game, seconds: int, profile: str = "") -> None:
        game.play_seconds += max(int(seconds), 0)
        game.last_played = time.time()
        self.stats.record(game.uid, seconds, profile)
        self.store.save()
