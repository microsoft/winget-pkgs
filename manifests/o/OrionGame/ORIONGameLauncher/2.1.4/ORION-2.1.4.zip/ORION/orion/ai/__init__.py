"""Integration d un assistant IA optionnel."""
