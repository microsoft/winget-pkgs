"""Pilotes plus recents proposes par Windows Update (mises a jour facultatives).

Windows tient, pour chaque PC, la liste des pilotes que les constructeurs ont
publies chez Microsoft, apparies par identifiant materiel. ORION la lit en
lecture seule par l'API de Windows Update (aucun droit administrateur, rien
n'est installe) et la compare a l'inventaire des pilotes : « 22.10 installe,
22.250 disponible dans Windows Update », bouton vers la page des mises a jour
facultatives.

La recherche en ligne prend de dix secondes a deux minutes la premiere fois :
elle tourne dans un fil de fond (`lancer`), jamais dans l'analyse de la
machine, et son resultat est garde un jour (`cache/pilotes-windows-update.json`).
Quand il arrive, `pilotes.maj` est emis : la page Conseils se recompose.
"""
from __future__ import annotations

import base64
import datetime as _dt
import json
import re
import subprocess
import threading
import time
from dataclasses import dataclass, field

from ..core.events import BUS
from ..core.logging_setup import get
from ..core.paths import CACHE_DIR, is_windows

log = get("hardware.maj_pilotes")

#: resultat garde un jour : les constructeurs publient rarement plus souvent
FRAICHEUR = 24 * 3600
#: secondes accordees a la recherche Windows Update
DELAI_MAX = 180
#: page des mises a jour facultatives de Windows
ADRESSE_WINDOWS_UPDATE = "ms-settings:windowsupdate-optionalupdates"
FICHIER = CACHE_DIR / "pilotes-windows-update.json"
EVENEMENT = "pilotes.maj"
CREATE_NO_WINDOW = 0x08000000

SCRIPT = r"""
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$r = [ordered]@{ pilotes = @() }
function Date-Texte($d) { if ($d -is [datetime]) { $d.ToString('yyyy-MM-dd') } elseif ($d) { [string]$d } else { '' } }
try {
  $session = New-Object -ComObject Microsoft.Update.Session
  $session.ClientApplicationID = 'ORION'
  $chercheur = $session.CreateUpdateSearcher()
  $chercheur.Online = $true
  $resultat = $chercheur.Search("IsInstalled=0 and Type='Driver' and IsHidden=0")
  $r.pilotes = @(foreach ($u in $resultat.Updates) {
    [ordered]@{ titre = [string]$u.Title; classe = [string]$u.DriverClass; fabricant = [string]$u.DriverManufacturer;
      modele = [string]$u.DriverModel; fournisseur = [string]$u.DriverProvider; date = (Date-Texte $u.DriverVerDate);
      id = [string]$u.DriverHardwareID; taille = [double]$u.MaxDownloadSize; telecharge = [bool]$u.IsDownloaded }
  })
} catch { $r.erreur = $_.Exception.Message }
$r | ConvertTo-Json -Depth 4 -Compress
"""

_VERSION = re.compile(r"\b(\d+(?:\.\d+){1,3})\b")


@dataclass
class MiseAJour:
    titre: str
    classe: str = ""
    fabricant: str = ""
    modele: str = ""
    fournisseur: str = ""
    date: _dt.date | None = None
    id_materiel: str = ""
    taille: float = 0.0

    @property
    def version(self) -> str:
        """« Intel Corporation - Net - 22.250.1.1 » -> « 22.250.1.1 »."""
        trouves = _VERSION.findall(self.titre)
        return trouves[-1] if trouves else ""

    @property
    def cle_materiel(self) -> str:
        from .systeme import cle_materiel
        return cle_materiel(self.id_materiel)


@dataclass
class Resultat:
    lu: float                               # horodatage de la recherche
    pilotes: list[MiseAJour] = field(default_factory=list)
    erreur: str = ""

    @property
    def date(self) -> _dt.date:
        return _dt.date.fromtimestamp(self.lu)

    def pour(self, cle: str) -> MiseAJour | None:
        """La mise a jour proposee pour cette puce (cle de `cle_materiel`)."""
        if not cle:
            return None
        for m in self.pilotes:
            if m.cle_materiel == cle:
                return m
        return None


# --------------------------------------------------------------------------
# lecture
# --------------------------------------------------------------------------

def interpreter(donnees: dict, lu: float | None = None) -> Resultat:
    """Fonction pure : la sortie du script -> Resultat."""
    from .systeme import lire_date
    res = Resultat(lu=lu or time.time(), erreur=str(donnees.get("erreur") or ""))
    bruts = donnees.get("pilotes")
    if isinstance(bruts, dict):
        bruts = [bruts]                      # ConvertTo-Json rend un objet seul pour un element
    for b in bruts or []:
        if not isinstance(b, dict) or not b.get("titre"):
            continue
        res.pilotes.append(MiseAJour(
            titre=str(b.get("titre") or "").strip(), classe=str(b.get("classe") or "").strip(),
            fabricant=str(b.get("fabricant") or "").strip(), modele=str(b.get("modele") or "").strip(),
            fournisseur=str(b.get("fournisseur") or "").strip(), date=lire_date(b.get("date")),
            id_materiel=str(b.get("id") or "").strip(),
            taille=float(b.get("taille") or 0)))
    return res


def _executer() -> dict:
    from ..core.lancement import popen_propre
    code = base64.b64encode(SCRIPT.encode("utf-16-le")).decode("ascii")
    proc = popen_propre(
        ["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
         "-EncodedCommand", code],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.DEVNULL,
        creationflags=CREATE_NO_WINDOW)
    try:
        sortie, _ = proc.communicate(timeout=DELAI_MAX)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.communicate()
        raise
    texte = (sortie or b"").decode("utf-8", errors="replace").strip()
    debut = texte.find("{")
    return json.loads(texte[debut:]) if debut >= 0 else {}


# --------------------------------------------------------------------------
# cache et fil de fond
# --------------------------------------------------------------------------
_DERNIER: Resultat | None = None
_VERROU = threading.Lock()
_EN_COURS = False


def _charger_fichier() -> Resultat | None:
    try:
        d = json.loads(FICHIER.read_text(encoding="utf-8"))
        return interpreter(d, lu=float(d.get("lu") or 0))
    except Exception:
        return None


def _garder_fichier(donnees: dict, lu: float) -> None:
    try:
        FICHIER.parent.mkdir(parents=True, exist_ok=True)
        FICHIER.write_text(json.dumps(dict(donnees, lu=lu), ensure_ascii=False), encoding="utf-8")
    except Exception:
        log.debug("Cache des mises a jour de pilotes non ecrit")


def dernier() -> Resultat | None:
    """Le dernier resultat connu (memoire, puis fichier), meme ancien ; None
    si aucune recherche n'a encore abouti."""
    global _DERNIER
    with _VERROU:
        if _DERNIER is None:
            _DERNIER = _charger_fichier()
        return _DERNIER


def frais(res: Resultat | None) -> bool:
    return res is not None and time.time() - res.lu < FRAICHEUR


def collecter(force: bool = False) -> Resultat | None:
    """Recherche Windows Update, dans le fil appelant (long). None hors Windows."""
    global _DERNIER
    if not is_windows():
        return None
    connu = dernier()
    if connu is not None and not force and frais(connu):
        return connu
    debut = time.time()
    try:
        donnees = _executer()
        res = interpreter(donnees)
        if res.erreur and not res.pilotes:
            log.info("Windows Update : recherche de pilotes en echec (%s)", res.erreur[:120])
        else:
            log.info("Windows Update : %d pilote(s) facultatif(s) propose(s) en %.0f s",
                     len(res.pilotes), time.time() - debut)
            _garder_fichier(donnees, res.lu)
    except Exception as exc:
        log.info("Windows Update injoignable : %s", exc)
        res = Resultat(lu=time.time(), erreur=str(exc) or exc.__class__.__name__)
    with _VERROU:
        _DERNIER = res
    return res


def lancer(force: bool = False) -> bool:
    """Lance la recherche dans un fil de fond si le resultat connu est
    perime. Rend vrai si un fil est parti ; `pilotes.maj` est emis a la fin."""
    global _EN_COURS
    if not is_windows():
        return False
    connu = dernier()
    with _VERROU:
        if _EN_COURS or (not force and frais(connu)):
            return False
        _EN_COURS = True

    def travail() -> None:
        global _EN_COURS
        try:
            collecter(force)
        finally:
            with _VERROU:
                _EN_COURS = False
            try:
                BUS.emit(EVENEMENT)
            except Exception:
                log.debug("Annonce des mises a jour de pilotes impossible")

    threading.Thread(target=travail, name="orion-windows-update", daemon=True).start()
    return True
