"""Steam : promotions, meilleures ventes, free-to-play, et recherche du catalogue.

Aucune cle. Les prix sont demandes pour la France (euros, TVA comprise).
Le flux de recherche de Steam ne donne que des noms : les prix sont ensuite
releves en un seul appel groupe (`appdetails` avec le filtre `price_overview`).
"""
from __future__ import annotations

from orion.core import region

import json
import re

from ...core import steam_limite
from ...core.config import CONFIG
from .base import Offre, SourceBoutique, SourceUnavailable, fetch_json, log

FEATURED = "https://store.steampowered.com/api/featuredcategories"
SEARCH_JSON = "https://store.steampowered.com/search/results/"
STORE_SEARCH = "https://store.steampowered.com/api/storesearch/"
DETAILS = "https://store.steampowered.com/api/appdetails"
PAGE = "https://store.steampowered.com/app/{appid}"
HEADER = "https://cdn.akamai.steamstatic.com/steam/apps/{appid}/header.jpg"
#: fiches groupees (100 jeux par appel, sans cle) : etiquettes, avis,
#: studios et visuels. Hors du magasin (store.steampowered.com) : ne
#: consomme pas le quota des fiches `appdetails`.
ITEMS = "https://api.steampowered.com/IStoreBrowseService/GetItems/v1/"
TAGS = "https://api.steampowered.com/IStoreService/GetTagList/v1/"
#: recherche du magasin par etiquette (sans cle) : les jeux les plus en vue
#: d'un type, avec leur fiche et leur prix, cent par appel
QUERY = "https://api.steampowered.com/IStoreQueryService/Query/v1/"
#: ordre « les plus en vue » de cette recherche
TRI_EN_VUE = 10
#: etiquette Steam de chaque type de jeu d'ORION (`orion/genres.py`). Les
#: noms ont ete relus aupres de Steam le 6 octobre 2026 (1663 = FPS, 1718 =
#: MOBA, 176981 = Battle Royale...).
ETIQUETTES_TYPES = {
    "fps": 1663, "tps": 3814, "battle-royale": 176981, "moba": 1718, "mmorpg": 1754,
    "mmo": 128, "rpg": 122, "action-rpg": 4231, "rts": 1676, "strategie": 9,
    "gestion": 12472, "simulation": 599, "survie": 1662, "horreur": 1667,
    "monde-ouvert": 1695, "aventure": 21, "action": 19, "plateforme": 1625,
    "roguelike": 1716, "combat": 1743, "course": 699, "sport": 701, "coop": 1685,
    "reflexion": 1664, "narratif": 1742, "inde": 492,
}
ASSETS = "https://shared.akamai.steamstatic.com/store_item_assets/"

#: poids de la mise en avant selon la rubrique de la vitrine Steam
_RUBRIQUES = {"top_sellers": 100, "specials": 75, "new_releases": 55}

_APPID = re.compile(r"/apps/(\d+)/")


def _pays() -> str:
    return str(CONFIG.get("market.country") or "FR").lower()


def _offre(appid, nom, final_cts, initial_cts, remise=0, image="",
           fin=0.0, devise="EUR") -> Offre:
    prix = round((final_cts or 0) / 100, 2)
    normal = round((initial_cts or final_cts or 0) / 100, 2)
    return Offre(titre=nom, boutique="Steam", prix=prix, prix_normal=normal,
                 remise=int(remise or 0), devise=devise or "EUR",
                 url=PAGE.format(appid=appid), source="steam",
                 steam_appid=str(appid),
                 image=image or HEADER.format(appid=appid),
                 fin_promo=float(fin or 0), drm="Steam")


from ...contenu_adulte import produit_adulte

class SteamBoutique(SourceBoutique):
    id = "steam"
    label = "Steam"
    priority = 100

    # -- vitrine -------------------------------------------------------
    filtre_adulte = ("Steam ne montre pas ces jeux aux visiteurs non connectes ; "
                     "la fiche detaillee (descripteur 3, etiquettes) les marque "
                     "ensuite et la Boutique les retire")

    def vitrine(self) -> list[Offre]:
        out: list[Offre] = []
        data = fetch_json(FEATURED, {"cc": _pays(), "l": region.langue_steam()})
        for cat in ("specials", "top_sellers", "new_releases"):
            rang = 0
            for it in (data.get(cat) or {}).get("items") or []:
                if it.get("type", 0) != 0 or not it.get("id"):
                    continue        # 0 = jeu ; le reste : lots, abonnements
                o = _offre(
                    it["id"], it.get("name", ""), it.get("final_price"),
                    it.get("original_price"), it.get("discount_percent"),
                    it.get("header_image") or it.get("large_capsule_image"),
                    it.get("discount_expiration") or 0, it.get("currency"))
                o.type_article = "game"
                # le premier des meilleures ventes vaut 100, puis -4 par rang
                o.populaire = max(10, _RUBRIQUES[cat] - 4 * rang)
                rang += 1
                out.append(o)

        # promotions et free-to-play au-dela des dix mises en avant
        noms: dict[str, str] = {}
        # category1=998 : jeux seulement (sans logiciels, bandes originales,
        # formations ni DLC)
        for params in ({"specials": 1, "count": 100, "category1": 998},
                       {"specials": 1, "count": 100, "start": 100, "category1": 998},
                       {"maxprice": "free", "category1": 998,
                        "filter": "topsellers", "count": 60}):
            try:
                res = fetch_json(SEARCH_JSON, {"json": 1, "cc": _pays(),
                                               "l": region.langue_steam(), **params})
            except SourceUnavailable as exc:
                log.debug("Recherche Steam partielle : %s", exc)
                continue
            for it in res.get("items") or []:
                m = _APPID.search(it.get("logo") or "")
                if m and m.group(1) not in noms:
                    noms[m.group(1)] = it.get("name", "")
        deja = {o.steam_appid for o in out}
        out += self.prix_groupes({a: n for a, n in noms.items() if a not in deja})
        return out

    def prix_groupes(self, noms: dict[str, str]) -> list[Offre]:
        """Prix actuels d'une liste d'appids, par cent, sur le service de
        Steam qui n'impose pas d'attente entre deux demandes : trois appels
        pour toute la vitrine, au lieu de sept espaces de 1,2 s chacun. En
        secours, l'ancienne lecture (`prix`)."""
        if not noms:
            return []
        try:
            items = articles(list(noms))
        except SourceUnavailable as exc:
            log.debug("%s", exc)
            return self.prix(noms)
        out: list[Offre] = []
        for it in items:
            o = offre_item(it)
            if o is not None and o.steam_appid in noms:
                o.adulte = bool(produit_adulte(
                    {"content_descriptorids": it.get("content_descriptorids")}))
                out.append(o)
        return out

    def prix(self, noms: dict[str, str]) -> list[Offre]:
        """Prix actuels d'une liste d'appids, en appels groupes."""
        out: list[Offre] = []
        ids = list(noms)
        for i in range(0, len(ids), 40):
            lot = ids[i:i + 40]
            try:
                data = fetch_json(DETAILS, {"appids": ",".join(lot),
                                            "cc": _pays(),
                                            "filters": "price_overview"})
            except SourceUnavailable as exc:
                log.debug("Prix Steam partiels : %s", exc)
                continue
            blocs = steam_limite.fiches_groupees(data, lot)
            for appid in lot:
                bloc = blocs.get(appid) or {}
                if not bloc.get("success"):
                    continue
                po = bloc.get("data") or {}
                po = po.get("price_overview") if isinstance(po, dict) else None
                if po:
                    out.append(_offre(appid, noms[appid], po.get("final"),
                                      po.get("initial"),
                                      po.get("discount_percent"),
                                      devise=po.get("currency")))
                else:       # pas de prix : jeu gratuit
                    out.append(_offre(appid, noms[appid], 0, 0))
        return out

    # -- recherche -----------------------------------------------------
    #: resultats demandes a la recherche du magasin
    NB_RECHERCHE = 30

    def chercher(self, terme: str) -> list[Offre]:
        """Les JEUX que le magasin trouve pour `terme`, avec leur prix.

        Un seul appel : la recherche du magasin (celle de son champ de
        saisie), limitee aux jeux, rend noms, prix et fiches d'un coup, en un
        quart de seconde, sur un service de Steam qui n'impose pas d'attente
        entre deux demandes. L'ancienne (`storesearch`) ne donnait que dix
        resultats, DLC et bandes originales compris : « borderlands » ne
        montrait pas le premier Borderlands. Un jeu retire de la vente n'a
        pas de prix et n'est pas rendu. `articles_recus` garde les fiches
        lues, pour ne pas les redemander. Deux secours : la recherche de la
        page du magasin, puis l'ancienne."""
        if getattr(self, "articles_recus", None) is None:
            self.articles_recus: dict[str, dict] = {}
        try:
            items = suggestions(terme, self.NB_RECHERCHE)
        except SourceUnavailable as exc:
            log.debug("%s", exc)
            return self._chercher_page(terme)
        return self._offres(items)

    def _offres(self, items, ordre=None) -> list[Offre]:
        offres: dict[str, Offre] = {}
        if getattr(self, "sans_prix", None) is None or len(self.sans_prix) > 200:
            self.sans_prix: dict[str, dict] = {}
        for it in items:
            o = offre_item(it) if isinstance(it, dict) else None
            if o is None and isinstance(it, dict) and it.get("type", 0) == 0 \
                    and it.get("success", 1) == 1 and str(it.get("appid") or "").isdigit():
                # un jeu fiche mais sans prix : retire de la vente. Ses
                # etiquettes serviront a proposer des jeux du meme esprit.
                self.sans_prix[str(it["appid"])] = it
            if o is not None and o.steam_appid not in offres:
                # descripteur « reserve aux adultes » : la Boutique ecarte le jeu
                o.adulte = bool(produit_adulte(
                    {"content_descriptorids": it.get("content_descriptorids")}))
                offres[o.steam_appid] = o
                self.articles_recus[o.steam_appid] = it
        # l'ordre du magasin : le plus pertinent d'abord
        return [offres[a] for a in (ordre or list(offres)) if a in offres]

    def _chercher_page(self, terme: str) -> list[Offre]:
        """Recherche de la page du magasin, puis prix en un appel groupe."""
        try:
            res = fetch_json(SEARCH_JSON, {"term": terme, "category1": 998, "json": 1,
                                           "count": self.NB_RECHERCHE, "cc": _pays(),
                                           "l": region.langue_steam()})
        except SourceUnavailable as exc:
            log.debug("Recherche du magasin Steam indisponible : %s", exc)
            return self._chercher_court(terme)
        ids: list[str] = []
        for it in res.get("items") or []:
            m = _APPID.search(str(it.get("logo") or ""))
            if m and m.group(1) not in ids:
                ids.append(m.group(1))
        if not ids:
            return []
        try:
            items = articles(ids)
        except SourceUnavailable as exc:
            log.debug("%s", exc)
            return self._chercher_court(terme)
        return self._offres(items, ids)

    def _chercher_court(self, terme: str) -> list[Offre]:
        """Ancienne recherche (dix resultats), en secours."""
        data = fetch_json(STORE_SEARCH, {"term": terme, "cc": _pays(),
                                         "l": region.langue_steam()})
        out: list[Offre] = []
        for it in data.get("items") or []:
            if it.get("type") not in (None, "app", "game"):
                continue
            p = it.get("price") or {}
            initial, final = p.get("initial", 0), p.get("final", 0)
            remise = round(100 - final * 100 / initial) if initial and \
                final < initial else 0
            o = _offre(it.get("id"), it.get("name", ""), final, initial,
                       remise, devise=p.get("currency") or "EUR")
            # la recherche Steam repond « app » pour tout, jeux compris : ce
            # mot ne dit rien. La nature vient de la fiche detaillee.
            nature = str(it.get("type") or "").lower()
            o.type_article = "" if nature == "app" else nature
            o.note = int(it.get("metascore") or 0) if str(
                it.get("metascore") or "").isdigit() else 0
            out.append(o)
        return out


# ---------------------------------------------------------------------------
# Fiches detaillees (etiquettes, avis, studios, visuels), par lots de 100
# ---------------------------------------------------------------------------
def noms_etiquettes() -> dict[int, str]:
    """{tagid: nom en francais} des etiquettes Steam (« Monde ouvert »...)."""
    from orion.core import reseau
    try:
        r = reseau.get(TAGS, params={"language": region.langue_steam()},
                       headers=steam_limite.NAVIGATEUR, timeout=15)
        tags = ((r.json() or {}).get("response") or {}).get("tags") or []
    except Exception as exc:
        raise SourceUnavailable(f"Etiquettes Steam : {exc}") from exc
    return {int(t["tagid"]): str(t.get("name") or "") for t in tags
            if str(t.get("tagid", "")).isdigit()}


def _visuel(assets: dict, nom: str) -> str:
    fichier = (assets or {}).get(nom) or ""
    modele = (assets or {}).get("asset_url_format") or ""
    if not fichier or not modele:
        return ""
    return ASSETS + modele.replace("${FILENAME}", fichier)


def lire_item(it: dict, etiquettes: dict[int, str] | None = None) -> dict:
    """Une fiche `GetItems` reduite a ce que la Boutique utilise."""
    etiquettes = etiquettes or {}
    base = it.get("basic_info") or {}
    avis = ((it.get("reviews") or {}).get("summary_filtered") or {})
    tags = sorted(it.get("tags") or [], key=lambda t: -int(t.get("weight") or 0))
    ids = [int(t.get("tagid")) for t in tags if str(t.get("tagid", "")).isdigit()] \
        or [int(t) for t in it.get("tagids") or [] if str(t).isdigit()]
    assets = it.get("assets") or {}
    return {
        "nom": it.get("name", ""),
        "jeu": it.get("type", 0) == 0,
        "tags": [etiquettes.get(i) or f"tag{i}" for i in ids[:12]],
        "devs": [d.get("name", "") for d in base.get("developers") or []
                 if d.get("name")][:3],
        "editeurs": [d.get("name", "") for d in base.get("publishers") or []
                     if d.get("name")][:3],
        "series": [d.get("name", "") for d in base.get("franchises") or []
                   if d.get("name")][:2],
        "avis": int(avis.get("review_count") or 0),
        "positifs": int(avis.get("percent_positive") or 0),
        # jeu reserve aux adultes : descripteur de contenu ou etiquettes
        "adulte": produit_adulte({"content_descriptorids": it.get("content_descriptorids"),
                                  "tags": [etiquettes.get(i) or "" for i in ids]}),
        "hero": _visuel(assets, "library_hero"),
        "capsule": _visuel(assets, "main_capsule"),
        "header": _visuel(assets, "header"),
    }


SUGGESTIONS = "https://api.steampowered.com/IStoreQueryService/SearchSuggestions/v1/"


def suggestions(terme: str, nombre: int = 30) -> list[dict]:
    """Les jeux que la recherche du magasin propose pour `terme` : articles
    complets (`store_items` : nom, prix, etiquettes, avis, visuels), le plus
    pertinent d'abord. Un seul appel, sans cle. Forme relue chez Steam le 7
    octobre 2026 (« battlefield 3 » : 4 jeux en 0,25 s, prix compris)."""
    from orion.core import reseau
    requete = json.dumps({
        "search_term": str(terme or "")[:80], "max_results": max(1, min(int(nombre), 50)),
        "filters": {"type_filters": {"include_games": True}},
        "context": {"language": region.langue_steam(), "country_code": _pays().upper(),
                    "steam_realm": 1},
        "data_request": {"include_assets": True, "include_tag_count": 12,
                         "include_reviews": True, "include_basic_info": True}})
    try:
        r = reseau.get(SUGGESTIONS, params={"input_json": requete},
                       headers=steam_limite.NAVIGATEUR, timeout=12)
        if r.status_code != 200:
            raise SourceUnavailable(f"Recherche Steam : reponse {r.status_code}")
        items = ((r.json() or {}).get("response") or {}).get("store_items") or []
    except SourceUnavailable:
        raise
    except Exception as exc:
        raise SourceUnavailable(f"Recherche Steam : {exc}") from exc
    return [it for it in items if isinstance(it, dict)]


def articles(appids) -> list[dict]:
    """Les articles du magasin (`store_items`) d'une liste d'appids, tels que
    Steam les rend : nom, prix, etiquettes, avis, visuels. 100 par appel."""
    from orion.core import reseau
    ids = [str(a) for a in appids if str(a).isdigit()]
    out: list[dict] = []
    for i in range(0, len(ids), 100):
        lot = ids[i:i + 100]
        requete = json.dumps({
            "ids": [{"appid": int(a)} for a in lot],
            "context": {"language": region.langue_steam(), "country_code": _pays().upper(),
                        "steam_realm": 1},
            "data_request": {"include_assets": True, "include_tag_count": 12,
                             "include_reviews": True, "include_basic_info": True}})
        try:
            r = reseau.get(ITEMS, params={"input_json": requete},
                           headers=steam_limite.NAVIGATEUR, timeout=20)
            items = ((r.json() or {}).get("response") or {}).get("store_items") or []
        except Exception as exc:
            raise SourceUnavailable(f"Fiches Steam groupees : {exc}") from exc
        out += [it for it in items if isinstance(it, dict)]
    return out


def details(appids, etiquettes: dict[int, str] | None = None) -> dict[str, dict]:
    """{appid: fiche reduite} pour une liste d'appids (100 par appel)."""
    out: dict[str, dict] = {}
    for it in articles(appids):
        a = str(it.get("appid") or it.get("id") or "")
        if a and it.get("success", 1) == 1:
            out[a] = lire_item(it, etiquettes)
    return out


def _centimes(v) -> int:
    try:
        return max(0, int(v or 0))
    except (TypeError, ValueError):
        return 0


def offre_item(it: dict) -> Offre | None:
    """L'offre Steam d'un article du magasin (`store_items`), ou None s'il
    n'est pas vendable : pas un jeu, pas encore de prix, plus en vente."""
    appid = str(it.get("appid") or it.get("id") or "")
    if not appid.isdigit() or it.get("success", 1) != 1 or it.get("visible") is False:
        return None
    if it.get("type", 0) != 0:
        return None
    option = it.get("best_purchase_option") or {}
    final = _centimes(option.get("final_price_in_cents"))
    gratuit = bool(it.get("is_free"))
    if not gratuit and final <= 0:
        return None
    normal = _centimes(option.get("original_price_in_cents")) or final
    fin = 0.0
    for remise in option.get("active_discounts") or []:
        fin = float(remise.get("discount_end_date") or 0) or fin
    o = _offre(appid, " ".join(str(it.get("name") or "").split()), 0 if gratuit else final,
               0 if gratuit else normal, 0 if gratuit else option.get("discount_pct"),
               _visuel(it.get("assets") or {}, "header"), fin, region.devise())
    o.type_article = "game"
    return o


def etiquettes_anglaises() -> dict[str, int]:
    """{nom anglais en minuscules: tagid} des etiquettes Steam, garde un mois.
    Les jeux « du meme esprit » sont decrits par ces noms (« Creature
    Collector », « Souls-like »...) : ils ne dependent pas de la langue du
    joueur, et un nom que Steam ne connait pas (ou plus) est simplement
    absent."""
    from orion.core import reseau
    try:
        d = reseau.get_json(TAGS, garder=30 * 86400, params={"language": "english"},
                            headers=steam_limite.NAVIGATEUR, timeout=15)
        tags = ((d or {}).get("response") or {}).get("tags") or []
    except Exception as exc:
        raise SourceUnavailable(f"Etiquettes Steam : {exc}") from exc
    return {str(t.get("name") or "").strip().lower(): int(t["tagid"]) for t in tags
            if str(t.get("tagid", "")).isdigit() and t.get("name")}


#: etiquettes Steam « Sexual Content », « Nudity », « Hentai » (numeros relus
#: chez Steam le 7 octobre 2026) : jamais dans les jeux « du meme esprit ».
#: Sans ce filtre, « Creature Collector » rendait en troisieme un jeu de
#: charme a cote de Palworld, pour qui cherche Pokemon.
ETIQUETTES_ADULTES = (12095, 6650, 9130)


def page_magasin(cle: str = "", debut: int = 0, nombre: int = 100,
                 etiquettes: dict[int, str] | None = None, tagids=None, sans=None
                 ) -> tuple[list[Offre], dict[str, dict], int]:
    """Une page des jeux du magasin, les plus en vue d'abord, en promotion ou
    non : (offres, {appid: fiche reduite}, nombre total de jeux chez Steam).

    `cle` : un type de jeu (FPS, MOBA...) ou vide pour tout le magasin.
    `debut` : rang du premier jeu voulu ; la Boutique avance ainsi de cent en
    cent, a la demande, jusqu'au bout du magasin (7 093 FPS et 131 407 jeux
    en tout le 7 octobre 2026). Un seul appel, sans cle.

    La fiche reduite porte le nom du type parmi ses etiquettes : Steam range
    le jeu dans ce type meme quand l'etiquette n'est pas dans ses douze
    premieres, et la page du type doit le retrouver."""
    from orion.core import reseau
    from ... import genres
    tagid = ETIQUETTES_TYPES.get(cle)
    if cle and not tagid:
        return [], {}, 0
    filtres: dict = {"released_only": True, "type_filters": {"include_games": True}}
    if tagids:
        # `tagids` : les jeux qui portent TOUTES ces etiquettes (« du meme esprit »)
        filtres["tagids_must_match"] = [{"tagids": [str(int(t))]} for t in tagids]
        if sans:
            # ... et aucune de celles-ci (filtre du magasin, essaye : 1 960 -> 1 908 jeux)
            filtres["tagids_exclude"] = [str(int(t)) for t in sans]
    elif tagid:
        filtres["tagids_must_match"] = [{"tagids": [str(tagid)]}]
    requete = json.dumps({
        "query": {"start": max(0, int(debut)), "count": max(1, min(int(nombre), 100)),
                  "sort": TRI_EN_VUE, "filters": filtres},
        "context": {"language": region.langue_steam(), "country_code": _pays().upper(),
                    "steam_realm": 1},
        "data_request": {"include_assets": True, "include_tag_count": 12,
                         "include_reviews": True, "include_basic_info": True}})
    nom = cle or "magasin"
    try:
        r = reseau.get(QUERY, params={"input_json": requete},
                       headers=steam_limite.NAVIGATEUR, timeout=20)
        if r.status_code != 200:
            raise SourceUnavailable(f"Jeux du type {nom} : reponse {r.status_code}")
        reponse = (r.json() or {}).get("response") or {}
        items = reponse.get("store_items") or []
    except SourceUnavailable:
        raise
    except Exception as exc:
        raise SourceUnavailable(f"Jeux du type {nom} : {exc}") from exc
    try:
        total = int((reponse.get("metadata") or {}).get("total_matching_records") or 0)
    except (TypeError, ValueError):
        total = 0
    offres: list[Offre] = []
    fiches: dict[str, dict] = {}
    libelle = genres.LIBELLES.get(cle, "")
    for it in items:
        o = offre_item(it) if isinstance(it, dict) else None
        if o is None:
            continue
        fiche = lire_item(it, etiquettes)
        o.adulte = bool(fiche.get("adulte"))
        offres.append(o)
        if etiquettes:                 # sans noms d'etiquettes, la fiche ne dirait rien
            if libelle and cle not in genres.types_de(fiche["tags"]):
                fiche["tags"] = list(fiche["tags"]) + [libelle]
            fiches[o.steam_appid] = fiche
    return offres, fiches, total


#: cle de la suite des promotions (voir `BoutiqueService.suite`)
PROMOS = "promos"


def page_promotions(debut: int = 0, nombre: int = 100,
                    etiquettes: dict[int, str] | None = None
                    ) -> tuple[list[Offre], dict[str, dict], int]:
    """Une page des jeux en promotion du magasin, dans l'ordre de Steam :
    (offres, {appid: fiche reduite}, 0). La vitrine en releve deux cents ;
    les listes « Meilleures affaires » et « Au plus bas historique » vont
    chercher les suivantes ici, a la demande. Le total n'est pas annonce par
    Steam : une page vide marque la fin."""
    res = fetch_json(SEARCH_JSON, {"json": 1, "cc": _pays(), "l": region.langue_steam(),
                                   "specials": 1, "category1": 998,
                                   "start": max(0, int(debut)),
                                   "count": max(1, min(int(nombre), 100))})
    ids: list[str] = []
    for it in res.get("items") or []:
        m = _APPID.search(str(it.get("logo") or ""))
        if m and m.group(1) not in ids:
            ids.append(m.group(1))
    offres: list[Offre] = []
    fiches: dict[str, dict] = {}
    for it in articles(ids) if ids else []:
        o = offre_item(it)
        if o is None:
            continue
        fiche = lire_item(it, etiquettes)
        o.adulte = bool(fiche.get("adulte"))
        offres.append(o)
        if etiquettes:
            fiches[o.steam_appid] = fiche
    return offres, fiches, 0


def par_type(cle: str, nombre: int = 100,
             etiquettes: dict[int, str] | None = None) -> tuple[list[Offre], dict[str, dict]]:
    """Les jeux les plus en vue d'un type de jeu : (offres, fiches)."""
    if cle not in ETIQUETTES_TYPES:
        return [], {}
    offres, fiches, _total = page_magasin(cle, 0, nombre, etiquettes)
    return offres, fiches
