"""Carrousel « A la une » de la Boutique : les gros jeux du moment.

A gauche, une grande scene : l'image du jeu (banniere sans texte quand
Steam en a une), son titre, ses genres, sa note et son prix, avec deux
boutons, « Voir l'offre » et « Suivre ». A droite, la liste des jeux a la
une ; celui qui est montre se remplit doucement jusqu'au suivant.

Le carrousel tourne seul (7 s par jeu), s'arrete sous la souris, et se
pilote aux fleches, aux points ou dans la liste. Tout est dessine : seuls
les deux boutons sont de vrais widgets (clavier, focus, lecteur d'ecran).
"""
from __future__ import annotations

from PySide6.QtCore import (QEasingCurve, QPointF, QRectF, QSize, Qt, QVariantAnimation,
                            Signal)
from PySide6.QtGui import (QBrush, QColor, QFont, QFontMetrics, QLinearGradient,
                           QPainter, QPainterPath, QPen, QPixmap)
from PySide6.QtWidgets import QPushButton, QSizePolicy, QWidget

from ...i18n import t
from .boutique_cartes import (SUIVI, couleur, degrade, euros, pilule, police, reste)
from .boutique_images import ChargeurImages, recadrer

DUREE = 7000            # ms par jeu
LISTE = 300             # largeur de la liste de droite
ECART = 16


def flou(source: QPixmap, taille: QSize) -> QPixmap:
    """Fond flou et sombre tire d'une petite image (en-tete Steam...)."""
    petit = source.scaled(max(8, source.width() // 14), max(4, source.height() // 14),
                          Qt.AspectRatioMode.IgnoreAspectRatio,
                          Qt.TransformationMode.SmoothTransformation)
    return recadrer(petit, taille)


class CarrouselUne(QWidget):
    ouvrir = Signal(object)          # clic sur la scene : la fiche detaillee
    voir = Signal(object)            # « Voir l'offre »
    suivre = Signal(object)          # « Suivre »
    ne_plus_suivre = Signal(object)  # second clic sur « Suivre » : on annule

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setMouseTracking(True)
        self.setMinimumHeight(360)
        self.setFixedHeight(420)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.setFocusPolicy(Qt.FocusPolicy.ClickFocus)     # fleches du clavier
        self.fiches: list = []
        self.suivis: set[str] = set()
        self.index = 0
        self._precedent = -1
        self._survol_scene = False
        self._survol_liste = -1
        self._voulues: set[str] = set()
        self.chargeur = ChargeurImages.instance()
        self.chargeur.prete.connect(self._image_prete)

        self._fondu = QVariantAnimation(self)
        self._fondu.setDuration(520)
        self._fondu.setStartValue(0.0)
        self._fondu.setEndValue(1.0)
        self._fondu.setEasingCurve(QEasingCurve.Type.InOutQuad)
        self._fondu.valueChanged.connect(lambda _v: self.update())

        self._progres = QVariantAnimation(self)
        self._progres.setDuration(DUREE)
        self._progres.setStartValue(0.0)
        self._progres.setEndValue(1.0)
        self._pas_progres = -1
        self._progres.valueChanged.connect(self._avance)
        self._progres.finished.connect(lambda: self.aller(self.index + 1))

        self.bouton_voir = QPushButton(t("Voir l'offre"), self)
        self.bouton_voir.setObjectName("Primary")
        self.bouton_voir.setCursor(Qt.CursorShape.PointingHandCursor)
        self.bouton_voir.clicked.connect(lambda: self.fiche and self.voir.emit(self.fiche))
        self.bouton_suivre = QPushButton(t("Suivre"), self)
        self.bouton_suivre.setObjectName("HeroGhost")
        self.bouton_suivre.setCursor(Qt.CursorShape.PointingHandCursor)
        self.bouton_suivre.setToolTip(t("Ajouter a vos Envies pour etre prevenu d'une baisse"))
        self.bouton_suivre.clicked.connect(self._suivre)

    # ------------------------------------------------------------------
    @property
    def fiche(self):
        return self.fiches[self.index] if 0 <= self.index < len(self.fiches) else None

    def set_fiches(self, fiches, suivis: set[str] | None = None) -> None:
        cles = [f.cle for f in fiches]
        actuelle = self.fiche.cle if self.fiche else ""
        self.fiches = list(fiches)
        if suivis is not None:
            self.suivis = set(suivis)
        # la meme selection apres une actualisation : on garde le jeu montre
        self.index = cles.index(actuelle) if actuelle in cles else 0
        self._precedent = -1
        self.setVisible(bool(self.fiches))
        for f in self.fiches[:3]:
            self.chargeur.precharger(f.visuels("une"))
        self._maj_boutons()
        self._relancer()
        self.update()

    def set_suivis(self, suivis: set[str]) -> None:
        self.suivis = set(suivis)
        self._maj_boutons()

    def aller(self, index: int) -> None:
        if not self.fiches:
            return
        index %= len(self.fiches)
        if index != self.index:
            self._precedent = self.index
            self.index = index
            self._fondu.stop()
            self._fondu.start()
            # le suivant est charge pendant qu'on regarde celui-ci
            self.chargeur.precharger(self.fiches[(index + 1) % len(self.fiches)].visuels("une"))
        self._maj_boutons()
        self._relancer()
        self.update()

    def _relancer(self) -> None:
        self._progres.stop()
        if len(self.fiches) > 1:
            self._progres.start()
            if self._survol_scene or self._survol_liste >= 0 or not self.isVisible():
                self._progres.pause()

    # page cachee (autre onglet, autre page) : le carrousel ne tourne pas
    # pour rien, il reprend ou il en etait
    def hideEvent(self, event) -> None:
        if self._progres.state() == QVariantAnimation.State.Running:
            self._progres.pause()
        super().hideEvent(event)

    def showEvent(self, event) -> None:
        if (self._progres.state() == QVariantAnimation.State.Paused
                and not self._survol_scene and self._survol_liste < 0):
            self._progres.resume()
        super().showEvent(event)

    def _suivre(self) -> None:
        f = self.fiche
        if f and f.steam_appid:
            # un clic suit, un second annule (clic de travers)
            if f.steam_appid in self.suivis:
                self.suivis.discard(f.steam_appid)
                self.ne_plus_suivre.emit(f)
            else:
                self.suivis.add(f.steam_appid)
                self.suivre.emit(f)
            self._maj_boutons()

    def _maj_boutons(self) -> None:
        f = self.fiche
        self.bouton_voir.setVisible(bool(f and f.meilleure))
        if f and f.meilleure:
            m = f.meilleure
            self.bouton_voir.setText(t("Voir l'offre") + f"  ·  {euros(m.prix)}")
            self.bouton_voir.setToolTip(t("Ouvrir la page du jeu chez") + f" {m.boutique}")
        suivi = bool(f and f.steam_appid in self.suivis)
        self.bouton_suivre.setVisible(bool(f and f.steam_appid))
        self.bouton_suivre.setText(t(SUIVI) if suivi else t("Suivre"))
        self.bouton_suivre.setToolTip(t(
            "Dans vos Envies. Cliquez pour ne plus suivre ce jeu." if suivi
            else "Ajouter a vos Envies pour etre prevenu d'une baisse"))
        self._placer_boutons()

    # -- geometrie ----------------------------------------------------------
    def _avec_liste(self) -> bool:
        return self.width() >= 980 and len(self.fiches) > 1

    def _rect_scene(self) -> QRectF:
        w = self.width() - (LISTE + ECART if self._avec_liste() else 0)
        return QRectF(0.5, 0.5, w - 1, self.height() - 1)

    def _rect_liste(self) -> QRectF:
        if not self._avec_liste():
            return QRectF()
        return QRectF(self.width() - LISTE, 0, LISTE, self.height())

    def _rect_item(self, i: int) -> QRectF:
        zone = self._rect_liste()
        n = max(1, len(self.fiches))
        h = (zone.height() - (n - 1) * 8) / n
        return QRectF(zone.left(), zone.top() + i * (h + 8), zone.width(), h)

    def _fleches(self) -> list[tuple[int, QRectF]]:
        if len(self.fiches) < 2:
            return []
        s = self._rect_scene()
        y = s.center().y() - 22
        return [(-1, QRectF(s.left() + 14, y, 44, 44)),
                (1, QRectF(s.right() - 58, y, 44, 44))]

    def _points(self) -> list[QRectF]:
        s = self._rect_scene()
        n = len(self.fiches)
        if n < 2:
            return []
        largeur = n * 10 + (n - 1) * 8 + 22      # le point actif est allonge
        x = s.right() - 36 - largeur
        out = []
        for i in range(n):
            w = 32 if i == self.index else 10
            out.append(QRectF(x, s.bottom() - 34, w, 10))
            x += w + 8
        return out

    def _marge(self) -> float:
        return 44 if self._rect_scene().width() > 700 else 28

    def _placer_boutons(self) -> None:
        s = self._rect_scene()
        x = s.left() + self._marge()
        y = s.bottom() - 40 - self.bouton_voir.sizeHint().height()
        self.bouton_voir.adjustSize()
        self.bouton_voir.move(int(x), int(y))
        self.bouton_suivre.adjustSize()
        self.bouton_suivre.resize(self.bouton_suivre.width(), self.bouton_voir.height())
        self.bouton_suivre.move(int(x + self.bouton_voir.width() + 10), int(y))

    def resizeEvent(self, event) -> None:
        self._placer_boutons()
        super().resizeEvent(event)

    # -- dessin ---------------------------------------------------------------
    def _avance(self, v) -> None:
        """La barre de progression avance par petits pas (10 par seconde) :
        repeindre le carrousel 60 fois par seconde occupait un tiers de coeur."""
        pas = int(float(v or 0.0) * (DUREE / 100.0))
        if pas != self._pas_progres:
            self._pas_progres = pas
            self.update(self._rect_liste().toRect())

    def _image_prete(self, url: str) -> None:
        if url in self._voulues:
            self.update()

    def _visuel(self, p: QPainter, fiche, scene: QRectF, opacite: float) -> None:
        urls = fiche.visuels("une")
        self._voulues.update(urls)
        taille = QSize(int(scene.width()), int(scene.height()))
        trouve = self.chargeur.source(urls)
        p.setOpacity(opacite)
        if trouve is None:
            degrade(p, scene, fiche.cle)
        else:
            url, source = trouve
            if source.width() >= scene.width() * 0.62:
                p.drawPixmap(scene.topLeft(), self.chargeur.a_la_taille(url, source, taille))
            else:
                # petite image (en-tete Steam) : fond flou + image nette a droite
                p.drawPixmap(scene.topLeft(),
                             self.chargeur.a_la_taille(url, source, taille, flou))
                p.fillRect(scene, QColor(10, 13, 20, 90))
                h = min(scene.height() * 0.62, source.height() * 1.6)
                w = h * source.width() / max(1, source.height())
                cible = QRectF(scene.right() - w - 64, scene.top() + (scene.height() - h) / 2 - 10,
                               w, h)
                net = self.chargeur.a_la_taille(url, source, QSize(int(w), int(h)))
                ombre = QPainterPath()
                ombre.addRoundedRect(cible.adjusted(-2, 6, 2, 14), 14, 14)
                p.fillPath(ombre, QColor(0, 0, 0, 110))
                chemin = QPainterPath()
                chemin.addRoundedRect(cible, 12, 12)
                p.save()
                p.setClipPath(chemin, Qt.ClipOperation.IntersectClip)
                p.drawPixmap(cible.topLeft(), net)
                p.restore()
        p.setOpacity(1.0)

    def paintEvent(self, event) -> None:
        if not self.fiches:
            return
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        base = self.font()
        self._voulues = set()
        scene = self._rect_scene()
        chemin = QPainterPath()
        chemin.addRoundedRect(scene, 18, 18)

        p.save()
        p.setClipPath(chemin)
        p.fillRect(scene, QColor(14, 18, 28))
        t_fondu = float(self._fondu.currentValue() or 1.0) \
            if self._fondu.state() == QVariantAnimation.State.Running else 1.0
        if 0 <= self._precedent < len(self.fiches) and t_fondu < 1.0:
            self._visuel(p, self.fiches[self._precedent], scene, 1.0)
        self._visuel(p, self.fiche, scene, t_fondu)

        # voiles : lisibilite du texte a gauche et en bas
        voile = QLinearGradient(scene.topLeft(), QPointF(scene.left() + scene.width() * 0.72,
                                                         scene.top()))
        voile.setColorAt(0, QColor(8, 11, 18, 238))
        voile.setColorAt(0.45, QColor(8, 11, 18, 150))
        voile.setColorAt(1, QColor(8, 11, 18, 0))
        p.fillRect(scene, QBrush(voile))
        bas = QLinearGradient(QPointF(0, scene.bottom() - 170), QPointF(0, scene.bottom()))
        bas.setColorAt(0, QColor(8, 11, 18, 0))
        bas.setColorAt(1, QColor(8, 11, 18, 200))
        p.fillRect(QRectF(scene.left(), scene.bottom() - 170, scene.width(), 170), QBrush(bas))
        p.restore()

        self._textes(p, scene, base)
        self._commandes(p, scene)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(QColor(255, 255, 255, 26), 1))
        p.drawPath(chemin)
        if self._avec_liste():
            self._liste(p, base)
        p.end()

    def _textes(self, p: QPainter, scene: QRectF, base: QFont) -> None:
        f = self.fiche
        x = scene.left() + self._marge()
        # meme largeur entiere pour la mesure et le dessin : sinon un titre
        # tout juste a la limite se mesure sur deux lignes et s'ecrit sur une
        largeur = int(min(scene.width() * 0.6, 620))
        y = scene.top() + 40

        fe = police(base, 10.5, QFont.Weight.Bold, 1.6)
        pilule(p, x, y, t("A LA UNE"), couleur("accent", 38), couleur("accent"), fe, 22)
        fin = reste(f.fin_promo)
        if fin:
            pilule(p, x + QFontMetrics(fe).horizontalAdvance(t("A LA UNE")) + 24, y,
                   t(fin).upper(), QColor(255, 180, 84, 34), couleur("warn"), fe, 22)
        y += 38

        ft = police(base, 34 if scene.width() > 760 else 27, QFont.Weight.Bold)
        p.setFont(ft)
        fm = QFontMetrics(ft)
        zone = fm.boundingRect(0, 0, largeur, 400, Qt.TextFlag.TextWordWrap, f.titre)
        h = min(zone.height(), fm.lineSpacing() * 2)
        drapeaux = Qt.TextFlag.TextWordWrap | Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop
        p.setPen(QColor(0, 0, 0, 90))
        p.drawText(QRectF(x + 1, y + 2, largeur, h), drapeaux, f.titre)
        p.setPen(QColor(255, 255, 255))
        p.drawText(QRectF(x, y, largeur, h), drapeaux, f.titre)
        y += h + 12

        infos = []
        if f.etiquettes:
            infos.append(" · ".join(f.etiquettes[:3]))
        if f.note:
            infos.append(f"{f.note} % " + t("d'avis positifs"))
        if f.studios:
            infos.append(f.studios[0])
        if infos:
            fi = police(base, 13)
            p.setFont(fi)
            p.setPen(QColor(231, 236, 245, 200))
            # des informations entieres plutot qu'une derniere coupee
            fmi = QFontMetrics(fi)
            ligne = infos[0]
            for info in infos[1:]:
                essai = ligne + "   ·   " + info
                if fmi.horizontalAdvance(essai) > largeur:
                    break
                ligne = essai
            p.drawText(QRectF(x, y, largeur, 22), Qt.AlignmentFlag.AlignLeft |
                       Qt.AlignmentFlag.AlignVCenter,
                       fmi.elidedText(ligne, Qt.TextElideMode.ElideRight, int(largeur)))
            y += 32

        # prix
        m = f.meilleure
        if m is not None:
            base_y = self.bouton_voir.y() - 26
            fp = police(base, 30, QFont.Weight.Bold)
            prix = euros(m.prix)
            xp = x
            if f.remise:
                fr = police(base, 17, QFont.Weight.Bold)
                xp += pilule(p, xp, base_y - 30, f"-{f.remise} %", couleur("ok"),
                             QColor(6, 22, 16), fr, 32) + 14
            if f.prix_normal and f.prix_normal > m.prix:
                fa = police(base, 15)
                ancien = euros(f.prix_normal)
                p.setFont(fa)
                p.setPen(QColor(231, 236, 245, 140))
                p.drawText(QPointF(xp, base_y - 8), ancien)
                wa = QFontMetrics(fa).horizontalAdvance(ancien)
                p.setPen(QPen(QColor(231, 236, 245, 140), 1.2))
                p.drawLine(QPointF(xp - 1, base_y - 13), QPointF(xp + wa + 1, base_y - 13))
                xp += wa + 12
            p.setFont(fp)
            p.setPen(couleur("ok") if f.remise else QColor(255, 255, 255))
            p.drawText(QPointF(xp, base_y - 4), prix)
            fc = police(base, 12)
            p.setFont(fc)
            p.setPen(QColor(231, 236, 245, 150))
            chez = t("chez") + f" {m.boutique}"
            if f.au_plus_bas:
                chez += "  ·  " + t("plus bas historique")
            p.drawText(QPointF(xp + QFontMetrics(fp).horizontalAdvance(prix) + 12,
                               base_y - 6), chez)

    def _commandes(self, p: QPainter, scene: QRectF) -> None:
        for i, r in enumerate(self._points()):
            actif = i == self.index
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(255, 255, 255, 230) if actif else QColor(255, 255, 255, 80))
            p.drawRoundedRect(r, 5, 5)
        if not self._survol_scene:
            return
        for sens, r in self._fleches():
            p.setPen(QPen(QColor(255, 255, 255, 70), 1))
            p.setBrush(QColor(10, 13, 20, 190))
            p.drawEllipse(r)
            p.setPen(QPen(QColor(255, 255, 255), 2.4, Qt.PenStyle.SolidLine,
                          Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
            c = r.center()
            k = 6 * sens
            p.drawPolyline([QPointF(c.x() - k * 0.6, c.y() - 8), QPointF(c.x() + k * 0.6, c.y()),
                            QPointF(c.x() - k * 0.6, c.y() + 8)])

    def _liste(self, p: QPainter, base: QFont) -> None:
        ft = police(base, 12.5, QFont.Weight.DemiBold)
        fs = police(base, 11.5)
        progres = float(self._progres.currentValue() or 0.0)
        for i, f in enumerate(self.fiches):
            r = self._rect_item(i)
            actif = i == self.index
            chemin = QPainterPath()
            chemin.addRoundedRect(r, 12, 12)
            if actif:
                p.fillPath(chemin, QColor(27, 34, 51, 235))
                p.save()
                p.setClipPath(chemin)
                p.fillRect(QRectF(r.left(), r.top(), r.width() * progres, r.height()),
                           couleur("accent", 26))
                p.restore()
            elif i == self._survol_liste:
                p.fillPath(chemin, QColor(27, 34, 51, 170))
            else:
                p.fillPath(chemin, QColor(20, 25, 38, 120))
            # vignette
            hv = r.height() - 16
            wv = min(hv * 1.75, 104)
            hv = wv / 1.75
            vr = QRectF(r.left() + 8, r.center().y() - hv / 2, wv, hv)
            urls = f.visuels("carte")
            self._voulues.update(urls)
            pix = self.chargeur.image(urls, QSize(int(wv), int(hv)))
            vc = QPainterPath()
            vc.addRoundedRect(vr, 8, 8)
            p.save()
            p.setClipPath(vc)
            if pix is not None:
                p.drawPixmap(vr.topLeft(), pix)
            else:
                degrade(p, vr, f.cle)
            if not actif:
                p.fillRect(vr, QColor(10, 13, 20, 70))
            p.restore()
            # textes
            x = vr.right() + 12
            largeur = r.right() - 12 - x
            p.setFont(ft)
            p.setPen(couleur("text") if actif else couleur("text_dim"))
            fm = QFontMetrics(ft)
            titre = fm.elidedText(f.titre, Qt.TextElideMode.ElideRight, int(largeur))
            p.drawText(QRectF(x, r.center().y() - 19, largeur, 18),
                       Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, titre)
            m = f.meilleure
            if m is not None:
                p.setFont(fs)
                ligne = (f"-{f.remise} %   " if f.remise else "") + euros(m.prix)
                p.setPen(couleur("ok") if f.remise else couleur("text_faint"))
                p.drawText(QRectF(x, r.center().y() + 1, largeur, 18),
                           Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, ligne)

    # -- souris ---------------------------------------------------------------
    def mouseMoveEvent(self, event) -> None:
        pos = event.position()
        scene = self._rect_scene().contains(pos)
        item = next((i for i in range(len(self.fiches)) if self._avec_liste()
                     and self._rect_item(i).contains(pos)), -1)
        if scene != self._survol_scene or item != self._survol_liste:
            self._survol_scene, self._survol_liste = scene, item
            if scene or item >= 0:
                self._progres.pause()
            elif self._progres.state() == QVariantAnimation.State.Paused:
                self._progres.resume()
            self.update()
        self.setCursor(Qt.CursorShape.PointingHandCursor if scene or item >= 0
                       else Qt.CursorShape.ArrowCursor)
        super().mouseMoveEvent(event)

    def leaveEvent(self, event) -> None:
        self._survol_scene, self._survol_liste = False, -1
        if self._progres.state() == QVariantAnimation.State.Paused:
            self._progres.resume()
        self.update()
        super().leaveEvent(event)

    def mouseReleaseEvent(self, event) -> None:
        if event.button() != Qt.MouseButton.LeftButton or not self.fiches:
            return super().mouseReleaseEvent(event)
        pos = event.position()
        for sens, r in self._fleches():
            if r.contains(pos):
                self.aller(self.index + sens)
                return
        for i, r in enumerate(self._points()):
            if r.adjusted(-4, -6, 4, 6).contains(pos):
                self.aller(i)
                return
        if self._avec_liste():
            for i in range(len(self.fiches)):
                if self._rect_item(i).contains(pos):
                    self.aller(i)
                    return
        if self._rect_scene().contains(pos):
            self.ouvrir.emit(self.fiche)

    def keyPressEvent(self, event) -> None:
        if event.key() == Qt.Key.Key_Left:
            self.aller(self.index - 1)
        elif event.key() == Qt.Key.Key_Right:
            self.aller(self.index + 1)
        else:
            super().keyPressEvent(event)
