"""Fichiers KeyValues de Valve (2.1.0) : « "setting.defaultres" "1920" ».

Format de Counter-Strike 2, Dota 2, Deadlock (cs2_video.txt) et des jeux
Respawn (Apex Legends, Titanfall 2 : videoconfig.txt). La valeur est
remplacee sur place, entre ses guillemets ; une cle absente n'est jamais
creee.
"""
from __future__ import annotations

import os
import re
from pathlib import Path

from ...core.logging_setup import get
from ...core.models import TweakOp
from .base import TweakWriter
from .ini_writer import lire_texte

log = get("tweaks.keyvalues")


def _motif(cle: str) -> re.Pattern:
    return re.compile(r'^(?P<avant>[ \t]*"' + re.escape(cle) + r'"[ \t]+")(?P<valeur>[^"\r\n]*)(?P<apres>")', re.M)


def lire_valeur(texte: str, cle: str) -> str | None:
    trouves = list(_motif(cle).finditer(texte or ""))
    return trouves[-1].group("valeur").strip() if trouves else None


def modifier(texte: str, valeurs: list[tuple[str, str]]) -> tuple[str, list[str]]:
    absentes: list[str] = []
    for cle, valeur in valeurs:
        m = list(_motif(cle).finditer(texte))
        if not m:
            absentes.append(cle)
            continue
        dernier = m[-1]
        texte = texte[:dernier.start("valeur")] + str(valeur) + texte[dernier.end("valeur"):]
    return texte, absentes


class KeyValuesWriter(TweakWriter):
    id = "keyvalues"
    label = "Fichier KeyValues (Valve)"

    def read(self, op: TweakOp) -> str | None:
        texte, _enc, _eol = lire_texte(Path(op.target))
        return lire_valeur(texte, op.key) if texte else None

    def write(self, ops: list[TweakOp]) -> tuple[int, str]:
        by_file: dict[str, list[TweakOp]] = {}
        for op in ops:
            by_file.setdefault(op.target, []).append(op)
        written, erreurs = 0, []
        for target, items in by_file.items():
            path = Path(target)
            if not path.exists():
                erreurs.append(f"{path.name} introuvable : rien n'est cree a sa place.")
                continue
            if not os.access(path, os.W_OK):
                erreurs.append(f"{path.name} est en lecture seule : ORION ne le force pas.")
                continue
            try:
                texte, enc, _eol = lire_texte(path)
                nouveau, absentes = modifier(texte, [(o.key, str(o.value)) for o in items])
                if absentes:
                    log.info("%s : cle(s) absente(s), non creee(s) : %s", path.name, absentes)
                if nouveau != texte:
                    provisoire = path.with_name(path.name + ".orion.tmp")
                    provisoire.write_bytes(nouveau.encode(enc))
                    os.replace(provisoire, path)
                written += len(items) - len(absentes)
            except Exception as exc:
                log.exception("Ecriture KeyValues impossible : %s", path)
                erreurs.append(f"Ecriture impossible dans {path.name} : {exc}")
        return written, (" ; ".join(erreurs) if erreurs else "Reglages ecrits")
