"""Jeux offerts par l'Epic Games Store.

Epic publie sa rotation hebdomadaire sur un point d'acces public, sans cle
ni compte. Les jeux annonces pour la semaine suivante y figurent aussi :
ORION les affiche en avance, avec leur date d'ouverture.

Un jeu recupere chez Epic reste acquis : la nature est donc « a garder »,
seule la fenetre de recuperation expire.
"""
from __future__ import annotations

from orion.core import region

import time

from ...core.logging_setup import get
from .base import A_GARDER, Freebie, FreebieSource, fetch_json, parse_date

log = get("gratuits.epic")

API = "https://store-site-backend-static.ak.epicgames.com/freeGamesPromotions"
PRODUCT = "https://store.epicgames.com/{locale}/p/{slug}"


class EpicFreebies(FreebieSource):
    id = "epic"
    label = "Epic Games Store"
    priority = 90
    filtre_adulte = "categories et etiquettes de l'offre Epic lues par produit_adulte"

    def fetch(self) -> list[Freebie]:
        country = region.pays()
        locale = "fr" if country == "FR" else "en-US"
        payload = fetch_json(API, {"locale": locale, "country": country,
                                   "allowCountries": country})
        elements = (((payload or {}).get("data") or {})
                    .get("Catalog", {}).get("searchStore", {})
                    .get("elements") or [])

        out: list[Freebie] = []
        for el in elements:
            try:
                fb = self._one(el, locale)
            except Exception:
                continue
            if fb is not None:
                out.append(fb)
        log.info("Epic : %d offre(s)", len(out))
        return out

    # ------------------------------------------------------------------
    def _one(self, el: dict, locale: str) -> Freebie | None:
        promos = el.get("promotions") or {}
        window = self._window(promos.get("promotionalOffers"))
        upcoming = False
        if window is None:
            window = self._window(promos.get("upcomingPromotionalOffers"))
            upcoming = window is not None
        if window is None:
            return None

        start, end = window
        # une offre deja terminee n'a plus rien a dire
        if end and end < time.time():
            return None

        price = (el.get("price") or {}).get("totalPrice") or {}
        original = int(price.get("originalPrice") or 0) / 100.0
        discount = int(price.get("discountPrice") or 0) / 100.0
        # en cours : le prix doit etre tombe a zero. A venir : pas encore.
        if not upcoming and discount > 0:
            return None
        if (el.get("offerType") or "").upper() in ("ADD_ON", "DLC"):
            return None

        slug = self._slug(el)
        title = str(el.get("title") or "").strip()
        if not title or not slug:
            return None

        url = PRODUCT.format(locale=locale, slug=slug)
        return Freebie(
            adulte=self.adulte(el),
            key=f"epic:{el.get('id') or slug}",
            title=title,
            source=self.id,
            shop="Epic Games Store",
            url=url,
            buy_url=url,
            kind=A_GARDER,
            starts_at=start if upcoming else 0.0,
            ends_at=end,
            worth=round(original, 2),
            currency=str(price.get("currencyCode") or "EUR"),
            image=self._image(el),
            description=str(el.get("description") or "").strip()[:400],
        )

    @staticmethod
    def _window(blocks) -> tuple[float, float] | None:
        """Premiere fenetre a 100 % de remise trouvee dans un bloc Epic."""
        for block in blocks or []:
            for offer in (block or {}).get("promotionalOffers") or []:
                setting = offer.get("discountSetting") or {}
                percent = setting.get("discountPercentage")
                # Epic exprime la gratuite par 0 (prix restant) selon les cas
                if percent not in (0, 0.0, None):
                    continue
                return (parse_date(offer.get("startDate")),
                        parse_date(offer.get("endDate")))
        return None

    @staticmethod
    def _slug(el: dict) -> str:
        mappings = (el.get("catalogNs") or {}).get("mappings") or []
        for m in mappings:
            if m.get("pageSlug"):
                return str(m["pageSlug"])
        for m in el.get("offerMappings") or []:
            if m.get("pageSlug"):
                return str(m["pageSlug"])
        slug = str(el.get("productSlug") or el.get("urlSlug") or "")
        return slug.split("/")[0]

    @staticmethod
    def _image(el: dict) -> str:
        images = {str(i.get("type") or ""): str(i.get("url") or "")
                  for i in el.get("keyImages") or []}
        for kind in ("OfferImageTall", "Thumbnail", "DieselStoreFrontTall",
                     "OfferImageWide", "DieselStoreFrontWide"):
            if images.get(kind):
                return images[kind]
        return next(iter(images.values()), "")
