"""Mise a jour automatique d'ORION.

1. `verifier()` lit la derniere version publiee sur GitHub
   (Sikher-kisa/orion-game-launcher, onglet Releases) ;
2. `telecharger()` recupere `Installateur-ORION.exe` et controle son
   empreinte SHA-256 (celle calculee par GitHub, a defaut celle ecrite dans
   les notes de version). Sans empreinte verifiable, rien n'est installe ;
3. `installer()` lance l'installateur en mode silencieux : il attend la
   fermeture d'ORION, remplace le programme (jamais les donnees) et
   relance la nouvelle version.

Aucune information n'est envoyee : ORION lit une page publique, comme un
navigateur.
"""
from __future__ import annotations

import hashlib
import os
import re
import sys
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path

from .core.logging_setup import get
from .version import APP_VERSION

log = get("maj")

DEPOT = "Sikher-kisa/orion-game-launcher"
API = f"https://api.github.com/repos/{DEPOT}/releases/latest"
PAGE = f"https://github.com/{DEPOT}/releases/latest"
NOM_INSTALLATEUR = "Installateur-ORION.exe"

_HEX64 = re.compile(r"\b([0-9a-fA-F]{64})\b")


MARQUE_STORE = "store.txt"


def depuis_store() -> bool:
    """ORION vient-il du Microsoft Store ? Le paquet du Store contient un
    fichier temoin a cote du programme. Dans ce cas c'est le Store qui met a
    jour : ORION ne telecharge ni n'installe rien lui-meme."""
    try:
        return (Path(sys.executable).resolve().parent / MARQUE_STORE).is_file()
    except OSError:
        return False


def version_tuple(texte: str) -> tuple[int, ...]:
    """« v1.7.0 », « 1.7 », « 1.7.0-essai » -> (1, 7, 0)."""
    nombres = re.findall(r"\d+", (texte or "").split("-")[0])
    t = tuple(int(n) for n in nombres[:4])
    return t + (0,) * (3 - len(t)) if len(t) < 3 else t


def plus_recente(distante: str, locale: str = APP_VERSION) -> bool:
    return version_tuple(distante) > version_tuple(locale)


@dataclass
class Publication:
    version: str = ""
    titre: str = ""
    notes: str = ""
    page: str = PAGE
    url: str = ""
    taille: int = 0
    sha256: str = ""
    date: str = ""
    points: list[str] = field(default_factory=list)

    @property
    def disponible(self) -> bool:
        return bool(self.version) and plus_recente(self.version)

    @property
    def verifiable(self) -> bool:
        return bool(self.url) and len(self.sha256) == 64


def lire_publication(donnees: dict) -> Publication:
    """Interprete la reponse de l'API GitHub (fonction pure, testee)."""
    pub = Publication()
    if not isinstance(donnees, dict) or donnees.get("draft"):
        return pub
    pub.version = str(donnees.get("tag_name") or "").lstrip("vV")
    pub.titre = donnees.get("name") or f"ORION {pub.version}"
    pub.notes = donnees.get("body") or ""
    pub.page = donnees.get("html_url") or PAGE
    pub.date = (donnees.get("published_at") or "")[:10]
    for asset in donnees.get("assets") or []:
        if (asset.get("name") or "").lower() == NOM_INSTALLATEUR.lower():
            pub.url = asset.get("browser_download_url") or ""
            pub.taille = int(asset.get("size") or 0)
            digest = str(asset.get("digest") or "")
            if digest.lower().startswith("sha256:"):
                pub.sha256 = digest.split(":", 1)[1].lower()
            break
    if not pub.sha256:
        # a defaut, l'empreinte publiee dans les notes de version
        trouve = _HEX64.search(pub.notes)
        if trouve:
            pub.sha256 = trouve.group(1).lower()
    pub.points = [_point(l.strip()[2:]) for l in pub.notes.splitlines()
                  if l.strip().startswith(("- ", "* "))][:12]
    return pub


def _point(ligne: str) -> str:
    """Une ligne des notes de version, prete pour la fenetre de mise a jour :
    le gras Markdown (**Titre.**) devient du gras, le reste est du texte."""
    import html
    texte = html.escape(ligne.strip(), quote=False)
    texte = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", texte)
    return re.sub(r"`([^`]+)`", r"\1", texte)


def verifier(garder: int = 1800) -> Publication:
    """Derniere version publiee. Leve une exception si GitHub est injoignable."""
    from .core import reseau
    donnees = reseau.get_json(API, garder=garder, timeout=15, headers={
        "Accept": "application/vnd.github+json"})
    pub = lire_publication(donnees)
    log.info("Derniere version publiee : %s (installee : %s)",
             pub.version or "?", APP_VERSION)
    return pub


def dossier_temporaire() -> Path:
    d = Path(tempfile.gettempdir()) / "ORION-mise-a-jour"
    d.mkdir(parents=True, exist_ok=True)
    return d


def empreinte(fichier: Path) -> str:
    h = hashlib.sha256()
    with open(fichier, "rb") as f:
        for bloc in iter(lambda: f.read(1024 * 1024), b""):
            h.update(bloc)
    return h.hexdigest()


def telecharger(pub: Publication, progress_cb=None) -> Path:
    """Telecharge et verifie l'installateur. Rend son chemin."""
    if not pub.verifiable:
        raise RuntimeError("empreinte de la version introuvable : "
                           "installation automatique refusee par prudence")
    from .core import reseau
    cible = dossier_temporaire() / f"Installateur-ORION-{pub.version}.exe"
    if cible.exists() and empreinte(cible) == pub.sha256:
        return cible

    def suivre(fait: int, total: int) -> None:
        if progress_cb:
            progress_cb(f"Telechargement de la version {pub.version}...",
                        int(fait * 100 / max(total, 1)))

    reseau.telecharger(pub.url, cible, progression=suivre, timeout=120,
                       headers={"Accept": "application/octet-stream"})
    obtenue = empreinte(cible)
    if obtenue != pub.sha256:
        cible.unlink(missing_ok=True)
        raise RuntimeError("le fichier telecharge ne correspond pas a "
                           "l'empreinte publiee : il a ete supprime")
    log.info("Version %s telechargee et verifiee", pub.version)
    return cible


def dossier_programme() -> Path:
    """Dossier ou cet ORION est reellement installe : celui de l'executable
    en cours quand l'application est compilee (l'utilisateur a pu choisir
    un autre dossier que celui par defaut), sinon celui declare a Windows."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    from .deploiement.installation import dossier_installe
    return dossier_installe()


def arguments_installateur(installateur: Path, pid: int | None = None,
                           cible: Path | None = None) -> list[str]:
    """Ligne de commande de l'installation silencieuse."""
    return [str(installateur), "--silencieux",
            "--attendre", str(pid if pid is not None else os.getpid()),
            "--cible", str(cible or dossier_programme()),
            "--relancer"]


def installer(installateur: Path) -> bool:
    """Lance l'installation silencieuse ; ORION doit se fermer juste apres.

    L'installateur attend la fin de ce processus avant de remplacer les
    fichiers (un programme en cours d'execution ne peut pas etre ecrase
    sous Windows), installe dans le dossier d'ORION (`--cible`), puis
    relance ORION. Il est lance sans rien heriter d'ORION (chemin des DLL,
    dossier courant, variables PyInstaller) : voir `core.lancement`.
    """
    try:
        from .core.lancement import popen_propre
        args = arguments_installateur(Path(installateur))
        options = {}
        if sys.platform.startswith("win"):
            options["creationflags"] = (0x00000008 | 0x00000200)  # DETACHED | NEW_GROUP
        popen_propre(args, **options)
        log.info("Installation de la mise a jour lancee (cible : %s)", args[5])
        return True
    except Exception:
        log.exception("Lancement de l'installateur impossible")
        return False


def nettoyer() -> None:
    """Supprime les installateurs deja utilises et les restes d'une version
    remplacee (ORION.ancien-*, ORION.nouveau*), au demarrage suivant.

    Chaque fichier est traite a part : un fichier verrouille (antivirus,
    installateur encore ouvert) est simplement laisse pour la fois suivante,
    sans empecher la suppression des autres. Appele hors du fil de
    l'interface."""
    if depuis_store():
        return
    try:
        from .deploiement.installation import nettoyer_anciennes
        nettoyer_anciennes(dossier_programme())
    except Exception:
        log.debug("Restes de l'ancienne version non nettoyes", exc_info=True)
    try:
        fichiers = list(dossier_temporaire().iterdir())
    except Exception:
        return
    for f in fichiers:
        nom = f.name
        try:
            if nom.endswith(".partiel"):
                # telechargement interrompu (pas celui qui serait en cours)
                if time.time() - f.stat().st_mtime > 3600:
                    f.unlink(missing_ok=True)
            elif nom.startswith("Installateur-ORION-") and nom.endswith(".exe"):
                if not plus_recente(f.stem.rsplit("-", 1)[-1]):
                    f.unlink(missing_ok=True)
        except Exception:
            log.debug("Reste non supprime : %s", nom)
