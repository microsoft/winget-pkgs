"""Rangees de cartes animees : les promos du partenaire et les DLC d'un jeu (2.0).

Meme principe que `boutique_cartes` (une rangee = un seul widget, chaque
carte est peinte a la demande), avec deux mouvements en plus :

* **l'entree en cascade** : a la premiere apparition a l'ecran, les cartes
  montent et s'eclaircissent l'une apres l'autre ;
* **le survol** : la carte grossit legerement, son contour s'allume et un
  reflet traverse l'image. Le mouvement est progressif dans les deux sens.

Rien ne tourne en continu : l'entree dure moins d'une seconde et le survol
s'arrete des que les cartes sont au repos. `ANIMER = False` (tests, captures)
peint directement l'etat final.
"""
from __future__ import annotations

import math

from PySide6.QtCore import QPointF, QRect, QRectF, QSize, Qt, QTimer, QVariantAnimation
from PySide6.QtGui import (QBrush, QColor, QFont, QFontMetrics, QLinearGradient, QPainter,
                           QPainterPath, QPen)

from ...i18n import t
from .boutique_cartes import RAYON, RangeeCartes, couleur, degrade, euros, pilule, police


def _lisse(x: float) -> float:
    """Depart et arrivee en douceur (0..1)."""
    x = max(0.0, min(1.0, x))
    return x * x * (3 - 2 * x)


class RangeeAnimee(RangeeCartes):
    """Rangee horizontale dont les cartes entrent en cascade et reagissent
    au survol. Les sous-classes fournissent `dessiner`."""

    #: `False` : aucune animation, l'etat final est peint tout de suite
    ANIMER = True
    ENTREE = 460              # duree de l'entree d'une carte (ms)
    CASCADE = 60              # retard d'une carte sur la precedente (ms)
    SURVOL = 150              # duree de la montee au survol (ms)
    ZOOM = 0.03               # grossissement au survol
    MARGE = 10                # place laissee au-dessus et au-dessous pour ce grossissement
    MARGE_X = 6               # et sur les cotes (la rangee reste alignee sur son titre)
    RATIO_IMAGE = 1.75
    BAS = 96                  # hauteur de la zone de texte sous l'image

    def __init__(self, parent=None, largeur: int = 236) -> None:
        super().__init__(parent, largeur)
        self.setFixedHeight(self.hauteur() + 2 * self.MARGE)
        self._ms = 1e9                    # temps ecoule de l'entree (1e9 = finie)
        self._premier = 0                 # premiere carte visible quand l'entree demarre
        self._a_jouer = False
        self._temps = QVariantAnimation(self)
        self._temps.valueChanged.connect(self._avancer)
        self._temps.finished.connect(self._entree_finie)
        self._chaleur: dict[int, float] = {}       # carte -> 0..1 (survol)
        self._pouls = QTimer(self)
        self._pouls.setInterval(16)
        self._pouls.timeout.connect(self._refroidir)

    # -- geometrie --------------------------------------------------------
    def hauteur_image(self) -> int:
        return int(round(self.largeur / self.RATIO_IMAGE))

    def hauteur(self) -> int:
        return self.hauteur_image() + self.BAS

    @property
    def total(self) -> float:
        return super().total + 2 * self.MARGE_X

    def rect_carte(self, i: int) -> QRectF:
        x = self.MARGE_X + i * (self.largeur + self.ECART) - self._decalage
        return QRectF(x + 0.5, self.MARGE + 0.5, self.largeur - 1, self.hauteur() - 1)

    def indices_visibles(self, zone: QRect) -> range:
        pas = self.largeur + self.ECART
        debut = max(0, int((self._decalage + zone.left() - self.MARGE_X) // pas))
        fin = min(len(self.fiches),
                  int((self._decalage + zone.right() - self.MARGE_X) // pas) + 1)
        return range(debut, fin)

    def _fleches(self) -> list[tuple[int, QRectF]]:
        y = self.MARGE + self.hauteur_image() / 2 - self.FLECHE / 2
        out = []
        if self._decalage > 1:
            out.append((-1, QRectF(8, y, self.FLECHE, self.FLECHE)))
        if self._decalage < self.maximum - 1:
            out.append((1, QRectF(self.width() - 8 - self.FLECHE, y, self.FLECHE,
                                  self.FLECHE)))
        return out

    # -- entree en cascade ------------------------------------------------
    def _apres_fiches(self) -> None:
        super()._apres_fiches()
        self._chaleur.clear()
        if not self.memes_fiches():
            # jouee au premier affichage reel (voir paintEvent) : une rangee
            # plus bas dans la page attend d'etre vue
            self._a_jouer = bool(self.fiches)

    def jouer_entree(self) -> None:
        self._a_jouer = False
        if not self.ANIMER or not self.fiches:
            self._ms = 1e9
            return
        pas = self.largeur + self.ECART
        self._premier = int(self._decalage // pas)
        visibles = max(1, min(len(self.fiches) - self._premier, self.width() // pas + 2))
        duree = self.ENTREE + self.CASCADE * (visibles - 1)
        self._ms = 0.0
        self._temps.stop()
        self._temps.setDuration(duree)
        self._temps.setStartValue(0.0)
        self._temps.setEndValue(float(duree))
        self._temps.start()

    def _avancer(self, v) -> None:
        self._ms = float(v)
        self.update()

    def _entree_finie(self) -> None:
        self._ms = 1e9
        self.update()

    def apparition(self, i: int) -> float:
        """0 (pas encore la) a 1 (en place) pour la carte `i`."""
        if self._ms >= 1e8:
            return 1.0
        x = (self._ms - max(0, i - self._premier) * self.CASCADE) / self.ENTREE
        x = max(0.0, min(1.0, x))
        return 1 - (1 - x) ** 3

    def paintEvent(self, event) -> None:
        if self._a_jouer:
            self.jouer_entree()
        super().paintEvent(event)

    def _peindre_fondue(self, p, gauche: float, droite: float) -> None:
        """Cartes coupees au bord : la rangee animee peint ses propres cartes
        (`dessiner`, `urls`) dans le tampon, jamais les cartes de fiches de
        jeu de la rangee de base (15 octobre : une rangee de DLC qui debordait
        passait par `_a_recopier`, qui lit `fiche.visuels` : un DLC n'en a
        pas, et ORION plantait des que la rangee se redessinait, par exemple
        en passant en affichage salon avec la manette)."""
        dpr = self.devicePixelRatioF()
        t = QPainter(self._tampon_neuf(dpr))
        self._cartes(t, self.rect())
        self._masquer_bords(t, gauche, droite)
        t.end()
        self._tampon_cle = None          # pas de cache : l'animation change a chaque image
        p.drawPixmap(0, 0, self._tampon)

    # -- survol progressif ------------------------------------------------
    def survolable(self, fiche) -> bool:
        return True

    def _cible(self) -> int:
        i = self._survol
        return i if 0 <= i < len(self.fiches) and self.survolable(self.fiches[i]) else -1

    def _refroidir(self) -> None:
        pas = self._pouls.interval() / self.SURVOL
        cible, actif = self._cible(), False
        for i in set(self._chaleur) | ({cible} if cible >= 0 else set()):
            but = 1.0 if i == cible else 0.0
            v = self._chaleur.get(i, 0.0)
            v = min(1.0, v + pas) if but > v else max(0.0, v - pas)
            if v <= 0:
                self._chaleur.pop(i, None)
            else:
                self._chaleur[i] = v
            actif = actif or v != but
        if not actif:
            self._pouls.stop()
        self.update()

    def _reveiller(self) -> None:
        if not self.ANIMER:
            cible = self._cible()
            self._chaleur = {cible: 1.0} if cible >= 0 else {}
            self.update()
        elif not self._pouls.isActive():
            self._pouls.start()

    def mouseMoveEvent(self, event) -> None:
        avant = self._survol
        super().mouseMoveEvent(event)
        if self._survol != avant:
            self._reveiller()

    def leaveEvent(self, event) -> None:
        super().leaveEvent(event)
        self._reveiller()

    def hideEvent(self, event) -> None:
        self._pouls.stop()
        self._chaleur.clear()
        super().hideEvent(event)

    # -- peinture ---------------------------------------------------------
    def urls(self, fiche) -> list[str]:
        return fiche.visuels("carte")

    def dessiner(self, p: QPainter, rect: QRectF, fiche, pix, chaleur: float,
                 base: QFont) -> None:
        raise NotImplementedError

    def _cartes(self, p: QPainter, zone: QRect) -> None:
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        base = self.font()
        taille = QSize(self.largeur - 1, self.hauteur_image())
        # la carte survolee est peinte en dernier : elle passe au-dessus
        ordre = sorted(self.indices_visibles(self.rect()),
                       key=lambda i: self._chaleur.get(i, 0.0))
        for i in ordre:
            r = self.rect_carte(i)
            a = self.apparition(i)
            if a <= 0.001:
                continue
            f = self.fiches[i]
            urls = self.urls(f)
            self._voulues.update(urls)
            pix = self.chargeur.image(urls, taille)
            h = _lisse(self._chaleur.get(i, 0.0))
            c = r.center()
            k = (0.96 + 0.04 * a) * (1 + self.ZOOM * h)
            p.save()
            p.setOpacity(a)
            p.translate(c.x(), c.y() + (1 - a) * 22)
            p.scale(k, k)
            p.translate(-c.x(), -c.y())
            self.dessiner(p, r, f, pix, h, base)
            p.restore()


# ---------------------------------------------------------------------------
# Morceaux de carte communs
# ---------------------------------------------------------------------------
def _fond_et_image(p: QPainter, rect: QRectF, ih: float, pix, cle: str, titre: str,
                   base: QFont, chaleur: float, sombre: float = 0.0) -> QPainterPath:
    """Fond arrondi, image (ou degrade d'attente), fondu bas et reflet de
    survol. `sombre` (0..1) eteint l'image : contenu deja acquis."""
    chemin = QPainterPath()
    chemin.addRoundedRect(rect, RAYON, RAYON)
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QColor(20 + int(7 * chaleur), 25 + int(9 * chaleur), 38 + int(13 * chaleur), 232))
    p.drawPath(chemin)
    image = QRectF(rect.left(), rect.top(), rect.width(), ih)
    p.save()
    p.setClipPath(chemin)
    if pix is not None:
        p.drawPixmap(image.topLeft(), pix)
    else:
        degrade(p, image, cle, titre, base)
    fondu = QLinearGradient(QPointF(0, image.bottom() - 58), QPointF(0, image.bottom()))
    fondu.setColorAt(0, QColor(10, 13, 20, 0))
    fondu.setColorAt(1, QColor(10, 13, 20, 170))
    p.fillRect(QRectF(image.left(), image.bottom() - 58, image.width(), 58), QBrush(fondu))
    if sombre:
        p.fillRect(image, QColor(10, 13, 20, int(150 * sombre)))
    if 0 < chaleur < 1:
        # un reflet traverse l'image pendant que la carte se leve
        x = image.left() + image.width() * (-0.35 + 1.7 * chaleur)
        reflet = QLinearGradient(QPointF(x - 60, image.top()), QPointF(x + 60, image.bottom()))
        force = int(34 * math.sin(math.pi * chaleur))
        reflet.setColorAt(0, QColor(255, 255, 255, 0))
        reflet.setColorAt(0.5, QColor(255, 255, 255, force))
        reflet.setColorAt(1, QColor(255, 255, 255, 0))
        p.fillRect(image, QBrush(reflet))
    p.restore()
    return chemin


def _contour(p: QPainter, chemin: QPainterPath, rect: QRectF, chaleur: float) -> None:
    p.setBrush(Qt.BrushStyle.NoBrush)
    if chaleur > 0:
        halo = QColor(couleur("accent"))
        halo.setAlpha(int(70 * chaleur))
        p.setPen(QPen(halo, 4))
        p.drawRoundedRect(rect.adjusted(-1, -1, 1, 1), RAYON + 1, RAYON + 1)
    bord = QColor(couleur("accent")) if chaleur > 0 else QColor(couleur("border"))
    if chaleur > 0:
        bord.setAlpha(int(90 + 140 * chaleur))
    p.setPen(QPen(bord, 1 + 0.3 * chaleur))
    p.drawPath(chemin)


def _etiquette_remise(p: QPainter, x: float, y: float, remise: int, base: QFont) -> None:
    """Remise en gros, pleine couleur : c'est elle qu'on voit d'abord."""
    f = police(base, 12.5, QFont.Weight.ExtraBold)
    pilule(p, x, y, f"-{remise} %", couleur("ok"), QColor(8, 20, 14), f, 25)


def _prix(p: QPainter, droite: float, base_y: float, prix: float, normal: float,
          base: QFont, taille: float, gauche: float) -> float:
    """Prix final en vert et ancien prix barre a sa gauche ; rend le bord
    gauche de ce qui a ete ecrit."""
    fp = police(base, taille, QFont.Weight.Bold)
    texte = euros(prix)
    p.setFont(fp)
    x = droite - QFontMetrics(fp).horizontalAdvance(texte)
    p.setPen(couleur("ok"))
    p.drawText(QPointF(x, base_y), texte)
    if normal and normal > prix + 0.004:
        fa = police(base, taille * 0.74)
        ancien = euros(normal)
        wa = QFontMetrics(fa).horizontalAdvance(ancien)
        if x - wa - 8 > gauche:
            x -= wa + 8
            p.setFont(fa)
            p.setPen(couleur("text_faint"))
            p.drawText(QPointF(x, base_y), ancien)
            yb = base_y - QFontMetrics(fa).ascent() * 0.36
            p.setPen(QPen(couleur("text_faint"), 1))
            p.drawLine(QPointF(x - 1, yb), QPointF(x + wa + 1, yb))
    return x


def _chez_et_prix(p: QPainter, gauche: float, droite: float, base_y: float, boutique: str,
                  prix: float, normal: float, base: QFont, taille: float) -> None:
    """Bas de carte : « chez <boutique> » a gauche, le prix a droite. Quand
    la place manque, l'ancien prix barre cede la sienne au nom de la boutique
    (la remise est deja ecrite sur l'image)."""
    fc = police(base, 11)
    chez = t("chez") + f" {boutique}"
    fin_chez = gauche + QFontMetrics(fc).horizontalAdvance(chez)
    x = _prix(p, droite, base_y, prix, normal, base, taille, fin_chez + 10)
    if fin_chez + 8 < x:
        p.setFont(fc)
        p.setPen(couleur("text_faint"))
        p.drawText(QPointF(gauche, base_y), chez)


def _ligne(p: QPainter, f: QFont, encre: QColor, x: float, y: float, largeur: float,
           texte: str, hauteur: float = 20) -> None:
    p.setFont(f)
    p.setPen(encre)
    p.drawText(QRectF(x, y, largeur, hauteur),
               Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
               QFontMetrics(f).elidedText(texte, Qt.TextElideMode.ElideRight, int(largeur)))


# ---------------------------------------------------------------------------
# Promos du partenaire (Boutique)
# ---------------------------------------------------------------------------
class RangeePromos(RangeeAnimee):
    """Les jeux en promotion chez un distributeur partenaire : la remise et
    l'economie d'abord, le prix en gros."""

    BAS = 100

    def __init__(self, parent=None, largeur: int = 264) -> None:
        super().__init__(parent, largeur)

    def dessiner(self, p: QPainter, rect: QRectF, fiche, pix, chaleur: float,
                 base: QFont) -> None:
        ih = self.hauteur_image()
        chemin = _fond_et_image(p, rect, ih, pix, fiche.cle, fiche.titre, base, chaleur)
        image_bas = rect.top() + ih
        m = fiche.meilleure
        if fiche.remise:
            _etiquette_remise(p, rect.left() + 10, rect.top() + 10, fiche.remise, base)
        if m is not None and fiche.economie >= 1:
            fb = police(base, 9.5, QFont.Weight.Bold, 0.6)
            pilule(p, rect.left() + 10, image_bas - 27,
                   t("ECONOMIE") + "  " + euros(fiche.economie),
                   QColor(10, 13, 20, 205), couleur("ok"), fb, 19)

        gauche, droite = rect.left() + 13, rect.right() - 13
        largeur = droite - gauche
        _ligne(p, police(base, 13.5, QFont.Weight.DemiBold), couleur("text"),
               gauche, image_bas + 12, largeur, fiche.titre)
        if m is not None:
            _ligne(p, police(base, 11.5), couleur("text_dim"), gauche, image_bas + 33,
                   largeur, t(m.drm) if m.drm else m.boutique, 18)
            _chez_et_prix(p, gauche, droite, rect.bottom() - 15, m.boutique, m.prix,
                          fiche.prix_normal, base, 17)
        _contour(p, chemin, rect, chaleur)


# ---------------------------------------------------------------------------
# DLC d'un jeu (page du jeu)
# ---------------------------------------------------------------------------
class RangeeDlc(RangeeAnimee):
    """Les DLC d'un jeu en cartes : ceux a acheter avec leur meilleur prix,
    ceux deja acquis eteints et marques. Les « fiches » sont des `dlc.Dlc`."""

    RATIO_IMAGE = 2.14            # banniere Steam 460 x 215
    BAS = 76
    ZOOM = 0.035

    def __init__(self, parent=None, largeur: int = 222) -> None:
        super().__init__(parent, largeur)

    def urls(self, d) -> list[str]:
        return [d.image] if d.image else []

    def survolable(self, d) -> bool:
        return not d.acquis

    @staticmethod
    def etat(d) -> str:
        """Ce que la carte annonce (lu aussi par les tests)."""
        if d.acquis:
            return "Installe" if d.installe else "Deja acquis"
        if d.a_venir:
            return "A venir"
        if d.gratuit:
            return "Gratuit"
        return "A acheter" if d.meilleure is not None else "Non vendu seul"

    def dessiner(self, p: QPainter, rect: QRectF, d, pix, chaleur: float,
                 base: QFont) -> None:
        ih = self.hauteur_image()
        chemin = _fond_et_image(p, rect, ih, pix, d.appid, d.nom, base, chaleur,
                                sombre=1.0 if d.acquis else 0.0)
        image_bas = rect.top() + ih
        etat, m = self.etat(d), d.meilleure
        fb = police(base, 9.5, QFont.Weight.Bold, 0.6)
        if d.acquis:
            pilule(p, rect.left() + 10, image_bas - 27, t(etat).upper(),
                   QColor(10, 13, 20, 215), couleur("ok"), fb, 19)
        elif m is not None and m.remise:
            _etiquette_remise(p, rect.left() + 10, rect.top() + 10, m.remise, base)
        if d.nature == "musique":
            pilule(p, rect.right() - 10, rect.top() + 10, t("Bande originale").upper(),
                   QColor(10, 13, 20, 205), couleur("text_dim"), fb, 19, a_droite=True)

        gauche, droite = rect.left() + 12, rect.right() - 12
        largeur = droite - gauche
        _ligne(p, police(base, 12.5, QFont.Weight.DemiBold),
               couleur("text_dim" if d.acquis else "text"), gauche, image_bas + 10,
               largeur, d.nom)
        base_y = rect.bottom() - 14
        fc = police(base, 11)
        if etat == "A acheter":
            _chez_et_prix(p, gauche, droite, base_y, m.boutique, m.prix, m.prix_normal,
                          base, 15.5)
        else:
            texte = t("Dans votre compte Steam") if d.acquis else t(etat)
            p.setFont(fc)
            p.setPen(couleur("text_faint"))
            p.drawText(QPointF(gauche, base_y), texte)
        _contour(p, chemin, rect, chaleur)
