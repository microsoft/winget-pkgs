"""Fenetre de soutien au projet : lien, QR code, et rien d'autre.

Aucune insistance : pas de rappel automatique, pas de minuterie, pas de
fonction bridee. La fenetre ne s'ouvre que si l'utilisateur clique.
"""
from __future__ import annotations

import webbrowser
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QGuiApplication, QPixmap
from PySide6.QtWidgets import (QDialog, QHBoxLayout, QLabel, QPushButton,
                               QVBoxLayout)

from ...core.config import DONATE_URL
from ...core.paths import ASSETS_DIR, ROOT_DIR
from ...version import APP_NAME
from ..theme import build_qss

QR_CANDIDATES = (
    ASSETS_DIR / "paypal_qr.png",
    ROOT_DIR / "orion" / "ui" / "assets" / "paypal_qr.png",
)


class DonateDialog(QDialog):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.url = DONATE_URL
        self.setWindowTitle(f"Soutenir {APP_NAME}")
        self.setStyleSheet(build_qss())
        self.setMinimumWidth(420)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(26, 22, 26, 22)
        lay.setSpacing(14)

        title = QLabel(f"{APP_NAME} est gratuit")
        title.setObjectName("PanelTitle")
        lay.addWidget(title)

        text = QLabel(
            "Pas de publicite, pas de compte, pas de fonction bridee, et "
            "rien qui parte de votre machine sans que vous l'ayez demande.\n\n"
            "Si l'application vous rend service, un don libre aide a la faire "
            "vivre et a payer le temps passe dessus. Merci.")
        text.setObjectName("Dim")
        text.setWordWrap(True)
        lay.addWidget(text)

        qr = self._qr()
        if qr is not None:
            image = QLabel()
            image.setPixmap(qr)
            image.setAlignment(Qt.AlignmentFlag.AlignCenter)
            lay.addWidget(image)
            caption = QLabel("Scannez ce code avec l'application PayPal")
            caption.setObjectName("Faint")
            caption.setAlignment(Qt.AlignmentFlag.AlignCenter)
            lay.addWidget(caption)

        link = QLabel(self.url or "Aucun lien configure")
        link.setObjectName("Value")
        link.setAlignment(Qt.AlignmentFlag.AlignCenter)
        link.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextSelectableByMouse)
        lay.addWidget(link)

        row = QHBoxLayout()
        row.setSpacing(10)
        open_btn = QPushButton("Ouvrir PayPal")
        open_btn.setObjectName("Primary")
        open_btn.clicked.connect(self._open)
        open_btn.setEnabled(bool(self.url))
        row.addWidget(open_btn)

        copy_btn = QPushButton("Copier le lien")
        copy_btn.setObjectName("Ghost")
        copy_btn.clicked.connect(self._copy)
        copy_btn.setEnabled(bool(self.url))
        row.addWidget(copy_btn)

        close_btn = QPushButton("Fermer")
        close_btn.setObjectName("Ghost")
        close_btn.clicked.connect(self.accept)
        row.addWidget(close_btn)
        lay.addLayout(row)

    # ------------------------------------------------------------------
    @staticmethod
    def _qr() -> QPixmap | None:
        for path in QR_CANDIDATES:
            if Path(path).exists():
                pix = QPixmap(str(path))
                if not pix.isNull():
                    return pix.scaled(210, 210,
                                      Qt.AspectRatioMode.KeepAspectRatio,
                                      Qt.TransformationMode.SmoothTransformation)
        return None

    def _open(self) -> None:
        if self.url:
            webbrowser.open(self.url)

    def _copy(self) -> None:
        clipboard = QGuiApplication.clipboard()
        if clipboard and self.url:
            clipboard.setText(self.url)
