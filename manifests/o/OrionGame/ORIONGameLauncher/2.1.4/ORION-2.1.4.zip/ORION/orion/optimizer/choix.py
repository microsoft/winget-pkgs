"""Le choix des graphismes d'un jeu (2.1.0) : deux cartes.

Demande de l'auteur (9 octobre) :

- « Votre ecran » (conseillee) : l'objectif est la frequence de l'ecran.
  ORION lit les composants et cherche, du plus beau au plus leger (Ultra,
  Haute, Moyenne, Basse, avec DLSS / FSR / XeSS quand ca aide), le premier
  reglage qui tient cet objectif de facon stable ; si meme Basse ne le tient
  pas, il descend par paliers (`recommande.paliers`). Apres une partie
  mesuree, le meme calcul repart des images par seconde reellement vues :
  le reglage se corrige tout seul.
- « Mon choix » : le joueur choisit lui-meme les graphismes (Ultra par
  defaut) ET les images par seconde visees. ORION montre ce que ce reglage
  donne sur ce PC (images par seconde attendues, super-resolution retenue
  pour tenir l'objectif, objectif tenu ou non) et, au clic, l'ecrit avec la
  limite d'images demandee.

Un clic sur une carte ecrit les reglages tout de suite. Le choix est
memorise par jeu : l'objectif dans `game.extra["cible_fps"]` (lu par
`recommande.cible_fps`), le niveau par `recommande.choisir_niveau` ; « Jouer »
refait toujours le meme calcul que la carte.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..core.models import Display, Game, HardwareInfo
from . import recommande as reco_mod

IDS = ("ecran", "choix")
NOMS = {"ecran": "Votre ecran", "choix": "Mon choix"}
EXPLICATIONS = {
    "ecran": "Le plus beau reglage qui tient la frequence de votre ecran",
    "choix": "Les graphismes et les images par seconde que vous choisissez",
}
COULEURS = {"ecran": "#3DDC97", "choix": "#B98CFF"}
CHOIX_DEFAUT = "ecran"
#: niveaux proposes dans « Mon choix », du plus beau au plus leger
NIVEAUX = ("ultra", "haute", "moyenne", "basse")
NIVEAU_DEFAUT = "ultra"
#: objectifs proposes au joueur, du plus haut au plus bas (ceux sous la
#: frequence de l'ecran sont retenus)
OBJECTIFS = (240, 200, 165, 144, 120, 100, 90, 75, 60, 45, 30)


@dataclass
class Choix:
    id: str
    niveau: str
    mode: str = "off"
    famille: str = ""
    fps: tuple[int, int] | None = None
    source: str = "inconnu"
    cible: int = 60                      # objectif d'images par seconde
    palier: int = 0                      # objectif tenu, 0 si meme 30 i/s hors de portee
    atteint: bool = False                # tient l'objectif
    identique: str = ""                  # id du choix auquel il se confond
    notes: list[str] = field(default_factory=list)
    #: case DLSS / FSR / XeSS (10 octobre) : proposee si le jeu et la carte
    #: la permettent ; `variantes` : la carte case cochee (« avec ») et
    #: decochee (« sans »), pour que la carte change tout de suite au clic,
    #: avec le gain d'images par seconde
    sr_dispo: bool = False
    nom_sr: str = ""
    gain: int = 0
    variantes: dict = field(default_factory=dict)

    @property
    def sr(self) -> bool:
        """La super-resolution est-elle utilisee par ce reglage ?"""
        return self.mode != "off" and bool(self.famille)

    @property
    def nom(self) -> str:
        return NOMS[self.id]

    @property
    def titre(self) -> str:
        """« Votre ecran · 165 i/s », « Mon choix · Ultra · 120 i/s »."""
        if self.id == "choix":
            return f"{self.nom} · {self.nom_niveau} · {self.cible} i/s"
        return f"{self.nom} · {self.cible} i/s"

    @property
    def explication(self) -> str:
        return EXPLICATIONS[self.id]

    @property
    def nom_niveau(self) -> str:
        return reco_mod.NOMS_NIVEAUX.get(self.niveau, self.niveau)

    @property
    def texte_mode(self) -> str:
        if self.mode == "off" or not self.famille:
            return ""
        if self.famille == "echelle":
            return f"Rendu {reco_mod.MODES[self.mode][2]} %"
        return f"{reco_mod.NOMS_FAMILLES.get(self.famille, self.famille)} {reco_mod.NOMS_MODES[self.mode]}"

    @property
    def reglage(self) -> str:
        """« Ultra + DLSS Qualite »."""
        return self.nom_niveau + (f" + {self.texte_mode}" if self.texte_mode else "")

    @property
    def fps_court(self) -> str:
        return reco_mod.court_fps(self.fps, self.source) if self.fps else "?"

    @property
    def origine(self) -> str:
        """D'ou vient le chiffre, en quelques mots."""
        return {
            "mesure": "d'apres vos parties mesurees",
            "communaute": "d'apres des joueurs equipes comme vous",
            "estime": "d'apres la configuration recommandee du jeu",
        }.get(self.source, "d'apres la gamme de votre carte, sans mesure")

    @property
    def tenue(self) -> str:
        """« tient 144 i/s », « jusqu'a 90 i/s », « sous 30 i/s »."""
        if not self.fps:
            return "images par seconde non verifiees"
        if self.atteint:
            return f"tient {self.cible} i/s"
        if self.palier:
            return f"jusqu'a {self.palier} i/s"
        return f"sous {reco_mod.PALIERS[-1]} i/s"

    def to_dict(self) -> dict[str, Any]:
        return {"id": self.id, "nom": self.nom, "titre": self.titre, "niveau": self.niveau,
                "mode": self.mode, "famille": self.famille,
                "fps": list(self.fps) if self.fps else None,
                "source": self.source, "cible": self.cible, "palier": self.palier,
                "atteint": self.atteint, "identique": self.identique,
                "reglage": self.reglage, "fps_court": self.fps_court,
                "origine": self.origine, "tenue": self.tenue,
                "sr": self.sr, "sr_dispo": self.sr_dispo, "nom_sr": self.nom_sr,
                "gain": self.gain, "variantes": dict(self.variantes)}


def _palier(fps: tuple[int, int] | None, cible: int, source: str) -> int:
    if not fps:
        return 0
    bas, haut = fps
    mesure = source == "mesure"
    return next((p for p in reco_mod.paliers(cible)
                 if (haut >= p * 0.97 and bas >= p * 0.6 if mesure else bas >= p * 0.92)), 0)


def _depuis_option(id_: str, o: reco_mod.Option, r: reco_mod.Recommandation, famille: str) -> Choix:
    palier = _palier(o.fps, r.cible, r.source)
    return Choix(id=id_, niveau=o.niveau, mode=o.mode, famille=famille if o.mode != "off" else "",
                 fps=o.fps, source=r.source, cible=r.cible, palier=palier,
                 atteint=palier >= r.cible and bool(o.fps), notes=list(r.notes))


def _mesures(game: Game | None, runs: dict | None) -> dict:
    if runs is not None or game is None:
        return runs or {}
    try:
        from ..perf.store import mesures_du_jeu
        return mesures_du_jeu(game.uid) or {}
    except Exception:
        return {}


def _recommandation(game: Game | None, hw: HardwareInfo, display: Display | None,
                    cible: int, capacites: list[str], runs: dict, refresh: int, exig,
                    sr=None):
    # le choix memorise pour ce jeu ne doit pas colorer la carte « Votre
    # ecran » ni l'apercu : on calcule hors de lui (objectif general des
    # reglages, sinon la frequence de l'ecran), sans niveau impose
    neutre = None
    if game is not None:
        neutre = Game(title=game.title, source=game.source, source_id=game.source_id)
        neutre.extra = {k: v for k, v in game.extra.items()
                        if k not in ("cible_fps", "choix_graphismes", "recommande_niveau")}
    return reco_mod.recommander(neutre, hw, display, capacites, runs=runs, exig=exig,
                                refresh=refresh, cible=cible or reco_mod.cible_fps(None, refresh),
                                sr=sr)


def _case(game: Game | None, carte: str, sr):
    return reco_mod.sr_du_jeu(game, carte) if sr == reco_mod.DU_JEU else sr


def _variantes(calcul, sr) -> Choix:
    """Le reglage avec la case telle qu'elle est (`sr`), et ses deux
    variantes, case cochee et decochee, avec le gain d'images par seconde."""
    actuel = calcul(sr)
    avec = calcul(True) if sr is not True else actuel
    sans = calcul(False) if sr is not False else actuel
    actuel.sr_dispo = avec.sr
    if avec.sr:
        actuel.nom_sr = (reco_mod.NOMS_FAMILLES.get(avec.famille, avec.famille.upper())
                         if avec.famille != "echelle" else "Rendu reduit")
        g = reco_mod.valeur_fps(avec.fps, avec.source) - reco_mod.valeur_fps(sans.fps, sans.source) \
            if avec.fps and sans.fps else 0
        actuel.gain = max(0, int(g))
        for v in (avec, sans):
            v.sr_dispo, v.nom_sr, v.gain = True, actuel.nom_sr, actuel.gain
        actuel.variantes = {"avec": avec.to_dict(), "sans": sans.to_dict()}
    return actuel


def pour_cible(game: Game | None, hw: HardwareInfo, display: Display | None,
               cible: int = 0, capacites: list[str] | None = None, runs: dict | None = None,
               refresh: int | None = None, exig=None, sr=reco_mod.DU_JEU) -> Choix:
    """Carte « Votre ecran » : le plus beau reglage qui tient `cible` images
    par seconde (0 : la frequence de l'ecran), avec la case DLSS du joueur."""
    if capacites is None:
        capacites = reco_mod.capacites_connues(game) or []
    runs = _mesures(game, runs)
    refresh = refresh or _refresh(display)
    famille = reco_mod.famille_upscaler(hw, capacites)

    def calcul(case):
        r = _recommandation(game, hw, display, cible, capacites, runs, refresh, exig, case)
        return _depuis_option("ecran", r.options[r.niveau_conseille], r, famille)
    return _variantes(calcul, _case(game, "ecran", sr))


def pour_choix(game: Game | None, hw: HardwareInfo, display: Display | None,
               niveau: str = NIVEAU_DEFAUT, cible: int = 0, capacites: list[str] | None = None,
               runs: dict | None = None, refresh: int | None = None, exig=None,
               sr=reco_mod.DU_JEU) -> Choix:
    """Carte « Mon choix » : ce que donne le niveau choisi par le joueur pour
    `cible` images par seconde (0 : la frequence de l'ecran) : la
    super-resolution qui tient l'objectif si elle existe, sinon la plus
    rapide, et les images par seconde attendues."""
    if niveau not in NIVEAUX:
        niveau = NIVEAU_DEFAUT
    if capacites is None:
        capacites = reco_mod.capacites_connues(game) or []
    runs = _mesures(game, runs)
    refresh = refresh or _refresh(display)
    famille = reco_mod.famille_upscaler(hw, capacites)

    def calcul(case):
        r = _recommandation(game, hw, display, cible, capacites, runs, refresh, exig, case)
        option = r.options.get(niveau) or reco_mod.Option(niveau)
        c = _depuis_option("choix", option, r, famille)
        if option.fps is None:
            c.notes.append("Le jeu ne publie pas de configuration pour ce niveau : "
                           "images par seconde non verifiees avant une partie mesuree.")
        return c
    return _variantes(calcul, _case(game, "choix", sr))


def _refresh(display: Display | None) -> int:
    if display is None:
        return 60
    n = display.native or display.current
    return (display.best_refresh(n.width, n.height) if n else display.max_refresh_at_native) or 60


def objectifs(refresh: int) -> list[int]:
    """Les objectifs proposes dans « Mon choix » pour cet ecran : la
    frequence de l'ecran et les paliers en dessous."""
    refresh = int(refresh or 60)
    return [refresh] + [o for o in OBJECTIFS if o < refresh]


def les_choix(game: Game | None, hw: HardwareInfo, display: Display | None,
              capacites: list[str] | None = None, runs: dict | None = None,
              refresh: int | None = None, exig=None) -> list[Choix]:
    """Les deux cartes : « Votre ecran », puis « Mon choix » (le choix
    memorise pour ce jeu, sinon Ultra a la frequence de l'ecran)."""
    if capacites is None:
        capacites = reco_mod.capacites_connues(game) or []
    runs = _mesures(game, runs)
    refresh = refresh or _refresh(display)
    ecran = pour_cible(game, hw, display, 0, capacites, runs, refresh, exig)
    niveau, cible = choix_memorise(game)
    joueur = pour_choix(game, hw, display, niveau, cible, capacites, runs, refresh, exig)
    if (joueur.niveau, joueur.mode) == (ecran.niveau, ecran.mode) and joueur.cible == ecran.cible:
        joueur.identique = "ecran"
    return [ecran, joueur]


def choix_memorise(game: Game | None) -> tuple[str, int]:
    """(niveau, objectif) de « Mon choix » pour ce jeu ; (Ultra, 0) par defaut."""
    niveau = reco_mod.niveau_choisi(game) if game is not None else ""
    return (niveau if niveau in NIVEAUX else NIVEAU_DEFAUT), cible_du_jeu(game)


def cible_du_jeu(game: Game | None) -> int:
    """L'objectif memorise pour ce jeu (0 : la frequence de l'ecran)."""
    return reco_mod.cible_du_jeu(game)


def choix_du_jeu(game: Game | None) -> str:
    """La carte en place : « choix » des que le joueur a fixe un niveau ou
    un objectif pour ce jeu."""
    if game is None:
        return CHOIX_DEFAUT
    return "choix" if (reco_mod.niveau_choisi(game) or cible_du_jeu(game)) else CHOIX_DEFAUT


def choisir(game: Game, niveau: str = "", cible: int = 0) -> None:
    """Memorise le choix du joueur. « Votre ecran » : niveau vide et objectif
    0 (le moteur refait le calcul automatique a chaque plan). « Mon choix » :
    le niveau est impose et l'objectif relu par le moteur."""
    cible = max(0, int(cible or 0))
    if cible:
        game.extra["cible_fps"] = cible
    else:
        game.extra.pop("cible_fps", None)
    reco_mod.choisir_niveau(game, niveau if niveau in NIVEAUX else "")


def choisir_sr(game: Game, carte: str, coche: bool) -> None:
    """Memorise la case DLSS / FSR / XeSS d'une carte pour ce jeu."""
    if carte in IDS:
        cases = dict(game.extra.get("sr") or {})
        cases[carte] = bool(coche)
        game.extra["sr"] = cases


def oublier(game: Game) -> None:
    """Retour a l'etat d'avant tout choix (bouton « Redefinir par defaut »)."""
    game.extra.pop("cible_fps", None)
    game.extra.pop("choix_graphismes", None)
    game.extra.pop("sr", None)
    reco_mod.choisir_niveau(game, "")
