"""Socle commun des comptes de plateformes (1.8).

Chaque plateforme (Steam, GOG, Xbox...) est une sous-classe de
`Plateforme`. Elle sait :

* construire l'adresse de sa page de connexion officielle et reconnaitre,
  dans l'adresse de retour, ce que la plateforme rend (`adresse_connexion`,
  `retour_connexion`) : la fenetre integree d'ORION s'en sert sans rien
  connaitre de la plateforme ;
* lire le profil, les jeux possedes et les succes, en lecture seule.

Les resultats sont gardes en cache dans la base locale : la page Comptes
et les fiches de jeu s'affichent tout de suite, meme hors ligne, puis
s'actualisent.

`nature` dit au joueur a quoi s'en tenir :
* « officiel » : methode publiee par la plateforme ;
* « tolere »   : methode non officielle, utilisee depuis des annees par des
                 launchers libres (Heroic, Legendary, Playnite), jamais avec
                 un mot de passe ;
* « local »    : rien ne sort du PC, ORION lit ce que le launcher y range.
"""
from __future__ import annotations

import time
from dataclasses import asdict, dataclass, field
from typing import Any

from ..core.logging_setup import get
from . import coffre

log = get("comptes")

NATURES = {
    "officiel": "Officiel",
    "tolere": "Non officiel (tolere)",
    "local": "Local uniquement",
}


class ConnexionRequise(Exception):
    """Le jeton a expire ou a ete retire : il faut se reconnecter."""

    MARQUE = "connexion requise"

    def __str__(self) -> str:
        detail = self.args[0] if self.args else ""
        return f"{self.MARQUE} ({detail})" if detail else self.MARQUE


@dataclass
class Succes:
    id: str
    nom: str
    description: str = ""
    obtenu: bool = False
    date: float = 0.0               # horodatage du deblocage
    rarete: float | None = None     # % des joueurs qui l'ont (None : inconnu)
    icone: str = ""                 # adresse de l'icone (obtenue)
    icone_grise: str = ""
    cache: bool = False             # succes secret, description masquee

    @property
    def rare(self) -> bool:
        return self.rarete is not None and self.rarete < 10.0


@dataclass
class JeuCompte:
    """Un jeu possede sur un compte (installe ou non)."""
    plateforme: str
    id: str
    titre: str
    minutes: int = 0                # temps de jeu total selon la plateforme
    minutes_2sem: int = 0           # deux dernieres semaines (si connu)
    derniere_partie: float = 0.0
    succes_total: int = 0
    succes_obtenus: int = 0
    image: str = ""                 # jaquette/icone fournie par la plateforme

    @property
    def progression(self) -> float | None:
        if not self.succes_total:
            return None
        return self.succes_obtenus / self.succes_total


@dataclass
class Profil:
    plateforme: str
    id: str = ""
    pseudo: str = ""
    avatar: str = ""
    adresse: str = ""               # page de profil publique
    niveau: int | None = None
    xp: int | None = None
    xp_prochain_niveau: int | None = None
    badges: int | None = None
    score: int | None = None        # Gamerscore, points GOG...
    pays: str = ""
    membre_depuis: float = 0.0
    prive: bool = False             # profil prive : donnees limitees
    extra: dict[str, Any] = field(default_factory=dict)
    maj: float = 0.0


class Plateforme:
    #: identifiant court (« steam », « gog »...)
    id: str = ""
    nom: str = ""
    nature: str = "officiel"
    #: une phrase pour le joueur : ce que la connexion apporte
    apport: str = ""
    #: la connexion passe-t-elle par la fenetre integree ?
    connexion_web: bool = True
    #: domaines de connexion ou les cles de securite (passkeys, WebAuthn)
    #: sont masquees a la page : le navigateur integre ne sait pas dialoguer
    #: avec elles, la plateforme propose alors le mot de passe ou un code
    domaines_sans_cle: tuple[str, ...] = ()
    #: conseil affiche en permanence dans la fenetre de connexion (ou « »)
    conseil_connexion: str = ""
    #: explication propre a la plateforme quand Google refuse la connexion
    #: « Se connecter avec Google » dans la fenetre integree (ou « »)
    aide_refus_google: str = ""

    # -- connexion ------------------------------------------------------
    def adresse_connexion(self) -> str:
        raise NotImplementedError

    def etape_apres_connexion(self) -> tuple[str, str] | None:
        """Page a ouvrir dans la meme fenetre apres la connexion (ou None)."""
        return None

    def est_retour(self, adresse: str) -> bool:
        """Vrai si la fenetre vient d'arriver sur l'adresse de retour."""
        raise NotImplementedError

    def retour_connexion(self, adresse: str) -> dict:
        """Transforme l'adresse de retour en secret a garder (jeton...).
        Leve ValueError si la connexion a echoue ou a ete refusee."""
        raise NotImplementedError

    #: augmente a chaque deconnexion : une tache lancee avant ne doit plus
    #: rien ecrire ensuite (voir `_garder`)
    _generation: int = 0

    def connecter(self, adresse_retour: str, **complement) -> Profil:
        """Termine la connexion (reseau : a lancer hors de l'interface).
        `complement` : donnees obtenues dans la meme fenetre (cle Steam).

        Si le profil ne peut pas etre lu, la connexion n'est pas gardee : un
        jeton sans profil laissait la page Comptes sur « Non connecte », sans
        bouton pour l'effacer. L'ancienne connexion (s'il y en avait une) est
        alors remise en place.
        """
        secret = self.retour_connexion(adresse_retour)
        secret.update({k: v for k, v in complement.items() if v})
        precedent = coffre.lire(self.id)
        generation = self._generation
        coffre.enregistrer(self.id, secret)
        try:
            profil = self.profil(forcer=True)
        except Exception:
            if precedent is not None and generation == self._generation:
                coffre.enregistrer(self.id, precedent)
            else:
                coffre.oublier(self.id)
            raise
        log.info("Compte %s connecte : %s", self.id, profil.pseudo or profil.id)
        return profil

    def connecte(self) -> bool:
        return coffre.lire(self.id) is not None

    def deconnecter(self) -> None:
        self._generation += 1
        coffre.oublier(self.id)
        for espace in ("profil", "jeux"):
            _cache(espace).supprimer(self.id)
        log.info("Compte %s deconnecte", self.id)

    def _garder(self, espace: str, valeur: dict, generation: int) -> None:
        """Met en cache ce qu'une tache a lu, sauf si le compte a ete
        deconnecte entre-temps : ses donnees ne doivent pas revenir."""
        if generation != self._generation or not self.connecte():
            raise ConnexionRequise(f"{self.nom} deconnecte")
        _cache(espace).set(self.id, valeur)

    def secret(self) -> dict:
        s = coffre.lire(self.id)
        if s is None:
            raise ConnexionRequise(self.nom)
        return s

    def maj_secret(self, **valeurs) -> None:
        s = self.secret()
        s.update(valeurs)
        coffre.enregistrer(self.id, s)

    # -- donnees (a surcharger) ------------------------------------------
    def _lire_profil(self) -> Profil:
        raise NotImplementedError

    def _lire_jeux(self) -> list[JeuCompte]:
        return []

    def succes(self, jeu_id: str) -> list[Succes]:
        return []

    # -- donnees avec cache ---------------------------------------------
    def profil(self, forcer: bool = False, garder: int = 3600) -> Profil:
        memo = _cache("profil").get(self.id)
        if memo and not forcer and time.time() - memo.get("maj", 0) < garder:
            return Profil(**memo)
        generation = self._generation
        p = self._lire_profil()
        p.maj = time.time()
        self._garder("profil", asdict(p), generation)
        return p

    def profil_garde(self) -> Profil | None:
        memo = _cache("profil").get(self.id)
        return Profil(**memo) if memo else None

    def jeux(self, forcer: bool = False, garder: int = 6 * 3600) -> list[JeuCompte]:
        memo = _cache("jeux").get(self.id)
        if memo and not forcer and time.time() - memo.get("maj", 0) < garder:
            return [JeuCompte(**j) for j in memo["jeux"]]
        generation = self._generation
        liste = self._lire_jeux()
        self._garder("jeux", {"maj": time.time(), "jeux": [asdict(j) for j in liste]},
                     generation)
        return liste

    def jeux_gardes(self) -> list[JeuCompte]:
        memo = _cache("jeux").get(self.id)
        return [JeuCompte(**j) for j in memo["jeux"]] if memo else []


def _cache(espace: str):
    from ..core.base import Table
    return Table(f"comptes_{espace}")


def resume_succes(liste: list[Succes]) -> dict:
    obtenus = [s for s in liste if s.obtenu]
    return {
        "total": len(liste),
        "obtenus": len(obtenus),
        "manquants": len(liste) - len(obtenus),
        "rares_obtenus": sum(1 for s in obtenus if s.rare),
        "pourcentage": round(100 * len(obtenus) / len(liste)) if liste else 0,
    }
