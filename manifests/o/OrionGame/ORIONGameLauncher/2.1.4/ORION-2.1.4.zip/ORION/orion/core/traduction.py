"""Traduction automatique en francais des textes publics (actualites de jeux).

Deux services gratuits, sans cle, essayes dans l'ordre :

1. Google Traduction (point d'acces public « gtx ») : bonne qualite, textes
   longs acceptes par morceaux ;
2. MyMemory : secours, limite a 500 caracteres par appel.

Seuls des textes deja publics (notes de mise a jour publiees par les
studios) sont envoyes. Chaque traduction est gardee en cache sur le disque :
une actualite n'est traduite qu'une fois.

En cas d'echec, le texte d'origine est rendu tel quel : l'affichage ne doit
jamais dependre du service de traduction.
"""
from __future__ import annotations

import hashlib
import re
import threading

from .logging_setup import get
from .paths import CACHE_DIR

log = get("traduction")

CACHE = CACHE_DIR / "traductions.json"
GOOGLE = "https://translate.googleapis.com/translate_a/single"
MYMEMORY = "https://api.mymemory.translated.net/get"
HEADERS = {"User-Agent": "Mozilla/5.0 (ORION-Launcher)"}

#: taille d'un morceau envoye en une fois (l'adresse reste sous 8 Ko)
MORCEAU = 1500

_verrou = threading.Lock()

#: mots tres frequents en francais : sert a ne pas retraduire un texte deja
#: en francais quand le service ne precise pas la langue detectee
_FR = re.compile(r"\b(le|la|les|des|une|est|pour|avec|dans|nous|vous|sur|"
                 r"du|au|aux|et|pas|mise|jour|correctifs?)\b", re.I)


_table = None


def _charger():
    """Cache des traductions : table de la base locale, bornee a 3000."""
    global _table
    if _table is None:
        from .base import Table
        _table = Table("traductions", CACHE, maximum=3000)
    return _table


def _enregistrer(cle: str = "", valeur: str = "") -> None:
    if cle:
        _charger().set(cle, valeur)


_EN = re.compile(r"\b(the|and|of|to|is|was|were|for|with|from|this|that|"
                 r"we|you|our|your|have|has|will|be|are|it|its)\b", re.I)


def semble_anglais_plutot_que_francais(texte: str) -> bool:
    """Vrai si le texte contient nettement plus de mots anglais que francais."""
    return len(_EN.findall(texte or "")) > 1.5 * len(_FR.findall(texte or "")) + 2


def semble_francais(texte: str) -> bool:
    mots = re.findall(r"[a-zA-ZÀ-ÿ']+", texte or "")
    if len(mots) < 4:
        return False
    return len(_FR.findall(texte)) / len(mots) > 0.12


def decouper(texte: str, taille: int = MORCEAU) -> list[str]:
    """Coupe aux paragraphes, puis aux phrases, sans jamais couper un mot.

    Les morceaux, mis bout a bout, redonnent exactement le texte d'origine.
    """
    unites: list[str] = []
    for bloc in re.split(r"(\n+)", texte):
        if len(bloc) <= taille:
            unites.append(bloc)
            continue
        for phrase in re.split(r"(?<=[.!?] )", bloc):
            while len(phrase) > taille:                  # phrase geante
                coupe = phrase.rfind(" ", 0, taille)
                coupe = coupe + 1 if coupe > 0 else taille
                unites.append(phrase[:coupe])
                phrase = phrase[coupe:]
            unites.append(phrase)
    morceaux: list[str] = []
    courant = ""
    for u in unites:
        if courant and len(courant) + len(u) > taille:
            morceaux.append(courant)
            courant = ""
        courant += u
    if courant:
        morceaux.append(courant)
    return morceaux


_google_pause = 0.0


def _google(texte: str, cible: str) -> tuple[str, str]:
    """Google Traduction. Sur un refus (trop de demandes), `reseau` met le
    service en pause 30 minutes : insister prolonge le blocage."""
    from orion.core import reseau
    # texte envoye dans le corps de la requete : dans l'adresse, un texte
    # en cyrillique ou en chinois encode depasse vite la longueur permise
    r = reseau.post(GOOGLE, params={"client": "gtx", "sl": "auto", "tl": cible,
                                    "dt": "t"},
                    data={"q": texte}, headers=HEADERS, timeout=15)
    r.raise_for_status()
    data = r.json()
    trad = "".join(seg[0] for seg in (data[0] or []) if seg and seg[0])
    langue = data[2] if len(data) > 2 and isinstance(data[2], str) else ""
    if not trad:
        raise ValueError("reponse vide")
    return trad, langue


def langue_probable(texte: str) -> str:
    """Langue source approximative, d'apres l'alphabet utilise."""
    if re.search(r"[\u0400-\u04FF]", texte):
        return "ru"
    if re.search(r"[\u3040-\u30FF]", texte):
        return "ja"
    if re.search(r"[\uAC00-\uD7AF]", texte):
        return "ko"
    if re.search(r"[\u4E00-\u9FFF]", texte):
        return "zh-CN"
    return "en"


def _mymemory(texte: str, cible: str) -> tuple[str, str]:
    from orion.core import reseau
    out = []
    source = langue_probable(texte)
    for bout in decouper(texte, 480):
        r = reseau.get(MYMEMORY, params={"q": bout, "langpair": f"{source}|{cible}"},
                         headers=HEADERS, timeout=15)
        d = r.json() or {}
        if int(d.get("responseStatus") or 0) != 200:
            raise ValueError(str(d.get("responseDetails") or "refus"))
        out.append((d.get("responseData") or {}).get("translatedText") or bout)
    return "\n".join(out) if "\n" in texte else " ".join(out), source


def traduire(texte: str, cible: str = "fr") -> str:
    """`texte` en francais. Rend le texte d'origine si rien ne marche."""
    texte = (texte or "").strip()
    if not texte or semble_francais(texte):
        return texte
    cle = hashlib.sha1(f"v2|{cible}|{texte}".encode("utf-8", "ignore")).hexdigest()
    with _verrou:
        deja = _charger().get(cle)
    if deja is not None:
        return deja

    resultat = ""
    for service in (_google, _mymemory):
        try:
            morceaux = []
            for bout in decouper(texte):
                trad, langue = service(bout, cible)
                if langue == cible:          # deja dans la bonne langue
                    trad = bout
                morceaux.append(trad)
            # les morceaux gardent leurs espaces et sauts de ligne d'origine,
            # que le service de traduction a tendance a rogner
            resultat = ""
            for bout, trad in zip(decouper(texte), morceaux):
                if resultat and bout[:1].isspace() is False and not resultat.endswith(("\n", " ")):
                    resultat += " "
                resultat += trad
                if bout.endswith("\n") and not trad.endswith("\n"):
                    resultat += "\n" * (len(bout) - len(bout.rstrip("\n")))
            # une « traduction » qui n'est pas du francais (service qui
            # renvoie de l'anglais) est refusee : ni affichee, ni gardee
            if cible == "fr" and semble_anglais_plutot_que_francais(resultat):
                raise ValueError("resultat qui n'est pas en francais")
            break
        except Exception as exc:
            resultat = ""
            log.info("Traduction via %s impossible : %s", service.__name__, exc)
    if not resultat:
        return texte
    with _verrou:
        _enregistrer(cle, resultat)
    return resultat
