"""Encart « version » en bas a gauche de la barre laterale (1.7.1).

Il affiche la version installee et suit GitHub :

* a jour           -> « ORION 1.7.1 · a jour »          (clic : verifier)
* verification     -> « ORION 1.7.1 · verification... »
* disponible       -> « Nouvelle version 1.7.2 » + « Cliquer pour installer »
* telechargement   -> barre de progression
* installation     -> « Installation : ORION redemarre... »
* erreur           -> « Mise a jour impossible · reessayer »
* inconnu          -> « ORION 1.7.1 » (hors ligne, GitHub injoignable)

Il ne fait rien lui-meme : il emet `clique(etat)` et la fenetre decide
(verifier, installer, reessayer).
"""
from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import QFrame, QLabel, QProgressBar, QVBoxLayout

from ...version import APP_NAME, APP_VERSION

ETATS = ("inconnu", "verification", "a_jour", "disponible",
         "telechargement", "installation", "erreur")


class EncartVersion(QFrame):
    clique = Signal(str)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("EncartVersion")
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.etat = "inconnu"
        self.version_distante = ""

        lay = QVBoxLayout(self)
        lay.setContentsMargins(10, 7, 10, 7)
        lay.setSpacing(3)
        self.ligne1 = QLabel()
        self.ligne1.setObjectName("EncartVersionTitre")
        self.ligne2 = QLabel()
        self.ligne2.setObjectName("EncartVersionInfo")
        self.ligne2.setWordWrap(True)
        self.barre = QProgressBar()
        self.barre.setRange(0, 100)
        self.barre.setTextVisible(False)
        self.barre.setFixedHeight(4)
        for w in (self.ligne1, self.ligne2, self.barre):
            w.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
            lay.addWidget(w)
        self.definir("inconnu")

    # ------------------------------------------------------------------
    def definir(self, etat: str, version: str = "", pourcentage: int = 0,
                message: str = "") -> None:
        if etat not in ETATS:
            etat = "inconnu"
        self.etat = etat
        if version:
            self.version_distante = version
        v = self.version_distante
        installee = f"{APP_NAME} {APP_VERSION}"
        titre, info, bulle = installee, "", ""
        if etat == "verification":
            info = "Recherche de mise a jour..."
            bulle = "ORION interroge la page officielle du projet sur GitHub."
        elif etat == "a_jour":
            info = "A jour"
            bulle = ("Derniere version publiee installee. "
                     "Cliquer pour verifier a nouveau.")
        elif etat == "disponible":
            titre = f"Nouvelle version {v}"
            info = "Cliquer pour installer"
            bulle = (f"Version installee : {APP_VERSION}. Un clic telecharge la "
                     f"version {v}, verifie son empreinte, l'installe puis "
                     "redemarre ORION. Vos donnees sont conservees.")
        elif etat == "telechargement":
            titre = f"Telechargement {v}"
            info = f"{pourcentage} %"
            bulle = "ORION redemarrera tout seul une fois la mise a jour installee."
        elif etat == "installation":
            titre = f"Installation {v}"
            info = "ORION redemarre..."
        elif etat == "erreur":
            titre = "Mise a jour impossible"
            info = "Cliquer pour reessayer"
            bulle = message or "La mise a jour n'a pas pu etre installee."
        else:
            bulle = "Cliquer pour rechercher une mise a jour."
        self.ligne1.setText(titre)
        self.ligne2.setText(info)
        self.ligne2.setVisible(bool(info))
        self.barre.setVisible(etat == "telechargement")
        self.barre.setValue(max(0, min(100, int(pourcentage))))
        self.setToolTip(bulle)
        occupe = etat in ("verification", "telechargement", "installation")
        self.setCursor(Qt.CursorShape.ArrowCursor if occupe
                       else Qt.CursorShape.PointingHandCursor)
        # la feuille de style depend de la propriete « etat »
        self.setProperty("etat", etat)
        self.style().unpolish(self)
        self.style().polish(self)
        for w in (self.ligne1, self.ligne2):
            w.style().unpolish(w)
            w.style().polish(w)

    def mouseReleaseEvent(self, event) -> None:  # noqa: N802 (Qt)
        if (event.button() == Qt.MouseButton.LeftButton
                and self.rect().contains(event.position().toPoint())
                and self.etat not in ("verification", "telechargement", "installation")):
            self.clique.emit(self.etat)
        super().mouseReleaseEvent(event)
