"""Section « Videos » de la fiche d'un jeu : un lecteur, trois sources.

* Gameplay (FR) : video YouTube choisie par le joueur (puis retenue pour le
  jeu), lue avec le lecteur officiel integrable ;
* En direct : lives YouTube dans le lecteur, Twitch dans le navigateur ;
* Bande-annonce : videos officielles de la fiche Steam.

Mise en page : cadre 16:9 aux coins arrondis, centre dans le panneau, puis
sous l'image le titre, la chaine et les liens (« Ouvrir sur YouTube »...).

Rien n'est charge tant que le joueur n'a pas clique : l'affiche est dessinee
par Qt, le moteur web n'est cree qu'a la premiere lecture. La lecture
s'arrete des que la fiche est quittee ou qu'un autre jeu est ouvert, et le
son est coupe par defaut. Sans moteur web (QtWebEngine absent), chaque
bouton ouvre la page correspondante dans le navigateur.

Voir `orion/videos.py` pour les sources et leurs limites.
"""
from __future__ import annotations

from ..minuteur import plus_tard

from pathlib import Path

from PySide6.QtCore import QRectF, QSize, Qt, QUrl, Signal
from PySide6.QtGui import (QBrush, QColor, QFont, QLinearGradient, QPainter,
                           QPainterPath, QPen, QPixmap)
from PySide6.QtWidgets import (QButtonGroup, QFrame, QHBoxLayout, QLabel,
                               QPushButton, QSizePolicy, QStackedWidget,
                               QVBoxLayout, QWidget)

from ... import videos
from ...core.logging_setup import get
from .layouts import clear_layout

log = get("ui.videos")

GAMEPLAY, BANDE, DIRECT = "gameplay", "bande", "direct"
#: delai laisse a la lecture automatique pour afficher sa premiere image (ms)
DELAI_AVANT_AUTO = 700        # ms entre la fiche posee et le depart de la bande-annonce
DELAI_AUTO = 4000
#: attente de la fiche Steam d'un jeu installe hors Steam, avant de montrer
#: le gameplay a la place (ms)
ATTENTE_FICHE = 8000

# la bande-annonce en tete : c'est elle qui s'ouvre et se lance d'elle-meme
ONGLETS = ((BANDE, "Bande-annonce"), (GAMEPLAY, "Gameplay (FR)"), (DIRECT, "En direct"))
HAUTEUR_MAX = 500           # hauteur maximale de l'image (16:9 : 889 de large)
HAUTEUR_MIN = 200

try:
    from PySide6.QtWebEngineCore import (QWebEnginePage, QWebEngineProfile,
                                         QWebEngineSettings)
    from PySide6.QtWebEngineWidgets import QWebEngineView
    WEB = True
except Exception:                                   # module absent
    WEB = False


def web_disponible() -> bool:
    """Lecteur integre utilisable : QtWebEngine present et un vrai ecran
    (les tests et les captures tournent sans affichage : « offscreen »)."""
    if not WEB:
        return False
    from PySide6.QtGui import QGuiApplication
    return QGuiApplication.platformName() not in ("offscreen", "minimal")


def ouvrir_externe(url: str) -> None:
    if not url:
        return
    try:
        from ...affiliation import ouvrir
        ouvrir(url, "video")
    except Exception:
        from PySide6.QtGui import QDesktopServices
        QDesktopServices.openUrl(QUrl(url))


# --------------------------------------------------------------------------
# Moteur web (cree a la demande)
# --------------------------------------------------------------------------
_PROFIL = None


def _profil():
    """Profil web dedie aux videos, garde sur le disque : le choix fait une
    fois sur la page de consentement de YouTube n'est pas redemande."""
    global _PROFIL
    if _PROFIL is None:
        from PySide6.QtWidgets import QApplication
        from ...core.paths import CACHE_DIR
        _PROFIL = QWebEngineProfile("orion-videos", QApplication.instance())
        dossier = CACHE_DIR / "web-videos"
        premiere_fois = not (dossier / "stockage").exists()
        _PROFIL.setPersistentStoragePath(str(dossier / "stockage"))
        _PROFIL.setCachePath(str(dossier / "cache"))
        _PROFIL.setHttpCacheMaximumSize(64 * 1024 * 1024)
        # agent de navigateur standard (sans la mention « QtWebEngine »)
        agent = _PROFIL.httpUserAgent()
        import re
        _PROFIL.setHttpUserAgent(re.sub(r"QtWebEngine/\S+\s*", "", agent))
        _PROFIL.setHttpAcceptLanguage("fr-FR,fr;q=0.9,en;q=0.6")
        if premiere_fois:
            _refuser_cookies_youtube(_PROFIL)
    return _PROFIL


def _refuser_cookies_youtube(profil) -> None:
    """Premiere utilisation : repond « Tout refuser » a la page de consentement
    de YouTube (cookies non essentiels refuses), au lieu de l'afficher dans le
    petit cadre du lecteur. Le joueur peut changer ce choix sur YouTube."""
    try:
        from PySide6.QtCore import QDateTime, QUrl
        from PySide6.QtNetwork import QNetworkCookie
        cookie = QNetworkCookie(b"SOCS", b"CAESEwgDEgk0ODE3Nzk3MjQaAmVuIAEaBgiA_LyaBg")
        cookie.setDomain(".youtube.com")
        cookie.setPath("/")
        cookie.setSecure(True)
        cookie.setExpirationDate(QDateTime.currentDateTime().addYears(1))
        profil.cookieStore().setCookie(cookie, QUrl("https://www.youtube.com/"))
    except Exception:                       # pragma: no cover - moteur absent
        pass


if WEB:
    class _PageExterne(QWebEnginePage):
        """Fenetre demandee par la page (logo YouTube...) : ouverte dans le
        navigateur du systeme, jamais dans ORION."""

        def acceptNavigationRequest(self, url, _type, _principal) -> bool:  # noqa: N802
            ouvrir_externe(url.toString())
            plus_tard(self, 0, self.deleteLater)
            return False

    class _PageVideo(QWebEnginePage):
        video_choisie = Signal(str)

        def __init__(self, profil, parent=None) -> None:
            super().__init__(profil, parent)
            self.intercepter = False
            self.urlChanged.connect(self._adresse)

        def _adresse(self, url) -> None:
            # YouTube change d'adresse sans recharger la page (clic sur un
            # resultat) : c'est ici qu'on voit la video choisie
            self._choisie(url.toString())

        def _choisie(self, adresse: str) -> bool:
            if not self.intercepter:
                return False
            video = videos.id_youtube(adresse)
            if not video:
                return False
            self.intercepter = False
            plus_tard(self, 0, lambda: self.video_choisie.emit(video))
            return True

        def acceptNavigationRequest(self, url, type_, principal) -> bool:  # noqa: N802
            if principal and self._choisie(url.toString()):
                return False
            return super().acceptNavigationRequest(url, type_, principal)

        def createWindow(self, _type):              # noqa: N802
            return _PageExterne(self.profile(), self)


# --------------------------------------------------------------------------
# Affiche (dessinee par Qt : aucun cout tant qu'on ne lit rien)
# --------------------------------------------------------------------------
class Affiche(QWidget):
    clique = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMinimumSize(320, 180)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self._pix = QPixmap()
        self.titre = ""
        self.sous_titre = ""
        self.etiquette = ""           # « BANDE-ANNONCE », « EN DIRECT »...
        self.direct = False
        self.bouton = True
        self._survol = False
        self.setMouseTracking(True)

    def definir(self, pix: QPixmap | None, titre: str, sous_titre: str = "",
                etiquette: str = "", direct: bool = False, bouton: bool = True) -> None:
        self._pix = pix if pix is not None and not pix.isNull() else QPixmap()
        self.titre, self.sous_titre = titre, sous_titre
        self.etiquette, self.direct, self.bouton = etiquette, direct, bouton
        self.setToolTip(titre)
        self.update()

    def enterEvent(self, event) -> None:            # noqa: N802
        self._survol = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:            # noqa: N802
        self._survol = False
        self.update()
        super().leaveEvent(event)

    def mousePressEvent(self, event) -> None:       # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton:
            self.clique.emit()
        super().mousePressEvent(event)

    def paintEvent(self, _event) -> None:           # noqa: N802
        from ..theme import PALETTE, accent
        w, h = self.width(), self.height()
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        cadre = QPainterPath()
        cadre.addRoundedRect(QRectF(0, 0, w, h), 12, 12)
        p.setClipPath(cadre)
        p.fillRect(self.rect(), QColor("#05070B"))
        if not self._pix.isNull():
            image = self._pix.scaled(QSize(w, h), Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                                     Qt.TransformationMode.SmoothTransformation)
            p.drawPixmap((w - image.width()) // 2, (h - image.height()) // 2, image)
        else:
            fond = QLinearGradient(0, 0, w, h)
            fond.setColorAt(0, QColor(PALETTE["surface_hi"]))
            fond.setColorAt(1, QColor("#05070B"))
            p.fillRect(self.rect(), QBrush(fond))
        # voile : lisibilite du texte en bas, image intacte en haut
        voile = QLinearGradient(0, 0, 0, h)
        voile.setColorAt(0.0, QColor(5, 7, 11, 70))
        voile.setColorAt(0.5, QColor(5, 7, 11, 120 if self._survol else 150))
        voile.setColorAt(1.0, QColor(5, 7, 11, 225))
        p.fillRect(self.rect(), QBrush(voile))

        couleur = QColor(accent())
        if self.etiquette:
            f = QFont(self.font())
            f.setPixelSize(11)
            f.setBold(True)
            f.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 1.5)
            p.setFont(f)
            largeur = p.fontMetrics().horizontalAdvance(self.etiquette) + 22 + (12 if self.direct else 0)
            zone = QRectF(16, 16, largeur, 24)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(PALETTE["danger"]) if self.direct else QColor(5, 7, 11, 200))
            p.drawRoundedRect(zone, 12, 12)
            x = zone.left() + 11
            if self.direct:
                p.setBrush(QColor("white"))
                p.drawEllipse(QRectF(x, zone.center().y() - 4, 8, 8))
                x += 13
            p.setPen(QColor("white") if self.direct else QColor(PALETTE["text_dim"]))
            p.drawText(QRectF(x, zone.top(), largeur, zone.height()),
                       Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft, self.etiquette)

        if self.bouton:
            r = 34 if self._survol else 31
            centre = QRectF(w / 2 - r, h / 2 - r - 10, 2 * r, 2 * r)
            p.setPen(QPen(QColor(255, 255, 255, 70), 1.5))
            p.setBrush(QColor(couleur.red(), couleur.green(), couleur.blue(),
                              250 if self._survol else 225))
            p.drawEllipse(centre)
            triangle = QPainterPath()
            cx, cy = centre.center().x() + 3, centre.center().y()
            triangle.moveTo(cx - 9, cy - 12)
            triangle.lineTo(cx + 12, cy)
            triangle.lineTo(cx - 9, cy + 12)
            triangle.closeSubpath()
            p.fillPath(triangle, QColor("#04121A"))

        # legende centree sous le bouton : ce que fait le clic
        marge = 24
        y = h / 2 + (28 if self.bouton else -18)
        if self.titre:
            f = QFont(self.font())
            f.setPixelSize(20 if w > 560 else 16)
            f.setBold(True)
            p.setFont(f)
            p.setPen(QColor(PALETTE["text"]))
            hl = p.fontMetrics().height()
            titre = p.fontMetrics().elidedText(self.titre, Qt.TextElideMode.ElideRight,
                                               w - 2 * marge)
            p.drawText(QRectF(marge, y, w - 2 * marge, hl), Qt.AlignmentFlag.AlignCenter, titre)
            y += hl + 4
        if self.sous_titre:
            fs = QFont(self.font())
            fs.setPixelSize(13)
            p.setFont(fs)
            p.setPen(QColor(PALETTE["text_dim"]))
            hl = p.fontMetrics().height()
            texte = p.fontMetrics().elidedText(self.sous_titre, Qt.TextElideMode.ElideRight,
                                               w - 2 * marge)
            p.drawText(QRectF(marge, y, w - 2 * marge, hl), Qt.AlignmentFlag.AlignCenter, texte)
        p.setClipping(False)
        p.setPen(QPen(QColor(255, 255, 255, 22), 1))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRoundedRect(QRectF(0.5, 0.5, w - 1, h - 1), 12, 12)
        p.end()


# --------------------------------------------------------------------------
def _lien(texte: str, rappel) -> QPushButton:
    """Bouton presente comme un lien (« Ouvrir sur YouTube »...)."""
    from ..theme import accent
    b = QPushButton(texte)
    b.setObjectName("LienVideo")
    b.setCursor(Qt.CursorShape.PointingHandCursor)
    b.setStyleSheet(
        "QPushButton#LienVideo{background:transparent;border:none;padding:4px 2px;"
        f"color:{accent()};font-weight:600;font-size:13px;}}"
        "QPushButton#LienVideo:hover{text-decoration:underline;}")
    b.clicked.connect(lambda _=False: rappel())
    return b


class LecteurVideo(QFrame):
    """Panneau « Videos » : onglets, image 16:9 centree, titre et liens dessous."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("Panel")
        self.game = None
        self.appid = ""
        self.onglet = GAMEPLAY
        self._onglet_choisi = False        # le joueur a change d'onglet lui-meme
        self.films: list[videos.BandeAnnonce] = []
        self._film = 0
        self._films_pour = None            # appid dont les films sont charges / demandes
        self._films_charges = False
        self._auto_fait = False
        self._attente_fiche = False
        self._miniatures: dict[str, str] = {}
        self._retenue: dict = {}
        self._actif = False
        self.vue = None                    # QWebEngineView, creee a la demande
        self.lecture = False               # une video est affichee dans la vue
        self._plein = None                 # fenetre plein ecran

        lay = QVBoxLayout(self)
        lay.setContentsMargins(18, 16, 18, 18)
        lay.setSpacing(14)

        tete = QHBoxLayout()
        tete.setSpacing(12)
        titre = QLabel("Videos")
        titre.setObjectName("PanelTitle")
        tete.addWidget(titre)
        segments = QFrame()
        segments.setObjectName("Segments")
        sl = QHBoxLayout(segments)
        sl.setContentsMargins(3, 3, 3, 3)
        sl.setSpacing(2)
        self.groupe = QButtonGroup(self)
        self.boutons: dict[str, QPushButton] = {}
        for cle, texte in ONGLETS:
            b = QPushButton(texte)
            b.setObjectName("Segment")
            b.setCheckable(True)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.clicked.connect(lambda _=False, c=cle: self.choisir_onglet(c, par_joueur=True))
            self.groupe.addButton(b)
            sl.addWidget(b)
            self.boutons[cle] = b
        tete.addWidget(segments)
        tete.addStretch(1)
        self.etat = QLabel("")
        self.etat.setObjectName("Faint")
        tete.addWidget(self.etat)
        self.b_stop = QPushButton("Arreter")
        self.b_stop.setObjectName("Ghost")
        self.b_stop.setToolTip("Arrete la lecture et revient a l'affiche")
        self.b_stop.clicked.connect(self.arreter)
        self.b_stop.hide()
        tete.addWidget(self.b_stop)
        lay.addLayout(tete)

        # colonne centree, de la largeur de l'image
        self.colonne = QWidget()
        self.colonne.setObjectName("Transparent")
        col = QVBoxLayout(self.colonne)
        col.setContentsMargins(0, 0, 0, 0)
        col.setSpacing(10)
        self.ecran = QStackedWidget()
        self.affiche = Affiche()
        self.affiche.clique.connect(self._lancer)
        self.ecran.addWidget(self.affiche)
        self.support = QFrame()                 # accueille la vue web
        self.support.setObjectName("SupportVideo")
        self.support.setStyleSheet("QFrame#SupportVideo{background:#05070B; border-radius:12px;}")
        self._support_lay = QVBoxLayout(self.support)
        self._support_lay.setContentsMargins(0, 0, 0, 0)
        self.ecran.addWidget(self.support)
        col.addWidget(self.ecran)

        dessous = QHBoxLayout()
        dessous.setSpacing(16)
        textes = QVBoxLayout()
        textes.setSpacing(3)
        self.c_titre = QLabel("")
        self.c_titre.setObjectName("Value")
        self.c_titre.setStyleSheet("font-size:16px;")
        self.c_titre.setWordWrap(True)
        textes.addWidget(self.c_titre)
        self.c_source = QLabel("")
        self.c_source.setObjectName("Dim")
        self.c_source.setWordWrap(True)
        textes.addWidget(self.c_source)
        self.c_texte = QLabel("")
        self.c_texte.setObjectName("Faint")
        self.c_texte.setWordWrap(True)
        textes.addWidget(self.c_texte)
        dessous.addLayout(textes, 1)
        self.actions = QHBoxLayout()
        self.actions.setSpacing(12)
        dessous.addLayout(self.actions)
        dessous.setAlignment(self.actions, Qt.AlignmentFlag.AlignTop)
        col.addLayout(dessous)

        self.liste = QHBoxLayout()               # autres bandes-annonces
        self.liste.setSpacing(6)
        col.addLayout(self.liste)
        self.c_note = QLabel("")
        self.c_note.setObjectName("Faint")
        self.c_note.setWordWrap(True)
        col.addWidget(self.c_note)

        # la colonne prend toute la place jusqu'a sa largeur maximale (16:9),
        # sans jamais empecher le panneau de retrecir
        self.colonne.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        self.ecran.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        centre = QHBoxLayout()
        centre.addStretch(1)
        centre.addWidget(self.colonne, 1000)
        centre.addStretch(1)
        lay.addLayout(centre)
        self._ajuster_hauteur()

    # ------------------------------------------------------------------
    # Jeu affiche
    # ------------------------------------------------------------------
    def definir_jeu(self, game, appid: str = "", en_recherche: bool = False) -> None:
        """Nouveau jeu : lecture arretee, rien du jeu precedent ne reste."""
        self.arreter()
        self.game = game
        self.appid = str(appid or "")
        self.films = []
        self._film = 0
        self._films_pour = None
        self._films_charges = False
        self._onglet_choisi = False
        self._actif = False
        self._auto_fait = False            # la lecture automatique n'a lieu qu'une fois
        # jeu reserve aux adultes : pas de lecteur du tout (ni bande-annonce,
        # ni gameplay, ni direct)
        from ... import contenu_adulte
        if game is not None and contenu_adulte.jeu_adulte(game, self.appid):
            self.game = None
            self.setVisible(False)
            return
        self.setVisible(True)
        self._retenue = videos.video_retenue(game.uid) if game is not None else {}
        # Bande-annonce d'abord. Sans fiche Steam il n'y en a pas : gameplay.
        # `en_recherche` : jeu installe hors Steam dont la fiche Steam est en
        # cours de recherche ; on patiente quelques secondes sur l'onglet
        # Bande-annonce plutot que de montrer le gameplay puis de changer.
        self._attente_fiche = bool(en_recherche and not self.appid)
        self.choisir_onglet(BANDE if (self.appid or self._attente_fiche) else GAMEPLAY)
        if self._attente_fiche:
            plus_tard(self, ATTENTE_FICHE, lambda g=game: self._fiche_trop_longue(g))

    def _fiche_trop_longue(self, game) -> None:
        """La fiche Steam n'est pas arrivee a temps : gameplay. Si elle
        arrive plus tard, la bande-annonce sera dans son onglet."""
        if self.game is game and getattr(self, "_attente_fiche", False):
            self.definir_appid("", cherche=True)

    def definir_appid(self, appid: str, cherche: bool = True) -> None:
        """Identifiant Steam retrouve apres coup (jeu installe hors Steam).
        `cherche` : la recherche est terminee (un identifiant vide veut alors
        dire « ce jeu n'est pas sur Steam »)."""
        appid = str(appid or "")
        from ... import contenu_adulte
        if appid and contenu_adulte.est_marque(appid):
            # la fiche Steam vient de reveler un jeu reserve aux adultes
            self.arreter()
            self.game = None
            self.setVisible(False)
            return
        attente = getattr(self, "_attente_fiche", False)
        if not appid:
            if attente and cherche:
                # recherche finie sans resultat : le gameplay prend la place
                self._attente_fiche = False
                if self.onglet == BANDE and not self._onglet_choisi and not self.lecture:
                    self.onglet = GAMEPLAY
                    self.boutons[GAMEPLAY].setChecked(True)
                if not self.lecture:
                    self._rendre()
            return
        if appid == self.appid:
            return
        self._attente_fiche = False
        self.appid = appid
        self._films_pour = None
        self._films_charges = False
        # la fiche Steam arrive apres coup : on ne change d'onglet que si la
        # section n'a pas encore ete montree (sinon l'ecran sauterait du
        # gameplay a la bande-annonce sous les yeux du joueur)
        if (not self._onglet_choisi and not self.lecture and not self._actif
                and self.onglet != BANDE):
            self.onglet = BANDE
            self.boutons[BANDE].setChecked(True)
        if self._actif:
            self._charger_films()
        if not self.lecture:
            self._rendre()

    def activer(self) -> None:
        """La section est visible a l'ecran : on peut chercher les films."""
        if self._actif or self.game is None:
            return
        self._actif = True
        self._charger_films()
        if not self.lecture:
            self._rendre()             # miniature de la video retenue, etc.
        self._lecture_auto_bientot()

    def _lecture_auto_bientot(self) -> None:
        """La lecture automatique attend que la fiche soit posee et lue : le
        `setHtml` du navigateur fige la fenetre 0,4 a 0,7 s (15 octobre,
        enregistrement de l'auteur), autant que ce ne soit pas pendant que
        la fiche se construit sous les yeux du joueur."""
        plus_tard(self, DELAI_AVANT_AUTO, self._lecture_auto)

    def _lecture_auto(self) -> None:
        """La bande-annonce demarre seule, son coupe, des que la section est
        a l'ecran et que les films sont connus. Une seule fois par fiche : si
        le joueur l'arrete, elle ne repart pas. Reglable (`videos.lecture_auto`)."""
        from ...core.config import CONFIG
        if (getattr(self, "_auto_fait", True) or not self._actif or self.lecture
                or self.onglet != BANDE or not self._films_charges or not self.films
                or not web_disponible() or not CONFIG.get("videos.lecture_auto", True)):
            return
        # la premiere bande-annonce lisible ici (certaines n'existent qu'en H.264)
        lisibles = [i for i, f in enumerate(self.films) if f.lisible]
        if not lisibles:
            return
        self._auto_fait = True
        if not self.films[min(self._film, len(self.films) - 1)].lisible:
            self._film = lisibles[0]
            self._rendre()
        # Lecture discrete : l'affiche reste a l'ecran pendant que la video se
        # charge derriere ; le lecteur ne prend sa place qu'a la premiere image.
        # Si la lecture echoue, l'affiche reste : jamais d'ecran noir.
        film = self.films[self._film]
        vue = self._vue()
        vue.page().intercepter = False
        self._attente_auto = True
        vue.setHtml(videos.html_bande_annonce(film), QUrl(videos.ORIGINE))
        plus_tard(self, DELAI_AUTO, self._auto_trop_long)

    def _signal_page(self, titre: str) -> None:
        """La page du lecteur signale par son titre que l'image arrive, ou
        que la lecture a echoue."""
        if titre == "ORION-FIN":
            # bande-annonce terminee : retour a l'affiche du jeu plutot
            # qu'une derniere image noire
            if self.onglet == BANDE:
                self.arreter()
            return
        if not getattr(self, "_attente_auto", False):
            if titre == "ORION-ECHEC" and self.lecture and self.onglet == BANDE \
                    and getattr(self, "_lecture_discrete", False):
                self.arreter()                 # echec apres coup : retour a l'affiche
            return
        if titre == "ORION-LECTURE":
            self._attente_auto = False
            self._lecture_discrete = True
            if self.onglet == BANDE and not self.lecture:
                self._montrer_vue("Lecture  ·  Steam  ·  son coupe")
        elif titre == "ORION-ECHEC":
            self._attente_auto = False
            self._vider_vue()

    def _auto_trop_long(self) -> None:
        """Aucun signal apres quelques secondes (reseau lent, ou page qui ne
        previent pas) : on montre le lecteur tel quel. Son affiche d'attente
        est la miniature de la video, donc pas d'ecran noir."""
        if getattr(self, "_attente_auto", False):
            self._attente_auto = False
            self._lecture_discrete = True
            if self.onglet == BANDE and not self.lecture and self.game is not None:
                self._montrer_vue("Lecture  ·  Steam  ·  son coupe")

    def _vider_vue(self) -> None:
        if self.vue is not None and not self.lecture:
            self.vue.stop()
            self.vue.setHtml("<html><body style='background:#05070B'></body></html>",
                             QUrl(videos.ORIGINE))

    # ------------------------------------------------------------------
    def choisir_onglet(self, cle: str, par_joueur: bool = False) -> None:
        if cle not in self.boutons:
            return
        if par_joueur:
            self._onglet_choisi = True
            self.activer()
        if self.lecture:
            self.arreter()
        self.onglet = cle
        self.boutons[cle].setChecked(True)
        self._rendre()

    def _rendre(self) -> None:
        """Affiche, textes et liens pour l'onglet courant."""
        if self.game is None:
            return
        clear_layout(self.liste)
        clear_layout(self.actions)
        self.c_note.setText("")
        titre_jeu = self.game.title
        fond = self._fond_jeu()
        web = web_disponible()
        if self.onglet == GAMEPLAY:
            r = self._retenue
            if r:
                pix = self._pixmap(self._miniatures.get("yt:" + r["id"], "")) or fond
                self.affiche.definir(pix, "Lire la video" if web else "Regarder sur YouTube",
                                     "Lecture integree, avec le son" if web else
                                     "S'ouvre dans votre navigateur", "GAMEPLAY FR")
                self.c_titre.setText(r.get("titre") or f"{titre_jeu} : gameplay en francais")
                self.c_source.setText((r.get("chaine") or "YouTube")
                                      + "  ·  video retenue pour ce jeu")
                self.c_texte.setText("")
                self._lien("Choisir une autre video", self._chercher)
                self._lien("Ouvrir sur YouTube",
                           lambda: ouvrir_externe(videos.url_youtube(r["id"])))
                if self._actif:
                    self._miniature_youtube(r)
            else:
                self.affiche.definir(fond, "Choisir une video de gameplay",
                                     "Resultats YouTube en francais, affiches ici" if web
                                     else "Resultats YouTube dans votre navigateur",
                                     "GAMEPLAY FR")
                self.c_titre.setText(f"{titre_jeu} : gameplay en francais")
                self.c_source.setText("YouTube  ·  « " + videos.requete_gameplay(titre_jeu) + " »")
                self.c_texte.setText(
                    "Choisissez une video dans les resultats : elle est lue dans ce lecteur "
                    "et proposee directement la prochaine fois." if web else
                    "Le lecteur integre n'est pas disponible : la recherche s'ouvre "
                    "dans votre navigateur.")
                self._lien("Ouvrir sur YouTube",
                           lambda: ouvrir_externe(videos.recherche_youtube(titre_jeu)))
        elif self.onglet == BANDE:
            self._rendre_bandes(fond)
        else:
            self.affiche.definir(fond, "Voir les lives en cours",
                                 "Lives YouTube affiches ici" if web
                                 else "Lives YouTube dans votre navigateur",
                                 "EN DIRECT", direct=True)
            self.c_titre.setText(f"{titre_jeu} en direct")
            self.c_source.setText("YouTube Live  ·  Twitch")
            self.c_texte.setText(
                "Choisissez un live dans les resultats YouTube pour le regarder ici. "
                "Le lecteur Twitch utilise un format video que le lecteur integre ne "
                "sait pas lire : Twitch s'ouvre dans votre navigateur." if web else
                "Le lecteur integre n'est pas disponible : les lives s'ouvrent dans "
                "votre navigateur.")
            self._lien("Voir sur Twitch",
                       lambda: ouvrir_externe(videos.recherche_twitch(titre_jeu)))
            self._lien("Ouvrir sur YouTube",
                       lambda: ouvrir_externe(videos.recherche_youtube(titre_jeu, direct=True)))
        self.ecran.setCurrentWidget(self.support if self.lecture else self.affiche)
        self.b_stop.setVisible(self.lecture)
        self.c_note.setVisible(bool(self.c_note.text()))
        self.c_texte.setVisible(bool(self.c_texte.text()))

    def _rendre_bandes(self, fond: QPixmap) -> None:
        titre_jeu = self.game.title
        if not self.appid and getattr(self, "_attente_fiche", False):
            self.affiche.definir(fond, "Bande-annonce", "Recherche de la bande-annonce...",
                                 "BANDE-ANNONCE", bouton=False)
            self.c_titre.setText("Bande-annonce")
            self.c_source.setText("Recherche de la fiche du jeu...")
            self.c_texte.setText("")
            return
        if not self.appid:
            self.affiche.definir(fond, "Bandes-annonces sur YouTube",
                                 "Jeu absent du magasin Steam", "BANDE-ANNONCE")
            self.c_titre.setText("Bande-annonce")
            self.c_source.setText("Jeu absent du magasin Steam")
            self.c_texte.setText("Les bandes-annonces officielles viennent de la fiche Steam "
                                 "du jeu.")
            self._lien("Ouvrir sur YouTube",
                       lambda: ouvrir_externe(videos.recherche_bande_annonce(titre_jeu)))
            return
        if not self._films_charges:
            self.affiche.definir(fond, "Bandes-annonces officielles",
                                 "Recherche sur la fiche Steam..." if self._actif else "",
                                 "BANDE-ANNONCE", bouton=False)
            self.c_titre.setText("Bande-annonce")
            self.c_source.setText("Steam  ·  videos officielles")
            self.c_texte.setText("")
            self._lien("Ouvrir la fiche Steam", lambda: ouvrir_externe(
                videos.STEAM_APP.format(appid=self.appid)))
            return
        if not self.films:
            self.affiche.definir(fond, "Bandes-annonces sur YouTube",
                                 "Aucune video officielle sur Steam", "BANDE-ANNONCE")
            self.c_titre.setText("Bande-annonce")
            self.c_source.setText("Steam  ·  aucune video officielle")
            self.c_texte.setText("L'editeur n'a publie aucune video sur la fiche Steam.")
            self._lien("Ouvrir sur YouTube",
                       lambda: ouvrir_externe(videos.recherche_bande_annonce(titre_jeu)))
            return
        film = self.films[min(self._film, len(self.films) - 1)]
        pix = self._pixmap(self._miniatures.get(film.id, "")) or fond
        lisible = film.lisible and web_disponible()
        self.affiche.definir(pix, "Lire la bande-annonce" if lisible else "Regarder sur Steam",
                             "Son coupe dans ORION" if lisible
                             else "S'ouvre dans votre navigateur", "BANDE-ANNONCE")
        self.c_titre.setText(film.nom)
        self.c_source.setText(f"Steam  ·  {len(self.films)} video(s) officielle(s)")
        self.c_texte.setText("")
        if len(self.films) > 1:
            for i, f in enumerate(self.films[:6]):
                b = QPushButton(f.nom)
                b.setObjectName("Chip")
                b.setCheckable(True)
                b.setChecked(i == self._film)
                b.setToolTip(f.nom)
                b.setMaximumWidth(220)
                b.setCursor(Qt.CursorShape.PointingHandCursor)
                b.clicked.connect(lambda _=False, n=i: self._choisir_film(n))
                self.liste.addWidget(b)
            self.liste.addStretch(1)
        self._lien("Ouvrir sur Steam (avec le son)", lambda: ouvrir_externe(film.page))
        if lisible:
            self.c_note.setText("Le lecteur integre lit l'image des bandes-annonces Steam ; "
                                "leur son (format AAC) n'y est pas pris en charge.")

    def _lien(self, texte: str, rappel) -> QPushButton:
        b = _lien(texte, rappel)
        self.actions.addWidget(b)
        return b

    # ------------------------------------------------------------------
    def url_externe(self) -> str:
        """Ce qu'ouvre un clic sur l'affiche sans lecteur integre."""
        if self.game is None:
            return ""
        titre = self.game.title
        if self.onglet == GAMEPLAY:
            if self._retenue:
                return videos.url_youtube(self._retenue["id"])
            return videos.recherche_youtube(titre)
        if self.onglet == BANDE:
            if self.films:
                return self.films[min(self._film, len(self.films) - 1)].page
            return (videos.STEAM_APP.format(appid=self.appid) if self.appid
                    else videos.recherche_bande_annonce(titre))
        return videos.recherche_youtube(titre, direct=True)

    def _lancer(self) -> None:
        """Clic sur l'affiche."""
        if self.game is None:
            return
        if not web_disponible():
            ouvrir_externe(self.url_externe())
            return
        if self.onglet == GAMEPLAY:
            if self._retenue:
                # lecture demandee d'un clic : avec le son
                self._jouer_html(videos.html_youtube(self._retenue["id"], muet=False),
                                 "YouTube", son=True)
            else:
                self._chercher()
        elif self.onglet == BANDE:
            if not self.films:
                if self._films_charges or not self.appid:
                    ouvrir_externe(self.url_externe())
                return
            film = self.films[min(self._film, len(self.films) - 1)]
            if not film.lisible:
                ouvrir_externe(film.page)
                return
            self._jouer_html(videos.html_bande_annonce(film), "Steam")
        else:
            self._chercher(direct=True)

    def _chercher(self, direct: bool = False) -> None:
        """Resultats YouTube dans le lecteur : le joueur choisit la video."""
        if self.game is None:
            return
        if not web_disponible():
            ouvrir_externe(videos.recherche_youtube(self.game.title, direct=direct))
            return
        vue = self._vue()
        vue.page().intercepter = True
        vue.setUrl(QUrl(videos.recherche_youtube(self.game.title, direct=direct, mobile=True)))
        self._montrer_vue("Choisissez une video dans les resultats YouTube")

    def _video_choisie(self, video: str) -> None:
        if self.game is None:
            return
        if self.onglet == GAMEPLAY:
            self._retenue = {"id": video, "titre": "", "chaine": ""}
            videos.retenir_video(self.game.uid, video)
            self._infos_youtube(self.game.uid, video)
        self._jouer_html(videos.html_youtube(video, muet=False), "YouTube", son=True)
        self._rendre()

    def _jouer_html(self, page: str, source: str, son: bool = False) -> None:
        vue = self._vue()
        vue.page().intercepter = False
        vue.setHtml(page, QUrl(videos.ORIGINE))
        self._montrer_vue(f"Lecture  ·  {source}" + ("" if son else "  ·  son coupe"))

    def _montrer_vue(self, etat: str) -> None:
        self._attente_auto = False
        self.lecture = True
        self.ecran.setCurrentWidget(self.support)
        self.b_stop.show()
        self.etat.setText(etat)

    def arreter(self) -> None:
        """Arrete toute lecture (fiche quittee, autre jeu, autre onglet)."""
        self._attente_auto = False
        self._lecture_discrete = False
        self._sortir_plein_ecran()
        if self.vue is not None:
            self.vue.page().intercepter = False
            self.vue.stop()
            self.vue.setHtml("<html><body style='background:#05070B'></body></html>",
                             QUrl(videos.ORIGINE))
        self.lecture = False
        self.ecran.setCurrentWidget(self.affiche)
        self.b_stop.hide()
        self.etat.setText("")

    # ------------------------------------------------------------------
    def prechauffer(self) -> None:
        """Cree la vue web pendant un temps mort du demarrage : le premier
        `setHtml` d'une bande-annonce ne paie plus le lancement du processus
        du navigateur (0,7 a 1,0 s de fenetre figee, constat du 7 octobre)."""
        if self.vue is not None or not WEB or not web_disponible():
            return
        try:
            vue = self._vue()
            vue.setHtml("<html><body style='background:#05070B'></body></html>",
                        QUrl(videos.ORIGINE))
        except Exception:
            log.debug("Prechauffage de la vue web impossible", exc_info=True)

    def _vue(self):
        if self.vue is None:
            vue = QWebEngineView(self.support)
            page = _PageVideo(_profil(), vue)
            vue.setPage(page)
            s = page.settings()
            s.setAttribute(QWebEngineSettings.WebAttribute.PlaybackRequiresUserGesture, False)
            s.setAttribute(QWebEngineSettings.WebAttribute.FullScreenSupportEnabled, True)
            s.setAttribute(QWebEngineSettings.WebAttribute.PluginsEnabled, False)
            page.setBackgroundColor(QColor("#05070B"))
            page.video_choisie.connect(self._video_choisie)
            page.fullScreenRequested.connect(self._plein_ecran)
            page.titleChanged.connect(self._signal_page)
            self._support_lay.addWidget(vue)
            self.vue = vue
        return self.vue

    def _plein_ecran(self, demande) -> None:
        demande.accept()
        if demande.toggleOn():
            if self._plein is None and self.vue is not None:
                self._plein = self.vue
                self._support_lay.removeWidget(self.vue)
                self.vue.setParent(None)
                self.vue.showFullScreen()
        else:
            self._sortir_plein_ecran()

    def _sortir_plein_ecran(self) -> None:
        if self._plein is None:
            return
        vue, self._plein = self._plein, None
        vue.showNormal()
        vue.setParent(self.support)
        self._support_lay.addWidget(vue)
        vue.show()

    # ------------------------------------------------------------------
    # Donnees en arriere-plan
    # ------------------------------------------------------------------
    def _charger_films(self) -> None:
        if not self.appid or self._films_pour == self.appid:
            return
        from ...core.tasks import Task
        appid = self._films_pour = self.appid
        t = Task(self._films_et_miniatures, appid)
        t.signals.finished.connect(lambda res, a=appid: self._films_lus(a, res))
        t.signals.failed.connect(lambda _m, a=appid: self._films_lus(a, ([], {})))
        t.start()
        if not self.lecture:
            self._rendre()

    @staticmethod
    def _films_et_miniatures(appid: str):
        films = videos.bandes_annonces(appid)
        miniatures = {f.id: videos.miniature_locale(f) for f in films[:6]}
        return films, miniatures

    def _films_lus(self, appid: str, resultat) -> None:
        if appid != self.appid:
            return                                   # autre jeu entre-temps
        films, miniatures = resultat
        self.films = list(films or [])
        self._miniatures.update({k: v for k, v in (miniatures or {}).items() if v})
        self._films_charges = True
        # aucune bande-annonce sur Steam : plutot qu'un onglet vide, on
        # montre le gameplay (sauf si le joueur a choisi l'onglet lui-meme)
        if (not self.films and self.onglet == BANDE and not self._onglet_choisi
                and not self.lecture):
            self.onglet = GAMEPLAY
            self.boutons[GAMEPLAY].setChecked(True)
        if not self.lecture:
            self._rendre()
        self._lecture_auto_bientot()

    def _choisir_film(self, n: int) -> None:
        self._film = n
        if self.lecture:
            self.arreter()
            self._rendre()
            self._lancer()
        else:
            self._rendre()

    def _miniature_youtube(self, r: dict) -> None:
        if "yt:" + r["id"] in self._miniatures:
            return                                   # deja demandee
        if self.game is not None:
            self._infos_youtube(self.game.uid, r["id"], titre_connu=bool(r.get("titre")))

    def _infos_youtube(self, uid: str, video: str, titre_connu: bool = False) -> None:
        cle = "yt:" + video
        self._miniatures.setdefault(cle, "")         # une seule demande
        from ...core.tasks import Task

        def travail():
            infos = {} if titre_connu else videos.infos_youtube(video)
            from ...core.paths import CACHE_DIR
            from ...plugins.artwork.base import download
            cible = CACHE_DIR / "videos" / f"yt_{video}.jpg"
            adresse = infos.get("miniature") or f"https://i.ytimg.com/vi/{video}/hqdefault.jpg"
            try:
                infos["local"] = str(cible) if download(adresse, cible) else ""
            except Exception:
                infos["local"] = ""
            return infos

        t = Task(travail)
        t.signals.finished.connect(lambda infos: self._infos_lues(uid, video, infos))
        t.start()

    def _infos_lues(self, uid: str, video: str, infos: dict) -> None:
        if infos.get("local"):
            self._miniatures["yt:" + video] = infos["local"]
        if infos.get("titre"):
            videos.retenir_video(uid, video, infos["titre"], infos.get("chaine", ""))
        if self.game is None or self.game.uid != uid:
            return
        if self._retenue.get("id") == video:
            self._retenue = videos.video_retenue(uid) or self._retenue
        if self.onglet == GAMEPLAY and not self.lecture:
            self._rendre()

    # ------------------------------------------------------------------
    def _fond_jeu(self) -> QPixmap:
        g = self.game
        for chemin in (getattr(g, "art_hero", ""), getattr(g, "art_cover", "")):
            pix = self._pixmap(chemin)
            if pix is not None:
                return pix
        # jeu sans aucun visuel (hors Steam, fiche introuvable) : une affiche
        # aux couleurs du jeu plutot qu'un cadre vide
        try:
            from .game_card import placeholder
            return placeholder(getattr(g, "title", "") or "", QSize(1280, 720),
                               getattr(g, "uid", "") or "")
        except Exception:
            return QPixmap()

    @staticmethod
    def _pixmap(chemin: str):
        if chemin and Path(chemin).exists():
            pix = QPixmap(chemin)
            if not pix.isNull():
                return pix
        return None

    def _ajuster_hauteur(self) -> None:
        """Image 16:9 aussi large que possible, sans depasser HAUTEUR_MAX."""
        marges = self.layout().contentsMargins()
        largeur = max(320, self.width() - marges.left() - marges.right())
        hauteur = max(HAUTEUR_MIN, min(HAUTEUR_MAX, round(largeur * 9 / 16)))
        largeur = round(hauteur * 16 / 9)
        if self.ecran.height() != hauteur or self.colonne.maximumWidth() != largeur:
            self.ecran.setFixedHeight(hauteur)
            self.ecran.setMaximumWidth(largeur)
            self.colonne.setMaximumWidth(largeur)

    def resizeEvent(self, event) -> None:           # noqa: N802
        super().resizeEvent(event)
        self._ajuster_hauteur()
