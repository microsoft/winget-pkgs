"""Jeux gratuits du catalogue GOG.

GOG expose son catalogue publiquement. Le filtre sur le prix zero fait
remonter les jeux offerts en permanence, sans DRM : ils ne disparaissent
pas et ne demandent donc jamais de desinstallation.
"""
from __future__ import annotations

from orion.core import region

from ...core.logging_setup import get
from .base import DEFINITIF, Freebie, FreebieSource, fetch_json

log = get("gratuits.gog")

CATALOG = "https://catalog.gog.com/v1/catalog"
STORE = "https://www.gog.com{slug}"


class GogFreebies(FreebieSource):
    id = "gog_free"
    label = "GOG"
    priority = 60

    filtre_adulte = "etiquettes du catalogue GOG (« nsfw ») lues par produit_adulte"

    def fetch(self) -> list[Freebie]:
        payload = fetch_json(CATALOG, {
            "limit": 48, "price": "between:0,0", "order": "desc:trending",
            "productType": "in:game", "page": 1,
            "countryCode": region.pays(), "locale": region.locale_gog(), "currencyCode": region.devise(),
        })
        products = (payload or {}).get("products") or []

        out: list[Freebie] = []
        for p in products:
            try:
                fb = self._one(p)
            except Exception:
                continue
            if fb is not None:
                fb.adulte = self.adulte(p)      # etiquette « nsfw » du catalogue
                out.append(fb)
        log.info("GOG : %d offre(s)", len(out))
        return out

    # ------------------------------------------------------------------
    def _one(self, p: dict) -> Freebie | None:
        title = str(p.get("title") or "").strip()
        slug = str(p.get("storeLink") or "")
        if not title:
            return None
        url = slug if slug.startswith("http") else STORE.format(
            slug=slug or "/fr/games")
        return Freebie(
            key=f"gog:{p.get('id')}",
            title=title,
            source=self.id,
            shop="GOG",
            url=url,
            buy_url=url,
            kind=DEFINITIF,
            image=str(p.get("coverVertical") or p.get("coverHorizontal") or ""),
            genres=[str(g.get("name") or "") for g in p.get("genres") or []][:4],
            developer=", ".join(p.get("developers") or [])[:80],
            release_date=str(p.get("releaseDate") or "")[:10],
        )
