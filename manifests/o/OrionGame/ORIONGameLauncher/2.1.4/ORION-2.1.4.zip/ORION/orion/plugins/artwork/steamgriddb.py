"""SteamGridDB : jaquettes de meilleure qualite, cle d'API facultative.

La cle se colle dans Reglages ; sans cle, ce fournisseur reste inactif.
"""
from __future__ import annotations

from ...core.config import CONFIG
from ...core.logging_setup import get
from ...core.models import Game
from .base import ArtworkProvider, cache_path, download

log = get("artwork.sgdb")

API = "https://www.steamgriddb.com/api/v2"


class SteamGridDBProvider(ArtworkProvider):
    id = "steamgriddb"
    label = "SteamGridDB"
    priority = 95           # teste avant le CDN Steam quand une cle existe

    def available(self) -> bool:
        return bool(CONFIG.get("artwork.steamgriddb_key"))

    def fetch(self, game: Game, want: set[str]) -> dict[str, str]:
        from orion.core import reseau

        key = CONFIG.get("artwork.steamgriddb_key")
        if not key:
            return {}
        headers = {"Authorization": f"Bearer {key}",
                   "User-Agent": "ORION-Launcher/1.0"}
        try:
            gid = self._game_id(game, headers)
            if not gid:
                return {}
            out: dict[str, str] = {}
            endpoints = {"cover": ("grids", {"dimensions": "600x900"}),
                         "hero": ("heroes", {}),
                         "logo": ("logos", {})}
            for kind, (ep, params) in endpoints.items():
                if kind not in want:
                    continue
                r = reseau.get(f"{API}/{ep}/game/{gid}", headers=headers,
                                 params=params, timeout=12)
                if r.status_code != 200:
                    continue
                items = (r.json() or {}).get("data") or []
                if not items:
                    continue
                url = items[0].get("url", "")
                ext = "png" if url.lower().endswith(".png") else "jpg"
                dest = cache_path(game, kind, ext)
                if url and download(url, dest):
                    out[kind] = str(dest)
            return out
        except Exception:
            log.debug("SteamGridDB indisponible pour %s", game.title)
            return {}

    @staticmethod
    def _game_id(game: Game, headers: dict) -> str:
        import requests
        from orion.core import reseau
        appid = game.extra.get("steam_appid") or (
            game.source_id if game.source == "steam" else "")
        try:
            if appid:
                r = reseau.get(f"{API}/games/steam/{appid}", headers=headers, timeout=10)
                if r.status_code == 200:
                    return str((r.json().get("data") or {}).get("id", ""))
            from ...core.recherche import meilleur_candidat, titre_recherche
            terme = titre_recherche(game.title) or game.title
            r = reseau.get(f"{API}/search/autocomplete/"
                           f"{requests.utils.quote(terme)}",
                           headers=headers, timeout=10)
            if r.status_code == 200:
                data = [d for d in (r.json() or {}).get("data") or []
                        if isinstance(d, dict) and d.get("id")]
                # le jeu lui-meme, pas le premier resultat venu (« Hades »
                # ne doit pas prendre les visuels de « Hades II »)
                choix = meilleur_candidat(game.title, data, genre=lambda d: None)
                if choix is not None:
                    return str(choix.get("id", ""))
        except Exception:
            pass
        return ""
