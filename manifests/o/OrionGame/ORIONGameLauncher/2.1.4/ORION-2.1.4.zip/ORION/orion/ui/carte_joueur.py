"""La carte de joueur (2.1.1) : une image 1200 x 630 a enregistrer et a
poster, dessinee depuis la fenetre « Valeur estimee de ma bibliotheque ».

Le joueur choisit ce qu'il y met : un pseudo et une photo de profil,
facultatifs, gardes sur son PC (reglages « carte.pseudo » et
« carte.photo ») et ecrits seulement sur l'image. Rien n'est envoye.
Sans photo, le cercle porte les initiales du pseudo, ou le logo d'ORION.

Tout est dessine avec Qt (QPainter), sans dependance supplementaire.
"""
from __future__ import annotations

import re
from pathlib import Path

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import (QBrush, QColor, QFont, QFontMetrics, QImage, QLinearGradient, QPainter,
                           QPainterPath, QPen, QPixmap, QRadialGradient)

from ..core.paths import ROOT_DIR
from ..i18n import t as _t

LARGEUR, HAUTEUR = 1200, 630
NUIT, NUIT_2 = "#0C1122", "#151D38"
CYAN, ORANGE, CRAIE, BRUME, PALE = "#38E1FF", "#FF9A4A", "#EFEAE0", "#A6AEC6", "#7780A0"
POLICE = "Segoe UI"
LOGO = ROOT_DIR / "orion" / "ui" / "assets" / "orion.png"
PSEUDO_MAX = 24
#: zones de texte : pas d'etoile dessous (colonne de droite, pseudo, pied)
SANS_ETOILES = (QRectF(424, 60, 740, 470), QRectF(60, 400, 350, 100), QRectF(28, 520, 1144, 82))


def titre_propre(titre: str) -> str:
    """« Call of Duty®: Modern Warfare® II » -> « Call of Duty: Modern Warfare II »."""
    return re.sub(r"\s{2,}", " ", re.sub(r"[™®©]", "", titre or "")).strip()


def _police(taille: int, poids=QFont.Weight.Normal) -> QFont:
    f = QFont(POLICE)
    f.setPixelSize(taille)
    f.setWeight(poids)
    return f


def _texte(p: QPainter, rect: QRectF, texte: str, police: QFont, couleur: str,
           alignement=Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter) -> None:
    p.setFont(police)
    p.setPen(QColor(couleur))
    elide = QFontMetrics(police).elidedText(texte, Qt.TextElideMode.ElideRight, int(rect.width()))
    p.drawText(rect, int(alignement), elide)


def initiales(pseudo: str) -> str:
    mots = [m for m in (pseudo or "").replace("_", " ").replace("-", " ").split() if m]
    if not mots:
        return ""
    return (mots[0][0] + (mots[1][0] if len(mots) > 1 else (mots[0][1] if len(mots[0]) > 1 else ""))).upper()


def photo_carree(chemin: str | Path | None) -> QImage | None:
    """La photo, recadree au centre en carre ; None si absente ou illisible."""
    if not chemin or not Path(chemin).is_file():
        return None
    img = QImage(str(chemin))
    if img.isNull():
        return None
    cote = min(img.width(), img.height())
    return img.copy((img.width() - cote) // 2, (img.height() - cote) // 2, cote, cote)


def _fond(p: QPainter) -> None:
    g = QLinearGradient(0, 0, LARGEUR, HAUTEUR)
    g.setColorAt(0.0, QColor(NUIT))
    g.setColorAt(1.0, QColor(NUIT_2))
    p.fillRect(QRectF(0, 0, LARGEUR, HAUTEUR), g)
    for (x, y, r, couleur, alpha) in ((1050, 80, 520, CYAN, 46), (120, 640, 560, ORANGE, 40)):
        rg = QRadialGradient(QPointF(x, y), r)
        c = QColor(couleur)
        c.setAlpha(alpha)
        rg.setColorAt(0.0, c)
        c2 = QColor(couleur)
        c2.setAlpha(0)
        rg.setColorAt(1.0, c2)
        p.fillRect(QRectF(0, 0, LARGEUR, HAUTEUR), QBrush(rg))
    # quelques etoiles, toujours au meme endroit (l'image ne change pas d'un tirage a l'autre)
    p.setPen(Qt.PenStyle.NoPen)
    for i in range(46):
        x = (i * 263 + 71) % LARGEUR
        y = (i * 151 + 37) % HAUTEUR
        if any(z.contains(QPointF(x, y)) for z in SANS_ETOILES):
            continue          # 11 octobre : une etoile sous « publicite » se lisait comme un accent,
                              # une autre comme une puce devant le logo ORION
        a = 40 + (i * 37) % 110
        p.setBrush(QColor(255, 255, 255, a))
        r = 1.0 + (i % 3) * 0.6
        p.drawEllipse(QPointF(x, y), r, r)
    # cadre de la carte
    cadre = QRectF(28, 28, LARGEUR - 56, HAUTEUR - 56)
    p.setBrush(QColor(255, 255, 255, 10))
    p.setPen(QPen(QColor(255, 255, 255, 34), 1.5))
    p.drawRoundedRect(cadre, 28, 28)
    trait = QLinearGradient(cadre.left(), 0, cadre.right(), 0)
    trait.setColorAt(0.0, QColor(CYAN))
    trait.setColorAt(1.0, QColor(ORANGE))
    p.setPen(QPen(QBrush(trait), 4))
    p.drawLine(QPointF(cadre.left() + 28, cadre.top() + 2), QPointF(cadre.right() - 28, cadre.top() + 2))


def _avatar(p: QPainter, centre: QPointF, rayon: float, photo: QImage | None, pseudo: str) -> None:
    halo = QRadialGradient(centre, rayon * 1.45)
    c = QColor(CYAN)
    c.setAlpha(90)
    halo.setColorAt(0.55, c)
    c0 = QColor(CYAN)
    c0.setAlpha(0)
    halo.setColorAt(1.0, c0)
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QBrush(halo))
    p.drawEllipse(centre, rayon * 1.45, rayon * 1.45)
    disque = QRectF(centre.x() - rayon, centre.y() - rayon, 2 * rayon, 2 * rayon)
    chemin = QPainterPath()
    chemin.addEllipse(disque)
    p.save()
    p.setClipPath(chemin)
    if photo is not None:
        p.drawImage(disque, photo.scaled(int(2 * rayon), int(2 * rayon), Qt.AspectRatioMode.IgnoreAspectRatio,
                                          Qt.TransformationMode.SmoothTransformation))
    else:
        g = QLinearGradient(disque.topLeft(), disque.bottomRight())
        g.setColorAt(0.0, QColor("#1E2A4F"))
        g.setColorAt(1.0, QColor("#0F1730"))
        p.fillRect(disque, g)
        ini = initiales(pseudo)
        if ini:
            _texte(p, disque, ini, _police(int(rayon * 0.82), QFont.Weight.Bold), CRAIE,
                   Qt.AlignmentFlag.AlignCenter)
        elif LOGO.exists():
            pm = QPixmap(str(LOGO)).scaled(int(rayon * 1.25), int(rayon * 1.25), Qt.AspectRatioMode.KeepAspectRatio,
                                           Qt.TransformationMode.SmoothTransformation)
            p.drawPixmap(int(centre.x() - pm.width() / 2), int(centre.y() - pm.height() / 2), pm)
    p.restore()
    anneau = QLinearGradient(disque.topLeft(), disque.bottomRight())
    anneau.setColorAt(0.0, QColor(CYAN))
    anneau.setColorAt(1.0, QColor(ORANGE))
    p.setBrush(Qt.BrushStyle.NoBrush)
    p.setPen(QPen(QBrush(anneau), 6))
    p.drawEllipse(disque)


def _pastille(p: QPainter, x: float, y: float, texte: str) -> float:
    police = _police(19, QFont.Weight.DemiBold)
    largeur = QFontMetrics(police).horizontalAdvance(texte) + 34
    rect = QRectF(x, y, largeur, 40)
    p.setPen(QPen(QColor(255, 255, 255, 46), 1))
    p.setBrush(QColor(255, 255, 255, 16))
    p.drawRoundedRect(rect, 20, 20)
    _texte(p, rect, texte, police, CRAIE, Qt.AlignmentFlag.AlignCenter)
    return largeur


def dessiner(titre_montant: str, montant: str, pastilles: list[str], meilleurs: list[tuple[str, str]],
             pseudo: str = "", photo: QImage | None = None, eyebrow: str = "CARTE DE JOUEUR",
             sous_titre: str = "", pied: str = "orion-launcher.com · gratuit, sans compte, sans publicite") -> QImage:
    """`titre_montant` : « Ma bibliotheque vaut » ; `montant` : « 5 892 € » ;
    `meilleurs` : [(titre, prix)] des jeux les plus chers (trois au plus)."""
    img = QImage(LARGEUR, HAUTEUR, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(QColor(NUIT))
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setRenderHint(QPainter.RenderHint.TextAntialiasing)
    p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
    _fond(p)

    # colonne de gauche : avatar et pseudo
    centre = QPointF(232, 262)
    _avatar(p, centre, 122, photo, pseudo)
    nom = (pseudo or "").strip()[:PSEUDO_MAX] or _t("Joueur ORION")
    _texte(p, QRectF(72, 410, 320, 52), nom, _police(36, QFont.Weight.Bold), CRAIE, Qt.AlignmentFlag.AlignCenter)
    if sous_titre:
        _texte(p, QRectF(72, 458, 320, 30), sous_titre, _police(18), BRUME, Qt.AlignmentFlag.AlignCenter)

    # colonne de droite : le montant, les pastilles, les jeux les plus chers
    x = 440
    lettres = _police(15, QFont.Weight.Bold)
    lettres.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 3)
    _texte(p, QRectF(x, 74, 700, 26), eyebrow.upper(), lettres, CYAN)
    _texte(p, QRectF(x, 108, 700, 40), titre_montant, _police(28), BRUME)
    grand = _police(96, QFont.Weight.Black)
    p.setFont(grand)
    rect_m = QRectF(x - 4, 140, 720, 118)
    degrade = QLinearGradient(x, 0, x + QFontMetrics(grand).horizontalAdvance(montant), 0)
    degrade.setColorAt(0.0, QColor(ORANGE))
    degrade.setColorAt(1.0, QColor("#FFC27A"))
    p.setPen(QPen(QBrush(degrade), 1))
    p.drawText(rect_m, int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), montant)
    px = x
    for texte in pastilles[:3]:
        px += _pastille(p, px, 272, texte) + 12
    y = 344
    p.setPen(QPen(QColor(255, 255, 255, 30), 1))
    p.drawLine(QPointF(x, y), QPointF(LARGEUR - 72, y))
    y += 18
    for i, (titre, prix) in enumerate(meilleurs[:3], 1):
        _texte(p, QRectF(x, y, 40, 44), f"{i}", _police(22, QFont.Weight.Bold), CYAN)
        _texte(p, QRectF(x + 40, y, 520, 44), titre, _police(24, QFont.Weight.DemiBold), CRAIE)
        _texte(p, QRectF(LARGEUR - 72 - 180, y, 180, 44), prix, _police(24, QFont.Weight.Bold), CRAIE,
               Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        y += 50

    # pied : logo et adresse
    if LOGO.exists():
        pm = QPixmap(str(LOGO)).scaled(34, 34, Qt.AspectRatioMode.KeepAspectRatio,
                                       Qt.TransformationMode.SmoothTransformation)
        p.drawPixmap(72, HAUTEUR - 92, pm)
    marque = _police(20, QFont.Weight.Bold)
    marque.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 4)
    _texte(p, QRectF(116, HAUTEUR - 96, 140, 42), "ORION", marque, CRAIE)
    _texte(p, QRectF(250, HAUTEUR - 96, LARGEUR - 322, 42), pied, _police(18), PALE)
    p.end()
    return img


def enregistrer(img: QImage, chemin) -> bool:
    return bool(img.save(str(chemin), "PNG"))
