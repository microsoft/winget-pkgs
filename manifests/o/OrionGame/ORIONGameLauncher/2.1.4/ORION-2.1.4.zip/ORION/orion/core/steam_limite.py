"""Politesse envers le magasin Steam : un appel a la fois, et une pause si refus.

Le magasin Steam limite le nombre de fiches demandees par connexion (de
l'ordre de 200 toutes les 5 minutes). La Boutique, les Envies, les jeux
gratuits et les fiches de jeux l'interrogent tous : sans coordination, quelques
redemarrages d'ORION suffisent a se faire refuser toutes les fiches pendant
plusieurs minutes.

* `attendre()` espace les appels (1,2 s minimum entre deux) ;
* `signaler_refus()` met Steam en pause 5 minutes : pendant ce temps,
  `en_pause()` est vrai et les modules sautent leurs appels au lieu
  d'aggraver le blocage.
"""
from __future__ import annotations

from .logging_setup import get

log = get("steam.limite")

ECART = 1.2          # secondes entre deux appels (voir reseau.POLITIQUES)

#: en-tete d'un navigateur courant : le magasin Steam degrade ses reponses
#: (« success: false ») pour les clients qu'il ne reconnait pas
NAVIGATEUR = {
    "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                   "AppleWebKit/537.36 (KHTML, like Gecko) "
                   "Chrome/128.0.0.0 Safari/537.36"),
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "fr-FR,fr;q=0.9,en;q=0.8",
}
PAUSE = 300          # secondes de pause apres un refus

# Depuis la 1.7, l'espacement et la pause sont geres par `core.reseau`
# pour toutes les connexions : ces fonctions restent pour les modules qui
# les appellent, et s'appuient sur lui.
_STEAM = "store.steampowered.com"


def en_pause() -> bool:
    from . import reseau
    return reseau.en_pause(_STEAM)


def attendre() -> None:
    """Sans effet : `reseau` espace deja les appels vers Steam."""
    return None


def signaler_refus() -> None:
    from . import reseau
    reseau.mettre_en_pause(_STEAM, PAUSE)


def concerne(url: str) -> bool:
    return "steampowered.com" in (url or "")


def fiche(reponse, appid) -> dict:
    """Bloc {success, data} d'un jeu dans une reponse `appdetails`.

    Steam range desormais parfois la fiche sous un autre numero que celui
    demande (Trailmakers, appid 585420, revient sous « 4443530 »). On cherche
    donc : la cle demandee, puis la fiche dont `steam_appid` correspond, puis
    la seule fiche presente quand un seul jeu a ete demande.
    """
    bloc = _trouver(reponse, appid)
    _observer(appid, bloc)
    return bloc


def _observer(appid, bloc) -> None:
    """Toute fiche Steam passe ici, quel que soit le module qui la demande :
    c'est donc ici qu'ORION retient qu'un jeu est reserve aux adultes."""
    try:
        from .. import contenu_adulte
        contenu_adulte.observer(appid, (bloc or {}).get("data"))
    except Exception:
        pass


def _trouver(reponse, appid) -> dict:
    if not isinstance(reponse, dict):
        return {}
    bloc = reponse.get(str(appid))
    if isinstance(bloc, dict):
        return bloc
    for b in reponse.values():
        data = (b or {}).get("data") if isinstance(b, dict) else None
        if isinstance(data, dict) and str(data.get("steam_appid")) == str(appid):
            return b
    if len(reponse) == 1:
        seul = next(iter(reponse.values()))
        return seul if isinstance(seul, dict) else {}
    return {}


def fiches_groupees(reponse, appids: list) -> dict:
    """Appel groupe (plusieurs appids) : {appid demande: bloc}.

    Si Steam a renomme les cles, l'ordre des reponses suit celui de la
    demande : on s'en sert quand le nombre de blocs correspond.
    """
    if not isinstance(reponse, dict):
        return {}
    out = {a: reponse[str(a)] for a in appids if isinstance(reponse.get(str(a)), dict)}
    if len(out) == len(appids):
        return out
    blocs = list(reponse.values())
    if len(blocs) == len(appids):
        for a, b in zip(appids, blocs):
            out.setdefault(a, b if isinstance(b, dict) else {})
    return out
