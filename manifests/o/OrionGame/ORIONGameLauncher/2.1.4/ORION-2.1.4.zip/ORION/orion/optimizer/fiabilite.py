"""Fiabilite des reglages : ORION ne doit jamais echouer en silence.

Trois controles, et un etat clair par jeu :

1. **Apres ecriture** (`verifier`) : chaque reglage est relu dans le
   fichier. Un reglage qui ne se relit pas comme il a ete ecrit est signale.
2. **Apres une partie** (`controler`) : ORION compare ce qu'il avait ecrit
   a ce que contient le fichier maintenant. Si le jeu (ou Steam Cloud, ou
   son lanceur) l'a remplace, on le dit ; si cela se reproduit, le jeu est
   classe « gere par le jeu » plutot que de pretendre le contraire.
3. **Etat affiche** (`statut`) :
   * « Reglages appliques : 12 sur 14 » - ORION ecrit et verifie ;
   * « Ce jeu n'est pas encore pris en charge » - aucune recette ;
   * « Le jeu a modifie N reglage(s) » - une fois, ORION reecrit ;
   * « Ce jeu gere ses reglages lui-meme : ORION regle l'ecran et le
     lancement » - aucun fichier connu, ou le jeu remplace toujours tout.

Ce qui est memorise (dans `game.extra["orion_reglages"]`) : la date, le
profil, les valeurs ecrites, et le nombre de parties ou elles ont ete
remplacees.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path

from ..core.logging_setup import get
from ..core.models import Game, OptimizationPlan, TweakOp

log = get("optimizer.fiabilite")

CLE = "orion_reglages"

AUTO, A_ECRIRE, MODIFIE, GERE_PAR_LE_JEU = "auto", "a_ecrire", "modifie", "jeu"
NON_PRIS = "non_pris"
COULEURS = {AUTO: "#3DDC97", A_ECRIRE: "#38E1FF", MODIFIE: "#FFB454",
            GERE_PAR_LE_JEU: "#AAB4C8", NON_PRIS: "#AAB4C8"}
TITRE_JEU = "Ce jeu gere ses reglages lui-meme : ORION regle l'ecran et le lancement"
TITRE_NON_PRIS = "Ce jeu n'est pas encore pris en charge"
TITRE_INTROUVABLE = "Lancez le jeu une fois pour qu'ORION puisse le regler"


@dataclass
class Verification:
    ecrits: int = 0
    refuses: list[TweakOp] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.refuses

    @property
    def message(self) -> str:
        if not self.refuses:
            return f"{self.ecrits} reglage(s) applique(s) et verifie(s)"
        noms = ", ".join(o.label or o.key for o in self.refuses[:3])
        return (f"{self.ecrits - len(self.refuses)} reglage(s) sur {self.ecrits} "
                f"verifie(s) ; non pris en compte : {noms}")


@dataclass
class Statut:
    cle: str
    titre: str
    detail: str = ""
    en_place: int = 0               # reglages deja dans le fichier
    total: int = 0                  # reglages que la recette sait regler

    @property
    def couleur(self) -> str:
        return COULEURS.get(self.cle, "#AAB4C8")

    @property
    def automatique(self) -> bool:
        return self.cle in (AUTO, A_ECRIRE, MODIFIE)

    @property
    def pris_en_charge(self) -> bool:
        return self.cle != NON_PRIS


# --------------------------------------------------------------------------
def meme_valeur(a, b) -> bool:
    """« 2 » = « 2.000000 », « True » = « true »."""
    if a is None or b is None:
        return a is None and b is None
    x, y = str(a).strip().strip('"'), str(b).strip().strip('"')
    if x.lower() == y.lower():
        return True
    try:
        return abs(float(x) - float(y)) < 1e-6
    except ValueError:
        return False


def _cle_op(op: TweakOp) -> str:
    return f"{op.target}|{op.section}|{op.key}"


def _ops_fichier(plan: OptimizationPlan) -> list[TweakOp]:
    return [o for o in plan.ops if o.kind != "note"]


def verifier(ops: list[TweakOp], writers: dict) -> Verification:
    """Relit chaque reglage ecrit."""
    v = Verification(ecrits=len(ops))
    for op in ops:
        writer = writers.get(op.kind)
        if writer is None:
            continue
        try:
            lu = writer.read(op)
        except Exception:
            lu = None
        if not meme_valeur(lu, op.value):
            v.refuses.append(op)
    if v.refuses:
        log.warning("Reglages non relus apres ecriture : %s",
                    [o.key for o in v.refuses[:5]])
    return v


def memoriser(game: Game, plan: OptimizationPlan,
              refuses: list[TweakOp] | None = None) -> None:
    """Retient ce qu'ORION vient d'ecrire (pour le controle apres partie).

    Les reglages refuses a l'ecriture ne sont pas retenus : sinon le
    controle apres partie accusait le jeu de les avoir remplaces."""
    ancien = game.extra.get(CLE) or {}
    refuses = refuses or []
    ecrits = [o for o in _ops_fichier(plan) if o not in refuses]
    game.extra[CLE] = {
        "profil": plan.profile, "at": time.time(),
        "valeurs": {_cle_op(o): str(o.value) for o in ecrits},
        "fichiers": sorted({Path(o.target).name for o in ecrits
                            if o.kind != "registry"}),
        "refuses": [o.label or o.key for o in refuses][:10],
        "ecrase": int(ancien.get("ecrase", 0)),
        "controle": False, "modifies": 0,
    }


def reecriture_identique(game: Game, plan: OptimizationPlan) -> bool:
    """Vrai si tout ce que le plan va ecrire, ORION l'a deja ecrit pour ce
    jeu (meme profil, memes valeurs) : le jeu les a juste remis a sa facon.
    La fenetre peut alors reappliquer sans redemander confirmation a
    chaque lancement."""
    memo = game.extra.get(CLE)
    if not isinstance(memo, dict) or memo.get("profil") != plan.profile:
        return False
    valeurs = memo.get("valeurs") or {}
    a_ecrire = [o for o in _ops_fichier(plan) if o.changed]
    return bool(a_ecrire) and all(
        meme_valeur(valeurs.get(_cle_op(o)), o.value) for o in a_ecrire)


def couverture(plan: OptimizationPlan | None) -> tuple[int, int]:
    """(reglages en place, reglages que la recette sait regler pour ce jeu).

    « Reglages appliques : 12 sur 14 ». Un reglage est « en place » quand
    le fichier contient deja la valeur voulue."""
    if plan is None:
        return 0, 0
    ops = _ops_fichier(plan)
    total = max(int(getattr(plan, "reglages_prevus", 0) or 0), len(ops))
    en_place = sum(1 for o in ops if not o.changed)
    return en_place, total


def controler(game: Game, plan: OptimizationPlan) -> int:
    """Compare la derniere ecriture d'ORION aux valeurs lues dans `plan`
    (`op.current`). Retourne le nombre de reglages remplaces depuis.

    Une partie jouee depuis l'ecriture est comptee une seule fois : remplace
    -> `ecrase` +1 ; intact -> `ecrase` remis a zero (le jeu garde bien les
    reglages)."""
    memo = game.extra.get(CLE)
    if not isinstance(memo, dict) or not memo.get("valeurs"):
        return 0
    valeurs: dict = memo["valeurs"]
    modifies = 0
    compares = 0
    for op in _ops_fichier(plan):
        attendu = valeurs.get(_cle_op(op))
        if attendu is None:
            continue
        compares += 1
        if not meme_valeur(op.current, attendu):
            modifies += 1
    if not compares:
        return 0
    memo["modifies"] = modifies
    joue_depuis = float(game.last_played or 0) > float(memo.get("at") or 0)
    if joue_depuis and not memo.get("controle"):
        memo["controle"] = True
        memo["ecrase"] = int(memo.get("ecrase", 0)) + 1 if modifies else 0
        if modifies:
            log.info("%s : %d reglage(s) remplace(s) par le jeu depuis la derniere "
                     "application", game.title, modifies)
    return modifies


def _steam_cloud(plan: OptimizationPlan) -> bool:
    for o in _ops_fichier(plan):
        t = o.target.replace("\\", "/").lower()
        if "/userdata/" in t and "/steam" in t:
            return True
    return False


def statut(plan: OptimizationPlan | None, game: Game | None = None) -> Statut:
    """Etat a afficher sur la fiche du jeu."""
    if plan is None or not _ops_fichier(plan):
        prevus = int(getattr(plan, "reglages_prevus", 0) or 0) if plan else 0
        if plan is not None and prevus:
            # recette connue, mais pas encore de fichier sur le disque
            return Statut(GERE_PAR_LE_JEU, TITRE_INTROUVABLE, (
                "Le fichier de reglages de ce jeu n'existe pas encore : il est "
                "cree a la premiere partie. Lancez le jeu une fois, quittez-le, "
                "puis revenez ici : ORION pourra alors regler ses "
                f"{prevus} options."))
        return Statut(NON_PRIS, TITRE_NON_PRIS, (
            "ORION ne connait pas encore de fichier de reglages pour ce jeu "
            "(moteur maison ou reglages enregistres en ligne). Il le lance "
            "normalement, sans toucher a ses fichiers ; choisissez le niveau "
            "conseille ci-dessus dans le menu des options du jeu."))
    memo = (game.extra.get(CLE) if game is not None else None) or {}
    fichiers = sorted({Path(o.target).name for o in _ops_fichier(plan)
                       if o.kind != "registry"}) or ["registre de Windows"]
    ou = ", ".join(fichiers[:2])
    en_place, total = couverture(plan)
    nuage = (" Ce fichier est synchronise par Steam Cloud, qui peut remettre "
             "l'ancienne version au lancement.") if _steam_cloud(plan) else ""
    if int(memo.get("ecrase", 0)) >= 2:
        return Statut(GERE_PAR_LE_JEU, TITRE_JEU, (
            f"Le jeu a remplace les reglages ecrits par ORION lors des "
            f"{int(memo['ecrase'])} dernieres parties. ORION continue de regler "
            f"l'ecran ; reglez les graphismes dans le menu du jeu." + nuage),
            en_place, total)
    if int(memo.get("modifies", 0)) > 0:
        n = int(memo["modifies"])
        return Statut(MODIFIE, f"Le jeu a modifie {n} reglage(s) depuis la derniere "
                      "application", (
                          "Par le jeu lui-meme, son lanceur ou vous dans ses "
                          "options. ORION les reecrit avant chaque partie lancee "
                          "depuis ORION, et vous previendra si cela se reproduit."
                          + nuage), en_place, total)
    refuses = [str(x) for x in (memo.get("refuses") or [])]
    if memo.get("valeurs") and refuses and plan.has_changes:
        return Statut(MODIFIE, f"Reglages appliques : {en_place} sur {total}", (
            "Non pris en compte : " + ", ".join(refuses[:3])
            + ". Le fichier est peut-etre en lecture seule ou ouvert par le jeu."
            + nuage), en_place, total)
    if not plan.has_changes:
        detail = f"Ecrits et verifies dans {ou}"
        if memo.get("valeurs"):
            quand = time.strftime("%d/%m a %H:%M",
                                  time.localtime(float(memo.get("at") or 0)))
            detail += f" le {quand}"
        return Statut(AUTO, f"Reglages appliques : {en_place} sur {total}",
                      detail + "." + nuage, en_place, total)
    n = sum(1 for o in _ops_fichier(plan) if o.changed)
    return Statut(A_ECRIRE, f"{n} reglage(s) a appliquer au lancement", (
        f"Reglages appliques : {en_place} sur {total}. ORION ecrira les autres "
        f"dans {ou} juste avant de lancer le jeu, puis verifiera qu'ils sont "
        "bien pris en compte." + nuage), en_place, total)
