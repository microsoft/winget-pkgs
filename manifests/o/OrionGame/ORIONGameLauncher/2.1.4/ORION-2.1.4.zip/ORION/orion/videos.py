"""Videos de la fiche d'un jeu : bandes-annonces, gameplay en francais, lives.

Aucune cle d'API, rien qui contourne les regles des sites :

* **Bandes-annonces officielles** : la liste vient de la fiche Steam publique
  (`appdetails`, filtre `movies`, deja utilisee par ORION pour les prix).
  Steam les diffuse en DASH ; la piste AV1 se lit dans le moteur web
  embarque (QtWebEngine), qui ne sait pas lire le H.264 ni l'AAC. Le son
  n'est joue que si le moteur le prend en charge.
* **Gameplay en francais et lives** : YouTube interdit aux robots ses pages
  de resultats (robots.txt : « Disallow: /results ») ; ORION ne les lit donc
  jamais tout seul. C'est le joueur qui choisit la video dans les resultats
  YouTube affiches dans le lecteur, comme dans n'importe quel navigateur ;
  ORION lit ensuite la video choisie avec le lecteur officiel integrable
  (youtube-nocookie.com/embed) et retient ce choix pour le jeu.
* **Twitch** : son lecteur ne diffuse que du H.264, illisible par le moteur
  web embarque : les lives Twitch s'ouvrent dans le navigateur.
"""
from __future__ import annotations

from orion.core import region

import html
import json
import re
import time
from dataclasses import asdict, dataclass
from urllib.parse import parse_qs, quote_plus, urlparse

from .core.logging_setup import get

log = get("videos")

APPDETAILS = "https://store.steampowered.com/api/appdetails"
OEMBED = "https://www.youtube.com/oembed"
STEAM_APP = "https://store.steampowered.com/app/{appid}"

#: hote fictif servant d'origine aux pages du lecteur : le lecteur YouTube
#: refuse de jouer sans page d'origine (erreur 153)
ORIGINE = "https://lecteur.orion.local/"

#: duree de conservation de la liste des bandes-annonces (secondes)
GARDER_BANDES = 3 * 24 * 3600

#: filtres YouTube (parametre `sp` des resultats) : videos seules, lives
FILTRE_VIDEOS = "EgIQAQ=="
FILTRE_LIVES = "EgJAAQ=="

_ID_YOUTUBE = re.compile(r"^[A-Za-z0-9_-]{11}$")


@dataclass
class BandeAnnonce:
    """Une video officielle publiee sur la fiche Steam du jeu."""
    id: str
    nom: str
    miniature: str = ""          # adresse de l'image d'apercu
    dash_av1: str = ""           # manifeste DASH, piste AV1 (lisible)
    dash_h264: str = ""
    hls_h264: str = ""
    webm: str = ""               # ancien format (VP8/VP9 + Vorbis), si fourni
    mp4: str = ""
    vedette: bool = False        # mise en avant par l'editeur
    appid: str = ""

    @property
    def lisible(self) -> bool:
        """Lisible dans le moteur web embarque (sans H.264)."""
        return bool(self.dash_av1 or self.webm)

    @property
    def page(self) -> str:
        return STEAM_APP.format(appid=self.appid) if self.appid else ""

    def to_dict(self) -> dict:
        return asdict(self)


# --------------------------------------------------------------------------
# Bandes-annonces Steam
# --------------------------------------------------------------------------
def lire_films(appid: str, brut: list) -> list[BandeAnnonce]:
    """Champ `movies` d'une fiche `appdetails` -> bandes-annonces lisibles.

    Accepte l'ancien format (`webm`/`mp4` : {"480", "max"}) comme le
    nouveau (manifestes `dash_av1`, `dash_h264`, `hls_h264`)."""
    films: list[BandeAnnonce] = []
    for m in brut or []:
        if not isinstance(m, dict) or not m.get("id"):
            continue
        webm = m.get("webm") or {}
        mp4 = m.get("mp4") or {}
        film = BandeAnnonce(
            id=str(m["id"]), nom=html.unescape(str(m.get("name") or "Bande-annonce")),
            miniature=str(m.get("thumbnail") or ""),
            dash_av1=str(m.get("dash_av1") or ""),
            dash_h264=str(m.get("dash_h264") or ""),
            hls_h264=str(m.get("hls_h264") or ""),
            webm=str(webm.get("max") or webm.get("480") or "") if isinstance(webm, dict) else "",
            mp4=str(mp4.get("max") or mp4.get("480") or "") if isinstance(mp4, dict) else "",
            vedette=bool(m.get("highlight")), appid=str(appid))
        films.append(film)
    # les videos mises en avant par l'editeur d'abord, l'ordre Steam ensuite
    films.sort(key=lambda f: not f.vedette)
    return films


def bandes_annonces(appid: str, forcer: bool = False) -> list[BandeAnnonce]:
    """Bandes-annonces officielles d'un jeu Steam (cache de quelques jours).

    Ne leve jamais d'exception : liste vide si Steam ne repond pas."""
    from .core.base import Table
    appid = str(appid or "").strip()
    if not appid.isdigit():
        return []
    from . import contenu_adulte
    if contenu_adulte.est_marque(appid):
        return []                        # jeu reserve aux adultes
    table = Table("videos_steam")
    memo = table.get(appid) or {}
    if memo and not forcer and time.time() - float(memo.get("le", 0)) < GARDER_BANDES:
        return [BandeAnnonce(**f) for f in memo.get("films") or []]
    from .core import reseau, steam_limite
    if steam_limite.en_pause():
        return [BandeAnnonce(**f) for f in memo.get("films") or []]
    try:
        r = reseau.get(APPDETAILS, params={"appids": appid, "filters": "movies,content_descriptors",
                                           "l": region.langue_steam()},
                       headers=steam_limite.NAVIGATEUR, timeout=12)
        if r.status_code in (403, 429):
            steam_limite.signaler_refus()
            raise RuntimeError(f"HTTP {r.status_code}")
        bloc = steam_limite.fiche(r.json(), appid)
    except Exception as exc:
        log.info("Bandes-annonces Steam %s indisponibles : %s", appid, exc)
        return [BandeAnnonce(**f) for f in memo.get("films") or []]
    data = bloc.get("data") if bloc.get("success") else {}
    if contenu_adulte.fiche_adulte(data):
        contenu_adulte.marquer(appid)
        table.set(appid, {"le": time.time(), "films": []})
        return []
    films = lire_films(appid, (data or {}).get("movies") or [])
    table.set(appid, {"le": time.time(), "films": [f.to_dict() for f in films]})
    return films


def miniature_locale(film: BandeAnnonce) -> str:
    """Telecharge l'apercu d'une bande-annonce ; chemin local ou « »."""
    if not film.miniature:
        return ""
    from .core.paths import CACHE_DIR
    from .plugins.artwork.base import download
    cible = CACHE_DIR / "videos" / f"{film.appid or 'x'}_{film.id}.jpg"
    try:
        return str(cible) if download(film.miniature, cible) else ""
    except Exception:
        return ""


# --------------------------------------------------------------------------
# YouTube et Twitch
# --------------------------------------------------------------------------
def requete_gameplay(titre: str) -> str:
    return f"{titre.strip()} gameplay fr"


def recherche_youtube(titre: str, direct: bool = False, mobile: bool = False) -> str:
    """Page de resultats YouTube : videos de gameplay en francais, ou lives.

    `mobile` donne la mise en page compacte (m.youtube.com), adaptee au
    lecteur integre."""
    hote = "https://m.youtube.com" if mobile else "https://www.youtube.com"
    terme = titre.strip() if direct else requete_gameplay(titre)
    filtre = FILTRE_LIVES if direct else FILTRE_VIDEOS
    return f"{hote}/results?search_query={quote_plus(terme)}&sp={quote_plus(filtre)}"


def recherche_twitch(titre: str) -> str:
    return f"https://www.twitch.tv/search?term={quote_plus(titre.strip())}"


def recherche_bande_annonce(titre: str) -> str:
    """Bandes-annonces sur YouTube (jeu absent de Steam)."""
    return ("https://www.youtube.com/results?search_query="
            + quote_plus(f"{titre.strip()} bande annonce vf"))


def id_youtube(url: str) -> str:
    """Identifiant d'une video YouTube d'apres son adresse, ou « ».

    watch?v=..., youtu.be/..., /shorts/..., /live/..., /embed/..."""
    try:
        u = urlparse(url or "")
    except Exception:
        return ""
    hote = (u.hostname or "").lower()
    if hote.startswith("www."):
        hote = hote[4:]
    if hote.startswith("m."):
        hote = hote[2:]
    candidat = ""
    if hote == "youtu.be":
        candidat = u.path.strip("/").split("/")[0]
    elif hote in ("youtube.com", "music.youtube.com", "youtube-nocookie.com"):
        if u.path == "/watch":
            candidat = (parse_qs(u.query).get("v") or [""])[0]
        else:
            morceaux = [m for m in u.path.split("/") if m]
            if len(morceaux) >= 2 and morceaux[0] in ("shorts", "live", "embed", "v"):
                candidat = morceaux[1]
    return candidat if _ID_YOUTUBE.match(candidat or "") else ""


def url_embed_youtube(video: str, lecture_auto: bool = True, muet: bool = True) -> str:
    """Lecteur officiel integrable, sans cookies publicitaires."""
    params = [("autoplay", "1" if lecture_auto else "0"), ("mute", "1" if muet else "0"),
              ("rel", "0"), ("playsinline", "1"), ("hl", "fr"), ("cc_lang_pref", "fr"),
              ("modestbranding", "1"), ("enablejsapi", "0"),
              ("origin", ORIGINE.rstrip("/"))]
    return (f"https://www.youtube-nocookie.com/embed/{video}?"
            + "&".join(f"{k}={quote_plus(v)}" for k, v in params))


def url_youtube(video: str) -> str:
    return f"https://www.youtube.com/watch?v={video}"


def infos_youtube(video: str) -> dict:
    """Titre et chaine d'une video, par le service oEmbed public de YouTube."""
    from .core import reseau
    try:
        r = reseau.get(OEMBED, params={"url": url_youtube(video), "format": "json"},
                       timeout=10)
        if r.status_code != 200:
            return {}
        d = r.json() or {}
        return {"titre": str(d.get("title") or ""), "chaine": str(d.get("author_name") or ""),
                "miniature": str(d.get("thumbnail_url") or "")}
    except Exception:
        return {}


# -- choix retenus pour chaque jeu --------------------------------------------
def _choix():
    from .core.base import Table
    return Table("videos_choisies")


def video_retenue(uid: str) -> dict:
    """Video de gameplay choisie pour ce jeu : {id, titre, chaine} ou {}."""
    d = _choix().get(uid) or {}
    return d if _ID_YOUTUBE.match(str(d.get("id") or "")) else {}


def retenir_video(uid: str, video: str, titre: str = "", chaine: str = "") -> None:
    if not uid or not _ID_YOUTUBE.match(video or ""):
        return
    _choix().set(uid, {"id": video, "titre": titre, "chaine": chaine, "le": time.time()})


# --------------------------------------------------------------------------
# Pages HTML du lecteur
# --------------------------------------------------------------------------
_STYLE = """
html,body{margin:0;height:100%;background:#05070B;overflow:hidden;
  font-family:"Segoe UI",sans-serif;color:#E7ECF5}
iframe,video{position:absolute;inset:0;width:100%;height:100%;border:0;background:#05070B}
.puce{position:absolute;left:14px;top:12px;padding:5px 11px;border-radius:12px;
  background:rgba(10,13,20,.78);border:1px solid #33405C;font-size:12px;color:#AAB4C8;
  display:none;z-index:2}
.erreur{position:absolute;inset:0;display:none;align-items:center;justify-content:center;
  text-align:center;color:#AAB4C8;font-size:14px;padding:30px;z-index:3}
"""


def html_youtube(video: str, lecture_auto: bool = True, muet: bool = True) -> str:
    src = html.escape(url_embed_youtube(video, lecture_auto, muet), quote=True)
    return (
        "<!doctype html><html><head><meta charset='utf-8'>"
        "<meta name='referrer' content='strict-origin-when-cross-origin'>"
        f"<style>{_STYLE}</style></head><body>"
        f"<iframe src=\"{src}\" title=\"YouTube\" "
        "allow=\"autoplay; encrypted-media; picture-in-picture; fullscreen\" "
        "referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>"
        "</body></html>")


#: mini lecteur DASH (Media Source Extensions) : lit la meilleure piste video
#: prise en charge (AV1 pour le moteur embarque) et la piste audio si elle
#: est lisible ; sinon la video reste muette et une puce le signale.
_LECTEUR_DASH = r"""
const video = document.getElementById('v');
const puce = document.getElementById('puce');
const erreur = document.getElementById('erreur');
function duree(s){const m=/PT(?:(\d+)H)?(?:(\d+)M)?(?:([\d.]+)S)?/.exec(s||'')||[];
  return (+m[1]||0)*3600+(+m[2]||0)*60+(+m[3]||0);}
function echec(t){erreur.textContent=t;erreur.style.display='flex';document.title='ORION-ECHEC';}
async function piste(ms, xml, base, genre, hauteurMax){
  let choix=null;
  for(const ens of xml.getElementsByTagName('AdaptationSet')){
    for(const r of ens.getElementsByTagName('Representation')){
      const mime=r.getAttribute('mimeType')||ens.getAttribute('mimeType')||'';
      if(!mime.startsWith(genre)) continue;
      const type=mime+'; codecs="'+(r.getAttribute('codecs')||ens.getAttribute('codecs')||'')+'"';
      if(!window.MediaSource||!MediaSource.isTypeSupported(type)) continue;
      const h=+r.getAttribute('height')||0;
      if(genre==='video'&&h>hauteurMax) continue;
      if(!choix||h>choix.h) choix={r,h,type,ens};
    }
  }
  if(!choix) return null;
  const mod=choix.r.getElementsByTagName('SegmentTemplate')[0]||choix.ens.getElementsByTagName('SegmentTemplate')[0];
  if(!mod) return null;
  const id=choix.r.getAttribute('id');
  const ts=+mod.getAttribute('timescale')||1, d=+mod.getAttribute('duration')||0;
  const debut=+(mod.getAttribute('startNumber')||1);
  const total=duree(xml.documentElement.getAttribute('mediaPresentationDuration'));
  const n=d?Math.ceil(total/(d/ts)):0;
  const remplir=(m,num)=>base+m.replace(/\$RepresentationID\$/g,id)
    .replace(/\$Number(%0(\d+)d)?\$/g,(_,f,w)=>w?String(num).padStart(+w,'0'):String(num));
  const sb=ms.addSourceBuffer(choix.type);
  return {sb,n,debut,mod,remplir,i:0,fini:false};
}
function ajouter(sb,buf){return new Promise((ok,ko)=>{
  sb.addEventListener('updateend',ok,{once:true});sb.addEventListener('error',ko,{once:true});
  sb.appendBuffer(buf);});}
async function nourrir(p,ms){
  const init=await fetch(p.remplir(p.mod.getAttribute('initialization'),0));
  await ajouter(p.sb,await init.arrayBuffer());
  while(p.i<p.n){
    const b=p.sb.buffered, avance=b.length?b.end(b.length-1)-video.currentTime:0;
    if(avance>40){await new Promise(r=>setTimeout(r,800));continue;}
    const rep=await fetch(p.remplir(p.mod.getAttribute('media'),p.debut+p.i));
    if(!rep.ok) break;
    await ajouter(p.sb,await rep.arrayBuffer());
    p.i++;
  }
  p.fini=true;
}
async function jouerDash(mpd){
  const base=mpd.split('?')[0].replace(/[^/]*$/,'');
  const texte=await (await fetch(mpd)).text();
  const xml=new DOMParser().parseFromString(texte,'application/xml');
  const ms=new MediaSource();
  video.src=URL.createObjectURL(ms);
  await new Promise(r=>ms.addEventListener('sourceopen',r,{once:true}));
  ms.duration=duree(xml.documentElement.getAttribute('mediaPresentationDuration'));
  const pv=await piste(ms,xml,base,'video',HAUTEUR);
  if(!pv){echec("Format video non pris en charge par le lecteur integre.");return;}
  const pa=await piste(ms,xml,base,'audio',0);
  if(!pa){video.muted=true;puce.style.display='block';}
  const pistes=[pv].concat(pa?[pa]:[]);
  await Promise.all(pistes.map(p=>nourrir(p,ms)));
  if(ms.readyState==='open'){try{ms.endOfStream();}catch(e){}}
}
"""


def html_bande_annonce(film: BandeAnnonce, lecture_auto: bool = True,
                       hauteur_max: int = 1080) -> str:
    """Page du lecteur pour une bande-annonce Steam (muette par defaut)."""
    affiche = html.escape(film.miniature, quote=True)
    auto = " autoplay" if lecture_auto else ""
    if film.dash_av1:
        source = ""
        script = (f"<script>const HAUTEUR={int(hauteur_max)};{_LECTEUR_DASH}"
                  f"jouerDash({json.dumps(film.dash_av1)}).catch(e=>echec("
                  "'Lecture impossible : '+e));</script>")
    elif film.webm:
        source = f"<source src=\"{html.escape(film.webm, quote=True)}\" type=\"video/webm\">"
        script = ""
    else:
        source = ""
        script = ("<script>document.getElementById('erreur').textContent="
                  "'Cette bande-annonce n\\'est disponible que dans un format illisible ici.';"
                  "document.getElementById('erreur').style.display='flex';"
                  "document.title='ORION-ECHEC';</script>")
    return (
        "<!doctype html><html><head><meta charset='utf-8'>"
        f"<style>{_STYLE}</style></head><body>"
        f"<video id='v' controls muted playsinline{auto} poster=\"{affiche}\">{source}</video>"
        "<div class='puce' id='puce'>Sans le son dans ORION · "
        "ouvrez-la sur Steam pour l'entendre</div>"
        "<div class='erreur' id='erreur'></div>"
        # signaux pour ORION (titre de la page) : premiere image affichee, ou echec
        "<script>(function(){var v=document.getElementById('v');"
        "v.addEventListener('playing',function(){document.title='ORION-LECTURE';},{once:true});"
        "v.addEventListener('error',function(){document.title='ORION-ECHEC';});"
        "v.addEventListener('ended',function(){document.title='ORION-FIN';});"
        "var s=v.querySelector('source');if(s)s.addEventListener('error',function(){"
        "document.title='ORION-ECHEC';});})();</script>"
        f"{script}</body></html>")
