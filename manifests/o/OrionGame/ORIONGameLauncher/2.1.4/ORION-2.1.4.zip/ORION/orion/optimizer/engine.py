"""Moteur d'optimisation : recette + profil + materiel -> plan applicable.

Le plan est toujours construit avant d'etre applique, et il expose la valeur
actuelle de chaque reglage : l'interface peut donc montrer exactement ce qui
va changer avant que quoi que ce soit ne soit ecrit.
"""
from __future__ import annotations

import glob
import json
from pathlib import Path
from typing import Any

from ..core import registry
from ..core.config import CONFIG
from ..core.events import BUS, TWEAKS_APPLIED
from ..core.fichiers import est_dossier, existe
from ..core.logging_setup import get
from ..core.models import (Display, Game, HardwareInfo, OptimizationPlan,
                           TweakOp, normalize_title)
from ..core.paths import (RECIPE_BUILTIN_DIR, RECIPE_COMMUNITY_DIR,
                          RECIPE_USER_DIR, ensure_dirs, expand)
from ..plugins.tweaks.base import TweakWriter
from . import backup as backup_mod
from .discovery import context_for
from . import fiabilite
from .profiles import (PROFILES, choose_display_mode, compute_settings,
                       profil_par_defaut)
from .recommande import noter_capacites

log = get("optimizer.moteur")


# --------------------------------------------------------------------------
# Recettes
# --------------------------------------------------------------------------

class Recipe:
    def __init__(self, data: dict, origin: Path) -> None:
        self.data = data
        self.origin = origin
        self.id = data.get("id") or origin.stem
        self.name = data.get("name") or self.id
        self.match = data.get("match") or {}
        self.confidence = data.get("confidence") or "generique"
        self.targets = data.get("targets") or []
        self.advice = data.get("advice") or []
        self.derive = data.get("derive") or {}
        self.community = data.get("community") or {}
        #: reglages au-dela des niveaux que la recette sait ecrire :
        #: « upscaler » (DLSS/FSR/XeSS du jeu), « echelle_resolution »
        caps = data.get("capacites") or []
        self.capacites = [str(c) for c in caps] if isinstance(caps, list) else []
        #: une cle absente du fichier est-elle creee ? Les recettes 2.1.0
        #: (XML, KeyValues, texte, moteurs sans section) disent non : jamais
        #: une cle inventee, le plan saute le reglage et le dit
        self.creer_cles = bool(data.get("creer_cles", True))

    @property
    def origin_label(self) -> str:
        """D'ou vient cette recette, pour l'afficher dans l'interface."""
        if self.community:
            author = self.community.get("author") or "la communaute"
            return f"partagee par {author}"
        if self.confidence == "appris":
            return "apprise dans le fichier du jeu"
        try:
            parent = self.origin.parent.resolve()
            if parent == RECIPE_COMMUNITY_DIR.resolve():
                return "partagee"
            if parent == RECIPE_USER_DIR.resolve():
                return "la votre"
        except Exception:
            pass
        return "livree avec ORION"

    def score(self, game: Game) -> int:
        """Pertinence de la recette pour ce jeu (0 = ne s'applique pas)."""
        m = self.match
        if not m:
            return 1                                  # recette de repli
        if "appid" in m and game.source == "steam" and game.source_id in [
                str(a) for a in m["appid"]]:
            return 100
        if "title" in m:
            key = normalize_title(game.title)
            for t in m["title"]:
                if normalize_title(str(t)) == key:
                    return 90
        if "title_contains" in m:
            low = game.title.lower()
            if any(str(t).lower() in low for t in m["title_contains"]):
                return 70
        if "engine" in m and game.engine and game.engine in m["engine"]:
            return 50
        return 0


#: recettes partagees deja signalees comme modifiees : les recettes sont
#: relues a chaque fiche ouverte, l'alerte remplissait le journal
_RECETTES_SIGNALEES: set[str] = set()


def cle_unity(nom: str) -> str:
    """Nom d'une option PlayerPrefs de Unity dans le registre : le nom suivi
    de « _h » et de son empreinte (djb2 en ou exclusif, 32 bits). Calcule ici :
    les empreintes recopiees a la main dans la recette Unity etaient fausses
    pour la qualite et la synchronisation (9 octobre, Aniimo) et ORION
    ecrivait sous un nom que le jeu ne lit pas."""
    h = 5381
    for c in nom.encode("utf-8"):
        h = ((h * 33) ^ c) & 0xFFFFFFFF
    return f"{nom}_h{h}"


def _apprise_perimee(data: dict) -> bool:
    """Niveaux de Baldur's Gate 3 appris avant le 10 octobre : seul
    « CurrentSettings » etait retenu (les options absentes du fichier, c'est-a-
    dire a leur valeur par defaut, n'etaient pas vues), et le jeu le recalcule
    au demarrage. Une telle recette ecrit un niveau que le jeu efface et fait
    dire « deja en place » : elle est ignoree, la fiche propose de reapprendre."""
    if not str(data.get("id") or "").startswith("exemple_"):
        return False
    if int((data.get("_appris") or {}).get("format") or 1) >= 2:
        return False
    for t in data.get("targets") or []:
        if any("graphicsettings.lsx" in str(c).lower() for c in t.get("paths") or []):
            return True
    return False


def load_recipes() -> list[Recipe]:
    """Recettes livrees + recettes personnelles (%LOCALAPPDATA%/ORION/recipes)."""
    ensure_dirs()
    out: list[Recipe] = []
    # ordre de chargement : livrees, communautaires, personnelles.
    # En cas d'egalite de score, la derniere chargee l'emporte, donc une
    # recette personnelle prime toujours sur une recette partagee.
    from . import securite
    empreintes = _empreintes_communautaires()
    livrees: set[str] = set()
    for folder in (RECIPE_BUILTIN_DIR, RECIPE_COMMUNITY_DIR, RECIPE_USER_DIR):
        if not folder.is_dir():
            continue
        partagee = folder == RECIPE_COMMUNITY_DIR
        for f in sorted(folder.glob("*.json")):
            if f.name.startswith("_"):
                continue
            try:
                brut = f.read_bytes()
                data = json.loads(brut.decode("utf-8"))
            except Exception:
                log.exception("Recette illisible : %s", f)
                continue
            if partagee:
                # une recette partagee modifiee sur le disque apres son
                # telechargement n'est plus celle qui a ete verifiee
                attendue = empreintes.get(str(data.get("id") or f.stem), "")
                # l'empreinte porte sur le texte : les fins de ligne de
                # Windows (CRLF), posees par l'ecriture du fichier, ne sont
                # pas une modification
                if attendue and securite.empreinte(brut.replace(b"\r\n", b"\n")) != attendue:
                    if f.name not in _RECETTES_SIGNALEES:
                        _RECETTES_SIGNALEES.add(f.name)
                        log.warning("Recette partagee modifiee localement, ignoree : %s", f.name)
                    continue
            ok, raisons = securite.verifier_recette(data, partagee=partagee)
            if not ok:
                log.warning("Recette refusee (%s) : %s", f.name, "; ".join(raisons[:4]))
                continue
            if _apprise_perimee(data):
                if f.name not in _RECETTES_SIGNALEES:
                    _RECETTES_SIGNALEES.add(f.name)
                    log.warning("Niveaux appris avant la 2.1.0 (Baldur's Gate 3), a refaire : %s", f.name)
                continue
            rid = str(data.get("id") or f.stem)
            if folder == RECIPE_BUILTIN_DIR:
                livrees.add(rid)
            elif partagee and rid in livrees:
                # la recette livree avec ORION fait reference : elle suit les
                # versions d'ORION, alors que la copie partagee du meme nom
                # peut dater. Les recettes partagees ajoutent des jeux, elles
                # ne remplacent pas celles d'ORION (une recette personnelle,
                # elle, garde toujours le dernier mot).
                continue
            out.append(Recipe(data, f))
    return out


def _empreintes_communautaires() -> dict[str, str]:
    try:
        etat = json.loads((RECIPE_COMMUNITY_DIR / "_index_local.json").read_text("utf-8"))
        return {rid: v.get("sha256", "") for rid, v in (etat.get("recipes") or {}).items()
                if isinstance(v, dict)}
    except Exception:
        return {}


def select_recipe(game: Game, recipes: list[Recipe] | None = None) -> Recipe | None:
    recipes = recipes if recipes is not None else load_recipes()
    scored = [(r.score(game), r) for r in recipes]
    scored = [(s, r) for s, r in scored if s > 0]
    if not scored:
        return None
    # a score egal, la derniere chargee l'emporte (livrees, puis partagees,
    # puis personnelles) : c'est ce qui laisse le dernier mot a une recette
    # personnelle. Le tri d'avant gardait la premiere, donc celle d'ORION.
    meilleur = max(s for s, _r in scored)
    return [r for s, r in scored if s == meilleur][-1]


# --------------------------------------------------------------------------
# Construction du plan
# --------------------------------------------------------------------------

def _fmt(template: str, ctx: dict[str, Any]) -> str:
    """Remplace {variable} sans planter si la variable manque."""
    out = str(template)
    for k, v in ctx.items():
        token = "{" + k + "}"
        if token in out:
            out = out.replace(token, str(v))
    return out


def _apply_derive(derive: dict, settings: dict) -> dict[str, str]:
    """Calcule les variables specifiques au moteur a partir des reglages."""
    out: dict[str, str] = {}
    for name, rule in (derive or {}).items():
        src = rule.get("from")
        raw = settings.get(src)
        key = str(raw).lower() if isinstance(raw, bool) else str(raw)
        mapping = rule.get("map") or {}
        if key in mapping:
            out[name] = str(mapping[key])
        elif "default" in rule:
            out[name] = str(rule["default"])
        elif rule.get("brut") and raw is not None:
            out[name] = key                   # valeur telle quelle hors des cas listes
    return out


def _cle_registre_existe(cle: str) -> bool:
    """Vrai si la cle de registre existe (toujours faux hors Windows)."""
    try:
        from ..core.paths import is_windows
        if not is_windows():
            return False
        from ..core.winutil import reg_open
        from ..plugins.tweaks.registry_writer import _split
        root, chemin = _split(cle)
        k = reg_open(root, chemin)
        if k is None:
            return False
        try:
            k.Close()
        except Exception:
            pass
        return True
    except Exception:
        return False


def _resolve_registry(patterns: list[str], ctx: dict, create: bool) -> list[str]:
    """Cles de registre : pas de fichier a chercher sur le disque (l'ancienne
    version testait `Path("HKCU/...").exists()`, toujours faux : la recette
    Unity n'etait jamais appliquee). Une cle dont une variable est vide
    (« HKCU/Software//Jeu ») est ecartee plutot que creee au hasard."""
    out: list[str] = []
    for pattern in patterns:
        if _variable_vide(pattern, ctx):
            continue
        raw = _fmt(pattern, ctx).replace("\\", "/")
        if "{" in raw or "//" in raw or raw.endswith("/") or not raw.strip():
            continue
        if create or _cle_registre_existe(raw):
            out.append(raw)
    return out


def _plus_recent(paths: list[str]) -> list[str]:
    """Fichier modifie le plus recemment en tete : quand un jeu a change de
    dossier de configuration (Unreal 4 -> 5 : WindowsNoEditor -> Windows),
    c'est celui que le jeu utilise encore."""
    def date(p: str) -> float:
        try:
            return Path(p).stat().st_mtime
        except OSError:
            return -1.0
    existants = [p for p in paths if date(p) >= 0]
    if len(existants) < 2:
        return paths
    return sorted(existants, key=date, reverse=True) + [p for p in paths
                                                         if p not in existants]


def _variable_vide(pattern: str, ctx: dict) -> bool:
    """Vrai si le chemin utilise une variable connue mais vide (dossier du
    jeu inconnu, projet Unreal introuvable...) : « {install_dir}/cfg »
    deviendrait « /cfg », a la racine du disque."""
    import re
    return any(nom in ctx and not str(ctx[nom] or "").strip()
               for nom in re.findall(r"{(\w+)}", pattern))


def _resolve_paths(patterns: list[str], ctx: dict, create: bool) -> list[str]:
    """Developpe variables, %VAR% et jokers ; garde les chemins existants."""
    found: list[str] = []
    for pattern in patterns:
        if _variable_vide(pattern, ctx):
            continue
        raw = _fmt(pattern, ctx)
        if "{" in raw:                     # variable non resolue
            continue
        if "//" in raw.replace("\\", "/").replace("://", ""):
            continue                       # variable vide (dossier inconnu)
        raw = str(expand(raw))
        if any(ch in raw for ch in "*?"):
            trouves = sorted(glob.glob(raw, recursive=True))
            if not trouves and create:
                # fichier a creer dans un dossier existant (autoexec.cfg)
                parent, nom = Path(raw).parent, Path(raw).name
                dossiers = [d for d in glob.glob(str(parent), recursive=True)
                            if est_dossier(d)]
                # un seul dossier possible, sinon on ne devine pas
                if len(dossiers) == 1 and not any(ch in nom for ch in "*?"):
                    trouves = [str(Path(dossiers[0]) / nom)]
            found.extend(trouves)
        else:
            p = Path(raw)
            if existe(p):
                found.append(str(p))
            elif create and existe(p.parent):
                found.append(str(p))
    # doublons elimines en conservant l'ordre
    seen: set[str] = set()
    out = []
    for f in found:
        k = f.lower()
        if k not in seen:
            seen.add(k)
            out.append(f)
    return out


class Optimizer:
    """Fabrique et applique les plans d'optimisation."""

    def __init__(self) -> None:
        self._writers: dict[str, TweakWriter] | None = None
        self._recipes: list[Recipe] | None = None
        #: resultat de la derniere relecture apres ecriture
        self.derniere_verification = None
        try:
            from .profiles import migrer_profil_par_defaut
            migrer_profil_par_defaut()
        except Exception:
            log.exception("Migration du profil par defaut impossible")

    @property
    def writers(self) -> dict[str, TweakWriter]:
        if self._writers is None:
            found = registry.discover(TweakWriter, "orion.plugins.tweaks", "tweaks")
            self._writers = {w.id: w for w in registry.available(found)}
            log.info("Formats de reglages : %s", list(self._writers))
        return self._writers

    @property
    def recipes(self) -> list[Recipe]:
        if self._recipes is None:
            self._recipes = load_recipes()
            log.info("%d recettes chargees", len(self._recipes))
        return self._recipes

    def reload(self) -> None:
        self._writers = None
        self._recipes = None

    # ------------------------------------------------------------------
    def build_plan(self, game: Game, profile_id: str, hw: HardwareInfo,
                   display: Display | None) -> OptimizationPlan:
        profile = PROFILES.get(profile_id) or PROFILES[profil_par_defaut()]
        mode = choose_display_mode(profile, hw, display) if display else None

        plan = OptimizationPlan(
            game_uid=game.uid, profile=profile.id,
            display_device=display.device if display else "",
            display_mode=mode,
            display_current=display.current if display else None,
        )

        # le moteur n'a pas toujours pu etre determine au moment du scan
        # (jeu en cours d'installation, dossier alors inaccessible) : on
        # retente ici, c'est ce qui decide de la recette utilisee.
        if not game.engine and game.install_dir:
            from ..plugins.scanners.base import detect_engine
            found = detect_engine(Path(game.install_dir))
            if found:
                game.engine = found
                log.info("Moteur detecte pour %s : %s", game.title, found)

        plan.reglages_prevus = 0          # couverture : voir fiabilite.couverture
        plan.generique = True
        recipe = select_recipe(game, self.recipes)
        capacites = list(recipe.capacites) if recipe else []
        noter_capacites(game, capacites)
        settings = compute_settings(profile, hw, display, game, capacites)
        self._noter_niveau(game, profile.id, settings)
        if recipe is None or not recipe.targets:
            # moteur inconnu : ORION apprend le fichier de reglages du jeu
            # (cles sures seulement, voir apprentissage.py)
            try:
                from . import apprentissage
                appris = apprentissage.apprendre(game, settings)
            except Exception:
                log.exception("Apprentissage impossible pour %s", game.title)
                appris = None
            if appris:
                recipe = Recipe(appris, Path("appris"))
        if recipe is None:
            plan.advice.append("Aucune recette disponible.")
            self._guider(plan, game, profile, hw, display)
            return plan
        plan.recipe_name = f"{recipe.name} ({recipe.origin_label})"
        plan.confidence = recipe.confidence
        plan.generique = not recipe.targets

        ctx: dict[str, Any] = dict(settings)
        ctx.update(context_for(game))
        ctx.update(_apply_derive(recipe.derive, settings))
        absents: list[str] = []

        for target in recipe.targets:
            fmt = target.get("format", "ini")
            writer = self.writers.get(fmt)
            if writer is None:
                continue
            if fmt == "registry":
                paths = _resolve_registry(target.get("paths", []), ctx,
                                          bool(target.get("create_if_missing")))
            else:
                paths = _resolve_paths(target.get("paths", []), ctx,
                                       bool(target.get("create_if_missing")))
            if fmt != "registry":
                from . import securite
                partagee = bool(recipe.community) or recipe.origin_label == "partagee"
                refuses = [p for p in paths if not securite.chemin_autorise(
                    p, game.install_dir or "", partagee)]
                if refuses:
                    log.warning("Recette %s : fichier(s) hors zone autorisee ignore(s) : %s",
                                recipe.id, refuses[:3])
                    paths = [p for p in paths if p not in refuses]
            if not paths:
                plan.reglages_prevus += len(target.get("entries", []))
                plan.advice.append(
                    f"Fichier de configuration introuvable pour ce jeu "
                    f"({recipe.name}) : seuls l'ecran et les conseils sont appliques.")
                continue
            if not target.get("all_matching", False):
                paths = _plus_recent(paths)[:1]

            for path in paths:
                ops_fichier: list[TweakOp] = []
                for entry in target.get("entries", []):
                    plan.reglages_prevus += 1
                    value = _fmt(entry.get("value", ""), ctx)
                    if "{" in value:
                        continue                # variable manquante : on saute
                    cle = entry.get("key", "")
                    if target.get("unity_prefs") and "_h" not in cle:
                        cle = cle_unity(cle)
                    op = TweakOp(
                        kind=fmt, target=path,
                        section=_fmt(entry.get("section", ""), ctx),
                        key=cle, value=value,
                        label=entry.get("label", entry.get("key", "")),
                    )
                    _lire(writer, op)
                    if op.current is None and not (recipe.creer_cles or entry.get("creer")):
                        absents.append(op.label or op.key)      # jamais une cle inventee
                        continue
                    plan.ops.append(op)
                    ops_fichier.append(op)
                if fmt == "ini" and ops_fichier:
                    # Unreal : le jeu lit la section de SA classe, pas celle
                    # d'Engine (Ready or Not restait en Epic) ; voir unreal.py
                    from . import unreal
                    from ..plugins.tweaks.ini_writer import lire_texte
                    texte, _enc, _eol = lire_texte(Path(path))
                    for op in unreal.ops_miroir(ops_fichier, texte):
                        _lire(writer, op)
                        plan.ops.append(op)

        plan.advice.extend(recipe.advice)
        if absents:
            plan.advice.append("Non ecrits, ce jeu n'a pas ces options dans son fichier : "
                               + ", ".join(absents[:6]) + (" ..." if len(absents) > 6 else "") + ".")
        reco = settings.get("recommande") or {}
        if reco and not reco.get("atteint") and reco.get("fps") \
                and "upscaler" not in (recipe.capacites if hasattr(recipe, "capacites") else []):
            plan.advice.insert(0, (
                f"Objectif de {reco.get('cible', 60)} images par seconde hors de portee "
                "au niveau retenu : si le jeu propose DLSS, FSR ou XeSS dans ses "
                "options, activez-le en mode Qualite ou Equilibre."))
        if not plan.tunable or recipe.confidence == "appris" or recipe.data.get("niveau_par_menu"):
            # rien d'ecrit, ou seulement les cles sures d'un fichier appris :
            # les niveaux de qualite se reglent dans le menu du jeu
            self._guider(plan, game, profile, hw, display, recipe)
        # la derniere ecriture d'ORION a-t-elle tenu ? (le jeu, son lanceur ou
        # Steam Cloud peuvent l'avoir remplacee)
        fiabilite.controler(game, plan)
        return plan

    def _guider(self, plan: OptimizationPlan, game: Game, profile, hw: HardwareInfo,
                display: Display | None, recipe=None) -> None:
        """ORION ne peut rien ecrire dans ce jeu : il prepare la liste des
        reglages a recopier dans ses menus. A la main, le joueur peut aussi
        activer DLSS, FSR ou XeSS, si le jeu en propose : le calcul en tient
        compte seulement quand la recette ou la fiche Steam le dit (15
        octobre : Rocket League, sans DLSS, se voyait conseiller « Ultra +
        DLSS Qualite »)."""
        from . import guide
        capacites = list(getattr(recipe, "capacites", None) or [])
        if "upscaler" not in capacites and self._propose_mise_a_l_echelle(game):
            capacites.append("upscaler")
        noter_capacites(game, capacites)
        settings = compute_settings(profile, hw, display, game, capacites)
        self._noter_niveau(game, profile.id, settings)
        plan.guide = guide.lignes(settings)

    @staticmethod
    def _propose_mise_a_l_echelle(game: Game) -> bool:
        """La fiche Steam du jeu cite DLSS, FSR, XeSS, TSR ou un upscaling."""
        try:
            from ..optimizer.recommande import appid_steam
            from ..puissance import exigences
            appid = appid_steam(game)
            exig = exigences.en_cache(appid) if appid else None
            return bool(exig and exig.mise_a_l_echelle)
        except Exception:
            return False

    @staticmethod
    def _noter_niveau(game: Game, profil: str, settings: dict) -> None:
        """Retient le niveau applique : une mesure prise ensuite saura a quel
        niveau le jeu tournait (indispensable pour « Recommande »)."""
        try:
            from ..perf.store import noter_reglage
            from .recommande import NIVEAU_DE_QUALITE
            reco = settings.get("recommande") or {}
            niveau = reco.get("niveau") or NIVEAU_DE_QUALITE.get(
                int(settings.get("quality", 2)), "haute")
            echelle = int(settings.get("resolution_scale") or 100)
            mode = reco.get("mode") if reco else "off"
            if not reco and echelle < 100:
                mode = {67: "quality", 58: "balanced", 50: "performance"}.get(echelle, "off")
            noter_reglage(game.uid, profil, niveau, mode or "off", echelle)
            if reco:
                game.extra["recommande"] = {k: reco.get(k) for k in
                                            ("niveau", "conseille", "cible", "resume",
                                             "source", "atteint")}
        except Exception:
            log.debug("Niveau applique non note", exc_info=True)

    def statut(self, game: Game, plan: OptimizationPlan | None) -> "fiabilite.Statut":
        """Etat clair a afficher sur la fiche (voir optimizer/fiabilite.py)."""
        return fiabilite.statut(plan, game)

    def relire(self, plan: OptimizationPlan) -> bool:
        """Relit les valeurs actuelles des fichiers du plan.

        Un plan est construit a l'ouverture de la fiche ; entre-temps le jeu
        (ou son lanceur, ou Steam Cloud) a pu reecrire ses fichiers. Sans
        cette relecture, un reglage remis a l'ancienne valeur par le jeu
        passait pour « deja en place » et n'etait plus reecrit au
        lancement. Retourne `plan.has_changes`."""
        for op in plan.ops:
            writer = self.writers.get(op.kind)
            if writer is not None and op.kind != "note":
                _lire(writer, op)
        return plan.has_changes


    def bilan_apres_partie(self, game: Game, hw: HardwareInfo,
                           display: Display | None = None) -> int:
        """Fin de partie : le jeu a-t-il garde les reglages d'ORION ?

        Reconstruit le plan du profil du jeu (ce qui relit ses fichiers) et
        met a jour l'etat affiche sur la fiche (« Le jeu a modifie N
        reglage(s) », puis « gere par le jeu » si cela se repete). Sans
        fenetre : appelable depuis le fil de surveillance de la partie."""
        if display is None:
            display = next((d for d in hw.displays
                            if d.device == game.preferred_display), None) \
                or hw.primary_display
        profil = game.preferred_profile or profil_par_defaut()
        plan = self.build_plan(game, profil, hw, display)
        memo = game.extra.get(fiabilite.CLE) or {}
        return int(memo.get("modifies", 0)) if plan.ops else 0

    # ------------------------------------------------------------------
    def apply_plan(self, game: Game, plan: OptimizationPlan) -> tuple[bool, str]:
        """Ecrit les reglages, apres sauvegarde. Retourne (succes, message).

        Rien n'est ecrit tant que le jeu (ou son lanceur) tourne
        (`securite.jeu_ouvert`). Un fichier en lecture seule ou illisible
        n'empeche plus d'ecrire les autres : chaque format est tente, puis tout est relu. `succes` est
        faux des qu'un reglage n'a pas pu etre ecrit (le message dit
        lesquels) ; la fenetre peut quand meme lancer le jeu."""
        self.relire(plan)
        ops = [o for o in plan.ops if o.kind != "note" and o.changed]
        if not ops:
            return True, "Reglages deja en place"
        from . import securite
        if securite.jeu_ouvert(game):
            # anti-triche : jamais une ecriture pendant une partie (et le jeu
            # reecrirait ses reglages en se fermant)
            log.info("%s est ouvert : reglages non ecrits", game.title)
            return False, (f"{game.title} est ouvert : ORION ne modifie jamais les reglages d'un jeu "
                           f"pendant qu'il tourne. Fermez-le, ils seront ecrits au prochain lancement "
                           f"depuis ORION.")

        backup_path = ""
        if CONFIG.get("optimizer.backup_before_write", True):
            try:
                backup_path = backup_mod.create(game, ops)
            except Exception:
                log.exception("Sauvegarde impossible : aucun reglage ecrit")
                return False, ("Sauvegarde des fichiers du jeu impossible : ORION "
                               "n'a rien modifie.")

        total = 0
        erreurs: list[str] = []
        by_kind: dict[str, list[TweakOp]] = {}
        for op in ops:
            by_kind.setdefault(op.kind, []).append(op)

        for kind, items in by_kind.items():
            writer = self.writers.get(kind)
            if writer is None:
                erreurs.append(f"format « {kind} » indisponible")
                continue
            try:
                count, message = writer.write(items)
            except Exception as exc:
                log.exception("Ecriture %s impossible", kind)
                count, message = 0, str(exc)
            total += count
            if count < len(items):
                erreurs.append(message)

        # relecture : un reglage annonce doit etre reellement dans le fichier
        verif = fiabilite.verifier(ops, self.writers)
        self.derniere_verification = verif
        for op in plan.ops:
            if op.kind != "note" and op not in verif.refuses:
                op.current = op.value
        fiabilite.memoriser(game, plan, verif.refuses)
        ok = not erreurs and verif.ok
        BUS.emit(TWEAKS_APPLIED, uid=game.uid, count=total, ok=ok)
        msg = verif.message
        if erreurs:
            msg = " ; ".join(dict.fromkeys(erreurs)) + " - " + msg
        if backup_path:
            msg += " - sauvegarde creee"
        return ok, msg


def _lire(writer: TweakWriter, op: TweakOp) -> None:
    """Valeur actuelle de l'operation. Une valeur equivalente (« 2 » et
    « 2.000000 », « true » et « True ») est consideree comme deja en place :
    sinon le plan annoncait des modifications a chaque lancement."""
    try:
        op.current = writer.read(op)
    except Exception:
        op.current = None
    if op.current is not None and fiabilite.meme_valeur(op.current, op.value):
        op.current = op.value
