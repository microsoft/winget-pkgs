"""Service de visuels : orchestre les fournisseurs et le cache disque."""
from __future__ import annotations

from pathlib import Path
from typing import Callable, Iterable

from .core import registry
from .core.config import CONFIG
from .core.events import ART_UPDATED, BUS
from .core.logging_setup import get
from .core.models import Game
from .plugins.artwork.base import image_vide, KINDS, ArtworkProvider

log = get("artwork.service")


def dominant_color(image_path: str) -> str:
    """Couleur dominante d'une image, utilisee comme teinte de la fiche."""
    try:
        from PySide6.QtGui import QImage

        img = QImage(image_path)
        if img.isNull():
            return ""
        small = img.scaled(24, 24).convertToFormat(QImage.Format.Format_RGB32)
        best, best_score = (60, 60, 70), -1.0
        for y in range(small.height()):
            for x in range(small.width()):
                c = small.pixelColor(x, y)
                r, g, b = c.red(), c.green(), c.blue()
                mx, mn = max(r, g, b), min(r, g, b)
                sat = (mx - mn) / 255.0
                lum = mx / 255.0
                # on privilegie les couleurs vives sans etre cramees
                score = sat * 1.6 + (1.0 - abs(lum - 0.55)) * 0.8
                if score > best_score:
                    best_score, best = score, (r, g, b)
        r, g, b = best
        return f"#{r:02x}{g:02x}{b:02x}"
    except Exception:
        return ""


#: un visuel introuvable n'est pas redemande avant ce delai
ABSENT_GARDER = 3 * 24 * 3600


def _hors_ligne() -> bool:
    try:
        from .core import reseau
        return bool(reseau._hors_ligne)
    except Exception:
        return False


class ArtworkService:
    """Recupere jaquette / banniere / logo / icone pour un jeu."""

    def __init__(self) -> None:
        self._providers: list[ArtworkProvider] | None = None

    @property
    def providers(self) -> list[ArtworkProvider]:
        if self._providers is None:
            found = registry.discover(ArtworkProvider, "orion.plugins.artwork", "artwork")
            self._providers = registry.available(found)
            log.info("Fournisseurs de visuels : %s", [p.id for p in self._providers])
        return self._providers

    def reload_plugins(self) -> None:
        self._providers = None

    # ------------------------------------------------------------------
    def missing_kinds(self, game: Game, tout: bool = False) -> set[str]:
        """Visuels a chercher. Un visuel introuvable recemment n'est pas
        redemande a chaque demarrage (`tout=True` pour l'inclure quand meme)."""
        import time
        absents = game.extra.get("art_absent")
        absents = absents if isinstance(absents, dict) else {}
        maintenant = time.time()
        want = set()
        for kind in KINDS:
            current = getattr(game, f"art_{kind}", "")
            if not current or not Path(current).exists() or image_vide(current):
                try:
                    recent = 0 <= maintenant - float(absents.get(kind) or 0) < ABSENT_GARDER
                except (TypeError, ValueError):
                    recent = False
                if tout or not recent:
                    want.add(kind)
        return want

    def ensure(self, game: Game, force: bool = False,
               kinds: set[str] | None = None) -> bool:
        """Complete les visuels manquants. Retourne True si quelque chose a change.
        `kinds` limite la recherche (la jaquette d'abord, le reste ensuite)."""
        if not CONFIG.get("artwork.enabled", True):
            return False
        if force:
            game.extra.pop("art_absent", None)
        want = set(KINDS) if force else self.missing_kinds(game)
        if kinds is not None:
            want &= set(kinds)
        if not want:
            return False

        changed = False
        for prov in self.providers:
            if not want:
                break
            try:
                got = prov.fetch(game, want) or {}
            except Exception:
                log.exception("Fournisseur en echec : %s", prov.id)
                continue
            for kind, path in got.items():
                if kind in KINDS and path and Path(path).exists():
                    setattr(game, f"art_{kind}", path)
                    want.discard(kind)
                    changed = True

        # introuvable alors que le reseau repond : inutile d'insister avant
        # quelques jours (« Rafraichir les visuels » repart de zero)
        if want and not _hors_ligne():
            import time
            absents = game.extra.get("art_absent")
            if not isinstance(absents, dict):
                absents = game.extra["art_absent"] = {}
            for kind in want:
                absents[kind] = time.time()

        if changed and not game.accent_color:
            src = game.art_cover or game.art_hero or game.art_icon
            if src:
                game.accent_color = dominant_color(src)
        if changed:
            BUS.emit(ART_UPDATED, uid=game.uid)
        return changed

    def ensure_many(self, games: Iterable[Game],
                    progress_cb: Callable[[str, int], None] | None = None) -> int:
        """Traite une liste de jeux en parallele (reseau essentiellement)."""
        from concurrent.futures import ThreadPoolExecutor, as_completed

        games = [g for g in games if self.missing_kinds(g)]
        if not games:
            return 0
        workers = max(1, int(CONFIG.get("artwork.max_parallel", 6)))
        done = 0
        modifies: set[str] = set()
        # deux passes : les jaquettes de tous les jeux (ce que montre la
        # grille), dans l'ordre recu, puis bannieres, logos et icones
        passes = [({"cover"}, [g for g in games if "cover" in self.missing_kinds(g)]),
                  (set(KINDS) - {"cover"}, games)]
        total = sum(len(liste) for _, liste in passes) or 1
        with ThreadPoolExecutor(max_workers=workers) as pool:
            for kinds, liste in passes:
                futures = {pool.submit(self.ensure, g, False, kinds): g for g in liste}
                for fut in as_completed(futures):
                    done += 1
                    g = futures[fut]
                    try:
                        if fut.result():
                            modifies.add(g.uid)
                    except Exception:
                        pass
                    if progress_cb:
                        progress_cb(f"Visuels : {g.title}", int(done / total * 100))
        log.info("Visuels completes pour %d jeux", len(modifies))
        return len(modifies)
