"""Tests d'existence qui ne plantent jamais.

15 octobre 2026 (journal de l'auteur) : un jeu deplace par ORION sur un
disque F: laisse une jonction `steamapps\\common\\Undisputed` -> `F:\\Jeux
ORION\\Undisputed`. Le disque debranche, `Path.exists()` et `Path.is_dir()`
sur la jonction levent `OSError [WinError 1] Fonction incorrecte` (pathlib
n'avale que « fichier introuvable »), et tout ce qui passait par la s'arretait
net : le scan de la bibliotheque, la veille des installations, la remise en
ordre des deplacements. Ici, un chemin qui ne se laisse pas interroger est
tenu pour absent, et le jeu suivant est examine.
"""
from __future__ import annotations

import os
from pathlib import Path


def existe(chemin) -> bool:
    """Comme `Path.exists()`, mais False (jamais une exception) quand le
    disque ne repond pas, la jonction est morte ou l'acces est refuse."""
    try:
        return os.path.exists(chemin)
    except (OSError, ValueError):
        return False


def est_dossier(chemin) -> bool:
    """Comme `Path.is_dir()`, sans exception (voir `existe`)."""
    try:
        return os.path.isdir(chemin)
    except (OSError, ValueError):
        return False


def est_fichier(chemin) -> bool:
    try:
        return os.path.isfile(chemin)
    except (OSError, ValueError):
        return False


def lecteur_absent(chemin) -> bool:
    """Vrai quand la racine du chemin (le disque) n'est pas la : un jeu
    deplace sur un disque externe debranche, par exemple."""
    try:
        racine = Path(chemin).anchor
        return bool(racine) and not os.path.exists(racine)
    except (OSError, ValueError):
        return True
