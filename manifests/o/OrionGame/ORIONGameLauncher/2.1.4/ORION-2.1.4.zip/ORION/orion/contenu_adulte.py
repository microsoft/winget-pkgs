"""Jeux « reserves aux adultes » : une seule regle pour toute l'application.

ORION ne montre ni captures, ni videos, ni offres de ces jeux, quelle que
soit la boutique ou la plateforme d'ou vient l'information.

Le principe, pour que la regle tienne aussi pour une source ajoutee demain :

* chaque source (boutique, jeux gratuits, fiche d'un jeu) se contente de
  **signaler** ce qu'elle sait, avec `produit_adulte(brut)` sur ce que sa
  plateforme lui a renvoye. Elle n'a aucune decision a prendre ;
* la decision est prise **a un seul endroit par famille**, la ou toutes les
  sources se rejoignent : `visibles()` pour la Boutique et les jeux gratuits,
  `MarketService.get()` pour la fiche d'un jeu. Une source qui oublierait de
  signaler est encore rattrapee par les etiquettes et les fiches Steam ;
* les tests (`tests/test_contenu_adulte.py`) parcourent toutes les sources
  enregistrees : une source sans declaration `filtre_adulte` fait echouer la
  suite.

Ce qui est filtre : les jeux pornographiques (descripteur Steam n° 3 « Adult
Only Sexual Content », etiquette « Hentai », « NSFW » accompagne de « Sexual
Content » ou « Nudity », drapeau « mature » d'IsThereAnyDeal...). Ce qui ne
l'est pas : les jeux grand public classes 18 ans (violence, nudite
ponctuelle, « Mature », « Sexual Content » ou « NSFW » seuls), qui gardent
captures et bandes-annonces.
"""
from __future__ import annotations

import logging
import re
import threading
import unicodedata

log = logging.getLogger(__name__)

#: descripteurs de contenu Steam qui designent un jeu reserve aux adultes
IDS_ADULTES = frozenset({3})

#: etiquettes et genres qui designent un jeu reserve aux adultes, toutes
#: plateformes confondues (compares sans casse, accents ni ponctuation).
#: « mature », « nudity », « sexual content » n'y sont pas : des jeux grand
#: public les portent.
MARQUEURS = frozenset({
    "adult", "adults", "adulte", "adultes", "adult only", "adults only",
    "adult only sexual content", "adult content", "contenu adulte",
    "reserve aux adultes", "pour adultes", "hentai", "eroge", "porn", "porno",
    "pornographic", "pornographique", "pornography", "xxx", "r18", "18 adult",
})

#: etiquettes ambigues : les boutiques les posent aussi sur des jeux grand
#: public violents (verifie sur le catalogue GOG le 04/10/2026 : « NSFW » sur
#: POSTAL 2, a cote de « Violent » et « Gore »). Seules, elles ne suffisent
#: pas ; accompagnees d'une etiquette de contenu sexuel, elles designent bien
#: un jeu reserve aux adultes (« NSFW » + « Sexual Content » + « Nudity »).
AMBIGUS = frozenset({"nsfw", "not safe for work"})
SEXUELS = frozenset({
    "sexual content", "nudity", "erotic", "erotica", "contenu sexuel", "nudite",
    "contenu a caractere sexuel", "erotique", "sexual", "sex", "ecchi",
})

#: cles d'un produit brut qui portent un drapeau « adulte » selon les
#: plateformes (IsThereAnyDeal : mature ; d'autres : adult, nsfw...)
DRAPEAUX = ("mature", "adult", "adults_only", "adultOnly", "adult_only",
            "isAdult", "is_adult", "nsfw", "isNsfw", "is_nsfw", "hasAdultContent")

#: cles d'un produit brut qui portent des etiquettes ou des genres
LISTES = ("tags", "genres", "categories", "features", "labels", "keywords",
          "themes", "etiquettes")

NOTE = "Captures et videos masquees : jeu reserve aux adultes."

#: cle rangee dans `game.extra` quand la fiche du jeu est marquee
CLE = "contenu_adulte"


def _norme(texte) -> str:
    brut = unicodedata.normalize("NFKD", str(texte or ""))
    brut = "".join(c for c in brut if not unicodedata.combining(c)).lower()
    return re.sub(r"[^a-z0-9]+", " ", brut).strip()


def _textes(valeur):
    """Tous les libelles d'une valeur : texte, liste, ou dictionnaires
    `{name, slug, description, label}` comme en renvoient les boutiques."""
    if valeur is None or isinstance(valeur, bool):
        return
    if isinstance(valeur, (str, int)):
        yield str(valeur)
    elif isinstance(valeur, dict):
        # L'identifiant stable d'abord : le libelle affiche change avec la
        # langue du joueur (GOG ecrit « Adulte » en francais la ou son
        # identifiant reste « nsfw »). Un libelle traduit ne doit jamais
        # decider seul quand l'identifiant existe.
        slug = valeur.get("slug")
        if isinstance(slug, str) and slug.strip():
            yield slug
            return
        for cle in ("name", "nom", "description", "label", "title", "id"):
            if valeur.get(cle) is not None and not isinstance(valeur.get(cle), (dict, list)):
                yield str(valeur[cle])
    elif isinstance(valeur, (list, tuple, set, frozenset)):
        for v in valeur:
            yield from _textes(v)


def signale(*valeurs, surs_seulement: bool = False) -> bool:
    """Vrai si une des etiquettes donnees designe un jeu reserve aux adultes.
    Accepte des textes, des listes et des dictionnaires d'etiquettes.
    `surs_seulement` : sans la regle des etiquettes ambigues (quand une
    information plus fiable, les descripteurs Steam, est deja connue)."""
    vus = {_norme(texte) for valeur in valeurs for texte in _textes(valeur)}
    if vus & MARQUEURS:
        return True
    return bool(not surs_seulement and vus & AMBIGUS and vus & SEXUELS)


def fiche_adulte(data) -> bool:
    """Vrai si une fiche Steam (`appdetails`) est celle d'un jeu reserve aux
    adultes : descripteur de contenu, ou etiquettes."""
    if not isinstance(data, dict):
        return False
    bloc = data.get("content_descriptors")
    ids = set()
    if isinstance(bloc, dict):
        bloc = bloc.get("ids")
    for brut in (bloc if isinstance(bloc, (list, tuple)) else []) \
            + list(data.get("content_descriptorids") or []):
        try:
            ids.add(int(brut))
        except (TypeError, ValueError):
            continue
    if ids & IDS_ADULTES:
        return True
    # Steam a classe le jeu (il porte des descripteurs) et ne l'a pas dit
    # reserve aux adultes : les etiquettes posees par les joueurs (« NSFW »,
    # « Nudite ») ne suffisent pas a le contredire.
    return signale(data.get("genres"), data.get("tags"), surs_seulement=bool(ids))


def produit_adulte(brut) -> bool:
    """Vrai si un produit, tel que sa boutique le renvoie, est reserve aux
    adultes. Fonctionne pour n'importe quelle plateforme : drapeaux
    (« mature », « adult », « nsfw »...), etiquettes, genres, descripteurs."""
    if not isinstance(brut, dict):
        return False
    for cle in DRAPEAUX:
        v = brut.get(cle)
        if v is True or (isinstance(v, (str, int)) and str(v).lower() in ("1", "true", "yes")):
            return True
    if fiche_adulte(brut):
        return True
    classe = bool(brut.get("content_descriptorids")) or bool(
        (brut.get("content_descriptors") or {}).get("ids")
        if isinstance(brut.get("content_descriptors"), dict) else False)
    return signale(*(brut.get(cle) for cle in LISTES), surs_seulement=classe)


def visibles(elements, adulte=lambda e: getattr(e, "adulte", False)):
    """Les elements (offres, fiches, jeux gratuits) qu'ORION peut montrer."""
    return [e for e in elements if not adulte(e)]


# --------------------------------------------------------------------------
# Memoire : la fiche d'un jeu et ses bandes-annonces sont demandees
# separement, l'une peut arriver avant l'autre
# --------------------------------------------------------------------------
def _table():
    from .core.base import Table
    return Table("contenu_adulte")


#: les identifiants marques, lus une fois par session : `est_marque` est
#: appele depuis le fil graphique (ouverture d'une fiche, cartes de la
#: Boutique) et une lecture dans la base attend le verrou que tient un
#: releve en cours (15 octobre : 223 ms figes sur une seule fiche)
_marques: set[str] | None = None
_verrou = threading.Lock()


def _connus() -> set[str]:
    global _marques
    with _verrou:
        if _marques is None:
            try:
                _marques = {str(k) for k, v in _table().items() if v}
            except Exception:
                log.debug("Liste des jeux adultes illisible", exc_info=True)
                return set()
        return _marques


def oublier_cache() -> None:
    """Pour les essais : la liste sera relue dans la base."""
    global _marques
    with _verrou:
        _marques = None


def marquer(appid, adulte: bool = True) -> None:
    """Retient qu'un jeu Steam est (ou n'est plus) reserve aux adultes.
    N'ecrit que si l'etat change : appelable a chaque fiche lue."""
    appid = str(appid or "").strip()
    if not appid:
        return
    try:
        connus = _connus()
        connu = appid in connus
        if adulte and not connu:
            _table().set(appid, True)
            with _verrou:
                connus.add(appid)
        elif connu and not adulte:
            _table().supprimer(appid)
            with _verrou:
                connus.discard(appid)
    except Exception:
        log.debug("Marquage adulte impossible pour %s", appid, exc_info=True)


def observer(appid, data) -> bool:
    """Appele pour TOUTE fiche Steam lue par ORION, par le passage commun
    (`core.steam_limite.fiche`) : le module qui a demande la fiche n'a rien a
    faire. Ne conclut que si la fiche porte ses descripteurs de contenu (une
    fiche reduite aux prix ne dit rien). Retourne vrai si le jeu est marque."""
    if not isinstance(data, dict):
        return False
    if "content_descriptors" in data or "content_descriptorids" in data:
        marquer(appid, fiche_adulte(data))
    return est_marque(appid)


def resultat_adulte(brut, *identifiants) -> bool:
    """Un resultat de recherche ou de liste, tel que recu d'une plateforme :
    signale par la plateforme elle-meme, ou deja connu d'ORION."""
    if produit_adulte(brut):
        return True
    cles = list(identifiants)
    if isinstance(brut, dict):
        cles += [brut.get(c) for c in ("appid", "steam_appid", "id")]
    return any(est_marque(c) for c in cles if c)


def est_marque(appid) -> bool:
    appid = str(appid or "").strip()
    if not appid:
        return False
    return appid in _connus()


def jeu_adulte(game, appid="") -> bool:
    """Vrai si ce jeu de la bibliotheque est marque, par lui-meme ou par sa
    fiche Steam."""
    extra = getattr(game, "extra", None) or {}
    if extra.get(CLE):
        return True
    return est_marque(appid or extra.get("steam_appid") or "")
