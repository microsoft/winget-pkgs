"""Fichiers de commandes console (moteur Source, idTech, autoexec.cfg)."""
from __future__ import annotations

import os
import re
from pathlib import Path

from ...core.logging_setup import get
from ...core.models import TweakOp
from .base import TweakWriter

log = get("tweaks.cfg")

MARK_START = "// --- ORION : debut du bloc genere ---"
MARK_END = "// --- ORION : fin du bloc genere ---"


def _bloc_existant(text: str) -> dict[str, str]:
    """Commandes du bloc ORION deja present (ordre conserve)."""
    m = re.search(rf"{re.escape(MARK_START)}(.*?){re.escape(MARK_END)}", text, re.S)
    sortie: dict[str, str] = {}
    if not m:
        return sortie
    for ligne in m.group(1).splitlines():
        ligne = ligne.strip()
        if not ligne or ligne.startswith("//"):
            continue
        cle, _, valeur = ligne.partition(" ")
        sortie[cle] = valeur.strip()
    return sortie


class CfgWriter(TweakWriter):
    id = "cfg"
    label = "Fichier de commandes"

    def read(self, op: TweakOp) -> str | None:
        try:
            text = Path(op.target).read_text("utf-8", errors="ignore")
        except OSError:
            return None
        # le moteur execute les lignes dans l'ordre : c'est la DERNIERE
        # definition de la commande qui compte (le bloc d'ORION est en fin
        # de fichier, apres les reglages du joueur)
        trouves = re.findall(rf"^\s*{re.escape(op.key)}\s+\"?([^\"\r\n]+?)\"?\s*$",
                             text, re.M | re.I)
        return trouves[-1].strip() if trouves else None

    def write(self, ops: list[TweakOp]) -> tuple[int, str]:
        by_file: dict[str, list[TweakOp]] = {}
        for op in ops:
            by_file.setdefault(op.target, []).append(op)

        written = 0
        for target, items in by_file.items():
            path = Path(target)
            try:
                text = path.read_text("utf-8", errors="ignore") if path.exists() else ""
            except OSError:
                text = ""
            # l'ancien bloc genere est remplace (jamais de doublons), mais ses
            # commandes sont conservees : ORION n'ecrit que les reglages qui
            # changent, l'ancienne version effacait donc tous les autres a
            # la deuxieme application
            commandes = _bloc_existant(text)
            for op in items:
                commandes[op.key] = str(op.value)
            text = re.sub(rf"{re.escape(MARK_START)}.*?{re.escape(MARK_END)}\r?\n?",
                          "", text, flags=re.S)
            block = [MARK_START] + [f"{k} {v}" for k, v in commandes.items()] + [MARK_END]
            if path.exists() and not os.access(path, os.W_OK):
                return written, (f"{path.name} est en lecture seule : ORION ne le "
                                 "force pas.")
            tete = text.rstrip()
            try:
                path.parent.mkdir(parents=True, exist_ok=True)
                provisoire = path.with_name(path.name + ".orion.tmp")
                provisoire.write_text((tete + "\n\n" if tete else "")
                                      + "\n".join(block) + "\n", "utf-8")
                os.replace(provisoire, path)
                written += len(items)
            except Exception as exc:
                log.exception("Ecriture cfg impossible : %s", path)
                return written, f"Ecriture impossible dans {path.name} : {exc}"
        return written, "Commandes ecrites"
