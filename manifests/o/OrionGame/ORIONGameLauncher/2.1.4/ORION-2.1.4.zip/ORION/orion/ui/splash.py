"""Ecran de demarrage.

Le premier lancement demande quelques secondes : lecture de la
bibliotheque, detection du materiel, chargement des extensions. Plutot
qu'une fenetre vide, ORION montre son identite et dit ou il en est.

L'ecran se dessine entierement : ni image a decouper, ni feuille de style,
pour qu'il s'affiche avant meme que le theme ne soit applique.
"""
from __future__ import annotations

from PySide6.QtCore import QRectF, Qt, QTimer
from PySide6.QtGui import (QBrush, QColor, QFont, QLinearGradient, QPainter,
                           QPainterPath, QPixmap)
from PySide6.QtWidgets import QApplication, QWidget

from ..core.paths import ASSETS_DIR
from ..version import APP_NAME, APP_TAGLINE, APP_VERSION
from .theme import PALETTE, accent

WIDTH = 560
HEIGHT = 300
RADIUS = 16


class Splash(QWidget):
    """Fenetre sans bordure affichee pendant le demarrage."""

    def __init__(self) -> None:
        super().__init__(None, Qt.WindowType.FramelessWindowHint
                         | Qt.WindowType.SplashScreen
                         | Qt.WindowType.WindowStaysOnTopHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setFixedSize(WIDTH, HEIGHT)
        self._message = "Demarrage..."
        self._tick = 0

        self._logo = QPixmap(str(ASSETS_DIR / "orion.png"))
        self._art = QPixmap(str(ASSETS_DIR / "fond.jpg"))
        if not self._art.isNull():
            self._art = self._art.scaled(
                WIDTH, HEIGHT, Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                Qt.TransformationMode.SmoothTransformation)

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._animate)
        self._timer.start(40)
        self._center()

    def _center(self) -> None:
        screen = QApplication.primaryScreen()
        if screen is not None:
            zone = screen.availableGeometry()
            self.move(zone.center().x() - WIDTH // 2,
                      zone.center().y() - HEIGHT // 2)

    def _animate(self) -> None:
        self._tick = (self._tick + 1) % 200
        self.update()

    # ------------------------------------------------------------------
    def message(self, text: str) -> None:
        """Ligne d'etat, sous le nom."""
        self._message = text
        self.update()
        QApplication.processEvents()

    def finish(self, window=None) -> None:
        self._timer.stop()
        self.close()
        if window is not None:
            window.raise_()
            window.activateWindow()

    # ------------------------------------------------------------------
    def paintEvent(self, event) -> None:            # noqa: N802 (API Qt)
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = QRectF(0, 0, WIDTH, HEIGHT)

        path = QPainterPath()
        path.addRoundedRect(rect, RADIUS, RADIUS)
        p.setClipPath(path)

        p.fillRect(rect, QColor(PALETTE["bg"]))
        if not self._art.isNull():
            p.drawPixmap(int((WIDTH - self._art.width()) / 2),
                         int((HEIGHT - self._art.height()) / 2), self._art)
        veil = QLinearGradient(0, 0, WIDTH, HEIGHT)
        veil.setColorAt(0.0, QColor(7, 10, 17, 236))
        veil.setColorAt(1.0, QColor(7, 10, 17, 178))
        p.fillRect(rect, QBrush(veil))

        if not self._logo.isNull():
            logo = self._logo.scaled(76, 76, Qt.AspectRatioMode.KeepAspectRatio,
                                     Qt.TransformationMode.SmoothTransformation)
            p.drawPixmap(46, 62, logo)

        left = 148
        p.setPen(QColor(PALETTE["text"]))
        name = QFont("Segoe UI", 34)
        name.setBold(True)
        name.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 6)
        p.setFont(name)
        p.drawText(left, 108, APP_NAME)

        p.setPen(QColor(accent()))
        tag = QFont("Segoe UI", 9)
        tag.setBold(True)
        tag.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 4)
        p.setFont(tag)
        p.drawText(left + 3, 130, APP_TAGLINE.upper())

        p.setPen(QColor(PALETTE["text_dim"]))
        p.setFont(QFont("Segoe UI", 9))
        p.drawText(left + 3, 160, self._message)

        # barre d'attente : un segment qui balaie la largeur
        bar_y = HEIGHT - 52
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(255, 255, 255, 24))
        p.drawRoundedRect(QRectF(left, bar_y, WIDTH - left - 46, 3), 2, 2)

        span = WIDTH - left - 46
        width = span * 0.32
        travel = (self._tick / 200.0) * (span + width) - width
        start = max(left, left + travel)
        end = min(left + span, left + travel + width)
        if end > start:
            color = QColor(accent())
            p.setBrush(color)
            p.drawRoundedRect(QRectF(start, bar_y, end - start, 3), 2, 2)

        p.setPen(QColor(PALETTE["text_faint"]))
        p.setFont(QFont("Segoe UI", 8))
        p.drawText(left, HEIGHT - 26, f"version {APP_VERSION}")
        p.end()
