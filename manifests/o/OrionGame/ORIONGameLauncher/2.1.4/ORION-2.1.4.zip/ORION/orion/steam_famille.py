"""Jeux de la famille Steam (2.1.2, demande de l'auteur le 12 octobre 2026).

Steam affiche dans la bibliotheque les jeux que la famille Steam prete :
ORION les trouvait aussi (WRC 10 chez l'auteur, le plus cher de sa carte de
joueur) sans dire qu'ils ne sont pas a lui. Ils restent comptes, mais sont
marques « (Steam Family) » sur la carte de joueur et dans la liste de la
valeur, et la bibliotheque peut les montrer ou non.

Comment ORION le sait, sans rien deviner :

* **jeu installe** : son manifeste (`appmanifest_<appid>.acf`) donne
  `LastOwner`, le compte Steam dont la licence a servi. Si ce n'est aucun
  des comptes de ce PC (dossiers `userdata`), le jeu est prete ;
* **jeu non installe** (vu dans la bibliotheque Steam, `appcache`) : il
  est prete s'il n'est pas dans la liste des jeux du compte Steam connecte
  dans ORION (page Comptes) **et** s'il est payant. Sans compte connecte,
  ORION ne peut pas le savoir et ne marque rien ; un jeu gratuit n'est
  jamais marque (il n'est pas dans cette liste quand on n'y a jamais joue).
"""
from __future__ import annotations

from pathlib import Path

from .core.logging_setup import get

log = get("steam_famille")

#: SteamID64 = cette base + l'identifiant de compte (nom du dossier `userdata`)
BASE_STEAMID64 = 76561197960265728
#: drapeaux poses dans `Game.extra`
PRETE = "steam_famille"                   # certain (manifeste)
HORS_COMPTE = "steam_hors_compte"         # pas dans la liste du compte : prete s'il est payant
MENTION = "Steam Family"


def comptes_locaux(racine: Path | None) -> set[str]:
    """SteamID64 des comptes Steam de ce PC."""
    ids: set[str] = set()
    if racine is None:
        return ids
    userdata = Path(racine) / "userdata"
    if userdata.is_dir():
        for d in userdata.iterdir():
            if d.is_dir() and d.name.isdigit() and d.name != "0":
                ids.add(str(BASE_STEAMID64 + int(d.name)))
    try:
        from .core.winutil import read_vdf
        donnees = read_vdf(Path(racine) / "config" / "loginusers.vdf")
        for cle in (donnees.get("users") or donnees.get("Users") or {}):
            if str(cle).isdigit():
                ids.add(str(cle))
    except Exception:
        log.debug("loginusers.vdf illisible", exc_info=True)
    return ids


def prete(dernier_proprietaire: str, locaux: set[str]) -> bool:
    """Le manifeste dit que la licence vient d'un autre compte que ceux du PC."""
    p = str(dernier_proprietaire or "").strip()
    return bool(locaux) and len(p) == 17 and p.isdigit() and p not in locaux


def jeux_du_compte() -> set[str] | None:
    """Appids du compte Steam connecte dans ORION ; None sans compte connecte."""
    try:
        from .core.base import Table
        donnees = Table("comptes_jeux").get("steam")
    except Exception:
        return None
    if not isinstance(donnees, dict) or not donnees.get("jeux"):
        return None
    return {str(j.get("id")) for j in donnees["jeux"] if isinstance(j, dict) and j.get("id")}


def de_la_famille(game, payants: set[str] | None = None) -> bool:
    """Le jeu vient de la famille Steam : certain (manifeste), ou hors du
    compte et payant (`payants` : appids dont la valeur est connue et > 0)."""
    extra = getattr(game, "extra", None) or {}
    if extra.get(PRETE):
        return True
    if not extra.get(HORS_COMPTE) or not payants:
        return False
    return str(extra.get("steam_appid") or getattr(game, "source_id", "") or "") in payants


def payants(valeur) -> set[str]:
    """Appids payants d'apres la derniere valeur de la bibliotheque."""
    return {str(j.get("appid")) for j in (getattr(valeur, "liste", None) or [])
            if j.get("appid") and float(j.get("normal") or 0) > 0}


def avec_mention(titre: str, famille: bool) -> str:
    return f"{titre} ({MENTION})" if famille else titre
