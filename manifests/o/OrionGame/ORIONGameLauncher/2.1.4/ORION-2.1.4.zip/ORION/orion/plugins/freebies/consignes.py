"""Traduction locale des consignes d'obtention des offres gratuites.

GamerPower decrit comment recuperer un jeu avec des phrases types, toujours
les memes (« Click the button to visit the giveaway page », « Login into your
itch.io account »...). Les traduire phrase par phrase, ici, evite de dependre
d'un service de traduction en ligne, limite en nombre d'appels. Une phrase
inconnue est laissee telle quelle et confiee au traducteur en ligne.
"""
from __future__ import annotations

import re

#: (motif anglais, traduction). Les groupes captures sont reinjectes.
PHRASES: tuple[tuple[str, str], ...] = (
    (r'click the "get giveaway" button to visit the giveaway page',
     "Cliquez sur « Recuperer » pour ouvrir la page de l'offre"),
    (r"click the button to visit the giveaway page",
     "Cliquez sur « Recuperer » pour ouvrir la page de l'offre"),
    (r'click the butt+on "?download or claim"? before the offer expires',
     "Cliquez sur « Download or Claim » avant la fin de l'offre"),
    (r'click the butt+on "?play now"?', "Cliquez sur « Play Now »"),
    (r'click the butt+on "?cart"? to add the game to your library',
     "Cliquez sur « Cart » pour ajouter le jeu a votre bibliotheque"),
    (r'scroll down and click the "?add to your library"? button to add the '
     r"game to your library",
     "Descendez et cliquez sur « Add to Your Library » pour l'ajouter a "
     "votre bibliotheque"),
    (r'go to "?my library"? to find your game',
     "Le jeu se trouve ensuite dans « My Library »"),
    (r"log ?in(?:to| to| into) your free (.+?) account and click the button to "
     r"unlock your key \((\d+) arp required\)",
     r"Connectez-vous a votre compte \1 (gratuit) et debloquez la cle "
     r"(\2 ARP requis, a gagner sur le site)"),
    (r"log ?in(?:to| to| into) your free (.+?) account",
     r"Connectez-vous a votre compte \1 (gratuit)"),
    (r"log ?in(?:to| to| into) your (.+?) account to access the game",
     r"Connectez-vous a votre compte \1 pour acceder au jeu"),
    (r"log ?in(?:to| to| into) your (.+?) account",
     r"Connectez-vous a votre compte \1"),
    (r"redeem the game", "Validez l'obtention du jeu"),
    (r"launch the steam client and click the games menu option",
     "Ouvrez Steam, menu « Jeux »"),
    (r'choose "?activate a product on steam"? to redeem your steam key',
     "Choisissez « Activer un produit sur Steam » et saisissez la cle"),
)

_ETAPE = re.compile(r"\s*(\d+)\.\s+")


def traduire_consignes(texte: str) -> tuple[str, bool]:
    """(texte en francais, tout_traduit). Les etapes numerotees sont gardees."""
    if not texte:
        return texte, True
    from ... import i18n
    if i18n.langue() != "fr":
        return texte, True              # la consigne d'origine est deja en anglais
    morceaux = _ETAPE.split(texte.strip())
    # ["", "1", "phrase", "2", "phrase"...] ou [phrase unique]
    if len(morceaux) >= 3 and morceaux[0] == "":
        etapes = list(zip(morceaux[1::2], morceaux[2::2]))
    else:
        etapes = [("", texte.strip())]
    tout = True
    sortie = []
    for numero, phrase in etapes:
        propre = phrase.strip().rstrip(".").strip()
        fr = None
        for motif, trad in PHRASES:
            m = re.fullmatch(motif, propre, flags=re.I)
            if m:
                # les accents reviennent phrase par phrase : le texte assemble
                # (« 1. ... 2. ... ») ne correspond a aucune entree du catalogue
                fr = i18n.traduire(m.expand(trad)) if i18n.langue() == "fr" else m.expand(trad)
                break
        if fr is None:
            fr, tout = propre, False
        sortie.append(f"{numero}. {fr}." if numero else f"{fr}.")
    return " ".join(sortie), tout
