"""Choix des graphismes d'un jeu (fiche du jeu), 2.1.0.

Demande de l'auteur (9 octobre) : deux cartes. « Votre ecran » : ORION
cherche le plus beau reglage qui tient la frequence de l'ecran (et se
corrige apres une partie mesuree). « Mon choix » : le joueur choisit les
graphismes (Ultra par defaut) et les images par seconde ; ORION montre ce
que ca donne sur ce PC. Un clic ecrit les reglages tout de suite ; un
bouton remet le jeu dans l'etat d'avant la premiere intervention d'ORION.

* `ChoixGraphismes` : le bloc complet, a poser tel quel dans la fiche :
  - la carte « Votre ecran » (conseillee) et la carte « Mon choix » avec ses
    deux selecteurs (niveau, images par seconde), calculees par
    `optimizer.choix` ; quand les deux se confondent, la seconde le dit ;
  - l'etat des reglages du jeu (`StatutReglages`) et la ligne « Reglages
    ecrits ... Restaurer pour revenir » ;
  - le bouton « Redefinir les parametres par defaut ».
  Donnees : `optimizer.profiles.donnees_fiche` (voir `set_donnees`).
"""
from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (QCheckBox, QComboBox, QFrame, QHBoxLayout, QLabel, QProgressBar,
                               QPushButton, QSizePolicy, QVBoxLayout, QWidget)

from ...i18n import t
from ...optimizer.choix import COULEURS, EXPLICATIONS, IDS, NIVEAUX, NOMS
from ...optimizer.recommande import COULEURS_NIVEAUX, NOMS_NIVEAUX

VERT = "#3DDC97"
NOMS_SOURCES = {"mesure": "Mesure sur votre PC", "communaute": "Mesures de joueurs",
                "estime": "Estimation", "inconnu": "Non verifie"}


def _rgba(couleur: str, alpha: int) -> str:
    c = couleur.lstrip("#")
    if len(c) != 6:
        return couleur
    return f"rgba({int(c[0:2], 16)}, {int(c[2:4], 16)}, {int(c[4:6], 16)}, {alpha})"


def style_pastille(couleur: str, taille: int = 11) -> str:
    return (f"QLabel {{ background: {_rgba(couleur, 38)}; color: {couleur}; "
            f"border: 1px solid {_rgba(couleur, 140)}; border-radius: 9px; "
            f"padding: 2px 9px; font-size: {taille}px; font-weight: 700; }}")


def pastille_niveau(niveau: str, texte: str = "") -> QLabel:
    """Pastille de couleur « Ultra / Haute / Moyenne / Basse »."""
    lbl = QLabel(texte or NOMS_NIVEAUX.get(niveau, niveau or "–"))
    lbl.setObjectName("PastilleNiveau")
    lbl.setStyleSheet(style_pastille(COULEURS_NIVEAUX.get(niveau, "#AAB4C8")))
    lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
    lbl.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
    return lbl


def _label(texte: str = "", nom: str = "", style: str = "", wrap: bool = False) -> QLabel:
    lbl = QLabel(texte)
    if nom:
        lbl.setObjectName(nom)
    if style:
        lbl.setStyleSheet(style)
    lbl.setWordWrap(wrap)
    return lbl


# --------------------------------------------------------------------------
class CarteChoix(QFrame):
    """Une carte : objectif, reglage retenu, images/s, origine, tenue. La
    carte « Mon choix » porte en plus ses deux selecteurs (niveau, images/s)."""
    selected = Signal(str)
    apercu_demande = Signal(str, int)        # niveau, objectif d'images/s
    sr_demande = Signal(str, bool)           # carte, case DLSS / FSR / XeSS cochee

    def __init__(self, choix_id: str, parent=None) -> None:
        super().__init__(parent)
        self.choix_id = choix_id
        self._couleur = COULEURS[choix_id]
        self.setObjectName("CarteChoix")
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setProperty("selected", "false")
        self._style()
        lay = QVBoxLayout(self)
        lay.setContentsMargins(18, 14, 18, 14)
        lay.setSpacing(5)

        tete = QHBoxLayout()
        tete.setSpacing(8)
        self.nom = _label(t(NOMS[choix_id]), style=(
            f"color: {self._couleur}; font-size: 11px; font-weight: 800; letter-spacing: 1.6px;"))
        tete.addWidget(self.nom)
        self.objectif = _label("", style=(
            f"color: {self._couleur}; font-size: 11px; font-weight: 700; letter-spacing: 1px;"))
        tete.addWidget(self.objectif)
        self.niveaux: QComboBox | None = None
        self.selecteur: QComboBox | None = None
        if choix_id == "choix":
            self.objectif.hide()
            self.niveaux = QComboBox()
            self.niveaux.setObjectName("Objectif")
            self.niveaux.setCursor(Qt.CursorShape.PointingHandCursor)
            self.niveaux.setToolTip(t("Les graphismes que vous voulez : ORION dit ce que ce niveau donne sur votre PC."))
            for n in NIVEAUX:
                self.niveaux.addItem(t(NOMS_NIVEAUX.get(n, n)), n)
            self.niveaux.currentIndexChanged.connect(self._objectif_change)
            tete.addWidget(self.niveaux)
            self.selecteur = QComboBox()
            self.selecteur.setObjectName("Objectif")
            self.selecteur.setCursor(Qt.CursorShape.PointingHandCursor)
            self.selecteur.setToolTip(t("Les images par seconde que vous voulez : ORION bride le jeu dessus et dit si votre PC les tient."))
            self.selecteur.currentIndexChanged.connect(self._objectif_change)
            tete.addWidget(self.selecteur)
        tete.addStretch(1)
        self.marque = _label(t("Conseille"), style=style_pastille(VERT, 10))
        self.marque.hide()
        tete.addWidget(self.marque)
        self.en_place = _label(t("Reglage utilise"), style=style_pastille(self._couleur, 10))
        self.en_place.hide()
        tete.addWidget(self.en_place)
        lay.addLayout(tete)

        ligne = QHBoxLayout()
        ligne.setSpacing(10)
        self.fps = _label("", style="font-size: 30px; font-weight: 800; color: #E7ECF5;")
        ligne.addWidget(self.fps, 0, Qt.AlignmentFlag.AlignBottom)
        col = QVBoxLayout()
        col.setSpacing(1)
        self.reglage = _label("", style="font-size: 15px; font-weight: 700; color: #E7ECF5;", wrap=True)
        col.addWidget(self.reglage)
        self.tenue = _label("", style="color: #AAB4C8; font-size: 12px;", wrap=True)
        col.addWidget(self.tenue)
        ligne.addLayout(col, 1)
        lay.addLayout(ligne)

        self.explication = _label(t(EXPLICATIONS[choix_id]), nom="Faint", wrap=True)
        lay.addWidget(self.explication)
        self.origine = _label("", style="color: #7F8AA3; font-size: 11px;", wrap=True)
        lay.addWidget(self.origine)
        self.identique = _label("", style=f"color: {self._couleur}; font-size: 11px; font-weight: 600;", wrap=True)
        self.identique.hide()
        lay.addWidget(self.identique)

        # case DLSS / FSR / XeSS (10 octobre : « une coche, et afficher le
        # gain sur les i/s en temps reel ») : la carte change des le clic,
        # avec et sans sont calcules d'avance
        ligne_sr = QHBoxLayout()
        ligne_sr.setSpacing(8)
        self.case_sr = QCheckBox("")
        self.case_sr.setCursor(Qt.CursorShape.PointingHandCursor)
        self.case_sr.setToolTip(t("Super-resolution : le jeu calcule une image plus petite et l'agrandit. "
                                  "Plus d'images par seconde, image un peu moins fine."))
        self.case_sr.toggled.connect(self._case_sr)
        ligne_sr.addWidget(self.case_sr)
        self.gain_sr = _label("", style="color: #3DDC97; font-size: 12px; font-weight: 700;")
        ligne_sr.addWidget(self.gain_sr)
        ligne_sr.addStretch(1)
        lay.addLayout(ligne_sr)
        self.case_sr.hide()
        self.gain_sr.hide()
        self._variantes: dict = {}

    def _style(self) -> None:
        c = self._couleur
        self.setStyleSheet(
            "QFrame#CarteChoix { border-radius: 14px; border: 1px solid #2A3A44;"
            " background: rgba(20, 25, 38, 225); }"
            f"QFrame#CarteChoix[selected=\"true\"] {{ border: 2px solid {c};"
            f" background: {_rgba(c, 22)}; }}"
            f"QFrame#CarteChoix:hover {{ border-color: {c}; }}")

    def set_objectifs(self, objectifs: list[int], cible: int, niveau: str = "") -> None:
        """Les objectifs proposes (frequence de l'ecran et paliers en
        dessous), celui en place (0 : la frequence de l'ecran) et le niveau
        en place (Ultra par defaut)."""
        if self.selecteur is None or self.niveaux is None:
            return
        self.selecteur.blockSignals(True)
        self.niveaux.blockSignals(True)
        self.selecteur.clear()
        for o in objectifs:
            self.selecteur.addItem(f"{o} i/s", o)
        voulu = cible or (objectifs[0] if objectifs else 60)
        i = self.selecteur.findData(voulu)
        if i < 0:
            self.selecteur.addItem(f"{voulu} i/s", voulu)
            i = self.selecteur.count() - 1
        self.selecteur.setCurrentIndex(max(0, i))
        j = self.niveaux.findData(niveau or NIVEAUX[0])
        self.niveaux.setCurrentIndex(max(0, j))
        self.selecteur.blockSignals(False)
        self.niveaux.blockSignals(False)

    def cible(self) -> int:
        if self.selecteur is None:
            return 0
        return int(self.selecteur.currentData() or 0)

    def niveau(self) -> str:
        if self.niveaux is None:
            return ""
        return str(self.niveaux.currentData() or "")

    def _objectif_change(self, _i: int) -> None:
        if self.cible():
            self.apercu_demande.emit(self.niveau(), self.cible())

    def set_choix(self, c, conseille: bool) -> None:
        """`c` : `optimizer.choix.Choix` (ou son dictionnaire)."""
        d = c.to_dict() if hasattr(c, "to_dict") else dict(c)
        self._variantes = dict(d.get("variantes") or {})
        dispo = bool(d.get("sr_dispo")) and bool(self._variantes)
        self.case_sr.blockSignals(True)
        self.case_sr.setText(t("Activer {0}").replace("{0}", t(d.get("nom_sr") or "DLSS")))
        self.case_sr.setChecked(bool(d.get("sr")))
        self.case_sr.blockSignals(False)
        self.case_sr.setVisible(dispo)
        self._gain(d)
        self._afficher(d, conseille)

    def _gain(self, d: dict) -> None:
        gain = int(d.get("gain") or 0)
        if not d.get("sr_dispo"):
            self.gain_sr.hide()
            return
        if gain <= 0:
            texte = t("pas d'images en plus ici")
        elif self.case_sr.isChecked():
            texte = t("+{0} i/s").replace("{0}", str(gain))
        else:
            texte = t("+{0} i/s si active").replace("{0}", str(gain))
        self.gain_sr.setText(texte)
        self.gain_sr.show()

    def _case_sr(self, coche: bool) -> None:
        """La carte bascule tout de suite sur sa variante, puis la fenetre
        memorise la case (et reecrit le jeu si cette carte est en place)."""
        v = self._variantes.get("avec" if coche else "sans")
        if v:
            v = dict(v, variantes=self._variantes, sr_dispo=True)
            self._gain(v)
            self._afficher(v, self.marque.isVisible())
        self.sr_demande.emit(self.choix_id, bool(coche))

    def _afficher(self, d: dict, conseille: bool) -> None:
        self.objectif.setText(f"· {d.get('cible', 0)} i/s")
        fps = d.get("fps_court") or "?"
        self.fps.setText(f"{fps}<span style='font-size:12px; color:#AAB4C8; font-weight:600;'> i/s</span>")
        self.reglage.setText(t(NOMS_NIVEAUX.get(d.get("niveau", ""), "")) + (
            " + " + t(d["reglage"].split(" + ", 1)[1]) if " + " in d.get("reglage", "") else ""))
        couleur = VERT if d.get("atteint") else ("#FFB454" if d.get("palier") else "#FF5A5F")
        self.tenue.setText(f"<span style='color:{couleur}'>●</span> " + t(d.get("tenue", "")))
        self.origine.setText(t(d.get("origine", "")).capitalize() + ".")
        self.marque.setVisible(conseille)
        autre = d.get("identique") or ""
        if autre:
            self.identique.setText(t("Identique a « {0} » sur ce PC").replace("{0}", t(NOMS.get(autre, autre))))
        self.identique.setVisible(bool(autre))
        self.setToolTip(f"{d.get('reglage', '')} · {d.get('tenue', '')} · {d.get('origine', '')}")

    def set_selected(self, value: bool) -> None:
        self.setProperty("selected", "true" if value else "false")
        self._selectionnee = value
        # « Reglage utilise » : seulement quand ORION ecrit lui-meme ce
        # reglage. Pour un jeu qui gere ses reglages lui-meme (Rocket League,
        # 15 octobre), la carte est un conseil, rien n'est « utilise ».
        self.en_place.setVisible(value and getattr(self, "_ecrit_par_orion", True))
        self.style().unpolish(self)
        self.style().polish(self)

    def set_ecrit_par_orion(self, oui: bool) -> None:
        self._ecrit_par_orion = oui
        self.en_place.setVisible(oui and getattr(self, "_selectionnee", False))

    def mousePressEvent(self, event) -> None:      # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton:
            self.selected.emit(self.choix_id)
        super().mousePressEvent(event)


# --------------------------------------------------------------------------
class StatutReglages(QFrame):
    """Etat des reglages : pastille, titre, detail et jauge « 12 sur 14 »."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("Statut")
        self._couleur = "#AAB4C8"
        lay = QHBoxLayout(self)
        lay.setContentsMargins(14, 10, 16, 10)
        lay.setSpacing(12)
        self.point = QLabel("●")
        self.point.setAlignment(Qt.AlignmentFlag.AlignTop)
        lay.addWidget(self.point)
        col = QVBoxLayout()
        col.setSpacing(3)
        haut = QHBoxLayout()
        haut.setSpacing(12)
        self.titre = QLabel("")
        self.titre.setObjectName("Value")
        self.titre.setWordWrap(True)
        haut.addWidget(self.titre, 1)
        self.jauge = QProgressBar()
        self.jauge.setTextVisible(False)
        self.jauge.setFixedSize(120, 6)
        haut.addWidget(self.jauge, 0, Qt.AlignmentFlag.AlignVCenter)
        col.addLayout(haut)
        self.detail = QLabel("")
        self.detail.setObjectName("Dim")
        self.detail.setStyleSheet("font-size: 12px;")
        self.detail.setWordWrap(True)
        col.addWidget(self.detail)
        lay.addLayout(col, 1)
        self._style()

    def _style(self) -> None:
        c = self._couleur
        self.setStyleSheet(
            f"QFrame#Statut {{ background: rgba(14, 18, 28, 186); border: 1px solid #232B3D;"
            f" border-left: 3px solid {c}; border-radius: 10px; }}")
        self.point.setStyleSheet(f"color: {c}; font-size: 15px;")
        self.jauge.setStyleSheet(
            f"QProgressBar {{ background: #232B3D; border: none; border-radius: 3px; }}"
            f"QProgressBar::chunk {{ background: {c}; border-radius: 3px; }}")

    def set_statut(self, statut) -> None:
        """`statut` : `optimizer.fiabilite.Statut`."""
        self._couleur = statut.couleur
        self._style()
        self.titre.setText(statut.titre)
        self.detail.setText(statut.detail)
        self.detail.setVisible(bool(statut.detail))
        total = int(getattr(statut, "total", 0) or 0)
        self.jauge.setVisible(total > 0)
        if total:
            self.jauge.setRange(0, total)
            self.jauge.setValue(int(getattr(statut, "en_place", 0) or 0))
            self.jauge.setToolTip(f"{statut.en_place} reglage(s) en place sur {total}")


# --------------------------------------------------------------------------
class ChoixGraphismes(QWidget):
    """Bloc « Graphismes » de la fiche : la carte « Votre ecran », la carte
    « Mon choix » et ses deux selecteurs, l'etat des reglages, la ligne de
    confirmation et le retour a l'etat d'origine.

    Signaux :
    * `choix_fait(str, int)` : une carte a ete cliquee ; (niveau, objectif
      d'images par seconde). « Votre ecran » donne ("", 0). La fenetre
      memorise le choix, refait le plan et ECRIT les reglages tout de suite
      (sauvegarde avant, relecture apres) ;
    * `apercu_demande(str, int)` : le joueur change le niveau ou l'objectif
      dans « Mon choix » : la fenetre recalcule la carte, sans rien ecrire ;
    * `defaut_demande()` : « Redefinir les parametres par defaut » : la
      fenetre demande confirmation puis restaure la premiere sauvegarde ;
    * `sr_demande(str, bool)` : la case DLSS / FSR / XeSS d'une carte : la
      carte a deja bascule ; la fenetre memorise et, si c'est la carte en
      place, reecrit le jeu.
    """
    choix_fait = Signal(str, int)
    apercu_demande = Signal(str, int)
    defaut_demande = Signal()
    sr_demande = Signal(str, bool)
    apprendre_demande = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.choix_id = "ecran"
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(10)

        rangee = QHBoxLayout()
        rangee.setSpacing(10)
        self.cartes: dict[str, CarteChoix] = {}
        for cid in IDS:
            carte = CarteChoix(cid)
            carte.selected.connect(self._clic)
            carte.apercu_demande.connect(self.apercu_demande.emit)
            carte.sr_demande.connect(self.sr_demande.emit)
            rangee.addWidget(carte, 1)
            self.cartes[cid] = carte
        lay.addLayout(rangee)

        self.manuel = _label("", wrap=True, style="color: #FFB454; font-size: 12px; font-weight: 600;")
        self.manuel.hide()
        lay.addWidget(self.manuel)

        self.statut = StatutReglages()
        lay.addWidget(self.statut)

        bas = QHBoxLayout()
        bas.setSpacing(10)
        self.ecrit = _label("", nom="Faint", wrap=True)
        bas.addWidget(self.ecrit, 1)
        self.defaut = QPushButton(t("Redefinir les parametres par defaut"))
        self.defaut.setObjectName("Ghost")
        self.defaut.setCursor(Qt.CursorShape.PointingHandCursor)
        self.defaut.setToolTip(t("Remet le jeu dans l'etat d'avant la premiere intervention d'ORION (premiere sauvegarde)."))
        self.defaut.clicked.connect(self.defaut_demande.emit)
        self.apprendre = QPushButton(t("Apprendre les niveaux de ce jeu"))
        self.apprendre.setObjectName("Ghost")
        self.apprendre.setCursor(Qt.CursorShape.PointingHandCursor)
        self.apprendre.setToolTip(t("Vous choisissez quelques niveaux dans le menu du jeu ; ORION retient ce que "
                                    "le jeu ecrit pour chacun, puis le regle tout seul."))
        self.apprendre.clicked.connect(self.apprendre_demande.emit)
        bas.addWidget(self.apprendre, 0, Qt.AlignmentFlag.AlignTop)
        bas.addWidget(self.defaut, 0, Qt.AlignmentFlag.AlignTop)
        lay.addLayout(bas)
        self.set_selected("ecran")

    # ------------------------------------------------------------------
    def set_donnees(self, donnees: dict) -> None:
        """`donnees` : `optimizer.profiles.donnees_fiche(...)`."""
        self.cartes["choix"].set_objectifs(list(donnees.get("objectifs") or []),
                                           int(donnees.get("cible") or 0),
                                           str(donnees.get("niveau") or ""))
        for c in list(donnees.get("choix") or []):
            d = c.to_dict() if hasattr(c, "to_dict") else dict(c)
            carte = self.cartes.get(d.get("id"))
            if carte is not None:
                carte.set_choix(c, conseille=(d.get("id") == "ecran"))
        statut = donnees.get("statut")
        if statut is not None:
            self.statut.set_statut(statut)
            reco = donnees.get("recommandation")
            self.set_pris_en_charge(statut.pris_en_charge and statut.automatique, reco)
        self.defaut.setVisible(bool(donnees.get("sauvegarde_origine")))
        self.set_selected(str(donnees.get("choix_id") or self.choix_id))

    def set_apercu(self, c) -> None:
        """Le resultat pour le niveau et l'objectif que le joueur vient de
        choisir (rien n'est ecrit tant qu'il ne clique pas la carte)."""
        self.cartes["choix"].set_choix(c, conseille=False)

    def set_pris_en_charge(self, oui: bool, reco=None) -> None:
        """Jeu non pris en charge (ou qui gere ses reglages lui-meme) : les
        cartes restent affichees, a regler dans le menu du jeu."""
        texte = ""
        if not oui and reco is not None:
            texte = (t("A regler vous-meme dans les options graphiques du jeu : « {0} »")
                     .replace("{0}", t(reco.nom_niveau) + (f" + {t(reco.texte_mode)}" if reco.texte_mode
                                                           and reco.famille != "echelle" else "")) + ".")
        self.manuel.setText(texte)
        self.manuel.setVisible(bool(texte))
        self.ecrit.setVisible(oui)
        for carte in self.cartes.values():
            carte.set_ecrit_par_orion(oui)

    def set_ecrit(self, texte: str) -> None:
        """« Reglages ecrits : Mon choix, Ultra, 120 i/s. Restaurer pour revenir. »"""
        self.ecrit.setText(texte)

    def cible(self) -> int:
        """L'objectif affiche dans « Mon choix »."""
        return self.cartes["choix"].cible()

    def niveau(self) -> str:
        """Le niveau affiche dans « Mon choix »."""
        return self.cartes["choix"].niveau()

    def set_selected(self, cid: str) -> None:
        if cid not in IDS:
            cid = "ecran"
        self.choix_id = cid
        for cle, carte in self.cartes.items():
            carte.set_selected(cle == cid)

    def _clic(self, cid: str) -> None:
        self.set_selected(cid)
        if cid == "choix":
            self.choix_fait.emit(self.niveau(), self.cible())
        else:
            self.choix_fait.emit("", 0)
