"""Fenetre principale : assemble les pages et orchestre les services."""
from __future__ import annotations

from .minuteur import plus_tard

from orion.affiliation import ouvreur  # liens de boutique (partenaires)

import time
from pathlib import Path

from PySide6.QtCore import QObject, QTimer, Signal
from PySide6.QtWidgets import (QApplication, QHBoxLayout, QInputDialog,
                               QLabel, QMainWindow, QMessageBox,
                               QStackedWidget, QStatusBar)

from ..artwork import ArtworkService
from ..core.config import CONFIG, DONATE_LABEL
from ..core.events import ART_UPDATED, BUS, GAME_EXITED, NOTIFY
from ..core.fichiers import existe
from ..core.logging_setup import get
from ..core.models import DisplayMode, Game, HardwareInfo
from ..core.tasks import Task
from ..plugins.market.base import MarketInfo
from ..hardware.displays import apply_mode
from ..hardware.probe import probe
from ..launch.launcher import GameSession
from ..community import CommunityRecipes
from ..boutique import BoutiqueService
from ..freebies import FreebiesService
from ..library import LibraryService
from ..market import MarketService
from ..perf.store import PerfStore
from ..saves import SaveManager, detect as detect_saves
from ..wishlist import WishlistService
from ..optimizer.recommande import NOMS_NIVEAUX
from ..optimizer import advisor, backup
from ..optimizer.engine import Optimizer
from ..optimizer.profiles import PROFILES, compute_settings, describe
from ..version import APP_NAME, APP_VERSION
from .comptes_mixin import ComptesMixin, StockageMixin
from .puissance_mixin import PuissanceMixin
from .sorties_mixin import SortiesMixin
from .reglages_mixin import ReglagesMixin
from .fond import FondMixin
from .gamepad import GamepadBridge
from .theme import build_qss
from .views.advice_view import AdviceView
from .views.detail_view import DetailView
from .backdrop import Backdrop
from .views.boutique_view import BoutiqueView
from .views.free_view import FreeView
from .views.hardware_view import HardwareView
from .views.storage_view import StorageView
from .views.tutorial_view import TutorialView
from .views.wishlist_view import WishlistView
from .views.library_view import LibraryView
from .views.settings_view import SettingsView
from .widgets.sidebar import Sidebar

ouvrir_lien = ouvreur("bibliotheque")   # d'ou vient le clic (compteur anonyme)
ouvrir_gratuit = ouvreur("gratuits")

log = get("ui")

#: pages de la pile, dans l'ordre ou elles y sont ajoutees
PAGES = ("library", "detail", "wishlist", "hardware", "storage",
         "advice", "tutorial", "settings", "boutique", "comptes", "sorties")
#: anciennes pages devenues des onglets : page -> (page de la pile, onglet)
ALIAS_PAGES = {"free": ("boutique", "gratuits")}


class _PontVisuels(QObject):
    """Ramene « visuel pret » (emis depuis un fil de travail) sur l'interface."""
    pret = Signal(str)


class MainWindow(ComptesMixin, StockageMixin, PuissanceMixin, SortiesMixin, FondMixin,
                 ReglagesMixin, QMainWindow):
    def __init__(self, on_progress=None) -> None:
        super().__init__()
        # `on_progress` relaie l'avancement vers l'ecran de demarrage : la
        # construction de la fenetre dure quelques secondes, autant dire
        # ce qui se passe.
        def etape(texte: str) -> None:
            if on_progress:
                on_progress(texte)

        etape("Chargement de la bibliotheque...")
        self.library = LibraryService()
        self.artwork = ArtworkService()
        self.optimizer = Optimizer()
        etape("Prix et jeux gratuits...")
        self.market = MarketService()
        self.community = CommunityRecipes()
        self.perf = PerfStore()
        self.wishlist = WishlistService()
        self.free = FreebiesService()
        self.boutique = BoutiqueService()
        self.saves = SaveManager()
        etape("Construction de l'interface...")
        self.hw: HardwareInfo = HardwareInfo()
        self.sessions: list[GameSession] = []
        self._busy = False
        self._free_busy = False
        self._boutique_busy = False
        self._images_busy = False
        self._wish_busy = False
        self._wish_encore = False
        self._free_kind = ""
        self._free_query = ""
        self._free_expired: dict[str, str] = {}
        self._free_installed: dict[str, str] = {}
        self.gamepad: GamepadBridge | None = None

        self.setWindowTitle(f"{APP_NAME} - Game Launcher")
        self.resize(1440, 900)
        self.setMinimumSize(1080, 700)
        self.setStyleSheet(build_qss())

        self._init_fond()
        self._build()
        self._init_comptes()
        self._init_stockage()
        self._init_puissance()
        self._init_sorties()
        self._init_reglages()
        self._connect_events()
        plus_tard(self, 60, self._boot)

    # ------------------------------------------------------------------
    def _build(self) -> None:
        root = Backdrop()
        self.backdrop = root
        lay = QHBoxLayout(root)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        self.sidebar = Sidebar()
        self.sidebar.page_changed.connect(self.show_page)
        self.sidebar.filters_changed.connect(self._filters_changed)
        self.sidebar.donate_requested.connect(self._donate)
        self.sidebar.signaler_demande.connect(lambda: self.signaler_probleme())
        self.sidebar.avis_demande.connect(lambda: self.donner_avis())
        lay.addWidget(self.sidebar)

        self.stack = QStackedWidget()
        lay.addWidget(self.stack, 1)
        root.set_pages(self.stack)        # la banniere de saison se peint en haut des pages

        self.library_view = LibraryView()
        self.library_view.game_selected.connect(self.open_game)
        self.library_view.game_play.connect(
            lambda uid: self.play(uid, self._profile_for(uid)))
        self.library_view.hero_play.connect(
            lambda uid, profile: self.play(uid, profile or self._profile_for(uid)))
        self.library_view.rescan_requested.connect(self.scan)
        self.library_view.game_action.connect(self._game_action)
        self.library_view.add_requested.connect(self._add_game)
        self.library_view.boutique_requested.connect(self.chercher_en_boutique)
        self._init_valeur()
        self.stack.addWidget(self.library_view)

        self.detail_view = DetailView()
        self.detail_view.back_requested.connect(lambda: self.show_page("library"))
        self.detail_view.play_requested.connect(self.play)
        self.detail_view.apply_requested.connect(self.apply_only)
        self.detail_view.profile_changed.connect(self._profile_changed)
        self.detail_view.choix_requested.connect(self._choix_graphismes)
        self.detail_view.cible_requested.connect(self._apercu_cible)
        self.detail_view.sr_requested.connect(self._case_sr)
        self.detail_view.apprendre_requested.connect(self._apprendre_niveaux)
        self.detail_view.defaut_requested.connect(self._defaut_graphismes)
        self.detail_view.favorite_toggled.connect(self._toggle_favorite)
        self.detail_view.restore_requested.connect(self._restore_backup)
        self.detail_view.market_refresh_requested.connect(
            lambda uid: self._load_market(uid, force=True))
        self.detail_view.ai_requested.connect(self._run_ai)
        self.detail_view.share_recipe_requested.connect(self._share_recipe)
        self.detail_view.tuning_requested.connect(self._tuning)
        self.detail_view.save_backup_requested.connect(self._backup_saves)
        self.detail_view.save_restore_requested.connect(self._restore_saves)
        self.stack.addWidget(self.detail_view)

        self.wishlist_view = WishlistView()
        self.wishlist_view.refresh_requested.connect(
            lambda: self.refresh_wishlist(True))
        self.wishlist_view.import_requested.connect(self._import_wishlist)
        self.wishlist_view.add_requested.connect(self._wishlist_add)
        self.wishlist_view.target_changed.connect(self._wishlist_target)
        self.wishlist_view.remove_requested.connect(self._wishlist_remove)
        self.stack.addWidget(self.wishlist_view)

        self.free_view = FreeView()
        self.free_view.refresh_requested.connect(lambda: self.refresh_free(True))
        self.free_view.claim_requested.connect(self._free_claim)
        self.free_view.dismiss_requested.connect(self._free_dismiss)
        self.free_view.buy_requested.connect(self._free_buy)
        self.free_view.uninstall_requested.connect(self._free_uninstall)
        self.free_view.remove_requested.connect(self._free_remove)
        self.free_view.keep_requested.connect(self._free_keep)
        self.free_view.filter_changed.connect(self._free_filter)
        # l'ancienne page « Jeux gratuits » vit desormais dans la Boutique
        # (onglet « Gratuits en ce moment ») : voir plus bas

        self.hardware_view = HardwareView()
        self.hardware_view.refresh_requested.connect(lambda: self.refresh_hardware(True))
        self.hardware_view.apply_mode_requested.connect(self._apply_display_mode)
        self.hardware_view.ai_requested.connect(self._machine_ai)
        self.hardware_view.bilan_requested.connect(lambda: self.montrer_bilan())
        self.stack.addWidget(self.hardware_view)

        self.storage_view = StorageView()
        self.storage_view.refresh_requested.connect(self.refresh_storage)
        self.storage_view.uninstall_requested.connect(self._uninstall_game)
        self.storage_view.open_folder_requested.connect(
            lambda uid: self._open_game_folder(uid))
        self.storage_view.ouvrir_fiche_requested.connect(self.open_game)
        self.stack.addWidget(self.storage_view)

        self.advice_view = AdviceView()
        self.advice_view.refresh_requested.connect(lambda: self.refresh_hardware(True))
        self.advice_view.alertes_changees.connect(self._pastille_conseils)
        self.stack.addWidget(self.advice_view)

        self.tutorial_view = TutorialView()
        self.tutorial_view.open_settings_requested.connect(
            lambda: self.show_page("settings"))
        self.stack.addWidget(self.tutorial_view)

        self.settings_view = SettingsView()
        self.settings_view.rescan_requested.connect(self.scan)
        self.settings_view.reload_plugins_requested.connect(self.reload_plugins)
        self.settings_view.art_refresh_requested.connect(lambda: self.fetch_artwork(True))
        self.settings_view.background_changed.connect(self._background_changed)
        self.settings_view.donate_changed.connect(self._refresh_donate)
        self.settings_view.community_sync_requested.connect(
            lambda: self.sync_community(True))
        self.settings_view.perf_tool_requested.connect(self._install_perf_tool)
        self.settings_view.maj_demandee.connect(lambda: self.verifier_maj(False))
        self.settings_view.version_visible_changee.connect(self._version_visible)
        self.settings_view.nouveautes_demandees.connect(lambda: self.montrer_nouveautes())
        self.settings_view.signaler_demande.connect(lambda: self.signaler_probleme())
        self.settings_view.possedes_change.connect(self.actualiser_possedes)
        self.settings_view.frequence_envies_changee.connect(self._appliquer_frequence_envies)
        self.stack.addWidget(self.settings_view)

        self.boutique_view = BoutiqueView()
        self.boutique_view.differer = self._au_repos
        self.boutique_view.actualiser_demande.connect(
            lambda: self.refresh_boutique(True))
        self.boutique_view.recherche_demandee.connect(self._boutique_chercher)
        self.boutique_view.comparer_demande.connect(self._boutique_comparer)
        self.boutique_view.suivre_demande.connect(self._boutique_suivre)
        self.boutique_view.ne_plus_suivre_demande.connect(self._boutique_ne_plus_suivre)
        self.boutique_view.suite_demandee.connect(self._boutique_suite)
        self.boutique_view.cles_demandees.connect(self._boutique_cles)
        self.boutique_view.esprit_demande.connect(self._boutique_esprit)
        self.boutique_view.cle_demandee.connect(self._boutique_cle)
        self.boutique_view.bibliotheque_demandee.connect(self._boutique_vers_bibliotheque)
        from .views.boutique_page import BoutiquePage
        self.boutique_page = BoutiquePage(self.boutique_view, self.free_view)
        self.stack.addWidget(self.boutique_page)

        from .views.comptes_view import ComptesView
        self.comptes_view = ComptesView()
        self.stack.addWidget(self.comptes_view)

        from .views.sorties_view import SortiesView
        self.sorties_view = SortiesView()
        self.stack.addWidget(self.sorties_view)

        self.setCentralWidget(root)

        from PySide6.QtGui import QKeySequence, QShortcut
        QShortcut(QKeySequence("F11"), self,
                  activated=lambda: self.toggle_big_picture())
        # Ctrl+F : la recherche de la page affichee
        QShortcut(QKeySequence.StandardKey.Find, self, activated=self.chercher_ici)
        # raccourci discret : captures de toutes les pages pour le site web
        QShortcut(QKeySequence("Ctrl+Shift+F12"), self,
                  activated=self.capturer_pour_le_site)

        bar = QStatusBar()
        bar.setSizeGripEnabled(False)
        self.status_label = QLabel(f"{APP_NAME} {APP_VERSION}")
        bar.addWidget(self.status_label)
        self.setStatusBar(bar)

    def _connect_events(self) -> None:
        BUS.on(NOTIFY, lambda message="", **_: self.notify(message))
        # une jaquette s'affiche des qu'elle arrive, sans attendre la fin du lot
        self._pont_visuels = _PontVisuels(self)
        self._pont_visuels.pret.connect(self._visuel_pret)
        BUS.on(ART_UPDATED, lambda uid="", **_: self._pont_visuels.pret.emit(uid))
        BUS.on(GAME_EXITED, lambda uid="", seconds=0, **_: None)

    # ------------------------------------------------------------------
    def _donate(self) -> None:
        """Ouvre la fenetre de soutien (lien + QR code)."""
        from .widgets.donate_dialog import DonateDialog
        DonateDialog(self).exec()

    def _refresh_donate(self) -> None:
        self.sidebar.set_donate(
            DONATE_LABEL,
            bool(CONFIG.get("support.show_button", True)))

    def _share_recipe(self, uid: str) -> None:
        """Prepare la recette de ce jeu pour le depot communautaire."""
        from ..optimizer.engine import select_recipe

        game = self.library.get(uid)
        if game is None:
            return
        recipe = select_recipe(game, self.optimizer.recipes)
        if recipe is None:
            self.notify("Aucune recette a partager pour ce jeu")
            return
        ok, message = self.community.prepare_share(
            recipe.origin, str(CONFIG.get("community.author") or ""))
        if not ok:
            self.notify(message, 10)
            return

        box = QMessageBox(self)
        box.setWindowTitle("Partager la recette")
        box.setIcon(QMessageBox.Icon.Information)
        box.setText("Recette prete a etre partagee.")
        box.setInformativeText(
            f"Deux fichiers ont ete crees dans :\n{message}\n\n"
            "Deposez le fichier de recette dans le dossier « recipes » du "
            "depot communautaire, et ajoutez la ligne du fichier « .index » "
            "dans index.json. Les autres utilisateurs la recevront a leur "
            "prochaine synchronisation.")
        box.setStandardButtons(QMessageBox.StandardButton.Ok)
        box.exec()
        self._open_folder_path(message)

    @staticmethod
    def _open_folder_path(path: str) -> None:
        import subprocess
        from ..core.lancement import startfile_propre
        from ..core.paths import is_windows
        try:
            if is_windows():
                startfile_propre(path)
            else:
                subprocess.Popen(["xdg-open", path])
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Liste d'envies et veille de prix
    # ------------------------------------------------------------------
    def refresh_wishlist_view(self) -> None:
        self.wishlist_view.set_items(self.wishlist.all())
        # la Boutique sait tout de suite ce qui est suivi, d'ou que vienne le
        # changement (bouton « Suivre », page Envies, import)
        vue = getattr(self, "boutique_view", None)
        if vue is not None:
            vue.set_suivis({i.appid for i in self.wishlist.all()})

    def refresh_wishlist(self, force: bool = False) -> None:
        self._appliquer_frequence_envies()
        if not self.wishlist.items:
            self.refresh_wishlist_view()
            return
        if getattr(self, "_wish_busy", False):
            # une verification tourne deja : on en refera une a la fin (un
            # jeu vient peut-etre d'etre ajoute), sans en lancer une seconde
            self._wish_encore = self._wish_encore or force
            return
        if not force and self._differer("envies"):
            return
        self._wish_busy = True
        self._wish_encore = False
        task = Task(self.wishlist.refresh, self.market, self.artwork)
        task.signals.progress.connect(self.wishlist_view.set_progress)
        task.signals.finished.connect(self._wishlist_refreshed)
        task.signals.failed.connect(self._wishlist_echec)
        task.start()

    def _appliquer_frequence_envies(self) -> None:
        """Minuterie de la veille des prix : toujours presente (une liste vide
        au demarrage peut se remplir ensuite) et a la frequence des Reglages."""
        heures = float(CONFIG.get("wishlist.check_hours", 6) or 6)
        intervalle = int(max(heures, 0.1) * 3600 * 1000)
        minuterie = getattr(self, "_wish_timer", None)
        if minuterie is None:
            minuterie = self._wish_timer = QTimer(self)
            minuterie.timeout.connect(lambda: self.refresh_wishlist())
            minuterie.start(intervalle)
        elif minuterie.interval() != intervalle:
            minuterie.setInterval(intervalle)

    def _wishlist_fin(self) -> None:
        self._wish_busy = False
        if getattr(self, "_wish_encore", False):
            self._wish_encore = False
            plus_tard(self, 0, lambda: self.refresh_wishlist(True))

    def _wishlist_echec(self, message: str) -> None:
        self._wishlist_fin()
        self.wishlist_view.set_progress("", 100)
        self.notify(f"Envies : verification des prix impossible ({message})", 8)

    def _wishlist_refreshed(self, alerts: list) -> None:
        self._wishlist_fin()
        self.refresh_wishlist_view()
        self.wishlist_view.set_progress("", 100)
        if not alerts:
            self.notify("Prix verifies : aucun seuil atteint")
            return
        from ..i18n import t
        from ..wishlist import message_alertes
        titre, message = message_alertes(alerts)
        self.notify(message, 12)
        if CONFIG.get("wishlist.notify", True):
            # un clic sur la notification mene aux jeux concernes
            self._system_notify(t(titre), t(message), page="wishlist")

    def _system_notify(self, title: str, message: str, page: str = "") -> None:
        """Notification Windows via l'icone de la zone de notification.
        `page` : la page d'ORION a ouvrir quand on clique sur la notification."""
        self._page_notification = page
        try:
            from PySide6.QtWidgets import QSystemTrayIcon
            if not QSystemTrayIcon.isSystemTrayAvailable():
                return
            if getattr(self, "_tray", None) is None:
                from PySide6.QtGui import QIcon
                from .icon import app_icon
                self._tray = QSystemTrayIcon(QIcon(app_icon()), self)
                self._tray.setToolTip(APP_NAME)
                self._tray.activated.connect(
                    lambda *_: (self.showNormal(), self.raise_()))
                self._tray.messageClicked.connect(self._notification_cliquee)
                self._tray.show()
            self._tray.showMessage(title, message,
                                   QSystemTrayIcon.MessageIcon.Information,
                                   8000)
        except Exception:
            log.debug("Notification systeme indisponible")

    def _notification_cliquee(self) -> None:
        self.showNormal()
        self.raise_()
        self.activateWindow()
        page = getattr(self, "_page_notification", "")
        if page:
            self.show_page(page)

    def _import_wishlist(self) -> None:
        task = Task(self.wishlist.import_steam)
        task.signals.finished.connect(self._wishlist_imported)
        task.signals.failed.connect(self._task_failed)
        task.start()

    def _wishlist_imported(self, result) -> None:
        added, message = result if isinstance(result, tuple) else (0, str(result))
        self.notify(message, 10)
        self.refresh_wishlist_view()
        if added:
            self.refresh_wishlist(True)

    def _wishlist_add(self, appid: str, title: str) -> None:
        if appid:
            self.wishlist.add(appid, title)
            self.refresh_wishlist_view()
            self.refresh_wishlist(True)
            return
        task = Task(self.wishlist.search, title)
        task.signals.finished.connect(self.wishlist_view.set_results)
        task.start()

    def _wishlist_target(self, appid: str, target: float) -> None:
        self.wishlist.set_target(appid, target)
        self.refresh_wishlist_view()

    def _wishlist_remove(self, appid: str) -> None:
        self.wishlist.remove(appid)
        self.refresh_wishlist_view()

    # ------------------------------------------------------------------
    # Manette et affichage salon
    # ------------------------------------------------------------------
    def _setup_gamepad(self) -> None:
        if not CONFIG.get("ui.gamepad", True):
            return
        bridge = GamepadBridge(self)
        if not bridge.start():
            return
        bridge.connected.connect(self._gamepad_connected)
        bridge.action.connect(self._gamepad_action)
        self.gamepad = bridge

    def _gamepad_connected(self, connected: bool) -> None:
        if connected:
            self.notify("Manette detectee : croix directionnelle pour "
                        "naviguer, A pour ouvrir, X pour jouer, Start pour "
                        "l'affichage salon", 12)

    def _gamepad_action(self, action: str) -> None:
        """Boutons qui ne correspondent pas a une touche de navigation."""
        if action == "start":
            self.toggle_big_picture()
        elif action == "x":
            widget = QApplication.focusWidget()
            game = getattr(widget, "game", None)
            if game is not None:
                self.play(game.uid, self._profile_for(game.uid))
            elif self.detail_view.game is not None and \
                    self.stack.currentIndex() == PAGES.index("detail"):
                self.play(self.detail_view.game.uid,
                          self.detail_view.profile_id)
        elif action == "y":
            self.scan()
        elif action == "back":
            if self.stack.currentIndex() == PAGES.index("detail"):
                self.show_page("library")

    def toggle_big_picture(self, enabled: bool | None = None) -> None:
        """Bascule l'affichage salon : plein ecran et grandes tuiles."""
        active = (not bool(CONFIG.get("ui.big_picture", False))
                  if enabled is None else bool(enabled))
        CONFIG.set("ui.big_picture", active)

        if active:
            self._normal_card_width = int(CONFIG.get("ui.card_width", 190))
            CONFIG.set("ui.card_width", max(self._normal_card_width, 300))
            self.sidebar.setFixedWidth(250)
            self.showFullScreen()
            self.notify("Affichage salon actif - Start pour revenir", 8)
        else:
            CONFIG.set("ui.card_width",
                       getattr(self, "_normal_card_width", 190))
            self.sidebar.setFixedWidth(212)
            self.showMaximized()

        self.library_view.set_big_picture(active)
        self.library_view.refresh()
        first = next(iter(self.library_view._cards.values()), None)
        if first is not None:
            first.setFocus()

    def _install_perf_tool(self) -> None:
        """Telecharge l'outil de mesure des images par seconde."""
        from ..perf.presentmon import ensure_tool

        self.settings_view.set_perf_tool_state("Telechargement...", True)
        task = Task(ensure_tool)
        task.signals.progress.connect(
            lambda msg, pct: self.settings_view.set_perf_tool_state(
                f"{msg} {pct} %", True))
        task.signals.finished.connect(self._perf_tool_done)
        task.signals.failed.connect(
            lambda err: self.settings_view.set_perf_tool_state(
                f"Echec : {err}"))
        task.start()

    def _perf_tool_done(self, result) -> None:
        ok, message = result if isinstance(result, tuple) else (False, str(result))
        if ok:
            CONFIG.set("perf.enabled", True)
            self.settings_view.cb_perf.setChecked(True)
            self.settings_view.set_perf_tool_state(
                "Outil installe. La mesure demarrera a votre prochaine partie.")
            self.notify("Mesure des performances activee")
        else:
            self.settings_view.set_perf_tool_state(message)

    def _refresh_perf_tool_state(self) -> None:
        from ..perf.presentmon import installed_path
        from ..i18n import t
        if not self.settings_view.perf_tool_btn.isEnabled():
            return                       # telechargement en cours : son avancement reste
        path = installed_path()
        if path and CONFIG.get("perf.acces_refuse", False):
            # derniere partie : Windows a refuse la mesure (droits)
            self.settings_view.set_perf_tool_state(
                t("Windows a refuse la derniere mesure : ajoutez votre compte au groupe "
                  "« Utilisateurs du journal de performances » (Tutos > Mesurer les images "
                  "par seconde), puis fermez et rouvrez votre session."))
            return
        self.settings_view.set_perf_tool_state(
            f"Outil present : {path.name}" if path
            else "Outil non installe.")

    def sync_community(self, force: bool = False) -> None:
        """Telecharge les recettes partagees par les autres utilisateurs."""
        if not force and self._differer("recettes"):
            return
        task = Task(self.community.sync, force)
        task.signals.finished.connect(self._community_done)
        task.signals.failed.connect(
            lambda err: self.settings_view.set_community_state(
                f"Synchronisation impossible : {err}"))
        task.start()

    def _community_done(self, result: dict) -> None:
        self.optimizer.reload()
        self._refresh_community_state()
        if result.get("error"):
            self.settings_view.set_community_state(
                f"{result['error']}  ({self.community.installed} recette(s) "
                "deja installee(s))")
            return
        if result.get("added") or result.get("updated"):
            self.notify(
                f"Recettes partagees : {result['added']} ajoutee(s), "
                f"{result['updated']} mise(s) a jour")
        if self.detail_view.game is not None:
            self._build_plan(self.detail_view.game, self.detail_view.profile_id)

    def _refresh_community_state(self) -> None:
        import time as _time
        last = self.community.last_sync
        when = (_time.strftime("%d/%m a %H:%M", _time.localtime(last))
                if last else "jamais")
        self.settings_view.set_community_state(
            f"{self.community.installed} recette(s) partagee(s) installee(s) - "
            f"derniere synchronisation : {when}")

    # ------------------------------------------------------------------
    # Captures pour le site web
    # ------------------------------------------------------------------
    def capturer_pour_le_site(self) -> None:
        """Photographie chaque page avec les vraies donnees, en pleine
        resolution, dans le dossier « captures-site » des donnees d'ORION.

        Chaque page a le temps de se remplir (jaquettes, prix, captures)
        avant d'etre photographiee. La fiche montree est celle du jeu le plus
        joue qui a des captures d'ecran.
        """
        from ..core.paths import DATA_DIR
        dossier = DATA_DIR / "captures-site"
        dossier.mkdir(parents=True, exist_ok=True)
        jeux = sorted(self.library.games(), key=lambda g: -g.total_play_seconds)
        vedette = next((g for g in jeux if (self.market.en_cache(g, True) or
                                            MarketInfo()).screenshots), None) \
            or (jeux[0] if jeux else None)
        etapes = [("bibliotheque", lambda: self.show_page("library"))]
        if vedette is not None:
            etapes.append(("fiche-jeu", lambda: self.open_game(vedette.uid)))
            etapes.append(("fiche-jeu-bas", lambda: self._defiler_fiche()))
        etapes += [
            ("boutique", lambda: self.show_page("boutique")),
            ("envies", lambda: self.show_page("wishlist")),
            ("jeux-gratuits", lambda: self.show_page("free")),
            ("ma-machine", lambda: self.show_page("hardware")),
            ("stockage", lambda: self.show_page("storage")),
            ("tuto", lambda: self.show_page("tutorial")),
            ("reglages", lambda: self.show_page("settings")),
        ]
        self.notify("Captures pour le site en cours : ne touchez a rien...", 30)

        def suivante(i: int = 0) -> None:
            if i >= len(etapes):
                self.show_page("library")
                self.notify(f"{len(etapes)} captures enregistrees dans {dossier}", 15)
                log.info("Captures du site : %s", dossier)
                return
            nom, action = etapes[i]
            action()
            plus_tard(self, 3500, lambda: (
                self.grab().save(str(dossier / f"{nom}.png"), "PNG"),
                suivante(i + 1)))
        suivante()

    def _defiler_fiche(self) -> None:
        """Fait defiler la fiche jusqu'aux captures et actualites."""
        from PySide6.QtWidgets import QScrollArea
        zone = self.detail_view.findChild(QScrollArea)
        if zone is not None:
            cible = self.detail_view.shots_panel if self.detail_view.shots_panel.isVisible() \
                else self.detail_view.news_panel
            zone.ensureWidgetVisible(cible, 0, 40)
            barre = zone.verticalScrollBar()
            barre.setValue(min(barre.maximum(), cible.y() - 60))

    def _watch_tick(self) -> None:
        """Veille : detecte les jeux installes depuis le dernier passage."""
        if self._busy or not CONFIG.get("scan.watch_enabled", True):
            return
        if self._differer("veille"):
            return
        # la veille est une analyse : pas d'analyse complete en parallele
        self._busy = True
        task = Task(self.library.scan, quick=True)
        task.signals.finished.connect(self._watch_done)
        task.signals.failed.connect(self._watch_echec)
        task.start()

    def _watch_echec(self, message: str) -> None:
        self._busy = False
        log.warning("Veille des installations : %s", message)

    def _watch_done(self, result: dict) -> None:
        self._busy = False
        added = result.get("added", 0)
        partis = result.get("removed", 0) + result.get("missing", 0)
        if added or partis:
            self._au_repos("library", self.refresh_library)
        if added:
            self.fetch_artwork()
        messages = []
        if added:
            messages.append(f"{added} nouveau(x) jeu(x) detecte(s)")
        if partis:
            messages.append(f"{partis} jeu(x) desinstalle(s) retire(s)")
        if messages:
            self.notify("  ·  ".join(messages), 8)

    def _boot(self) -> None:
        self.refresh_library()
        # veille rapide des le demarrage : un jeu desinstalle pendant
        # qu'ORION etait ferme disparait sans attendre « Analyser »
        plus_tard(self, 4000, self._watch_tick)
        self.refresh_hardware()
        self._refresh_donate()

        self.refresh_wishlist_view()
        # minuterie creee meme si la liste est vide : un jeu suivi plus tard
        # depuis la Boutique doit lui aussi etre surveille
        self._appliquer_frequence_envies()
        if self.wishlist.items:
            plus_tard(self, 20000, lambda: self.refresh_wishlist())

        # pages qui ne sont pas a l'ecran au demarrage : remplies des que la
        # fenetre est au calme (ou a leur ouverture), pas pendant qu'elle
        # s'affiche
        self._au_repos("free", self.refresh_free_view)
        self._appliquer_frequence_gratuits()
        if CONFIG.get("free.enabled", True):
            plus_tard(self, 30000, lambda: self.refresh_free())

        # Boutique : vitrine actualisee toutes les 10 a 15 minutes
        self._au_repos("boutique", self.refresh_boutique_view)
        minutes = self.boutique.intervalle_minutes()
        self._boutique_timer = QTimer(self)
        self._boutique_timer.timeout.connect(lambda: self.refresh_boutique())
        self._boutique_timer.start(minutes * 60 * 1000)
        if time.time() - self.boutique.actualise_le > minutes * 60:
            plus_tard(self, 15000, lambda: self.refresh_boutique())

        if self.community.should_sync():
            self.sync_community()
        self._refresh_community_state()
        self._refresh_perf_tool_state()
        self._setup_gamepad()

        self._appliquer_veille()
        if CONFIG.get("scan.auto_scan_on_start", True) and not self.library.games():
            self.scan()
        elif self.library.games():
            self.fetch_artwork()
        self._boot_fond()
        self._boot_comptes()
        self._reparer_deplacements()      # deplacement de jeu interrompu ?
        self._boot_puissance()
        self._boot_sorties()
        # a partir d'ici, un reglage change s'applique tout de suite
        self._reglages_actifs = True

    def notify(self, message: str, seconds: int = 6) -> None:
        self.status_label.setText(message)
        log.info("Notification : %s", message)
        # une seule minuterie : un message court precedent ne doit pas
        # effacer avant l'heure un message plus long arrive ensuite
        minuterie = getattr(self, "_timer_notify", None)
        if minuterie is None:
            minuterie = self._timer_notify = QTimer(self)
            minuterie.setSingleShot(True)
            minuterie.timeout.connect(
                lambda: self.status_label.setText(f"{APP_NAME} {APP_VERSION}"))
        minuterie.start(max(1, int(seconds)) * 1000)

    def _background_changed(self) -> None:
        """Le decor a change dans les reglages : on le relit tout de suite."""
        self.backdrop.reload()
        self.backdrop.update()

    # ------------------------------------------------------------------
    # Mises a jour de fond : pas pendant un geste du joueur
    # ------------------------------------------------------------------
    #: vrai dans l'application lancee (voir `app.py`) : les resultats des
    #: taches de fond attendent un moment de calme (`ui/repos.py`). Faux par
    #: defaut : une fenetre construite a la main les applique tout de suite.
    mises_a_jour_au_repos = False

    def chercher_ici(self) -> None:
        """Ctrl+F : met le curseur dans la recherche de la page affichee.
        Depuis une page sans recherche (fiche d'un jeu, Comptes, Conseils...),
        c'est celle de la bibliotheque."""
        page = PAGES[self.stack.currentIndex()] if \
            0 <= self.stack.currentIndex() < len(PAGES) else "library"
        if page == "boutique":
            champ = self.boutique_view.recherche \
                if self.boutique_page.onglet != "gratuits" else None
            if champ is not None:
                champ.setFocus()
                champ.selectAll()
                return
        cible = {"hardware": self.hardware_view, "storage": self.storage_view,
                 "settings": self.settings_view}.get(page)
        if cible is None:
            if page != "library":
                self.show_page("library")
            cible = self.library_view
        cible.chercher()

    def chercher_en_boutique(self, terme: str) -> None:
        """Recherche lancee depuis la bibliotheque : « ce jeu n'est pas chez
        moi, ou le trouver ? »"""
        terme = (terme or "").strip()
        self.show_page("boutique")
        self.boutique_page.montrer("offres")
        if terme:
            vue = self.boutique_view
            if vue._genre or vue._liste:
                vue.accueil()                 # la recherche porte sur tout le magasin
            vue.recherche.setText(terme)
            vue.recherche.setFocus()

    def _au_repos(self, cle: str, fonction) -> None:
        """Applique le resultat d'une tache de fond sans couper un geste :
        tout de suite si la fenetre n'est pas en service normal, sinon au
        prochain moment de calme. `cle` est la page concernee : l'ouvrir
        applique aussitot ce qui attend."""
        if self.mises_a_jour_au_repos:
            from . import repos
            repos.differer(cle, fonction)
        else:
            fonction()

    def show_page(self, key: str) -> None:
        from . import repos
        for cle in {key, ALIAS_PAGES.get(key, (key,))[0]} | (
                {"free"} if key == "boutique" else set()):
            repos.faire(cle)             # la page ouverte doit etre a jour
        if key == "storage":
            self.refresh_storage()
        if key == "settings":
            # une partie a pu finir sur un refus de mesure par Windows
            self._refresh_perf_tool_state()
        if key == "advice":
            # conseils relus a chaque visite (l'etat du systeme est en memoire)
            self.advice_view.set_advice(
                advisor.for_system(self.hw, self.library.games()), analyse=False)
        # la fiche d'un jeu a son propre visuel en tete : pas de banniere de saison
        self.backdrop.montrer_banniere(key != "detail")
        if key != "detail":
            # hors fiche de jeu, le decor revient a l'image de l'application
            self.backdrop.set_dynamic_art("")
            # et la video eventuelle de la fiche s'arrete
            self.detail_view.arreter_videos()
        from .. import compteur
        compteur.page(key)
        onglet = ""
        if key in ALIAS_PAGES:
            key, onglet = ALIAS_PAGES[key]
        if key in PAGES:
            self.stack.setCurrentIndex(PAGES.index(key))
            if onglet:
                self.boutique_page.montrer(onglet)
            # la fiche d'un jeu reste rattachee a la bibliotheque
            self.sidebar.select_page("library" if key == "detail" else key)

    # ------------------------------------------------------------------
    # Bibliotheque
    # ------------------------------------------------------------------
    def refresh_library(self) -> None:
        games = self.library.games(include_hidden=CONFIG.get("ui.show_hidden", False))
        self.library_view.set_games(games)
        vedettes = self._featured_games(games)
        self.library_view.set_featured(
            vedettes,
            {g.uid: self._profile_for(g.uid) for g in vedettes},
            {g.uid: self._is_tunable(g) for g in vedettes})
        counts: dict[str, int] = {}
        for g in games:
            counts[g.source] = counts.get(g.source, 0) + 1
        labels = {s.id: s.label for s in self.library.scanners}
        self.sidebar.set_sources(counts, labels)
        last = self.library.store.last_scan
        self.sidebar.set_status(
            f"{len(games)} jeux\nAnalyse : " +
            (time.strftime("%d/%m a %H:%M", time.localtime(last)) if last else "jamais"))
        # page Comptes : jeux installes par plateforme et jeux en double
        self._compter_locaux()

    @staticmethod
    def _featured_games(games: list) -> list:
        """Jeux que la banniere fait defiler, dans l'ordre.

        La premiere place revient au dernier jeu joue : c'est la reponse a
        « qu'est-ce que je relance ? ». Viennent ensuite les favoris, les
        parties recentes, puis les installations recentes — de quoi faire
        remonter des jeux oublies sans jamais bousculer la premiere place.
        """
        jouables = [g for g in games
                    if not g.hidden and not g.extra.get("missing")]
        if not jouables:
            return []

        joues = sorted((g for g in jouables if g.last_played),
                       key=lambda g: -g.last_played)
        favoris = sorted((g for g in jouables if g.favorite),
                         key=lambda g: g.title.lower())
        recents = sorted(jouables,
                         key=lambda g: -(g.last_updated or g.installed_at))

        ordre: list = []
        vus: set[str] = set()
        for lot in (joues[:1], favoris, joues[1:5], recents):
            for jeu in lot:
                if jeu.uid not in vus:
                    vus.add(jeu.uid)
                    ordre.append(jeu)
        limite = max(1, int(CONFIG.get("ui.hero_count", 8) or 8))
        return ordre[:limite]

    def _is_tunable(self, game) -> bool:
        """Vrai si ORION sait ecrire des reglages dans ce jeu.

        Sert a ne pas proposer de profil graphique sur un jeu qui n'expose
        aucun fichier de configuration : la recette retenue n'ecrirait
        nulle part.
        """
        try:
            from ..optimizer.engine import select_recipe
            # les recettes deja chargees : les relire sur le disque pour
            # chaque jeu, a chaque rafraichissement, figeait la fenetre
            recipe = select_recipe(game, self.optimizer.recipes)
            return bool(recipe is not None and recipe.targets)
        except Exception:
            return True

    def _filters_changed(self, sources: set) -> None:
        self.library_view.set_source_filter(sources)

    def scan(self) -> None:
        if self._busy:
            self.notify("Une analyse est deja en cours")
            return
        self._busy = True
        self.library_view.set_progress("Analyse en cours...", 1)

        task = Task(self.library.scan)
        task.signals.progress.connect(
            lambda msg, pct: self.library_view.set_progress(msg, pct))
        task.signals.finished.connect(self._scan_done)
        task.signals.failed.connect(self._scan_echec)
        task.start()

    def _scan_echec(self, message: str) -> None:
        """Seul l'echec de l'analyse libere le verrou de l'analyse."""
        self._busy = False
        self.library_view.set_progress("", 100)
        self._task_failed(message)

    def _scan_done(self, result: dict) -> None:
        self._busy = False
        self.library_view.set_progress("", 100)
        self.refresh_library()
        message = (f"{result['total']} jeux detectes "
                   f"({result['added']} nouveaux) en {result['seconds']} s")
        if result.get("missing"):
            message += (f" - {result['missing']} declares par leur plateforme "
                        "mais absents du disque")
        if result.get("ignored"):
            message += f" - {result['ignored']} lanceurs ecartes"
        self.notify(message, 10)
        self.fetch_artwork()
        if not CONFIG.get("bilan.montre", False):
            plus_tard(self, 4000, self._bilan_premier_lancement)
        # la vue web des bandes-annonces se cree maintenant, en temps mort,
        # plutot qu'a la premiere fiche ouverte (fenetre figee 0,7 a 1,0 s)
        plus_tard(self, 15000, self.detail_view.lecteur.prechauffer)

    def _visuel_pret(self, uid: str) -> None:
        game = self.library.get(uid)
        if game is not None:
            self.library_view.update_card(game)

    def fetch_artwork(self, force: bool = False) -> None:
        games = self.library.games(include_hidden=True)
        try:                               # les jeux affiches passent en premier
            rang = {g.uid: i for i, g in enumerate(self.library_view.visible_games())}
            games = sorted(games, key=lambda g: rang.get(g.uid, len(rang)))
        except Exception:
            pass
        if not games or not CONFIG.get("artwork.enabled", True):
            return
        if not force and self._differer("jaquettes"):
            return

        def work(progress_cb=None):
            if force:
                for g in games:
                    for kind in ("cover", "hero", "logo"):
                        setattr(g, f"art_{kind}", "")
            changed = self.artwork.ensure_many(games, progress_cb)
            self.library.save()
            return changed

        task = Task(work)
        task.signals.progress.connect(
            lambda msg, pct: self.library_view.set_progress(msg, pct))
        task.signals.finished.connect(self._artwork_done)
        task.signals.failed.connect(self._artwork_echec)
        task.start()

    def _artwork_echec(self, message: str) -> None:
        if not self._busy:                  # la barre appartient a l'analyse
            self.library_view.set_progress("", 100)
        self._task_failed(message)

    def _artwork_done(self, changed: int) -> None:
        self.library_view.set_progress("", 100)
        self._au_repos("library", self.refresh_library)
        if changed:
            self.notify(f"Visuels recuperes pour {changed} jeux")

    def reload_plugins(self) -> None:
        self.library.reload_plugins()
        self.artwork.reload_plugins()
        self.optimizer.reload()
        self.market.reload_plugins()
        self.notify("Extensions et recettes rechargees")

    # ------------------------------------------------------------------
    # Valeur de la bibliotheque (prix du catalogue possede, indicatif)
    # ------------------------------------------------------------------
    def _init_valeur(self) -> None:
        from ..valeur_catalogue import derniere
        self._valeur_busy = False
        self._valeur_encore = False
        self._valeur_timer = QTimer(self)
        self._valeur_timer.setSingleShot(True)
        self._valeur_timer.timeout.connect(self.calculer_valeur)
        # les ajouts et retraits arrivent par rafales (analyse, comptes) :
        # un seul calcul, quelques secondes apres le dernier changement
        self.library_view.contenu_change.connect(lambda: self._valeur_timer.start(8000))
        self.library_view.set_valeur(derniere())

    def calculer_valeur(self) -> None:
        """Prix actuel du catalogue possede, calcule en arriere-plan."""
        from ..valeur_catalogue import estimer, preparer
        if getattr(self, "en_partie", False):
            self._valeur_timer.start(10 * 60 * 1000)     # apres la partie
            return
        if self._valeur_busy:
            self._valeur_encore = True
            return
        jeux = list(self.library.games(include_hidden=False))
        possedes = getattr(self, "possedes", None)
        if possedes is not None:
            jeux += [g for g in possedes.tous() if not g.hidden]
        if not jeux:
            self.library_view.set_valeur(None)
            return
        try:
            instantane = preparer(jeux, dict(getattr(self.market, "_cache", {}) or {}),
                                  list(getattr(self.boutique, "fiches", []) or []))
        except Exception:
            log.exception("Valeur de la bibliotheque : preparation impossible")
            return
        self._valeur_busy = True
        task = Task(estimer, instantane, bool(CONFIG.get("market.enabled", True)))
        task.signals.finished.connect(self._valeur_calculee)
        task.signals.failed.connect(self._valeur_echec)
        task.start()

    def _valeur_calculee(self, valeur) -> None:
        from ..valeur_catalogue import retenir
        self._valeur_busy = False
        self.library_view.set_valeur(valeur)
        if valeur is not None and valeur.connue:
            retenir(valeur)
        partiel = bool(valeur is not None and valeur.partiel)
        if self._valeur_encore or partiel:
            self._valeur_encore = False
            # nouveau changement entre-temps, ou Steam en pause : on reprend
            self._valeur_timer.start(6 * 60 * 1000 if partiel else 8000)

    def _valeur_echec(self, message: str) -> None:
        self._valeur_busy = False
        log.warning("Valeur de la bibliotheque : %s", message)

    # ------------------------------------------------------------------
    # Materiel
    # ------------------------------------------------------------------
    def refresh_hardware(self, force: bool = False) -> None:
        task = Task(probe, force)
        task.signals.finished.connect(self._hardware_done)
        task.signals.failed.connect(self._task_failed)
        # la page Conseils ne reste pas « Analyse... » si l'analyse echoue
        task.signals.failed.connect(lambda _m: self.advice_view.set_occupe(False))
        task.start()

    def _page_affichee(self) -> str:
        i = self.stack.currentIndex()
        return PAGES[i] if 0 <= i < len(PAGES) else ""

    def _pour_la_page(self, cle: str, fonction) -> None:
        """Resultat d'une tache de fond destine a une page : tout de suite si
        le joueur la regarde (il l'attend), sinon au repos ou a son
        ouverture."""
        if self._page_affichee() == cle:
            fonction()
        else:
            self._au_repos(cle, fonction)

    def _hardware_done(self, hw: HardwareInfo) -> None:
        self.hw = hw

        def montrer() -> None:
            self.hardware_view.set_hardware(hw)
            self._refresh_bilan()
        # l'analyse du materiel finit une dizaine de secondes apres le
        # demarrage : reconstruire « Ma machine » et les cartes de conseils a
        # ce moment-la coupait le geste en cours sur une autre page
        self._pour_la_page("hardware", montrer)
        if self._page_affichee() == "storage":
            self.refresh_storage()
        self._pour_la_page("advice", lambda: self.advice_view.set_advice(
            advisor.for_system(hw, self.library.games())))
        # l'ecran choisi sur la fiche ouverte est conserve (il revenait au
        # premier ecran apres chaque changement de mode d'affichage)
        choisi = self.detail_view.selected_display()
        if not choisi and self.detail_view.game is not None:
            choisi = self.detail_view.game.preferred_display or ""
        self.detail_view.set_displays(hw.displays, choisi)
        # le calculateur de puissance suit le materiel (premiere analyse
        # terminee apres son premier passage, « Reanalyser », nouvel ecran)
        if hasattr(self, "_puissance_occupe"):
            self.actualiser_puissance()

    def _pastille_conseils(self, alertes: int) -> None:
        """Nombre de points « a corriger » a cote de « Conseils » dans le
        menu : on sait qu'il y a quelque chose a voir sans ouvrir la page."""
        from .theme import PALETTE
        self.sidebar.set_pastille(
            "advice", str(alertes) if alertes else "", PALETTE["warn"],
            f"{alertes} point(s) a corriger sur cette machine" if alertes else "")

    def _apply_display_mode(self, device: str, mode: DisplayMode) -> None:
        if mode is None:
            return
        ok, msg = apply_mode(device, mode)
        self.notify(msg)
        if ok:
            plus_tard(self, 1200, lambda: self.refresh_hardware(True))

    # ------------------------------------------------------------------
    # Fiche de jeu
    # ------------------------------------------------------------------
    def _boutique_vers_bibliotheque(self, appid: str, titre: str) -> None:
        """« Voir dans ma bibliotheque » depuis la Boutique : la fiche du jeu
        installe, sinon la bibliotheque filtree sur son titre (jeu possede pas
        encore installe)."""
        from ..suggestions import appid_steam, cle_titre
        cible = cle_titre(titre)
        for game in self.library.games():
            if (appid and appid_steam(game) == appid) or (cible and cle_titre(game.title) == cible):
                self.open_game(game.uid)
                return
        self.show_page("library")
        self.library_view.search.setText(titre)

    def open_game(self, uid: str) -> None:
        game = self.library.get(uid)
        if game is None:
            if self.possedes.get(uid) is not None:
                self.installer_possede(uid)
            return
        self.detail_view.set_displays(
            self.hw.displays, game.preferred_display or "")
        self.detail_view.set_game(game, self.hw)
        # plus rien du jeu precedent : prix, captures et actualites sont
        # vides tant que ceux de ce jeu ne sont pas la
        self.detail_view.set_market_loading()
        self.detail_view.set_ai_output("")
        # le decor prend la couleur du jeu ouvert : l'application respire
        # avec ce qu'on regarde plutot que de rester figee.
        self.backdrop.set_dynamic_art(game.art_hero or game.art_cover or "")
        self.show_page("detail")
        # le profil surligne par la fiche est celui du plan demande
        self._build_plan(game, self.detail_view.profile_id)
        self._load_market(uid)
        self._load_saves(game)
        self.charger_succes(game)

    def _profile_for(self, uid: str) -> str:
        game = self.library.get(uid)
        from ..optimizer.profiles import profil_par_defaut
        return (game.preferred_profile if game and game.preferred_profile
                else profil_par_defaut())

    def _profile_changed(self, uid: str, profile_id: str) -> None:
        game = self.library.get(uid)
        if game is None:
            return
        game.preferred_profile = profile_id
        game.preferred_display = self.detail_view.selected_display()
        self.library.save()
        self._build_plan(game, profile_id)

    def _apercu_cible(self, uid: str, niveau: str, cible: int) -> None:
        """Le joueur change le niveau ou l'objectif dans « Mon choix » : la
        carte montre ce que ce reglage donnerait, rien n'est ecrit."""
        from ..optimizer import choix as choix_mod
        game = self.library.get(uid)
        if game is None:
            return
        display = self._display_for(game)
        try:
            c = choix_mod.pour_choix(game, self.hw, display, niveau, int(cible or 0))
        except Exception:
            log.exception("Apercu du choix impossible")
            return
        self.detail_view.choix.set_apercu(c)

    def _apprendre_niveaux(self, uid: str) -> None:
        """Apprentissage par l'exemple : le joueur choisit des niveaux dans le
        menu du jeu, ORION retient ce que le jeu ecrit (optimizer/exemple.py)."""
        game = self.library.get(uid)
        if game is None:
            return
        from .widgets.apprendre import ApprendreNiveaux
        boite = ApprendreNiveaux(game, self)

        def appris(_chemin: str) -> None:
            self.optimizer.reload()
            courant = getattr(self.detail_view, "game", None)
            if courant is not None and courant.uid == uid:
                self._build_plan(game, "recommande")
        boite.appris.connect(appris)
        boite.exec()

    def _case_sr(self, uid: str, carte: str, coche: bool) -> None:
        """La case DLSS / FSR / XeSS d'une carte : memorisee pour ce jeu ; si
        cette carte est celle en place, le jeu est reecrit tout de suite."""
        from ..optimizer import choix as choix_mod
        game = self.library.get(uid)
        if game is None:
            return
        choix_mod.choisir_sr(game, carte, coche)
        self.library.save()
        if choix_mod.choix_du_jeu(game) != carte:
            return
        if carte == "choix":
            n, c = choix_mod.choix_memorise(game)
            self._choix_graphismes(uid, n, c)
        else:
            self._choix_graphismes(uid, "", 0)

    def _choix_graphismes(self, uid: str, niveau: str, cible: int) -> None:
        """Une carte cliquee (« Votre ecran » : niveau vide et objectif 0, ou
        « Mon choix » : le niveau et l'objectif choisis) : le choix est
        memorise pour ce jeu, le plan refait, et les reglages ECRITS tout de
        suite (sauvegarde avant, relecture apres), sans fenetre de
        confirmation (demande du 7 octobre)."""
        from ..optimizer import choix as choix_mod
        game = self.library.get(uid)
        if game is None:
            return
        display = self._display_for(game)
        choix_mod.choisir(game, niveau, int(cible or 0))
        game.preferred_profile = "recommande"
        game.preferred_display = self.detail_view.selected_display()
        self.library.save()
        nom = choix_mod.NOMS["ecran"]
        if choix_mod.choix_du_jeu(game) == "choix":
            n, c = choix_mod.choix_memorise(game)
            nom = f"{choix_mod.NOMS['choix']}, {NOMS_NIVEAUX.get(n, n)}" + (f", {c} i/s" if c else "")
        task = Task(self.optimizer.build_plan, game, "recommande", self.hw, display)
        task.signals.finished.connect(
            lambda plan: self._plan_choisi_pret(game, nom, plan, display))
        task.signals.failed.connect(self._task_failed)
        task.start()

    def _plan_choisi_pret(self, game: Game, nom: str, plan, display) -> None:
        self._plan_ready(game, "recommande", plan, display)
        if not self._plan_est_courant(game, "recommande"):
            return
        if not plan.tunable:
            self.detail_view.choix.set_ecrit(
                f"{nom} retenu : a regler dans le menu du jeu (voir le guide).")
            return
        ok, msg = self._ecrire_plan(game, plan)
        self.detail_view.choix.set_ecrit(
            f"Reglages ecrits : {nom}. Restaurer pour revenir." if ok
            else f"Reglages non ecrits : {msg}")
        self._build_plan(game, "recommande")       # etat des reglages relu

    def _ecrire_plan(self, game: Game, plan) -> tuple[bool, str]:
        """Ecrit un plan (sauvegarde avant, relecture apres) et regle l'ecran
        si le plan le demande. Pas de question : l'appelant a deja decide."""
        ok, msg = self.optimizer.apply_plan(game, plan)
        if ok and plan.display_mode and plan.display_changes \
                and CONFIG.get("optimizer.apply_display_mode", True):
            ok2, msg2 = apply_mode(plan.display_device, plan.display_mode)
            msg += f" · ecran : {msg2}"
            if ok2:
                plus_tard(self, 1200, lambda: self.refresh_hardware(True))
        self.notify(msg)
        return ok, msg

    def _defaut_graphismes(self, uid: str) -> None:
        """« Redefinir les parametres par defaut » : remet le jeu dans l'etat
        d'avant la PREMIERE intervention d'ORION (sa premiere sauvegarde),
        avec confirmation, et oublie le choix fait pour ce jeu."""
        from ..optimizer import choix as choix_mod
        game = self.library.get(uid)
        if game is None:
            return
        slots = backup.list_backups(game)
        if not slots:
            self.notify("Aucune sauvegarde pour ce jeu : rien a remettre")
            return
        origine = slots[-1]                         # la plus ancienne
        stamp = time.strftime("%d/%m/%Y a %H:%M", time.localtime(origine.get("at", 0)))
        answer = QMessageBox.question(
            self, "Redefinir les parametres par defaut",
            f"Remettre {game.title} dans l'etat d'avant la premiere intervention "
            f"d'ORION (sauvegarde du {stamp}) ?\n\nLes reglages ecrits depuis seront "
            "remplaces par ceux d'origine.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if answer != QMessageBox.StandardButton.Yes:
            return
        ok, msg = backup.restore(origine["path"])
        choix_mod.oublier(game)
        game.preferred_profile = "recommande"
        self.library.save()
        self.notify(msg)
        self.detail_view.choix.set_ecrit("Parametres d'origine remis." if ok else msg)
        self._build_plan(game, "recommande")

    def _display_for(self, game: Game):
        want = self.detail_view.selected_display() or game.preferred_display
        for d in self.hw.displays:
            if d.device == want:
                return d
        return self.hw.primary_display

    def _build_plan(self, game: Game, profile_id: str) -> None:
        display = self._display_for(game)
        task = Task(self.optimizer.build_plan, game, profile_id, self.hw, display)
        task.signals.finished.connect(
            lambda plan: self._plan_ready(game, profile_id, plan, display))
        task.signals.failed.connect(self._task_failed)
        task.start()

    def _plan_est_courant(self, game: Game, profile_id: str) -> bool:
        """Vrai si la fiche montre encore ce jeu avec ce profil."""
        courant = self.detail_view.game
        return (courant is not None and courant.uid == game.uid
                and self.detail_view.profile_id == profile_id)

    def _plan_ready(self, game: Game, profile_id: str, plan, display) -> None:
        # un plan arrive en retard (autre jeu ouvert, autre profil choisi
        # entre-temps) est ignore : sinon « Appliquer » ecrirait ses reglages
        if not self._plan_est_courant(game, profile_id):
            log.debug("Plan perime ignore : %s / %s", game.title, profile_id)
            return
        from ..optimizer.profiles import donnees_fiche, profil_par_defaut
        profile = PROFILES.get(profile_id) or PROFILES[profil_par_defaut()]
        settings = describe(compute_settings(profile, self.hw, display, game))
        self.detail_view.set_plan(plan, settings,
                                  advisor.for_game(game, self.hw, display))
        self.detail_view.set_graphismes(donnees_fiche(game, self.hw, display, plan))
        self._refresh_perf(game, display)

    def _refresh_perf(self, game: Game, display) -> None:
        """Met a jour le panneau des performances mesurees."""
        from ..optimizer.adaptive import suggest

        by_profile = self.perf.by_profile(game.uid)
        hint = ""
        if not by_profile:
            if not CONFIG.get("perf.enabled", False):
                hint = ("Mesure desactivee - activez-la dans Reglages pour "
                        "connaitre vos images par seconde reelles")
            else:
                hint = "Aucune mesure pour l'instant : lancez une partie"
        from ..optimizer.adaptive import proposals, stored_tuning

        advice = suggest(game, by_profile, self.hw, display)
        profile_id = self.detail_view.profile_id
        can_tune = any(p.changes for p in
                       proposals(game, by_profile, self.hw, display)
                       if p.profile == profile_id)
        tuned = bool(stored_tuning(game, profile_id))
        if tuned:
            advice = (advice + "\n\nCe profil est ajuste pour ce jeu "
                      "d'apres vos mesures.").strip()
        self.detail_view.set_perf(by_profile, advice, hint, can_tune, tuned)

    # ------------------------------------------------------------------
    # Prix et evaluation
    # ------------------------------------------------------------------
    def _load_market(self, uid: str, force: bool = False) -> None:
        game = self.library.get(uid)
        if game is None:
            return
        # affichage immediat de ce qui est deja connu (disque), puis releve
        # en arriere-plan seulement si c'est necessaire
        if not force:
            connu = self.market.en_cache(game, meme_perime=True)
            if connu is not None:
                self._market_ready(uid, connu, releve=False)   # rien de neuf a ecrire
                if self.market.en_cache(game) is not None:
                    return          # a jour : rien a demander au reseau
                if not (connu.developer or connu.review_count or connu.screenshots):
                    # ancien releve vide (jeu pas encore reconnu) : on montre
                    # que la recherche est en cours plutot que « rien trouve »
                    self.detail_view.set_market_loading()
        else:
            self.detail_view.set_market_loading()
        task = Task(self.market.get, game, force)
        task.signals.finished.connect(
            lambda info, u=uid: self._market_ready(u, info))
        task.signals.failed.connect(self._task_failed)
        task.start()

    def _market_ready(self, uid: str, info, releve: bool = True) -> None:
        if self.detail_view.game and self.detail_view.game.uid == uid:
            self.detail_view.set_market(info)
            if releve:
                self.library.save()  # identifiant Steam eventuellement retrouve
            self._charger_joueurs(uid, info)
            # traduction faite ici, a l'ouverture de la fiche, et non a chaque
            # releve de prix (la veille des Envies en fait des dizaines)
            if self.market.a_traduire(info):
                task = Task(self.market.traduire_actus, uid, info)
                task.signals.finished.connect(
                    lambda inf, u=uid: self._news_translated(u, inf))
                task.start()

    # -- joueurs en ligne (1.8.1) -----------------------------------------
    def _charger_joueurs(self, uid: str, info=None) -> None:
        """Joueurs Steam connectes en ce moment, pour un jeu en ligne."""
        from .. import en_ligne
        from ..core.liens import appid_steam
        game = self.library.get(uid)
        if info is None:
            info = self.market.en_cache(game, meme_perime=True) if game else None
        if game is None or info is None or not en_ligne.est_en_ligne(info.categories):
            return
        # Un jeu installe par Battle.net, Rockstar, EA... a l'essentiel de ses
        # joueurs hors de Steam : afficher « N joueurs sur Steam » pour lui
        # serait faux. Le compteur est reserve aux jeux joues par Steam.
        if game.source != "steam":
            return
        appid = appid_steam(game)
        if not appid:
            return
        t = Task(en_ligne.joueurs, appid)
        t.signals.finished.connect(
            lambda n, u=uid: self.detail_view.game and self.detail_view.game.uid == u
            and self.detail_view.set_joueurs(en_ligne.texte(n)))
        t.start()
        if not hasattr(self, "_timer_joueurs"):
            self._timer_joueurs = QTimer(self)
            self._timer_joueurs.timeout.connect(self._rafraichir_joueurs)
            self._timer_joueurs.start(en_ligne.GARDER * 1000)

    def _rafraichir_joueurs(self) -> None:
        if (self.stack.currentIndex() == PAGES.index("detail") and self.detail_view.game
                and self.isVisible() and not self.isMinimized()):
            self._charger_joueurs(self.detail_view.game.uid)

    def _news_translated(self, uid: str, info) -> None:
        if self.detail_view.game and self.detail_view.game.uid == uid:
            self.detail_view._fill_news(info)

    # ------------------------------------------------------------------
    # Assistant IA
    # ------------------------------------------------------------------
    def _run_ai(self, uid: str, kind: str) -> None:
        from ..ai import tasks as ai_tasks
        from ..ai.client import AIClient

        game = self.library.get(uid)
        if game is None:
            return
        if not AIClient().configured():
            self.detail_view.set_ai_output(
                "Aucun assistant configure. Ouvrez Reglages puis Assistant IA : "
                "une cle gratuite (Gemini, Mistral) ou un modele local Ollama "
                "suffisent.")
            return

        display = self._display_for(game)
        plan = self.detail_view.plan
        profile = self.detail_view.profile_id

        if kind == "recipe":
            fn, args = ai_tasks.generate_recipe, (game, self.hw)
            message = ("Analyse des fichiers de configuration du jeu en "
                       "cours...")
        elif kind == "buy":
            info = getattr(self.detail_view, "market", None)
            summary = self._market_summary(info)
            fn, args = ai_tasks.buying_advice, (game, summary)
            message = "Analyse des prix en cours..."
        elif kind == "diagnose":
            symptom, ok = QInputDialog.getText(
                self, "Diagnostic",
                "Decrivez le probleme (saccades, ecran noir, fps bas...) :")
            if not ok or not symptom.strip():
                return
            fn, args = ai_tasks.diagnose, (game, self.hw, display, symptom.strip())
            message = "Diagnostic en cours..."
        else:
            fn, args = ai_tasks.advise_game, (game, self.hw, display, profile, plan)
            message = "Analyse du jeu en cours..."

        self.detail_view.set_ai_output(message, busy=True)
        task = Task(fn, *args)
        task.signals.finished.connect(
            lambda result, k=kind, u=uid: self._ai_ready(k, result, u))
        task.signals.failed.connect(
            lambda err, u=uid: self._fiche_montre(u)
            and self.detail_view.set_ai_output(f"Echec : {err}"))
        task.start()

    def _fiche_montre(self, uid: str) -> bool:
        return self.detail_view.game is not None and self.detail_view.game.uid == uid

    def _ai_ready(self, kind: str, result, uid: str = "") -> None:
        ok, text = result if isinstance(result, tuple) else (True, str(result))
        if ok and kind == "recipe":
            self.optimizer.reload()         # la recette sert quel que soit le jeu affiche
        if uid and not self._fiche_montre(uid):
            return                          # le joueur a change de jeu entre-temps
        self.detail_view.set_ai_output(text)
        if ok and kind == "recipe":
            game = self.detail_view.game
            if game is not None:
                self._build_plan(game, self.detail_view.profile_id)
            self.notify("Nouvelle recette enregistree et activee")

    @staticmethod
    def _market_summary(info) -> str:
        if info is None:
            return "Aucune donnee relevee."
        lines = []
        if info.review_count:
            lines.append(f"Avis joueurs : {info.review_score} % positifs sur "
                         f"{info.review_count} avis ({info.review_label})")
        if info.metacritic:
            lines.append(f"Metacritic : {info.metacritic}/100")
        if info.current:
            lines.append(f"Prix {info.current.shop} : {info.current.price} "
                         f"{info.current.currency} (-{info.current.cut} %)")
        for o in info.offers[:6]:
            lines.append(f"Offre : {o.shop} {o.price} {o.currency} "
                         f"(-{o.cut} %) {o.drm}")
        if info.historical_low:
            lines.append(f"Plus bas historique : {info.historical_low} "
                         f"({info.historical_shop})")
        if info.release_date:
            lines.append(f"Sortie : {info.release_date}")
        return "\n".join(lines) or "Aucune donnee relevee."

    def _add_game(self) -> None:
        """Ajout manuel : pour un jeu qu'aucune source n'a detecte."""
        from PySide6.QtWidgets import QFileDialog, QInputDialog
        from ..core.doublons import meme_jeu
        from ..core.models import Game
        from ..plugins.scanners.folders import FolderScanner

        chemin, _ = QFileDialog.getOpenFileName(
            self, "Choisir l'executable du jeu", "",
            "Jeux (*.exe *.lnk *.url *.bat);;Tous les fichiers (*)")
        if not chemin:
            return
        exe = Path(chemin)
        # le dossier du jeu, pas son sous-dossier technique
        dossier = exe.parent
        for _ in range(3):
            if dossier.name.lower() in ("bin", "bin64", "binaries", "win64",
                                        "win32", "x64", "x86", "retail",
                                        "game", "shipping") \
                    and dossier.parent != dossier:
                dossier = dossier.parent
        propose = FolderScanner._title(dossier.name) or exe.stem
        titre, ok = QInputDialog.getText(
            self, "Ajouter un jeu", "Nom du jeu :", text=propose)
        titre = (titre or "").strip()
        if not ok or not titre:
            return

        nouveau = Game(title=titre, source="manuel",
                       source_id=str(exe).lower(), install_dir=str(dossier),
                       executable=str(exe), working_dir=str(exe.parent))
        for g in self.library.games(include_hidden=True):
            if meme_jeu(g, nouveau):
                g.hidden = False
                self.library.save()
                self.refresh_library()
                self.notify(f"{g.title} est deja dans la bibliotheque "
                            f"(source : {g.source}).", 8)
                return
        self.library.store.add_manual(nouveau)
        self.refresh_library()
        self.notify(f"{titre} ajoute a la bibliotheque. Recherche de sa "
                    "jaquette...", 6)
        self.fetch_artwork()

    def _game_action(self, uid: str, action: str) -> None:
        """Actions du menu ⋮ des tuiles de la bibliotheque."""
        from ..core.liens import fiche_lanceur, page_magasin
        game = self.jeu(uid)
        if game is None:
            return
        if action == "installer":
            self.installer_possede(uid)
            return
        if game.extra.get("non_installe"):
            if action == "magasin":
                ouvrir_lien(game.store_url or page_magasin(game))
            elif action == "masquer":
                game.hidden = True
                self.possedes.enregistrer()
                self.library_view.set_possedes(self.possedes.tous())
                self.notify(f"{game.title} ne sera plus affiche")
            return
        if action == "jouer":
            self.play(uid, self._profile_for(uid))
        elif action == "fiche":
            self.open_game(uid)
        elif action == "magasin":
            ouvrir_lien(page_magasin(game))
        elif action == "lanceur":
            uri, _ = fiche_lanceur(game)
            if uri:
                self._open_folder_path(uri)
        elif action == "dossier":
            if game.install_dir and existe(game.install_dir):
                self._open_folder_path(game.install_dir)
            else:
                self.notify("Dossier d'installation introuvable", 6)
        elif action == "favori":
            self._toggle_favorite(uid)
            self.notify(f"{game.title} : "
                        + ("ajoute aux favoris" if game.favorite
                           else "retire des favoris"))
        elif action == "masquer":
            game.hidden = not game.hidden
            self.library.save()
            self.refresh_library()
            if game.hidden:
                self.notify(f"{game.title} est masque. Pour le retrouver : "
                            "Reglages, « Afficher les jeux masques ».", 8)
            else:
                self.notify(f"{game.title} est de nouveau visible")
        elif action == "desinstaller":
            self._uninstall_game(uid)

    def _toggle_favorite(self, uid: str) -> None:
        game = self.library.get(uid)
        if game is None:
            return
        game.favorite = not game.favorite
        self.library.save()
        self.detail_view.fav.setChecked(game.favorite)
        self.detail_view.fav.setText(
            "Favori" if game.favorite else "Ajouter aux favoris")
        self.refresh_library()

    # ------------------------------------------------------------------
    # Application et lancement
    # ------------------------------------------------------------------
    def _confirm_changes(self, game: Game, plan) -> bool:
        changes = [o for o in plan.ops if o.changed]
        if not changes or not CONFIG.get("optimizer.confirm_before_write", True):
            return True
        from ..plugins.tweaks.xml_writer import ABSENT
        preview = "\n".join(
            f"  · {o.label or o.key} : "
            f"{'absent' if o.current is None else ('defaut du jeu' if o.current == ABSENT else o.current)}"
            f" -> {'defaut du jeu' if o.value == ABSENT else o.value}"
            for o in changes[:12])
        if len(changes) > 12:
            preview += f"\n  · ... et {len(changes) - 12} autres"

        box = QMessageBox(self)
        box.setWindowTitle("Appliquer les reglages")
        box.setIcon(QMessageBox.Icon.Question)
        box.setText(f"{len(changes)} reglage(s) vont etre ecrits pour "
                    f"{game.title}.")
        box.setInformativeText(
            preview + "\n\nUne sauvegarde sera creee avant modification.")
        box.setStandardButtons(QMessageBox.StandardButton.Yes |
                               QMessageBox.StandardButton.No)
        box.setDefaultButton(QMessageBox.StandardButton.Yes)
        return box.exec() == QMessageBox.StandardButton.Yes

    def apply_only(self, uid: str, profile_id: str) -> None:
        game = self.library.get(uid)
        if game is None:
            return
        plan = self.detail_view.plan
        if plan is None or plan.game_uid != game.uid or plan.profile != profile_id:
            # plan absent ou d'un autre jeu / profil : on le recalcule pour
            # CE jeu et CE profil plutot que d'appliquer celui affiche
            display = self._display_for(game)
            plan = self.optimizer.build_plan(game, profile_id, self.hw, display)
        if not plan.tunable:
            self.notify(f"{game.title} : aucun reglage a appliquer")
            return
        if not self._confirm_changes(game, plan):
            return
        self._ecrire_plan(game, plan)
        self._build_plan(game, profile_id)

    def play(self, uid: str, profile_id: str) -> None:
        game = self.library.get(uid)
        if game is None:
            return
        if self._lancement_bloque(game):          # jeu en cours de deplacement
            return
        if any(s.game.uid == game.uid and not s.termine for s in self.sessions):
            # second clic sur « Jouer » : une seule partie, une seule mesure,
            # un seul decompte du temps de jeu
            self.notify(f"{game.title} : deja lance")
            return

        plan = self.detail_view.plan
        if plan is None or plan.game_uid != game.uid or plan.profile != profile_id:
            display = self._display_for(game)
            plan = self.optimizer.build_plan(game, profile_id, self.hw, display)

        if not plan.tunable and plan.guide and not game.extra.get("guide_vu"):
            # premiere partie d'un jeu qu'ORION ne peut pas regler : un tour
            # dans ses reglages est conseille, liste a l'appui. Une seule fois.
            from .widgets.dialogues import DialogueGuide
            game.extra["guide_vu"] = True
            self.library.save()
            d = DialogueGuide(game.title, plan.guide, self, avant_partie=True)
            d.exec()
            if not d.jouer:
                return

        if not plan.tunable:
            # Rien a regler dans ce jeu : ORION le lance tel quel, sans
            # toucher ni a ses fichiers ni a l'ecran. Promettre une
            # optimisation qui n'aura pas lieu serait pire que rien.
            plan.display_mode = None
            log.info("%s : aucun reglage disponible, lancement tel quel",
                     game.title)
        elif self.optimizer.relire(plan):
            # relu juste avant de lancer : le jeu a pu remettre ses reglages
            # depuis l'ouverture de la fiche. Une reecriture deja acceptee
            # (memes valeurs) ne redemande pas confirmation a chaque partie.
            # plus de fenetre de confirmation au lancement (demande du
            # 9 octobre) : le choix a ete fait dans la fiche, on l'ecrit
            ok, msg = self.optimizer.apply_plan(game, plan)
            self.notify(msg)
            if not ok:
                # reglages en partie seulement : le jeu se lance quand meme
                log.warning("%s : reglages appliques en partie (%s)", game.title, msg)

        session = GameSession(game, plan, on_finished=self._session_finished,
                              on_measured=self._session_measured,
                              on_fenetre=self._fenetre_du_jeu)
        # `on_measured` et `on_fenetre` arrivent depuis le fil de surveillance
        # (voir `_session_measured`) ; `on_finished` aussi, et reste hors du
        # fil graphique : il ne touche que le disque (bilan, stats, sauvegarde)
        ok, msg = session.start()
        if ok:
            self.sessions.append(session)
            # ORION reste a l'ecran, « X demarre... », jusqu'a ce que la
            # fenetre du jeu apparaisse (15 octobre : Steam et Rocket League
            # mettaient 40 s, bureau vide). Il se reduit alors : sinon, quand
            # le jeu ferme sa fenetre de demarrage (lanceur, anti-triche),
            # Windows rend la main a ORION, qui passe devant le jeu (signale
            # le 9 octobre). Il revient a la fin.
            self.notify(f"{game.title} demarre... ({msg})", 180)
            # son temps est compte par la session : la veille ne le recompte pas
            self.veille_jeu.par_orion.add(game.uid)
            game.last_played = time.time()
            self.library.save()

    def _refresh_bilan(self) -> None:
        """Bilan de configuration : calcule ici, sans reseau ni cle."""
        from ..hardware.bilan import analyse as analyse_bilan
        from ..hardware.bilan import verdict as verdict_bilan
        points = analyse_bilan(self.hw)
        self._bilan_points = points
        self.hardware_view.set_bilan(points, verdict_bilan(points, self.hw),
                                     self._ia_configuree())

    def _ia_configuree(self) -> bool:
        provider = str(CONFIG.get("ai.provider", "") or "")
        if provider == "ollama":
            return True
        return bool(str(CONFIG.get("ai.api_key", "") or "").strip())

    def _machine_ai(self) -> None:
        """Demande a l'IA d'approfondir le bilan de configuration."""
        if not self._ia_configuree():
            self.notify("Renseignez une cle d'IA dans Reglages / Assistant IA", 9)
            return
        from ..ai.tasks import analyse_machine
        resume = "\n".join(f"- [{p.level}] {p.title} : {p.detail}"
                            for p in getattr(self, "_bilan_points", []))
        display = self.hw.primary_display
        self.hardware_view.set_ai_busy()
        task = Task(analyse_machine, self.hw, display, resume)
        task.signals.finished.connect(self._machine_ai_done)
        task.signals.failed.connect(
            lambda msg: self.hardware_view.set_ai_answer(
                f"L'IA n'a pas repondu : {msg}"))
        task.start()

    def _machine_ai_done(self, result) -> None:
        ok, text = result if isinstance(result, tuple) else (True, str(result))
        self.hardware_view.set_ai_answer(
            text if ok else f"L'IA n'a pas repondu : {text}")

    # ------------------------------------------------------------------
    # Stockage
    # ------------------------------------------------------------------
    def refresh_storage(self) -> None:
        from ..storage import disks_in_use, inventory
        entries = inventory(self.library.games(), self.hw)
        self.storage_view.set_data(entries, disks_in_use(entries, self.hw),
                                   self.hw)

    # ------------------------------------------------------------------
    # Jeux gratuits
    # ------------------------------------------------------------------
    # ------------------------------------------------------------------
    # Boutique
    # ------------------------------------------------------------------
    def refresh_boutique_view(self) -> None:
        self.boutique_view.set_suivis({i.appid for i in self.wishlist.all()})
        self.boutique_view.set_catalogue(
            self.boutique.fiches, self.boutique.actualise_le,
            self.boutique.intervalle_minutes(), self.boutique.comparateur_actif,
            self.boutique.etat_sources)

    def refresh_boutique(self, force: bool = False) -> None:
        if self._boutique_busy:
            return
        if not force and self._differer("boutique"):
            return
        self._boutique_busy = True
        # un changement d'intervalle dans les Reglages s'applique ici
        self._boutique_timer.setInterval(self.boutique.intervalle_minutes() * 60_000)
        self.boutique_view.occupe(True, "Actualisation des prix...")
        gratuits = self.free.all("", "")
        task = Task(self.boutique.actualiser, gratuits)
        task.signals.finished.connect(self._boutique_actualisee)
        task.signals.failed.connect(self._boutique_echec)
        task.start()

    def _boutique_actualisee(self, _fiches) -> None:
        # les prix du jour sont la : la Boutique les montre tout de suite
        self.boutique_view.occupe(False)
        self._au_repos("boutique", self.refresh_boutique_view)
        # le reste (types de jeu, fiches detaillees, plus bas historiques) se
        # complete derriere, sans faire attendre
        task = Task(self.boutique.completer)
        task.signals.finished.connect(self._boutique_completee)
        task.signals.failed.connect(lambda _m: self._boutique_completee(False))
        task.start()

    def _boutique_completee(self, change) -> None:
        self._boutique_busy = False
        if change:
            self._au_repos("boutique", self.refresh_boutique_view)

    def _boutique_echec(self, message: str) -> None:
        self._boutique_busy = False
        self.boutique_view.occupe(False)
        log.warning("Boutique : %s", message)
        self.notify("Boutique : actualisation impossible pour le moment", 8)

    def _boutique_esprit(self, terme: str, sans_resultat: bool) -> None:
        """Jeu introuvable : pourquoi, et des jeux du meme esprit (en tache de fond).

        Une seule demande a la fois par recherche : pour « pokemon », la
        reponse part avec la recherche puis etait redemandee a son retour
        (vu dans le journal du 7 octobre : deux fois 4,8 s)."""
        en_cours = self.__dict__.setdefault("_esprits_en_cours", set())
        if terme in en_cours:
            return
        en_cours.add(terme)
        task = Task(self.boutique.dans_l_esprit, terme, sans_resultat)
        task.signals.finished.connect(lambda r, t=terme: (en_cours.discard(t),
                                                           self._boutique_esprit_recu(r)))
        task.signals.failed.connect(lambda _m, t=terme: en_cours.discard(t))
        task.start()

    def _boutique_esprit_recu(self, resultat) -> None:
        if isinstance(resultat, dict):
            self.boutique_view.set_esprit(resultat)
            self._boutique_images(list(resultat.get("fiches") or []))

    def _boutique_chercher(self, terme: str) -> None:
        from .. import esprit
        if esprit.connu(terme):
            # serie connue pour ne pas etre en boutique PC (« pokemon »,
            # « fortnite ») : la reponse part en meme temps que la recherche
            self._boutique_esprit(terme, False)
        task = Task(self.boutique.chercher, terme)
        task.signals.finished.connect(
            lambda fiches, t=terme: self._boutique_trouve(t, fiches))
        task.signals.failed.connect(
            lambda msg, t=terme: self._boutique_trouve(t, []))
        task.start()

    def _boutique_cles(self, fiches: list) -> None:
        """Cles verifiees des revendeurs pour les cartes affichees, en tache
        de fond : les cartes se redessinent a l'arrivee."""
        task = Task(self.boutique.cles_revendeurs, list(fiches))
        task.signals.finished.connect(lambda n: n and self.boutique_view.cles_recues())
        task.start()

    def _boutique_suite(self, cle: str) -> None:
        """Les cent jeux suivants du magasin pour la page ouverte (un type de
        jeu, ou tout le magasin), en tache de fond."""
        task = Task(self.boutique.suite, cle)
        task.signals.finished.connect(lambda fiches, c=cle: self._boutique_suite_recue(c, fiches))
        task.signals.failed.connect(lambda _m, c=cle: self._boutique_suite_recue(c, []))
        task.start()

    def _boutique_suite_recue(self, cle: str, fiches) -> None:
        nouvelles = list(fiches or [])
        self.boutique_view.suite_recue(cle, nouvelles, self.boutique.suite_possible(cle))
        if nouvelles:
            self._boutique_images(nouvelles)

    def _boutique_trouve(self, terme: str, fiches) -> None:
        fiches = list(fiches or [])
        self.boutique_view.set_resultats(terme, fiches, self.boutique.sources_muettes(terme))
        if fiches:
            # plus bas historiques des jeux trouves : apres l'affichage
            suite = Task(self.boutique.plus_bas_des_resultats, fiches)
            suite.signals.finished.connect(lambda n: n and self.boutique_view.cles_recues())
            suite.start()

    def _boutique_comparer(self, fiche) -> None:
        task = Task(self.boutique.comparer, fiche)
        task.signals.finished.connect(self.boutique_view.maj_fiche)
        task.signals.failed.connect(lambda _m, f=fiche: self.boutique_view.maj_fiche(f))
        task.start()

    def _boutique_suivre(self, appid: str, titre: str) -> None:
        self._wishlist_add(appid, titre)
        self.notify(f"{titre} ajoute a vos Envies : ORION vous previendra "
                    "d'une baisse de prix", 7)

    def _boutique_ne_plus_suivre(self, appid: str, titre: str) -> None:
        self._wishlist_remove(appid)
        self.notify(f"{titre} retire de vos Envies", 5)

    def _boutique_cle(self) -> None:
        self.show_page("settings")
        self.notify("Collez votre cle dans « Prix et evaluations ». Pas "
                    "encore de cle ? Onglet Tuto, article « IsThereAnyDeal ».", 12)

    def _boutique_images(self, fiches: list) -> None:
        if self._images_busy or not fiches:
            return
        self._images_busy = True
        task = Task(self.boutique.vignettes, fiches)
        task.signals.finished.connect(self._boutique_images_pretes)
        task.signals.failed.connect(lambda _m: setattr(self, "_images_busy", False))
        task.start()

    def _boutique_images_pretes(self, n) -> None:
        self._images_busy = False
        if n:
            self.boutique_view.maj_images()

    def refresh_free_view(self) -> None:
        """Rafraichit la page a partir de ce qui est deja connu."""
        games = self.library.games()
        items = self.free.all(self._free_kind, self._free_query)
        arts = {fb.key: self.free.art(fb) for fb in items}

        # toutes les offres dont le jeu est deja sur le disque : elles
        # recoivent le bouton de suppression complete.
        found = self.free.installed(games)
        self._free_installed = {key: g.uid for key, g in found.items()}
        sizes = {key: g.size_gb for key, g in found.items()}

        # sous-ensemble : les gratuites temporaires arrivees a terme, qui
        # meritent une alerte parce que le jeu n'est plus jouable.
        expired = self.free.expired_temporaries(games)
        self._free_expired = {fb.key: g.uid for fb, g in expired}

        self.free_view.set_items(items, arts, sizes, self.free.counts(),
                                 self.free.last_refresh)
        self.free_view.set_expired(
            [(fb, g.title, g.size_gb) for fb, g in expired])
        self._compter_gratuits(bool(expired))
        self._announce_expired(games)

    def _compter_gratuits(self, alerte: bool = False) -> None:
        """Pastilles « gratuits a saisir » : onglet de la Boutique et entree
        de la barre laterale (la page « Jeux gratuits » n'a plus d'entree)."""
        from .theme import PALETTE
        a_saisir = [fb for fb in self.free.all("", "")
                    if not fb.claimed and not fb.upcoming]
        urgent = alerte or any(fb.urgent for fb in a_saisir)
        n = len(a_saisir)
        self.boutique_page.set_gratuits(n, urgent)
        couleur = PALETTE["warn"] if urgent else PALETTE["ok"]
        infobulle = ""
        if n:
            infobulle = (f"{n} jeu(x) gratuit(s) "
                         "a recuperer : onglet « Gratuits en ce moment »")
        if alerte:
            infobulle = "Une gratuite temporaire est terminee : voir l'onglet Gratuits"
        self.sidebar.set_pastille("boutique", str(n) if n else ("!" if alerte else ""),
                                  couleur, infobulle)

    def _announce_expired(self, games: list) -> None:
        """Previent quand une gratuite temporaire vient de se terminer.

        Sans cela, le joueur ne l'apprendrait qu'en ouvrant la page. Le jeu
        occupe pourtant de la place et n'est plus jouable : c'est le moment
        ou la proposition de suppression a un sens. Chaque offre n'est
        annoncee qu'une fois.
        """
        pending = self.free.pending_alerts(games)
        if not pending:
            return
        fb, game = pending[0]
        extra = f" (et {len(pending) - 1} autre(s))" if len(pending) > 1 else ""
        message = (f"{game.title} n'est plus gratuit{extra} : "
                   f"{game.size_gb:.0f} Go occupes pour un jeu qui n'est plus "
                   "jouable." if game.size_gb >= 1 else
                   f"{game.title} n'est plus gratuit{extra} : le jeu n'est "
                   "plus jouable.")
        self.notify(message + " Voir Boutique, onglet Gratuits.", 14)
        self._system_notify("Gratuite terminee", message)

    def refresh_free(self, force: bool = False) -> None:
        """Interroge les sources en ligne sans bloquer l'interface."""
        if self._free_busy:
            return
        if not force and self._differer("gratuits"):
            return
        if not force and not self.free.should_refresh():
            self.refresh_free_view()
            return
        self._free_busy = True
        task = Task(self.free.refresh, force=force)
        task.signals.progress.connect(self.free_view.set_progress)
        task.signals.finished.connect(self._free_refreshed)
        task.signals.failed.connect(self._free_failed)
        task.start()

    def _free_refreshed(self, result) -> None:
        self._free_busy = False
        self.free_view.set_progress("", 100)
        self._au_repos("free", self.refresh_free_view)

        arrivals = (result or {}).get("arrivals") or []
        errors = (result or {}).get("errors") or []
        # jeux gratuits du jour : une seule notification Windows par releve,
        # un clic ouvre l'onglet des gratuits (une offre connue d'avance est
        # annoncee le jour ou elle commence, pas a son arrivee dans la liste)
        annonce = (result or {}).get("annonce")
        if annonce and CONFIG.get("free.notify", True):
            from ..i18n import t
            self._system_notify(t(annonce[0]), t(annonce[1]), page="free")
        if arrivals and CONFIG.get("free.notify", True):
            names = ", ".join(a.title for a in arrivals[:3])
            extra = f" et {len(arrivals) - 3} autre(s)" if len(arrivals) > 3 else ""
            self.notify(f"Jeux gratuits : {names}{extra}", 12)
        elif errors:
            self.notify("Jeux gratuits : " + ", ".join(errors)
                        + " injoignable(s)", 8)

    def _free_failed(self, message: str) -> None:
        self._free_busy = False
        self.free_view.set_progress("", 100)
        self.notify(f"Recherche des jeux gratuits impossible : {message}", 10)

    def _free_filter(self, kind: str, query: str) -> None:
        self._free_kind, self._free_query = kind, query
        self.refresh_free_view()

    def _free_claim(self, key: str) -> None:
        fb = self.free.get(key)
        if fb is None or not fb.url:
            return
        ouvrir_gratuit(fb.url)
        self.free.mark_claimed(key)
        self.refresh_free_view()
        if fb.temporary:
            self.notify(
                "Acces temporaire : ORION previendra a la fin de l'offre.", 9)

    def _free_dismiss(self, key: str) -> None:
        self.free.dismiss(key)
        self.refresh_free_view()

    def _free_keep(self, key: str) -> None:
        """L'utilisateur garde le jeu : l'alerte ne revient plus."""
        self.free.dismiss(key)
        self.refresh_free_view()

    def _free_buy(self, key: str) -> None:
        fb = self.free.get(key)
        if fb is None:
            return
        target = fb.buy_url or fb.url
        if target:
            ouvrir_gratuit(target)

    def _free_uninstall(self, key: str) -> None:
        """Desinstalle un jeu dont la gratuite temporaire est terminee.

        La suppression passe par le circuit habituel (archivage de la
        sauvegarde, puis desinstalleur de la plateforme). Une fois lance,
        ORION propose la page d'achat a ceux qui veulent continuer.
        """
        fb = self.free.get(key)
        uid = self._free_expired.get(key)
        if fb is None or not uid:
            return
        # alerte retiree et achat propose seulement si la desinstallation a
        # vraiment ete lancee (pas sur un « Non » ni sans desinstalleur)
        if not self._uninstall_game(uid):
            return
        self.free.dismiss(key)
        self.refresh_free_view()
        self._offer_purchase(fb)

    def _free_remove(self, key: str) -> None:
        """Supprime completement un jeu gratuit installe sur le disque.

        Le circuit est le meme que partout ailleurs dans ORION : la
        sauvegarde est archivee, puis le desinstalleur de la plateforme est
        lance. ORION ne supprime jamais de fichier lui-meme. Ce qui change
        ici, c'est ce qu'on annonce avant : un jeu garde a vie reste acquis,
        un jeu gratuit pour toujours reste reinstallable, une gratuite
        temporaire terminee devra etre achetee.
        """
        fb = self.free.get(key)
        uid = self._free_installed.get(key)
        if fb is None or not uid:
            return
        game = self.library.get(uid)
        if game is None:
            return

        answer = QMessageBox.question(
            self, "Supprimer le jeu",
            f"Supprimer {game.title} du disque ?"
            + (f"\n\nIl occupe {game.size_gb:.0f} Go."
               if game.size_gb >= 1 else "")
            + "\n\n" + self.free.removal_notice(fb),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if answer != QMessageBox.StandardButton.Yes:
            return

        if not self._uninstall_game(uid):
            return
        self.refresh_free_view()

        # une gratuite temporaire terminee est le seul cas ou continuer a
        # jouer suppose un achat : on propose la page, jamais ailleurs.
        if fb.temporary and fb.expired:
            self._offer_purchase(fb)

    def _offer_purchase(self, fb) -> None:
        """Propose la page d'achat apres la fin d'une gratuite temporaire."""
        target = fb.buy_url or fb.url
        if not target:
            return
        answer = QMessageBox.question(
            self, "Continuer a y jouer",
            f"{fb.title} n'est plus gratuit.\n\nOuvrir la page d'achat ?"
            + (f"\n\nPrix habituel : {fb.worth_label}" if fb.worth else ""),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if answer == QMessageBox.StandardButton.Yes:
            ouvrir_gratuit(target)

    def _uninstall_game(self, uid: str) -> bool:
        """Propose d'archiver la sauvegarde puis ouvre le desinstalleur.
        Vrai seulement si la desinstallation a ete lancee."""
        from ..core.paths import is_windows
        from ..storage import uninstall_command

        game = self.library.get(uid)
        if game is None:
            return False
        command, description = uninstall_command(game)
        if not command:
            self.notify(description, 8)
            return False

        if CONFIG.get("saves.enabled", True):
            answer = QMessageBox.question(
                self, "Sauvegarde de partie",
                f"Archiver la sauvegarde de {game.title} avant de "
                "desinstaller ?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            if answer == QMessageBox.StandardButton.Yes:
                try:
                    self._auto_backup(game)
                    self.notify("Sauvegarde archivee avant desinstallation")
                except Exception:
                    log.exception("Archivage avant desinstallation impossible")

        from ..deplacement import taille_lisible
        confirm = QMessageBox.question(
            self, "Desinstaller",
            f"Lancer la desinstallation de {game.title}"
            + (f" ({taille_lisible(game.size_bytes)})" if game.size_bytes else "")
            + f" ?\n\n{description}",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if confirm != QMessageBox.StandardButton.Yes:
            return False

        try:
            if command.startswith(("steam://", "com.epicgames", "uplay://",
                                   "ms-settings:")):
                if not is_windows():
                    self.notify("Desinstallation disponible sous Windows seulement", 8)
                    return False
                from ..core.lancement import startfile_propre
                startfile_propre(command)
            elif Path(command).is_dir():
                self._open_folder_path(command)
            else:
                from ..core.lancement import popen_propre
                popen_propre(command, shell=True)

            self.notify(f"Desinstallation de {game.title} lancee")
            return True
        except Exception as exc:
            self.notify(f"Desinstallation impossible : {exc}", 10)
            return False

    def _open_game_folder(self, uid: str) -> None:
        game = self.library.get(uid)
        if game is not None and game.install_dir:
            self._open_folder_path(game.install_dir)

    # ------------------------------------------------------------------
    # Sauvegardes de parties
    # ------------------------------------------------------------------
    def _load_saves(self, game: Game) -> None:
        if not CONFIG.get("saves.enabled", True):
            return
        task = Task(detect_saves, game)
        task.signals.finished.connect(
            lambda locations, g=game: self._saves_ready(g, locations))
        task.start()

    def _saves_ready(self, game: Game, locations: list) -> None:
        if self.detail_view.game is None or self.detail_view.game.uid != game.uid:
            return
        self.detail_view.set_saves(locations, self.saves.archives(game),
                                   self.saves.location_for(game))

    def _backup_saves(self, uid: str, folder: str) -> None:
        game = self.library.get(uid)
        if game is None:
            return
        task = Task(self.saves.backup, game, folder)
        task.signals.finished.connect(
            lambda result, g=game: self._backup_done(g, result))
        task.signals.failed.connect(self._task_failed)
        task.start()

    def _backup_done(self, game: Game, result) -> None:
        ok, message = result if isinstance(result, tuple) else (False, str(result))
        self.notify(("Sauvegarde archivee : " if ok else "") + message, 8)
        if ok and self.detail_view.game and \
                self.detail_view.game.uid == game.uid:
            self._load_saves(game)

    def _restore_saves(self, uid: str, index: int) -> None:
        game = self.library.get(uid)
        if game is None:
            return
        archives = self.saves.archives(game)
        if index < 0 or index >= len(archives):
            return
        archive = archives[index]
        answer = QMessageBox.question(
            self, "Restaurer la sauvegarde",
            f"Remettre la sauvegarde de {game.title} datee du "
            f"{archive.when} ?\n\nLa sauvegarde actuelle sera renommee, "
            "pas supprimee.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if answer != QMessageBox.StandardButton.Yes:
            return
        ok, message = self.saves.restore(archive)
        self.notify(message, 10)

    def _auto_backup(self, game: Game) -> None:
        """Archivage automatique apres une partie."""
        if not CONFIG.get("saves.enabled", True) or \
                not CONFIG.get("saves.auto_after_play", True):
            return
        folder = self.saves.location_for(game)
        if not folder:
            locations = detect_saves(game)
            if not locations or locations[0].score < 40:
                return
            folder = locations[0].path
        ok, message = self.saves.backup(game, folder)
        if ok:
            log.info("Sauvegarde automatique de %s : %s", game.title, message)

    def _tuning(self, uid: str, action: str) -> None:
        """Applique ou annule les ajustements deduits des mesures."""
        from ..optimizer.adaptive import (apply_tuning, clear_tuning,
                                          proposals)

        game = self.library.get(uid)
        if game is None:
            return
        profile_id = self.detail_view.profile_id
        display = self._display_for(game)

        if action == "reset":
            clear_tuning(game, profile_id)
            self.library.save()
            self.notify("Profil remis a son reglage d'origine")
        else:
            by_profile = self.perf.by_profile(uid)
            changes: dict = {}
            for proposal in proposals(game, by_profile, self.hw, display):
                if proposal.profile == profile_id:
                    changes.update(proposal.changes)
            if not changes:
                self.notify("Aucun ajustement a appliquer")
                return
            apply_tuning(game, profile_id, changes)
            self.library.save()
            self.notify(f"{len(changes)} ajustement(s) memorise(s) pour "
                        f"{game.title}")
        self._build_plan(game, profile_id)

    def _session_measured(self, game: Game, stats: dict) -> None:
        """Une mesure de performances vient d'etre enregistree : le prochain
        plan repart des images par seconde reellement vues. La fiche ouverte
        sur ce jeu est recalculee tout de suite, sinon « Jouer » reprendrait
        le plan d'avant la partie."""
        try:
            from ..optimizer.recommande import appid_steam
            if appid_steam(game):
                stats.setdefault("appid", appid_steam(game))
        except Exception:
            pass
        self.perf.add(stats)
        log.info("Performances mesurees pour %s : %s i/s", game.title,
                 stats.get("fps_avg"))
        if stats.get("douteuse"):
            # gardee pour le diagnostic, ni reference ni partagee (2.1.2)
            log.info("Mesure de %s douteuse (%s images ecartees pour %s gardees) : non utilisee",
                     game.title, stats.get("ecartees"), stats.get("frames"))
            return
        # appele depuis le fil de surveillance de la partie : la suite cree
        # des taches Qt et recalcule la fiche, donc dans le fil graphique.
        # (Jusqu'a la 2.1.2, `_build_plan` partait de ce fil : Qt refusait le
        # parent de la tache et son resultat n'etait jamais livre : la fiche
        # ouverte gardait le plan d'avant la partie.)
        plus_tard(self, 0, lambda: self._apres_mesure(game, stats))

    def _apres_mesure(self, game: Game, stats: dict) -> None:
        self._partager_mesure(game, stats)
        courant = getattr(self.detail_view, "game", None)
        if courant is not None and courant.uid == game.uid:
            self._build_plan(game, "recommande")

    def _partager_mesure(self, game: Game, stats: dict) -> None:
        """Envoie la mesure au service communautaire, si le joueur a dit oui."""
        from .. import partage
        if not partage.actif():
            return
        try:
            from ..puissance.estimation import machine_depuis
            display = self._display_for(game)
            mode = (display.native or display.current) if display else None
            donnees = partage.ligne(partage.cle_jeu(game), stats, machine_depuis(self.hw),
                                    mode.pixels if mode else 0)
            if donnees:
                Task(partage.envoyer, donnees).start()
        except Exception:
            log.exception("Partage de la mesure impossible")

    def _fenetre_du_jeu(self, game: Game) -> None:
        """Appele depuis le fil de surveillance : la fenetre du jeu est la."""
        plus_tard(self, 0, lambda: self._reduire_pour(game))

    def _reduire_pour(self, game: Game) -> None:
        self.notify(f"{game.title} : en cours", 8)
        if CONFIG.get("jeu.reduire", True) and not self.isMinimized():
            self._reduit_pour_jeu = True
            self.showMinimized()

    def _revenir_apres_jeu(self) -> None:
        """Fin de partie (vue par la veille des jeux, pas par la session : un
        lanceur comme celui de Baldur's Gate 3 se ferme apres 2 secondes,
        bien avant le jeu) : ORION revient s'il s'etait reduit lui-meme."""
        if getattr(self, "_reduit_pour_jeu", False):
            self._reduit_pour_jeu = False
            if self.isMinimized():
                self.showNormal()

    def _session_finished(self, game: Game, seconds: int) -> None:
        # le jeu a-t-il garde les reglages d'ORION ? (etat de la fiche)
        try:
            self.optimizer.bilan_apres_partie(game, self.hw)
        except Exception:
            log.exception("Controle des reglages apres partie impossible")
        self.library.record_session(game, seconds,
                                    game.preferred_profile or "")
        log.info("Session terminee : %s (%d s)", game.title, seconds)
        if seconds > 120:
            try:
                self._auto_backup(game)
            except Exception:
                log.exception("Sauvegarde automatique impossible")

    def _restore_backup(self, uid: str) -> None:
        game = self.library.get(uid)
        if game is None:
            return
        slots = backup.list_backups(game)
        if not slots:
            self.notify("Aucune sauvegarde pour ce jeu")
            return
        latest = slots[0]
        stamp = time.strftime("%d/%m/%Y a %H:%M", time.localtime(latest.get("at", 0)))
        answer = QMessageBox.question(
            self, "Restaurer les reglages",
            f"Remettre les reglages de {game.title} enregistres le {stamp} ?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if answer != QMessageBox.StandardButton.Yes:
            return
        ok, msg = backup.restore(latest["path"])
        self.notify(msg)
        self._build_plan(game, self.detail_view.profile_id)

    # ------------------------------------------------------------------
    def _task_failed(self, message: str) -> None:
        # gestionnaire commun (prix, plan, materiel, jaquettes...) : il ne
        # touche ni au verrou ni a la barre de l'analyse, qui peut tourner
        # en ce moment meme
        self.notify(f"Erreur : {message}", 10)
        log.error("Tache en echec : %s", message)

    def closeEvent(self, event) -> None:          # noqa: N802
        # sauvegarde ou retour de jeu en cours : confirmation demandee
        if not self._stockage_fermeture_permise():
            event.ignore()
            return
        # des ici, la session finit volontairement : une ecriture finale lente
        # ou coupee n'est plus prise pour un plantage (signalement du 17/10)
        from .. import signalement
        signalement.marquer_fermeture()
        debut = time.perf_counter()
        try:
            self.library.save(attendre=True)
            CONFIG.save()
            from ..core.base import ecrire_en_attente
            ecrire_en_attente()
        except Exception:
            log.exception("Sauvegarde finale impossible")
        self._fermer_fond()
        log.info("Fermeture : ecriture finale en %.0f ms", (time.perf_counter() - debut) * 1000)
        super().closeEvent(event)
