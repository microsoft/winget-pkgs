"""Page conseils : ce qu'ORION a remarque sur la machine.

Les conseils sont ranges en rubriques (Pilotes, Windows, Materiel, Jeux).
Une rangee de tuiles resume chaque rubrique et y mene d'un clic.
"""
from __future__ import annotations

import time

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (QFrame, QHBoxLayout, QLabel, QPushButton,
                               QVBoxLayout, QWidget)

from ...core.config import CONFIG
from ...i18n import t
from ...optimizer.advisor import GROUPES, Advice
from ..theme import PALETTE
from ..widgets.advice_card import AdviceCard, cle, texte_brut
from ..widgets.layouts import clear_layout
from ..defilement import ZoneDefilante

#: sous-titre de chaque rubrique
DESCRIPTIONS = {
    "Pilotes": "Carte graphique, reseau, audio, chipset, stockage, USB, Bluetooth",
    "Windows": "Mode jeu, alimentation, planification GPU, fichier d'echange",
    "Materiel": "Ecrans, memoire, disques, equilibre des composants",
    "Jeux": "Emplacement des jeux installes et mises a jour en attente",
}

_STYLE = f"""
QFrame#AdviceTuile {{
    background: {PALETTE['surface']}; border: 1px solid {PALETTE['border']};
    border-radius: 10px;
}}
QFrame#AdviceTuile:hover {{ border-color: {PALETTE['border_hi']}; }}
QFrame#AdviceTuile[etat="attention"] {{ border-top: 3px solid {PALETTE['warn']}; }}
QFrame#AdviceTuile[etat="conseil"] {{ border-top: 3px solid {PALETTE['accent']}; }}
QFrame#AdviceTuile[etat="ok"] {{ border-top: 3px solid {PALETTE['ok']}; }}
QFrame#AdviceTuile[etat="vide"] {{ border-top: 3px solid {PALETTE['border_hi']}; }}
QLabel#AdviceTuileNom {{
    color: {PALETTE['text_dim']}; font-size: 11px; font-weight: 600;
    letter-spacing: 2px;
}}
QLabel#AdviceTuileChiffre {{ font-size: 26px; font-weight: 700; }}
QFrame#AdviceTuile[etat="attention"] QLabel#AdviceTuileChiffre {{ color: {PALETTE['warn']}; }}
QFrame#AdviceTuile[etat="conseil"] QLabel#AdviceTuileChiffre {{ color: {PALETTE['accent']}; }}
QFrame#AdviceTuile[etat="ok"] QLabel#AdviceTuileChiffre {{ color: {PALETTE['ok']}; }}
QFrame#AdviceTuile[etat="vide"] QLabel#AdviceTuileChiffre {{ color: {PALETTE['text_faint']}; }}
QLabel#AdviceTuileEtat {{ color: {PALETTE['text_faint']}; font-size: 11px; }}
QLabel#AdviceRubrique {{
    font-size: 15px; font-weight: 600; padding-top: 12px;
}}
QLabel#AdviceRubriqueInfo {{ color: {PALETTE['text_faint']}; font-size: 11px; padding-top: 12px; }}
"""


def resume(items: list[Advice]) -> tuple[str, int, str]:
    """(etat, nombre de points a traiter, phrase) pour une rubrique."""
    alertes = sum(1 for a in items if a.level == "attention")
    conseils = sum(1 for a in items if a.level == "conseil")
    if alertes:
        texte = (f"{alertes} a corriger" + (f", {conseils} conseil(s)"
                                            if conseils else ""))
        return "attention", alertes + conseils, texte
    if conseils:
        return "conseil", conseils, f"{conseils} conseil(s)"
    if items:
        return "ok", 0, "Rien a corriger"
    return "vide", 0, "Rien a signaler"


class _Tuile(QFrame):
    clicked = Signal()

    def __init__(self, groupe: str, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("AdviceTuile")
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 10, 14, 11)
        lay.setSpacing(1)
        nom = QLabel(groupe.upper())
        nom.setObjectName("AdviceTuileNom")
        lay.addWidget(nom)
        self.chiffre = QLabel("-")
        self.chiffre.setObjectName("AdviceTuileChiffre")
        lay.addWidget(self.chiffre)
        self.etat = QLabel("")
        self.etat.setObjectName("AdviceTuileEtat")
        lay.addWidget(self.etat)

    def montrer(self, etat: str, nombre: int, texte: str) -> None:
        self.setProperty("etat", etat)
        self.chiffre.setText(str(nombre) if etat in ("attention", "conseil")
                             else "OK" if etat == "ok" else "-")
        self.etat.setText(texte)
        self.style().unpolish(self)
        self.style().polish(self)
        for w in (self.chiffre, self.etat):
            w.style().unpolish(w)
            w.style().polish(w)

    def mousePressEvent(self, event) -> None:      # noqa: N802 (Qt)
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit()
        super().mousePressEvent(event)


class AdviceView(QWidget):
    refresh_requested = Signal()
    #: nombre de points « a corriger » encore affiches (pastille du menu)
    alertes_changees = Signal(int)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setStyleSheet(_STYLE)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(24, 18, 24, 18)
        outer.setSpacing(14)

        head = QHBoxLayout()
        head.setSpacing(10)
        titre_page = QLabel("Conseils")
        titre_page.setObjectName("PageTitle")
        head.addWidget(titre_page)
        self.count = QLabel("")
        self.count.setObjectName("PageHint")
        head.addWidget(self.count)
        head.addStretch(1)
        self.quand = QLabel("")
        self.quand.setObjectName("PageHint")
        head.addWidget(self.quand)
        self.a_traiter = QPushButton("A traiter seulement")
        self.a_traiter.setObjectName("Chip")
        self.a_traiter.setCheckable(True)
        self.a_traiter.setCursor(Qt.CursorShape.PointingHandCursor)
        self.a_traiter.setChecked(bool(CONFIG.get("advisor.a_traiter", False)))
        self.a_traiter.setToolTip("N'affiche que ce qui demande une action : les "
                                  "verifications deja bonnes sont repliees.")
        self.a_traiter.toggled.connect(self._a_traiter_change)
        head.addWidget(self.a_traiter)
        self.copier = QPushButton("Copier le rapport")
        self.copier.setObjectName("Ghost")
        self.copier.setToolTip("Copie tous les conseils en texte, pour les coller dans "
                               "un message ou un forum d'entraide.")
        self.copier.clicked.connect(self._copier)
        head.addWidget(self.copier)
        self.bouton = QPushButton("Actualiser")
        self.bouton.setObjectName("Ghost")
        self.bouton.setMinimumWidth(130)
        self.bouton.setToolTip("Relit les pilotes, les reglages de Windows, la memoire "
                               "et les disques (quelques secondes).")
        self.bouton.clicked.connect(self._actualiser)
        head.addWidget(self.bouton)
        outer.addLayout(head)

        tuiles = QHBoxLayout()
        tuiles.setSpacing(10)
        self.tuiles: dict[str, _Tuile] = {}
        for g in GROUPES:
            tuile = _Tuile(g)
            tuile.clicked.connect(lambda g=g: self.aller_a(g))
            tuiles.addWidget(tuile, 1)
            self.tuiles[g] = tuile
        outer.addLayout(tuiles)

        self.scroll = ZoneDefilante()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)
        outer.addWidget(self.scroll, 1)
        self.body = QWidget()
        self.scroll.setWidget(self.body)
        self.lay = QVBoxLayout(self.body)
        self.lay.setContentsMargins(0, 0, 8, 0)
        self.lay.setSpacing(9)
        self._ancres: dict[str, QWidget] = {}
        self.items: list[Advice] = []
        self._dessine: tuple | None = None       # ce que la page montre
        self._attente("Analyse de la machine en cours...")

    # ------------------------------------------------------------------
    def _attente(self, texte: str) -> None:
        self.count.setText(texte)
        for tuile in self.tuiles.values():
            tuile.montrer("vide", 0, "Analyse...")

    def _actualiser(self) -> None:
        self.set_occupe(True)
        self.refresh_requested.emit()

    def set_occupe(self, occupe: bool) -> None:
        """Pendant l'analyse : bouton coupe et message d'attente. `set_advice`
        (ou `set_occupe(False)` en cas d'echec) le rend."""
        self.bouton.setEnabled(not occupe)
        self.bouton.setText("Analyse..." if occupe else "Actualiser")
        if occupe:
            self.count.setText("Analyse en cours : pilotes, Windows, memoire, "
                               "disques...")
        elif self._dessine is not None:
            self._resumer()

    def aller_a(self, groupe: str) -> None:
        ancre = self._ancres.get(groupe)
        if ancre is not None:
            self.lay.activate()
            self.scroll.verticalScrollBar().setValue(ancre.y())

    # -- conseils masques ------------------------------------------------
    @staticmethod
    def masques() -> set[str]:
        return {str(c) for c in (CONFIG.get("advisor.masques", []) or [])}

    def _masquer(self, cle_conseil: str) -> None:
        CONFIG.set("advisor.masques", sorted(self.masques() | {cle_conseil}))
        self._dessiner()

    def _reafficher(self) -> None:
        CONFIG.set("advisor.masques", [])
        self._dessiner()

    def _a_traiter_change(self, coche: bool) -> None:
        CONFIG.set("advisor.a_traiter", bool(coche))
        self._dessiner()

    def visibles(self) -> list[Advice]:
        """Conseils affiches : ni masques par le joueur, ni (filtre « a
        traiter ») deja bons."""
        masques = self.masques()
        gardes = [a for a in self.items if cle(a) not in masques]
        if self.a_traiter.isChecked():
            gardes = [a for a in gardes if a.level in ("attention", "conseil")]
        return gardes

    def rapport(self) -> str:
        """Tous les conseils, masques compris, en texte simple."""
        lignes = [f"ORION - {t('Conseils')} ({self.quand.text()})" if self.quand.text()
                  else f"ORION - {t('Conseils')}"]
        for g in GROUPES:
            lot = sorted((a for a in self.items if (a.groupe if a.groupe in GROUPES
                                                    else "Materiel") == g),
                         key=lambda a: a.rank)
            if lot:
                lignes += ["", f"== {t(g)} =="] + [texte_brut(a) for a in lot]
        return "\n".join(lignes)

    def _copier(self) -> None:
        from PySide6.QtWidgets import QApplication
        QApplication.clipboard().setText(self.rapport())
        self.copier.setText("Copie !")
        from ..minuteur import plus_tard
        plus_tard(self, 1800, lambda: self.copier.setText("Copier le rapport"))

    # -- affichage -------------------------------------------------------
    def set_advice(self, items: list[Advice], analyse: bool = True) -> None:
        """`analyse` : ces conseils sortent d'une analyse du materiel qui
        vient de finir (l'heure affichee est la sienne). Une simple visite de
        la page relit les conseils sans changer cette heure."""
        self.items = list(items)
        if analyse or not self.quand.text():
            self.quand.setText(time.strftime("analyse a %H:%M"))
        self._dessiner()
        self.set_occupe(False)

    def _etat(self) -> tuple:
        return (tuple((a.level, a.title, a.detail, a.action, a.action_url, a.groupe,
                       a.preuve) for a in self.items),
                tuple(sorted(self.masques())), self.a_traiter.isChecked())

    def _dessiner(self) -> None:
        """Reconstruit la page seulement si ce qu'elle doit montrer a change.
        Les conseils sont relus a chaque visite et apres chaque analyse du
        materiel : refaire a chaque fois une vingtaine de cartes identiques
        coutait un dixieme de seconde a l'ouverture de la page."""
        etat = self._etat()
        if etat == self._dessine:
            return
        self._dessine = etat
        masques = self.masques()
        montres = self.visibles()
        clear_layout(self.lay)
        self._ancres = {}
        par_groupe: dict[str, list[Advice]] = {g: [] for g in GROUPES}
        for a in montres:
            par_groupe[a.groupe if a.groupe in par_groupe else "Materiel"].append(a)
        # les tuiles comptent ce qui reste a traiter, conseils masques exclus
        compte: dict[str, list[Advice]] = {g: [] for g in GROUPES}
        for a in self.items:
            if cle(a) not in masques:
                compte[a.groupe if a.groupe in compte else "Materiel"].append(a)

        for g in GROUPES:
            lot = sorted(par_groupe[g], key=lambda a: a.rank)
            self.tuiles[g].montrer(*resume(compte[g]))

            entete = QWidget()
            hl = QHBoxLayout(entete)
            hl.setContentsMargins(0, 0, 0, 0)
            hl.setSpacing(10)
            titre = QLabel(g)
            titre.setObjectName("AdviceRubrique")
            hl.addWidget(titre)
            info = QLabel(DESCRIPTIONS.get(g, ""))
            info.setObjectName("AdviceRubriqueInfo")
            hl.addWidget(info, 1)
            self.lay.addWidget(entete)
            self._ancres[g] = entete

            for a in lot:
                carte = AdviceCard(a, masquable=True)
                carte.masquer.connect(self._masquer)
                self.lay.addWidget(carte)
            if not lot:
                vide = QLabel("Rien a corriger dans cette rubrique." if compte[g]
                              else "Rien a signaler dans cette rubrique.")
                vide.setObjectName("Dim")
                vide.setContentsMargins(2, 0, 0, 4)
                self.lay.addWidget(vide)

        caches = [a for a in self.items if cle(a) in masques]
        if caches:
            pied = QWidget()
            pl = QHBoxLayout(pied)
            pl.setContentsMargins(2, 10, 0, 0)
            pl.setSpacing(10)
            texte = QLabel(t(f"{len(caches)} conseil(s) masque(s) : ")
                           + " · ".join(t(a.title) for a in caches[:3])
                           + (" · ..." if len(caches) > 3 else ""))
            texte.setObjectName("Faint")
            texte.setWordWrap(True)
            pl.addWidget(texte, 1)
            self.b_reafficher = QPushButton("Reafficher")
            self.b_reafficher.setObjectName("Ghost")
            self.b_reafficher.clicked.connect(self._reafficher)
            pl.addWidget(self.b_reafficher)
            self.lay.addWidget(pied)
        self.lay.addStretch(1)
        self._resumer()

    def _resumer(self) -> None:
        masques = self.masques()
        suivis = [a for a in self.items if cle(a) not in masques]
        alertes = sum(1 for a in suivis if a.level == "attention")
        conseils = sum(1 for a in suivis if a.level == "conseil")
        if alertes:
            self.count.setText(f"{alertes} point(s) d'attention, "
                               f"{conseils} conseil(s)")
        elif conseils:
            self.count.setText(f"{conseils} conseil(s)")
        else:
            self.count.setText("Rien a corriger : la configuration est coherente.")
        self.alertes_changees.emit(alertes)
