"""Detection des jeux Ubisoft Connect."""
from __future__ import annotations

from pathlib import Path

from ...core.logging_setup import get
from ...core.models import Game
from ...core.winutil import HKLM, dir_size, reg_subkeys, reg_value
from .base import Scanner, detect_engine, pick_main_exe

log = get("scan.ubisoft")

BASE = r"SOFTWARE\WOW6432Node\Ubisoft\Launcher\Installs"


class UbisoftScanner(Scanner):
    id = "ubisoft"
    label = "Ubisoft Connect"
    icon = "UBI"
    priority = 70

    def available(self) -> bool:
        return bool(reg_subkeys(HKLM, BASE))

    def scan(self) -> list[Game]:
        games: list[Game] = []
        for gid in reg_subkeys(HKLM, BASE):
            path = reg_value(HKLM, f"{BASE}\\{gid}", "InstallDir")
            if not path:
                continue
            p = Path(str(path).replace("/", "\\"))
            if not p.is_dir():
                continue
            title = p.name
            games.append(self._mk(
                title=title,
                source_id=gid,
                install_dir=str(p),
                executable=pick_main_exe(p, title),
                launch_uri=f"uplay://launch/{gid}/0",
                size_bytes=dir_size(p, 8000),
                engine=detect_engine(p),
            ))
        log.info("%d jeux Ubisoft", len(games))
        return games
