"""Coffre des connexions aux plateformes.

ORION ne voit jamais un mot de passe : la connexion se fait sur la page
officielle de chaque plateforme, qui rend un jeton. Seul ce jeton est
garde ici, chiffre par Windows (DPAPI, `CryptProtectData`) : il n'est
lisible que par ta session Windows, sur ce PC. Copie sur une autre
machine ou lu par un autre utilisateur, il est inutilisable.

Les jetons ne passent jamais par le journal ni par les rapports de
signalement, et « Se deconnecter » les efface.

Hors Windows (tests, developpement), un simple encodage est utilise et le
coffre le signale par `chiffrement_reel() == False`.
"""
from __future__ import annotations

import base64
import json
import sys
import time
from typing import Any

from ..core.logging_setup import get

log = get("comptes.coffre")

#: entropie supplementaire propre a ORION (DPAPI la melange a la cle)
_SEL = b"ORION-comptes-v1"
_ESPACE = "coffre"


def chiffrement_reel() -> bool:
    return sys.platform.startswith("win")


# ----------------------------------------------------------------------
# DPAPI
# ----------------------------------------------------------------------
def _dpapi(donnees: bytes, chiffrer: bool) -> bytes:
    import ctypes
    from ctypes import wintypes

    class BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD),
                    ("pbData", ctypes.POINTER(ctypes.c_char))]

    def blob(b: bytes) -> BLOB:
        tampon = ctypes.create_string_buffer(b, len(b))
        return BLOB(len(b), ctypes.cast(tampon, ctypes.POINTER(ctypes.c_char)))

    entree, sel, sortie = blob(donnees), blob(_SEL), BLOB()
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    CRYPTPROTECT_UI_FORBIDDEN = 0x01
    if chiffrer:
        ok = crypt32.CryptProtectData(ctypes.byref(entree), "ORION", ctypes.byref(sel),
                                      None, None, CRYPTPROTECT_UI_FORBIDDEN,
                                      ctypes.byref(sortie))
    else:
        ok = crypt32.CryptUnprotectData(ctypes.byref(entree), None, ctypes.byref(sel),
                                        None, None, CRYPTPROTECT_UI_FORBIDDEN,
                                        ctypes.byref(sortie))
    if not ok:
        raise OSError("DPAPI : operation refusee par Windows")
    try:
        return ctypes.string_at(sortie.pbData, sortie.cbData)
    finally:
        kernel32.LocalFree(sortie.pbData)


def chiffrer(texte: str) -> str:
    brut = texte.encode("utf-8")
    if chiffrement_reel():
        brut = _dpapi(brut, True)
    return base64.b64encode(brut).decode("ascii")


def dechiffrer(texte: str) -> str:
    brut = base64.b64decode(texte.encode("ascii"))
    if chiffrement_reel():
        brut = _dpapi(brut, False)
    return brut.decode("utf-8")


# ----------------------------------------------------------------------
# Rangement
# ----------------------------------------------------------------------
def _table():
    from ..core.base import Table
    return Table(_ESPACE)


def enregistrer(plateforme: str, secret: dict[str, Any]) -> None:
    """Garde le jeton (et ce qui l'accompagne) d'une plateforme, chiffre."""
    _table().set(plateforme, {
        "le": time.time(),
        "donnees": chiffrer(json.dumps(secret)),
    })
    log.info("Connexion %s enregistree (chiffree)", plateforme)


def lire(plateforme: str) -> dict[str, Any] | None:
    ligne = _table().get(plateforme)
    if not ligne:
        return None
    try:
        return json.loads(dechiffrer(ligne["donnees"]))
    except Exception:
        # autre session Windows, autre PC, donnee abimee : on oublie
        log.warning("Connexion %s illisible : a refaire", plateforme)
        oublier(plateforme)
        return None


def oublier(plateforme: str) -> None:
    _table().supprimer(plateforme)
    log.info("Connexion %s effacee", plateforme)

