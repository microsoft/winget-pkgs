"""Copie des sauvegardes de parties dans un dossier synchronise.

ORION n'a pas de serveur et n'en veut pas : il se contente de deposer une
copie de chaque archive dans le dossier d'un service deja installe sur le
PC (OneDrive, Google Drive, Dropbox, ou tout autre dossier choisi). C'est
ce service qui l'envoie en ligne, avec le compte de l'utilisateur.

Sur un autre PC (ou apres une reinstallation), les archives du dossier
synchronise apparaissent dans la liste des sauvegardes d'un jeu et
peuvent etre restaurees.

Arborescence : <dossier>/ORION/Sauvegardes/<Titre du jeu>/<date>.zip
"""
from __future__ import annotations

import json
import os
import shutil
import zipfile
from dataclasses import dataclass
from pathlib import Path

from .core.logging_setup import get

log = get("nuage")

SOUS_DOSSIER = Path("ORION") / "Sauvegardes"


@dataclass
class Emplacement:
    service: str
    chemin: str

    @property
    def libelle(self) -> str:
        return f"{self.service} — {self.chemin}"


def _dropbox() -> list[Path]:
    """Dropbox indique son dossier dans info.json (personnel et pro)."""
    sortie = []
    for base in (os.environ.get("LOCALAPPDATA"), os.environ.get("APPDATA")):
        if not base:
            continue
        info = Path(base) / "Dropbox" / "info.json"
        try:
            donnees = json.loads(info.read_text("utf-8"))
            for compte in donnees.values():
                if isinstance(compte, dict) and compte.get("path"):
                    sortie.append(Path(compte["path"]))
        except Exception:
            continue
    return sortie


def _google_drive() -> list[Path]:
    """Google Drive pour ordinateur monte un lecteur (G:\\Mon Drive) ou,
    en mode miroir, un dossier dans le profil."""
    sortie = []
    for lettre in "GHIJKLMNOPQRSTUVWXYZ":
        for nom in ("Mon Drive", "My Drive"):
            p = Path(f"{lettre}:\\") / nom
            try:
                if p.is_dir():
                    sortie.append(p)
            except OSError:
                continue
    maison = Path.home()
    for nom in ("Mon Drive", "My Drive", "Google Drive"):
        if (maison / nom).is_dir():
            sortie.append(maison / nom)
    return sortie


def emplacements() -> list[Emplacement]:
    """Dossiers synchronises trouves sur ce PC."""
    trouves: list[Emplacement] = []
    vus: set[str] = set()

    def ajouter(service: str, chemin) -> None:
        if not chemin:
            return
        p = Path(chemin)
        try:
            if not p.is_dir():
                return
        except OSError:
            return
        cle = os.path.normcase(str(p))
        if cle in vus:
            return
        vus.add(cle)
        trouves.append(Emplacement(service, str(p)))

    ajouter("OneDrive", os.environ.get("OneDriveConsumer"))
    ajouter("OneDrive", os.environ.get("OneDrive"))
    ajouter("OneDrive professionnel", os.environ.get("OneDriveCommercial"))
    for p in _google_drive():
        ajouter("Google Drive", p)
    for p in _dropbox():
        ajouter("Dropbox", p)
    ajouter("Dropbox", Path.home() / "Dropbox")
    return trouves


def dossier_jeux(racine: str) -> Path:
    return Path(racine) / SOUS_DOSSIER


def copier(archive: Path, titre_dossier: str, racine: str, garder: int = 10) -> bool:
    """Copie une archive dans le dossier synchronise, et n'y garde que les
    `garder` plus recentes pour ce jeu."""
    if not racine:
        return False
    try:
        cible = dossier_jeux(racine) / titre_dossier
        cible.mkdir(parents=True, exist_ok=True)
        shutil.copy2(archive, cible / archive.name)
        anciennes = sorted(cible.glob("*.zip"), key=lambda f: f.name, reverse=True)
        for vieille in anciennes[max(1, garder):]:
            vieille.unlink(missing_ok=True)
        log.info("Sauvegarde copiee dans le nuage : %s", cible / archive.name)
        return True
    except Exception as exc:
        log.warning("Copie dans le dossier synchronise impossible : %s", exc)
        return False


def archives(racine: str) -> list[dict]:
    """Archives presentes dans le dossier synchronise (lues depuis leur
    fiche _orion.json, sans les decompresser)."""
    sortie = []
    base = dossier_jeux(racine) if racine else None
    if base is None or not base.is_dir():
        return sortie
    for zf_path in base.glob("*/*.zip"):
        try:
            with zipfile.ZipFile(zf_path) as zf:
                meta = json.loads(zf.read("_orion.json").decode("utf-8"))
        except Exception:
            continue
        sortie.append({
            "game_uid": meta.get("uid", ""), "title": meta.get("jeu", zf_path.parent.name),
            "path": str(zf_path), "source": meta.get("source", ""),
            "at": zf_path.stat().st_mtime, "bytes": zf_path.stat().st_size,
        })
    return sortie
