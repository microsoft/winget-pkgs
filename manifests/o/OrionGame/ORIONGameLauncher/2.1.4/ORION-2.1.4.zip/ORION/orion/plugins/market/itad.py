"""IsThereAnyDeal : meilleur prix du moment sur des dizaines de boutiques.

Ce fournisseur donne le vrai comparateur (Steam, Epic, GOG, Fanatical,
GreenManGaming, Humble, GamersGate...) ainsi que le plus bas prix jamais
releve, ce qui permet de dire si le moment est bon pour acheter.

Rien a configurer : les demandes passent par le relais du service d'ORION
(voir `orion/itad.py`). Une cle personnelle, saisie dans les Reglages, fait
passer en direct.
"""
from __future__ import annotations

import time

from ... import itad as acces
from ...core.config import CONFIG
from ...core.logging_setup import get
from ...core.models import Game
from .base import MarketInfo, MarketProvider, Offer
from .steam_store import steam_appid

log = get("market.itad")

WEB_SEARCH = "https://isthereanydeal.com/search/?q={query}"


class ITADProvider(MarketProvider):
    id = "itad"
    label = "IsThereAnyDeal"
    priority = 90
    needs_key = True

    filtre_adulte = "drapeau « mature » de la fiche IsThereAnyDeal"

    @staticmethod
    def key() -> str:
        return str(CONFIG.get("market.itad_key") or "").strip()

    def available(self) -> bool:
        return True          # actif meme sans cle, pour le lien de recherche

    # ------------------------------------------------------------------
    def fetch(self, game: Game, info: MarketInfo) -> None:
        import requests

        country = str(CONFIG.get("market.country") or "FR").strip().upper()
        query = requests.utils.quote(game.title)
        info.deals_url = WEB_SEARCH.format(query=query)

        key = self.key()
        if not acces.actif():
            info.note = (
                "Comparateur de prix complet indisponible pour le moment : "
                "ORION affiche les prix de Steam et reessaiera plus tard.")
            return

        self._adulte = False
        game_id = self._lookup(key, game)
        info.adulte = info.adulte or self._adulte
        if not game_id:
            return

        self._prices(key, country, game_id, info)
        self._history(key, country, game_id, info)
        if info.best or info.historical_low:
            info.sources.append(self.id)
            info.fetched_at = time.time()

    # ------------------------------------------------------------------
    def _lookup(self, key: str, game: Game) -> str:
        appid = steam_appid(game)
        params = {"appid": appid} if appid else {"title": game.title.strip()[:120]}
        try:
            data = acces.demander("GET", "/games/lookup/v1", params, timeout=12) or {}
            if data.get("found"):
                jeu = data.get("game") or {}
                self._adulte = self.adulte(jeu)          # drapeau « mature »
                return str(jeu.get("id") or "")
        except Exception:
            log.debug("Recherche ITAD impossible pour %s", game.title)
        return ""

    def _prices(self, key: str, country: str, game_id: str,
                info: MarketInfo) -> None:
        try:
            entries = acces.demander("POST", "/games/prices/v3",
                                     {"country": country, "capacity": 12, "nondeals": "false"},
                                     [game_id]) or []
        except Exception:
            log.debug("Prix ITAD indisponibles")
            return

        for entry in entries:
            for deal in acces.du_pays(entry.get("deals") or [], country):
                price = (deal.get("price") or {})
                amount = price.get("amount")
                if amount is None:
                    continue
                offer = Offer(
                    shop=(deal.get("shop") or {}).get("name", "?"),
                    price=round(float(amount), 2),
                    currency=price.get("currency", "EUR"),
                    cut=int(deal.get("cut") or 0),
                    url=deal.get("url", ""),
                    drm=", ".join(d.get("name", "") for d in
                                  (deal.get("drm") or [])[:2]),
                )
                info.offers.append(offer)

        info.offers.sort(key=lambda o: o.price)
        if info.offers:
            info.best = info.offers[0]

    def _history(self, key: str, country: str, game_id: str,
                 info: MarketInfo) -> None:
        try:
            for entry in acces.demander("POST", "/games/historylow/v1", {"country": country},
                                        [game_id], timeout=12) or []:
                low = entry.get("low") or {}
                if low.get("amount") is not None:
                    info.historical_low = round(float(low["amount"]), 2)
                    info.historical_shop = (low.get("shop") or {}).get("name", "")
        except Exception:
            log.debug("Historique ITAD indisponible")
