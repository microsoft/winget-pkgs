"""Panneau de recherche de la Boutique : la liste qui s'ouvre sous la barre.

Comme sur les sites de vente de jeux (Instant Gaming, Kinguin, DLCompare,
releves par l'auteur le 14 octobre 2026) :

* **champ vide** : les jeux du moment (« Tendances ») et les fiches vues
  recemment, en vignettes ;
* **des la premiere lettre** : les jeux qui correspondent (vignette, nom,
  « Jeu » ou « DLC », boutique, remise et prix), les types de jeux dont le
  nom correspond, puis « Voir les resultats » (la page complete, filtres et
  tri compris) ;
* clavier : fleches haut / bas, Entree, Echap. Le champ garde la saisie.

Le panneau est dessine (une seule surface, comme les cartes de la
Boutique) et pose au-dessus de la page, sous la barre de recherche. Les
images viennent du chargeur partage (`boutique_images.ChargeurImages`)."""
from __future__ import annotations

from PySide6.QtCore import QPoint, QPointF, QRectF, QSize, Qt, Signal
from PySide6.QtGui import QColor, QFont, QFontMetrics, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QWidget

from ...i18n import t
from .boutique_cartes import bloc_prix, couleur, degrade, pilule, police
from .boutique_images import ChargeurImages

#: nombre de jeux montres sous la barre (le reste : « Voir les resultats »)
JEUX_MAX = 6
TUILES_MAX = 6
TYPES_MAX = 6


def est_dlc(fiche) -> bool:
    return any((o.type_article or "").lower() == "dlc" for o in getattr(fiche, "offres", ()))


class PanneauRecherche(QWidget):
    """Liste deroulante de la recherche. Ne prend jamais le clavier."""

    fiche_choisie = Signal(object)
    type_choisi = Signal(str)
    tout_voir = Signal()

    LARGEUR_MAX = 820
    MARGE = 10
    H_TITRE = 34
    H_LIGNE = 66
    H_PUCES = 46
    H_TUILES = 126
    H_PIED = 48
    H_VIDE = 64

    def __init__(self, parent: QWidget, possede=None) -> None:
        super().__init__(parent)
        self.setMouseTracking(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.possede = possede or (lambda f: False)
        self._terme = ""
        self._jeux: list = []
        self._types: list[tuple[str, str]] = []
        self._tuiles: list = []
        self._titre_tuiles = ""
        self._total = 0
        self._en_cours = False
        self._zones: list[tuple[QRectF, str, object]] = []   # (rectangle, genre, valeur)
        self._actif = -1                                        # zone choisie au clavier
        self._survol = -1
        self.hide()
        ChargeurImages.instance().prete.connect(self._image_prete)

    # ------------------------------------------------------------------ contenu
    def remplir(self, terme: str, jeux=(), types=(), tuiles=(), titre_tuiles: str = "",
                total: int = 0, en_cours: bool = False) -> None:
        self._terme = terme
        self._jeux = list(jeux)[:JEUX_MAX]
        self._types = list(types)[:TYPES_MAX]
        self._tuiles = list(tuiles)[:TUILES_MAX]
        self._titre_tuiles = titre_tuiles
        self._total = max(total, len(self._jeux))
        self._en_cours = en_cours
        self._actif = -1
        self._mise_en_page()
        self.update()

    @property
    def zones(self) -> list[tuple[QRectF, str, object]]:
        return list(self._zones)

    def placer(self, champ: QWidget) -> None:
        """Sous le champ, aligne a gauche, jamais plus bas que la fenetre."""
        hote = self.parentWidget()
        if hote is None:
            return
        coin = champ.mapTo(hote, QPoint(0, champ.height() + 6))
        largeur = min(max(champ.width(), 420), self.LARGEUR_MAX, hote.width() - coin.x() - 8)
        self.setGeometry(coin.x(), coin.y(), max(320, largeur), self.height() or 120)
        self._mise_en_page()

    # ------------------------------------------------------------------ clavier
    def deplacer(self, pas: int) -> None:
        if not self._zones:
            return
        self._actif = (self._actif + pas) % len(self._zones) if self._actif >= 0 else (
            0 if pas > 0 else len(self._zones) - 1)
        self.update()

    def activer(self) -> bool:
        """Entree : ouvre la zone choisie au clavier. Faux si aucune."""
        if not (0 <= self._actif < len(self._zones)):
            return False
        self._declencher(self._zones[self._actif])
        return True

    # ------------------------------------------------------------------ mise en page
    def _mise_en_page(self) -> None:
        w, m = self.width() or 600, self.MARGE
        y = m
        zones: list[tuple[QRectF, str, object]] = []
        self._titres: list[tuple[float, str]] = []
        if self._terme:
            if self._jeux:
                self._titres.append((y, t("Jeux")))
                y += self.H_TITRE
                for f in self._jeux:
                    zones.append((QRectF(m, y, w - 2 * m, self.H_LIGNE), "fiche", f))
                    y += self.H_LIGNE
            else:
                self._vide_y = y
                y += self.H_VIDE
            if self._types:
                self._titres.append((y + 4, t("Types de jeux")))
                y += self.H_TITRE + 4
                x = m + 6
                fm = QFontMetrics(police(self.font(), 13, QFont.Weight.DemiBold))
                for cle, libelle in self._types:
                    lw = fm.horizontalAdvance(libelle) + 28
                    if x + lw > w - m and x > m + 6:
                        break
                    zones.append((QRectF(x, y + 6, lw, 30), "type", cle))
                    x += lw + 8
                y += self.H_PUCES
            zones.append((QRectF(m, y + 6, w - 2 * m, self.H_PIED - 12), "tout", None))
            y += self.H_PIED
        else:
            if self._tuiles:
                self._titres.append((y, t(self._titre_tuiles)))
                y += self.H_TITRE
                n = len(self._tuiles)
                lw = (w - 2 * m - (n - 1) * 10) / max(n, 1)
                lw = min(lw, 170)
                for i, f in enumerate(self._tuiles):
                    zones.append((QRectF(m + i * (lw + 10), y, lw, self.H_TUILES - 12), "tuile", f))
                y += self.H_TUILES
        hote = self.parentWidget()
        plafond = (hote.height() - self.y() - 12) if hote is not None else 900
        self._zones = zones
        self.resize(w, int(min(max(y + m, 60), max(160, plafond))))

    # ------------------------------------------------------------------ dessin
    def paintEvent(self, _event) -> None:              # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        cadre = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        fond = QPainterPath()
        fond.addRoundedRect(cadre, 14, 14)
        p.fillPath(fond, QColor(16, 21, 33, 250))
        p.setPen(QPen(couleur("border_hi"), 1))
        p.drawPath(fond)
        p.setClipPath(fond)
        base = self.font()
        for y, titre in self._titres:
            p.setFont(police(base, 12, QFont.Weight.Bold, 1.2))
            p.setPen(couleur("text_faint"))
            p.drawText(QRectF(self.MARGE + 8, y, self.width(), self.H_TITRE),
                       Qt.AlignmentFlag.AlignVCenter, titre.upper())
        if self._terme and not self._jeux:
            p.setFont(police(base, 14))
            p.setPen(couleur("text_dim"))
            texte = (t("Recherche dans toutes les boutiques...") if self._en_cours
                     else t("Aucun jeu du catalogue ne correspond : Entree cherche partout."))
            p.drawText(QRectF(self.MARGE + 8, getattr(self, "_vide_y", 10), self.width() - 40, self.H_VIDE),
                       Qt.AlignmentFlag.AlignVCenter, texte)
        for i, (r, genre, valeur) in enumerate(self._zones):
            choisi = i == self._actif or i == self._survol
            if genre == "fiche":
                self._ligne(p, r, valeur, choisi)
            elif genre == "type":
                self._puce(p, r, dict(self._types).get(valeur, valeur), choisi)
            elif genre == "tuile":
                self._tuile(p, r, valeur, choisi)
            elif genre == "tout":
                self._pied(p, r, choisi)
        p.end()

    def _vignette(self, p: QPainter, r: QRectF, fiche) -> None:
        chemin = QPainterPath()
        chemin.addRoundedRect(r, 8, 8)
        p.save()
        p.setClipPath(chemin, Qt.ClipOperation.IntersectClip)
        taille = QSize(int(r.width()), int(r.height()))
        pix = ChargeurImages.instance().image(fiche.visuels("carte"), taille)
        if pix is not None and not pix.isNull():
            p.drawPixmap(r.toRect(), pix)
        else:
            degrade(p, r, fiche.cle or fiche.titre)
        p.restore()

    def _ligne(self, p: QPainter, r: QRectF, fiche, choisi: bool) -> None:
        if choisi:
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(couleur("surface_hi"))
            p.drawRoundedRect(r.adjusted(0, 2, 0, -2), 10, 10)
        base = self.font()
        image = QRectF(r.left() + 8, r.top() + 8, 108, r.height() - 16)
        self._vignette(p, image, fiche)
        droite = r.right() - 14
        texte_x = image.right() + 14
        largeur_prix = 170
        p.setFont(police(base, 15, QFont.Weight.DemiBold))
        p.setPen(couleur("text"))
        titre = QFontMetrics(p.font()).elidedText(fiche.titre, Qt.TextElideMode.ElideRight,
                                                  int(droite - largeur_prix - texte_x))
        p.drawText(QPointF(texte_x, r.top() + 29), titre)
        sous = [t("DLC") if est_dlc(fiche) else t("Jeu")]
        m = fiche.meilleure
        if m is not None and m.boutique:
            sous.append(t("chez") + f" {m.boutique}")
        if self.possede(fiche):
            sous.append(t("dans ta bibliotheque"))
        p.setFont(police(base, 12.5))
        p.setPen(couleur("text_faint"))
        p.drawText(QPointF(texte_x, r.top() + 50), "  ·  ".join(sous))
        if m is not None:
            bloc_prix(p, droite, r.top() + 40, fiche, base, 15, gauche=droite - largeur_prix)

    def _puce(self, p: QPainter, r: QRectF, libelle: str, choisi: bool) -> None:
        p.setPen(QPen(couleur("accent") if choisi else couleur("border_hi"), 1))
        p.setBrush(couleur("surface_hi") if choisi else Qt.BrushStyle.NoBrush)
        p.drawRoundedRect(r, r.height() / 2, r.height() / 2)
        p.setFont(police(self.font(), 13, QFont.Weight.DemiBold))
        p.setPen(couleur("text"))
        p.drawText(r, Qt.AlignmentFlag.AlignCenter, libelle)

    def _tuile(self, p: QPainter, r: QRectF, fiche, choisi: bool) -> None:
        image = QRectF(r.left(), r.top(), r.width(), r.height() - 30)
        self._vignette(p, image, fiche)
        if choisi:
            p.setPen(QPen(couleur("accent"), 2))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRoundedRect(image.adjusted(1, 1, -1, -1), 8, 8)
        p.setFont(police(self.font(), 12.5, QFont.Weight.DemiBold))
        p.setPen(couleur("text"))
        titre = QFontMetrics(p.font()).elidedText(fiche.titre, Qt.TextElideMode.ElideRight, int(r.width()))
        p.drawText(QPointF(r.left(), r.bottom() - 10), titre)
        if fiche.remise > 0:
            pilule(p, image.right() - 6, image.top() + 6, f"-{fiche.remise} %", couleur("ok"),
                   QColor("#06210F"), police(self.font(), 11.5, QFont.Weight.Bold), 20, a_droite=True)

    def _pied(self, p: QPainter, r: QRectF, choisi: bool) -> None:
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(couleur("accent") if choisi else couleur("surface_hi"))
        p.drawRoundedRect(r, 10, 10)
        n = self._total
        texte = (t("Voir les resultats pour") + f" « {self._terme} »"
                 + (f"  ({n})" if n > JEUX_MAX else "") + "   →")
        p.setFont(police(self.font(), 14, QFont.Weight.Bold))
        p.setPen(QColor("#06121A") if choisi else couleur("text"))
        p.drawText(r, Qt.AlignmentFlag.AlignCenter, texte)

    # ------------------------------------------------------------------ souris
    def _zone(self, pos) -> int:
        for i, (r, _g, _v) in enumerate(self._zones):
            if r.contains(QPointF(pos)):
                return i
        return -1

    def mouseMoveEvent(self, event) -> None:          # noqa: N802
        i = self._zone(event.position())
        if i != self._survol:
            self._survol = i
            self.update()

    def leaveEvent(self, _event) -> None:              # noqa: N802
        self._survol = -1
        self.update()

    def mousePressEvent(self, event) -> None:         # noqa: N802
        i = self._zone(event.position())
        if i >= 0:
            self._declencher(self._zones[i])

    def _declencher(self, zone) -> None:
        _r, genre, valeur = zone
        if genre in ("fiche", "tuile"):
            self.fiche_choisie.emit(valeur)
        elif genre == "type":
            self.type_choisi.emit(valeur)
        elif genre == "tout":
            self.tout_voir.emit()

    def _image_prete(self, _url: str) -> None:
        if self.isVisible():
            self.update()
