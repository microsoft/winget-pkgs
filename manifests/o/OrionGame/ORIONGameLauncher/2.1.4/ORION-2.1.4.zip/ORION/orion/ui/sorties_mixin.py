"""Page Sorties cote fenetre principale (1.8.1).

La liste est lue (en ligne, sinon embarquee) au demarrage puis a chaque
visite de la page si elle date de plus de 6 heures ; les visuels Steam
sont telecharges une fois, en tache de fond, jamais pendant une partie
(le telechargement s'arrete des qu'une partie commence).

Demarrage hors ligne : la liste embarquee s'affiche, mais elle n'est pas
consideree comme « lue » ; la lecture en ligne est refaite au retour du
reseau (evenement `reseau.etat`), ou a la prochaine visite de la page
apres quelques minutes.
"""
from __future__ import annotations

from .minuteur import plus_tard

import time

from PySide6.QtCore import QObject, Signal

from .. import sorties
from ..affiliation import ouvreur
from ..core.config import CONFIG
from ..core.events import BUS
from ..core.logging_setup import get
from ..core.tasks import Task

log = get("ui.sorties")

#: hors ligne, delai avant de retenter a la visite de la page
REESSAI_HORS_LIGNE = 600


class _PontSorties(QObject):
    """Ramene l'evenement reseau (emis depuis un fil de travail) sur l'interface."""
    reseau = Signal(bool)
    visuel = Signal(str, object)           # une affiche vient d'arriver

ouvrir_lien = ouvreur("sorties")   # d'ou vient le clic (compteur anonyme)


class SortiesMixin:
    def _init_sorties(self) -> None:
        v = self.sorties_view
        v.ouvrir_lien.connect(ouvrir_lien)
        v.suivre.connect(self._sortie_suivie)
        v.actualiser_demande.connect(lambda: self.charger_sorties(auto=True))
        self._sorties_lues = 0.0
        self._sorties_en_ligne = False
        self._sorties_occupe = False
        self._visuels_occupe = False
        self._pont_sorties = _PontSorties()
        self._pont_sorties.reseau.connect(self._sorties_reseau)
        self._pont_sorties.visuel.connect(
            lambda ident, v: self.sorties_view.set_visuels({ident: v}))
        BUS.on("reseau.etat",
               lambda en_ligne=True, **_: self._pont_sorties.reseau.emit(bool(en_ligne)))
        # liste embarquee tout de suite : la page n'est jamais vide
        v.definir(sorties.embarquee(), sorties.MAJ)
        # precommandes (2.1.0) : prix des cartes a chaque lecture de la liste,
        # bloc prix de la sortie a la une toutes les 10 minutes
        from PySide6.QtCore import QTimer
        from .. import precommandes
        self._offre_occupe = False
        self._timer_une = QTimer(self)
        self._timer_une.setInterval(precommandes.RAFRAICHIR_UNE * 1000)
        self._timer_une.timeout.connect(lambda: self._releve_une(forcer=True))
        self._timer_une.start()

    def _boot_sorties(self) -> None:
        plus_tard(self, 15000, lambda: self.charger_sorties(auto=True))

    def charger_sorties(self, auto: bool = False) -> None:
        if self._sorties_occupe:
            return
        if auto and time.time() - self._sorties_lues < sorties.GARDER:
            self._illustrer_sorties()
            return
        self._sorties_occupe = True
        t = Task(sorties.charger_etat)
        t.signals.finished.connect(self._sorties_chargees)
        t.signals.failed.connect(lambda *_: setattr(self, "_sorties_occupe", False))
        t.start()

    def _sorties_chargees(self, resultat) -> None:
        self._sorties_occupe = False
        try:
            liste, maj, en_ligne = resultat
        except (TypeError, ValueError):
            return
        self._sorties_en_ligne = bool(en_ligne)
        if en_ligne:
            self._sorties_lues = time.time()
        else:
            # rien d'en ligne (premier demarrage hors ligne) : pas d'attente
            # de 6 h ; nouvel essai au retour du reseau ou dans 10 minutes
            self._sorties_lues = time.time() - sorties.GARDER + REESSAI_HORS_LIGNE
        def appliquer() -> None:
            self.sorties_view.definir(liste, maj)
            self._illustrer_sorties()
            self._releve_precommandes(liste)
        # la page se reconstruit (une carte par sortie) : au repos, ou des
        # qu'on l'ouvre, jamais au milieu d'un geste sur une autre page
        au_repos = getattr(self, "_au_repos", None)
        if au_repos is None:
            appliquer()
        else:
            au_repos("sorties", appliquer)

    def _releve_precommandes(self, liste) -> None:
        """Prix des precommandes (cartes) puis bloc prix de la une."""
        from .. import precommandes
        if self._sorties_a_arreter():
            return
        t = Task(precommandes.prix_cartes, list(liste))
        t.signals.finished.connect(self.sorties_view.set_prix_cartes)
        t.signals.failed.connect(lambda *_: None)
        t.start()
        self._releve_une(forcer=False)

    def _releve_une(self, forcer: bool) -> None:
        """Bloc prix de la sortie a la une : prix officiel, cle verifiee,
        offre de fidelite (si un jeu de la serie est dans la bibliotheque).
        Jamais pendant une partie."""
        from .. import precommandes
        s = self.sorties_view.vedette.s
        if self._offre_occupe or s is None or not s.une or not s.steam \
                or self._sorties_a_arreter():
            return
        self._offre_occupe = True
        jeux = list(self.library.games(include_hidden=True))
        t = Task(precommandes.offre_une, s, jeux, forcer)

        def fini(o) -> None:
            self._offre_occupe = False
            self.sorties_view.set_offre(o)
            self._annoncer_sortie(s, o)
        t.signals.finished.connect(fini)
        t.signals.failed.connect(lambda *_: setattr(self, "_offre_occupe", False))
        t.start()

    def _annoncer_sortie(self, s, o) -> None:
        """Le jour de la sortie de la une : une notification, une seule, avec
        le prix officiel (jamais le revendeur en titre)."""
        restant = sorties.restant(s)
        if restant is None or restant.total_seconds() > 0 \
                or restant.total_seconds() < -sorties.DISPONIBLE_JOURS * 86400:
            return
        if CONFIG.get("sorties.une_annoncee", "") == s.id:
            return
        CONFIG.set("sorties.une_annoncee", s.id)
        prix = f" : {o.texte_officiel}" if o is not None and o.precommande else ""
        notifier = getattr(self, "_system_notify", None)
        if notifier is not None:
            notifier(f"{s.titre} est disponible", f"Disponible maintenant{prix}.", "sorties")

    def _sorties_reseau(self, en_ligne: bool) -> None:
        """Retour du reseau : la liste en ligne est relue si elle manquait."""
        if en_ligne and not self._sorties_en_ligne:
            self.charger_sorties(auto=False)

    def _sorties_a_arreter(self) -> bool:
        """Vrai si une partie est en cours (mode discret) : on n'utilise plus
        le reseau pour les visuels. Lu depuis le fil de travail."""
        try:
            return bool(CONFIG.get("jeu.discret", True) and self.en_partie)
        except Exception:
            return False

    def _illustrer_sorties(self) -> None:
        """Visuels Steam des sorties (une fois ; ensuite lus sur le disque)."""
        if self._visuels_occupe:
            return
        v = self.sorties_view
        deja = {s.id: sorties.visuels(s) for s in v._montrees}
        v.set_visuels({k: d for k, d in deja.items() if d})
        a_faire = v.a_illustrer()
        if not a_faire or self._differer("sorties"):
            return
        self._visuels_occupe = True

        def travail(progress=None):
            return sorties.illustrer(a_faire, arreter=self._sorties_a_arreter,
                                     pret=self._pont_sorties.visuel.emit)

        t = Task(travail)
        t.signals.finished.connect(self._visuels_sorties)
        t.signals.failed.connect(lambda *_: setattr(self, "_visuels_occupe", False))
        t.start()

    def _visuels_sorties(self, visuels) -> None:
        self._visuels_occupe = False
        self.sorties_view.set_visuels({k: d for k, d in (visuels or {}).items() if d})
        # interrompu par une partie : repris a la fin de la partie
        if self._sorties_a_arreter():
            self._differer("sorties")

    def _sortie_suivie(self, appid: str, titre: str) -> None:
        if appid:
            self._wishlist_add(appid, titre)
            self.notify(f"{titre} ajoute a vos Envies.")
