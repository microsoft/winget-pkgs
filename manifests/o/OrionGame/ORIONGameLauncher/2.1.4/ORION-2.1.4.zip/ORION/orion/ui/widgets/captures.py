"""Captures d'ecran d'un jeu : bandeau de vignettes et visionneuse plein ecran.

Les vignettes sont deja sur le disque (telechargees avec les prix). L'image
en grand n'est recuperee qu'a l'ouverture, en arriere-plan : la vignette
agrandie s'affiche aussitot, puis est remplacee par l'image nette.
"""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QObject, QRunnable, QSize, Qt, QThreadPool, Signal
from PySide6.QtGui import QImage, QImageReader, QPixmap
from PySide6.QtWidgets import (QDialog, QFrame, QHBoxLayout, QLabel,
                               QPushButton, QVBoxLayout, QWidget)

from .game_card import rounded
from .layouts import clear_layout
from ..defilement import ZoneDefilante
from ..minuteur import plus_tard

VIGNETTE = QSize(240, 135)


class _Signaux(QObject):
    pret = Signal(int, str)            # index, chemin local


class _Telechargement(QRunnable):
    def __init__(self, index: int, url: str, cible: str) -> None:
        super().__init__()
        self.index, self.url, self.cible = index, url, cible
        self.signaux = _Signaux()

    def run(self) -> None:
        from ...plugins.artwork.base import download
        try:
            Path(self.cible).parent.mkdir(parents=True, exist_ok=True)
            ok = download(self.url, Path(self.cible), timeout=20)
        except Exception:
            ok = False
        self.signaux.pret.emit(self.index, self.cible if ok else "")


def _image_vignette(chemin: str) -> QImage:
    """La capture decodee directement a la taille de la vignette : un JPEG
    de 1920x1080 se lit en reduction (0,45 s pour dix captures en plein
    format, constat du 7 octobre, contre quelques millisecondes ainsi).
    Sans rien de Qt-interface : appelable depuis un fil a part."""
    if not chemin or not Path(chemin).exists():
        return QImage()
    lecteur = QImageReader(chemin)
    lecteur.setAutoTransform(True)
    taille = lecteur.size()
    if taille.isValid() and taille.width() > 0 and taille.height() > 0:
        # reduction a l'echelle qui couvre la vignette (aspect conserve)
        r = max(VIGNETTE.width() / taille.width(), VIGNETTE.height() / taille.height())
        if r < 1:
            lecteur.setScaledSize(QSize(max(1, round(taille.width() * r)),
                                        max(1, round(taille.height() * r))))
    image = lecteur.read()
    if image.isNull():
        return QImage()
    return image.scaled(VIGNETTE, Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                        Qt.TransformationMode.SmoothTransformation)


def _vignette(chemin: str) -> QPixmap:
    """Version synchrone (visionneuse, essais)."""
    image = _image_vignette(chemin)
    return QPixmap() if image.isNull() else QPixmap.fromImage(image)


class _SignalImage(QObject):
    prete = Signal(QImage)


class _Decodage(QRunnable):
    """Lecture et reduction de la capture hors du fil graphique. 15 octobre
    2026 (enregistrement de l'auteur) : la lecture du fichier, sur un disque
    occupe par un releve ou l'antivirus, figeait la fiche a l'ouverture."""

    def __init__(self, chemin: str) -> None:
        super().__init__()
        self.chemin = chemin
        self.signaux = _SignalImage()

    def run(self) -> None:
        try:
            image = _image_vignette(self.chemin)
        except Exception:
            image = QImage()
        self.signaux.prete.emit(image)


class Vignette(QLabel):
    clique = Signal(int)

    def __init__(self, index: int, chemin: str, parent=None) -> None:
        super().__init__(parent)
        self.index = index
        self.setFixedSize(VIGNETTE)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setToolTip("Agrandir")
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setObjectName("Faint")
        if not chemin:
            self.setText("Capture indisponible")
            return
        self.setText("…")
        tache = _Decodage(chemin)
        self._signaux = tache.signaux               # garde la reference le temps du decodage
        tache.signaux.prete.connect(self._poser)
        QThreadPool.globalInstance().start(tache)

    def _poser(self, image: QImage) -> None:
        if image.isNull():
            self.setText("Capture indisponible")
            return
        self.setText("")
        self.setPixmap(rounded(QPixmap.fromImage(image), VIGNETTE, 8))

    def mousePressEvent(self, event) -> None:       # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton:
            self.clique.emit(self.index)
        super().mousePressEvent(event)


class BandeauCaptures(QWidget):
    """Rangee de vignettes defilante ; un clic ouvre la visionneuse."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.captures: list[dict] = []
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self.defile = ZoneDefilante()
        self.defile.setWidgetResizable(True)
        self.defile.setFrameShape(QFrame.Shape.NoFrame)
        self.defile.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.defile.setFixedHeight(VIGNETTE.height() + 18)
        interieur = QWidget()
        interieur.setObjectName("Transparent")
        self.rangee = QHBoxLayout(interieur)
        self.rangee.setContentsMargins(0, 0, 0, 0)
        self.rangee.setSpacing(10)
        self.defile.setWidget(interieur)
        lay.addWidget(self.defile)

    LOT = 4                                 # vignettes posees par tour d'horloge

    def set_captures(self, captures: list[dict]) -> None:
        """Les premieres vignettes tout de suite, les suivantes par lots au
        tour d'horloge suivant : la fiche ne se fige pas le temps de tout lire."""
        self.captures = list(captures or [])
        clear_layout(self.rangee)
        self._serie = getattr(self, "_serie", 0) + 1
        self._poser(0, self._serie)

    def _poser(self, depuis: int, serie: int) -> None:
        if serie != getattr(self, "_serie", 0):
            return                            # d'autres captures sont arrivees entre-temps
        fin = min(depuis + self.LOT, len(self.captures))
        for i in range(depuis, fin):
            v = Vignette(i, self.captures[i].get("local", ""))
            v.clique.connect(self.ouvrir)
            self.rangee.addWidget(v)
        if fin < len(self.captures):
            plus_tard(self, 0, lambda: self._poser(fin, serie))
        else:
            self.rangee.addStretch(1)

    def ouvrir(self, index: int) -> None:
        Visionneuse(self.captures, index, self.window()).exec()


class Visionneuse(QDialog):
    """Capture en grand, avec precedente / suivante (fleches du clavier)."""

    def __init__(self, captures: list[dict], index: int, parent=None) -> None:
        super().__init__(parent)
        self.captures = captures
        self.index = index
        self._taches: list[_Telechargement] = []
        self.setWindowTitle("Captures d'ecran")
        self.setModal(True)
        self.setStyleSheet("QDialog { background: #06080D; }")
        ecran = (parent.screen() if parent else self.screen()).availableGeometry()
        self.resize(int(ecran.width() * 0.8), int(ecran.height() * 0.82))

        lay = QVBoxLayout(self)
        lay.setContentsMargins(16, 12, 16, 12)
        self.image = QLabel()
        self.image.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.image.setMinimumSize(320, 180)
        lay.addWidget(self.image, 1)

        bas = QHBoxLayout()
        self.prec = QPushButton("‹  Precedente")
        self.prec.setObjectName("Ghost")
        self.prec.clicked.connect(lambda: self.aller(self.index - 1))
        bas.addWidget(self.prec)
        bas.addStretch(1)
        self.compteur = QLabel("")
        self.compteur.setObjectName("Dim")
        bas.addWidget(self.compteur)
        bas.addStretch(1)
        self.suiv = QPushButton("Suivante  ›")
        self.suiv.setObjectName("Ghost")
        self.suiv.clicked.connect(lambda: self.aller(self.index + 1))
        bas.addWidget(self.suiv)
        fermer = QPushButton("Fermer")
        fermer.clicked.connect(self.accept)
        bas.addWidget(fermer)
        lay.addLayout(bas)
        # Les fleches font defiler les captures. Un bouton qui a le focus les
        # garderait pour lui (Qt s'en sert pour passer d'un bouton a l'autre) :
        # aucun bouton ne prend le focus, la fenetre recoit les touches.
        for bouton in (self.prec, self.suiv, fermer):
            bouton.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            bouton.setAutoDefault(False)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setFocus()
        self.aller(index)

    # ------------------------------------------------------------------
    def aller(self, index: int) -> None:
        if not self.captures:
            return
        self.index = index % len(self.captures)
        c = self.captures[self.index]
        self.compteur.setText(f"{self.index + 1} / {len(self.captures)}")
        grande = c.get("full_local", "")
        if grande and Path(grande).exists() and Path(grande).stat().st_size > 1024:
            self._afficher(grande)
            return
        self._afficher(c.get("local", ""))          # en attendant la nette
        if c.get("full") and grande:
            tache = _Telechargement(self.index, c["full"], grande)
            tache.signaux.pret.connect(self._arrivee)
            self._taches.append(tache)
            QThreadPool.globalInstance().start(tache)

    def _arrivee(self, index: int, chemin: str) -> None:
        if chemin and index == self.index:
            self._afficher(chemin)

    def _afficher(self, chemin: str) -> None:
        pix = QPixmap(chemin) if chemin and Path(chemin).exists() else QPixmap()
        if pix.isNull():
            self.image.setText("Image indisponible")
            return
        self._pix = pix
        self._ajuster()

    def _ajuster(self) -> None:
        pix = getattr(self, "_pix", None)
        if pix is not None and not pix.isNull():
            self.image.setPixmap(pix.scaled(
                self.image.size(), Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation))

    def resizeEvent(self, event) -> None:           # noqa: N802
        super().resizeEvent(event)
        self._ajuster()

    def keyPressEvent(self, event) -> None:         # noqa: N802
        if event.key() in (Qt.Key.Key_Right, Qt.Key.Key_Space):
            self.aller(self.index + 1)
        elif event.key() == Qt.Key.Key_Left:
            self.aller(self.index - 1)
        else:
            super().keyPressEvent(event)
