"""Banniere d'accueil : l'horizon des jeux, en grand.

Une bibliotheque est une grille de tuiles ; un launcher commence par une
proposition. La banniere ouvre la page sur la derniere partie — de quoi la
reprendre en un clic, avec le choix du profil graphique — puis fait
defiler le reste de la bibliotheque en fondu, comme un horizon qui tourne.

Deux regles tiennent l'ensemble :

* la premiere place revient toujours au dernier jeu joue, annonce comme
  tel. C'est la reponse a « qu'est-ce que je relance ? », et elle ne doit
  pas se derober pendant qu'on la lit ;
* le defilement s'arrete des que la souris entre dans la banniere. Un
  bouton qui bouge sous le curseur est un bouton rate.

Le visuel est peint directement (image large du jeu, recadree, fondue vers
le bas) pour que le texte pose dessus reste lisible quelle que soit la
jaquette : les jeux livrent des images tres claires comme tres sombres.
"""
from __future__ import annotations

import time
from pathlib import Path

from PySide6.QtCore import (QEasingCurve, QPointF, QRect, QRectF, QSize, Qt,
                            QTimer, QVariantAnimation, Signal)
from PySide6.QtGui import (QBrush, QColor, QLinearGradient, QPainter,
                           QPainterPath, QPixmap)
from PySide6.QtWidgets import (QFrame, QGraphicsOpacityEffect, QHBoxLayout,
                               QLabel, QPushButton, QSizePolicy, QVBoxLayout,
                               QWidget)

from ...core.config import CONFIG
from ...core.models import Game
from ...i18n import t
from ..theme import PALETTE, accent

HEIGHT = 208
RADIUS = 14

#: duree du fondu entre deux jeux
FADE_MS = 620

#: taille et marge des pastilles de position, en bas a droite
DOT = 7
DOT_GAP = 9
DOT_MARGIN = 18

#: nom lisible des plateformes, pour la ligne d'informations
SOURCES = {
    "steam": "Steam", "epic": "Epic Games", "gog": "GOG",
    "ubisoft": "Ubisoft Connect", "ea": "EA", "battlenet": "Battle.net",
    "xbox": "Microsoft Store", "dossier": "Dossier de jeux",
    "registre": "Programme installe",
}


def _art(game: Game) -> str:
    """Image la plus large disponible pour ce jeu."""
    for path in (game.art_hero, game.art_cover, game.art_icon):
        if path and Path(path).exists():
            return path
    return ""


def _eyebrow(game: Game, first: bool) -> str:
    """Pourquoi ce jeu est propose, en deux mots."""
    if first:
        return "Dernier jeu joue" if game.last_played else "A lancer"
    if game.favorite:
        return "Votre favori"
    if not game.last_played:
        return "Jamais lance"
    if (time.time() - game.last_played) > 120 * 86400:
        return "Oublie depuis longtemps"
    return "Dans votre bibliotheque"


class HeroBanner(QFrame):
    """L'horizon des jeux : le dernier joue, puis les autres en fondu."""

    play_requested = Signal(str, str)        # uid, profil
    open_requested = Signal(str)             # uid

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("Hero")
        self.setFixedHeight(HEIGHT)
        self.setSizePolicy(QSizePolicy.Policy.Expanding,
                           QSizePolicy.Policy.Fixed)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMouseTracking(True)

        self._games: list[Game] = []
        self._tunable: dict[str, bool] = {}
        self._profiles_by_uid: dict[str, str] = {}
        self._index = 0

        # visuels : celui qui s'efface et celui qui arrive
        self._art_from = QPixmap()
        self._art_to = QPixmap()
        self._scaled: dict[int, QPixmap] = {}
        self._fade = 1.0

        # bloc de texte, anime en opacite pendant la transition
        self._text = QWidget(self)
        self._opacity = QGraphicsOpacityEffect(self._text)
        self._opacity.setOpacity(1.0)
        self._text.setGraphicsEffect(self._opacity)

        root = QVBoxLayout(self)
        root.setContentsMargins(30, 20, 30, 20)
        root.setSpacing(0)
        root.addWidget(self._text)

        col = QVBoxLayout(self._text)
        col.setContentsMargins(0, 0, 0, 0)
        col.setSpacing(0)

        self.eyebrow = QLabel("")
        self.eyebrow.setObjectName("HeroEyebrow")
        col.addWidget(self.eyebrow)

        self.logo = QLabel()
        self.logo.setVisible(False)
        col.addWidget(self.logo)

        self.title = QLabel("")
        self.title.setObjectName("HeroTitle")
        col.addWidget(self.title)

        self.meta = QLabel("")
        self.meta.setObjectName("HeroMeta")
        col.addWidget(self.meta)

        root.addStretch(1)

        row = QHBoxLayout()
        row.setSpacing(10)

        self.play = QPushButton("Jouer")
        self.play.setObjectName("Primary")
        self.play.setCursor(Qt.CursorShape.PointingHandCursor)
        self.play.clicked.connect(self._play)
        row.addWidget(self.play)

        # 2.1.0 : plus de boutons Esport / Detente / Photorealiste ici ; le
        # jeu se lance avec l'objectif choisi dans sa fiche (Votre ecran / Mon choix)
        self.profiles: dict[str, QPushButton] = {}

        row.addSpacing(6)
        self.details = QPushButton("Voir la fiche")
        self.details.setObjectName("HeroGhost")
        self.details.setCursor(Qt.CursorShape.PointingHandCursor)
        self.details.clicked.connect(self._open)
        row.addWidget(self.details)

        row.addStretch(1)
        root.addLayout(row)

        self._profile = ""

        # -- animation ---------------------------------------------------
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(FADE_MS)
        self._anim.setStartValue(0.0)
        self._anim.setEndValue(1.0)
        self._anim.setEasingCurve(QEasingCurve.Type.InOutCubic)
        self._anim.valueChanged.connect(self._on_fade)

        self._rotation = QTimer(self)
        self._rotation.timeout.connect(self._advance)

    # ------------------------------------------------------------------
    # Contenu
    # ------------------------------------------------------------------
    @property
    def game(self) -> Game | None:
        if 0 <= self._index < len(self._games):
            return self._games[self._index]
        return None

    def set_games(self, games: list[Game], profiles: dict[str, str] | None = None,
                  tunable: dict[str, bool] | None = None) -> None:
        """Jeux a faire defiler. Le premier est le dernier joue."""
        self._profiles_by_uid = dict(profiles or {})
        self._tunable = dict(tunable or {})

        ancien = self.game.uid if self.game else ""
        self._games = list(games)
        self.setVisible(bool(self._games))
        if not self._games:
            self._rotation.stop()
            return

        # on reste sur le meme jeu si possible : un rafraichissement de la
        # bibliotheque ne doit pas faire sauter la banniere sous les yeux.
        self._index = next((i for i, g in enumerate(self._games)
                            if g.uid == ancien), 0)
        self._show(self._index, animate=False)
        self._restart_rotation()

    def set_game(self, game: Game | None, profile: str = "") -> None:
        """Compatibilite : un seul jeu a la une."""
        if game is None:
            self.set_games([])
            return
        self.set_games([game], {game.uid: profile} if profile else {})

    def set_profile(self, profile: str) -> None:
        self._profile = profile or ""

    def set_tunable(self, tunable: bool) -> None:
        """Masque le choix du profil quand le jeu n'expose aucun reglage."""
        for button in self.profiles.values():
            button.setVisible(tunable)
        self.play.setText("Jouer" if tunable else "Lancer le jeu")

    # ------------------------------------------------------------------
    # Defilement
    # ------------------------------------------------------------------
    def _restart_rotation(self) -> None:
        secondes = int(CONFIG.get("ui.hero_rotation_seconds", 9) or 0)
        self._rotation.stop()
        if secondes > 0 and len(self._games) > 1:
            self._rotation.start(secondes * 1000)

    def _advance(self) -> None:
        if len(self._games) > 1:
            self._show((self._index + 1) % len(self._games))

    def _show(self, index: int, animate: bool = True) -> None:
        if not self._games:
            return
        index = index % len(self._games)
        jeu = self._games[index]
        precedent = self._art_to

        self._index = index
        self._load_art(jeu)
        self._fill_text(jeu, first=index == 0)
        self.set_profile(self._profiles_by_uid.get(jeu.uid, ""))
        self.set_tunable(self._tunable.get(jeu.uid, True))

        if animate and not precedent.isNull():
            self._art_from = precedent
            self._anim.stop()
            self._anim.start()
        else:
            self._art_from = QPixmap()
            self._fade = 1.0
            self._opacity.setOpacity(1.0)
            self.update()

    def _on_fade(self, value) -> None:
        self._fade = float(value)
        # le texte s'efface puis revient : il ne traverse jamais l'image
        # a mi-chemin, ou les deux visuels se superposent.
        self._opacity.setOpacity(abs(self._fade * 2 - 1))
        self.update()

    def _fill_text(self, game: Game, first: bool) -> None:
        self._load_logo(game)
        self.eyebrow.setText(_eyebrow(game, first))
        self.title.setText("" if not self._logo.isNull() else game.title)
        self.title.setVisible(self._logo.isNull())
        self.meta.setText("   ·   ".join(self._facts(game)))

    # ------------------------------------------------------------------
    @staticmethod
    def _facts(game: Game) -> list[str]:
        out: list[str] = []
        if game.source:
            out.append(SOURCES.get(game.source, game.source.capitalize()))
        seconds = game.total_play_seconds
        if seconds >= 3600:
            out.append(t(f"{seconds // 3600} h de jeu"))
        elif seconds >= 60:
            out.append(t(f"{seconds // 60} min de jeu"))
        if game.last_played:
            days = (time.time() - game.last_played) / 86400
            if days < 1:
                out.append("joue aujourd'hui")
            elif days < 2:
                out.append("joue hier")
            elif days < 30:
                out.append(f"il y a {days:.0f} jours")
            else:
                out.append("derniere partie le " + time.strftime(
                    "%d/%m/%Y", time.localtime(game.last_played)))
        elif game.size_gb >= 1:
            out.append(f"{game.size_gb:.0f} Go installes")
        return out

    def _load_art(self, game: Game) -> None:
        path = _art(game)
        self._art_to = QPixmap(path) if path else QPixmap()
        self._scaled.clear()

    def _load_logo(self, game: Game) -> None:
        path = game.art_logo
        self._logo = QPixmap(path) if path and Path(path).exists() else QPixmap()
        if self._logo.isNull():
            self.logo.setVisible(False)
            return
        scaled = self._logo.scaled(QSize(360, 84),
                                   Qt.AspectRatioMode.KeepAspectRatio,
                                   Qt.TransformationMode.SmoothTransformation)
        self.logo.setPixmap(scaled)
        self.logo.setFixedHeight(scaled.height())
        self.logo.setVisible(True)

    # ------------------------------------------------------------------
    # Interactions
    # ------------------------------------------------------------------
    def _play(self) -> None:
        if self.game is not None:
            self.play_requested.emit(self.game.uid, self._profile)

    def _open(self) -> None:
        if self.game is not None:
            self.open_requested.emit(self.game.uid)

    def _dot_rects(self) -> list[QRect]:
        if len(self._games) < 2:
            return []
        total = len(self._games)
        largeur = total * DOT + (total - 1) * DOT_GAP
        x = self.width() - DOT_MARGIN - largeur
        y = self.height() - DOT_MARGIN - DOT
        return [QRect(x + i * (DOT + DOT_GAP), y, DOT, DOT)
                for i in range(total)]

    def enterEvent(self, event) -> None:              # noqa: N802 (API Qt)
        # un bouton qui bouge sous le curseur est un bouton rate
        self._rotation.stop()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:              # noqa: N802 (API Qt)
        self._restart_rotation()
        super().leaveEvent(event)

    def mouseReleaseEvent(self, event) -> None:       # noqa: N802 (API Qt)
        if event.button() == Qt.MouseButton.LeftButton:
            point = event.position().toPoint()
            for i, rect in enumerate(self._dot_rects()):
                if rect.adjusted(-6, -8, 6, 8).contains(point):
                    self._show(i)
                    return
            self._open()
        super().mouseReleaseEvent(event)

    # ------------------------------------------------------------------
    def resizeEvent(self, event) -> None:             # noqa: N802 (API Qt)
        self._scaled.clear()
        super().resizeEvent(event)

    def _cover(self, pix: QPixmap) -> QPixmap:
        """Image mise a l'echelle pour couvrir la banniere, en cache."""
        if pix.isNull() or self.width() < 2:
            return QPixmap()
        cle = pix.cacheKey()
        cache = self._scaled.get(cle)
        if cache is None:
            cache = pix.scaled(self.size(),
                               Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                               Qt.TransformationMode.SmoothTransformation)
            self._scaled[cle] = cache
        return cache

    def _draw_art(self, p: QPainter, pix: QPixmap, opacity: float,
                  decalage: int) -> None:
        image = self._cover(pix)
        if image.isNull() or opacity <= 0.01:
            return
        p.setOpacity(opacity)
        x = (self.width() - image.width()) // 2 + decalage
        # les bannieres cadrent le sujet en haut : on montre le haut de
        # l'image plutot que son centre.
        y = min(0, (self.height() - image.height()) // 3)
        p.drawPixmap(x, y, image)
        p.setOpacity(1.0)

    def paintEvent(self, event) -> None:              # noqa: N802 (API Qt)
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        rect = QRectF(0, 0, self.width(), self.height())

        path = QPainterPath()
        path.addRoundedRect(rect, RADIUS, RADIUS)
        p.setClipPath(path)
        p.fillRect(rect, QColor(PALETTE["surface"]))

        # fondu croise, avec un leger glissement lateral : l'image sortante
        # part vers la gauche, l'entrante arrive de la droite.
        glisse = int(26 * (1 - self._fade))
        self._draw_art(p, self._art_from, 1.0 - self._fade, -glisse)
        self._draw_art(p, self._art_to, self._fade, glisse)

        veil = QLinearGradient(QPointF(0, 0), QPointF(self.width(), 0))
        veil.setColorAt(0.0, QColor(8, 11, 19, 244))
        veil.setColorAt(0.45, QColor(8, 11, 19, 198))
        veil.setColorAt(1.0, QColor(8, 11, 19, 92))
        p.fillRect(rect, QBrush(veil))

        fade = QLinearGradient(QPointF(0, self.height() * 0.45),
                               QPointF(0, self.height()))
        fade.setColorAt(0.0, QColor(8, 11, 19, 0))
        fade.setColorAt(1.0, QColor(8, 11, 19, 216))
        p.fillRect(rect, QBrush(fade))

        # pastilles de position
        couleur = QColor(accent())
        for i, dot in enumerate(self._dot_rects()):
            actif = i == self._index
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(couleur.red(), couleur.green(), couleur.blue(),
                              230 if actif else 70))
            p.drawEllipse(dot)

        p.setClipping(False)
        line = QLinearGradient(QPointF(0, 0), QPointF(self.width(), 0))
        couleur.setAlpha(170)
        line.setColorAt(0.0, couleur)
        line.setColorAt(0.75, QColor(couleur.red(), couleur.green(),
                                     couleur.blue(), 0))
        p.fillRect(QRect(int(RADIUS), self.height() - 2,
                         int(self.width() - RADIUS * 2), 2), QBrush(line))
        p.end()
