"""Panneau « Ce que votre PC peut faire » (page Ma machine).

De haut en bas :

* **la lecture du PC** : carte graphique, processeur, memoire video et
  memoire vive, chacun avec ce qu'il retient parmi les jeux evalues, et le
  premier frein de la machine en une phrase ;
* **la liste des jeux** : pour chacun, une pastille de niveau (Ultra, Haute,
  Moyenne, Basse, Trop juste) = le plus beau reglage qui reste fluide
  (environ 60 images/s) a la definition de l'ecran, la fourchette d'images
  par seconde, la source (mesure, communaute, estimation) et ou l'avoir.
  Quand une mise a l'echelle (DLSS, FSR, XeSS) ou une definition inferieure
  ferait monter le jeu d'un niveau, la ligne le dit ;
* **le detail du jeu choisi** : sa configuration demandee face a la machine,
  composant par composant, ce qui le rend jouable sans rien acheter, et ce
  qu'il manquerait pour le niveau au-dessus.

La liste compte pres de deux mille jeux. Elle repose sur un modele
(`ModelePuissance`) : seules les lignes a l'ecran sont demandees, filtrer,
chercher ou trier ne fait que recalculer un ordre. Avant la 2.0 chaque
evaluation creait une cellule par case (sept mille objets) et figeait la
fenetre un quart de seconde.
"""
from __future__ import annotations

import html

from orion.core import region

from orion.affiliation import ouvreur  # liens de boutique (partenaires)

from PySide6.QtCore import (QAbstractTableModel, QModelIndex, QRectF, QSize, Qt,
                            QTimer, Signal)
from PySide6.QtGui import QBrush, QColor, QFont, QPainter, QPen
from PySide6.QtWidgets import (QAbstractItemView, QButtonGroup, QComboBox,
                               QFrame, QGridLayout, QHBoxLayout, QHeaderView,
                               QLabel, QLineEdit, QPushButton, QStyle,
                               QStyledItemDelegate, QTableView, QVBoxLayout)

from ...i18n import t
from ...puissance import NOMS, SOURCES, lecture

ouvrir_lien = ouvreur("machine")   # d'ou vient le clic (compteur anonyme)

ICONES = {"mesure": "● Mesure", "communaute": "● Communaute", "estime": "○ Estimation",
          "inconnu": "–"}
COULEURS = {"mesure": "#3DDC97", "communaute": "#38E1FF", "estime": "#AAB4C8",
            "inconnu": "#7F8AA3"}
#: memes couleurs que les pastilles du profil Recommande (fiche du jeu)
COULEURS_NIVEAUX = {"ultra": "#B98CFF", "haute": "#3DDC97", "moyenne": "#38E1FF",
                    "basse": "#FFB454", "insuffisant": "#FF5A5F", "": "#7F8AA3"}
NOMS_NIVEAUX = {"ultra": "Ultra", "haute": "Haute", "moyenne": "Moyenne",
                "basse": "Basse", "insuffisant": "Trop juste", "": "A evaluer"}
RANG = {"ultra": 0, "haute": 1, "moyenne": 2, "basse": 3, "insuffisant": 4, "": 5}
LIMITES = {"cpu": "processeur", "vram": "mem. video", "ram": "memoire",
           "rt": "ray tracing exige"}
COULEURS_ETATS = {"ok": "#3DDC97", "juste": "#FFB454", "manque": "#FF5A5F",
                  "conseil": "#FFB454", "attention": "#FF5A5F", "inconnu": "#7F8AA3"}
SIGNES = {"ok": "✓", "juste": "≈", "manque": "✗", "inconnu": "?"}

#: un jeu que le processeur plafonne sous 60 images/s garde son plus beau niveau
PLAFOND_EXPLIQUE = ("Un niveau peut aussi etre retenu sous les 60 images par seconde quand "
                    "le processeur plafonne : baisser les reglages n'y changerait rien.")

FILTRES = (("tous", "Tous"), ("mes", "Mes jeux"), ("acheter", "A acheter"),
           ("pistes", "Rattrapables"))
TRIS = (("niveau", "Niveau"), ("nom", "Nom"), ("fps", "Images/s"), ("prix", "Prix"))
#: anciens onglets (compatibilite)
ANCIENS = {"vos": "mes", "ultra": "tous", "haute": "tous", "moyenne": "tous"}

NIVEAU = Qt.ItemDataRole.UserRole + 2
LIMITE = Qt.ItemDataRole.UserRole + 3

COL_JEU, COL_NIVEAU, COL_FPS, COL_SOURCE, COL_OFFRE = range(5)
ENTETES = ("Jeu", "Niveau fluide", "Images/s", "Source", "Ou l'avoir")
_SOURCES_TRI = {"mesure": 0, "communaute": 1, "estime": 2, "inconnu": 3}


def _mien(c) -> bool:
    return bool(c.installe or c.possede)


def _fps_tri(e) -> float:
    affiche = e.fps_affiche
    return affiche[0][0] if affiche else -1


#: cle de tri de chaque colonne triable (croissant = le plus interessant d'abord)
CLES_TRI = {
    "niveau": lambda c, e: (RANG.get(e.niveau or "", 5) * 100000 - _fps_tri(e)),
    "nom": lambda c, e: c.titre.lower(),
    "fps": lambda c, e: -_fps_tri(e),
    "prix": lambda c, e: (-1.0 if _mien(c) else float(c.prix) if c.prix is not None else 1e9),
}


class ModelePuissance(QAbstractTableModel):
    """Les jeux evalues, filtres et tries. `ordre` liste les indices (dans
    `tout`) des lignes montrees."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.tout: list[tuple] = []          # (candidat, evaluation)
        self.ordre: list[int] = []
        self._textes: dict[int, tuple] = {}  # indice -> textes de la ligne

    # -- Qt ----------------------------------------------------------------
    def rowCount(self, parent=QModelIndex()) -> int:          # noqa: N802
        return 0 if parent.isValid() else len(self.ordre)

    def columnCount(self, parent=QModelIndex()) -> int:       # noqa: N802
        return 0 if parent.isValid() else len(ENTETES)

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):  # noqa: N802
        if role == Qt.ItemDataRole.DisplayRole and orientation == Qt.Orientation.Horizontal:
            return t(ENTETES[section])
        if role == Qt.ItemDataRole.TextAlignmentRole:
            return int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        return None

    def ligne(self, rangee: int):
        """(candidat, evaluation) de la ligne affichee, ou None."""
        if 0 <= rangee < len(self.ordre):
            return self.tout[self.ordre[rangee]]
        return None

    def _lire(self, i: int) -> tuple:
        """Textes de la ligne, calcules a la premiere demande seulement."""
        memo = self._textes.get(i)
        if memo is not None:
            return memo
        c, e = self.tout[i]
        notes = "\n".join(t(n) for n in e.notes)
        etat = t("installe") if c.installe else t("dans votre bibliotheque") if c.possede else ""
        niveau = e.niveau or ""
        affiche = e.fps_affiche
        texte_fps = "–"
        if affiche:
            f_, preset = affiche
            from ...optimizer.recommande import plage_fps
            texte_fps = t(plage_fps(f_))
            if preset != e.niveau:          # mesure faite a un autre niveau
                texte_fps += f" ({t(NOMS.get(preset, preset))})"
        if _mien(c):
            offre = t("Dans votre bibliotheque")
        elif c.prix is not None:
            offre = ("Gratuit" if c.prix == 0 else region.prix(c.prix)) \
                + (f" · {c.boutique}" if c.boutique else "")
        else:
            offre = "–"
        # a cote de la pastille : la piste pour monter d'un niveau, sinon ce
        # qui plafonne le niveau retenu
        piste = getattr(e, "piste", "")
        a_cote = ("→ " + t(piste)) if piste else (
            t(LIMITES.get(e.limite, "")) if e.limite else "")
        bulle_niveau = notes
        if piste:
            bulle_niveau = (notes + "\n" if notes else "") + t(
                "Sans rien acheter : ") + t(piste)
        memo = (
            c.titre,
            c.titre + (f" ({etat})" if etat else "") + ("\n" + notes if notes else ""),
            t(NOMS_NIVEAUX.get(niveau, niveau)), niveau, a_cote, bulle_niveau,
            texte_fps,
            t(ICONES.get(e.source, e.source)),
            t(SOURCES.get(e.source, "")) + ("\n" + notes if notes else ""),
            offre,
        )
        self._textes[i] = memo
        return memo

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid() or not (0 <= index.row() < len(self.ordre)):
            return None
        i = self.ordre[index.row()]
        c, e = self.tout[i]
        col = index.column()
        if role == Qt.ItemDataRole.DisplayRole:
            m = self._lire(i)
            return (m[0], m[2], m[6], m[7], m[9])[col]
        if role == Qt.ItemDataRole.ToolTipRole:
            m = self._lire(i)
            if col == COL_JEU:
                return m[1]
            if col == COL_NIVEAU:
                return m[5]
            if col == COL_FPS:
                return t("Images par seconde attendues au niveau indique "
                         "(valeur basse : prudente).")
            if col == COL_SOURCE:
                return m[8]
            return t("Double-clic : ouvrir l'offre") if c.url and not _mien(c) else None
        if role == NIVEAU:
            return e.niveau or ""
        if role == LIMITE:
            return self._lire(i)[4]
        if role == Qt.ItemDataRole.FontRole and col == COL_JEU and _mien(c):
            police = QFont()
            police.setBold(True)
            return police
        if role == Qt.ItemDataRole.ForegroundRole:
            if col == COL_SOURCE:
                return QColor(COULEURS.get(e.source, "#AAB4C8"))
            if col == COL_OFFRE and _mien(c):
                return QColor("#7F8AA3")
        return None

    # -- contenu -------------------------------------------------------------
    def definir(self, resultats: list[tuple]) -> None:
        self.beginResetModel()
        self.tout = list(resultats)
        self.ordre = list(range(len(self.tout)))
        self._textes = {}
        self.endResetModel()

    def ordonner(self, ordre: list[int]) -> None:
        """Nouvel ordre des lignes montrees (filtre, recherche ou tri)."""
        if ordre == self.ordre:
            return
        self.beginResetModel()
        self.ordre = list(ordre)
        self.endResetModel()

    def titres(self) -> list[str]:
        return [self.tout[i][0].titre for i in self.ordre]


class _DelegueNiveau(QStyledItemDelegate):
    """Pastille de couleur « Haute », suivie de la piste ou de la limite."""

    def paint(self, painter: QPainter, option, index) -> None:
        self.initStyleOption(option, index)
        # fond de cellule (survol, selection, separateur) comme les autres
        # colonnes, sans le texte : la pastille le remplace
        option.text = ""
        style = option.widget.style() if option.widget is not None else None
        if style is not None:
            style.drawControl(QStyle.ControlElement.CE_ItemViewItem, option, painter,
                              option.widget)
        painter.save()
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        niveau = index.data(NIVEAU) or ""
        texte = t(NOMS_NIVEAUX.get(niveau, niveau))
        couleur = QColor(COULEURS_NIVEAUX.get(niveau, "#7F8AA3"))
        police = QFont(option.font)
        police.setPixelSize(11)
        police.setBold(True)
        painter.setFont(police)
        fm = painter.fontMetrics()
        largeur = max(fm.horizontalAdvance(texte) + 22, 64)
        r = QRectF(option.rect.x() + 6, option.rect.center().y() - 11, largeur, 22)
        fond = QColor(couleur)
        fond.setAlpha(36)
        bord = QColor(couleur)
        bord.setAlpha(150)
        painter.setPen(QPen(bord, 1))
        painter.setBrush(QBrush(fond))
        painter.drawRoundedRect(r, 11, 11)
        painter.setPen(couleur)
        painter.drawText(r, Qt.AlignmentFlag.AlignCenter, texte)
        limite = index.data(LIMITE) or ""
        if limite:
            police.setBold(False)
            painter.setFont(police)
            # une piste (« → Haute avec DLSS ») se lit mieux qu'une limite
            painter.setPen(QColor("#C9D2E3" if limite.startswith("→") else "#7F8AA3"))
            zone = QRectF(r.right() + 8, option.rect.y(),
                          option.rect.right() - r.right() - 10, option.rect.height())
            painter.drawText(zone, Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft,
                             painter.fontMetrics().elidedText(
                                 limite, Qt.TextElideMode.ElideRight, int(zone.width())))
        painter.restore()

    def sizeHint(self, option, index) -> QSize:      # noqa: N802
        return QSize(150, 40)


def _style_pastille(couleur: str) -> str:
    c = QColor(couleur)
    rvb = f"{c.red()}, {c.green()}, {c.blue()}"
    return (
        f"QPushButton {{ background: rgba({rvb}, 36); color: {couleur};"
        f" border: 1px solid rgba({rvb}, 150); border-radius: 9px; padding: 2px 9px;"
        " font-size: 11px; font-weight: 700; }"
        f"QPushButton:hover {{ border-color: {couleur}; }}"
        f"QPushButton:checked {{ background: rgba({rvb}, 90); border: 2px solid {couleur};"
        " padding: 1px 8px; }")


class PuissancePanel(QFrame):
    analyser_demande = Signal()
    ouvrir_jeu = Signal(str)                # uid

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("Panel")
        self._resultats: list[tuple] = []
        self._etat_resultats = None
        self._machine = None
        self._filtre_actif = ""            # choisi a la premiere evaluation
        self._niveau = ""                  # filtre par niveau (« » : tous)
        self._tri = "niveau"
        self._choisi = ""                  # jeu dont le detail est affiche
        lay = QVBoxLayout(self)
        lay.setContentsMargins(18, 16, 18, 16)
        lay.setSpacing(10)

        tete = QHBoxLayout()
        titre = QLabel("Ce que votre PC peut faire")
        titre.setObjectName("PanelTitle")
        tete.addWidget(titre)
        tete.addStretch(1)
        self.note = QLabel("")
        self.note.setObjectName("Value")
        tete.addWidget(self.note)
        lay.addLayout(tete)

        # -- lecture du PC : composant par composant ---------------------
        self.lecture = QFrame()
        self.lecture.setObjectName("Legende")
        self.lecture.setStyleSheet("QFrame#Legende { background: rgba(10, 13, 20, 150);"
                                   " border: 1px solid #232B3D; border-radius: 10px; }"
                                   "QFrame#Legende QLabel { background: transparent; }")
        ll = QVBoxLayout(self.lecture)
        ll.setContentsMargins(14, 10, 14, 10)
        ll.setSpacing(6)
        self.grille = QGridLayout()
        self.grille.setHorizontalSpacing(18)
        self.grille.setVerticalSpacing(5)
        self.grille.setColumnStretch(1, 3)
        self.grille.setColumnStretch(2, 4)
        self.lignes_composants: dict[str, tuple[QLabel, QLabel, QLabel]] = {}
        for rang, (cle, nom) in enumerate((("gpu", "Carte graphique"), ("cpu", "Processeur"),
                                           ("vram", "Memoire video"), ("ram", "Memoire vive"))):
            k = QLabel(nom)
            k.setObjectName("Key")
            valeur = QLabel("–")
            valeur.setObjectName("Value")
            valeur.setWordWrap(True)
            verdict = QLabel("")
            verdict.setWordWrap(True)
            verdict.setStyleSheet("color: #AAB4C8; font-size: 12px;")
            self.grille.addWidget(k, rang, 0, Qt.AlignmentFlag.AlignTop)
            self.grille.addWidget(valeur, rang, 1, Qt.AlignmentFlag.AlignTop)
            self.grille.addWidget(verdict, rang, 2, Qt.AlignmentFlag.AlignTop)
            self.lignes_composants[cle] = (k, valeur, verdict)
        ll.addLayout(self.grille)
        self.frein = QLabel("")
        self.frein.setWordWrap(True)
        self.frein.setStyleSheet("color: #C9D2E3; font-size: 12px; font-weight: 600;")
        ll.addWidget(self.frein)
        self.machine = QLabel("")
        self.machine.setObjectName("Faint")
        self.machine.setWordWrap(True)
        ll.addWidget(self.machine)
        lay.addWidget(self.lecture)

        # legende : ce que veut dire le niveau, en une phrase
        legende = QFrame()
        legende.setObjectName("Legende")
        legende.setStyleSheet("QFrame#Legende { background: rgba(10, 13, 20, 150);"
                              " border: 1px solid #232B3D; border-radius: 10px; }"
                              "QFrame#Legende QLabel { background: transparent; }")
        leg = QVBoxLayout(legende)
        leg.setContentsMargins(14, 10, 14, 10)
        leg.setSpacing(8)
        self.regle = QLabel("")
        self.regle.setWordWrap(True)
        self.regle.setStyleSheet("color: #C9D2E3; font-size: 12px;")
        leg.addWidget(self.regle)
        pastilles = QHBoxLayout()
        pastilles.setSpacing(6)
        self.compteurs: dict[str, QPushButton] = {}
        for n in ("ultra", "haute", "moyenne", "basse", "insuffisant"):
            p = QPushButton(NOMS_NIVEAUX[n])
            p.setCheckable(True)
            p.setCursor(Qt.CursorShape.PointingHandCursor)
            p.setStyleSheet(_style_pastille(COULEURS_NIVEAUX[n]))
            p.setToolTip({
                "ultra": "Tout au maximum et fluide. Attribue seulement apres une "
                         "mesure sur votre PC (ou par la communaute).",
                "haute": "Reglages eleves, fluides.",
                "moyenne": "Fluide en reglages moyens.",
                "basse": "Fluide seulement en reglages bas (ou jouable, sans plus).",
                "insuffisant": "Sous la configuration minimale du jeu."}[n]
                + ("\n" + PLAFOND_EXPLIQUE if n in ("haute", "moyenne") else "")
                + "\nCliquez pour ne voir que ces jeux ; un second clic les montre tous.")
            p.clicked.connect(lambda _=False, c=n: self.filtrer_niveau(c))
            pastilles.addWidget(p)
            self.compteurs[n] = p
        pastilles.addSpacing(14)
        sources = QLabel(
            "<span style='color:#3DDC97'>●</span> mesure sur votre PC &nbsp; "
            "<span style='color:#38E1FF'>●</span> communaute &nbsp; "
            "<span style='color:#AAB4C8'>○</span> estimation prudente")
        sources.setStyleSheet("color: #AAB4C8; font-size: 11px;")
        sources.setToolTip(
            "Mesure : releve par ORION pendant vos parties.\n"
            "Communaute : au moins 3 joueurs ORION avec une carte proche.\n"
            "Estimation : deduite de la configuration recommandee du jeu, "
            "fourchette prudente, jamais classee Ultra.")
        pastilles.addWidget(sources)
        pastilles.addStretch(1)
        leg.addLayout(pastilles)
        lay.addWidget(legende)

        barre = QHBoxLayout()
        barre.setSpacing(6)
        self.groupe = QButtonGroup(self)
        self.groupe.setExclusive(True)
        self.filtres: dict[str, QPushButton] = {}
        for cle, texte in FILTRES:
            b = QPushButton(texte)
            b.setObjectName("Chip")
            b.setCheckable(True)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.clicked.connect(lambda _=False, c=cle: self._montrer(c))
            self.groupe.addButton(b)
            barre.addWidget(b)
            self.filtres[cle] = b
        self.filtres["pistes"].setToolTip(
            "Jeux sous le niveau Haute qu'une mise a l'echelle (DLSS, FSR, XeSS) ou une "
            "definition d'affichage inferieure ferait monter d'un niveau, sans rien "
            "acheter.")
        barre.addSpacing(8)
        self.recherche = QLineEdit()
        self.recherche.setObjectName("Search")
        self.recherche.setPlaceholderText("Rechercher un jeu")
        self.recherche.setClearButtonEnabled(True)
        self.recherche.setMaximumWidth(240)
        self.recherche.setStyleSheet("QLineEdit#Search { padding: 4px 12px; }")
        # le filtre attend la fin de la frappe (comparaison tolerante de
        # pres de deux mille titres)
        self._frappe = QTimer(self)
        self._frappe.setSingleShot(True)
        self._frappe.setInterval(120)
        self._frappe.timeout.connect(self._appliquer_filtre)
        self.recherche.textChanged.connect(lambda _t: self._frappe.start())
        barre.addWidget(self.recherche)
        barre.addStretch(1)
        tri = QLabel("Trier par")
        tri.setObjectName("Faint")
        barre.addWidget(tri)
        self.tri = QComboBox()
        for cle, texte in TRIS:
            self.tri.addItem(texte, cle)
        self.tri.currentIndexChanged.connect(
            lambda _i: self.trier(self.tri.currentData() or "niveau"))
        barre.addWidget(self.tri)
        lay.addLayout(barre)

        self.modele = ModelePuissance(self)
        self.table = QTableView()
        self.table.setModel(self.modele)
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Fixed)
        self.table.verticalHeader().setDefaultSectionSize(40)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setShowGrid(False)
        self.table.setWordWrap(False)
        self.table.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.table.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.table.setItemDelegateForColumn(COL_NIVEAU, _DelegueNiveau(self.table))
        h = self.table.horizontalHeader()
        h.setSectionResizeMode(COL_JEU, QHeaderView.ResizeMode.Stretch)
        for i, w in ((COL_NIVEAU, 265), (COL_FPS, 110), (COL_SOURCE, 120),
                     (COL_OFFRE, 190)):
            h.resizeSection(i, w)
        h.setDefaultAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        h.setSectionsClickable(True)
        h.sectionClicked.connect(self._clic_entete)
        self.table.setMinimumHeight(380)
        self.table.viewport().setToolTip(
            "Clic : pourquoi ce niveau, et comment le rendre jouable. Double-clic : "
            "ouvrir la fiche du jeu, ou l'offre pour un jeu a acheter.")
        self.table.doubleClicked.connect(lambda index: self._double_clic(index.row()))
        self.table.clicked.connect(lambda index: self.choisir(index.row()))
        lay.addWidget(self.table)

        # -- detail du jeu choisi -------------------------------------------
        self.detail = QFrame()
        self.detail.setObjectName("Legende")
        self.detail.setStyleSheet("QFrame#Legende { background: rgba(10, 13, 20, 150);"
                                  " border: 1px solid #232B3D; border-radius: 10px; }"
                                  "QFrame#Legende QLabel { background: transparent; }")
        dl = QVBoxLayout(self.detail)
        dl.setContentsMargins(14, 10, 14, 10)
        dl.setSpacing(5)
        self.detail_titre = QLabel("")
        self.detail_titre.setObjectName("Value")
        dl.addWidget(self.detail_titre)
        self.detail_resume = QLabel("")
        self.detail_resume.setWordWrap(True)
        self.detail_resume.setStyleSheet("color: #C9D2E3; font-size: 12px;")
        dl.addWidget(self.detail_resume)
        self.detail_lignes = QLabel("")
        self.detail_lignes.setWordWrap(True)
        self.detail_lignes.setTextFormat(Qt.TextFormat.RichText)
        self.detail_lignes.setStyleSheet("color: #AAB4C8; font-size: 12px;")
        dl.addWidget(self.detail_lignes)
        self.detail_pistes = QLabel("")
        self.detail_pistes.setWordWrap(True)
        self.detail_pistes.setTextFormat(Qt.TextFormat.RichText)
        self.detail_pistes.setStyleSheet("color: #C9D2E3; font-size: 12px;")
        dl.addWidget(self.detail_pistes)
        self.detail_manque = QLabel("")
        self.detail_manque.setWordWrap(True)
        self.detail_manque.setStyleSheet("color: #AAB4C8; font-size: 12px;")
        dl.addWidget(self.detail_manque)
        # pieces neuves compatibles avec ce PC, chez des revendeurs (2.1.0)
        self.detail_pieces = QLabel("")
        self.detail_pieces.setWordWrap(True)
        self.detail_pieces.setTextFormat(Qt.TextFormat.RichText)
        self.detail_pieces.setOpenExternalLinks(False)
        self.detail_pieces.linkActivated.connect(ouvrir_lien)
        self.detail_pieces.setStyleSheet("color: #C9D2E3; font-size: 12px;")
        dl.addWidget(self.detail_pieces)
        lay.addWidget(self.detail)
        self._detail_vide()

        bas = QHBoxLayout()
        self.vide = QLabel("")
        self.vide.setObjectName("Dim")
        self.vide.setWordWrap(True)
        bas.addWidget(self.vide, 1)
        self.etat = QLabel("")
        self.etat.setObjectName("Faint")
        bas.addWidget(self.etat)
        self.b_analyser = QPushButton("Analyser plus de jeux")
        self.b_analyser.setObjectName("Ghost")
        self.b_analyser.clicked.connect(self.analyser_demande.emit)
        bas.addWidget(self.b_analyser)
        lay.addLayout(bas)
        self.set_definition("")

    # ------------------------------------------------------------------
    def set_definition(self, definition: str) -> None:
        ecran = f"en {definition} (la definition de votre ecran)" if definition \
            else "a la definition de votre ecran"
        self.regle.setText(
            "<b>Niveau fluide</b> = le plus beau reglage qui tient environ 60 images "
            f"par seconde {ecran}.")

    def set_machine(self, machine) -> None:
        self._machine = machine
        score = machine.score
        self.note.setText(t(f"Note {score}/100") if score is not None else "")
        self.machine.setText(t(f"Ecran {machine.definition} a {machine.hz} Hz")
                             + t(". Indices de puissance : RTX 4090 = 100, "
                                 "Ryzen 7 9800X3D = 100."))
        self.set_definition(machine.definition)
        self._lire_composants()

    def _lire_composants(self) -> None:
        """Les quatre composants, avec ce que chacun retient parmi les jeux
        evalues, et le premier frein de la machine."""
        if self._machine is None:
            return
        for c in lecture.composants(self._machine, self._resultats):
            _nom, valeur, verdict = self.lignes_composants[c.cle]
            texte = c.valeur
            if c.indice:
                texte += t(f" · indice {c.indice:g}")
            if c.proches:
                texte += t(f" (du niveau de : {c.proches})")
            valeur.setText(texte)
            verdict.setText(t(c.verdict))
            verdict.setStyleSheet(
                f"color: {COULEURS_ETATS.get(c.etat, '#AAB4C8')}; font-size: 12px;"
                if c.etat in ("attention", "conseil", "ok") else
                "color: #7F8AA3; font-size: 12px;")
        bilan = lecture.freins(self._resultats)
        phrase = t(lecture.phrase_frein(bilan))
        mes = lecture.freins(self._resultats, seulement_mes=True)
        if mes["evalues"]:
            fluides = mes["fluides"]
            phrase += t(f"  Parmi vos jeux : {fluides} sur {mes['evalues']} "
                        "en Haute.")
        self.frein.setText(phrase)
        self.frein.setVisible(bool(phrase))

    def set_etat(self, texte: str, occupe: bool = False) -> None:
        self.etat.setText(texte)
        self.b_analyser.setEnabled(not occupe)

    # ------------------------------------------------------------------
    def set_resultats(self, resultats) -> None:
        """Nouvelle evaluation. Une evaluation qui rend les memes resultats
        ne change rien a l'ecran."""
        resultats = list(resultats)
        etat = tuple((c.titre, c.installe, c.possede, c.prix, c.boutique, e.niveau, e.source,
                      e.limite, str(e.fps_affiche), tuple(e.notes),
                      getattr(e, "piste", "")) for c, e in resultats)
        if etat == self._etat_resultats:
            return
        self._etat_resultats = etat
        self._resultats = resultats
        mes = sum(1 for c, _e in resultats if _mien(c))
        nombres = {"tous": len(resultats), "mes": mes, "acheter": len(resultats) - mes,
                   "pistes": sum(1 for _c, e in resultats if getattr(e, "piste", ""))}
        for cle, texte in FILTRES:
            self.filtres[cle].setText(f"{t(texte)}  {nombres[cle]}")
        for n, p in self.compteurs.items():
            k = sum(1 for _c, e in resultats if e.niveau == n)
            p.setText(f"{t(NOMS_NIVEAUX[n])}  {k}")
        if not self._filtre_actif:
            self._filtre_actif = "mes" if mes else "tous"
        self.filtres[self._filtre_actif].setChecked(True)
        self.modele.definir(resultats)
        self._appliquer_filtre()
        self._lire_composants()
        self._rechoisir()

    # ------------------------------------------------------------------
    def trier(self, cle: str) -> None:
        """Reordonne les lignes (rien n'est reconstruit)."""
        self._tri = cle if cle in dict(TRIS) else "niveau"
        i = self.tri.findData(self._tri)
        if i >= 0 and i != self.tri.currentIndex():
            self.tri.blockSignals(True)
            self.tri.setCurrentIndex(i)
            self.tri.blockSignals(False)
        self._appliquer_filtre()

    def _clic_entete(self, col: int) -> None:
        cle = {COL_NIVEAU: "niveau", COL_JEU: "nom", COL_FPS: "fps",
               COL_OFFRE: "prix"}.get(col)
        if cle:
            self.trier(cle)

    def _montrer(self, cle: str) -> None:
        """Filtre « Tous | Mes jeux | A acheter | Rattrapables »."""
        cle = ANCIENS.get(cle, cle)
        if cle not in self.filtres:
            cle = "tous"
        self._filtre_actif = cle
        self.filtres[cle].setChecked(True)
        self._appliquer_filtre()

    def filtrer_niveau(self, niveau: str) -> None:
        """Clic sur une pastille : seulement les jeux de ce niveau ; un second
        clic sur la meme les montre tous."""
        self._niveau = "" if niveau == self._niveau or niveau not in self.compteurs \
            else niveau
        for n, p in self.compteurs.items():
            p.setChecked(n == self._niveau)
        self._appliquer_filtre()

    def _visible(self, c, e, cherche: str) -> bool:
        if self._filtre_actif == "mes" and not _mien(c):
            return False
        if self._filtre_actif == "acheter" and _mien(c):
            return False
        if self._filtre_actif == "pistes" and not getattr(e, "piste", ""):
            return False
        if self._niveau and e.niveau != self._niveau:
            return False
        if not cherche or cherche in c.titre.lower():
            return True
        from ...core.recherche import correspond
        return correspond(cherche, c.titre)

    def _appliquer_filtre(self) -> None:
        self._frappe.stop()
        cherche = self.recherche.text().strip().lower()
        cle = CLES_TRI[self._tri]
        tout = self.modele.tout
        gardes = [i for i, (c, e) in enumerate(tout) if self._visible(c, e, cherche)]
        # tri stable : a egalite, les jeux du joueur puis l'ordre alphabetique
        gardes.sort(key=lambda i: (cle(*tout[i]), not _mien(tout[i][0]),
                                   tout[i][0].titre.lower()))
        self.modele.ordonner(gardes)
        self._rechoisir()
        if gardes:
            self.vide.setText("")
            return
        if cherche:
            self.vide.setText(t("Aucun jeu ne correspond a cette recherche."))
        elif self._niveau:
            self.vide.setText(t("Aucun jeu a ce niveau dans cette liste."))
        elif self._filtre_actif == "pistes":
            self.vide.setText(t("Aucun jeu a rattraper : tout ce qui est evalue tourne "
                                "deja en Haute, ou rien n'y ferait."))
        elif self._filtre_actif == "mes":
            self.vide.setText(t("Aucun de vos jeux n'a encore ete evalue : cliquez sur "
                                "« Analyser plus de jeux »."))
        else:
            self.vide.setText(t("Aucun jeu evalue pour l'instant : cliquez sur "
                                "« Analyser plus de jeux »."))

    def titres_visibles(self) -> list[str]:
        """Titres des jeux montres, dans l'ordre de la liste."""
        return self.modele.titres()

    # -- detail du jeu choisi ------------------------------------------------
    @staticmethod
    def _cle_jeu(c) -> str:
        return c.appid or c.uid or c.titre

    def choisir(self, rangee: int) -> None:
        """Montre le detail du jeu de cette ligne."""
        ligne = self.modele.ligne(rangee)
        if ligne is None:
            return
        self._choisi = self._cle_jeu(ligne[0])
        self._expliquer(*ligne)

    def _rechoisir(self) -> None:
        """Apres un filtre, un tri ou une nouvelle evaluation : la selection
        et le detail suivent le jeu choisi, ou s'effacent s'il n'est plus
        dans la liste."""
        if not self._choisi:
            return
        for rangee, i in enumerate(self.modele.ordre):
            c, e = self.modele.tout[i]
            if self._cle_jeu(c) == self._choisi:
                self.table.selectRow(rangee)
                self._expliquer(c, e)
                return
        self.table.clearSelection()
        self._choisi = ""
        self._detail_vide()

    def _detail_vide(self) -> None:
        self.detail_titre.setText(t("Cliquez un jeu de la liste"))
        self.detail_resume.setText(t(
            "ORION vous dit pourquoi il obtient ce niveau, ce qui peut le rendre "
            "jouable sans rien acheter, et ce qu'il manquerait pour le niveau au-dessus."))
        for w in (self.detail_lignes, self.detail_pistes, self.detail_manque):
            w.setText("")
            w.hide()

    def _expliquer(self, c, e) -> None:
        from ...puissance import exigences
        exig = None
        if c.appid:
            try:
                exig = exigences.en_cache(c.appid)
            except Exception:
                exig = None
        machine = self._machine
        if machine is None:
            return
        x = lecture.expliquer(c.titre, e, exig, machine, getattr(e, "calibration", 1.0))
        self.detail_titre.setText(c.titre)
        # les composants qui retiennent le jeu se traduisent un a un
        self.detail_resume.setText(
            t(x.debut) + " · ".join(t(r) for r in x.retenus) + "." if x.retenus
            else t(x.resume))
        rangs = []
        for li in x.lignes:
            couleur = COULEURS_ETATS.get(li.etat, "#7F8AA3")
            rangs.append(
                f"<tr><td style='color:{couleur}; padding-right:8px'>{SIGNES.get(li.etat, '?')}"
                f"</td><td style='padding-right:14px'>{t(li.nom)}</td>"
                f"<td style='padding-right:14px; color:#C9D2E3'>{t(li.vous)}</td>"
                f"<td>{t('demande :')} {t(li.demande)}</td></tr>")
        entete = t({"recommandee": "Face a la configuration recommandee du jeu :",
                    "minimale": "Face a la configuration minimale du jeu (la seule "
                                "publiee) :"}.get(x.base, ""))
        self.detail_lignes.setText(
            (f"<div style='margin-bottom:3px'>{entete}</div>"
             f"<table cellspacing='0' cellpadding='1'>{''.join(rangs)}</table>"
             + (f"<div style='margin-top:3px; color:#C9D2E3'>{t(x.contexte)}</div>"
                if x.contexte else ""))
            if rangs else "")
        self.detail_lignes.setVisible(bool(rangs))
        if x.pistes:
            self.detail_pistes.setText(
                "<b>" + t("Sans rien acheter") + "</b> " + t("(si le jeu le propose) : ")
                + " · ".join(t(p.texte) for p in x.pistes))
        self.detail_pistes.setVisible(bool(x.pistes))
        pieces = self._pieces_html(x, machine)
        self.detail_manque.setText(" ".join(t(m) for m in x.manque)
                                   + ((t(" Ce sont des reperes de puissance ; les pieces "
                                         "compatibles avec votre PC sont en dessous.") if pieces
                                       else t(" Ce sont des reperes de puissance, pas des "
                                              "conseils d'achat.")) if x.manque else ""))
        self.detail_manque.setVisible(bool(x.manque))
        self.detail_pieces.setText(pieces)
        self.detail_pieces.setVisible(bool(pieces))

    @staticmethod
    def _pieces_html(x, machine) -> str:
        """Les pieces neuves compatibles pour le niveau Haute, avec un lien de
        recherche par revendeur ; « » quand il n'y a rien a proposer."""
        from ...hardware import systeme
        from ... import materiel
        try:
            pieces = materiel.pieces_du_jeu(x.besoins, machine, systeme.en_cache())
        except Exception:
            return ""
        if not any(p.achetable for p in pieces):
            return ""
        morceaux = []
        for p in pieces:
            exemples = []
            for e in p.exemples:
                liens = p.liens.get(e) or []
                if liens:
                    boutiques = " · ".join(
                        f"<a href='{html.escape(li.url, quote=True)}' style='color:#8FB5FF'>"
                        f"{html.escape(li.boutique)}</a>"
                        + (f" <span style='color:#7F8AA3'>({t('lien partenaire')})</span>"
                           if li.partenaire else "")
                        for li in liens)
                    exemples.append(f"{html.escape(e)} ({boutiques})")
                else:
                    exemples.append(html.escape(e))
            ligne = f"<b>{t(p.nom)}</b> : " + f" {t('ou')} ".join(exemples)
            if p.precision:
                ligne += f", {t(p.precision)}"
            if p.reserve:
                ligne += f". <span style='color:#AAB4C8'>{t(p.reserve)}</span>"
            morceaux.append(ligne)
        titre = x.besoins[-1].debut if x.besoins else "Pour le niveau Haute"
        return (f"<div style='margin-top:4px'><b>{t('Materiel neuf compatible avec votre PC')}</b> "
                f"({t(titre)}) — {t('les prix et les stocks sont ceux du revendeur, ORION ne vend rien.')}"
                "</div>" + "".join(f"<div style='margin-top:2px'>{m}</div>" for m in morceaux))

    def _double_clic(self, rangee: int) -> None:
        ligne = self.modele.ligne(rangee)
        if ligne is None:
            return
        c = ligne[0]
        if _mien(c) and c.uid:
            self.ouvrir_jeu.emit(c.uid)
        elif c.url:
            ouvrir_lien(c.url)
