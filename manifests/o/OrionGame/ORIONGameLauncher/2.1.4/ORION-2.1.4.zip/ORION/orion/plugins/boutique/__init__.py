"""Sources de prix de la Boutique (Steam, GOG, IsThereAnyDeal...)."""
