"""Mesure des performances en jeu."""
