"""Cadeaux et week-ends gratuits agreges (GamerPower).

Cette source couvre ce qu'aucune boutique ne publie seule : les cadeaux
Prime Gaming, GOG, Ubisoft, itch.io, les cles distribuees par les editeurs,
et les week-ends gratuits. Elle est publique et ne demande pas de cle.

C'est ici que se joue la distinction la plus utile de la page : un cadeau
se garde a vie, un week-end gratuit s'arrete. Le libelle de l'offre est
analyse pour trancher, et le doute penche vers « a garder », qui ne propose
jamais de supprimer un jeu.
"""
from __future__ import annotations

import re

from ...core.logging_setup import get
from .base import (A_GARDER, TEMPORAIRE, Freebie, FreebieSource, fetch_json,
                   looks_temporary, parse_date)

log = get("gratuits.gamerpower")

API = "https://www.gamerpower.com/api/giveaways"

#: boutique reconnue a partir du champ `platforms` renvoye par l'API
SHOPS = (
    ("epic", "Epic Games Store"),
    ("steam", "Steam"),
    ("gog", "GOG"),
    ("ubisoft", "Ubisoft Connect"),
    ("origin", "EA app"),
    ("ea app", "EA app"),
    ("battle.net", "Battle.net"),
    ("prime", "Prime Gaming"),
    ("itch.io", "itch.io"),
    ("xbox", "Xbox"),
    ("drm-free", "Sans DRM"),
)


#: l'API suffixe le titre par la plateforme et la nature de l'offre :
#: « Sausage Hunter (Indiegala) Giveaway », « Dwarven Realms (Steam) Key
#: Giveaway ». Retirer ces mentions permet de reconnaitre l'offre que la
#: boutique publie elle-meme et d'eviter un doublon dans la liste.
#:
#: Seules les parentheses dont le contenu designe une plateforme ou une cle
#: sont retirees : « Game (Definitive Edition) » garde son titre entier.
_PAREN = re.compile(
    r"\s*\((?:[^()]*\b(?:steam|epic|epic\s*games|gog|itch\.io|itchio|ubisoft|"
    r"uplay|origin|ea\s*app|battle\.net|prime\s*gaming|amazon|xbox|"
    r"microsoft\s*store|drm[- ]?free|indiegala|fanatical|humble|alienware|"
    r"gamehag|key|keys|giveaway|early\s*access|free\s*weekend|beta|pc)\b"
    r"[^()]*)\)\s*$", re.I)

_TRAILING = re.compile(
    r"\s*(?:\b(?:steam|epic|gog|pc|game|dlc|beta|key|keys)\b\s*)*"
    r"(?:giveaway|free\s*weekend|early\s*access|beta\s*keys?|"
    r"key\s*giveaway)\s*$", re.I)


def _clean_instructions(texte: str) -> str:
    """Instructions de l'agregateur, ramenees a une consigne lisible."""
    brut = re.sub(r"<[^>]+>", " ", texte or "")
    brut = re.sub(r"\s+", " ", brut).strip()
    return brut[:400]


def clean_title(title: str) -> str:
    """Titre sans les mentions ajoutees par l'agregateur."""
    previous = None
    out = (title or "").strip()
    while out != previous:
        previous = out
        out = _TRAILING.sub("", out).strip()
        out = _PAREN.sub("", out).strip()
        out = out.strip(" -:\u2013\u2014").strip()
    return out or (title or "").strip()


class GamerPowerFreebies(FreebieSource):
    id = "gamerpower"
    label = "Cadeaux et week-ends gratuits"
    priority = 80
    filtre_adulte = ("champs de l'annonce lus par produit_adulte ; le jeu est ensuite "
                     "verifie sur sa fiche Steam quand il en a une")

    def fetch(self) -> list[Freebie]:
        entries = fetch_json(API, {"platform": "pc", "type": "game",
                                   "sort-by": "date"}) or []
        if not isinstance(entries, list):
            return []

        out: list[Freebie] = []
        for e in entries:
            try:
                fb = self._one(e)
            except Exception:
                continue
            if fb is not None:
                out.append(fb)
        log.info("GamerPower : %d offre(s)", len(out))
        return out

    # ------------------------------------------------------------------
    def _one(self, e: dict) -> Freebie | None:
        if str(e.get("status") or "Active").lower() != "active":
            return None
        title = str(e.get("title") or "").strip()
        if not title:
            return None
        platforms = str(e.get("platforms") or "")
        instructions = str(e.get("instructions") or "")
        description = str(e.get("description") or "")

        temporary = looks_temporary(title, description, instructions)
        # « Mindcop (Epic Games) Giveaway » -> « Mindcop » : sans cela,
        # l'annonce de l'agregateur et celle de la boutique feraient deux
        # lignes pour le meme jeu.
        clean = clean_title(title)

        # (2.1.2) une offre IndieGala est rangee « DRM-Free » par l'agregateur,
        # mais elle demande un compte IndieGala (gratuit) ; sa « valeur »
        # (29,99 $ pour Wordle comme pour Best Plumber) est celle qu'annonce
        # IndieGala, inverifiable : elle n'est pas montree.
        indiegala = "indiegala" in f"{title} {instructions}".lower()
        shop = "IndieGala" if indiegala else self._shop(platforms)
        return Freebie(
            adulte=self.adulte(e),
            key=f"gamerpower:{e.get('id')}",
            title=clean or title,
            source=self.id,
            shop=shop,
            url=str(e.get("open_giveaway_url") or e.get("gamerpower_url") or ""),
            kind=TEMPORAIRE if temporary else A_GARDER,
            ends_at=parse_date(e.get("end_date")),
            worth=0.0 if indiegala else self._worth(e.get("worth")),
            currency="USD",
            image=str(e.get("image") or e.get("thumbnail") or ""),
            description=description.strip()[:400],
            # « Login to your Alienware Arena account and redeem 10 ARP » :
            # c'est exactement ce que le joueur doit savoir avant de cliquer.
            conditions=_clean_instructions(instructions),
        )

    @staticmethod
    def _shop(platforms: str) -> str:
        low = platforms.lower()
        for needle, label in SHOPS:
            if needle in low:
                return label
        return platforms.split(",")[0].strip() or "PC"

    @staticmethod
    def _worth(value) -> float:
        raw = str(value or "").replace("$", "").replace("EUR", "").strip()
        try:
            return round(float(raw), 2)
        except ValueError:
            return 0.0
