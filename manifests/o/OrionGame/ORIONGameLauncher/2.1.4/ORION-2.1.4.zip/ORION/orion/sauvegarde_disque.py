"""Sauvegarder un jeu sur un autre disque dur (1.9).

Remplace, dans l'interface, le « deplacement » par jonction de la 1.8 :
Steam et les autres launchers ne reconnaissaient pas un jeu transfere de
cette facon. Ici le jeu installe n'est JAMAIS touche (ni renomme, ni
remplace par un lien) : ORION en fait une copie complete et verifiee dans
`<disque>:\\Sauvegardes ORION\\<nom du jeu>`.

Sauvegarder :

1. controles : le jeu existe, la destination est sur un autre disque et
   celui-ci a la place (taille du jeu + 5 % + 1 Go de marge) ;
2. copie fichier par fichier vers `<nom>.copie-en-cours`, avec un
   avancement detaille (pourcentage, taille, temps restant, fichier en
   cours) et une annulation propre : la copie partielle est supprimee ;
3. verification : memes fichiers, memes tailles, memes dates ; puis le jeu
   est remesure pour s'assurer qu'il n'a pas change pendant la copie ;
4. la copie prend son nom definitif. Une sauvegarde precedente au meme
   endroit n'est remplacee qu'une fois la nouvelle complete et verifiee.

Restaurer : meme copie verifiee, vers `<dossier du jeu>.restauration-en-cours`
a cote du jeu, puis renommage. Si des fichiers du jeu sont presents (et
seulement avec l'accord explicite du joueur, `remplacer=True`), ils sont
mis de cote (`.remplace-orion`) le temps de la bascule et supprimes
ensuite ; en cas d'echec ils reprennent leur place.

`reparer_restes()`, appele au demarrage, nettoie ce qu'un arret brutal
aurait laisse. Les sauvegardes sont notees par l'interface dans
`game.extra["sauvegardes_disque"]` : liste de
`{"chemin", "date", "octets", "fichiers", "version"?}`.
"""
from __future__ import annotations

import os
import re
import shutil
import threading
import time
from pathlib import Path

from . import deplacement as dep
from .core.logging_setup import get

log = get("sauvegarde_disque")

DOSSIER = "Sauvegardes ORION"
CLE = "sauvegardes_disque"

SUFFIXE_COPIE = ".copie-en-cours"
SUFFIXE_ANCIENNE = ".ancienne-sauvegarde"
SUFFIXE_RESTAURATION = ".restauration-en-cours"
SUFFIXE_REMPLACE = ".remplace-orion"
SUFFIXES = (SUFFIXE_COPIE, SUFFIXE_ANCIENNE, SUFFIXE_RESTAURATION, SUFFIXE_REMPLACE)

#: taille des blocs copies (l'annulation est verifiee entre deux blocs)
TAMPON = 4 * 1024 * 1024

ORIGINAL_INTACT = "Le jeu installe n'a pas ete modifie."
JEU_INTACT = "Les fichiers actuels du jeu n'ont pas ete modifies."

_INTERDITS = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
_RESERVES = {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)),
             *(f"LPT{i}" for i in range(1, 10))}


class SauvegardeImpossible(Exception):
    """Echec d'une sauvegarde, d'une restauration ou d'une suppression.

    Le texte dit toujours dans quel etat se trouve le jeu."""


class SauvegardeAnnulee(SauvegardeImpossible):
    """Le joueur a annule ; la copie partielle a ete retiree."""


class SauvegardeExistante(SauvegardeImpossible):
    """Une sauvegarde existe deja a cet endroit (`remplacer=True` pour la
    remplacer)."""


class JeuPresent(SauvegardeImpossible):
    """Des fichiers du jeu sont presents : restaurer les remplacerait
    (`remplacer=True` apres accord explicite du joueur)."""


class Annulation:
    """Drapeau partage entre l'interface (qui annule) et la copie (qui
    s'arrete au prochain bloc)."""

    def __init__(self) -> None:
        self._evenement = threading.Event()

    def annuler(self) -> None:
        self._evenement.set()

    @property
    def demandee(self) -> bool:
        return self._evenement.is_set()


# ----------------------------------------------------------------------
# chemins
# ----------------------------------------------------------------------
def nom_dossier(titre: str, install_dir: str = "") -> str:
    """Nom de dossier Windows valide tire du titre du jeu."""
    nom = _INTERDITS.sub(" ", titre or "")
    nom = re.sub(r"\s+", " ", nom).strip(" .")[:120].strip(" .")
    if not nom:
        # separateurs Windows ET POSIX (le nom est aussi calcule hors Windows)
        nom = re.split(r"[\\/]", (install_dir or "").rstrip("\\/"))[-1] or "Jeu"
        nom = _INTERDITS.sub(" ", nom).strip(" .") or "Jeu"
    if nom.split(".")[0].upper() in _RESERVES:
        nom = f"{nom} (jeu)"
    return nom


def racine_disque(disque: str) -> Path:
    """`disque` : « F: », « F:\\ »... ou un dossier racine (tests)."""
    d = str(disque).rstrip("\\/")
    return Path(d + "\\") if len(d) == 2 and d[1] == ":" else Path(d)


def destination(disque: str, nom: str) -> Path:
    return racine_disque(disque) / DOSSIER / nom


def _lettre(chemin: Path) -> str:
    ancre = Path(chemin).anchor
    return ancre[:2].upper() if ancre[1:2] == ":" else ""


def _dedans(enfant: Path, parent: Path) -> bool:
    e, p = dep._normal(enfant), dep._normal(parent)
    return e == p or e.startswith(p.rstrip("\\/") + os.sep)


def disques_sauvegarde(hw_disques: list[dict], install_dir: str) -> list[dict]:
    """Disques ou sauvegarder ce jeu : tous sauf le sien, les lecteurs
    optiques et les partages reseau. Les disques externes (USB) conviennent
    tres bien a une sauvegarde et sont donc proposes."""
    actuel = (install_dir[:2] if len(install_dir) > 1 and install_dir[1] == ":"
              else "").upper()
    sortie = []
    for d in hw_disques or []:
        lettre = str(d.get("mount", "")).rstrip("\\/").upper()
        if not lettre or lettre == actuel:
            continue
        if d.get("type") in ("cdrom", "network"):
            continue
        sortie.append({"lettre": lettre, "libre_go": d.get("free_gb"),
                       "total_go": d.get("total_gb"),
                       "amovible": d.get("type") == "removable" or bool(d.get("removable"))})
    return sortie


# ----------------------------------------------------------------------
# copie fichier par fichier, annulable
# ----------------------------------------------------------------------
def _est_lien(chemin: str) -> bool:
    try:
        return os.path.islink(chemin) or (hasattr(os.path, "isjunction")
                                           and os.path.isjunction(chemin))
    except OSError:
        return False


def _copier_fichier(a: str, b: str, suivi: dep.Suivi, annulation) -> None:
    with open(a, "rb") as fa, open(b, "wb") as fb:
        while True:
            if annulation is not None and annulation.demandee:
                raise SauvegardeAnnulee("annulee")
            bloc = fa.read(TAMPON)
            if not bloc:
                break
            fb.write(bloc)
            suivi.ajouter(len(bloc))
    # dates (la verification les compare) et attributs (lecture seule...)
    shutil.copystat(a, b)


def copier_dossier(src: Path, dst: Path, total: int, progress_cb=None,
                   annulation: Annulation | None = None) -> None:
    """Copie `src` dans `dst` (qui ne doit pas exister).

    Les dossiers-liens (jonctions, liens symboliques) a l'interieur du jeu
    ne sont pas suivis, comme dans `deplacement.mesurer` : la verification
    compare donc les memes fichiers.
    """
    suivi = dep.Suivi(total, progress_cb)
    src, dst = str(src), str(dst)
    os.makedirs(dst)
    for racine, dossiers, fichiers in os.walk(src):
        rel = os.path.relpath(racine, src)
        cible = dst if rel == "." else os.path.join(dst, rel)
        for d in list(dossiers):
            chemin = os.path.join(racine, d)
            if _est_lien(chemin):
                log.info("Lien ignore dans la copie : %s", chemin)
                dossiers.remove(d)
                continue
            os.makedirs(os.path.join(cible, d), exist_ok=True)
        for f in fichiers:
            if annulation is not None and annulation.demandee:
                raise SauvegardeAnnulee("annulee")
            a = os.path.join(racine, f)
            suivi.fichier(os.path.relpath(a, src))
            _copier_fichier(a, os.path.join(cible, f), suivi, annulation)
    suivi._envoyer(force=True)


# ----------------------------------------------------------------------
# outils communs
# ----------------------------------------------------------------------
def _abandonner(temp: Path, message: str, etat: str,
                classe: type = SauvegardeImpossible) -> None:
    """Retire la copie de travail puis leve l'erreur."""
    restes = dep._supprimer(temp)
    if restes:
        message += (f"\nLa copie partielle « {temp} » n'a pas pu etre supprimee "
                    f"entierement ({len(restes)} element(s)) : supprimez-la a la main.")
    raise classe(f"{message}\n\n{etat}")


def _vider(temp: Path, etat: str) -> None:
    if temp.exists() or dep.est_jonction(temp):
        if dep._supprimer(temp):
            raise SauvegardeImpossible(
                f"une copie d'une tentative precedente (« {temp} ») n'a pas pu etre "
                f"supprimee : supprimez-la a la main puis reessayez\n\n{etat}")


def _verifier(reference: dep.Bilan, autre: dep.Bilan, temp: Path, etat: str,
              message: str, tolerance_ns: int) -> None:
    if (autre.fichiers, autre.octets) != (reference.fichiers, reference.octets):
        _abandonner(temp, f"{message} ({autre.fichiers}/{reference.fichiers} fichiers)",
                    etat)
    ecarts = dep._ecarts(reference, autre, tolerance_ns)
    if ecarts:
        exemples = ", ".join(ecarts[:3]) + (" ..." if len(ecarts) > 3 else "")
        _abandonner(temp, f"{message} : {len(ecarts)} fichier(s) different(s) ({exemples})",
                    etat)


def _place(bilan: dep.Bilan, dossier: Path, disque: str, etat: str) -> None:
    besoin = int(bilan.octets * dep.MARGE) + dep.MARGE_FIXE
    libre = dep.espace_libre(dossier)
    if libre < besoin:
        raise SauvegardeImpossible(
            f"place insuffisante sur {disque} : {dep.taille_lisible(besoin)} necessaires "
            f"(jeu + marge de securite), {dep.taille_lisible(libre)} libres\n\n{etat}")


def _modifiable(dossier: Path, etat: str) -> None:
    try:
        dep._dossier_modifiable(dossier, "")
    except dep.DeplacementImpossible as exc:
        raise SauvegardeImpossible(f"{exc.message}\n\n{etat}") from exc


def _copier_et_verifier(src: Path, temp: Path, bilan: dep.Bilan, progress_cb,
                        annulation, etat: str, quoi: str) -> None:
    try:
        copier_dossier(src, temp, bilan.octets, progress_cb, annulation)
    except SauvegardeAnnulee:
        _abandonner(temp, f"{quoi} annulee : la copie partielle a ete supprimee.", etat,
                    SauvegardeAnnulee)
    except Exception as exc:
        log.warning("Copie impossible : %s", exc)
        _abandonner(temp, f"copie impossible : {dep._detail(exc)}", etat)
    if annulation is not None and annulation.demandee:
        _abandonner(temp, f"{quoi} annulee : la copie partielle a ete supprimee.", etat,
                    SauvegardeAnnulee)
    if progress_cb:
        progress_cb("Verification de la copie, fichier par fichier...", 100)
    _verifier(bilan, dep.mesurer(temp), temp, etat, "copie incomplete ou differente",
              dep.TOLERANCE_NS)
    _verifier(bilan, dep.mesurer(src), temp, etat,
              "les fichiers d'origine ont change pendant la copie (jeu ou launcher "
              "ouvert ?) : reessayez une fois tout ferme", 0)


# ----------------------------------------------------------------------
# sauvegarder
# ----------------------------------------------------------------------
def verifier_possible(install_dir, disque: str, nom: str,
                      remplacer: bool = False) -> tuple[Path, dep.Bilan]:
    src = Path(install_dir)
    etat = ORIGINAL_INTACT
    if not src.is_dir():
        raise SauvegardeImpossible(f"dossier du jeu introuvable ({src})")
    if dep.est_jonction(src):
        raise SauvegardeImpossible(
            "ce jeu a ete deplace par une ancienne version d'ORION : ramenez-le "
            f"d'abord sur son disque d'origine, puis sauvegardez-le\n\n{etat}")
    dst = destination(disque, nom)
    if _lettre(src) and _lettre(src) == _lettre(dst):
        raise SauvegardeImpossible(
            f"la sauvegarde doit se trouver sur un autre disque que le jeu\n\n{etat}")
    if _dedans(dst, src) or _dedans(src, dst):
        raise SauvegardeImpossible(
            f"la sauvegarde ne peut pas etre rangee dans le dossier du jeu\n\n{etat}")
    if (dst.exists() or dep.est_jonction(dst)) and not remplacer:
        raise SauvegardeExistante(f"une sauvegarde existe deja dans « {dst} »\n\n{etat}")
    try:
        dst.parent.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise SauvegardeImpossible(
            f"impossible de creer « {dst.parent} » ({dep._detail(exc)})\n\n{etat}") from exc
    _modifiable(dst.parent, etat)
    bilan = dep.mesurer(src)
    if not bilan.fichiers:
        raise SauvegardeImpossible(f"le dossier du jeu est vide ({src})\n\n{etat}")
    _place(bilan, dst.parent, disque, etat)
    return dst, bilan


def sauvegarder(install_dir: str, disque: str, nom: str = "", progress_cb=None,
                annulation: Annulation | None = None, remplacer: bool = False,
                version: str = "") -> dict:
    """Copie verifiee du jeu sur `disque` ; le jeu installe n'est pas touche.

    Rend `{"chemin", "date", "octets", "fichiers", "duree", "source",
    "version"?, "restes"}` (`restes` : ce qui n'a pas pu etre nettoye)."""
    debut = time.monotonic()
    src = Path(install_dir)
    nom = nom or nom_dossier("", str(src))
    etat = ORIGINAL_INTACT
    if progress_cb:
        progress_cb("Mesure du jeu...", 0)
    dst, bilan = verifier_possible(src, disque, nom, remplacer)
    temp = dst.with_name(dst.name + SUFFIXE_COPIE)
    _vider(temp, etat)
    log.info("Sauvegarde de %s vers %s (%d fichiers, %s)", src, dst, bilan.fichiers,
             dep.taille_lisible(bilan.octets))
    _copier_et_verifier(src, temp, bilan, progress_cb, annulation, etat, "Sauvegarde")

    restes: list[str] = []
    if dst.exists() or dep.est_jonction(dst):
        # la sauvegarde precedente ne part qu'une fois la nouvelle en place
        ancienne = dst.with_name(dst.name + SUFFIXE_ANCIENNE)
        _vider(ancienne, etat)
        try:
            dst.rename(ancienne)
        except OSError as exc:
            _abandonner(temp, "l'ancienne sauvegarde est utilisee (dossier ouvert dans "
                              f"l'Explorateur ?) : {dep._detail(exc)}", etat)
        try:
            temp.rename(dst)
        except OSError as exc:
            ancienne.rename(dst)
            _abandonner(temp, f"mise en place impossible : {dep._detail(exc)}", etat)
        fin = dep._supprimer(ancienne)
        if fin:
            restes.append(f"L'ancienne sauvegarde « {ancienne} » n'a pas pu etre supprimee "
                          f"entierement ({len(fin)} element(s)) : supprimez-la a la main.")
    else:
        try:
            temp.rename(dst)
        except OSError as exc:
            _abandonner(temp, f"mise en place impossible : {dep._detail(exc)}", etat)

    log.info("Jeu sauvegarde : %s -> %s", src, dst)
    resultat = {"chemin": str(dst), "date": time.time(), "octets": bilan.octets,
                "fichiers": bilan.fichiers, "duree": round(time.monotonic() - debut, 1),
                "source": str(src), "restes": restes}
    if version:
        resultat["version"] = version
    return resultat


# ----------------------------------------------------------------------
# restaurer
# ----------------------------------------------------------------------
def restaurer(sauvegarde: str, install_dir: str, progress_cb=None,
              annulation: Annulation | None = None, remplacer: bool = False) -> dict:
    """Recopie la sauvegarde a l'emplacement du jeu.

    Si des fichiers du jeu sont presents, leve `JeuPresent` sauf si
    `remplacer` (accord explicite du joueur) : ils ne sont alors supprimes
    qu'une fois la restauration complete et verifiee."""
    debut = time.monotonic()
    sauv, cible = Path(sauvegarde), Path(install_dir)
    if not sauv.is_dir():
        raise SauvegardeImpossible(
            f"sauvegarde introuvable : « {sauv} » (disque debranche ?)\n\n{JEU_INTACT}")
    if sauv.parent.name != DOSSIER:
        raise SauvegardeImpossible(f"« {sauv} » n'est pas une sauvegarde ORION\n\n{JEU_INTACT}")
    if dep.est_jonction(cible):
        raise SauvegardeImpossible(
            "ce jeu a ete deplace par une ancienne version d'ORION : ramenez-le "
            f"d'abord sur son disque d'origine\n\n{JEU_INTACT}")
    if _dedans(cible, sauv) or _dedans(sauv, cible):
        raise SauvegardeImpossible(f"emplacements imbriques, rien n'est fait\n\n{JEU_INTACT}")
    present = cible.exists()
    if present and not remplacer:
        raise JeuPresent(f"des fichiers du jeu sont presents dans « {cible} »\n\n{JEU_INTACT}")
    etat = JEU_INTACT if present else "Le jeu n'a pas ete restaure ; la sauvegarde est intacte."
    remplace = cible.with_name(cible.name + SUFFIXE_REMPLACE)
    if present and (remplace.exists() or dep.est_jonction(remplace)):
        raise SauvegardeImpossible(
            f"« {remplace} » existe deja (reste d'une restauration precedente) : "
            f"verifiez son contenu puis supprimez-le avant de reessayer\n\n{etat}")
    try:
        cible.parent.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise SauvegardeImpossible(
            f"impossible de creer « {cible.parent} » ({dep._detail(exc)})\n\n{etat}") from exc
    _modifiable(cible.parent, etat)
    if progress_cb:
        progress_cb("Mesure de la sauvegarde...", 0)
    bilan = dep.mesurer(sauv)
    _place(bilan, cible.parent, _lettre(cible) or str(cible.parent), etat)
    temp = cible.with_name(cible.name + SUFFIXE_RESTAURATION)
    _vider(temp, etat)
    log.info("Restauration de %s vers %s (%d fichiers)", sauv, cible, bilan.fichiers)
    _copier_et_verifier(sauv, temp, bilan, progress_cb, annulation, etat, "Restauration")

    restes: list[str] = []
    if present:
        try:
            cible.rename(remplace)
        except OSError as exc:
            _abandonner(temp, "les fichiers actuels du jeu sont utilises (jeu, launcher ou "
                              f"antivirus ouvert ?) : {dep._detail(exc)}", etat)
        try:
            temp.rename(cible)
        except OSError as exc:
            remplace.rename(cible)
            _abandonner(temp, f"mise en place impossible : {dep._detail(exc)}", etat)
        fin = dep._supprimer(remplace)
        if fin:
            restes.append(f"Les anciens fichiers « {remplace} » n'ont pas pu etre supprimes "
                          f"entierement ({len(fin)} element(s)) : supprimez-les a la main.")
    else:
        try:
            temp.rename(cible)
        except OSError as exc:
            _abandonner(temp, f"mise en place impossible : {dep._detail(exc)}", etat)
    log.info("Jeu restaure : %s -> %s", sauv, cible)
    return {"chemin": str(cible), "octets": bilan.octets, "fichiers": bilan.fichiers,
            "duree": round(time.monotonic() - debut, 1), "remplace": present,
            "restes": restes}


# ----------------------------------------------------------------------
# supprimer
# ----------------------------------------------------------------------
def supprimer_sauvegarde(chemin: str) -> list[str]:
    """Supprime une sauvegarde ORION ; rend ce qui n'a pas pu l'etre.

    Par securite, seul un dossier range dans « Sauvegardes ORION » est
    supprime (jamais un jeu installe)."""
    p = Path(chemin)
    if p.parent.name != DOSSIER or not p.name or p.name.endswith(SUFFIXES):
        raise SauvegardeImpossible(
            f"« {p} » n'est pas une sauvegarde ORION : par securite, rien n'est supprime")
    if not p.exists() and not dep.est_jonction(p):
        return []
    restes = dep._supprimer(p)
    try:
        p.parent.rmdir()                 # « Sauvegardes ORION » vide : retire
    except OSError:
        pass
    return restes


# ----------------------------------------------------------------------
# fiches
# ----------------------------------------------------------------------
def liste(game) -> list[dict]:
    return [s for s in (getattr(game, "extra", {}) or {}).get(CLE) or []
            if isinstance(s, dict) and s.get("chemin")]


def noter(game, resultat: dict) -> dict:
    """Enregistre une sauvegarde sur la fiche (remplace celle du meme dossier)."""
    fiche = {"chemin": resultat["chemin"], "date": resultat.get("date") or time.time(),
             "octets": int(resultat.get("octets") or 0),
             "fichiers": int(resultat.get("fichiers") or 0)}
    if resultat.get("version"):
        fiche["version"] = resultat["version"]
    autres = [s for s in liste(game) if not dep._meme_chemin(s["chemin"], fiche["chemin"])]
    game.extra[CLE] = autres + [fiche]
    return fiche


def oublier(game, chemin: str) -> None:
    restantes = [s for s in liste(game) if not dep._meme_chemin(s["chemin"], chemin)]
    if restantes:
        game.extra[CLE] = restantes
    else:
        game.extra.pop(CLE, None)


def version_du_jeu(game) -> str:
    extra = getattr(game, "extra", {}) or {}
    return str(extra.get("version") or extra.get("buildid") or "")


# ----------------------------------------------------------------------
# remise en ordre au demarrage
# ----------------------------------------------------------------------
def reparer_restes(games, racines=()) -> dep.Reparation:
    """Nettoie ce qu'un arret brutal pendant une sauvegarde ou une
    restauration a laisse. L'etat retenu est toujours le plus sur."""
    r = dep.Reparation()
    for racine in racines:
        if not racine:
            continue
        base = racine_disque(str(racine)) / DOSSIER
        try:
            entrees = list(base.iterdir()) if base.is_dir() else []
        except OSError:
            continue
        for d in entrees:
            if d.name.endswith(SUFFIXE_COPIE):
                dep._nettoyer(d, r, f"Copie de sauvegarde inachevee supprimee : {d}")
            elif d.name.endswith(SUFFIXE_ANCIENNE):
                finale = d.with_name(d.name[:-len(SUFFIXE_ANCIENNE)])
                if finale.is_dir():
                    dep._nettoyer(d, r, f"Ancienne sauvegarde remplacee supprimee : {d}")
                else:
                    try:
                        d.rename(finale)
                        r.actions.append(f"Sauvegarde precedente remise en place : {finale}")
                    except OSError as exc:
                        r.restes.append(f"« {d} » : renommez-le en « {finale.name} » "
                                        f"({dep._detail(exc)}).")
    for g in games:
        dossier = getattr(g, "install_dir", "")
        if not dossier:
            continue
        cible = Path(dossier)
        titre = getattr(g, "title", cible.name)
        temp = cible.with_name(cible.name + SUFFIXE_RESTAURATION)
        remplace = cible.with_name(cible.name + SUFFIXE_REMPLACE)
        try:
            if remplace.is_dir() and not cible.exists() and not dep.est_jonction(cible):
                # restauration interrompue entre les deux renommages
                remplace.rename(cible)
                r.actions.append(f"{titre} : restauration interrompue, fichiers d'origine "
                                 f"remis en place ({cible})")
            elif remplace.exists() and cible.is_dir():
                # la bascule avait abouti (copie verifiee en place)
                dep._nettoyer(remplace, r, f"{titre} : anciens fichiers remplaces par la "
                                           "restauration supprimes")
            if temp.exists() or dep.est_jonction(temp):
                dep._nettoyer(temp, r, f"{titre} : copie de restauration inachevee supprimee")
        except OSError as exc:
            r.restes.append(f"{titre} : remise en ordre impossible ({dep._detail(exc)})")
    for texte in r.actions:
        log.info("Remise en ordre : %s", texte)
    for texte in r.restes:
        log.warning("A regler : %s", texte)
    return r
