"""La derniere version du pilote NVIDIA pour la serie de la carte.

Le service d'ORION (`api.orion-launcher.com/pilotes`) releve une fois par
jour, sur le site de NVIDIA, la derniere version Game Ready par serie de
cartes (50, 40, 30, 20, 16 et 10, bureau et portable) : la version n'est pas
la meme d'une serie a l'autre (les GeForce 10 sont sur une branche de
securite). L'application compare a la version installee et donne la page du
pilote de *cette* serie. Resultat garde douze heures ; sans reponse, rien
n'est affirme.
"""
from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass

from ..core.logging_setup import get
from ..core.paths import CACHE_DIR

log = get("hardware.pilotes_nvidia")

ADRESSE = "https://api.orion-launcher.com/pilotes"
FICHIER = CACHE_DIR / "pilotes-nvidia.json"
FRAICHEUR = 12 * 3600

_SERIE = re.compile(r"\b(?:rtx|gtx)\s*(50|40|30|20|16|10)\d{2}\b", re.I)
_PORTABLE = re.compile(r"(laptop|notebook|mobile|max-q|max q)", re.I)
_NVIDIA = re.compile(r"^\d{3}\.\d{2}$")


@dataclass
class Derniere:
    version: str
    date: str = ""
    nom: str = ""
    details: str = ""
    fichier: str = ""


def serie(nom_gpu: str, portable: bool = False) -> str:
    """« NVIDIA GeForce RTX 4070 » -> « 40 » ; « RTX 4070 Laptop GPU » -> « 40p »."""
    m = _SERIE.search(nom_gpu or "")
    if not m:
        return ""
    mobile = portable or bool(_PORTABLE.search(nom_gpu or ""))
    return m.group(1) + ("p" if mobile else "")


def version_installee(gpu) -> str:
    """La version NVIDIA (« 561.74 ») : celle de nvidia-smi quand il repond,
    sinon convertie depuis la version Windows du pilote (« 32.0.15.6174 »)."""
    v = str(getattr(gpu, "driver_version", "") or "").strip()
    if _NVIDIA.match(v):
        return v
    parts = v.split(".")
    if len(parts) == 4 and all(p.isdigit() for p in parts):
        chiffres = (parts[2] + parts[3])[-5:]
        if len(chiffres) == 5:
            return f"{chiffres[:3]}.{chiffres[3:]}"
    return ""


def plus_recente(installee: str, derniere: str) -> bool:
    try:
        a = tuple(int(x) for x in installee.split("."))
        b = tuple(int(x) for x in derniere.split("."))
    except ValueError:
        return False
    return len(a) == len(b) == 2 and b > a


def interpreter(donnees: dict) -> dict[str, Derniere]:
    """Fonction pure : la reponse du service -> {serie: Derniere}."""
    out: dict[str, Derniere] = {}
    for cle, v in (donnees.get("nvidia") or {}).items():
        if not isinstance(v, dict) or not _NVIDIA.match(str(v.get("version") or "")):
            continue
        details = str(v.get("details") or "")
        if details and not details.startswith("https://www.nvidia.com/"):
            continue
        out[str(cle)] = Derniere(version=str(v["version"]), date=str(v.get("date") or ""),
                                nom=str(v.get("nom") or ""), details=details,
                                fichier=str(v.get("fichier") or ""))
    return out


_CACHE: tuple[float, dict[str, Derniere]] | None = None
_EN_COURS = False


def connu() -> dict[str, Derniere]:
    """Ce qui est deja en memoire ou dans le fichier, meme ancien, sans
    toucher au reseau (pour le fil de l'interface)."""
    global _CACHE
    if _CACHE:
        return _CACHE[1]
    try:
        d = json.loads(FICHIER.read_text(encoding="utf-8"))
        _CACHE = (float(d.get("lu") or 0), interpreter(d))
        return _CACHE[1]
    except Exception:
        return {}


def lancer(force: bool = False) -> bool:
    """Rafraichit en fond si le resultat a plus de douze heures ; `pilotes.maj`
    est emis a la fin pour que la page Conseils se recompose."""
    global _EN_COURS
    connu()
    if _EN_COURS or (not force and _CACHE and time.time() - _CACHE[0] < FRAICHEUR):
        return False
    _EN_COURS = True

    def travail() -> None:
        global _EN_COURS
        try:
            dernieres(force)
        finally:
            _EN_COURS = False
            try:
                from ..core.events import BUS
                BUS.emit("pilotes.maj")
            except Exception:
                pass

    import threading
    threading.Thread(target=travail, name="orion-pilotes-nvidia", daemon=True).start()
    return True


def dernieres(force: bool = False) -> dict[str, Derniere]:
    """{serie: Derniere} connu (memoire, fichier de moins de douze heures,
    sinon le service). Vide si rien n'est connu : l'appelant n'affirme rien."""
    global _CACHE
    if _CACHE and not force and time.time() - _CACHE[0] < FRAICHEUR:
        return _CACHE[1]
    if not force:
        try:
            d = json.loads(FICHIER.read_text(encoding="utf-8"))
            if time.time() - float(d.get("lu") or 0) < FRAICHEUR:
                _CACHE = (float(d["lu"]), interpreter(d))
                return _CACHE[1]
        except Exception:
            pass
    try:
        from ..core import reseau
        r = reseau.get(ADRESSE, timeout=10)
        d = r.json() if r.status_code == 200 else {}
    except Exception as exc:
        log.debug("Service des pilotes injoignable : %s", exc)
        d = {}
    lu = interpreter(d) if isinstance(d, dict) else {}
    if lu:
        try:
            FICHIER.parent.mkdir(parents=True, exist_ok=True)
            FICHIER.write_text(json.dumps(dict(d, lu=time.time()), ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass
        _CACHE = (time.time(), lu)
    return lu
