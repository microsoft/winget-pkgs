"""Detection des jeux Steam (toutes bibliotheques)."""
from __future__ import annotations

from pathlib import Path

from ...core.logging_setup import get
from ...core.models import Game
from ...core.winutil import HKCU, HKLM, read_vdf, reg_value
from .base import Scanner, detect_engine

log = get("scan.steam")

#: Outils Steam qui ne sont pas des jeux.
SKIP_APPIDS = {
    "228980",   # Steamworks Common Redistributables
    "1070560", "1391110", "1628350",   # runtimes Proton/Linux
}


def steam_root() -> Path | None:
    for root, path, name in (
        (HKCU, r"Software\Valve\Steam", "SteamPath"),
        (HKLM, r"SOFTWARE\Valve\Steam", "InstallPath"),
    ):
        v = reg_value(root, path, name)
        if v and Path(v).is_dir():
            return Path(v)
    for guess in (r"C:\Program Files (x86)\Steam", r"C:\Program Files\Steam"):
        if Path(guess).is_dir():
            return Path(guess)
    return None


def steam_libraries(root: Path) -> list[Path]:
    """Toutes les bibliotheques declarees (disques secondaires compris)."""
    libs = [root]
    vdf = root / "steamapps" / "libraryfolders.vdf"
    data = read_vdf(vdf).get("libraryfolders") or read_vdf(vdf).get("LibraryFolders") or {}
    for _idx, entry in data.items():
        path = entry.get("path") if isinstance(entry, dict) else entry
        if path:
            p = Path(path)
            if p.is_dir() and p not in libs:
                libs.append(p)
    return libs


def steam_playtimes(root: Path) -> dict[str, tuple[int, float]]:
    """Temps de jeu Steam par appid : {appid: (secondes, derniere partie)}.

    Lu dans localconfig.vdf de chaque compte local ; c'est la seule source
    fiable hors connexion a l'API Steam.
    """
    out: dict[str, tuple[int, float]] = {}
    userdata = root / "userdata"
    if not userdata.is_dir():
        return out
    for account in userdata.iterdir():
        cfg = account / "config" / "localconfig.vdf"
        if not cfg.is_file():
            continue
        data = read_vdf(cfg)
        node = data.get("UserLocalConfigStore", {})
        for key in ("Software", "software"):
            node = node.get(key, node) if isinstance(node, dict) else {}
        for key in ("Valve", "valve"):
            node = node.get(key, node) if isinstance(node, dict) else {}
        for key in ("Steam", "steam"):
            node = node.get(key, node) if isinstance(node, dict) else {}
        apps = {}
        for key in ("apps", "Apps"):
            if isinstance(node, dict) and key in node:
                apps = node[key]
                break
        if not isinstance(apps, dict):
            continue
        for appid, info in apps.items():
            if not isinstance(info, dict):
                continue
            minutes = info.get("Playtime") or info.get("playtime") or 0
            last = info.get("LastPlayed") or info.get("lastplayed") or 0
            try:
                seconds = int(minutes) * 60
                last_f = float(last)
            except (TypeError, ValueError):
                continue
            if seconds or last_f:
                known = out.get(str(appid), (0, 0.0))
                out[str(appid)] = (max(known[0], seconds), max(known[1], last_f))
    return out


class SteamScanner(Scanner):
    id = "steam"
    label = "Steam"
    icon = "STM"
    priority = 100

    def available(self) -> bool:
        return steam_root() is not None

    def scan(self) -> list[Game]:
        root = steam_root()
        if root is None:
            return []
        games: list[Game] = []
        playtimes = steam_playtimes(root)
        from ...steam_famille import comptes_locaux
        self._locaux = comptes_locaux(root)
        for lib in steam_libraries(root):
            apps = lib / "steamapps"
            if not apps.is_dir():
                continue
            for acf in apps.glob("appmanifest_*.acf"):
                try:
                    g = self._from_manifest(acf, apps)
                    if g:
                        seconds, last = playtimes.get(g.source_id, (0, 0.0))
                        g.external_seconds = seconds
                        if last:
                            g.last_played = max(g.last_played, last)
                        games.append(g)
                except Exception:
                    log.exception("Manifeste Steam illisible : %s", acf)
        log.info("%d jeux Steam", len(games))
        return games

    # ------------------------------------------------------------------
    def _from_manifest(self, acf: Path, apps_dir: Path) -> Game | None:
        data = read_vdf(acf).get("AppState") or {}
        appid = str(data.get("appid") or "")
        name = data.get("name") or ""
        if not appid or appid in SKIP_APPIDS or not name:
            return None
        if "Steamworks Common" in name or name.startswith("Proton"):
            return None

        install_dir = apps_dir / "common" / (data.get("installdir") or name)
        # StateFlags : 4 = totalement installe ; tout autre bit = maj en attente
        try:
            flags = int(data.get("StateFlags") or 0)
        except ValueError:
            flags = 0

        # (2.1.2) jeu prete par la famille Steam : la licence vient d'un
        # compte qui n'est pas sur ce PC
        from ...steam_famille import PRETE, prete
        famille = prete(str(data.get("LastOwner") or ""), getattr(self, "_locaux", set()))
        return self._mk(
            title=name,
            source_id=appid,
            install_dir=str(install_dir),
            launch_uri=f"steam://rungameid/{appid}",
            size_bytes=int(data.get("SizeOnDisk") or 0),
            last_updated=float(data.get("LastUpdated") or 0),
            store_url=f"https://store.steampowered.com/app/{appid}",
            update_pending=bool(flags and flags != 4),
            engine=detect_engine(install_dir),
            extra={"library": str(apps_dir.parent), "state_flags": flags,
                   "steam_appid": appid, **({PRETE: True} if famille else {})},
        )
