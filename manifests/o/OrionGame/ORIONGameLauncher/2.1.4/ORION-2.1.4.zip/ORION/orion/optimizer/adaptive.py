"""Profil adaptatif : ORION apprend de ce qu'il a mesure.

Une fois qu'une partie a ete mesuree, l'application ne raisonne plus sur des
estimations : elle sait combien d'images par seconde le jeu a reellement
delivre avec un profil donne, sur cette machine et sur cet ecran. Elle peut
donc proposer un ajustement chiffre, que l'utilisateur accepte ou non.

Les ajustements acceptes sont memorises par jeu et par profil, et viennent
surcharger les reglages calcules : le profil s'adapte au fil des parties.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..core.logging_setup import get
from ..core.models import Display, Game, HardwareInfo
from .profiles import PROFILES, QUALITY_NAMES

log = get("optimizer.adaptatif")

LABELS = {"esport": "Esport", "detente": "Detente", "photo": "Photorealiste",
          "recommande": "Recommande"}


@dataclass
class Proposal:
    """Un ajustement propose, avec son effet attendu."""
    profile: str
    reason: str
    changes: dict[str, Any] = field(default_factory=dict)
    expected: str = ""

    @property
    def summary(self) -> str:
        return f"{self.reason} {self.expected}".strip()


def _target_fps(display: Display | None) -> int:
    if display and display.native:
        return display.max_refresh_at_native or (
            display.current.refresh if display.current else 60)
    return 60


def _quality_label(value: int) -> str:
    return QUALITY_NAMES.get(max(0, min(3, value)), str(value))


def proposals(game: Game, by_profile: dict, hw: HardwareInfo,
              display: Display | None) -> list[Proposal]:
    """Ajustements pertinents d'apres les mesures relevees."""
    target = _target_fps(display)
    out: list[Proposal] = []

    for profile_id, run in by_profile.items():
        profile = PROFILES.get(profile_id)
        if profile is None:
            continue
        avg = float(run.get("fps_avg") or 0)
        low1 = float(run.get("fps_low_1") or 0)
        stutter = float(run.get("stutter") or 0)
        if avg <= 0:
            continue

        if profile_id == "recommande":
            # « Recommande » repart de cette mesure a la prochaine partie :
            # pas d'ajustement manuel a proposer, juste l'expliquer
            from .recommande import NOMS_NIVEAUX, cible_fps
            cible = cible_fps(game, target)
            niveau = NOMS_NIVEAUX.get(str(run.get("preset") or ""), "")
            if avg < cible * 0.97:
                out.append(Proposal(
                    profile_id,
                    f"Recommande tourne a {avg:.0f} i/s"
                    + (f" en {niveau}" if niveau else "")
                    + f" pour un objectif de {cible} i/s.",
                    {}, "Le reglage sera ajuste automatiquement a la prochaine "
                        "partie, d'apres cette mesure."))

        # 1. Tres en dessous de l'ecran : il faut alleger
        if profile_id == "recommande":
            pass
        elif avg < target * 0.62:
            changes: dict[str, Any] = {}
            if profile.quality > 0:
                changes["q_shadows"] = max(profile.quality - 1, 0)
                changes["q_effects"] = max(profile.quality - 1, 0)
            changes["upscaler_level"] = "balanced" if avg > target * 0.45 \
                else "performance"
            out.append(Proposal(
                profile_id,
                f"{LABELS.get(profile_id, profile_id)} tourne a "
                f"{avg:.0f} i/s pour un ecran a {target} Hz.",
                changes,
                "Baisser les ombres et les effets d'un cran et passer la "
                f"super-resolution en mode "
                f"{'equilibre' if avg > target * 0.45 else 'performance'} "
                "devrait rendre la fluidite."))

        # 2. Large marge : on peut embellir
        elif avg > target * 1.25 and profile.quality < 3:
            out.append(Proposal(
                profile_id,
                f"{LABELS.get(profile_id, profile_id)} depasse largement "
                f"l'ecran ({avg:.0f} i/s pour {target} Hz).",
                {"q_shadows": min(profile.quality + 1, 3),
                 "q_effects": min(profile.quality + 1, 3),
                 "q_reflections": min(profile.quality + 1, 3)},
                f"Monter les ombres, les effets et les reflets en "
                f"{_quality_label(profile.quality + 1)} ne devrait pas "
                "couter la fluidite."))

        # 3. Moyenne correcte mais a-coups
        if low1 and avg and low1 < avg * 0.55:
            reason = (f"Les creux sont marques sur {LABELS.get(profile_id, profile_id)} : "
                      f"{low1:.0f} i/s dans le 1 % le plus bas contre "
                      f"{avg:.0f} en moyenne.")
            if hw.gpu.vram_mb and hw.gpu.vram_mb < 12000:
                out.append(Proposal(
                    profile_id, reason,
                    {"q_textures": max(0, min(3, 2))},
                    "Reduire les textures d'un cran limite les a-coups lies "
                    "a la memoire video saturee."))
            elif hw.cpu_threads and hw.cpu_threads <= 8:
                out.append(Proposal(
                    profile_id, reason, {"q_view_distance": 2},
                    "Baisser la distance d'affichage soulage le processeur, "
                    "qui est la cause la plus probable ici."))
            else:
                out.append(Proposal(
                    profile_id, reason, {},
                    "Ce profil de creux vient souvent de la compilation des "
                    "shaders : les a-coups doivent disparaitre apres quelques "
                    "minutes de jeu."))

        if stutter > 4:
            out.append(Proposal(
                profile_id,
                f"{stutter:.1f} % des images ont mis plus du double du temps "
                "habituel a s'afficher.",
                {},
                "Verifiez qu'aucun enregistrement video ou navigateur lourd "
                "ne tourne pendant la partie."))

    return out


def suggest(game: Game, by_profile: dict, hw: HardwareInfo,
            display: Display | None) -> str:
    """Texte affiche sous le tableau des mesures."""
    if not by_profile:
        return ""
    items = proposals(game, by_profile, hw, display)
    if not items:
        target = _target_fps(display)
        best = max(by_profile.values(), key=lambda r: r.get("fps_avg", 0))
        return (f"Rien a corriger : {best.get('fps_avg', 0):.0f} i/s de "
                f"moyenne pour un ecran a {target} Hz, avec des creux "
                f"contenus a {best.get('fps_low_1', 0):.0f} i/s.")
    return "\n".join(f"• {p.summary}" for p in items[:3])


# --------------------------------------------------------------------------
# Memorisation des ajustements acceptes
# --------------------------------------------------------------------------

def stored_tuning(game: Game, profile_id: str) -> dict[str, Any]:
    return dict((game.extra.get("tuning") or {}).get(profile_id) or {})


def apply_tuning(game: Game, profile_id: str, changes: dict[str, Any]) -> None:
    """Enregistre un ajustement pour ce jeu et ce profil."""
    tuning = game.extra.setdefault("tuning", {})
    current = tuning.setdefault(profile_id, {})
    current.update(changes)
    log.info("Ajustement memorise pour %s / %s : %s", game.title, profile_id,
             changes)


def clear_tuning(game: Game, profile_id: str = "") -> None:
    if profile_id:
        (game.extra.get("tuning") or {}).pop(profile_id, None)
    else:
        game.extra.pop("tuning", None)
