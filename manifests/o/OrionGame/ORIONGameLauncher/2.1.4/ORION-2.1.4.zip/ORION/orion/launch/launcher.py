"""Lancement des jeux et suivi de la session.

Sequence : reglage de l'ecran -> ecriture des reglages (deja validee) ->
lancement -> surveillance du processus -> restauration de l'ecran et
enregistrement du temps de jeu.
"""
from __future__ import annotations

import os
import re
import subprocess
import threading
import time
from pathlib import Path

from ..core import lancement
from ..core.config import CONFIG
from ..core.events import BUS, DISPLAY_CHANGED, GAME_EXITED, GAME_LAUNCHED
from ..core.fichiers import est_dossier
from ..core.logging_setup import get
from ..core.models import Game, OptimizationPlan
from ..core.paths import is_windows
from ..core.winutil import iter_exes
from ..hardware.displays import apply_mode

log = get("launch")


#: drapeau Windows DETACHED_PROCESS : le jeu ne depend pas de la console d'ORION
DETACHED_PROCESS = 0x00000008

#: duree maximale de surveillance d'une partie : au-dela, la session est
#: consideree terminee (processus fige, horloge deregle...) et ORION reprend
#: ses taches au lieu de rester en retrait pour toujours
DUREE_MAX = 24 * 3600

#: intervalle de controle de la fin du jeu (et de la demande d'arret)
INTERVALLE_ATTENTE = 5
#: seul un lanceur ou un rapporteur de plantage tourne : temps laisse au jeu
#: pour apparaitre avant de se rabattre sur ce programme (secondes)
PATIENCE_LANCEUR = 30
#: le lanceur surveille s'est ferme : temps laisse au jeu pour prendre sa suite
RELAIS = 12
#: pause entre deux recherches du programme du jeu
PAUSE_RECHERCHE = 2
#: un programme du jeu qui se ferme avant ce delai etait un outil du lanceur,
#: ou le jeu qui se relance : la session cherche le programme qui prend sa
#: suite au lieu de se croire finie.
VIE_COURTE = 90


def _startfile(target: str, dossier: str | None = None) -> bool:
    """Ouvre une adresse (steam://...) ou un fichier par le shell, sans rien
    transmettre d'ORION (chemin des DLL, dossier courant, variables)."""
    try:
        if is_windows():
            lancement.startfile_propre(target, dossier)
            return True
        log.info("Simulation de lancement : %s", target)
        return True
    except Exception:
        log.exception("Lancement impossible : %s", target)
        return False


#: Windows refuse `CreateProcess` pour un executable dont le manifeste
#: reclame les droits administrateur. Seul le shell sait presenter la
#: demande d'elevation a l'utilisateur.
ELEVATION_REQUIRED = 740


def _run_elevated(exe: str, args: list[str], cwd: str) -> bool:
    """Relance par le shell, ce qui affiche la demande d'elevation Windows.

    C'est Windows qui demande l'autorisation, et l'utilisateur qui repond :
    ORION ne contourne rien, il cesse simplement d'echouer sur les jeux dont
    le lanceur reclame les droits administrateur (anticheat, pilote de
    peripherique, mise a jour integree).
    """
    if not is_windows():
        return False
    try:
        joined = subprocess.list2cmdline(args) if args else None
        result = lancement.shell_execute(exe, joined, cwd or None, verbe="runas")
        # ShellExecute renvoie une valeur <= 32 en cas d'echec ; 5 signifie
        # que l'utilisateur a refuse l'elevation.
        return int(result) > 32
    except Exception:
        log.exception("Elevation impossible")
        return False


def launch_target(game: Game) -> tuple[bool, str]:
    """Demarre le jeu par son URI de plateforme, sinon par son executable."""
    if game.launch_uri:
        if game.launch_uri.startswith("shell:"):
            try:
                lancement.popen_propre(["explorer.exe", game.launch_uri])
                return True, "Lance via le Microsoft Store"
            except Exception:
                log.exception("Lancement Store impossible")
        elif _startfile(game.launch_uri):
            return True, "Lance via la plateforme"

    exe = game.executable
    if exe and Path(exe).exists():
        cwd = game.working_dir or ""
        if not cwd or not Path(cwd).is_dir():
            cwd = str(Path(exe).parent)
        try:
            # dossier courant = dossier du jeu, jamais celui d'ORION
            lancement.popen_propre([exe, *game.launch_args], cwd=cwd,
                                   creationflags=DETACHED_PROCESS if is_windows() else 0)
            return True, "Lance directement"
        except OSError as exc:
            if getattr(exc, "winerror", 0) == ELEVATION_REQUIRED:
                log.info("%s reclame les droits administrateur", game.title)
                if _run_elevated(exe, list(game.launch_args), cwd):
                    return True, ("Lance avec les droits administrateur, "
                                  "demandes par le jeu")
                return False, ("Ce jeu reclame les droits administrateur et "
                               "l'autorisation n'a pas ete accordee.")
            log.exception("Lancement direct impossible")
            return False, f"Lancement impossible : {exc}"
        except Exception as exc:
            log.exception("Lancement direct impossible")
            return False, f"Lancement impossible : {exc}"

    if game.install_dir and est_dossier(game.install_dir):
        return False, "Executable introuvable : ouvrez la fiche du jeu pour le designer"
    return False, "Aucun moyen de lancer ce jeu n'a ete trouve"


def _normaliser(chemin: str) -> str:
    return os.path.normpath(chemin).lower() if chemin else ""


def _dossier_jeu(game: Game) -> str:
    """Dossier du jeu, termine par un separateur (« C:\\Jeux\\Foo\\ ») :
    « C:\\Jeux\\Foo » ne doit pas reconnaitre « C:\\Jeux\\Foobar ». Vide si
    le dossier est trop general pour designer un seul jeu (racine d'un
    disque)."""
    racine = game.install_dir or (str(Path(game.executable).parent)
                                  if game.executable else "")
    racine = _normaliser(racine)
    if not racine or len(Path(racine).parts) < 2:
        return ""
    return racine.rstrip("\\/") + os.sep


#: moteur Unreal : l'executable a la racine du jeu (« Aniimo.exe ») n'est
#: qu'une amorce. Elle lance le vrai programme, « <Projet>\Binaries\Win64\
#: <Projet>-Win64-Shipping.exe », puis reste ouverte derriere lui sans rien
#: afficher : une mesure prise sur l'amorce ne releve aucune image.
_RENDU_UNREAL = re.compile(r"-win(64|32|gdk)-(shipping|test|debug|development)\.exe$",
                           re.I)


def _programmes_de_rendu(game: Game) -> set[str]:
    """Noms (en minuscules) des executables de rendu Unreal installes dans le
    dossier du jeu. Vide pour les autres moteurs ; sinon, l'executable
    declare du jeu n'est qu'une amorce, a traiter comme un lanceur."""
    root = game.install_dir or ""
    if not root:
        return set()
    noms: set[str] = set()
    try:
        for exe in iter_exes(Path(root), max_depth=4):
            if _RENDU_UNREAL.search(exe.name):
                noms.add(exe.name.lower())
    except Exception:
        log.debug("Lecture des executables de %s impossible", root)
    return noms


def _correspond(info: dict, exe_name: str, root: str, depart: float) -> bool:
    """Ce processus est-il celui du jeu lance ?

    * par son chemin : il se trouve dans le dossier du jeu ;
    * par son nom : seulement s'il est dans le dossier du jeu, ou, si son
      chemin est illisible (jeu lance avec les droits administrateur), s'il
      a demarre apres le lancement. Un « launcher.exe » ou « game.exe »
      quelconque deja ouvert n'est jamais pris pour le jeu."""
    name = (info.get("name") or "").lower()
    path = _normaliser(info.get("exe") or "")
    dans_dossier = bool(root and path and path.startswith(root))
    if dans_dossier:
        return True
    if exe_name and name == exe_name:
        if path and root:
            return False             # chemin connu mais hors du dossier du jeu
        # chemin illisible, ou dossier du jeu inconnu : seulement un
        # processus apparu apres le lancement
        cree = info.get("create_time") or 0
        return bool(cree) and cree >= depart
    return False


def retenir_refus(stats, erreur: str) -> None:
    """Retient pour la page Reglages que Windows a refuse la mesure (droits) :
    sans cela, le joueur ne saurait jamais pourquoi rien n'est mesure. Une
    mesure reussie efface le refus."""
    try:
        from ..perf.presentmon import ACCES_REFUSE
        if stats:
            if CONFIG.get("perf.acces_refuse", False):
                CONFIG.set("perf.acces_refuse", False)
        elif erreur == ACCES_REFUSE:
            CONFIG.set("perf.acces_refuse", True)
    except Exception:
        log.debug("Etat de la mesure non retenu")


def fenetre_visible(pid: int) -> bool | None:
    """Vrai si le programme `pid` a une fenetre visible de taille non nulle
    (sa fenetre de jeu, pas une console cachee) ; `None` quand on ne peut
    pas le savoir (hors Windows, erreur)."""
    if not pid:
        return False
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
    except Exception:
        return None
    trouvee = False
    try:
        PROC = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)

        def visite(hwnd, _):
            nonlocal trouvee
            proprietaire = wintypes.DWORD()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(proprietaire))
            if int(proprietaire.value) != int(pid) or not user32.IsWindowVisible(hwnd):
                return True
            rect = wintypes.RECT()
            if user32.GetWindowRect(hwnd, ctypes.byref(rect)) and \
                    rect.right - rect.left > 100 and rect.bottom - rect.top > 100:
                trouvee = True
                return False
            return True
        user32.EnumWindows(PROC(visite), 0)
    except Exception:
        return None
    return trouvee


#: temps, en secondes, laisse au jeu pour montrer sa fenetre une fois son
#: programme vu, avant de considerer qu'il est bien lance quand meme
ATTENTE_FENETRE = 120
#: secondes entre deux regards sur ses fenetres
PAUSE_FENETRE = 0.5


class GameSession:
    """Surveille un jeu lance, mesure ses performances et remet l'ecran.

    `on_fenetre(game)` est appele (depuis le fil de surveillance) la premiere
    fois que le jeu lui-meme - pas son lanceur - montre une fenetre : ORION
    peut alors se retirer. 15 octobre 2026 (enregistrement de l'auteur) :
    ORION se reduisait 1,5 s apres le clic, et le bureau restait vide les
    40 s que Steam et Rocket League mettaient a demarrer."""

    def __init__(self, game: Game, plan: OptimizationPlan | None,
                 on_finished=None, on_measured=None, on_fenetre=None) -> None:
        self.game = game
        self.plan = plan
        self.on_finished = on_finished
        self.on_measured = on_measured
        self.on_fenetre = on_fenetre
        self._fenetre_annoncee = False
        self.started_at = 0.0
        self.seconds = 0
        self.capture = None
        self.stats: dict | None = None
        self._restore: tuple[str, object] | None = None
        self._thread: threading.Thread | None = None
        #: vrai une fois la surveillance finie, quelle qu'en soit la raison
        self.termine = False
        self.duree_max = DUREE_MAX
        self._mesure_sur = ""       # programme dont les images sont mesurees
        self._mesure_pid = 0        # et son numero de processus
        self._rendu: set[str] = set()   # executables de rendu Unreal du jeu
        self._arret = threading.Event()

    # ------------------------------------------------------------------
    def start(self) -> tuple[bool, str]:
        messages: list[str] = []

        if (self.plan and self.plan.display_mode and self.plan.display_device
                and CONFIG.get("optimizer.apply_display_mode", True)
                and self.plan.display_changes):
            ok, msg = apply_mode(self.plan.display_device, self.plan.display_mode)
            messages.append(f"Ecran : {msg}")
            if ok:
                BUS.emit(DISPLAY_CHANGED, device=self.plan.display_device,
                         mode=str(self.plan.display_mode))
                if CONFIG.get("optimizer.restore_display_after", True) \
                        and self.plan.display_current:
                    self._restore = (self.plan.display_device, self.plan.display_current)

        ok, msg = launch_target(self.game)
        messages.append(msg)
        if not ok:
            self._undo_display()
            self.termine = True
            return False, " - ".join(messages)

        self.started_at = time.time()
        BUS.emit(GAME_LAUNCHED, uid=self.game.uid, profile=
                 self.plan.profile if self.plan else "")
        self._thread = threading.Thread(target=self._watch, daemon=True)
        self._thread.start()
        return True, " - ".join(messages)

    # ------------------------------------------------------------------
    def _start_capture(self, process_name: str, pid: int = 0) -> None:
        """Lance la mesure des images par seconde, si elle est activee."""
        if not CONFIG.get("perf.enabled", False) or not process_name:
            return
        try:
            from ..perf.presentmon import Capture, installed_path
            if installed_path() is None:
                return
            capture = Capture(process_name, self.game.uid,
                              self.plan.profile if self.plan else "", pid=pid)
            if capture.start():
                self.capture = capture
        except Exception:
            log.debug("Mesure des performances indisponible")

    def _watch(self) -> None:
        """Attend la fin du jeu pour restaurer l'ecran et compter le temps.

        Quoi qu'il arrive (exception, delai depasse), la session finit
        marquee `termine` : sans cela ORION resterait « en partie » pour
        toujours (mode discret, mise a jour reportee indefiniment)."""
        try:
            try:
                self._attendre_fin()
            except Exception:
                log.exception("Surveillance de %s interrompue", self.game.title)
            self.seconds = max(1, int(time.time() - (self.started_at or time.time())))

            if self.capture is not None:
                try:
                    self.stats = self.capture.stop()
                except Exception:
                    log.debug("Arret de la mesure impossible")
                if not self.stats:
                    log.info("Mesure sans resultat sur %s : %s", self._mesure_sur or "?",
                             getattr(self.capture, "error", "") or "aucune image relevee")
                retenir_refus(self.stats, getattr(self.capture, "error", ""))
                if self.stats and self.on_measured:
                    try:
                        self.on_measured(self.game, self.stats)
                    except Exception:
                        log.exception("Rappel de mesure en echec")

            try:
                self._undo_display()
            except Exception:
                log.exception("Restauration de l'ecran impossible")
        finally:
            if not self.seconds:
                self.seconds = max(1, int(time.time() - (self.started_at or time.time())))
            self.termine = True
        try:
            BUS.emit(GAME_EXITED, uid=self.game.uid, seconds=self.seconds)
        except Exception:
            log.exception("Annonce de fin de partie impossible")
        if self.on_finished:
            try:
                self.on_finished(self.game, self.seconds)
            except Exception:
                log.exception("Rappel de fin de session en echec")

    def arreter(self) -> None:
        """Cesse de surveiller la partie (fermeture d'ORION)."""
        self._arret.set()

    def _attendre_fin(self) -> None:
        """Attend la fin de la partie, au plus `duree_max` secondes.

        Le premier programme vu dans le dossier du jeu n'est pas toujours le
        jeu : un lanceur (« REDprelauncher.exe ») ou un rapporteur de plantage
        s'ouvre souvent d'abord, puis passe la main. La session suit ce
        relais au lieu de se croire finie, et ne mesure que le jeu."""
        self._rendu = _programmes_de_rendu(self.game)
        proc = self._wait_for_process(timeout=150)
        if proc is None:
            # processus introuvable (jeu lance par un launcher tiers) :
            # on attend une duree raisonnable avant de rendre la main.
            self._arret.wait(60)
            return
        limite = time.monotonic() + self.duree_max
        while proc is not None:
            self._mesurer(proc)
            self._attendre_fenetre(proc)
            proc = self._suivre(proc, limite)

    def _attendre_fenetre(self, proc) -> None:
        """Previent (`on_fenetre`) des que le jeu lui-meme montre une
        fenetre ; un lanceur n'en est pas une. Une seule fois par partie."""
        if self._fenetre_annoncee or self.on_fenetre is None:
            return
        try:
            if self._rang(proc) >= 2:
                return
            pid = int(getattr(proc, "pid", 0) or 0)
        except Exception:
            return
        fin = time.monotonic() + ATTENTE_FENETRE
        while not self._arret.is_set() and time.monotonic() < fin:
            vue = fenetre_visible(pid)
            if vue or vue is None:
                break                      # fenetre la, ou impossible a savoir : on ne retient pas ORION
            try:
                if not proc.is_running():
                    return                 # ferme avant toute fenetre : le relais tranchera
            except Exception:
                return
            self._arret.wait(PAUSE_FENETRE)
        self._fenetre_annoncee = True
        try:
            self.on_fenetre(self.game)
        except Exception:
            log.exception("Rappel de fenetre en echec")

    def _rang(self, proc) -> int:
        """0 : l'executable declare du jeu (ou, sur Unreal, son programme de
        rendu) ; 1 : un autre programme de son dossier ; 2 : un lanceur, un
        rapporteur de plantage, un anti-triche, l'amorce d'un jeu Unreal."""
        from ..en_jeu import auxiliaire
        nom = (proc.info.get("name") or "").lower()
        if nom in self._rendu:
            return 0
        exe = Path(self.game.executable).name.lower() if self.game.executable else ""
        if exe and nom == exe:
            # un jeu Unreal a un programme de rendu : l'executable declare
            # n'est que l'amorce qui le lance, et n'affiche rien
            return 2 if self._rendu else 0
        return 2 if auxiliaire(nom) else 1

    def _processus_du_jeu(self, sauf: int = 0) -> list:
        """Programmes du jeu en cours, le plus probable d'abord (a rang egal,
        celui qui occupe le plus de memoire)."""
        try:
            import psutil
        except Exception:
            return []
        root = _dossier_jeu(self.game)
        exe_name = Path(self.game.executable).name.lower() if self.game.executable else ""
        depart = (self.started_at or time.time()) - 10
        trouves = []
        for p in psutil.process_iter(["name", "exe", "create_time"]):
            try:
                if p.pid != sauf and _correspond(p.info, exe_name, root, depart):
                    trouves.append(p)
            except Exception:
                continue

        def poids(p) -> tuple:
            try:
                memoire = p.memory_info().rss
            except Exception:
                memoire = 0
            return (self._rang(p), -memoire)
        return sorted(trouves, key=poids)

    def _meilleur(self, sauf: int = 0):
        """Le jeu lui-meme (jamais un lanceur), s'il tourne ; sinon None."""
        try:
            for p in self._processus_du_jeu(sauf):
                if self._rang(p) < 2:
                    return p
        except Exception:
            log.debug("Recherche du programme du jeu impossible")
        return None

    def _mesurer(self, proc) -> None:
        """Mesure les images par seconde du jeu. Un lanceur ne se mesure
        pas ; une mesure commencee sur un autre programme est jetee."""
        try:
            nom = proc.info.get("name") or ""
            pid = int(getattr(proc, "pid", 0) or 0)
            # meme programme ET meme processus : deja mesure. Un jeu qui se
            # relance sous le meme nom (Baldur's Gate 3, 10 octobre : la mesure
            # suivait le premier « bg3_dx11.exe », ferme aussitot) est mesure a
            # nouveau sur son nouveau processus.
            if self._rang(proc) >= 2 or (self._mesure_sur == nom.lower()
                                         and (not pid or pid == self._mesure_pid)):
                return
            if self.capture is not None:
                try:
                    self.capture.stop()
                except Exception:
                    log.debug("Arret de la mesure impossible")
                self.capture = None
            self._mesure_sur = nom.lower()
            self._mesure_pid = pid
            self._start_capture(nom, pid)
        except Exception:
            log.debug("Mesure des performances indisponible")

    def _suivre(self, proc, limite: float):
        """Attend la fin de `proc`. Rend le programme qui prend sa suite (un
        lanceur passe la main au jeu), ou None quand la partie est finie."""
        try:
            rang = self._rang(proc)
            lanceur = rang >= 2
            pid = int(getattr(proc, "pid", 0) or 0)
        except Exception:
            rang, lanceur, pid = 1, False, 0
        suivi_depuis = time.monotonic()
        while not self._arret.is_set() and time.monotonic() < limite:
            try:
                proc.wait(timeout=INTERVALLE_ATTENTE)
                break
            except Exception as exc:
                # psutil.TimeoutExpired : il tourne toujours ; toute autre
                # erreur (processus disparu, acces refuse) : il est ferme
                if type(exc).__name__ != "TimeoutExpired":
                    break
                if lanceur:
                    # surveille faute de mieux : le jeu est-il arrive depuis ?
                    jeu = self._meilleur(pid)
                    if jeu is not None:
                        return jeu
                elif self._rang(proc) == 1:
                    # un programme du dossier qui n'est pas l'executable du
                    # jeu (outil, navigateur d'un lanceur...) : des que le
                    # jeu lui-meme tourne, c'est lui qu'on mesure
                    jeu = self._meilleur(pid)
                    if jeu is not None and self._rang(jeu) == 0:
                        return jeu
        else:
            if not self._arret.is_set():
                log.warning("%s : surveillance arretee apres %d s", self.game.title,
                            self.duree_max)
            return None
        # vite referme : un outil du dossier, ou le jeu qui se relance (BG3)
        court = rang <= 1 and time.monotonic() - suivi_depuis < VIE_COURTE
        if not lanceur and not court:
            return None       # le jeu s'est ferme : un lanceur reste ouvert ne prolonge rien
        # un lanceur, ou un outil du dossier vite referme : le jeu prend-il la suite ?
        # le lanceur s'est ferme : il a peut-etre passe la main au jeu
        fin = time.monotonic() + RELAIS
        while not self._arret.is_set() and time.monotonic() < fin:
            jeu = self._meilleur(pid)
            if jeu is not None:
                return jeu
            self._arret.wait(min(1, PAUSE_RECHERCHE))
        return None

    def _wait_for_process(self, timeout: int = 150):
        """Le programme du jeu, des qu'il tourne. Un lanceur seul n'est rendu
        qu'apres `PATIENCE_LANCEUR` secondes sans rien de mieux."""
        try:
            import psutil  # noqa: F401
        except Exception:
            return None
        deadline = time.time() + timeout
        lanceur_vu = 0.0
        dernier = None
        while time.time() < deadline and not self._arret.is_set():
            candidats = self._processus_du_jeu()
            if candidats:
                dernier = candidats[0]
                if self._rang(dernier) < 2:
                    return dernier
                lanceur_vu = lanceur_vu or time.time()
                if time.time() - lanceur_vu >= PATIENCE_LANCEUR:
                    return dernier
            self._arret.wait(PAUSE_RECHERCHE)
        return dernier

    def _undo_display(self) -> None:
        if not self._restore:
            return
        device, mode = self._restore
        try:
            apply_mode(device, mode)            # type: ignore[arg-type]
            BUS.emit(DISPLAY_CHANGED, device=device, mode=str(mode))
        except Exception:
            log.exception("Restauration de l'ecran impossible")
        self._restore = None
