"""Vitrine de la Boutique : les jeux a la une et les suggestions « Pour vous ».

Tout est calcule sur le PC, sans compte ni envoi : a partir des jeux deja
possedes (bibliotheque et jeux non installes) et de ce qu'ORION sait deja
d'eux, en local :

* les genres, le studio et les modes de jeu releves sur leur fiche
  (`MarketInfo`, cache des prix) ;
* les etiquettes Steam, les studios et les series des fiches Steam
  detaillees (`boutique.MEMO`) ;
* les genres des offres de la Boutique quand le jeu y figure.

Chaque jeu possede devient un ensemble de *traits* (genre « rpg », studio
« dev:supergiantgames », serie « serie:hades »...), pese selon le temps
passe dessus, les favoris et les parties recentes. Le profil du joueur est
la somme de ces traits. Une fiche de la Boutique est notee par sa
ressemblance a ce profil (cosinus), les traits trop courants dans le
catalogue comptant moins (« Action » ne dit pas grand-chose, « Roguelike »
beaucoup plus). Un jeu deja possede n'est jamais propose.

`a_la_une()` choisit les grosses sorties du moment : notoriete (meilleures
ventes, nombre d'avis), prix de base d'un « gros » jeu, note des joueurs et
qualite de la promotion.
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass, field

from .core.recherche import cle_titre, mots_cle, normaliser

# ---------------------------------------------------------------------------
# Vocabulaire commun : genres Steam (francais), etiquettes, genres GOG
# ---------------------------------------------------------------------------
#: synonymes -> trait canonique (cles deja normalisees : minuscules, sans
#: accents ni separateurs)
SYNONYMES = {
    "jeuderole": "rpg", "roleplaying": "rpg", "rpg": "rpg", "jrpg": "jrpg",
    "rpgdaction": "rpgaction", "actionrpg": "rpgaction", "arpg": "rpgaction",
    "aventure": "aventure", "adventure": "aventure",
    "strategie": "strategie", "strategy": "strategie",
    "strategieentempsreel": "rts", "rts": "rts", "realtimestrategy": "rts",
    "tourpartour": "tourpartour", "turnbased": "tourpartour",
    "strategieautourpartour": "tourpartour", "turnbasedstrategy": "tourpartour",
    "simulation": "simulation", "sport": "sport", "sports": "sport",
    "course": "course", "racing": "course", "courseautomobile": "course",
    "independant": "inde", "indie": "inde",
    "massivementmultijoueur": "mmo", "mmo": "mmo", "mmorpg": "mmo",
    "occasionnel": "occasionnel", "casual": "occasionnel",
    "fps": "fps", "tirapremierepersonne": "fps", "firstpersonshooter": "fps",
    "jeudetir": "tir", "tir": "tir", "shooter": "tir", "shootemup": "shmup",
    "horreur": "horreur", "horror": "horreur", "survivalhorror": "horreur",
    "mondeouvert": "mondeouvert", "openworld": "mondeouvert",
    "survie": "survie", "survival": "survie",
    "plateforme": "plateforme", "plateformes": "plateforme",
    "platformer": "plateforme", "jeudeplateforme": "plateforme",
    "reflexion": "reflexion", "puzzle": "reflexion",
    "roguelike": "roguelike", "roguelite": "roguelike", "roguelikedaction": "roguelike",
    "soulslike": "soulslike", "metroidvania": "metroidvania",
    "gestion": "gestion", "management": "gestion",
    "construction": "construction", "building": "construction",
    "combat": "combat", "fighting": "combat", "jeudecombat": "combat",
    "sciencefiction": "sf", "scifi": "sf", "fantastique": "fantasy",
    "fantasy": "fantasy", "bacasable": "bacasable", "sandbox": "bacasable",
    "richeenhistoire": "narratif", "storyrich": "narratif", "narration": "narratif",
    "multijoueur": "multi", "multiplayer": "multi",
    "cooperation": "coop", "coop": "coop", "cooperatif": "coop",
    "cooperationenligne": "coop", "onlinecoop": "coop",
    "action": "action", "furtivite": "furtivite", "stealth": "furtivite",
    "hackandslash": "hackslash", "beatemup": "beatemup",
    "cartes": "cartes", "jeudecartes": "cartes", "cardgame": "cartes",
    "deckbuilding": "deckbuilding", "constructiondedeck": "deckbuilding",
    "tactique": "tactique", "tactical": "tactique",
    "postapocalyptique": "postapo", "postapocalyptic": "postapo",
    "cyberpunk": "cyberpunk", "zombies": "zombies", "medieval": "medieval",
    "historique": "historique", "historical": "historique",
    "4x": "4x", "grandestrategie": "grandestrategie", "grandstrategy": "grandestrategie",
    "colonie": "colonie", "colonysim": "colonie", "craft": "craft", "crafting": "craft",
    "pvp": "pvp", "battleroyale": "battleroyale", "moba": "moba",
}

#: categories Steam (identifiants) -> mode de jeu
CATEGORIES = {1: "multi", 36: "multi", 49: "pvp", 20: "mmo",
              9: "coop", 38: "coop", 39: "coop", 24: "coop", 48: "coop"}

#: traits trop vagues pour fonder une suggestion
VAGUES = {"solo", "singleplayer", "gratuit", "freetoplay", "accesanticipe",
          "earlyaccess", "manette", "controller", "graphismes", "2d", "3d",
          "bonnebandeson", "greatsoundtrack", "atmospherique", "atmospheric",
          "premierepersonne", "troisiemepersonne", "firstperson", "thirdperson",
          "colore", "colorful", "mignon", "cute", "difficile", "difficult",
          "classique", "classic", "famille", "familyfriendly", "detente",
          "relaxing", "fun", "drole", "funny", "realiste", "realistic"}

#: poids des familles de traits
POIDS = {"g": 1.0, "dev": 1.7, "edit": 0.5, "serie": 2.6, "mode": 0.45}

_MOTS_VIDES = {"the", "a", "an", "of", "and", "le", "la", "les", "l", "de",
               "du", "des", "et", "un", "une"}


def canon(nom: str) -> str:
    """Trait canonique d'un genre ou d'une etiquette (« Jeu de role » -> rpg)."""
    k = normaliser(nom or "")
    return SYNONYMES.get(k, k)


def cle_serie(titre: str) -> str:
    """Serie d'un jeu deduite du titre : deux premiers mots significatifs.

    « Far Cry 5 » et « Far Cry 6 » -> farcry ; « Call of Duty » -> callduty
    (et non « call of », que partagerait « Call of Cthulhu »)."""
    mots = [m for m in mots_cle((titre or "").split(":")[0].split(" - ")[0])
            if m not in _MOTS_VIDES and not m.isdigit()]
    return "".join(mots[:2])


# ---------------------------------------------------------------------------
# Traits d'un jeu
# ---------------------------------------------------------------------------
def _ajouter(traits: dict[str, float], libelles: dict[str, str], cle: str,
             poids: float, libelle: str = "") -> None:
    if not cle or cle.split(":", 1)[-1] in VAGUES or cle.split(":", 1)[-1] == "":
        return
    if poids > traits.get(cle, 0.0):
        traits[cle] = poids
    if libelle and cle not in libelles:
        libelles[cle] = libelle


def traits(genres=(), etiquettes=(), studios=(), editeurs=(), series=(),
           categories=(), titre: str = "",
           libelles: dict[str, str] | None = None) -> dict[str, float]:
    """{trait: poids} d'un jeu. `libelles` recoit le nom lisible des genres."""
    out: dict[str, float] = {}
    lib = libelles if libelles is not None else {}
    for g in genres or ():
        _ajouter(out, lib, "g:" + canon(g), POIDS["g"], str(g).strip())
    # etiquettes Steam, les plus votees d'abord : le poids decroit avec le rang
    for i, e in enumerate(list(etiquettes or ())[:12]):
        _ajouter(out, lib, "g:" + canon(e), POIDS["g"] * max(0.45, 1.0 - i * 0.06),
                 str(e).strip())
    devs = {normaliser(d) for d in studios or () if d}
    for d in devs:
        _ajouter(out, lib, "dev:" + d, POIDS["dev"])
    for e in editeurs or ():
        k = normaliser(e)
        if k and k not in devs:
            _ajouter(out, lib, "edit:" + k, POIDS["edit"])
    for s in series or ():
        _ajouter(out, lib, "serie:" + normaliser(s), POIDS["serie"])
    serie = cle_serie(titre)
    if serie and len(serie) >= 4:
        _ajouter(out, lib, "serie:" + serie, POIDS["serie"])
    for c in categories or ():
        try:
            mode = CATEGORIES.get(int(c))
        except (TypeError, ValueError):
            mode = None
        if mode:
            _ajouter(out, lib, "mode:" + mode, POIDS["mode"])
    return out


#: traits deja calcules : {(titre, genres, etiquettes, studios...): (traits, libelles)}
_TRAITS: dict[tuple, tuple[dict, dict]] = {}


def traits_fiche(fiche, libelles: dict[str, str] | None = None) -> dict[str, float]:
    """Traits d'une fiche de la Boutique. Gardes en memoire : ils ne dependent
    que du titre, des genres et de la fiche Steam, qui ne changent pas d'une
    actualisation des prix a l'autre (les recalculer pour tout le catalogue
    prenait 0,2 s du fil d'affichage a chaque actualisation). Le dictionnaire
    rendu est partage : ne pas le modifier."""
    d = fiche.details or {}
    cle = (fiche.titre, tuple(fiche.genres or ()), tuple((d.get("tags") or ())[:12]),
           tuple(d.get("devs") or ()), tuple(d.get("editeurs") or ()),
           tuple(d.get("series") or ()))
    garde = _TRAITS.get(cle)
    if garde is None:
        noms: dict[str, str] = {}
        calcul = traits(genres=cle[1], etiquettes=cle[2], studios=cle[3], editeurs=cle[4],
                        series=cle[5], titre=fiche.titre, libelles=noms)
        if len(_TRAITS) > 30000:
            _TRAITS.clear()
        garde = _TRAITS[cle] = (calcul, noms)
    if libelles is not None:
        for k, v in garde[1].items():
            libelles.setdefault(k, v)
    return garde[0]


def appid_steam(jeu) -> str:
    if getattr(jeu, "source", "") == "steam" and str(jeu.source_id).isdigit():
        return str(jeu.source_id)
    a = str((getattr(jeu, "extra", None) or {}).get("steam_appid") or "")
    return a if a.isdigit() else ""


def traits_jeu(jeu, info=None, details: dict | None = None,
               fiche=None) -> dict[str, float]:
    """Traits d'un jeu possede, avec tout ce qui est connu localement."""
    d = details or {}
    genres = list(getattr(info, "genres", None) or [])
    if fiche is not None:
        genres += list(fiche.genres or [])
    studios = [s.strip() for s in (getattr(info, "developer", "") or "").split(",")]
    editeurs = [s.strip() for s in (getattr(info, "publisher", "") or "").split(",")]
    return traits(genres=genres, etiquettes=d.get("tags") or (),
                  studios=[s for s in studios + list(d.get("devs") or []) if s],
                  editeurs=[s for s in editeurs + list(d.get("editeurs") or []) if s],
                  series=d.get("series") or (),
                  categories=getattr(info, "categories", None) or (),
                  titre=jeu.title)


def poids_jeu(jeu, maintenant: float | None = None) -> float:
    """Importance d'un jeu possede dans le profil."""
    maintenant = maintenant or time.time()
    heures = max(0, int(getattr(jeu, "total_play_seconds", 0) or 0)) / 3600
    p = 1.0 + 0.8 * min(3.5, math.log1p(heures))
    if getattr(jeu, "favorite", False):
        p += 1.0
    dernier = float(getattr(jeu, "last_played", 0) or 0)
    if dernier and maintenant - dernier < 30 * 86400:
        p += 0.8
    if getattr(jeu, "hidden", False):
        p *= 0.3
    elif (getattr(jeu, "extra", None) or {}).get("non_installe") and heures <= 0:
        p *= 0.6
    return p


# ---------------------------------------------------------------------------
# Jeux possedes
# ---------------------------------------------------------------------------
@dataclass
class Possedes:
    """Ce qui permet de reconnaitre un jeu deja possede."""
    appids: set[str] = field(default_factory=set)
    titres: set[str] = field(default_factory=set)

    @classmethod
    def depuis(cls, jeux) -> "Possedes":
        p = cls()
        for j in jeux or []:
            a = appid_steam(j)
            if a:
                p.appids.add(a)
            k = cle_titre(j.title)
            if k:
                p.titres.add(k)
        return p

    def contient(self, fiche) -> bool:
        if fiche.steam_appid and fiche.steam_appid in self.appids:
            return True
        k = cle_titre(fiche.titre)
        return bool(k and k in self.titres)

    def __bool__(self) -> bool:
        return bool(self.appids or self.titres)


# ---------------------------------------------------------------------------
# Profil et suggestions
# ---------------------------------------------------------------------------
@dataclass
class Profil:
    #: trait -> poids cumule
    poids: dict[str, float] = field(default_factory=dict)
    #: trait -> {titre du jeu possede: part de ce jeu}
    origines: dict[str, dict[str, float]] = field(default_factory=dict)
    #: titre -> le jeu a-t-il deja ete lance
    joues: dict[str, bool] = field(default_factory=dict)
    nb_jeux: int = 0

    def __bool__(self) -> bool:
        return bool(self.poids)


def profil(jeux, infos: dict | None = None, details: dict | None = None,
           fiches=None) -> Profil:
    """Profil de gouts a partir des jeux possedes.

    `infos` : {uid: MarketInfo} ; `details` : {appid: fiche Steam detaillee} ;
    `fiches` : catalogue de la Boutique (un jeu possede qui y figure apporte
    ses genres)."""
    infos, details = infos or {}, details or {}
    par_appid, par_titre = {}, {}
    for f in fiches or []:
        if f.steam_appid:
            par_appid.setdefault(f.steam_appid, f)
        par_titre.setdefault(cle_titre(f.titre), f)
    p = Profil()
    maintenant = time.time()
    for j in jeux or []:
        a = appid_steam(j)
        fiche = par_appid.get(a) if a else None
        fiche = fiche or par_titre.get(cle_titre(j.title))
        t = traits_jeu(j, infos.get(j.uid), details.get(a) if a else None, fiche)
        if not t:
            continue
        w = poids_jeu(j, maintenant)
        p.nb_jeux += 1
        p.joues[j.title] = bool(getattr(j, "total_play_seconds", 0))
        for k, v in t.items():
            p.poids[k] = p.poids.get(k, 0.0) + w * v
            p.origines.setdefault(k, {})[j.title] = \
                p.origines.get(k, {}).get(j.title, 0.0) + w * v
    return p


@dataclass
class Suggestion:
    fiche: object
    score: float
    raison: str
    jeu: str = ""                       # jeu possede a l'origine
    communs: list[str] = field(default_factory=list)   # genres partages


def _rarete(fiches, traits_par_fiche) -> dict[str, float]:
    """Poids inverse de la frequence d'un trait dans le catalogue."""
    n = max(1, len(fiches))
    df: dict[str, int] = {}
    for t in traits_par_fiche:
        for k in t:
            df[k] = df.get(k, 0) + 1
    return {k: math.log((n + 1) / (v + 1)) + 0.6 for k, v in df.items()}


def _qualite(fiche) -> float:
    note = fiche.note or 0
    return (note / 100) if note else 0.7


def suggerer(fiches, prof: Profil, possedes: Possedes | None = None,
             limite: int = 14, exclus: set[str] | None = None) -> list[Suggestion]:
    """Les fiches les plus proches des gouts du joueur, expliquees.

    Ne propose jamais un jeu possede ; `exclus` ecarte des cles de fiche
    (jeux deja a la une...)."""
    if not prof:
        return []
    possedes = possedes or Possedes()
    exclus = exclus or set()
    candidates = [f for f in fiches if f.meilleure and not possedes.contient(f)
                  and f.cle not in exclus]
    if not candidates:
        return []
    libelles: dict[str, str] = {}
    tf = [traits_fiche(f, libelles) for f in candidates]
    rare = _rarete(candidates, tf)
    profil_vec = {k: v * rare.get(k, 1.0) for k, v in prof.poids.items()}
    norme_p = math.sqrt(sum(v * v for v in profil_vec.values())) or 1.0

    notees: list[Suggestion] = []
    for f, t in zip(candidates, tf):
        if not t:
            continue
        vec = {k: v * rare.get(k, 1.0) for k, v in t.items()}
        communs = [k for k in vec if k in profil_vec]
        if not communs:
            continue
        produit = sum(vec[k] * profil_vec[k] for k in communs)
        norme_f = math.sqrt(sum(v * v for v in vec.values())) or 1.0
        cos = produit / (norme_f * norme_p)
        if cos < 0.05:
            continue
        score = cos * (0.75 + 0.25 * _qualite(f)) + 0.04 * (f.remise / 100)

        # le jeu possede qui explique le mieux la suggestion
        part: dict[str, float] = {}
        for k in communs:
            for titre, w in (prof.origines.get(k) or {}).items():
                part[titre] = part.get(titre, 0.0) + vec[k] * w * rare.get(k, 1.0)
        jeu = max(part, key=part.get) if part else ""
        notees.append(Suggestion(f, score, _raison(jeu, communs, prof, f),
                                 jeu, [libelles[k] for k in sorted(
                                     communs, key=lambda k: -vec[k] * profil_vec[k])
                                     if k.startswith("g:") and k in libelles][:2]))

    # variete : chaque nouvelle suggestion due au meme jeu pese un peu moins
    notees.sort(key=lambda s: -s.score)
    choisies: list[Suggestion] = []
    deja: dict[str, int] = {}
    restantes = notees
    while restantes and len(choisies) < limite:
        meilleure = max(restantes, key=lambda s: s.score * (0.72 ** deja.get(s.jeu, 0)))
        choisies.append(meilleure)
        deja[meilleure.jeu] = deja.get(meilleure.jeu, 0) + 1
        restantes = [s for s in restantes if s is not meilleure]
    return choisies


def _raison(jeu: str, communs, prof: Profil, fiche) -> str:
    if not jeu:
        return "Proche de vos jeux"
    origines = {k for k in communs if jeu in (prof.origines.get(k) or {})}
    if any(k.startswith("serie:") for k in origines):
        return f"Dans la lignee de {jeu}"
    if any(k.startswith("dev:") for k in origines):
        # court : la carte n'a qu'une ligne (le studio est sur la fiche)
        return f"Du studio de {jeu}"
    if prof.joues.get(jeu):
        return f"Parce que vous jouez a {jeu}"
    return f"Parce que vous avez {jeu}"


# ---------------------------------------------------------------------------
# A la une et rangees thematiques
# ---------------------------------------------------------------------------
def notoriete(fiche) -> float:
    """0..1 : meilleures ventes du moment et nombre d'avis Steam."""
    avis = min(1.0, math.log10(fiche.avis + 1) / 5.5) if fiche.avis else 0.0
    return max(avis, fiche.populaire / 100)


def score_une(fiche) -> float:
    gros = min(fiche.prix_normal or 0.0, 70.0) / 70.0
    return (0.36 * notoriete(fiche) + 0.24 * gros + 0.2 * _qualite(fiche)
            + 0.2 * (fiche.remise / 100) + (0.05 if fiche.au_plus_bas else 0.0))


def a_la_une(fiches, possedes: Possedes | None = None, limite: int = 6) -> list:
    """Les gros jeux du moment : connus, chers d'ordinaire, bien notes, en promo."""
    possedes = possedes or Possedes()
    candidats = [f for f in fiches if f.meilleure and not f.gratuit
                 and not possedes.contient(f) and f.visuels("une")]
    candidats.sort(key=lambda f: -score_une(f))
    vus, out = set(), []
    for f in candidats:
        serie = cle_serie(f.titre) or f.cle
        if serie in vus:            # pas deux episodes de la meme serie
            continue
        vus.add(serie)
        out.append(f)
        if len(out) >= limite:
            break
    return out


def grosses_promos(fiches, limite: int = 18) -> list:
    """Remises d'au moins 50 %, les jeux les plus connus d'abord."""
    choix = [f for f in fiches if f.meilleure and not f.gratuit and f.remise >= 50]
    return sorted(choix, key=lambda f: -(f.remise / 100 + 0.8 * notoriete(f)
                                         + 0.3 * _qualite(f)))[:limite]


def promo_partenaire(fiche, source: str = "gamesplanet", mini: int = 20) -> bool:
    """Vrai quand la meilleure offre sure du jeu est chez ce distributeur
    partenaire, avec au moins `mini` % de remise : on ne met en avant le
    partenaire que la ou il est vraiment le moins cher."""
    m = fiche.meilleure
    return bool(m and m.source == source and not m.gratuit and fiche.remise >= mini)


def promos_partenaire(fiches, source: str = "gamesplanet", limite: int = 18,
                      mini: int = 20) -> list:
    """Les promos du partenaire, grosses remises et jeux connus d'abord."""
    choix = [f for f in fiches if promo_partenaire(f, source, mini)]
    return sorted(choix, key=lambda f: -(f.remise / 100 + 0.8 * notoriete(f)
                                         + 0.3 * _qualite(f)))[:limite]


def plus_bas(fiches, limite: int = 18) -> list:
    """Au plus bas prix jamais releve."""
    choix = [f for f in fiches if f.meilleure and f.au_plus_bas]
    return sorted(choix, key=lambda f: -(notoriete(f) + 0.5 * _qualite(f)
                                         + 0.3 * f.remise / 100))[:limite]
