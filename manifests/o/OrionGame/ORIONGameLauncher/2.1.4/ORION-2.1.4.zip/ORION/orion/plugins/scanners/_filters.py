"""Filtrage des entrees qui ne sont pas des jeux.

Les plateformes exposent aussi leurs propres lanceurs, leurs runtimes et des
utilitaires : sans ce filtre, ils se retrouvent dans la bibliotheque.
Le filtre est centralise ici pour pouvoir etre etendu d'un seul endroit.
"""
from __future__ import annotations

import re

#: Titres qui ne sont jamais des jeux (comparaison insensible a la casse).
NOT_A_GAME = re.compile(
    r"^("
    r"steam(vr| linux runtime.*| client.*)?|"
    r"epic games launcher|epic online services|"
    r"ubisoft (connect|game launcher)|uplay|"
    r"rockstar games launcher|social club|"
    r"ea (app|desktop)|origin|"
    r"battle\.net|blizzard( battle\.net)? app|"
    r"gog galaxy|"
    r"xbox( game bar| identity provider| gaming services)?|gaming services|"
    r"microsoft (visual c\+\+|xna|\.net).*|"
    r"oculus.*|meta (quest|horizon).*|virtual desktop streamer|sidequest|"
    r"windows mixed reality.*|vive(port| console).*|"
    r"steam(works)? common redistributables|"
    r"directx.*|vulkan.*|physx.*|"
    r"nvidia .*|amd software.*|intel .*|"
    r"riva ?tuner.*|msi afterburner|"
    r"proton.*|steam runtime.*|"
    r"unreal engine.*|unreal editor.*|quixel bridge|twinmotion|realitycapture|"
    r"epic web ?helper|easy ?anti-?cheat.*|battleye.*|"
    r"wallpaper engine helper|geforce experience|nvidia app|"
    # signalement n° 4 (7 octobre) : « Opera Stable 136.0.6008.52 » pris pour
    # un jeu, son processus toujours ouvert tenait ORION en retrait
    r"(opera|opera gx|brave|vivaldi|google chrome|chromium|mozilla firefox|firefox|"
    r"microsoft edge|tor browser)( (stable|beta|developer|canary|nightly))?( [0-9][0-9.]*)?|"
    r"discord|discord ptb|discord canary|spotify|telegram desktop|whatsapp|signal|"
    r"skype|zoom|slack|microsoft teams|obs studio|vlc media player|7-zip|winrar|"
    r"notepad\+\+|visual studio code|overwolf|medal|streamlabs.*|nvidia broadcast"
    r")$", re.I)

#: Navigateurs et logiciels courants, avec leur canal, leur architecture et
#: leur version (« Opera Stable 136.0.6008.52 », « Mozilla Firefox (x64 fr) »).
#: Le nom seul ne suffit pas : « Opera Omnia » est un jeu.
NOT_A_GAME_START = re.compile(
    r"^(opera( gx)?( stable| beta| developer| one)?|brave( browser)?|vivaldi|google chrome|"
    r"chromium|mozilla firefox|microsoft edge|discord( ptb| canary)?|spotify|"
    r"telegram( desktop)?|whatsapp|obs studio|vlc( media player)?|overwolf|microsoft teams|"
    r"adobe [a-z ]+|autodesk [a-z0-9 ]+|jetbrains [a-z ]+|visual studio( code| community)?)"
    r"( \([^)]*\))?( [0-9][0-9.]*)?( \([^)]*\))?$", re.I)

#: Mots qui, seuls dans un titre, trahissent un outil plutot qu'un jeu.
TOOL_HINT = re.compile(
    r"(launcher|redistributable|runtime|anti-?cheat|dedicated server|"
    r"server tool|sdk|benchmark tool|crash handler)$", re.I)


def is_game(title: str) -> bool:
    """Faux pour un lanceur, un runtime ou un utilitaire."""
    t = (title or "").strip()
    if not t:
        return False
    if NOT_A_GAME.match(t) or NOT_A_GAME_START.match(t):
        return False
    if TOOL_HINT.search(t):
        return False
    return True
