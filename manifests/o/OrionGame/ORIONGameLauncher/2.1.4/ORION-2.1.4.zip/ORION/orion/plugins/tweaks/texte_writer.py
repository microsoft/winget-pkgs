"""Fichiers texte « cle valeur » sans sections (2.1.0).

Une ligne par reglage, avec un separateur propre au jeu : « maxFps:120 »
(Minecraft, options.txt), « GstRender.ResolutionWidth 1920 » (Frostbite,
PROFSAVE_profile), « Key = Value » (fichiers maison). Le separateur et les
guillemets sont ceux de la ligne existante : ORION ne reecrit que la
valeur. Une cle absente n'est JAMAIS creee (regle de l'auteur, 7 octobre :
jamais une cle inventee) : elle est dite absente, le plan la saute.
"""
from __future__ import annotations

import os
import re
from pathlib import Path

from ...core.logging_setup import get
from ...core.models import TweakOp
from .base import TweakWriter
from .ini_writer import lire_texte

log = get("tweaks.texte")


def _motif(cle: str) -> re.Pattern:
    # debut de ligne, cle (eventuellement entre guillemets), separateur
    # « : », « = » ou espaces, valeur (eventuellement entre guillemets)
    return re.compile(r'^(?P<avant>[ \t]*"?' + re.escape(cle) + r'"?[ \t]*(?:[:=]|[ \t])[ \t]*)'
                      r'(?P<q>"?)(?P<valeur>[^"\r\n]*)(?P=q)[ \t]*\r?$', re.M)


def lire_valeur(texte: str, cle: str) -> str | None:
    trouves = list(_motif(cle).finditer(texte or ""))
    return trouves[-1].group("valeur").strip() if trouves else None


def modifier(texte: str, valeurs: list[tuple[str, str]]) -> tuple[str, list[str]]:
    """Remplace la valeur des cles presentes ; rend (texte, cles absentes)."""
    absentes: list[str] = []
    for cle, valeur in valeurs:
        m = list(_motif(cle).finditer(texte))
        if not m:
            absentes.append(cle)
            continue
        dernier = m[-1]                       # c'est la derniere definition qui compte
        texte = texte[:dernier.start("valeur")] + str(valeur) + texte[dernier.end("valeur"):]
    return texte, absentes


class TexteWriter(TweakWriter):
    id = "texte"
    label = "Fichier texte cle-valeur"

    def read(self, op: TweakOp) -> str | None:
        texte, _enc, _eol = lire_texte(Path(op.target))
        return lire_valeur(texte, op.key) if texte else None

    def write(self, ops: list[TweakOp]) -> tuple[int, str]:
        by_file: dict[str, list[TweakOp]] = {}
        for op in ops:
            by_file.setdefault(op.target, []).append(op)
        written, erreurs = 0, []
        for target, items in by_file.items():
            path = Path(target)
            if not path.exists():
                erreurs.append(f"{path.name} introuvable : rien n'est cree a sa place.")
                continue
            if not os.access(path, os.W_OK):
                erreurs.append(f"{path.name} est en lecture seule : ORION ne le force pas.")
                continue
            try:
                texte, enc, eol = lire_texte(path)
                nouveau, absentes = modifier(texte, [(o.key, str(o.value)) for o in items])
                if absentes:
                    log.info("%s : cle(s) absente(s), non creee(s) : %s", path.name, absentes)
                if nouveau != texte:
                    provisoire = path.with_name(path.name + ".orion.tmp")
                    provisoire.write_bytes(nouveau.encode(enc))
                    os.replace(provisoire, path)
                written += len(items) - len(absentes)
            except Exception as exc:
                log.exception("Ecriture texte impossible : %s", path)
                erreurs.append(f"Ecriture impossible dans {path.name} : {exc}")
        return written, (" ; ".join(erreurs) if erreurs else "Reglages ecrits")
