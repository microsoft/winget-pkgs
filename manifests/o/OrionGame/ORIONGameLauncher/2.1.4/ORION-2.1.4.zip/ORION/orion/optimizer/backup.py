"""Sauvegarde et restauration avant toute modification.

Regle absolue d'ORION : rien n'est ecrit sans qu'une copie de l'original
existe et soit restaurable en un clic.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import time
from pathlib import Path

from ..core.logging_setup import get
from ..core.models import Game, TweakOp
from ..core.paths import BACKUP_DIR, ensure_dirs, is_windows

log = get("optimizer.sauvegarde")


def _slot(game: Game) -> Path:
    ensure_dirs()
    stamp = time.strftime("%Y-%m-%d_%H-%M-%S")
    safe = "".join(c for c in game.title if c.isalnum() or c in " -_")[:50].strip()
    d = BACKUP_DIR / f"{safe or game.uid}" / stamp
    # deux ecritures dans la meme seconde (un clic sur deux cartes) ne doivent
    # pas partager un dossier : la premiere sauvegarde, celle de l'etat
    # d'origine, serait ecrasee
    n = 1
    while d.exists():
        n += 1
        d = BACKUP_DIR / f"{safe or game.uid}" / f"{stamp}-{n}"
    d.mkdir(parents=True, exist_ok=True)
    return d


def create(game: Game, ops: list[TweakOp]) -> str:
    """Copie les fichiers et exporte les cles de registre concernes."""
    files = sorted({op.target for op in ops if op.kind in ("ini", "cfg", "json")})
    regkeys = sorted({op.target for op in ops if op.kind == "registry"})
    if not files and not regkeys:
        return ""

    slot = _slot(game)
    manifest = {"game": game.title, "uid": game.uid, "at": time.time(),
                "files": [], "registry": []}

    for i, f in enumerate(files):
        src = Path(f)
        if not src.exists():
            continue
        dest = slot / f"{i:02d}_{src.name}"
        try:
            shutil.copy2(src, dest)
            manifest["files"].append({"original": str(src), "copy": dest.name})
        except Exception:
            log.exception("Sauvegarde impossible : %s", src)

    for i, k in enumerate(regkeys):
        if not is_windows():
            continue
        dest = slot / f"reg_{i:02d}.reg"
        key = k.replace("/", "\\")
        key = key.replace("HKCU\\", "HKEY_CURRENT_USER\\").replace(
            "HKLM\\", "HKEY_LOCAL_MACHINE\\")
        try:
            subprocess.run(["reg", "export", key, str(dest), "/y"],
                           capture_output=True, timeout=15,
                           creationflags=0x08000000)
            if dest.exists():
                manifest["registry"].append({"key": key, "copy": dest.name})
        except Exception:
            log.debug("Export registre impossible : %s", key)

    try:
        (slot / "manifest.json").write_text(
            json.dumps(manifest, indent=2, ensure_ascii=False), "utf-8")
    except Exception:
        pass
    log.info("Sauvegarde creee : %s", slot)
    return str(slot)


def list_backups(game: Game | None = None) -> list[dict]:
    ensure_dirs()
    out: list[dict] = []
    for folder in BACKUP_DIR.glob("*/*"):
        man = folder / "manifest.json"
        if not man.exists():
            continue
        try:
            data = json.loads(man.read_text("utf-8"))
        except Exception:
            continue
        if game and data.get("uid") != game.uid:
            continue
        data["path"] = str(folder)
        out.append(data)
    out.sort(key=lambda d: d.get("at", 0), reverse=True)
    return out


def restore(slot_path: str) -> tuple[bool, str]:
    """Remet les fichiers et cles d'une sauvegarde."""
    slot = Path(slot_path)
    man = slot / "manifest.json"
    if not man.exists():
        return False, "Sauvegarde introuvable"
    try:
        data = json.loads(man.read_text("utf-8"))
    except Exception:
        return False, "Sauvegarde illisible"

    restored = 0
    for f in data.get("files", []):
        src, dest = slot / f["copy"], Path(f["original"])
        try:
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dest)
            restored += 1
        except Exception:
            log.exception("Restauration impossible : %s", dest)

    for r in data.get("registry", []):
        if not is_windows():
            continue
        try:
            subprocess.run(["reg", "import", str(slot / r["copy"])],
                           capture_output=True, timeout=15,
                           creationflags=0x08000000)
            restored += 1
        except Exception:
            log.debug("Import registre impossible")

    return restored > 0, f"{restored} element(s) restaure(s)"
