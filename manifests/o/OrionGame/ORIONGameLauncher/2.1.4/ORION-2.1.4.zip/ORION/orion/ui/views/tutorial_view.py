"""Page « Tuto » : tout le fonctionnement d'ORION, cherchable.

Le contenu ne vit pas ici : il est dans `orion/aide.py`, partage avec le
site web. Cette page ne fait que le presenter — rubriques a gauche,
articles a droite, et un champ de recherche qui filtre les deux.

La recherche est le point d'entree principal : on arrive ici avec une
question (« comment j'obtiens une cle Gemini ? »), pas avec l'envie de lire
un sommaire.
"""
from __future__ import annotations

import webbrowser

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtWidgets import (QFrame, QGridLayout, QHBoxLayout, QLabel,
                               QLineEdit, QPushButton, QVBoxLayout,
                               QWidget)

from ...aide import FAQ, RUBRIQUES, faq_matching, search
from ..theme import PALETTE
from ..widgets.layouts import clear_layout
from ..defilement import ZoneDefilante


def _titre(texte: str, objet: str = "PanelTitle") -> QLabel:
    lab = QLabel(texte)
    lab.setObjectName(objet)
    lab.setWordWrap(True)
    return lab


class ArticleCard(QFrame):
    """Un article : resume, explications, marche a suivre, liens."""

    def __init__(self, article, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("Panel")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 16, 20, 18)
        lay.setSpacing(9)

        lay.addWidget(_titre(article.title))

        resume = QLabel(article.summary)
        resume.setObjectName("Dim")
        resume.setWordWrap(True)
        lay.addWidget(resume)

        for paragraphe in article.body:
            texte = QLabel(paragraphe)
            texte.setObjectName("Faint")
            texte.setWordWrap(True)
            texte.setTextInteractionFlags(
                Qt.TextInteractionFlag.TextSelectableByMouse)
            lay.addWidget(texte)

        if article.steps:
            grille = QGridLayout()
            grille.setHorizontalSpacing(14)
            grille.setVerticalSpacing(10)
            grille.setColumnStretch(2, 1)
            for i, (titre, detail) in enumerate(article.steps):
                numero = QLabel(f"{i + 1:02d}")
                numero.setStyleSheet(
                    f"color:{PALETTE['accent']}; font-weight:700;"
                    " font-size:11px; letter-spacing:1px;")
                numero.setAlignment(Qt.AlignmentFlag.AlignTop
                                    | Qt.AlignmentFlag.AlignRight)
                grille.addWidget(numero, i, 0)

                nom = QLabel(titre)
                nom.setObjectName("Value")
                nom.setWordWrap(True)
                nom.setMinimumWidth(190)
                nom.setMaximumWidth(260)
                nom.setAlignment(Qt.AlignmentFlag.AlignTop)
                grille.addWidget(nom, i, 1)

                texte = QLabel(detail)
                texte.setObjectName("Faint")
                texte.setWordWrap(True)
                grille.addWidget(texte, i, 2)
            lay.addLayout(grille)

        if article.links:
            ligne = QHBoxLayout()
            ligne.setSpacing(8)
            for libelle, url in article.links:
                bouton = QPushButton(libelle)
                bouton.setObjectName("Ghost")
                bouton.setCursor(Qt.CursorShape.PointingHandCursor)
                bouton.setToolTip(url)
                bouton.clicked.connect(
                    lambda _checked=False, u=url: webbrowser.open(u))
                ligne.addWidget(bouton)
            ligne.addStretch(1)
            lay.addLayout(ligne)


class TutorialView(QWidget):
    """Le mode d'emploi complet, avec recherche."""

    open_settings_requested = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._rubrique = ""

        root = QVBoxLayout(self)
        root.setContentsMargins(24, 18, 24, 12)
        root.setSpacing(14)

        # -- en-tete -----------------------------------------------------
        bar = QHBoxLayout()
        titre = QLabel("Tuto")
        titre.setObjectName("PageTitle")
        bar.addWidget(titre)
        self.count = QLabel("")
        self.count.setObjectName("PageHint")
        bar.addWidget(self.count)
        bar.addStretch(1)

        self.search = QLineEdit()
        self.search.setObjectName("Search")
        self.search.setPlaceholderText(
            "Chercher : cle gemini, bottleneck, sauvegarde, 180 Hz...")
        self.search.setFixedWidth(420)
        self.search.setClearButtonEnabled(True)
        # la page attend la fin de la frappe avant de se reconstruire
        self._frappe = QTimer(self)
        self._frappe.setSingleShot(True)
        self._frappe.setInterval(180)
        self._frappe.timeout.connect(self._refresh)
        self.search.textChanged.connect(lambda _t: self._frappe.start())
        bar.addWidget(self.search)

        reglages = QPushButton("Ouvrir les reglages")
        reglages.setObjectName("Ghost")
        reglages.clicked.connect(self.open_settings_requested.emit)
        bar.addWidget(reglages)
        root.addLayout(bar)

        corps = QHBoxLayout()
        corps.setSpacing(16)
        root.addLayout(corps, 1)

        # -- rubriques ----------------------------------------------------
        cote = QVBoxLayout()
        cote.setSpacing(6)
        self.buttons: dict[str, QPushButton] = {}
        for rid, label in [("", "Tout")] + [(r.id, r.title) for r in RUBRIQUES] \
                + [("faq", "Questions frequentes")]:
            bouton = QPushButton(label)
            bouton.setObjectName("NavButton")
            bouton.setCheckable(True)
            bouton.setCursor(Qt.CursorShape.PointingHandCursor)
            bouton.setChecked(rid == "")
            bouton.clicked.connect(
                lambda _checked=False, r=rid: self._choose(r))
            cote.addWidget(bouton)
            self.buttons[rid] = bouton
        cote.addStretch(1)
        cadre = QWidget()
        cadre.setFixedWidth(232)
        cadre.setLayout(cote)
        corps.addWidget(cadre)

        # -- contenu ------------------------------------------------------
        scroll = ZoneDefilante()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        corps.addWidget(scroll, 1)
        page = QWidget()
        scroll.setWidget(page)
        self.content = QVBoxLayout(page)
        self.content.setContentsMargins(0, 0, 10, 0)
        self.content.setSpacing(14)

        self._refresh()

    # ------------------------------------------------------------------
    def _choose(self, rubrique: str) -> None:
        self._rubrique = rubrique
        for rid, bouton in self.buttons.items():
            bouton.setChecked(rid == rubrique)
        self._refresh()


    def _refresh(self) -> None:
        query = self.search.text().strip()
        clear_layout(self.content)

        articles = 0
        if self._rubrique != "faq":
            for rubrique, trouves in search(query):
                if self._rubrique and rubrique.id != self._rubrique:
                    continue
                entete = QLabel(rubrique.title.upper())
                entete.setStyleSheet(
                    f"color:{PALETTE['text_faint']}; font-size:11px;"
                    " font-weight:700; letter-spacing:2px;")
                self.content.addWidget(entete)
                for article in trouves:
                    self.content.addWidget(ArticleCard(article))
                    articles += 1

        # la FAQ suit les articles, ou occupe la page entiere
        questions = faq_matching(query)
        if questions and self._rubrique in ("", "faq"):
            entete = QLabel("QUESTIONS FREQUENTES")
            entete.setStyleSheet(
                f"color:{PALETTE['text_faint']}; font-size:11px;"
                " font-weight:700; letter-spacing:2px;")
            self.content.addWidget(entete)
            for question, reponse in questions:
                self.content.addWidget(self._faq_card(question, reponse))

        if not articles and not (questions and self._rubrique in ("", "faq")):
            vide = QLabel(
                f"Rien trouve pour « {query} ».\n\n"
                "Essayez un mot plus simple : cle, prix, manette, "
                "sauvegarde, disque, ecran, recette.")
            vide.setObjectName("Dim")
            vide.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.content.addWidget(vide)

        self.content.addStretch(1)
        total = articles + (len(questions) if self._rubrique in ("", "faq")
                            else 0)
        self.count.setText(
            f"{total} resultat(s) pour « {query} »" if query
            else f"{len(FAQ)} questions et tout le fonctionnement")

    @staticmethod
    def _faq_card(question: str, reponse: str) -> QFrame:
        cadre = QFrame()
        cadre.setObjectName("Panel")
        lay = QVBoxLayout(cadre)
        lay.setContentsMargins(20, 14, 20, 15)
        lay.setSpacing(5)
        q = QLabel(question)
        q.setObjectName("Value")
        q.setWordWrap(True)
        lay.addWidget(q)
        r = QLabel(reponse)
        r.setObjectName("Faint")
        r.setWordWrap(True)
        lay.addWidget(r)
        return cadre
