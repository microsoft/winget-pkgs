"""Instance unique : un seul ORION a la fois.

Avec un raccourci sur le bureau et une entree dans le menu Demarrer, un
double-clic de trop est vite arrive. Deux ORION en meme temps, ce sont deux
veilles de prix, deux mesures de performance sur la meme partie et deux
notifications pour chaque evenement.

Le verrou passe par un serveur local nomme (fonction integree a Qt, donc
aucune dependance). La deuxieme instance ne trouve pas le verrou libre :
elle previent la premiere, qui se remet au premier plan, puis s'arrete.

Si le mecanisme echoue pour une raison quelconque, l'application demarre
normalement : mieux vaut deux fenetres qu'aucune.
"""
from __future__ import annotations

import getpass

from PySide6.QtCore import QObject, Signal
from PySide6.QtNetwork import QLocalServer, QLocalSocket

from .logging_setup import get

log = get("instance")


def _socket_name() -> str:
    """Nom du verrou, propre a l'utilisateur de la session Windows."""
    try:
        who = getpass.getuser()
    except Exception:
        who = "utilisateur"
    return f"orion-launcher-{who}"


class SingleInstance(QObject):
    """Verrou d'instance unique, et reveil de la fenetre existante."""

    raise_requested = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._server: QLocalServer | None = None
        self.name = _socket_name()

    # ------------------------------------------------------------------
    def already_running(self, timeout_ms: int = 350) -> bool:
        """Vrai si une autre instance repond, et a qui on a passe la main."""
        probe = QLocalSocket()
        probe.connectToServer(self.name)
        if not probe.waitForConnected(timeout_ms):
            return False
        try:
            probe.write(b"montre-toi")
            probe.waitForBytesWritten(timeout_ms)
        finally:
            probe.disconnectFromServer()
        log.info("ORION est deja lance : la fenetre existante est rappelee")
        return True

    def listen(self) -> bool:
        """Prend le verrou. A appeler une fois l'absence d'autre instance etablie."""
        server = QLocalServer(self)
        # un arret brutal (coupure de courant, fin de tache) laisse le nom
        # occupe sous Windows : on le libere avant d'ecouter.
        QLocalServer.removeServer(self.name)
        if not server.listen(self.name):
            log.debug("Verrou d'instance indisponible : %s",
                      server.errorString())
            return False
        server.newConnection.connect(self._welcome)
        self._server = server
        return True

    def _welcome(self) -> None:
        """Une autre instance s'est annoncee : on revient au premier plan."""
        while self._server is not None and self._server.hasPendingConnections():
            client = self._server.nextPendingConnection()
            client.readyRead.connect(client.deleteLater)
            client.disconnected.connect(client.deleteLater)
        self.raise_requested.emit()

    def close(self) -> None:
        if self._server is not None:
            self._server.close()
            self._server = None
