"""Etat du systeme vu par la page Conseils : pilotes, reglages Windows, memoire.

Une seule requete PowerShell rassemble tout (inventaire des pilotes, mode
jeu, planification GPU, plan d'alimentation, barrettes memoire, disques
physiques, redemarrage en attente, fichier d'echange, peripheriques sans
pilote). Elle tourne dans le fil de la sonde materielle, jamais dans celui
de l'interface.

Le module ne produit que des donnees : les textes affiches sont ecrits par
`optimizer/advisor.py`. Toutes les fonctions d'interpretation sont pures
(dictionnaires en entree) pour etre testees hors de Windows.
"""
from __future__ import annotations

import base64
import datetime as _dt
import json
import re
import subprocess
import threading
import time
import unicodedata
from dataclasses import dataclass, field

from ..core.logging_setup import get
from ..core.paths import is_windows

log = get("materiel.systeme")

CREATE_NO_WINDOW = 0x08000000
DELAI_MAX = 75                  # secondes accordees a PowerShell
CACHE_SECONDS = 600


# --- plans d'alimentation (identifiants fixes de Windows) ------------------
PLAN_EQUILIBRE = "381b4222-f694-41f0-9685-ff5bb260df2e"
PLAN_ECONOMIE = "a1841308-3541-4fab-bc81-f71556f20b4a"
PLAN_PERFORMANCES = "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c"
PLAN_ULTIME = "e9a42b02-d5df-448d-aa00-03f14749eb61"
#: « mode d'alimentation » de Windows 10/11 pose par-dessus le plan
SURCOUCHE_PERFORMANCES = "ded574b5-45a0-4f42-8737-46345c09c238"
SURCOUCHE_ECONOMIE = "961cc777-2547-4f9d-8174-7d86181b8a7a"

#: types de boitier SMBIOS (Win32_SystemEnclosure.ChassisTypes)
BOITIERS_BUREAU = {3, 4, 5, 6, 7, 13, 15, 16, 24, 35, 36}
BOITIERS_PORTABLE = {8, 9, 10, 11, 12, 14, 18, 21, 30, 31, 32}

#: vitesses de memoire standard, pour lire la reference d'une barrette
VITESSES_STANDARD = {2133, 2400, 2666, 2667, 2800, 2933, 3000, 3200, 3333,
                     3466, 3600, 3733, 3866, 4000, 4133, 4266, 4400, 4600,
                     4800, 5200, 5600, 6000, 6200, 6400, 6600, 6800, 7000,
                     7200, 7600, 8000, 8200, 8400}

SCRIPT = r"""
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$r = [ordered]@{}
function Date-Texte($d) { if ($d -is [datetime]) { $d.ToString('yyyy-MM-dd') } elseif ($d) { [string]$d } else { '' } }
try {
  $classes = @('DISPLAY','NET','MEDIA','SYSTEM','SCSIADAPTER','HDC','USB','BLUETOOTH')
  $r.pilotes = @(Get-CimInstance Win32_PnPSignedDriver | Where-Object { $_.DeviceClass -and ($classes -contains $_.DeviceClass) } | ForEach-Object {
    [ordered]@{ DeviceName = $_.DeviceName; DeviceClass = $_.DeviceClass; DriverVersion = $_.DriverVersion;
      DriverDate = (Date-Texte $_.DriverDate); Manufacturer = $_.Manufacturer;
      DriverProviderName = $_.DriverProviderName; IsSigned = $_.IsSigned;
      HardwareID = [string]$_.HardwareID; DeviceID = [string]$_.DeviceID } })
} catch { $r.erreur_pilotes = $_.Exception.Message }
try {
  $r.sans_pilote = @(Get-CimInstance Win32_PnPEntity | Where-Object { $_.ConfigManagerErrorCode -and $_.ConfigManagerErrorCode -ne 22 -and $_.ConfigManagerErrorCode -ne 45 } | ForEach-Object {
    [ordered]@{ nom = $_.Name; classe = $_.PNPClass; code = [int]$_.ConfigManagerErrorCode } })
} catch {}
try { $g = Get-ItemProperty 'HKCU:\Software\Microsoft\GameBar' -ErrorAction Stop; if ($null -ne $g.AutoGameModeEnabled) { $r.mode_jeu = [int]$g.AutoGameModeEnabled } } catch {}
try { $g = Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -ErrorAction Stop; if ($null -ne $g.HwSchMode) { $r.hags = [int]$g.HwSchMode } } catch {}
try { $g = Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -ErrorAction Stop; if ($null -ne $g.HistoricalCaptureEnabled) { $r.capture_fond = [int]$g.HistoricalCaptureEnabled } } catch {}
try { $r.plans = [string]((powercfg /list) -join "`n") } catch {}
try { $g = Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\User\PowerSchemes' -ErrorAction Stop; if ($g.ActiveOverlayAcPowerScheme) { $r.surcouche = [string]$g.ActiveOverlayAcPowerScheme } } catch {}
try { $r.boitier = @((Get-CimInstance Win32_SystemEnclosure).ChassisTypes | ForEach-Object { [int]$_ }) } catch {}
try { $r.batteries = @(Get-CimInstance Win32_Battery).Count } catch {}
try {
  $cs = Get-CimInstance Win32_ComputerSystem
  $r.pc = [ordered]@{ fabricant = $cs.Manufacturer; modele = $cs.Model; type = [int]$cs.PCSystemType; pagination_auto = [bool]$cs.AutomaticManagedPagefile; sku = [string]$cs.SystemSKUNumber }
} catch {}
try { $b = Get-CimInstance Win32_BaseBoard | Select-Object -First 1; $r.carte_mere = [ordered]@{ fabricant = $b.Manufacturer; modele = $b.Product } } catch {}
try {
  $r.barrettes = @(Get-CimInstance Win32_PhysicalMemory | ForEach-Object {
    [ordered]@{ capacite = [double]$_.Capacity; vitesse = [int]$_.Speed; configuree = [int]$_.ConfiguredClockSpeed;
      emplacement = $_.DeviceLocator; banque = $_.BankLabel; fabricant = $_.Manufacturer;
      reference = ([string]$_.PartNumber).Trim(); type = [int]$_.SMBIOSMemoryType } })
} catch {}
try {
  $r.disques = @(Get-PhysicalDisk | ForEach-Object {
    [ordered]@{ numero = [string]$_.DeviceId; nom = $_.FriendlyName; type = [string]$_.MediaType; bus = [string]$_.BusType } })
  $r.partitions = @(Get-Partition | Where-Object { $_.DriveLetter } | ForEach-Object {
    [ordered]@{ lettre = [string]$_.DriveLetter; disque = [string]$_.DiskNumber } })
} catch {}
try {
  $r.redemarrage = [ordered]@{
    cbs = [bool](Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending');
    wu = [bool](Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired') }
} catch {}
try {
  $r.pagination = @(Get-CimInstance Win32_PageFileSetting | ForEach-Object { [ordered]@{ nom = $_.Name; initial = [int]$_.InitialSize; maximum = [int]$_.MaximumSize } })
  $r.pagination_usage = @(Get-CimInstance Win32_PageFileUsage | ForEach-Object { [ordered]@{ nom = $_.Name; alloue = [int]$_.AllocatedBaseSize } })
} catch {}
$r | ConvertTo-Json -Depth 5 -Compress
"""


# --------------------------------------------------------------------------
# Modele
# --------------------------------------------------------------------------

@dataclass
class Pilote:
    nom: str
    classe: str                       # DISPLAY, NET, MEDIA...
    version: str = ""
    date: _dt.date | None = None
    fabricant: str = ""               # fabricant du peripherique
    fournisseur: str = ""             # editeur du pilote (DriverProviderName)
    signe: bool | None = None
    categorie: str = ""               # graphique | reseau | audio | chipset | stockage | usb | bluetooth
    marque: str = ""                  # amd | intel | nvidia | realtek | ...
    id_materiel: str = ""             # PCI\VEN_8086&DEV_2723&SUBSYS_00848086&REV_1A
    id_instance: str = ""             # PCI\VEN_...\4&2F3A...&0&00E0

    @property
    def cle_materiel(self) -> str:
        """Puce identifiee par son bus, son fabricant et son modele (sans
        sous-systeme ni revision) : ce que Windows Update apparie."""
        return cle_materiel(self.id_materiel)

    @property
    def bus(self) -> str:
        """Le bus qui a enumere le peripherique (« PCI », « USB », « HDAUDIO »,
        « ACPI »... ou « ROOT », « SWD » pour un peripherique logiciel), d'apres
        l'identifiant d'instance, que le pilote ne choisit pas."""
        return bus(self.id_instance or self.id_materiel)

    @property
    def fabricant_carte(self) -> str:
        """Identifiant de celui qui a fabrique la carte ou l'appareil : le
        sous-systeme PCI (« SUBSYS_87411043 » -> « 1043 », ASUS) ou le VID USB
        (« USB\\VID_2357&PID_0138 » -> « 2357 », TP-Link). Vide ailleurs.
        Distingue une carte ajoutee (reseau 10G ASUS dans une tour MSI) d'une
        puce de la carte mere."""
        return fabricant_carte(self.id_materiel)

    @property
    def nom_fabricant_carte(self) -> str:
        """Le nom du fabricant de la carte d'apres la base publique des
        identifiants PCI/USB (« ASUS », « TP-Link », « Corsair »), ou ""."""
        return nom_fabricant(self.bus, self.fabricant_carte)

    @property
    def generique(self) -> bool:
        """Pilote fourni par Microsoft (pilote de classe de Windows)."""
        return "microsoft" in simple(self.fournisseur)

    def age_jours(self, aujourdhui: _dt.date) -> int | None:
        """Age du pilote, seulement si la date est plausible.

        Les dates factices (Intel INF « 1968 », pilotes de Windows « 2006 »)
        ou posterieures a aujourd'hui ne donnent pas d'age."""
        if self.date is None or self.date.year < 2012 or self.date > aujourdhui:
            return None
        return (aujourdhui - self.date).days


@dataclass
class EtatSysteme:
    pilotes: list[Pilote] | None = None      # None : inventaire impossible
    pilotes_bruts: int = 0                   # peripheriques lus avant filtrage
    classes_brutes: dict[str, int] = field(default_factory=dict)
    sans_pilote: list[dict] = field(default_factory=list)
    mode_jeu: int | None = None              # AutoGameModeEnabled
    hags: int | None = None                  # HwSchMode : 2 actif, 1 inactif
    capture_fond: int | None = None          # HistoricalCaptureEnabled
    plan_actif: str = ""                     # GUID en minuscules
    plan_nom: str = ""
    plans: dict[str, str] = field(default_factory=dict)
    surcouche: str = ""
    boitier: str = ""                        # bureau | portable | ""
    barrettes: list[dict] = field(default_factory=list)
    lettres: dict[str, dict] = field(default_factory=dict)   # "D" -> disque physique
    redemarrage: dict | None = None
    pagination_auto: bool | None = None
    pagination: list[dict] | None = None
    pagination_usage: list[dict] = field(default_factory=list)
    carte_mere: tuple[str, str] = ("", "")
    pc: tuple[str, str] = ("", "")           # fabricant, modele du PC
    pc_sku: str = ""                         # numero de produit (HP « 4M4R6EA#ABF », Dell, Lenovo)
    erreurs: list[str] = field(default_factory=list)

    @property
    def bureau(self) -> bool:
        return self.boitier == "bureau"

    def type_disque(self, lettre: str) -> str:
        """HDD | SSD | "" pour une lettre de lecteur."""
        d = self.lettres.get((lettre or "")[:1].upper())
        if not d:
            return ""
        t = str(d.get("type") or "").upper()
        if t in ("HDD", "3"):
            return "HDD"
        if t in ("SSD", "4", "SCM", "5") or str(d.get("bus") or "").upper() in ("NVME", "17"):
            return "SSD"
        return ""


# --------------------------------------------------------------------------
# Interpretation (fonctions pures)
# --------------------------------------------------------------------------

def simple(texte) -> str:
    """Minuscules sans accents, pour comparer des libelles localises."""
    t = unicodedata.normalize("NFKD", str(texte or ""))
    return "".join(c for c in t if not unicodedata.combining(c)).lower()


def lire_date(valeur) -> _dt.date | None:
    """Accepte 2024-05-14, 5-14-2024, 20240514000000.000000+000, /Date(ms)/."""
    s = str(valeur or "").strip()
    if not s:
        return None
    m = re.search(r"/Date\((-?\d+)", s)
    try:
        if m:
            return _dt.datetime.fromtimestamp(int(m.group(1)) / 1000,
                                              _dt.timezone.utc).date()
        m = re.match(r"(\d{4})-(\d{1,2})-(\d{1,2})", s)
        if m:
            return _dt.date(*(int(x) for x in m.groups()))
        m = re.match(r"(\d{1,2})[-/](\d{1,2})[-/](\d{4})", s)
        if m:
            mois, jour, annee = (int(x) for x in m.groups())
            return _dt.date(annee, mois, jour)
        m = re.match(r"(\d{4})(\d{2})(\d{2})", s)
        if m:
            return _dt.date(*(int(x) for x in m.groups()))
    except (ValueError, OverflowError, OSError):
        return None
    return None


_MARQUES = (
    ("nvidia", "nvidia"), ("advanced micro devices", "amd"), ("amd", "amd"),
    ("ati technologies", "amd"), ("killer", "intel"), ("intel", "intel"),
    ("realtek", "realtek"), ("mediatek", "mediatek"), ("qualcomm", "qualcomm"),
    ("atheros", "qualcomm"), ("broadcom", "broadcom"), ("asmedia", "asmedia"),
    ("aquantia", "marvell"), ("marvell", "marvell"), ("samsung", "samsung"),
    ("creative", "creative"), ("via ", "via"),
)


_ID = re.compile(r"^([A-Z0-9_]+)\\.*?(VEN|VID)_([0-9A-F]{4}).*?(DEV|PID)_([0-9A-F]{4})", re.I)


_SOUS_SYSTEME = re.compile(r"^PCI\\.*SUBSYS_([0-9A-F]{4})([0-9A-F]{4})", re.I)
_VID_USB = re.compile(r"^USB\\VID_([0-9A-F]{4})", re.I)

#: bus qui enumerent du materiel ; tout autre bus (ROOT, SWD, {GUID}, BTH,
#: VMS_MP...) porte un peripherique logiciel : VPN, casque VR, son virtuel,
#: streaming... Une regle d'identifiant, pas une liste de noms a entretenir.
BUS_MATERIEL = ("PCI", "USB", "HDAUDIO", "INTELAUDIO", "ACPI", "SD", "USB4", "TBT")

#: fabricants de puces (pas de cartes) : une puce Intel ou Realtek sur une
#: carte mere HP vient de HP, pas d'une « carte Intel ajoutee »
PUCES = {
    "PCI": frozenset(("8086", "10EC", "1002", "1022", "10DE", "11AB", "1B4B", "1D6A", "14E4",
                      "168C", "17CB", "14C3", "144D", "1A56", "1987", "15B7", "1C5C", "1E0F",
                      "C0A9", "1B21", "1106", "104C", "1033", "10B5", "1217", "1180", "1B73",
                      "1912", "1F1F", "126F", "1CC1", "1E4B", "1E95", "2646", "10EE", "1000")),
    "USB": frozenset(("8087", "0BDA", "0CF3", "0E8D", "0A5C", "13D3", "0489", "04CA", "0A12",
                      "2109", "0451", "05E3", "1A40", "0BC2", "174C", "152D")),
}


def bus(identifiant: str) -> str:
    i = (identifiant or "").strip()
    return i.split("\\", 1)[0].upper() if "\\" in i else ""


def fabricant_carte(identifiant: str) -> str:
    i = (identifiant or "").strip()
    m = _SOUS_SYSTEME.match(i)
    if m:
        return m.group(2).upper()
    m = _VID_USB.match(i)
    return m.group(1).upper() if m else ""


_FABRICANTS: dict | None = None


def nom_fabricant(bus_: str, identifiant: str) -> str:
    """Nom court du fabricant d'apres la base publique pci.ids / usb.ids
    embarquee (`fabricants_ids.json`, rafraichie par service/maj_fabricants.py)."""
    global _FABRICANTS
    if not identifiant:
        return ""
    if _FABRICANTS is None:
        try:
            from ..core.paths import ROOT_DIR
            _FABRICANTS = json.loads((ROOT_DIR / "orion" / "hardware" / "fabricants_ids.json")
                                     .read_text(encoding="utf-8"))
        except Exception:
            log.warning("Base des fabricants (fabricants_ids.json) introuvable")
            _FABRICANTS = {}
    table = _FABRICANTS.get((bus_ or "").lower()) or {}
    return str(table.get(identifiant.upper()) or "")


def cle_materiel(identifiant: str) -> str:
    """« PCI\\VEN_8086&DEV_2723&SUBSYS_00848086&REV_1A » -> « PCI\\VEN_8086&DEV_2723 ».
    Vide si l'identifiant n'a pas cette forme (ACPI, racines, virtuels)."""
    m = _ID.match((identifiant or "").strip())
    if not m:
        return ""
    return f"{m.group(1).upper()}\\{m.group(2).upper()}_{m.group(3).upper()}&{m.group(4).upper()}_{m.group(5).upper()}"


#: marque de la puce d'apres son identifiant de fabricant (PCI VEN_ / USB VID_)
MARQUES_ID = {
    "8086": "intel", "8087": "intel", "1A56": "intel", "10EC": "realtek", "0BDA": "realtek",
    "1002": "amd", "1022": "amd", "10DE": "nvidia", "0955": "nvidia", "11AB": "marvell",
    "1B4B": "marvell", "1D6A": "marvell", "14E4": "broadcom", "0A5C": "broadcom",
    "168C": "qualcomm", "17CB": "qualcomm", "0CF3": "qualcomm", "14C3": "mediatek",
    "0E8D": "mediatek", "144D": "samsung", "1102": "creative", "041E": "creative",
    "1B21": "asmedia", "1106": "via", "2109": "via",
}


def marque_id(identifiant: str) -> str:
    """« PCI\\VEN_8086&DEV_15BC... » -> « intel » ; "" si la puce est inconnue."""
    m = _ID.match((identifiant or "").strip())
    return MARQUES_ID.get(m.group(3).upper(), "") if m else ""


def marque(*textes, identifiant: str = "") -> str:
    par_id = marque_id(identifiant)
    if par_id:
        return par_id
    for t in textes:
        s = simple(t)
        if not s or s.startswith("(standard") or s.startswith("standard"):
            continue
        for motif, cle in _MARQUES:
            if re.search(r"\b" + re.escape(motif.strip()) + r"\b", s):
                return cle
    return ""


_VIRTUEL = re.compile(
    r"(virtual|virtuel|wan miniport|miniport|hyper-v|vmware|virtualbox|tap-|"
    r"tunnel|teredo|isatap|6to4|ip-https|loopback|bouclage|kernel debug|"
    r"wi-fi direct|vpn|wireguard|tailscale|zerotier|hamachi|npcap|"
    r"steam streaming|vb-audio|voicemeeter|sonar|nahimic|oculus|meta |"
    r"bigscreen|audio stream|voicemod|virtual desktop|droidcam|obs |ndi |"
    r"parsec|remote|distant|idd |usb display|citrix|teamviewer|"
    r"personal area network|reseau personnel|rfcomm|enumerator|enumerateur|"
    r"identification|avrcp|le generic attribute|\bble\b|hands-free|mains libres)",
    re.I)

_CHIPSET = re.compile(
    r"(smbus|sm bus|psp|platform security|gpio|i2c|chipset|management engine|"
    r"\bmei\b|serial io|ppm provisioning|provisioning|3d v-cache|ryzen|"
    r"pci express root|pci standard host|pci host|amd pci|"
    r"interface du moteur de gestion|ipf|dynamic tuning|gna|lpc controller)",
    re.I)

_USB_HOTE = re.compile(r"(host controller|xhci|extensible|controleur d.hote|"
                       r"controleur hote)", re.I)


#: codecs HDMI/DisplayPort des cartes graphiques (Intel, AMD, NVIDIA) :
#: livres avec le pilote graphique, jamais a mettre a jour a part
_SON_ECRAN = re.compile(r"^HDAUDIO\\.*VEN_(8086|1002|10DE)\b", re.I)


def categorie(classe: str, nom: str, id_materiel: str = "", id_instance: str = "") -> str:
    """Categorie de la page Conseils, ou "" si le peripherique est ignore.

    Le tri se fait d'abord sur le bus de l'identifiant d'instance : PCI, USB,
    HDAUDIO, ACPI... sont du materiel ; ROOT, SWD, {GUID}... sont des
    peripheriques logiciels (VPN, casque VR, son virtuel, streaming), quel
    que soit leur nom et la langue de Windows. La liste de noms `_VIRTUEL`
    ne sert plus que sans identifiant (anciens releves).

    Retour de l'auteur (8 octobre, HP EliteDesk) : « Son Intel(R) pour
    ecrans » (le nom francais d'Intel Display Audio) et « AMD Streaming
    Audio Device » (un peripherique logiciel du pilote Radeon, bus ROOT)
    ressortaient en « pilote audio ancien ».
    """
    c = (classe or "").upper()
    n = simple(nom)
    i = (id_materiel or "").upper()
    b = bus(id_instance or id_materiel)
    if not n:
        return ""
    if b:
        if b not in BUS_MATERIEL:
            return ""                     # peripherique logiciel
        virtuel = False
    else:
        virtuel = bool(_VIRTUEL.search(n))
    if c == "DISPLAY":
        if virtuel and "basic" not in n and "de base" not in n:
            return ""
        return "graphique"
    if virtuel:
        return ""
    if c == "NET":
        if re.search(r"(ethernet|wi-?fi|wireless|wlan|802\.11|gbe|\blan\b|"
                     r"network|reseau|killer|controller|controleur)", n):
            return "reseau"
        return ""
    if c == "MEDIA":
        if _SON_ECRAN.search(i):
            return ""                     # son HDMI : livre avec le pilote graphique
        if re.search(r"(nvidia high definition|amd high definition|"
                     r"intel\(r\) display audio|display audio|hdmi|"
                     r"pour ecrans?|streaming audio)", n):
            return ""                     # son HDMI : livre avec le pilote graphique
        if re.search(r"(audio|realtek|sound|\bson\b|codec|high definition)", n):
            return "audio"
        return ""
    if c == "SYSTEM":
        return "chipset" if _CHIPSET.search(n) else ""
    if c in ("SCSIADAPTER", "HDC"):
        if re.search(r"(nvm|nvme|sata|ahci|raid|\brst\b|storage|stockage|"
                     r"controller|controleur)", n) and "spaces" not in n:
            return "stockage"
        return ""
    if c == "USB":
        return "usb" if _USB_HOTE.search(n) else ""
    if c == "BLUETOOTH":
        if re.search(r"(adapter|adaptateur|radio|wireless bluetooth|"
                     r"bluetooth\(r\)|intel|realtek|mediatek|qualcomm|"
                     r"broadcom)", n):
            return "bluetooth"
        return ""
    return ""


def pilotes(bruts: list[dict]) -> list[Pilote]:
    """Pilotes retenus pour l'analyse, doublons ecartes."""
    out: list[Pilote] = []
    vus: set[tuple] = set()
    for b in bruts or []:
        if not isinstance(b, dict):
            continue
        nom = str(b.get("DeviceName") or "").strip()
        classe = str(b.get("DeviceClass") or "").strip().upper()
        cat = categorie(classe, nom, str(b.get("HardwareID") or ""), str(b.get("DeviceID") or ""))
        if not cat:
            continue
        p = Pilote(
            nom=nom, classe=classe,
            version=str(b.get("DriverVersion") or "").strip(),
            date=lire_date(b.get("DriverDate")),
            fabricant=str(b.get("Manufacturer") or "").strip(),
            fournisseur=str(b.get("DriverProviderName") or "").strip(),
            signe=b.get("IsSigned") if isinstance(b.get("IsSigned"), bool) else None,
            categorie=cat,
            id_materiel=str(b.get("HardwareID") or "").strip(),
            id_instance=str(b.get("DeviceID") or "").strip())
        p.marque = marque(p.nom, p.fabricant, p.fournisseur, identifiant=p.id_materiel)
        cle = (p.nom, p.version, p.fournisseur)
        if cle in vus:
            continue
        vus.add(cle)
        out.append(p)
    return out


def lire_plans(texte: str) -> tuple[dict[str, str], str]:
    """Sortie de `powercfg /list` -> ({guid: nom}, guid actif)."""
    plans: dict[str, str] = {}
    actif = ""
    for ligne in str(texte or "").splitlines():
        m = re.search(r"([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-"
                      r"[0-9a-f]{12})\s*(?:\(([^)]*)\))?\s*(\*)?", ligne, re.I)
        if not m:
            continue
        guid = m.group(1).lower()
        plans[guid] = (m.group(2) or "").strip()
        if m.group(3):
            actif = guid
    return plans, actif


def boitier(types: list | None, type_pc: int | None, batteries: int | None) -> str:
    """bureau | portable | "" (inconnu)."""
    types = {int(t) for t in (types or []) if str(t).lstrip("-").isdigit()}
    if types & BOITIERS_PORTABLE or type_pc == 2:
        return "portable"
    if batteries:
        return "portable"
    if types & BOITIERS_BUREAU or type_pc in (1, 3):
        return "bureau"
    return ""


def vitesse_annoncee(reference: str) -> int:
    """Vitesse lue dans la reference commerciale d'une barrette (0 si absente).

    F4-3600C16-16GVKC -> 3600 ; CMK32GX4M2D3600C18 -> 3600 ;
    F5-6000J3038F16G -> 6000 ; KF560C36-16 -> 6000 ; KF3600C16D4/16GX -> 3600.
    """
    ref = str(reference or "").upper()
    for m in re.finditer(r"(?<!\d)(\d{4})(?!\d)", ref):
        v = int(m.group(1))
        if v in VITESSES_STANDARD:
            return v
    # Kingston Fury : KF<generation><vitesse/100>C.. (KF560C36 = DDR5-6000)
    m = re.match(r"KF[45](\d{2})C", ref)
    if m:
        v = int(m.group(1)) * 100
        v = {2600: 2666, 2900: 2933}.get(v, v)
        if v in VITESSES_STANDARD:
            return v
    return 0


def canal(emplacement: str, banque: str = "") -> str:
    """Lettre de canal memoire lue dans l'emplacement (A, B...), "" si inconnue."""
    for texte in (emplacement, banque):
        s = simple(texte)
        m = re.search(r"channel\s*([a-d])\b", s) or re.search(r"canal\s*([a-d])\b", s)
        if m:
            return m.group(1).upper()
        m = re.search(r"dimm[_\s-]?([a-d])[0-9]\b", s)
        if m:
            return m.group(1).upper()
        m = re.fullmatch(r"\s*([a-d])[12]\s*", s)
        if m:
            return m.group(1).upper()
    return ""


def interpreter(donnees: dict) -> EtatSysteme:
    """Dictionnaire produit par le script PowerShell -> EtatSysteme."""
    d = donnees if isinstance(donnees, dict) else {}
    e = EtatSysteme()

    def liste(cle):
        v = d.get(cle)
        if v is None:
            return None
        if isinstance(v, dict):         # PowerShell aplatit les tableaux d'un element
            return [v]
        return v if isinstance(v, list) else None

    bruts = liste("pilotes")
    if bruts is not None:
        e.pilotes_bruts = len(bruts)
        for b in bruts:
            if isinstance(b, dict):
                c = str(b.get("DeviceClass") or "").upper()
                e.classes_brutes[c] = e.classes_brutes.get(c, 0) + 1
        e.pilotes = pilotes(bruts)
    elif d.get("erreur_pilotes"):
        e.erreurs.append(str(d["erreur_pilotes"]))
    e.sans_pilote = [x for x in (liste("sans_pilote") or []) if isinstance(x, dict)]

    def entier(cle):
        try:
            return int(d[cle]) if d.get(cle) is not None else None
        except (TypeError, ValueError):
            return None

    e.mode_jeu = entier("mode_jeu")
    e.hags = entier("hags")
    e.capture_fond = entier("capture_fond")
    e.plans, e.plan_actif = lire_plans(d.get("plans") or "")
    e.plan_nom = e.plans.get(e.plan_actif, "")
    e.surcouche = str(d.get("surcouche") or "").strip("{} ").lower()

    pc = d.get("pc") if isinstance(d.get("pc"), dict) else {}
    boit = d.get("boitier")
    e.boitier = boitier(boit if isinstance(boit, list) else ([boit] if boit is not None else []),
                        pc.get("type"), d.get("batteries"))
    e.pc = (str(pc.get("fabricant") or "").strip(), str(pc.get("modele") or "").strip())
    sku = str(pc.get("sku") or "").strip()
    e.pc_sku = "" if simple(sku) in ("", "to be filled by o.e.m.", "default string", "none") else sku
    if "pagination_auto" in pc:
        e.pagination_auto = bool(pc.get("pagination_auto"))
    cm = d.get("carte_mere") if isinstance(d.get("carte_mere"), dict) else {}
    e.carte_mere = (str(cm.get("fabricant") or "").strip(),
                    str(cm.get("modele") or "").strip())

    e.barrettes = [b for b in (liste("barrettes") or []) if isinstance(b, dict)]

    disques = {str(x.get("numero")): x for x in (liste("disques") or [])
               if isinstance(x, dict)}
    for p in liste("partitions") or []:
        if not isinstance(p, dict):
            continue
        lettre = str(p.get("lettre") or "")[:1].upper()
        disque = disques.get(str(p.get("disque")))
        if lettre and disque:
            e.lettres[lettre] = disque

    if isinstance(d.get("redemarrage"), dict):
        e.redemarrage = d["redemarrage"]
    pag = liste("pagination")
    if pag is not None:
        e.pagination = [x for x in pag if isinstance(x, dict)]
    e.pagination_usage = [x for x in (liste("pagination_usage") or [])
                          if isinstance(x, dict)]
    return e


def lire_json(texte: str) -> dict:
    """Extrait l'objet JSON de la sortie de PowerShell (bruit eventuel autour)."""
    s = str(texte or "")
    debut, fin = s.find("{"), s.rfind("}")
    if debut < 0 or fin <= debut:
        return {}
    try:
        v = json.loads(s[debut:fin + 1])
    except ValueError:
        return {}
    return v if isinstance(v, dict) else {}


# --------------------------------------------------------------------------
# Collecte (Windows, fil de fond)
# --------------------------------------------------------------------------

_CACHE: tuple[float, EtatSysteme] | None = None
_VERROU = threading.Lock()


def _executer() -> str:
    from ..core.lancement import popen_propre
    code = base64.b64encode(SCRIPT.encode("utf-16-le")).decode("ascii")
    proc = popen_propre(
        ["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy",
         "Bypass", "-EncodedCommand", code],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.DEVNULL,
        creationflags=CREATE_NO_WINDOW)
    try:
        sortie, _ = proc.communicate(timeout=DELAI_MAX)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.communicate()
        raise
    return (sortie or b"").decode("utf-8", errors="replace")


def en_cache() -> EtatSysteme | None:
    """Le dernier etat lu, sans rien lancer (None tant qu'aucune lecture n'a
    abouti) : utilisable depuis le fil d'interface."""
    return _CACHE[1] if _CACHE else None


def collecter(force: bool = False) -> EtatSysteme | None:
    """Etat du systeme (None hors Windows). A appeler hors du fil d'interface."""
    global _CACHE
    if not is_windows():
        return None
    with _VERROU:
        if _CACHE and not force and time.time() - _CACHE[0] < CACHE_SECONDS:
            return _CACHE[1]
        debut = time.time()
        try:
            etat = interpreter(lire_json(_executer()))
        except Exception as exc:
            log.warning("Etat du systeme illisible : %s", exc)
            etat = EtatSysteme(erreurs=[str(exc) or exc.__class__.__name__])
        log.info("Etat du systeme lu en %.1f s : %s pilotes retenus",
                 time.time() - debut,
                 "?" if etat.pilotes is None else len(etat.pilotes))
        _CACHE = (time.time(), etat)
        return etat
