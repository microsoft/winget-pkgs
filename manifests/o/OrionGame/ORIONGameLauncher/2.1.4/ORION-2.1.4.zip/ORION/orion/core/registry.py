"""Registre de plugins : le coeur de la modularite d'ORION.

Principe
--------
Chaque capacite (detecter des jeux, trouver des jaquettes, regler un moteur)
est une classe qui herite d'une classe de base. Le registre importe tous les
modules des paquets de plugins, collecte les sous-classes concretes et les
instancie. Aucun `import` a ajouter ailleurs.

Ajouter une source de jeux se resume donc a deposer un fichier
`orion/plugins/scanners/mon_store.py` (ou, sans toucher au code livre,
`%LOCALAPPDATA%/ORION/plugins/scanners/mon_store.py`) contenant :

    from orion.plugins.scanners.base import Scanner

    class MonStoreScanner(Scanner):
        id = "monstore"
        label = "Mon Store"
        def available(self) -> bool: ...
        def scan(self): ...
"""
from __future__ import annotations

import importlib
import importlib.util
import pkgutil
import sys
from typing import Iterable, Type, TypeVar

from .logging_setup import get
from .paths import PLUGIN_USER_DIR

log = get("registry")

T = TypeVar("T")

_LOADED: set[str] = set()


def _import_package(package: str) -> None:
    """Importe tous les sous-modules d'un paquet livre avec l'application."""
    try:
        pkg = importlib.import_module(package)
    except Exception:
        log.exception("Paquet de plugins introuvable : %s", package)
        return
    for mod in pkgutil.iter_modules(pkg.__path__):
        if mod.name.startswith("_"):
            continue
        full = f"{package}.{mod.name}"
        if full in _LOADED:
            continue
        try:
            importlib.import_module(full)
            _LOADED.add(full)
            log.debug("Plugin charge : %s", full)
        except Exception:
            log.exception("Plugin ignore (erreur au chargement) : %s", full)


def _import_user_dir(subdir: str) -> None:
    """Importe les plugins deposes par l'utilisateur hors du code source."""
    d = PLUGIN_USER_DIR / subdir
    if not d.is_dir():
        return
    for path in sorted(d.glob("*.py")):
        name = f"orion_user_{subdir}_{path.stem}"
        if name in _LOADED:
            continue
        try:
            spec = importlib.util.spec_from_file_location(name, path)
            if spec and spec.loader:
                module = importlib.util.module_from_spec(spec)
                sys.modules[name] = module
                spec.loader.exec_module(module)
                _LOADED.add(name)
                log.info("Plugin utilisateur charge : %s", path)
        except Exception:
            log.exception("Plugin utilisateur ignore : %s", path)


def _concrete_subclasses(base: Type[T]) -> list[Type[T]]:
    out: list[Type[T]] = []
    stack = list(base.__subclasses__())
    while stack:
        cls = stack.pop()
        stack.extend(cls.__subclasses__())
        # `abstract` n'est pris en compte que s'il est declare sur la classe
        # elle-meme : les sous-classes concretes n'ont rien a redefinir.
        if cls.__dict__.get("abstract", False):
            continue
        if not getattr(cls, "id", ""):
            continue
        out.append(cls)
    # ordre stable : priorite decroissante puis nom
    out.sort(key=lambda c: (-getattr(c, "priority", 50), c.__name__))
    return out


def discover(base: Type[T], package: str, user_subdir: str = "") -> list[T]:
    """Importe le paquet puis instancie toutes les implementations trouvees."""
    _import_package(package)
    if user_subdir:
        _import_user_dir(user_subdir)
    instances: list[T] = []
    for cls in _concrete_subclasses(base):
        try:
            instances.append(cls())
        except Exception:
            log.exception("Instanciation impossible : %s", cls.__name__)
    return instances


def available(instances: Iterable) -> list:
    """Filtre les plugins qui declarent ne pas pouvoir fonctionner ici."""
    out = []
    for p in instances:
        try:
            if p.available():
                out.append(p)
            else:
                log.debug("Plugin inactif sur cette machine : %s", getattr(p, "id", p))
        except Exception:
            log.exception("available() a echoue pour %s", getattr(p, "id", p))
    return out

