"""Compte Steam (officiel).

Connexion : « Se connecter via Steam » (OpenID 2.0), la methode publiee
par Valve pour les sites et applications tiers. Le joueur se connecte sur
la page de Steam ; ORION ne recoit que son identifiant Steam (SteamID64),
verifie ensuite aupres de Steam (`check_authentication`) pour qu'aucune
page ne puisse se faire passer pour lui.

Donnees : l'API Web officielle de Steam demande une cle. Chaque joueur
peut creer la sienne gratuitement (steamcommunity.com/dev/apikey) ; ORION
l'ouvre dans la meme fenetre, juste apres la connexion, et la garde
chiffree. Avec elle : profil, niveau, badges, XP, tous les jeux possedes
et leur temps de jeu, succes obtenus et manquants dans la langue du
joueur. La rarete mondiale des succes est publique (pas besoin de cle).
"""
from __future__ import annotations

from orion.core import region

import re
from urllib.parse import parse_qs, urlencode, urlparse

from ..core.logging_setup import get
from .base import ConnexionRequise, JeuCompte, Plateforme, Profil, Succes

log = get("comptes.steam")

OPENID = "https://steamcommunity.com/openid/login"
RETOUR = "https://orion.localhost/connexion/steam"
PAGE_CLE = "https://steamcommunity.com/dev/apikey"
API = "https://api.steampowered.com"
_ID_STEAM = re.compile(r"^https?://steamcommunity\.com/openid/id/(\d{17})$")


class Steam(Plateforme):
    id = "steam"
    nom = "Steam"
    nature = "officiel"
    apport = ("Tous vos jeux et leur temps de jeu, succes obtenus et manquants "
              "avec leur rarete, niveau, badges et XP.")

    # ------------------------------------------------------------------
    # connexion (OpenID 2.0)
    # ------------------------------------------------------------------
    def adresse_connexion(self) -> str:
        p = {
            "openid.ns": "http://specs.openid.net/auth/2.0",
            "openid.mode": "checkid_setup",
            "openid.return_to": RETOUR,
            "openid.realm": "https://orion.localhost/",
            "openid.identity": "http://specs.openid.net/auth/2.0/identifier_select",
            "openid.claimed_id": "http://specs.openid.net/auth/2.0/identifier_select",
        }
        return f"{OPENID}?{urlencode(p)}"

    def est_retour(self, adresse: str) -> bool:
        return adresse.startswith(RETOUR)

    def retour_connexion(self, adresse: str) -> dict:
        if adresse == "-":                        # etape « cle » seule
            return dict(self.secret())
        params = {k: v[0] for k, v in parse_qs(urlparse(adresse).query).items()}
        if params.get("openid.mode") != "id_res":
            raise ValueError("connexion annulee")
        m = _ID_STEAM.match(params.get("openid.claimed_id", ""))
        if not m:
            raise ValueError("reponse de Steam inattendue")
        if not self._verifier_openid(params):
            raise ValueError("Steam n'a pas confirme la connexion")
        ancien = {}
        try:
            ancien = self.secret()
        except ConnexionRequise:
            pass
        secret = {"steamid": m.group(1)}
        if ancien.get("steamid") == m.group(1) and ancien.get("cle"):
            secret["cle"] = ancien["cle"]           # meme compte : on garde la cle
        return secret

    @staticmethod
    def _verifier_openid(params: dict) -> bool:
        """Demande a Steam si la reponse vient bien de lui."""
        from ..core import reseau
        donnees = dict(params)
        donnees["openid.mode"] = "check_authentication"
        try:
            r = reseau.post(OPENID, data=donnees, timeout=15)
            return "is_valid:true" in r.text
        except Exception:
            log.exception("Verification OpenID impossible")
            return False

    def etape_apres_connexion(self) -> tuple[str, str] | None:
        if self.a_une_cle():
            return None
        return PAGE_CLE, (
            "Derniere etape : votre cle Web API Steam, personnelle et gratuite. Elle "
            "donne acces a vos jeux, succes, niveau et badges. Indiquez "
            "« orion.localhost » comme nom de domaine, acceptez les conditions puis "
            "« Enregistrer » (Steam peut demander une confirmation sur votre "
            "telephone). Si vous avez deja une cle, elle s'affiche directement : "
            "ORION la repere toute seule.")

    # -- cle Web API ------------------------------------------------------
    @staticmethod
    def cle_dans_page(texte: str) -> str:
        """La page steamcommunity.com/dev/apikey affiche « Key: XXXX »."""
        m = re.search(r"(?:Key|Cl[eé])\s*:\s*([0-9A-F]{32})", texte or "")
        return m.group(1) if m else ""


    def a_une_cle(self) -> bool:
        try:
            return bool(self.secret().get("cle"))
        except ConnexionRequise:
            return False

    # ------------------------------------------------------------------
    # API
    # ------------------------------------------------------------------
    def _api(self, chemin: str, **params) -> dict:
        from ..core import reseau
        s = self.secret()
        if not s.get("cle"):
            raise ConnexionRequise("cle Web API Steam manquante")
        params.setdefault("steamid", s["steamid"])
        params["key"] = s["cle"]
        params["format"] = "json"
        r = reseau.get(f"{API}/{chemin}", params=params, timeout=20)
        if r.status_code in (401, 403):
            raise ConnexionRequise("cle Web API Steam refusee")
        r.raise_for_status()
        return r.json() or {}

    def _lire_profil(self) -> Profil:
        s = self.secret()
        p = Profil(plateforme=self.id, id=s["steamid"],
                   adresse=f"https://steamcommunity.com/profiles/{s['steamid']}")
        if not s.get("cle"):
            p.extra["cle_manquante"] = True
            return p
        joueurs = self._api("ISteamUser/GetPlayerSummaries/v2/",
                            steamids=s["steamid"]).get("response", {}).get("players", [])
        if joueurs:
            j = joueurs[0]
            p.pseudo = j.get("personaname", "")
            p.avatar = j.get("avatarfull", "")
            p.adresse = j.get("profileurl", p.adresse)
            p.pays = j.get("loccountrycode", "")
            p.membre_depuis = float(j.get("timecreated") or 0)
            p.prive = j.get("communityvisibilitystate") != 3
        badges = self._api("IPlayerService/GetBadges/v1/").get("response", {})
        p.niveau = badges.get("player_level")
        p.xp = badges.get("player_xp")
        p.xp_prochain_niveau = badges.get("player_xp_needed_to_level_up")
        p.badges = len(badges.get("badges") or [])
        if p.niveau is None:
            p.niveau = self._api("IPlayerService/GetSteamLevel/v1/").get(
                "response", {}).get("player_level")
        return p

    def _lire_jeux(self) -> list[JeuCompte]:
        if not self.a_une_cle():
            return []
        rep = self._api("IPlayerService/GetOwnedGames/v1/", include_appinfo=1,
                        include_played_free_games=1, skip_unvetted_apps=0
                        ).get("response", {})
        jeux = []
        for g in rep.get("games") or []:
            appid = str(g.get("appid"))
            jeux.append(JeuCompte(
                plateforme=self.id, id=appid, titre=g.get("name") or appid,
                minutes=int(g.get("playtime_forever") or 0),
                minutes_2sem=int(g.get("playtime_2weeks") or 0),
                derniere_partie=float(g.get("rtime_last_played") or 0),
                image=(f"https://media.steampowered.com/steamcommunity/public/images/apps/"
                       f"{appid}/{g['img_icon_url']}.jpg" if g.get("img_icon_url") else "")))
        log.info("Steam : %d jeux sur le compte", len(jeux))
        return jeux

    def succes(self, jeu_id: str) -> list[Succes]:
        """Succes d'un jeu : obtenus, manquants, rarete (dans l'ordre du jeu)."""
        schema = self._api("ISteamUserStats/GetSchemaForGame/v2/", appid=jeu_id,
                           l=region.langue_steam()).get("game", {})
        definitions = ((schema.get("availableGameStats") or {}).get("achievements") or [])
        if not definitions:
            return []
        try:
            perso = self._api("ISteamUserStats/GetPlayerAchievements/v1/", appid=jeu_id,
                              l=region.langue_steam()).get("playerstats", {})
        except Exception as exc:
            # profil prive ou jeu jamais lance : on montre tout comme manquant
            log.info("Succes Steam %s indisponibles : %s", jeu_id, exc)
            perso = {}
        etat = {a["apiname"]: a for a in perso.get("achievements") or []}
        rarete = self.raretes(jeu_id)
        liste = []
        for d in definitions:
            a = etat.get(d["name"], {})
            liste.append(Succes(
                id=d["name"], nom=d.get("displayName") or d["name"],
                description=d.get("description", ""),
                obtenu=bool(a.get("achieved")), date=float(a.get("unlocktime") or 0),
                rarete=rarete.get(d["name"]), icone=d.get("icon", ""),
                icone_grise=d.get("icongray", ""), cache=bool(d.get("hidden"))))
        return liste

    @staticmethod
    def raretes(jeu_id: str) -> dict[str, float]:
        """% de joueurs ayant chaque succes (public, sans cle)."""
        from ..core import reseau
        try:
            donnees = reseau.get_json(
                f"{API}/ISteamUserStats/GetGlobalAchievementPercentagesForApp/v2/",
                garder=7 * 24 * 3600, params={"gameid": jeu_id}, timeout=15)
        except Exception:
            return {}
        return {a["name"]: round(float(a.get("percent") or 0), 1)
                for a in (donnees or {}).get("achievementpercentages", {}).get(
                    "achievements", [])}
