"""Petits utilitaires Windows (registre, VDF, tailles) tolerants hors Windows.

Tout renvoie des valeurs vides sur une plateforme non Windows, ce qui permet
de developper et de tester les modules sans plantage.
"""
from __future__ import annotations

import os
import re
import subprocess
from pathlib import Path
from typing import Any, Iterator

from .logging_setup import get
from .paths import is_windows

log = get("winutil")

try:                                    # pragma: no cover - dependant de l'OS
    import winreg                       # type: ignore
except ImportError:                     # pragma: no cover
    winreg = None                       # type: ignore

HKLM = "HKLM"
HKCU = "HKCU"

_ROOTS = {}
if winreg is not None:                  # pragma: no cover
    _ROOTS = {HKLM: winreg.HKEY_LOCAL_MACHINE, HKCU: winreg.HKEY_CURRENT_USER}

# vues 32/64 bits : beaucoup de jeux s'enregistrent en WOW6432Node
_VIEWS = ()
if winreg is not None:                  # pragma: no cover
    _VIEWS = (winreg.KEY_WOW64_64KEY, winreg.KEY_WOW64_32KEY)


def reg_open(root: str, path: str):
    """Ouvre une cle en essayant les vues 64 puis 32 bits. Renvoie None sinon."""
    if winreg is None or root not in _ROOTS:
        return None
    for view in _VIEWS:
        try:
            return winreg.OpenKey(_ROOTS[root], path, 0, winreg.KEY_READ | view)
        except OSError:
            continue
    return None


def reg_value(root: str, path: str, name: str, default: Any = "") -> Any:
    key = reg_open(root, path)
    if key is None:
        return default
    try:
        val, _ = winreg.QueryValueEx(key, name)     # type: ignore[union-attr]
        return val
    except OSError:
        return default
    finally:
        key.Close()


def reg_subkeys(root: str, path: str) -> list[str]:
    key = reg_open(root, path)
    if key is None:
        return []
    out: list[str] = []
    try:
        i = 0
        while True:
            try:
                out.append(winreg.EnumKey(key, i))   # type: ignore[union-attr]
                i += 1
            except OSError:
                break
    finally:
        key.Close()
    return out


def reg_values(root: str, path: str) -> dict[str, Any]:
    key = reg_open(root, path)
    if key is None:
        return {}
    out: dict[str, Any] = {}
    try:
        i = 0
        while True:
            try:
                name, val, _ = winreg.EnumValue(key, i)   # type: ignore[union-attr]
                out[name] = val
                i += 1
            except OSError:
                break
    finally:
        key.Close()
    return out


def reg_write_dword(root: str, path: str, name: str, value: int) -> bool:
    """Ecriture (utilisee uniquement apres validation explicite de l'utilisateur)."""
    if winreg is None or root not in _ROOTS:
        return False
    try:
        key = winreg.CreateKeyEx(_ROOTS[root], path, 0, winreg.KEY_SET_VALUE)  # type: ignore[union-attr]
        winreg.SetValueEx(key, name, 0, winreg.REG_DWORD, int(value))          # type: ignore[union-attr]
        key.Close()
        return True
    except OSError:
        log.exception("Ecriture registre refusee : %s\\%s\\%s", root, path, name)
        return False


def reg_type(root: str, path: str, name: str) -> int | None:
    """Type de la valeur (winreg.REG_DWORD, REG_SZ, REG_BINARY...), None si absente."""
    key = reg_open(root, path)
    if key is None:
        return None
    try:
        _val, typ = winreg.QueryValueEx(key, name)     # type: ignore[union-attr]
        return int(typ)
    except OSError:
        return None
    finally:
        key.Close()


def reg_write_binary(root: str, path: str, name: str, value: bytes) -> bool:
    """Valeur binaire : Unity range ainsi ses textes (« TemporalAntialiasing\\0 »)."""
    if winreg is None or root not in _ROOTS:
        return False
    try:
        key = winreg.CreateKeyEx(_ROOTS[root], path, 0, winreg.KEY_SET_VALUE)  # type: ignore[union-attr]
        winreg.SetValueEx(key, name, 0, winreg.REG_BINARY, bytes(value))       # type: ignore[union-attr]
        key.Close()
        return True
    except OSError:
        log.exception("Ecriture registre refusee : %s\\%s\\%s", root, path, name)
        return False


def reg_write_string(root: str, path: str, name: str, value: str) -> bool:
    if winreg is None or root not in _ROOTS:
        return False
    try:
        key = winreg.CreateKeyEx(_ROOTS[root], path, 0, winreg.KEY_SET_VALUE)  # type: ignore[union-attr]
        winreg.SetValueEx(key, name, 0, winreg.REG_SZ, str(value))             # type: ignore[union-attr]
        key.Close()
        return True
    except OSError:
        log.exception("Ecriture registre refusee : %s\\%s\\%s", root, path, name)
        return False


# --------------------------------------------------------------------------
# VDF (format de configuration de Valve)
# --------------------------------------------------------------------------

_VDF_TOKEN = re.compile(r'"((?:[^"\\]|\\.)*)"|([{}])')


def parse_vdf(text: str) -> dict:
    """Parseur VDF suffisant pour libraryfolders.vdf et les .acf."""
    root: dict = {}
    stack: list[dict] = [root]
    pending: str | None = None

    for m in _VDF_TOKEN.finditer(text):
        raw, brace = m.group(1), m.group(2)
        if brace == "{":
            node: dict = {}
            if pending is not None:
                stack[-1][pending] = node
                pending = None
            stack.append(node)
        elif brace == "}":
            if len(stack) > 1:
                stack.pop()
        else:
            value = (raw or "").replace('\\\\', '\\').replace('\\"', '"')
            if pending is None:
                pending = value
            else:
                stack[-1][pending] = value
                pending = None
    return root


def read_vdf(path: Path) -> dict:
    try:
        return parse_vdf(path.read_text("utf-8", errors="ignore"))
    except Exception:
        log.debug("VDF illisible : %s", path)
        return {}


# --------------------------------------------------------------------------
# Divers
# --------------------------------------------------------------------------

def dir_size(path: Path, limit_files: int = 40000) -> int:
    """Taille approximative d'un dossier (arret apres `limit_files` fichiers)."""
    total = n = 0
    try:
        for root, _dirs, files in os.walk(path):
            for f in files:
                try:
                    total += os.path.getsize(os.path.join(root, f))
                except OSError:
                    pass
                n += 1
                if n > limit_files:
                    return total
    except Exception:
        pass
    return total


def iter_exes(folder: Path, max_depth: int = 3) -> Iterator[Path]:
    """Parcourt les .exe d'un dossier avec une profondeur limitee."""
    base_depth = len(folder.parts)
    try:
        for root, dirs, files in os.walk(folder):
            depth = len(Path(root).parts) - base_depth
            if depth >= max_depth:
                dirs[:] = []
            for f in files:
                if f.lower().endswith(".exe"):
                    yield Path(root) / f
    except Exception:
        return


def run_powershell(script: str, timeout: int = 25) -> str:
    """Execute un script PowerShell et renvoie sa sortie (vide en cas d'echec)."""
    if not is_windows():
        return ""
    try:
        proc = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive",
             "-ExecutionPolicy", "Bypass", "-Command", script],
            capture_output=True, text=True, timeout=timeout,
            creationflags=0x08000000,          # CREATE_NO_WINDOW
        )
        return proc.stdout or ""
    except Exception:
        log.debug("PowerShell indisponible ou trop lent")
        return ""
