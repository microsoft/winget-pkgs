"""La demande de note sur le Microsoft Store (2.0.2).

Les notes font le classement du Store, et ORION n'en a aucune : on la
demande une fois, au cinquieme lancement, seulement pour une installation
venue du Store. Quelle que soit la reponse, la question ne revient jamais.
Rien n'est envoye : « Noter ORION » ouvre la page de notation du Store,
c'est le joueur qui ecrit ou non.
"""
from __future__ import annotations

from .core.config import CONFIG
from .core.logging_setup import get

log = get("note_store")

PRODUIT = "9P91GMXV7FPW"
ADRESSE = f"ms-windows-store://review/?ProductId={PRODUIT}"
SEUIL = 5


def compter_lancement() -> int:
    n = int(CONFIG.get("note.lancements", 0) or 0) + 1
    CONFIG.set("note.lancements", n)
    return n


def a_demander(depuis_store: bool | None = None) -> bool:
    if CONFIG.get("note.demandee", False):
        return False
    if int(CONFIG.get("note.lancements", 0) or 0) < SEUIL:
        return False
    if depuis_store is None:
        from . import maj
        depuis_store = maj.depuis_store()
    return bool(depuis_store)


def repondre(oui: bool) -> None:
    """Une seule fois, jamais plus : la reponse est notee quelle qu'elle soit."""
    CONFIG.set("note.demandee", True)
    if oui:
        try:
            import os
            os.startfile(ADRESSE)                      # Windows ouvre le Store a la page de notation
        except Exception:
            import webbrowser
            webbrowser.open(ADRESSE)
        log.info("Page de notation du Store ouverte")
