"""Outils de mise en page : vider proprement une liste reconstruite.

Presque toutes les pages d'ORION se reconstruisent en vidant leur
disposition puis en la remplissant a nouveau. Deux pieges de Qt guettent ce
geste anodin, et les deux ont ete rencontres en vrai :

1. `setParent(None)` ne detruit pas un widget, il le detache. Un widget
   sans parent est une **fenetre a part entiere** : cent lignes retirees,
   cent fenetres fantomes qui portent le nom et l'icone de l'application.
2. Un champ de saisie qui perd le focus pendant la destruction emet ses
   signaux d'edition (`editingFinished`). Si ce signal declenche la
   reconstruction de la liste, la reconstruction se rappelle elle-meme
   jusqu'a l'epuisement de la pile.

`clear_layout` neutralise les deux : les signaux sont coupes avant tout,
puis les widgets sont reellement detruits.
"""
from __future__ import annotations

from PySide6.QtWidgets import QLayout, QWidget


def clear_layout(layout: QLayout, keep: tuple[QWidget, ...] = ()) -> None:
    """Vide `layout` et detruit ses widgets.

    Les widgets listes dans `keep` sont conserves : ils sont simplement
    masques et retires de la disposition, pour pouvoir etre remis plus tard
    (le message « aucun element », typiquement).
    """
    gardes = set(keep)
    while layout.count():
        item = layout.takeAt(0)
        if item is None:
            break
        widget = item.widget()
        if widget is None:
            enfant = item.layout()
            if enfant is not None:
                clear_layout(enfant)
            continue

        if widget in gardes:
            # conserve : il garde son parent, on le sort juste de la vue
            widget.hide()
            continue

        # l'ordre compte : couper les signaux avant de toucher au parent
        widget.blockSignals(True)
        for descendant in widget.findChildren(QWidget):
            descendant.blockSignals(True)
        widget.hide()
        widget.setParent(None)
        widget.deleteLater()
