"""Page « Jeux gratuits » : ce qui est offert en ce moment, et jusqu'a quand.

La page tient en trois blocs :

1. un bandeau d'alerte, visible seulement quand une gratuite temporaire est
   arrivee a son terme alors que le jeu est encore installe : ORION propose
   alors de le desinstaller, et ouvre la page d'achat pour continuer ;
2. les filtres par nature de gratuite, qui est l'information decisive ;
3. la liste, la plus pressante en premier.
"""
from __future__ import annotations

from orion.affiliation import ouvreur  # liens de boutique (partenaires)

import time
from pathlib import Path

from PySide6.QtCore import QSize, Qt, QTimer, Signal
from PySide6.QtGui import QImageReader, QPixmap
from PySide6.QtWidgets import (QButtonGroup, QFrame, QHBoxLayout, QLabel,
                               QLineEdit, QProgressBar, QPushButton,
                               QVBoxLayout, QWidget)

from ...plugins.freebies.base import (A_GARDER, DEFINITIF, TEMPORAIRE,
                                      Freebie)
from ..theme import PALETTE
from ..widgets.game_card import placeholder, rounded
from ..widgets.layouts import clear_layout
from ..defilement import ZoneDefilante
from ..minuteur import plus_tard

ouvrir_lien = ouvreur("gratuits")   # d'ou vient le clic (compteur anonyme)

KIND_COLOR = {
    DEFINITIF: PALETTE["ok"],
    A_GARDER: PALETTE["accent"],
    TEMPORAIRE: PALETTE["warn"],
}

#: le bouton principal doit dire ce qui se passe vraiment
ACTION_LABELS = {
    DEFINITIF: "Ouvrir la boutique",
    A_GARDER: "Recuperer",
    TEMPORAIRE: "Jouer gratuitement",
}

ACTION_HINTS = {
    DEFINITIF: "Ce jeu est gratuit en permanence.",
    A_GARDER: "Une fois ajoute au compte, le jeu reste acquis pour toujours.",
    TEMPORAIRE: ("Acces temporaire : passee la date, il faudra acheter le jeu "
                 "pour continuer a y jouer."),
}

#: ce que la suppression coute reellement, selon la nature de la gratuite
REMOVE_HINTS = {
    DEFINITIF: ("Suppression complete : sauvegarde archivee puis "
                "desinstallation. Le jeu etant gratuit en permanence, il "
                "reste reinstallable quand vous voulez."),
    A_GARDER: ("Suppression complete : sauvegarde archivee puis "
               "desinstallation. Le jeu reste acquis sur votre compte et "
               "pourra etre retelecharge."),
    TEMPORAIRE: ("Suppression complete : sauvegarde archivee puis "
                 "desinstallation. La periode gratuite passee, il faudra "
                 "acheter le jeu pour y rejouer."),
}

FILTERS = (
    ("", "Tout"),
    (A_GARDER, "A recuperer"),
    (DEFINITIF, "Gratuits pour toujours"),
    (TEMPORAIRE, "Temporaires"),
)


def _tag(text: str, color: str = "", strong: bool = False) -> QLabel:
    """Petite etiquette coloree."""
    lab = QLabel(text)
    weight = "700" if strong else "600"
    tint = color or PALETTE["text_dim"]
    lab.setStyleSheet(
        f"color:{tint}; font-size:10px; font-weight:{weight};"
        f" letter-spacing:.5px; border:1px solid {tint};"
        " border-radius:4px; padding:2px 7px;")
    return lab


#: jaquettes deja reduites : (fichier, date, largeur, hauteur) -> image
_MINIATURES: dict[tuple, QPixmap] = {}


def miniature(chemin: str, taille: QSize) -> QPixmap:
    """La jaquette, lue directement a petite taille et gardee en memoire.

    Chaque ligne relisait sa jaquette en entier (600 x 900) pour l'afficher en
    58 x 87 : trente offres figeaient la fenetre 0,7 s a chaque passage de la
    veille (journal de l'auteur, 7 octobre 2026). Un JPEG se decode quatre a
    huit fois plus vite quand on le demande petit."""
    try:
        cle = (chemin, Path(chemin).stat().st_mtime, taille.width(), taille.height())
    except OSError:
        return QPixmap()
    pix = _MINIATURES.get(cle)
    if pix is None:
        lecteur = QImageReader(chemin)
        lecteur.setAutoTransform(True)
        origine = lecteur.size()
        if origine.isValid() and origine.width() > taille.width() * 2:
            lecteur.setScaledSize(origine.scaled(
                taille * 2, Qt.AspectRatioMode.KeepAspectRatioByExpanding))
        pix = QPixmap.fromImage(lecteur.read())
        if len(_MINIATURES) > 400:
            _MINIATURES.clear()
        _MINIATURES[cle] = pix
    return pix


class FreeRow(QFrame):
    """Une offre : visuel, nature, echeance, details et actions."""

    claim_requested = Signal(str)
    dismiss_requested = Signal(str)
    buy_requested = Signal(str)
    uninstall_requested = Signal(str)
    remove_requested = Signal(str)

    def __init__(self, item: Freebie, art: str = "", installed: bool = False,
                 size_gb: float = 0.0, parent=None) -> None:
        super().__init__(parent)
        self.item = item
        self.setObjectName("Panel")

        lay = QHBoxLayout(self)
        lay.setContentsMargins(14, 12, 14, 12)
        lay.setSpacing(16)

        cover = QLabel()
        size = QSize(58, 87)
        cover.setFixedSize(size)
        pix = miniature(art, size) if art else QPixmap()
        cover.setPixmap(rounded(pix, size) if not pix.isNull()
                        else placeholder(item.title, size, item.steam_appid))
        lay.addWidget(cover)

        info = QVBoxLayout()
        info.setSpacing(5)

        # -- titre et nature de la gratuite -----------------------------
        head = QHBoxLayout()
        head.setSpacing(9)
        title = QLabel(item.title)
        title.setObjectName("Value")
        head.addWidget(title)
        head.addWidget(_tag(item.kind_label.upper(),
                            KIND_COLOR.get(item.kind, ""), strong=True))
        if item.claimed:
            head.addWidget(_tag("RECUPERE", PALETTE["ok"]))
        if installed:
            head.addWidget(_tag(
                f"INSTALLE - {size_gb:.0f} GO" if size_gb >= 1 else "INSTALLE",
                PALETTE["text_dim"]))
        head.addStretch(1)
        info.addLayout(head)

        # -- echeance, boutique, prix, accueil --------------------------
        # ligne assemblee a la main : chaque morceau passe par la traduction
        from ...i18n import t
        bits = [item.shop]
        deadline = item.deadline_label
        bits.append(t(deadline))
        if item.genre_label:
            bits.append(item.genre_label)
        if item.release_date:
            bits.append(t(f"sorti le {item.release_date}"))
        if item.worth:
            bits.append(t(f"habituellement {item.worth_label}"))
        if item.price_before and abs(item.price_before - item.worth) > 0.01:
            bits.append(t(f"encore {item.price_before_label} avant l'offre"))
        if item.review_score:
            label = t(f"{item.review_score} % d'avis positifs")
            if item.review_label:
                label += f" ({t(item.review_label.lower())})"
            bits.append(label)
        if item.metacritic:
            bits.append(f"Metacritic {item.metacritic}")
        line = QLabel("   -   ".join(b for b in bits if b))
        line.setObjectName("Faint")
        if item.urgent:
            line.setStyleSheet(f"color:{PALETTE['warn']}; font-size:11px;")
        line.setWordWrap(True)
        info.addWidget(line)

        # -- modes de jeu et plateformes --------------------------------
        tags = QHBoxLayout()
        tags.setSpacing(6)
        for mode in item.modes[:5]:
            tags.addWidget(_tag(mode))
        for plat in item.platforms:
            tags.addWidget(_tag(plat, PALETTE["text_faint"]))
        if not item.modes and not item.platforms:
            unknown = QLabel("details non publies par la boutique")
            unknown.setObjectName("Faint")
            tags.addWidget(unknown)
        tags.addStretch(1)
        info.addLayout(tags)

        # -- conditions d'obtention -------------------------------------
        conditions = item.conditions_label
        if conditions:
            bloc = QHBoxLayout()
            bloc.setSpacing(7)
            etiquette = QLabel("Pour l'obtenir")
            etiquette.setStyleSheet(
                f"color:{PALETTE['warn']}; font-size:10px; font-weight:700;"
                " letter-spacing:.6px;")
            etiquette.setAlignment(Qt.AlignmentFlag.AlignTop)
            bloc.addWidget(etiquette)
            texte = QLabel(conditions)
            texte.setObjectName("Dim")
            texte.setWordWrap(True)
            bloc.addWidget(texte, 1)
            info.addLayout(bloc)

        # -- photos du jeu ----------------------------------------------
        if item.shots_local:
            photos = QHBoxLayout()
            photos.setSpacing(7)
            for chemin in item.shots_local[:3]:
                vignette = QLabel()
                taille = QSize(152, 71)
                vignette.setFixedSize(taille)
                pix = QPixmap(chemin)
                if not pix.isNull():
                    vignette.setPixmap(rounded(pix, taille, radius=6))
                    photos.addWidget(vignette)
            photos.addStretch(1)
            info.addLayout(photos)

        lay.addLayout(info, 1)

        # -- actions ----------------------------------------------------
        actions = QVBoxLayout()
        actions.setSpacing(7)
        if item.upcoming:
            soon = QPushButton("Voir la fiche")
            soon.setObjectName("Ghost")
            soon.clicked.connect(self._open)
            actions.addWidget(soon)
        else:
            grab = QPushButton(ACTION_LABELS.get(item.kind, "Recuperer"))
            grab.setToolTip(ACTION_HINTS.get(item.kind, ""))
            grab.clicked.connect(
                lambda: self.claim_requested.emit(self.item.key))
            actions.addWidget(grab)

        if installed:
            # Le jeu est deja sur le disque : la seule action utile qui reste
            # est de le supprimer. Le libelle dit ce qu'on perd vraiment, qui
            # depend entierement de la nature de la gratuite.
            remove = QPushButton("Supprimer du disque")
            remove.setObjectName("Ghost")
            remove.setToolTip(REMOVE_HINTS.get(item.kind, ""))
            remove.clicked.connect(
                lambda: self.remove_requested.emit(self.item.key))
            actions.addWidget(remove)

        hide = QPushButton("Masquer")
        hide.setObjectName("Ghost")
        hide.clicked.connect(lambda: self.dismiss_requested.emit(self.item.key))
        actions.addWidget(hide)
        actions.addStretch(1)
        lay.addLayout(actions)

    def _open(self) -> None:
        if self.item.url:
            ouvrir_lien(self.item.url)


class ExpiredRow(QFrame):
    """Un jeu pris pendant une gratuite temporaire, desormais terminee."""

    buy_requested = Signal(str)
    uninstall_requested = Signal(str)
    keep_requested = Signal(str)

    def __init__(self, item: Freebie, game_title: str, size_gb: float,
                 parent=None) -> None:
        super().__init__(parent)
        self.item = item
        self.setObjectName("Panel")
        self.setStyleSheet(
            f"QFrame#Panel {{ border-left: 3px solid {PALETTE['warn']}; }}")

        lay = QHBoxLayout(self)
        lay.setContentsMargins(16, 13, 16, 13)
        lay.setSpacing(16)

        info = QVBoxLayout()
        info.setSpacing(4)
        title = QLabel(game_title)
        title.setObjectName("Value")
        info.addWidget(title)

        detail = QLabel(
            f"La periode gratuite est terminee : le jeu n'est plus jouable. "
            f"Il occupe {size_gb:.0f} Go."
            + (f" Prix habituel : {item.worth_label}." if item.worth else ""))
        detail.setObjectName("Dim")
        detail.setWordWrap(True)
        info.addWidget(detail)
        lay.addLayout(info, 1)

        buy = QPushButton("Acheter le jeu")
        buy.setToolTip("Ouvre la page d'achat, pour continuer a y jouer.")
        buy.clicked.connect(lambda: self.buy_requested.emit(self.item.key))
        lay.addWidget(buy)

        remove = QPushButton("Desinstaller")
        remove.setObjectName("Ghost")
        remove.setToolTip("ORION archive la sauvegarde, ouvre le "
                          "desinstalleur de la plateforme, puis propose la "
                          "page d'achat.")
        remove.clicked.connect(
            lambda: self.uninstall_requested.emit(self.item.key))
        lay.addWidget(remove)

        keep = QPushButton("Garder quand meme")
        keep.setObjectName("Ghost")
        keep.clicked.connect(lambda: self.keep_requested.emit(self.item.key))
        lay.addWidget(keep)


class FreeView(QWidget):
    refresh_requested = Signal()
    claim_requested = Signal(str)
    dismiss_requested = Signal(str)
    buy_requested = Signal(str)
    uninstall_requested = Signal(str)
    remove_requested = Signal(str)
    keep_requested = Signal(str)
    filter_changed = Signal(str, str)      # nature, recherche

    #: lignes construites tout de suite, puis taille des lots suivants
    PREMIERES = 6
    PAR_LOT = 4
    #: vrai en service (pose par `app.main`) : les lignes au-dela des
    #: premieres sont construites par lots, sans figer la fenetre
    etaler = False

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._tour = 0
        self._kind = ""

        root = QVBoxLayout(self)
        root.setContentsMargins(24, 18, 24, 18)
        root.setSpacing(13)

        self._racine = root
        bar = QHBoxLayout()
        title = QLabel("Jeux gratuits")
        title.setObjectName("PageTitle")
        bar.addWidget(title)
        self.titre_page = title
        self.summary = QLabel("")
        self.summary.setObjectName("PageHint")
        bar.addWidget(self.summary)
        bar.addStretch(1)

        self.search = QLineEdit()
        self.search.setObjectName("Search")
        self.search.setPlaceholderText("Filtrer par nom...")
        self.search.setFixedWidth(220)
        # la page attend la fin de la frappe avant de se reconstruire
        self._frappe = QTimer(self)
        self._frappe.setSingleShot(True)
        self._frappe.setInterval(180)
        self._frappe.timeout.connect(self._emit_filter)
        self.search.textChanged.connect(lambda _t: self._frappe.start())
        bar.addWidget(self.search)

        self.refresh = QPushButton("Chercher maintenant")
        self.refresh.clicked.connect(self.refresh_requested.emit)
        bar.addWidget(self.refresh)
        root.addLayout(bar)

        chips = QHBoxLayout()
        chips.setSpacing(8)
        self.group = QButtonGroup(self)
        self.group.setExclusive(True)
        for key, label in FILTERS:
            btn = QPushButton(label)
            btn.setObjectName("Chip")
            btn.setCheckable(True)
            btn.setChecked(key == "")
            btn.clicked.connect(lambda _=False, k=key: self._set_kind(k))
            self.group.addButton(btn)
            chips.addWidget(btn)
        chips.addStretch(1)
        self.updated = QLabel("")
        self.updated.setObjectName("Faint")
        chips.addWidget(self.updated)
        root.addLayout(chips)

        self.progress = QProgressBar()
        self.progress.setVisible(False)
        self.progress.setTextVisible(False)
        root.addWidget(self.progress)

        self.expired_box = QWidget()
        self.expired_layout = QVBoxLayout(self.expired_box)
        self.expired_layout.setContentsMargins(0, 0, 0, 0)
        self.expired_layout.setSpacing(8)
        self.expired_box.setVisible(False)
        root.addWidget(self.expired_box)

        scroll = ZoneDefilante()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        root.addWidget(scroll, 1)
        body = QWidget()
        scroll.setWidget(body)
        self.rows = QVBoxLayout(body)
        self.rows.setContentsMargins(0, 0, 8, 0)
        self.rows.setSpacing(9)

        self.empty = QLabel(
            "Aucune offre connue pour l'instant.\n\n"
            "ORION interroge les boutiques et les agregateurs publics "
            "plusieurs fois par jour. Lancez une recherche pour voir ce qui "
            "est offert en ce moment.")
        self._texte_vide = self.empty.text()
        self.empty.setObjectName("Dim")
        self.empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.rows.addWidget(self.empty)

    # ------------------------------------------------------------------
    def integrer(self) -> None:
        """Vue placee dans l'onglet « Gratuits » de la Boutique : le titre de
        la page suffit, marges alignees sur celles de l'en-tete."""
        self.titre_page.hide()
        self._racine.setContentsMargins(28, 8, 28, 18)

    def _set_kind(self, kind: str) -> None:
        self._kind = kind
        self._emit_filter()

    def _emit_filter(self) -> None:
        self.filter_changed.emit(self._kind, self.search.text().strip())

    def _ligne(self, item, arts: dict[str, str], installed: dict[str, float]) -> FreeRow:
        row = FreeRow(item, arts.get(item.key, ""),
                      item.key in installed,
                      float(installed.get(item.key) or 0.0))
        row.claim_requested.connect(self.claim_requested.emit)
        row.dismiss_requested.connect(self.dismiss_requested.emit)
        row.buy_requested.connect(self.buy_requested.emit)
        row.remove_requested.connect(self.remove_requested.emit)
        return row

    def _suite_des_lignes(self, tour: int, reste: list, arts, installed) -> None:
        """Les lignes suivantes, par petits lots : l'affichage respire entre
        deux lots, et une liste arrivee entre-temps annule celle-ci."""
        if tour != self._tour or not reste:
            return
        for item in reste[:self.PAR_LOT]:
            # avant l'espace elastique qui ferme la liste
            self.rows.insertWidget(self.rows.count() - 1, self._ligne(item, arts, installed))
        plus_tard(self, 12, lambda: self._suite_des_lignes(
            tour, reste[self.PAR_LOT:], arts, installed))

    def _construire_lignes(self, items, arts: dict[str, str], installed: dict[str, float]) -> None:
        clear_layout(self.rows, keep=(self.empty,))
        self._tour += 1
        # en service, seules les premieres lignes (celles qu'on voit) sont
        # construites tout de suite ; les essais gardent tout d'un bloc
        tout_de_suite = items if not self.etaler else items[:self.PREMIERES]
        for item in tout_de_suite:
            self.rows.addWidget(self._ligne(item, arts, installed))
        reste = list(items[len(tout_de_suite):])
        if reste:
            plus_tard(self, 12, lambda t=self._tour: self._suite_des_lignes(
                t, reste, arts, installed))

        if not items:
            cherche = self.search.text().strip()
            if cherche:
                from ...i18n import t as _t
                self.empty.setText(_t(f"Aucun jeu gratuit ne correspond a « {cherche} »."))
            else:
                self.empty.setText(self._texte_vide)
            self.rows.addWidget(self.empty)
            self.empty.setVisible(True)
        self.rows.addStretch(1)

    # ------------------------------------------------------------------
    def set_items(self, items: list[Freebie], arts: dict[str, str],
                  installed: dict[str, float], counts: dict[str, int],
                  last_refresh: float = 0.0) -> None:
        # les lignes ne sont reconstruites que si ce qu'elles montrent a
        # change : la veille des gratuits repasse toutes les quelques heures
        # et rend presque toujours la meme liste (reconstruire trente lignes
        # et relire leurs images figeait la fenetre un quart de seconde)
        etat = (tuple(repr(i) for i in items),
                tuple(arts.get(i.key, "") for i in items),
                tuple((i.key in installed, float(installed.get(i.key) or 0.0)) for i in items),
                self.search.text().strip() if not items else "")
        if etat != getattr(self, "_etat_lignes", None):
            self._etat_lignes = etat
            self._construire_lignes(items, arts, installed)

        from ...i18n import t      # assemble a la main : chaque morceau est traduit
        total = sum(counts.values())
        parts = []
        if counts.get(A_GARDER):
            parts.append(t(f"{counts[A_GARDER]} a recuperer"))
        if counts.get(TEMPORAIRE):
            parts.append(t(f"{counts[TEMPORAIRE]} temporaire(s)"))
        if counts.get(DEFINITIF):
            parts.append(t(f"{counts[DEFINITIF]} gratuit(s) pour toujours"))
        self.summary.setText(t(f"{total} offre(s)")
                             + ("  -  " + ", ".join(parts) if parts else ""))

        if last_refresh:
            self.updated.setText("derniere recherche : " + time.strftime(
                "%d/%m a %H:%M", time.localtime(last_refresh)))

    def set_expired(self, entries: list[tuple[Freebie, str, float]]) -> None:
        """Bloc d'alerte des gratuites temporaires arrivees a terme."""
        clear_layout(self.expired_layout)

        self.expired_box.setVisible(bool(entries))
        if not entries:
            return

        head = QLabel("Ces jeux n'etaient gratuits que pour un temps")
        head.setObjectName("Value")
        head.setStyleSheet(f"color:{PALETTE['warn']};")
        self.expired_layout.addWidget(head)

        for item, game_title, size_gb in entries:
            row = ExpiredRow(item, game_title, size_gb)
            row.buy_requested.connect(self.buy_requested.emit)
            row.uninstall_requested.connect(self.uninstall_requested.emit)
            row.keep_requested.connect(self.keep_requested.emit)
            self.expired_layout.addWidget(row)

    def set_progress(self, message: str, percent: int) -> None:
        running = 0 <= percent < 100
        self.progress.setVisible(running)
        self.refresh.setEnabled(not running)
        if running:
            self.progress.setValue(max(percent, 1))
        if message:
            self.updated.setText(message)
