"""Execution en arriere-plan sans bloquer l'interface."""
from __future__ import annotations

import sys
import time
from typing import Any, Callable

from PySide6.QtCore import QCoreApplication, QObject, QRunnable, QThreadPool, Signal, Slot

from .logging_setup import get

log = get("tasks")

#: Les taches en cours sont conservees ici : sans cela, l'objet Python peut
#: etre liberé avant que ses signaux n'aient ete delivres a l'interface.
_ACTIVE: list["Task"] = []


#: ORION se ferme : plus aucune tache n'est lancee, et celles qui echouent
#: parce que l'application disparait sous elles ne sont pas des erreurs
_fermeture = False


def fermer() -> None:
    """A appeler quand l'application quitte (`aboutToQuit`)."""
    global _fermeture
    _fermeture = True


def en_fermeture() -> bool:
    return _fermeture or sys.is_finalizing()


def _purge() -> None:
    now = time.time()
    for t in list(_ACTIVE):
        if t.finished_at and (now - t.finished_at) > 20:
            _ACTIVE.remove(t)


class _Signals(QObject):
    finished = Signal(object)
    failed = Signal(str)
    progress = Signal(str, int)


class Task(QRunnable):
    """Enveloppe une fonction pour l'executer dans le pool de threads.

        t = Task(ma_fonction, arg1, kwarg=2)
        t.signals.finished.connect(on_done)
        t.start()

    Si la fonction accepte un parametre `progress_cb`, il lui est fourni
    automatiquement et relaie l'avancement vers le signal `progress`.
    """

    def __init__(self, fn: Callable[..., Any], *args, **kwargs) -> None:
        super().__init__()
        self.fn, self.args, self.kwargs = fn, args, kwargs
        # le parent garantit la survie de l'objet jusqu'a la livraison
        self.signals = _Signals(QCoreApplication.instance())
        self.finished_at = 0.0
        self.setAutoDelete(True)

        self._inject_progress(fn)

    def _inject_progress(self, fn: Callable[..., Any]) -> None:
        """Fournit `progress_cb` a la fonction, si elle en accepte un.

        L'injection est ignoree quand l'appelant a deja renseigne ce
        parametre — y compris par position, ce qui provoquait sinon un
        « got multiple values for argument 'progress_cb' » a l'execution
        plutot qu'a l'ecriture du code.
        """
        code = getattr(fn, "__code__", None)
        if code is None or "progress_cb" not in code.co_varnames:
            return
        if "progress_cb" in self.kwargs:
            return
        names = list(code.co_varnames[:code.co_argcount])
        if hasattr(fn, "__self__") and names and names[0] == "self":
            names = names[1:]          # methode liee : `self` est deja fourni
        try:
            if len(self.args) > names.index("progress_cb"):
                return                 # deja passe par position
        except ValueError:
            return
        self.kwargs["progress_cb"] = self._progress

    def _progress(self, message: str, percent: int = -1) -> None:
        try:
            self.signals.progress.emit(message, percent)
        except RuntimeError:           # tache terminee : objet des signaux libere
            pass

    @Slot()
    def run(self) -> None:
        try:
            result = self.fn(*self.args, **self.kwargs)
        except Exception as exc:                       # pragma: no cover
            self.finished_at = time.time()
            if en_fermeture():
                # l'application se ferme sous la tache (pool de fils arrete,
                # fenetre detruite) : un abandon, pas une erreur a signaler
                log.debug("Tache abandonnee a la fermeture : %s (%s)",
                          getattr(self.fn, "__name__", self.fn), exc)
                return
            log.exception("Tache en echec : %s",
                          getattr(self.fn, "__name__", self.fn))
            self.signals.failed.emit(str(exc))
        else:
            self.finished_at = time.time()
            self.signals.finished.emit(result)
        finally:
            # L'objet des signaux est libere une fois ses signaux livres : sa
            # destruction differee est postee dans le fil de l'interface
            # APRES les appels en file deja emis, qui passent donc avant.
            # Sans cela, chaque tache laissait un QObject (et les fonctions
            # connectees) attache a l'application jusqu'a sa fermeture.
            try:
                self.signals.deleteLater()
            except RuntimeError:
                pass

    def start(self, pool: QThreadPool | None = None) -> "Task":
        if en_fermeture():
            return self                # ORION se ferme : rien n'est lance
        _purge()
        _ACTIVE.append(self)
        (pool or QThreadPool.globalInstance()).start(self)
        return self
