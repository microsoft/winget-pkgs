"""Tableaux de reference : puissance relative des cartes graphiques et des
processeurs en jeu.

Indices approximatifs, etablis a partir des classements de performances
relatives publies par la presse specialisee (bancs d'essai en 1440p pour
les cartes graphiques, moyenne de jeux pour les processeurs). Ils servent a
COMPARER deux composants (celui du joueur et celui demande par un jeu), pas
a predire un nombre d'images exact : c'est pourquoi toute estimation qui en
decoule est affichee en fourchette prudente et etiquetee « Estime ».

Cartes graphiques : RTX 4090 = 100. Processeurs : Ryzen 7 9800X3D = 100.
"""
from __future__ import annotations

import re

GPU: dict[str, float] = {
    # NVIDIA RTX 50
    "rtx 5090": 130, "rtx 5080": 84, "rtx 5070 ti": 74, "rtx 5070": 58,
    "rtx 5060 ti": 42, "rtx 5060": 35, "rtx 5050": 26,
    # RTX 40
    "rtx 4090": 100, "rtx 4080 super": 81, "rtx 4080": 79, "rtx 4070 ti super": 69,
    "rtx 4070 ti": 63, "rtx 4070 super": 58, "rtx 4070": 50, "rtx 4060 ti": 38,
    "rtx 4060": 31, "rtx 4050": 24,
    # RTX 30
    "rtx 3090 ti": 62, "rtx 3090": 55, "rtx 3080 ti": 53, "rtx 3080": 49,
    "rtx 3070 ti": 41, "rtx 3070": 38, "rtx 3060 ti": 33, "rtx 3060": 26,
    "rtx 3050": 18,
    # RTX 20 / GTX 16
    "rtx 2080 ti": 37, "rtx 2080 super": 32, "rtx 2080": 30, "rtx 2070 super": 28,
    "rtx 2070": 24, "rtx 2060 super": 22, "rtx 2060": 19,
    "gtx 1660 ti": 16, "gtx 1660 super": 16, "gtx 1660": 14, "gtx 1650 super": 12,
    "gtx 1650": 9,
    # GTX 10 / 900 / 700
    "gtx 1080 ti": 25, "gtx 1080": 19, "gtx 1070 ti": 17.5, "gtx 1070": 15.5,
    "gtx 1060 6gb": 11.5, "gtx 1060 3gb": 10.5, "gtx 1060": 11, "gtx 1050 ti": 6.5,
    "gtx 1050": 5, "gt 1030": 2.5,
    "gtx 980 ti": 14, "gtx 980": 11, "gtx 970": 9, "gtx 960": 6.5, "gtx 950": 5,
    "gtx 780 ti": 7.5, "gtx 780": 6.5, "gtx 770": 5, "gtx 760": 4, "gtx 750 ti": 3,
    "gtx 680": 4.5, "gtx 670": 4, "gtx 660": 3, "gtx 650": 1.8,
    # AMD RX 9000 / 7000 / 6000
    "rx 9070 xt": 72, "rx 9070": 65, "rx 9060 xt": 40,
    "rx 7900 xtx": 82, "rx 7900 xt": 70, "rx 7900 gre": 60, "rx 7800 xt": 55,
    "rx 7700 xt": 46, "rx 7600 xt": 32, "rx 7600": 30,
    "rx 6950 xt": 58, "rx 6900 xt": 54, "rx 6800 xt": 50, "rx 6800": 43,
    "rx 6750 xt": 38, "rx 6700 xt": 36, "rx 6700": 32, "rx 6650 xt": 29,
    "rx 6600 xt": 28, "rx 6600": 24, "rx 6500 xt": 11, "rx 6400": 8,
    # AMD RX 5000 / Vega / Polaris / R9
    "rx 5700 xt": 24, "rx 5700": 21, "rx 5600 xt": 19, "rx 5500 xt": 12,
    "radeon vii": 23, "vega 64": 18, "vega 56": 16,
    "rx 590": 13, "rx 580": 12, "rx 570": 10.5, "rx 480": 11.5, "rx 470": 10,
    "rx 560": 6.5, "rx 550": 4,
    "r9 fury x": 12, "r9 fury": 11, "r9 390x": 11, "r9 390": 10, "r9 290x": 9.5,
    "r9 290": 9, "r9 380": 7, "r9 280x": 7, "r9 280": 6, "r9 270x": 5, "r7 370": 4.5,
    "hd 7970": 6.5, "hd 7950": 5.5, "hd 7870": 4.5, "hd 7850": 3.8,
    # Intel Arc
    "arc b580": 32, "arc b570": 28, "arc a770": 29, "arc a750": 27, "arc a580": 23,
    "arc a380": 9, "arc a310": 6,
    # cartes de bureau d'entree de gamme ou de constructeur
    "rx 9060": 34, "rx 7650 gre": 31, "rx 6300": 5.5, "rx 5300": 8, "rx 460": 4.5,
    "gtx 1630": 5.5, "gtx 750": 2.4, "gt 730": 1, "gt 710": 0.6,
}

#: puces qui n'existent que dans les portables. L'indice est celui de la puce
#: telle qu'elle est montee (pas de reduction « portable » en plus, sauf si
#: Windows ajoute « Laptop GPU » au nom). Jamais citees en exemple d'achat.
GPU_PORTABLES: dict[str, float] = {
    "rtx 3050 ti": 20, "rtx 2050": 10, "gtx 1650 ti": 9.5,
    "mx 570": 8, "mx 550": 5.5, "mx 450": 4.8, "mx 350": 3.4, "mx 330": 2.8,
    "mx 250": 2.6, "mx 150": 2.4, "mx 130": 1.3,
    "rx 7700s": 27, "rx 7600m xt": 25, "rx 7600m": 22, "rx 7600s": 21,
    "rx 6850m xt": 34, "rx 6800m": 33, "rx 6800s": 28, "rx 6700m": 27,
    "rx 6700s": 24, "rx 6650m": 21, "rx 6600m": 20, "rx 6600s": 19, "rx 6500m": 9,
    "rx 5700m": 17, "rx 5600m": 15, "rx 5500m": 9, "rx 5300m": 7,
    "arc a770m": 22, "arc a730m": 17, "arc a570m": 13, "arc a550m": 12,
    "arc a370m": 7, "arc a350m": 5,
}

#: graphiques integres au processeur. Jamais cites en exemple d'achat.
GPU_INTEGREES: dict[str, float] = {
    "radeon 8060s": 30, "radeon 8050s": 22,
    "radeon 890m": 11, "radeon 880m": 10, "radeon 860m": 8, "radeon 840m": 5,
    "radeon 780m": 9, "radeon 760m": 7.5, "radeon 740m": 5, "radeon 680m": 7,
    "radeon 660m": 5, "radeon 610m": 1.5,
    "vega 11": 3.8, "vega 10": 3.5, "vega 8": 3.2, "vega 7": 3, "vega 6": 2.6,
    "vega 3": 1.6,
    "arc 140v": 9, "arc 140t": 8, "arc 130v": 7, "arc 130t": 6.5, "arc graphics": 6,
    "iris xe": 3, "iris plus": 2, "iris graphics": 1.5, "iris pro": 1.5,
    "uhd graphics": 1.5, "hd graphics": 1,
    # « Intel(R) Graphics » et « AMD Radeon(TM) Graphics » : Windows ne dit
    # pas lequel ; valeur d'une puce integree courante
    "intel graphics": 3.5, "radeon graphics": 3.5,
}

#: references qu'on ne peut pas acheter seules
HORS_VENTE = frozenset(GPU_PORTABLES) | frozenset(GPU_INTEGREES)
GPU.update(GPU_PORTABLES)
GPU.update(GPU_INTEGREES)

CPU_AMD: dict[str, float] = {
    "9800x3d": 100, "9950x3d": 98, "9900x3d": 94, "7800x3d": 90, "7950x3d": 90,
    "7900x3d": 86, "9950x": 84, "9900x": 82, "9700x": 82, "9600x": 80, "7950x": 82,
    "7900x": 80, "7700x": 79, "7700": 77, "7600x": 76, "7600": 74, "8700g": 66,
    "8600g": 62, "5800x3d": 74, "5700x3d": 71, "5950x": 66, "5900x": 66,
    "5800x": 64, "5700x": 62, "5800": 62, "5600x": 61, "5700g": 56, "5600g": 54,
    "5600": 59, "5500": 52, "3950x": 53, "3900x": 52, "3800x": 50, "3700x": 50,
    "3600x": 48, "3600": 47, "3400g": 36, "3300x": 45, "3100": 40, "2700x": 40,
    "2700": 38, "2600x": 38, "2600": 37, "2400g": 30, "1800x": 33, "1700x": 32,
    "1700": 31, "1600x": 32, "1600": 31, "1500x": 28, "1400": 26, "1200": 24,
    "fx 8350": 18, "fx 8320": 17, "fx 6300": 14, "fx 4300": 10,
    # bureau, complements
    "7600x3d": 86, "7500f": 74, "7400f": 70, "9600": 79, "8500g": 52, "8400f": 60,
    "5900xt": 64, "5800xt": 64, "5700": 58, "5600x3d": 68, "5600xt": 61, "5600t": 60,
    "4600g": 46, "4650g": 46, "4500": 44, "3500x": 44, "3500": 43, "3200g": 30,
    "2200g": 27, "1300x": 25,
}
#: portables (jamais proposes a l'achat : un processeur de portable ne se
#: change pas)
CPU_AMD_PORTABLES: dict[str, float] = {
    # portables : indice de la puce de bureau equivalente ; `indice_cpu` retire
    # 15 % quand le nom porte un suffixe de portable (H, HS, HX, U...)
    "9955": 96, "7945": 90, "7845": 86, "8945": 76, "8845": 73, "8840": 72,
    "8645": 68, "8640": 66, "7940": 74, "7840": 72, "7640": 68, "7735": 60,
    "7730": 56, "7535": 56, "7530": 54, "7435": 58, "7235": 55, "7520": 30,
    "7320": 28, "6900": 62, "6800": 60, "6600": 56, "5900": 64, "5625": 52,
    "5825": 56, "4900": 54, "4800": 52, "4700": 46, "4600": 48, "3750": 34,
    "3550": 33,
    # Ryzen AI : pas de suffixe reconnu, indice de la puce elle-meme
    "hx 375": 72, "hx 370": 70, "ai 9 365": 67, "ai 7 350": 64, "ai 5 340": 56,
}
CPU_AMD.update(CPU_AMD_PORTABLES)

#: Intel et AMD partagent des numeros (i7-7700 contre Ryzen 7 7700, i5-7600
#: contre Ryzen 5 7600) : deux tables, choisies d'apres la marque citee.
CPU_INTEL: dict[str, float] = {
    "285k": 86, "265k": 84, "245k": 78,
    "14900k": 88, "14900": 84, "14700k": 86, "14700": 82, "14600k": 81, "14400": 70,
    "13900k": 87, "13900": 82, "13700k": 84, "13700": 80, "13600k": 80, "13500": 72,
    "13400": 68, "13100": 58, "12900k": 80, "12700k": 77, "12700": 74, "12600k": 74,
    "12400": 66, "12100": 58, "11900k": 64, "11700k": 62, "11600k": 60, "11400": 57,
    "10900k": 60, "10850k": 59, "10700k": 58, "10700": 56, "10600k": 55, "10400": 50,
    "10100": 42, "9900k": 57, "9900": 55, "9700k": 54, "9700": 52, "9600k": 49,
    "9400": 45, "9100": 38, "8700k": 52, "8700": 50, "8600k": 46, "8400": 43,
    "8350k": 40, "8100": 36, "7700k": 44, "7700": 41, "7600k": 40, "7500": 37,
    "6700k": 40, "6700": 38, "6600k": 36, "6500": 34, "6100": 28, "4790k": 36,
    "4770k": 33, "4770": 32, "4690k": 32, "4690": 31, "4670k": 31, "4670": 30,
    "4590": 30, "4460": 28, "4440": 27, "4430": 26, "4160": 20,
    "3770k": 30, "3770": 29, "3570k": 28, "2600k": 26, "2500k": 25,
    "7600": 38, "2600": 24,
    # bureau, complements
    "14500": 73, "13600": 76, "12600": 70, "12500": 68, "11700": 60, "11600": 58,
    "11500": 57, "10600": 53, "10500": 52, "9600": 47, "9500": 46, "8600": 45,
    "8500": 44, "7400": 35, "6600": 35, "6400": 32, "4570": 30, "3570": 27,
    "3470": 26, "2500": 24, "2400": 23,
}
CPU_INTEL_PORTABLES: dict[str, float] = {
    # portables : indice de la puce de bureau equivalente (voir `indice_cpu`)
    "14650": 78, "14450": 70, "13650": 74, "13620": 70, "13450": 66, "13420": 62,
    "12650": 68, "12450": 62, "11800": 62, "11300": 50, "11260": 54, "10870": 55,
    "10875": 55, "10750": 52, "10300": 44, "9750": 50, "9300": 42, "8750": 48,
    "8300": 40, "7300": 32, "1355": 50, "1335": 49, "1255": 48, "1235": 47,
    "10510": 33, "10210": 31, "8565": 33, "8265": 31, "8250": 30, "7200": 22,
    "6200": 20,
    # sans suffixe reconnu : indice de la puce elle-meme
    "1165g7": 33, "1135g7": 30, "1035g1": 22, "1005g1": 18,
    "285h": 74, "255h": 70, "185h": 66, "155h": 62, "125h": 56, "275hx": 84,
    "255hx": 78, "258v": 62, "226v": 55,
}
CPU_INTEL.update(CPU_INTEL_PORTABLES)
#: cles de processeurs qu'on ne peut pas acheter pour un PC de bureau
CPU_PORTABLES = frozenset(CPU_AMD_PORTABLES) | frozenset(CPU_INTEL_PORTABLES)

#: les deux tables ; a numero egal, AMD l'emporte quand la marque est inconnue
CPU: dict[str, float] = {**CPU_INTEL, **CPU_AMD}

def _sans_frequence(texte: str) -> str:
    """« 3.50GHz », « 2400 MHz » : une frequence n'est pas un modele (« Dual
    Core 2600 MHz » etait lu comme un Core i7-2600)."""
    return re.sub(r"\d+(?:[.,]\d+)?\s*[gm]hz\b", " ", texte)


def _normaliser(texte: str) -> str:
    t = (texte or "").lower().replace("™", " ").replace("®", " ")
    t = re.sub(r"\((tm|r)\)", " ", t)
    t = re.sub(r"(\d)\s*(ti|xt|xtx|super|gre)\b", r"\1 \2", t)
    t = t.replace("-", " ").replace("_", " ")
    t = re.sub(r"\s+", " ", t)
    return t


def _chercher(table: dict[str, float], texte: str) -> tuple[str, float] | None:
    """Plus longue reference contenue dans le texte (« 4070 ti super » avant
    « 4070 ti » avant « 4070 »)."""
    t = " " + _normaliser(texte) + " "
    for cle in sorted(table, key=len, reverse=True):
        motif = r"(?<![a-z0-9])" + re.escape(cle).replace(r"\ ", r"\s?") + r"(?![a-z0-9])"
        if re.search(motif, t):
            return cle, table[cle]
    return None


def indice_gpu(nom: str) -> tuple[str, float] | None:
    trouve = _chercher(GPU, nom)
    if trouve is None:
        return None
    cle, indice = trouve
    if re.search(r"laptop|mobile|max[ -]?q|notebook", nom or "", re.I):
        indice *= 0.75                      # variante portable, moins puissante
    return cle, round(indice, 1)


#: puces integrees RDNA 2 et suivantes (Ryzen 6000 et plus recents) : elles
#: ont des unites de ray tracing
_RADEON_RT = frozenset({"radeon 610m", "radeon 660m", "radeon 680m", "radeon 740m", "radeon 760m",
                        "radeon 780m", "radeon 840m", "radeon 860m", "radeon 880m", "radeon 890m",
                        "radeon 8050s", "radeon 8060s"})


def ray_tracing_materiel(nom: str) -> bool | None:
    """La carte calcule-t-elle le ray tracing elle-meme (DirectX Raytracing) ?
    True : GeForce RTX, Radeon RX 6000 et plus recentes (et leurs puces
    integrees), Intel Arc. False : GeForce GTX, GT et MX, Radeon RX 5000 et
    plus anciennes, Vega, Intel HD, UHD et Iris. None : on ne sait pas (carte
    non reconnue, « Radeon Graphics » ou « Intel Graphics » sans modele).

    13 octobre 2026 : Ace Combat 8, DOOM: The Dark Ages et Indiana Jones et le
    Cercle Ancien exigent le ray tracing materiel ; le site les disait
    jouables sur GTX 1660 Super, ou ils ne se lancent pas."""
    trouve = _chercher(GPU, nom)
    if trouve is None:
        return None
    cle = trouve[0]
    if cle.startswith("rtx") or cle.startswith("arc"):
        return True
    if cle.startswith(("gtx", "gt ", "mx ")):
        return False
    if cle.startswith("rx "):
        n = re.match(r"rx (\d+)", cle)
        return bool(n) and len(n.group(1)) == 4 and n.group(1)[0] in "6789"
    if cle in _RADEON_RT:
        return True
    if cle in ("radeon graphics", "intel graphics"):
        return None
    return False                        # Vega, Radeon VII, R9, HD 7000, Intel HD/UHD/Iris


def _table_cpu(texte: str) -> dict[str, float]:
    """Table selon la marque citee dans le texte (les deux si aucune)."""
    t = _normaliser(texte)
    # AMD d'abord : « AMD Ryzen 7 7700 8-Core Processor » contient « core »
    if re.search(r"\b(amd|ryzen|athlon|threadripper)\b|\bfx\b", t):
        return CPU_AMD
    if re.search(r"\b(intel|core|pentium|celeron|xeon)\b|\bi[3579]\b", t):
        return CPU_INTEL
    return CPU


def indice_cpu(nom: str) -> tuple[str, float] | None:
    table = _table_cpu(nom)
    t = _sans_frequence(_normaliser(nom)).replace("ryzen", " ").replace("core", " ")
    t = re.sub(r"\bi[3579]\s", " ", t)
    for cle in sorted(table, key=len, reverse=True):
        if re.search(r"(?<![0-9a-z])" + re.escape(cle) + r"(?![0-9])", t):
            indice = table[cle]
            if re.search(r"\d{4,5}(h|hs|hx|hq|hk|u|p)\b", _normaliser(nom)):
                indice *= 0.85                 # processeur portable
            return cle, round(indice, 1)
    return None


def tous_les_gpu(texte: str) -> list[tuple[str, float]]:
    """Toutes les cartes citees dans un texte (configurations requises)."""
    sortie, reste = [], " " + _normaliser(texte) + " "
    for cle in sorted(GPU, key=len, reverse=True):
        motif = r"(?<![a-z0-9])" + re.escape(cle).replace(r"\ ", r"\s?") + r"(?![a-z0-9])"
        if re.search(motif, reste):
            sortie.append((cle, GPU[cle]))
            reste = re.sub(motif, " ", reste)
    return sortie


#: mots qui designent la marque d'un processeur quand « intel » / « amd »
#: ne sont pas ecrits (« Core i5-7600 ou Ryzen 5 1600 »)
_MARQUES = re.compile(
    r"\b(intel|amd|core|pentium|celeron|xeon|i[3579]|ryzen|fx|athlon|threadripper)\b")
_MOTS_INTEL = {"intel", "core", "pentium", "celeron", "xeon", "i3", "i5", "i7", "i9"}


def tous_les_cpu(texte: str) -> list[tuple[str, float]]:
    """Tous les processeurs cites (« Intel Core i5-7600 / AMD Ryzen 5 1600 ») :
    chaque morceau est lu avec la table de la marque qui le precede (le mot
    « intel »/« amd », ou a defaut core, i5, ryzen, fx...). Sans aucune
    marque, les deux tables sont consultees."""
    sortie = []
    morceaux = _MARQUES.split(_sans_frequence(_normaliser(texte)))
    table, prefixe = CPU, ""
    for m in morceaux:
        if m is None:
            continue
        if _MARQUES.fullmatch(m):
            table = CPU_INTEL if m in _MOTS_INTEL else CPU_AMD
            prefixe = "fx" if m == "fx" else ""     # « fx 8350 » est une cle
            continue
        reste = " " + prefixe + m + " "
        prefixe = ""
        for cle in sorted(table, key=len, reverse=True):
            motif = r"(?<![0-9a-z])" + re.escape(cle) + r"(?![0-9])"
            if re.search(motif, reste):
                sortie.append((cle, table[cle]))
                reste = re.sub(motif, " ", reste)
    return sortie
