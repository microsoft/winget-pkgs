"""Fichiers INI (Unreal Engine, nombreux moteurs maison).

Edition ligne a ligne, jamais une reecriture complete du fichier :

* seules les lignes des cles visees changent, tout le reste (commentaires,
  ordre, cles en double comme les « +Paths= » d'Unreal, lignes que le
  module standard ne sait pas lire) est conserve a l'identique ;
* l'encodage d'origine (UTF-8 avec ou sans BOM, UTF-16 d'Unreal, ANSI) et
  les fins de ligne sont conserves ;
* l'ecriture passe par un fichier voisin remplace d'un coup : une coupure
  ne laisse jamais un fichier a moitie ecrit ;
* un fichier en lecture seule n'est pas force : on le dit.

L'ancienne version passait par `configparser` : une seule ligne
inattendue faisait echouer la lecture, et la reecriture qui suivait
pouvait vider le fichier de tout ce qui n'avait pas ete lu.
"""
from __future__ import annotations

import os
import re
from pathlib import Path

from ...core.logging_setup import get
from ...core.models import TweakOp
from .base import TweakWriter

log = get("tweaks.ini")

_SECTION = re.compile(r"^\s*\[(.+?)\]\s*$")
_CLE = re.compile(r"^\s*([^;#\s=][^=]*?)\s*=(.*)$")


def lire_texte(path: Path) -> tuple[str, str, str]:
    """(texte, encodage, fin de ligne). Texte vide si le fichier manque."""
    try:
        brut = path.read_bytes()
    except FileNotFoundError:
        return "", "utf-8", "\r\n" if os.name == "nt" else "\n"
    if brut.startswith((b"\xff\xfe", b"\xfe\xff")):
        enc = "utf-16"
    elif brut.startswith(b"\xef\xbb\xbf"):
        enc = "utf-8-sig"
    else:
        try:
            brut.decode("utf-8")
            enc = "utf-8"
        except UnicodeDecodeError:
            enc = "cp1252"
    texte = brut.decode(enc, errors="replace")
    eol = "\r\n" if "\r\n" in texte else "\n"
    return texte, enc, eol


def _meme_section(a: str, b: str, exact: bool) -> bool:
    return a == b if exact else a.lower() == b.lower()


def _bornes(lignes: list[str], section: str) -> tuple[int, int] | None:
    """(debut, fin) des lignes de la section (debut = ligne d'en-tete)."""
    for exact in (True, False):
        debut = None
        for i, ligne in enumerate(lignes):
            m = _SECTION.match(ligne)
            if not m:
                continue
            if debut is not None:
                return debut, i
            if _meme_section(m.group(1).strip(), section, exact):
                debut = i
        if debut is not None:
            return debut, len(lignes)
    return None


def _position_cle(lignes: list[str], debut: int, fin: int, cle: str) -> int:
    """Indice de la DERNIERE ligne qui definit la cle (c'est elle qui compte)."""
    trouve = -1
    for i in range(debut + 1, fin):
        m = _CLE.match(lignes[i])
        if m and m.group(1).strip() == cle:
            trouve = i
    return trouve


def lire_valeur(texte: str, section: str, cle: str) -> str | None:
    lignes = texte.splitlines()
    if section:
        bornes = _bornes(lignes, section)
        if bornes is None:
            return None
        debut, fin = bornes
    else:
        debut, fin = -1, len(lignes)
        for i, ligne in enumerate(lignes):
            if _SECTION.match(ligne):
                fin = i
                break
    i = _position_cle(lignes, debut, fin, cle)
    if i < 0:
        return None
    return _CLE.match(lignes[i]).group(2).strip()


def modifier(texte: str, valeurs: list[tuple[str, str, str]]) -> str:
    """Applique (section, cle, valeur) en ne touchant que les lignes visees.
    Fonction pure, testee."""
    lignes = texte.splitlines()
    for section, cle, valeur in valeurs:
        nouvelle = f"{cle}={valeur}"
        bornes = _bornes(lignes, section) if section else None
        if section and bornes is None:
            while lignes and not lignes[-1].strip():
                lignes.pop()
            if lignes:
                lignes.append("")
            lignes += [f"[{section}]", nouvelle]
            continue
        if bornes is None:                         # cle hors section, en tete
            fin = next((i for i, l in enumerate(lignes) if _SECTION.match(l)),
                       len(lignes))
            debut = -1
        else:
            debut, fin = bornes
        i = _position_cle(lignes, debut, fin, cle)
        if i >= 0:
            lignes[i] = nouvelle
            continue
        # insertion apres la derniere ligne non vide de la section
        pos = fin
        while pos - 1 > debut and not lignes[pos - 1].strip():
            pos -= 1
        lignes.insert(pos, nouvelle)
    return "\n".join(lignes) + "\n"


class IniWriter(TweakWriter):
    id = "ini"
    label = "Fichier INI"

    def read(self, op: TweakOp) -> str | None:
        texte, _enc, _eol = lire_texte(Path(op.target))
        return lire_valeur(texte, op.section, op.key) if texte else None

    def write(self, ops: list[TweakOp]) -> tuple[int, str]:
        by_file: dict[str, list[TweakOp]] = {}
        for op in ops:
            by_file.setdefault(op.target, []).append(op)

        written = 0
        erreurs: list[str] = []
        for target, items in by_file.items():
            path = Path(target)
            if path.exists() and not os.access(path, os.W_OK):
                # un fichier refuse n'empeche pas d'ecrire les autres
                erreurs.append(f"{path.name} est en lecture seule : ORION ne le "
                               "force pas. Retirez l'attribut lecture seule pour "
                               "laisser ORION le regler.")
                continue
            try:
                texte, enc, eol = lire_texte(path)
                nouveau = modifier(texte, [(o.section, o.key, str(o.value)) for o in items])
                if eol != "\n":
                    nouveau = nouveau.replace("\n", eol)
                path.parent.mkdir(parents=True, exist_ok=True)
                provisoire = path.with_name(path.name + ".orion.tmp")
                provisoire.write_bytes(nouveau.encode(enc))
                os.replace(provisoire, path)
                written += len(items)
            except Exception as exc:
                log.exception("Ecriture INI impossible : %s", path)
                erreurs.append(f"Ecriture impossible dans {path.name} : {exc}")
        if erreurs:
            return written, " ; ".join(erreurs)
        return written, "Reglages ecrits"
