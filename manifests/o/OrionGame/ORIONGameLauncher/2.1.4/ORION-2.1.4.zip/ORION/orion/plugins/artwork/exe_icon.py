"""Repli hors ligne : icone de l'executable, extraite par Qt.

Toujours disponible, sans reseau : garantit qu'aucune tuile ne reste vide.
"""
from __future__ import annotations

from pathlib import Path

from ...core.logging_setup import get
from ...core.models import Game
from .base import ArtworkProvider, cache_path

log = get("artwork.icone")


class ExeIconProvider(ArtworkProvider):
    id = "exe_icon"
    label = "Icone du jeu"
    priority = 10
    needs_network = False

    def fetch(self, game: Game, want: set[str]) -> dict[str, str]:
        if "icon" not in want and "cover" not in want:
            return {}
        target = game.executable or game.install_dir
        if not target or not Path(target).exists():
            return {}
        try:
            from PySide6.QtCore import QFileInfo, QSize
            from PySide6.QtWidgets import QFileIconProvider

            icon = QFileIconProvider().icon(QFileInfo(target))
            if icon.isNull():
                return {}
            sizes = icon.availableSizes()
            best = max(sizes, key=lambda s: s.width()) if sizes else QSize(256, 256)
            pix = icon.pixmap(max(best.width(), 128), max(best.height(), 128))
            if pix.isNull():
                return {}
            dest = cache_path(game, "icon", "png")
            pix.save(str(dest), "PNG")
            return {"icon": str(dest)}
        except Exception:
            log.debug("Extraction d'icone impossible : %s", target)
            return {}
