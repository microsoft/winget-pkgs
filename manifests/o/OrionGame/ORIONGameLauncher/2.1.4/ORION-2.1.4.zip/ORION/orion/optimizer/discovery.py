"""Localisation des fichiers de configuration propres a chaque moteur.

16 octobre 2026 : les tests d'existence passent par `core.fichiers` (jamais
d'exception) : le dossier d'un jeu deplace sur un disque debranche (jonction
morte, `WinError 1`) faisait echouer `build_plan` 281 fois dans le journal de
l'auteur, et la fiche affichait « Erreur : Fonction incorrecte ».

C'est le maillon qui permet aux recettes generiques de fonctionner sans
connaitre le jeu : on deduit le nom du projet Unreal, l'editeur Unity, etc.
"""
from __future__ import annotations

import os
from pathlib import Path

from ..core.fichiers import est_dossier, existe
from ..core.logging_setup import get
from ..core.models import Game, normalize_title
from ..core.paths import expand

log = get("optimizer.decouverte")


def unreal_project(game: Game) -> str:
    """Nom du projet Unreal (dossier sous %LOCALAPPDATA%)."""
    inst = Path(game.install_dir) if game.install_dir else None

    # 1) le dossier du projet contient Binaries/Win64 a cote de Content
    if inst and est_dossier(inst):
        try:
            for child in inst.iterdir():
                if est_dossier(child) and est_dossier(child / "Binaries" / "Win64"):
                    if child.name.lower() != "engine":
                        return child.name
        except OSError:
            pass

    # 2) un dossier de configuration deja existant qui porte le meme nom
    local = expand("%LOCALAPPDATA%")
    key = normalize_title(game.title)
    if est_dossier(local) and key:
        best = ""
        try:
            for child in local.iterdir():
                if not est_dossier(child):
                    continue
                if not est_dossier(child / "Saved" / "Config"):
                    continue
                n = normalize_title(child.name)
                if n == key:
                    return child.name
                if n and (n in key or key in n) and len(n) > 3:
                    best = best or child.name
        except OSError:
            pass
        if best:
            return best
    return ""


def documents_dir() -> Path:
    """Vrai dossier Documents : sous Windows 11 il est souvent redirige vers
    OneDrive, et « ~/Documents » n'existe alors pas (les jeux ecrivent
    ailleurs que la ou ORION cherchait)."""
    try:
        from ..core.winutil import HKCU, reg_value
        val = reg_value(HKCU, r"Software\Microsoft\Windows\CurrentVersion\Explorer"
                              r"\User Shell Folders", "Personal", "")
        if val:
            p = expand(str(val))
            if est_dossier(p):
                return p
    except Exception:
        pass
    maison = Path.home()
    for cand in (maison / "Documents", maison / "OneDrive" / "Documents"):
        if est_dossier(cand):
            return cand
    return maison / "Documents"


def unreal_mygames(game: Game, projet: str = "") -> str:
    """Dossier Unreal sous Documents/My Games (Borderlands, Gears...)."""
    racine = documents_dir() / "My Games"
    if not est_dossier(racine):
        return ""
    cles = {k for k in (normalize_title(game.title), normalize_title(projet)) if k}
    try:
        for child in racine.iterdir():
            if est_dossier(child) and normalize_title(child.name) in cles and \
                    est_dossier(child / "Saved" / "Config"):
                return child.name
    except OSError:
        pass
    return ""


def unity_identity(game: Game) -> tuple[str, str]:
    """(editeur, produit) lus dans le dossier *_Data du jeu."""
    inst = Path(game.install_dir) if game.install_dir else None
    if not inst or not est_dossier(inst):
        return "", ""
    try:
        for child in inst.iterdir():
            if est_dossier(child) and child.name.lower().endswith("_data"):
                info = child / "app.info"
                if existe(info):
                    lines = info.read_text("utf-8", errors="ignore").splitlines()
                    if len(lines) >= 2:
                        return lines[0].strip(), lines[1].strip()
    except OSError:
        pass
    return "", game.title


def context_for(game: Game) -> dict[str, str]:
    """Variables de chemin disponibles dans les recettes."""
    ctx: dict[str, str] = {
        "install_dir": game.install_dir or "",
        "exe_dir": str(Path(game.executable).parent) if game.executable else "",
        "title": game.title,
        "appid": game.source_id or "",
        "documents": str(documents_dir()),
        "saved_games": str(Path.home() / "Saved Games"),
        "localappdata": os.environ.get("LOCALAPPDATA", ""),
        "appdata": os.environ.get("APPDATA", ""),
    }
    if game.engine == "unreal":
        ctx["ue_project"] = unreal_project(game)
        ctx["ue_mygames"] = unreal_mygames(game, ctx["ue_project"])
    elif game.engine == "unity":
        company, product = unity_identity(game)
        ctx["unity_company"] = company
        ctx["unity_product"] = product
    return ctx
