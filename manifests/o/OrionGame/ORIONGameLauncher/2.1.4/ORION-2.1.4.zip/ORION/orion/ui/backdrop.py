"""Fond de la fenetre : une image, un voile, et rien qui gene la lecture.

Le decor n'est pas une decoration gratuite : il donne sa profondeur a
l'interface, qui flotte au-dessus au lieu d'etre posee sur un aplat. Tout
le reste de l'application reste donc semi-transparent, et c'est ce widget
qui peint ce qu'on voit derriere.

Trois sources possibles, dans l'ordre :

1. l'image choisie par l'utilisateur dans les reglages ;
2. la jaquette du jeu selectionne, floutee, si le fond dynamique est actif ;
3. un fond livre avec l'application : celui du jour (`assets/fonds/`, un
   different chaque jour) ou, si l'option est coupee, la constellation
   d'Orion (`assets/fond.jpg`).

Un voile sombre est peint par-dessus, plus dense a gauche ou se trouve la
barre laterale : le contraste du texte ne depend jamais de l'image.

Par-dessus le voile, en haut des pages, la banniere de la saison : la meme
hauteur et la meme place sur toutes les pages, derriere leur titre. Elle
s'efface a gauche (le titre) et vers le bas (le contenu).
"""
from __future__ import annotations

from pathlib import Path

import datetime as dt

from PySide6.QtCore import QPointF, QRect, QSize, Qt, QTimer
from PySide6.QtGui import (QBrush, QColor, QLinearGradient, QPainter,
                           QPixmap)
from PySide6.QtWidgets import QWidget

from ..core.config import CONFIG
from ..core.logging_setup import get
from ..core.paths import ASSETS_DIR

log = get("ui.fond")

#: fond livre avec l'application
BUILTIN = ASSETS_DIR / "fond.jpg"

#: opacite du voile, de la gauche (dense) vers la droite (leger)
SCRIM_LEFT = 0.90
SCRIM_RIGHT = 0.62


#: hauteur de la banniere de saison, la meme sur toutes les pages
HAUTEUR_BANNIERE = 104
#: sa presence : assez pour la voir, pas assez pour gener les commandes
OPACITE_BANNIERE = 0.88


def builtin_background() -> str:
    """Le fond livre : celui du jour, sinon la constellation d'Orion."""
    if CONFIG.get("ui.fond_du_jour", True):
        from .. import saisons
        du_jour = saisons.fond_du_jour()
        if du_jour is not None:
            return str(du_jour)
    return str(BUILTIN) if BUILTIN.exists() else ""


def banniere_du_jour() -> str:
    if not CONFIG.get("ui.banniere_saison", True):
        return ""
    from .. import saisons
    chemin = saisons.banniere()
    return str(chemin) if chemin is not None else ""


def _blurred(pix: QPixmap, radius: int = 26) -> QPixmap:
    """Flou bon marche : reduction puis agrandissement lisse.

    Un vrai flou gaussien sur une image plein ecran couterait plus cher que
    ce qu'il apporte ici, ou l'image est de toute facon recouverte d'un
    voile. La reduction donne exactement l'aspect recherche.
    """
    if pix.isNull():
        return pix
    small = pix.scaled(max(pix.width() // radius, 8),
                       max(pix.height() // radius, 5),
                       Qt.AspectRatioMode.IgnoreAspectRatio,
                       Qt.TransformationMode.SmoothTransformation)
    return small.scaled(pix.size(), Qt.AspectRatioMode.IgnoreAspectRatio,
                        Qt.TransformationMode.SmoothTransformation)


class Backdrop(QWidget):
    """Widget racine : peint l'image de fond et son voile."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("Root")
        self.setAutoFillBackground(False)
        self._source = ""
        self._pixmap = QPixmap()
        self._scaled = QPixmap()
        self._scaled_key = ""
        self._dynamic = QPixmap()
        # banniere de saison : son image, la zone des pages, son rendu en cache
        self._banniere_source = ""
        self._banniere = QPixmap()
        self._banniere_rendue = QPixmap()
        self._banniere_cle = ""
        self._banniere_visible = True
        self._pages: QWidget | None = None
        self._jour = dt.date.today()
        self.reload()
        # ORION reste souvent ouvert plusieurs jours : le fond du jour et la
        # banniere suivent le calendrier sans redemarrage
        self._veille_jour = QTimer(self)
        self._veille_jour.setInterval(10 * 60 * 1000)
        self._veille_jour.timeout.connect(self.suivre_le_jour)
        self._veille_jour.start()

    # ------------------------------------------------------------------
    def reload(self) -> None:
        """Relit le fond choisi dans les reglages."""
        self._jour = dt.date.today()
        self._relire_banniere()
        chosen = str(CONFIG.get("ui.background") or "").strip()
        path = chosen if chosen and Path(chosen).exists() else builtin_background()
        if path == self._source and not self._pixmap.isNull():
            return
        self._source = path
        self._pixmap = QPixmap(path) if path else QPixmap()
        if self._pixmap.isNull() and path:
            log.debug("Fond illisible : %s", path)
        self._scaled_key = ""
        self.update()

    def suivre_le_jour(self) -> None:
        """Changement de date pendant qu'ORION est ouvert : nouveau fond du
        jour, et nouvelle banniere si la saison a change."""
        if dt.date.today() != self._jour:
            self.reload()
            self.update()

    # -- banniere de saison ----------------------------------------------
    def _relire_banniere(self) -> None:
        path = banniere_du_jour()
        if path == self._banniere_source:
            return
        self._banniere_source = path
        self._banniere = QPixmap(path) if path else QPixmap()
        self._banniere_cle = ""
        self.update()

    def set_pages(self, zone: QWidget | None) -> None:
        """La zone des pages (a droite de la barre laterale) : la banniere
        est peinte en haut de cette zone."""
        self._pages = zone

    def montrer_banniere(self, oui: bool) -> None:
        """La fiche d'un jeu a son propre visuel en tete : pas de banniere."""
        if oui != self._banniere_visible:
            self._banniere_visible = oui
            self.update()

    def zone_banniere(self) -> QRect:
        """Rectangle de la banniere, vide quand il n'y en a pas a peindre."""
        if self._banniere.isNull() or not self._banniere_visible:
            return QRect()
        gauche = self._pages.geometry().left() if self._pages is not None else 0
        largeur = self.width() - gauche
        return QRect(gauche, 0, largeur, HAUTEUR_BANNIERE) if largeur > 40 else QRect()

    def _rendre_banniere(self, taille: QSize) -> QPixmap:
        """La banniere a la taille de la zone, effacee a gauche et en bas.
        Recalculee seulement quand l'image ou la largeur change."""
        cle = f"{self._banniere.cacheKey()}:{taille.width()}x{taille.height()}"
        if cle == self._banniere_cle:
            return self._banniere_rendue
        image = self._banniere.scaled(taille, Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                                      Qt.TransformationMode.SmoothTransformation)
        rendu = QPixmap(taille)
        rendu.fill(Qt.GlobalColor.transparent)
        p = QPainter(rendu)
        # calee a droite : les motifs y sont, le cote gauche est deja eteint
        p.drawPixmap(taille.width() - image.width(), (taille.height() - image.height()) // 2, image)
        p.setCompositionMode(QPainter.CompositionMode.CompositionMode_DestinationIn)
        bas = QLinearGradient(QPointF(0, 0), QPointF(0, taille.height()))
        bas.setColorAt(0.0, QColor(0, 0, 0, 255))
        bas.setColorAt(0.5, QColor(0, 0, 0, 235))
        bas.setColorAt(1.0, QColor(0, 0, 0, 0))
        p.fillRect(rendu.rect(), QBrush(bas))
        gauche = QLinearGradient(QPointF(0, 0), QPointF(taille.width(), 0))
        gauche.setColorAt(0.0, QColor(0, 0, 0, 0))
        gauche.setColorAt(0.3, QColor(0, 0, 0, 255))
        gauche.setColorAt(1.0, QColor(0, 0, 0, 255))
        p.fillRect(rendu.rect(), QBrush(gauche))
        p.end()
        self._banniere_rendue, self._banniere_cle = rendu, cle
        return rendu

    def set_dynamic_art(self, path: str) -> None:
        """Jaquette du jeu selectionne, utilisee comme fond si l'option l'est."""
        if not CONFIG.get("ui.dynamic_background", False):
            if not self._dynamic.isNull():
                self._dynamic = QPixmap()
                self.update()
            return
        pix = QPixmap(path) if path and Path(path).exists() else QPixmap()
        self._dynamic = _blurred(pix) if not pix.isNull() else QPixmap()
        self.update()

    # ------------------------------------------------------------------
    def _cover(self, source: QPixmap) -> QPixmap:
        """Image mise a l'echelle pour couvrir la fenetre, sans deformation."""
        if source.isNull() or self.width() < 2 or self.height() < 2:
            return QPixmap()
        return source.scaled(self.size(), Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                             Qt.TransformationMode.SmoothTransformation)

    def resizeEvent(self, event) -> None:      # noqa: N802 (API Qt)
        self._scaled_key = ""
        super().resizeEvent(event)

    def paintEvent(self, event) -> None:       # noqa: N802 (API Qt)
        # Le decor est compose une fois (image, voile, bandeaux, banniere)
        # puis recopie : il est redessine a CHAQUE image de l'interface, sous
        # tout ce qui defile ou s'anime. Recompose a chaque fois, il coutait
        # une dizaine de millisecondes par image (mesure du 7 octobre 2026).
        dim = max(0.0, min(1.0, float(CONFIG.get("ui.background_dim", 78) or 78) / 100))
        source = self._dynamic if not self._dynamic.isNull() else self._pixmap
        zone = self.zone_banniere()
        dpr = self.devicePixelRatioF()
        cle = (source.cacheKey(), self.width(), self.height(), dpr, dim,
               zone.x(), zone.y(), zone.width(), zone.height(), self._banniere.cacheKey())
        if cle != getattr(self, "_compose_cle", None):
            compose = QPixmap(QSize(max(1, round(self.width() * dpr)),
                                    max(1, round(self.height() * dpr))))
            compose.setDevicePixelRatio(dpr)
            p = QPainter(compose)
            self._composer(p, dim, source, zone)
            p.end()
            self._compose, self._compose_cle = compose, cle
        p = QPainter(self)
        p.drawPixmap(0, 0, self._compose)
        p.end()

    def _composer(self, p: QPainter, dim: float, source: QPixmap, zone: QRect) -> None:
        rect = QRect(0, 0, self.width(), self.height())

        # 1) couleur de secours : la fenetre n'est jamais transparente
        p.fillRect(rect, QColor("#070A11"))

        # 2) l'image, centree sur la zone couverte
        if not source.isNull():
            # la mise a l'echelle est refaite seulement quand l'image ou la
            # taille de la fenetre change, jamais a chaque rafraichissement.
            key = f"{source.cacheKey()}:{self.width()}x{self.height()}"
            if key != self._scaled_key:
                self._scaled = self._cover(source)
                self._scaled_key = key
            if not self._scaled.isNull():
                x = (self.width() - self._scaled.width()) // 2
                y = (self.height() - self._scaled.height()) // 2
                p.drawPixmap(x, y, self._scaled)

        # 3) le voile : le texte doit rester lisible quelle que soit l'image
        gradient = QLinearGradient(QPointF(0, 0), QPointF(self.width(), 0))
        gradient.setColorAt(0.0, QColor(7, 10, 17, int(255 * SCRIM_LEFT * dim)))
        gradient.setColorAt(0.35, QColor(7, 10, 17, int(255 * 0.80 * dim)))
        gradient.setColorAt(1.0, QColor(7, 10, 17, int(255 * SCRIM_RIGHT * dim)))
        p.fillRect(rect, QBrush(gradient))

        # 4) bandeaux haut et bas : les barres d'outils et la barre d'etat
        # gardent un appui sombre, quelle que soit l'image en dessous.
        bands = QLinearGradient(QPointF(0, 0), QPointF(0, self.height()))
        edge = int(150 * dim)
        band_h = max(0.04, min(0.16, 70 / max(self.height(), 1)))
        bands.setColorAt(0.0, QColor(6, 9, 15, edge))
        bands.setColorAt(band_h, QColor(6, 9, 15, 0))
        bands.setColorAt(1.0 - band_h * 0.6, QColor(6, 9, 15, 0))
        bands.setColorAt(1.0, QColor(6, 9, 15, edge))
        p.fillRect(rect, QBrush(bands))

        # 5) la banniere de saison, en haut des pages, par-dessus le voile
        if not zone.isEmpty():
            p.setOpacity(OPACITE_BANNIERE)
            p.drawPixmap(zone.topLeft(), self._rendre_banniere(zone.size()))
            p.setOpacity(1.0)

