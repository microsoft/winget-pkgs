"""Historique des mesures de performance, par jeu et par profil."""
from __future__ import annotations


from ..core.logging_setup import get
from ..core.paths import DATA_DIR, ensure_dirs

log = get("perf.historique")

PERF_FILE = DATA_DIR / "performances.json"

#: historique en service dans l'application (le dernier ouvert)
_ACTIF: "PerfStore | None" = None
#: (uid, profil) -> reglages reellement appliques (niveau, super-resolution) :
#: une mesure prise avec le profil « Recommande » n'a de sens que si l'on
#: sait a quel niveau le jeu tournait.
_APPLIQUE: dict[tuple[str, str], dict] = {}


def noter_reglage(uid: str, profil: str, preset: str, upscaler_mode: str = "off",
                  echelle: int = 100) -> None:
    """Retient le niveau applique pour ce jeu et ce profil (voir `add`)."""
    if uid and profil and preset:
        _APPLIQUE[(uid, profil)] = {"preset": preset, "upscaler_mode": upscaler_mode,
                                    "echelle": echelle}


def mesures_du_jeu(uid: str) -> dict[str, dict]:
    """Meilleure mesure par profil, depuis l'historique en service."""
    if _ACTIF is None or not uid:
        return {}
    try:
        return _ACTIF.by_profile(uid)
    except Exception:
        return {}


def fiable(run: dict) -> bool:
    """Une mesure qui peut servir de reference. Douteuse : marquee comme
    telle a l'analyse, ou, pour les mesures d'avant la 2.1.2, plus d'images
    ecartees que gardees (11 octobre : 169 789 ecartees pour 81 876 gardees,
    21 i/s retenus au lieu de ~115)."""
    if run.get("douteuse"):
        return False
    return int(run.get("ecartees") or 0) <= int(run.get("frames") or 0)


class PerfStore:
    def __init__(self) -> None:
        global _ACTIF
        self.runs: list[dict] = []
        self.load()
        _ACTIF = self

    def load(self) -> None:
        ensure_dirs()
        from ..core.base import Document
        self._doc = Document("performances", PERF_FILE)
        try:
            self.runs = (self._doc.lire({}) or {}).get("runs", [])
        except Exception:
            self.runs = []

    def save(self) -> None:
        self._doc.ecrire({"runs": self.runs[-500:]})

    # ------------------------------------------------------------------
    def add(self, stats: dict) -> None:
        if not stats:
            return
        applique = _APPLIQUE.get((stats.get("uid", ""), stats.get("profile", "")))
        if applique:
            for cle, valeur in applique.items():
                stats.setdefault(cle, valeur)
        self.runs.append(stats)
        self.save()

    def for_game(self, uid: str) -> list[dict]:
        return [r for r in self.runs if r.get("uid") == uid]

    def latest(self, uid: str, profile: str = "") -> dict | None:
        runs = [r for r in self.for_game(uid)
                if not profile or r.get("profile") == profile]
        return max(runs, key=lambda r: r.get("at", 0)) if runs else None

    def by_profile(self, uid: str) -> dict[str, dict]:
        """Derniere mesure fiable de chaque profil de ce jeu (une mesure
        douteuse n'en remplace jamais une bonne, 2.1.2)."""
        out: dict[str, dict] = {}
        for run in self.for_game(uid):
            if not fiable(run):
                continue
            profile = run.get("profile") or "?"
            best = out.get(profile)
            if best is None or run.get("at", 0) > best.get("at", 0):
                out[profile] = run
        return out

    def summary(self, uid: str) -> str:
        """Phrase de synthese affichee sur la fiche du jeu."""
        runs = self.by_profile(uid)
        if not runs:
            return ""
        labels = {"esport": "Esport", "detente": "Detente", "photo": "Photorealiste",
                  "recommande": "Recommande"}
        parts = []
        for profile, run in sorted(runs.items()):
            parts.append(f"{labels.get(profile, profile)} : "
                         f"{run['fps_avg']:.0f} i/s "
                         f"(1 % bas {run['fps_low_1']:.0f})")
        return "   ·   ".join(parts)

