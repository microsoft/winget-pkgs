"""Carte graphique : identification, capacites et niveau de performance.

Les capacites detectees (DLSS, generation d'images, ray tracing...) pilotent
directement les reglages proposes par les profils d'optimisation.
"""
from __future__ import annotations

import re
import subprocess

from ..core.logging_setup import get
from ..core.models import GPUInfo
from ..core.paths import is_windows
from ..core.winutil import HKLM, reg_subkeys, reg_values

log = get("hardware.gpu")

VIRTUAL = re.compile(r"(virtual|remote|meta |oculus|parsec|idd |usb display|"
                     r"basic display|citrix|vmware|teamviewer)", re.I)

FEATURES = {
    "dlss": "Super-resolution DLSS",
    "dlss_fg": "Generation d'images DLSS",
    "dlss_mfg": "Generation multi-images DLSS",
    "ray_reconstruction": "Ray Reconstruction",
    "reflex": "NVIDIA Reflex",
    "fsr": "AMD FSR",
    "fsr_fg": "Generation d'images FSR",
    "xess": "Intel XeSS",
    "rt": "Ray tracing materiel",
    "anti_lag": "AMD Anti-Lag",
}


def _nvidia_series(name: str) -> int | None:
    m = re.search(r"(?:RTX|GTX)\s*(\d{3,4})", name, re.I)
    return int(m.group(1)) if m else None


def classify(name: str) -> tuple[str, int, list[str]]:
    """Retourne (fabricant, niveau 0-3, capacites) a partir du nom du GPU."""
    n = name.lower()

    if "nvidia" in n or "geforce" in n or "rtx" in n or "gtx" in n or "quadro" in n:
        num = _nvidia_series(name)
        feats: list[str] = []
        tier = 1
        if "rtx" in n and num:
            feats += ["dlss", "rt", "ray_reconstruction", "reflex"]
            if num >= 5000:
                feats += ["dlss_fg", "dlss_mfg"]
            elif num >= 4000:
                feats += ["dlss_fg"]
            last = num % 1000
            if last >= 80:
                tier = 3
            elif last >= 70:
                tier = 2
            elif last >= 60:
                tier = 2 if num >= 4000 else 1
            else:
                tier = 1
            if num < 3000:
                tier = max(tier - 1, 1)
        elif "gtx" in n:
            feats += ["fsr"]
            tier = 1 if (num or 0) >= 1060 else 0
        return "nvidia", tier, feats

    if "radeon" in n or "amd" in n or re.search(r"\brx\s*\d", n):
        feats = ["fsr", "anti_lag"]
        m = re.search(r"RX\s*(\d{4})", name, re.I)
        num = int(m.group(1)) if m else 0
        # ray tracing materiel : RX 6000 et suivantes, et les puces integrees
        # RDNA 2 et suivantes (Radeon 680M, 780M...) ; meme regle que le
        # calculateur (`references.ray_tracing_materiel`)
        from ..puissance.references import ray_tracing_materiel
        if num >= 6000 or ray_tracing_materiel(name):
            feats += ["rt"]
        if num >= 7000:
            feats += ["fsr_fg"]
        last = num % 1000
        tier = 3 if last >= 900 else 2 if last >= 700 else 1 if num else 1
        return "amd", tier, feats

    if "intel" in n or "arc" in n:
        feats = ["xess"]
        tier = 1
        if "arc" in n:
            feats += ["rt"]
            tier = 2 if re.search(r"[AB]7\d\d", name) else 1
        else:
            tier = 0
        return "intel", tier, feats

    return "inconnu", 1, []


def _nvidia_smi() -> dict:
    try:
        out = subprocess.run(
            ["nvidia-smi", "--query-gpu=name,driver_version,memory.total",
             "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=8,
            creationflags=0x08000000 if is_windows() else 0,
        ).stdout.strip()
        if not out:
            return {}
        name, driver, vram = [x.strip() for x in out.splitlines()[0].split(",")]
        return {"name": name, "driver": driver, "vram_mb": int(float(vram))}
    except Exception:
        return {}


def _from_registry() -> list[dict]:
    """Cartes declarees dans le registre (nom, pilote, date, VRAM)."""
    base = r"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}"
    out = []
    for sub in reg_subkeys(HKLM, base):
        if not sub.isdigit():
            continue
        v = reg_values(HKLM, f"{base}\\{sub}")
        name = v.get("DriverDesc") or ""
        if not name:
            continue
        vram = v.get("HardwareInformation.qwMemorySize") or 0
        if isinstance(vram, bytes):
            vram = int.from_bytes(vram, "little")
        out.append({
            "name": name,
            "driver": str(v.get("DriverVersion") or ""),
            "date": str(v.get("DriverDate") or ""),
            "vram_mb": int(int(vram) / (1024 * 1024)) if vram else 0,
        })
    return out


def detect_gpus() -> list[GPUInfo]:
    """Cartes graphiques reelles, les peripheriques virtuels sont ecartes."""
    entries = _from_registry()
    smi = _nvidia_smi()

    gpus: list[GPUInfo] = []
    for e in entries:
        if VIRTUAL.search(e["name"]):
            continue
        vendor, tier, feats = classify(e["name"])
        vram = e["vram_mb"]
        driver = e["driver"]
        if vendor == "nvidia" and smi:
            vram = smi.get("vram_mb") or vram
            driver = smi.get("driver") or driver
        gpus.append(GPUInfo(name=e["name"], vendor=vendor, vram_mb=vram,
                            driver_version=driver, driver_date=e.get("date", ""),
                            tier=tier, features=feats))

    if not gpus and smi:
        vendor, tier, feats = classify(smi["name"])
        gpus.append(GPUInfo(name=smi["name"], vendor=vendor,
                            vram_mb=smi.get("vram_mb", 0),
                            driver_version=smi.get("driver", ""),
                            tier=tier, features=feats))

    gpus.sort(key=lambda g: (g.tier, g.vram_mb), reverse=True)
    log.info("GPU : %s", [(g.name, g.vram_mb, g.features) for g in gpus])
    return gpus
