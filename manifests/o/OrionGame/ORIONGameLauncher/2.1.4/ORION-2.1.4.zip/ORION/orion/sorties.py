"""Grosses sorties a venir, toutes plateformes (1.8.1).

La liste vient de trois endroits :

* la liste embarquee ci-dessous (`EMBARQUEE`), relevee a partir des
  annonces officielles des editeurs, qui sert hors ligne et couvre les
  consoles (GTA VI, Zelda...) ;
* sa version en ligne, sur le site d'ORION (`sorties.json`), mise a jour
  sans nouvelle version de l'application quand une date change. Elle
  n'est prise que si elle est bien formee et plus recente que la liste
  embarquee ;
* les jeux a venir les plus suivis sur Steam (classement par listes de
  souhaits, date donnee par l'editeur sur sa fiche). Ils completent la
  page automatiquement : quand un jeu sort, il laisse sa place au suivant,
  sans intervention.

Une date exacte donne un compte a rebours jusqu'a minuit (heure du PC) le
jour de la sortie. Une fenetre (« Fin 2027 ») est affichee telle quelle,
sans compte a rebours : ORION n'invente pas de date.

Les visuels viennent de la fiche Steam du jeu quand il y en a une ; sinon
la carte est peinte aux couleurs du jeu.
"""
from __future__ import annotations

from orion.core import region

import colorsys
import datetime as dt
import hashlib
import html
import json
import re
from dataclasses import dataclass, replace
from pathlib import Path

from .core.logging_setup import get

log = get("sorties")

FORMAT = 1
URL = "https://orion-launcher.com/sorties.json"
GARDER = 6 * 3600                       # la liste en ligne est relue toutes les 6 h
DISPONIBLE_JOURS = 3                    # un jeu sorti reste affiche 3 jours
AFFICHEES = 24                          # sorties datees montrees (hors vedette)
ANNONCES = 8                            # jeux sans date precise montres
STEAM_URL = "https://store.steampowered.com/search/results/"
STEAM_GARDER = 12 * 3600                # classement Steam relu toutes les 12 h
RANG_MAX = 60                           # seuls les 60 jeux les plus suivis comptent

PLATEFORMES = {                         # code -> nom affiche
    "pc": "PC",
    "ps5": "PS5",
    "xbox": "Xbox Series",
    "switch2": "Switch 2",
    "switch": "Switch",
}

MOIS = ("janvier", "fevrier", "mars", "avril", "mai", "juin", "juillet", "aout",
        "septembre", "octobre", "novembre", "decembre")
MONTHS = ("January", "February", "March", "April", "May", "June", "July", "August",
          "September", "October", "November", "December")


def anglais() -> bool:
    """Interface en anglais ? (les textes peints ne passent pas par Qt)."""
    try:
        from .i18n import actif, langue
        return actif() and langue() == "en"
    except Exception:
        return False


def _t(texte: str) -> str:
    from .i18n import t
    return t(texte)


@dataclass(frozen=True)
class Sortie:
    id: str
    titre: str
    date: str = ""                          # « AAAA-MM-JJ » si la date est officielle
    fenetre: str = ""                       # sinon : « Fin 2027 », « 2028 »...
    plateformes: tuple[str, ...] = ()
    studio: str = ""
    genre: str = ""
    steam: str = ""                         # identifiant Steam (visuels, envies)
    couleurs: tuple[str, str] = ("#1B2233", "#0A0D14")
    vedette: bool = False
    lien: str = ""                          # page officielle
    source: str = ""                        # annonce qui confirme la date
    attente: int = 0                        # 0-100 : a quel point le jeu est attendu
    rang: int = 0                           # rang Steam (listes de souhaits), 0 = hors Steam
    image: str = ""                         # visuel officiel d'un jeu absent de Steam
    mot: str = ""                           # remarque affichee sous la date (facultatif)
    #: « a la une » (2.1.0) : prend la place de la vedette jusqu'a sa sortie
    #: et pendant `DISPONIBLE_JOURS` apres, avec son bloc prix (precommandes)
    une: bool = False
    #: offre de fidelite de l'editeur : {"serie": "call of duty", "texte": "..."}
    fidelite: dict | None = None
    #: Instant Gaming (10 octobre, test de toutes les pages de la page Sorties) :
    #: la fiche du jeu lui-meme, ouverte et avec un prix ce jour-la ; pas de
    #: lien quand Instant Gaming n'a pas encore de prix (Metro 2039, God of
    #: War Laufey, Final Fantasy VII Revelation, Kingmakers).
    #: fiches de revendeurs choisies a la main (10 octobre : un code Nintendo
    #: eShop chez Instant Gaming pour Zelda) : ({"site", "url", "quoi"}, ...).
    #: Toujours apres la boutique officielle, jamais « meilleur prix ».
    revendeurs: tuple = ()

    @property
    def jour(self) -> dt.date | None:
        try:
            return dt.date.fromisoformat(self.date) if self.date else None
        except ValueError:
            return None

    @property
    def instant(self) -> dt.datetime | None:
        """Minuit (heure du PC) le jour de la sortie."""
        j = self.jour
        return dt.datetime(j.year, j.month, j.day) if j else None

    @property
    def lien_boutique(self) -> str:
        if self.steam:
            return f"https://store.steampowered.com/app/{self.steam}/"
        return self.lien

    @classmethod
    def depuis(cls, d: dict) -> "Sortie":
        """Sortie d'une entree du fichier. Leve KeyError/TypeError/ValueError
        si l'entree est inutilisable ; un champ mal forme est ignore."""
        if not isinstance(d, dict):
            raise TypeError("entree de sortie attendue sous forme de dictionnaire")
        ident, titre = _champ(d.get("id")), _champ(d.get("titre"))
        if not ident or not titre:
            raise KeyError("id et titre obligatoires")
        plateformes = d.get("plateformes")
        if not isinstance(plateformes, (list, tuple)):
            plateformes = ()
        steam = _champ(d.get("steam"))
        vedette = isinstance(d.get("vedette"), (bool, int)) and bool(d.get("vedette"))
        return cls(
            id=ident, titre=titre, date=_champ(d.get("date")),
            fenetre=_champ(d.get("fenetre")),
            plateformes=tuple(p for p in plateformes if isinstance(p, str) and p in PLATEFORMES),
            studio=_champ(d.get("studio")), genre=_champ(d.get("genre")),
            steam=steam if steam.isdigit() else "",
            couleurs=couleurs_valides(d.get("couleurs")),
            vedette=vedette, lien=_adresse(d.get("lien")),
            source=_adresse(d.get("source")),
            attente=max(0, min(100, _entier(d.get("attente") or None,
                                            100 if vedette else 0))),
            rang=max(0, _entier(d.get("rang"), 0)),
            image=_image(d.get("image")), mot=_champ(d.get("mot"))[:160],
            une=isinstance(d.get("une"), (bool, int)) and bool(d.get("une")),
            fidelite=_fidelite(d.get("fidelite")),
            revendeurs=_revendeurs(d.get("revendeurs")))


def _fidelite(valeur) -> dict | None:
    """{"serie", "texte"} bien formes, sinon None (texte d'editeur, borne)."""
    if not isinstance(valeur, dict):
        return None
    serie, texte = _champ(valeur.get("serie"))[:40], _champ(valeur.get("texte"))[:400]
    return {"serie": serie, "texte": texte} if serie and texte else None


COULEURS_DEFAUT = ("#1B2233", "#0A0D14")
_HEXA = re.compile(r"#[0-9A-Fa-f]{6}")


def couleurs_valides(valeur) -> tuple[str, str]:
    """Deux couleurs « #RRGGBB », sinon les couleurs par defaut."""
    if isinstance(valeur, (list, tuple)) and len(valeur) >= 2:
        paire = tuple(valeur[:2])
        if all(isinstance(c, str) and _HEXA.fullmatch(c) for c in paire):
            return paire
    return COULEURS_DEFAUT


def _champ(valeur) -> str:
    """Texte d'un champ du fichier en ligne (nombre accepte, rien d'autre)."""
    if isinstance(valeur, bool) or valeur is None:
        return ""
    if isinstance(valeur, (str, int)):
        return str(valeur).strip()
    return ""


def _adresse(valeur) -> str:
    v = _champ(valeur)
    return v if v.startswith(("https://", "http://")) else ""


#: revendeurs admis dans `revendeurs` (ceux qu'ORION propose deja)
SITES_REVENDEURS = {"instant-gaming": ("Instant Gaming", "www.instant-gaming.com"),
                    "kinguin": ("Kinguin", "www.kinguin.net"),
                    "loaded": ("Loaded", "www.loaded.com")}


def _revendeurs(valeur) -> tuple:
    """Fiches de revendeurs valides : site connu, adresse https de ce site,
    sans parametre (les suivis publicitaires comme gclid ou _gl sont retires ;
    l'identifiant partenaire est ajoute a l'affichage)."""
    out = []
    for v in valeur if isinstance(valeur, (list, tuple)) else ():
        if not isinstance(v, dict) or v.get("site") not in SITES_REVENDEURS:
            continue
        url = _adresse(v.get("url")).split("#")[0].split("?")[0]
        hote = SITES_REVENDEURS[v["site"]][1]
        if not url.startswith(f"https://{hote}/") or len(url) > 300:
            continue
        out.append({"site": v["site"], "url": url, "quoi": _champ(v.get("quoi"))[:80]})
    return tuple(out[:3])


def liens_revendeurs(s: "Sortie") -> list[tuple[str, str, str]]:
    """(nom, adresse avec l'identifiant partenaire, quoi) de chaque fiche."""
    from .affiliation import affilier
    return [(SITES_REVENDEURS[r["site"]][0], affilier(r["url"]), r["quoi"]) for r in s.revendeurs]


def _image(valeur) -> str:
    """Adresse d'un visuel : https uniquement (le fichier vient d'internet)."""
    v = _adresse(valeur)
    return v if v.startswith("https://") and len(v) <= 300 else ""


def _entier(valeur, defaut: int) -> int:
    if isinstance(valeur, bool) or valeur in (None, ""):
        return defaut
    try:
        return int(float(valeur))
    except (TypeError, ValueError, OverflowError):
        return defaut


# ----------------------------------------------------------------------
# Liste embarquee (releve du 27/09/2026, annonces officielles)
# ----------------------------------------------------------------------
MAJ = "2026-10-10"

EMBARQUEE: list[dict] = [
    {"id": "minecraft-dungeons-2", "attente": 65, "titre": "Minecraft Dungeons II", "date": "2026-09-29",
     "plateformes": ["pc", "ps5", "xbox", "switch2"], "studio": "Mojang Studios",
     "genre": "Action-aventure", "steam": "1912410", "couleurs": ["#5FAE3B", "#1D2E14"],
     "lien": "https://www.minecraft.net/en-us/about-dungeons-ii",
     "source": "https://www.minecraft.net/en-us/article/minecraft-dungeons-ii-date-announce"},
    {"id": "ace-combat-8", "attente": 60, "titre": "Ace Combat 8: Wings of Theve", "date": "2026-10-02",
     "plateformes": ["pc", "ps5", "xbox"], "studio": "Bandai Namco",
     "genre": "Combat aerien", "steam": "2288340", "couleurs": ["#6FA8DC", "#0B1B2E"],
     "lien": "https://en.bandainamcoent.eu/ace-combat",
     "source": "https://blog.playstation.com/2026/06/02/ace-combat-8-wings-of-theve-launches-globally-october-2-on-ps5/"},
    {"id": "gears-e-day", "attente": 78, "titre": "Gears of War: E-Day", "date": "2026-10-06",
     "plateformes": ["pc", "xbox"], "studio": "The Coalition", "genre": "Tir a la troisieme personne",
     "steam": "3010850", "couleurs": ["#C0392B", "#1A0B0B"],
     "lien": "https://www.xbox.com/games/gears-of-war-eday",
     "source": "https://www.xbox.com/en-US/games/gears-of-war-eday"},
    {"id": "star-wars-galactic-racer", "attente": 62, "titre": "Star Wars: Galactic Racer", "date": "2026-10-06",
     "plateformes": ["pc", "ps5", "xbox"], "studio": "Fuse Games", "genre": "Course",
     "steam": "4078430", "couleurs": ["#F5A623", "#1B1206"],
     "lien": "https://www.starwars.com/games-apps",
     "source": "https://wearesecretmode.com/news/star-wars-galactic-racer-release-date"},
    {"id": "castlevania-belmonts-curse", "attente": 60, "titre": "Castlevania: Belmont's Curse",
     "date": "2026-10-15", "plateformes": ["pc", "ps5", "xbox"], "studio": "Konami",
     "genre": "Action", "steam": "4231820", "couleurs": ["#8E1B2E", "#12060A"],
     "lien": "https://www.konami.com/games/eu/en/topics/19188/",
     "revendeurs": [{"site": "instant-gaming", "quoi": "Cle Steam PC (Europe)",
                     "url": "https://www.instant-gaming.com/fr/21801-acheter-castlevania-belmont-s-curse-pc-steam/"}],
     "source": "https://www.konami.com/games/eu/en/topics/19188/"},
    {"id": "cod-mw4", "attente": 80, "titre": "Call of Duty: Modern Warfare 4", "date": "2026-10-23",
     "plateformes": ["pc", "ps5", "xbox", "switch2"], "studio": "Infinity Ward",
     "genre": "Tir", "steam": "4435490", "couleurs": ["#9BA88A", "#12140E"],
     "lien": "https://www.callofduty.com/",
     "source": "https://www.xbox.com/en-US/games/call-of-duty-modern-warfare-4",
     "une": True, "page": "/call-of-duty-modern-warfare-4",
     "mot": "Precommandes ouvertes. Pas dans le Game Pass au lancement.",
     "revendeurs": [{"site": "kinguin", "quoi": "Cle Microsoft Store PC (Europe, precommande)",
                     "url": "https://www.kinguin.net/fr/category/536535/call-of-duty-modern-warfare-4-pre-order-eu-pc-windows-cd-key"},
                    {"site": "instant-gaming", "quoi": "Cle Microsoft Store (PC et Xbox)",
                     "url": "https://www.instant-gaming.com/fr/16809-acheter-call-of-duty-modern-warfare-4-xbox-series-x-s-pc-microsoft-store/"}],
     "fidelite": {"serie": "call of duty",
                  "texte": "Steam : -10 % sur l'edition Coffre d'armes en precommande jusqu'au "
                           "23 octobre si vous possedez Modern Warfare II, Modern Warfare III, "
                           "Black Ops 6 ou Black Ops 7 sur ce compte Steam et y avez joue "
                           "(remise appliquee par Steam au paiement)."}},
    {"id": "phantom-blade-zero", "attente": 70, "titre": "Phantom Blade Zero", "date": "2026-10-29",
     "plateformes": ["pc", "ps5"], "studio": "S-GAME", "genre": "Action",
     "steam": "4115450", "couleurs": ["#B8342F", "#0C0A0A"],
     "lien": "https://www.phantomblade.com/",
     "revendeurs": [{"site": "instant-gaming", "quoi": "Cle Steam PC (Europe)",
                     "url": "https://www.instant-gaming.com/fr/14205-acheter-steam-phantom-blade-zero-pc-steam/"}],
     "source": "https://x.com/pbzero_official/status/2061938441185821154"},
    {"id": "zelda-ocarina-of-time", "attente": 90, "titre": "The Legend of Zelda: Ocarina of Time",
     "date": "2026-11-05", "plateformes": ["switch2"], "studio": "Nintendo",
     "genre": "Action-aventure", "couleurs": ["#2F8F5B", "#C9A43B"],
     "image": "https://img-eshop.cdn.nintendo.net/i/8507e0aad9ed021b24bb3ae45209e71be675557d3579f1577f4127fd965b9dd9.jpg?w=1000",
     "lien": "https://www.nintendo.com/fr-fr/Jeux/Jeux-Nintendo-Switch-2/The-Legend-of-Zelda-Ocarina-of-Time-3115664.html",
     # boutique officielle (10 octobre : la page Nintendo France, avec l'eShop,
     # a la place de la boutique americaine)
     "boutique": {"nom": "Nintendo eShop (France)",
                  "url": "https://www.nintendo.com/fr-fr/Jeux/Jeux-Nintendo-Switch-2/The-Legend-of-Zelda-Ocarina-of-Time-3115664.html"},
     "revendeurs": [{"site": "instant-gaming", "quoi": "Code Nintendo eShop (Switch 2, Europe)",
                     "url": "https://www.instant-gaming.com/fr/22210-acheter-the-legend-of-zelda-ocarina-of-time-switch-2-nintendo-eshop/"}],
     "source": "https://www.nintendolife.com/news/2026/09/zelda-ocarina-of-time-launches-on-switch-2-on-5th-november-2026"},
    {"id": "gta-6", "attente": 100, "titre": "Grand Theft Auto VI", "date": "2026-11-19",
     "plateformes": ["ps5", "xbox"], "studio": "Rockstar Games", "genre": "Action, monde ouvert",
     "couleurs": ["#FF3E8A", "#FF9F43"], "vedette": True,
     "image": "https://www.rockstargames.com/VI/-/opengraph-image.jpg",
     "mot": "Pas de version PC au lancement. Rockstar nous garde pour le dessert, comme d'habitude.",
     "lien": "https://www.rockstargames.com/VI",
     "revendeurs": [{"site": "instant-gaming", "quoi": "Code PS5 (Europe)",
                     "url": "https://www.instant-gaming.com/fr/15506-acheter-grand-theft-auto-vi-playstation-5-playstation-store/"},
                    {"site": "instant-gaming", "quoi": "Code Xbox Series (Europe)",
                     "url": "https://www.instant-gaming.com/fr/15505-acheter-grand-theft-auto-vi-xbox-series-x-s-microsoft-store/"}],
     "source": "https://gamerant.com/gta-6-release-date-reaffirmed-november-19-2026/"},
    {"id": "dawn-of-war-4", "attente": 60, "titre": "Warhammer 40,000: Dawn of War IV", "date": "2026-12-03",
     "plateformes": ["pc"], "studio": "King Art Games", "genre": "Strategie en temps reel",
     "steam": "2272360", "couleurs": ["#A67C2E", "#140F06"],
     "lien": "https://www.deepsilver.com/games/dawn-of-war-iv",
     "revendeurs": [{"site": "instant-gaming", "quoi": "Cle Steam PC (Europe)",
                     "url": "https://www.instant-gaming.com/fr/20153-acheter-steam-warhammer-40-000-dawn-of-war-iv-pc-steam/"}],
     "source": "https://www.gematsu.com/2026/08/warhammer-40000-dawn-of-war-iv-delayed-to-december-3"},
    {"id": "stranger-than-heaven", "attente": 62, "titre": "Stranger Than Heaven", "date": "2027-01-15",
     "plateformes": ["pc", "ps5", "xbox"], "studio": "RGG Studio", "genre": "Action-aventure",
     "couleurs": ["#D4A24C", "#1A1206"],
     "lien": "https://ryu-ga-gotoku.com/",
     "revendeurs": [{"site": "instant-gaming", "quoi": "Cle Steam PC (Europe)",
                     "url": "https://www.instant-gaming.com/fr/18302-acheter-stranger-than-heaven-pc-steam/"}],
     "source": "https://www.sega.co.jp/en/release/260608_3.html"},
    {"id": "metro-2039", "attente": 72, "titre": "Metro 2039", "date": "2027-02-04",
     "plateformes": ["pc", "ps5", "xbox"], "studio": "4A Games", "genre": "Tir, survie",
     "steam": "2590240", "couleurs": ["#7A8B6F", "#0B0D0A"],
     "lien": "https://www.deepsilver.com/games/metro2039",
     "source": "https://www.deepsilver.com/games/metro2039/news/metro-2039-launches-february-4th-2027"},
    {"id": "tomb-raider-atlantis", "attente": 75, "titre": "Tomb Raider: Legacy of Atlantis",
     "date": "2027-02-12", "plateformes": ["pc", "ps5", "xbox", "switch2"],
     "studio": "Crystal Dynamics", "genre": "Action-aventure", "steam": "3558670",
     "couleurs": ["#2BA6A0", "#0A1A1A"],
     "lien": "https://www.tombraider.com/",
     "revendeurs": [{"site": "instant-gaming", "quoi": "Cle Steam PC (Europe)",
                     "url": "https://www.instant-gaming.com/fr/21377-acheter-steam-tomb-raider-legacy-of-atlantis-pc-steam/"}],
     "source": "https://blog.playstation.com/2026/06/02/tomb-raider-legacy-of-atlantis-launches-feb-12-2027-on-ps5/"},
    {"id": "god-of-war-laufey", "attente": 85, "titre": "God of War Laufey", "date": "2027-02-16",
     "plateformes": ["ps5"], "studio": "Santa Monica Studio", "genre": "Action-aventure",
     "couleurs": ["#5B8DB8", "#0B1320"],
     "lien": "https://www.playstation.com/",
     "source": "https://www.gematsu.com/2026/07/god-of-war-laufey-launches-february-16-2027"},
    {"id": "persona-4-revival", "attente": 70, "titre": "Persona 4 Revival", "date": "2027-02-18",
     "plateformes": ["pc", "ps5", "xbox"], "studio": "Atlus", "genre": "Jeu de role",
     "steam": "2963950", "couleurs": ["#F2C230", "#1A1504"],
     "lien": "https://atlus.com/",
     "revendeurs": [{"site": "instant-gaming", "quoi": "Cle Steam PC (Europe)",
                     "url": "https://www.instant-gaming.com/fr/16604-acheter-steam-persona-4-revival-pc-steam/"}],
     "source": "https://sega.co.jp/en/release/260608_4.html"},
    {"id": "fable", "attente": 85, "titre": "Fable", "date": "2027-02-23",
     "plateformes": ["pc", "ps5", "xbox"], "studio": "Playground Games", "genre": "Jeu de role",
     "steam": "2769570", "couleurs": ["#6BA368", "#101A0F"],
     "lien": "https://www.xbox.com/games/fable",
     "revendeurs": [{"site": "instant-gaming", "quoi": "Cle Microsoft Store (PC et Xbox)",
                     "url": "https://www.instant-gaming.com/fr/22985-acheter-fable-pc-xbox-series-x-s-microsoft-store/"}],
     "source": "https://www.videogameschronicle.com/news/after-being-delayed-to-2027-fable-finally-has-an-actual-release-date/"},
    {"id": "ff7-revelation", "attente": 85, "titre": "Final Fantasy VII Revelation", "date": "2027-04-08",
     "plateformes": ["pc", "ps5", "xbox", "switch2"], "studio": "Square Enix",
     "genre": "Jeu de role", "steam": "4354570", "couleurs": ["#4E7FC0", "#0A1224"],
     "lien": "https://www.square-enix-games.com/",
     "source": "https://press.na.square-enix.com/FINAL-FANTASY-VII-REVELATION-RELEASES-APRIL-8-2027-ON-PHYSICAL-AND-DIG"},
    {"id": "kingmakers", "attente": 72, "titre": "Kingmakers", "fenetre": "Acces anticipe : date non annoncee",
     "plateformes": ["pc"], "studio": "Redemption Road", "genre": "Action",
     "steam": "2109770", "couleurs": ["#C9A24A", "#15110A"],
     "lien": "https://store.steampowered.com/app/2109770/",
     "source": "https://store.steampowered.com/app/2109770/",
     "mot": "Repousse en octobre 2025, toujours sans date : un nouveau test public est annonce."},
    {"id": "kingdom-hearts-4", "attente": 80, "titre": "Kingdom Hearts IV", "fenetre": "Fin 2027",
     "studio": "Square Enix", "genre": "Jeu de role", "couleurs": ["#3D6FD1", "#E8C45A"],
     "lien": "https://www.kingdomhearts.com/",
     "source": "https://press.na.square-enix.com/KINGDOM-HEARTS-IV-RELEASING-IN-LATE-2027"},
    {"id": "witcher-4", "attente": 95, "titre": "The Witcher 4", "fenetre": "2028",
     "plateformes": ["pc", "ps5", "xbox"], "studio": "CD Projekt Red", "genre": "Jeu de role",
     "couleurs": ["#9C2F2F", "#0F0A0A"],
     "lien": "https://www.thewitcher.com/",
     "source": "https://www.gamespot.com/articles/witcher-4-release-window-narrowed-down-to-2028/"},
    {"id": "intergalactic", "attente": 85, "titre": "Intergalactic: The Heretic Prophet",
     "fenetre": "Date non annoncee", "plateformes": ["ps5"], "studio": "Naughty Dog",
     "genre": "Action-aventure", "couleurs": ["#E8483F", "#1A0708"],
     "lien": "https://www.naughtydog.com/"},
    {"id": "elder-scrolls-6", "attente": 95, "titre": "The Elder Scrolls VI", "fenetre": "Date non annoncee",
     "studio": "Bethesda Game Studios", "genre": "Jeu de role",
     "couleurs": ["#8C7A5B", "#12100C"], "lien": "https://elderscrolls.bethesda.net/"},
]


# ----------------------------------------------------------------------
def lire(donnees) -> list[Sortie]:
    """Sorties d'un document {format, maj, sorties}, les entrees invalides ignorees.

    Ne leve jamais : un document mal forme (liste a la place d'un
    dictionnaire, entrees nulles ou en texte...) donne une liste vide ou
    partielle."""
    if not isinstance(donnees, dict):
        return []
    entrees = donnees.get("sorties")
    if not isinstance(entrees, (list, tuple)):
        return []
    out = []
    for d in entrees:
        if not isinstance(d, dict):
            continue
        try:
            s = Sortie.depuis(d)
        except (KeyError, TypeError, ValueError, AttributeError):
            continue
        if s.titre and (s.jour or s.fenetre or not s.date):
            out.append(s)
    return out


def embarquee() -> list[Sortie]:
    return lire({"format": FORMAT, "maj": MAJ, "sorties": EMBARQUEE})


def choisir(distant, locale_maj: str = MAJ) -> tuple[list[Sortie], str]:
    """Liste en ligne si elle est valide et plus recente, sinon l'embarquee."""
    try:
        if (isinstance(distant, dict) and _entier(distant.get("format"), 0) == FORMAT
                and isinstance(distant.get("maj"), str) and distant["maj"] >= locale_maj):
            liste = lire(distant)
            if liste:
                return liste, str(distant["maj"])
    except (TypeError, ValueError, AttributeError, KeyError):
        pass
    return embarquee(), locale_maj


def charger_etat() -> tuple[list[Sortie], str, bool]:
    """(sorties, date de mise a jour, en ligne). Ne leve jamais.

    `en ligne` est faux quand ni la liste en ligne ni le classement Steam
    n'ont pu etre lus (premier demarrage hors ligne) : l'appelant doit alors
    reessayer au retour du reseau au lieu d'attendre 6 heures."""
    from .core import reseau
    try:
        distant = reseau.get_json(URL, garder=GARDER, timeout=10)
    except Exception as exc:
        log.info("Liste des sorties en ligne indisponible : %s", exc)
        distant = None
    steam = charger_steam()
    # hors ligne, `get_json` rend la version gardee d'une session precedente :
    # elle s'affiche, mais la lecture sera refaite au retour du reseau
    try:
        coupe = bool(reseau.hors_ligne())
    except Exception:
        coupe = False
    try:
        officielles, maj = choisir(distant)
        return (fusionner(officielles, steam), maj,
                bool(distant is not None or steam) and not coupe)
    except Exception as exc:                      # filet : jamais d'erreur ici
        log.warning("Liste des sorties illisible : %s", exc)
        return embarquee(), MAJ, False


def charger() -> tuple[list[Sortie], str]:
    """(sorties, date de mise a jour). Ne leve jamais : hors ligne, liste embarquee.

    La liste officielle (en ligne ou embarquee) est completee par les jeux
    a venir les plus suivis sur Steam."""
    liste, maj, _ = charger_etat()
    return liste, maj


# ----------------------------------------------------------------------
# Steam : les jeux a venir les plus suivis (listes de souhaits)
# ----------------------------------------------------------------------
_MOIS_EN = {m[:3].lower(): i + 1 for i, m in enumerate(MONTHS)}
_LIGNE = re.compile(r'<a[^>]*data-ds-appid="([\d,]+)"[^>]*>(.*?)</a>', re.S)
_TITRE = re.compile(r'<span class="title">(.*?)</span>', re.S)
_SORTIE = re.compile(r'search_released[^"]*"[^>]*>(.*?)</div>', re.S)
TRIMESTRES = ("1er trimestre", "2e trimestre", "3e trimestre", "4e trimestre")


def _texte(fragment: str) -> str:
    return html.unescape(re.sub(r"<[^>]+>", "", fragment or "")).strip()


def date_steam(texte: str) -> tuple[str, str]:
    """(date AAAA-MM-JJ, fenetre) d'apres la date de sortie d'une fiche Steam
    (en anglais). ('', '') si aucune date n'est annoncee."""
    t = re.sub(r"\s+", " ", _texte(texte))
    m = (re.fullmatch(r"(\d{1,2}) ([A-Za-z]{3})[a-z]*\.?,? (\d{4})", t)
         or re.fullmatch(r"([A-Za-z]{3})[a-z]*\.? (\d{1,2}),? (\d{4})", t))
    if m:
        a, b, annee = m.groups()
        jour, mois = (a, b) if a.isdigit() else (b, a)
        n = _MOIS_EN.get(mois.lower())
        if n:
            try:
                return dt.date(int(annee), n, int(jour)).isoformat(), ""
            except ValueError:
                return "", ""
    m = re.fullmatch(r"Q([1-4]) (\d{4})", t)
    if m:
        return "", f"{TRIMESTRES[int(m.group(1)) - 1]} {m.group(2)}"
    m = re.fullmatch(r"([A-Za-z]+) (\d{4})", t)
    if m and m.group(1)[:3].lower() in _MOIS_EN:
        return "", f"{MOIS[_MOIS_EN[m.group(1)[:3].lower()] - 1].capitalize()} {m.group(2)}"
    if re.fullmatch(r"\d{4}", t):
        return "", t
    return "", ""


def couleurs_de(titre: str) -> tuple[str, str]:
    """Deux teintes stables tirees du titre (affiche peinte en attendant l'image)."""
    h = int(hashlib.sha1(titre.encode("utf-8", "ignore")).hexdigest()[:6], 16) % 360 / 360

    def hexa(teinte, lum, sat):
        r, g, b = colorsys.hls_to_rgb(teinte % 1, lum, sat)
        return "#%02X%02X%02X" % (int(r * 255), int(g * 255), int(b * 255))
    return hexa(h, 0.45, 0.55), hexa(h + 0.1, 0.10, 0.5)


def lire_steam(corps) -> list[Sortie]:
    """Sorties d'une page de resultats Steam (filtre « popularwishlist »)."""
    out, vus = [], set()
    for rang, (ids, bloc) in enumerate(_LIGNE.findall((corps or {}).get("results_html") or ""), 1):
        appid = ids.split(",")[0]
        m = _TITRE.search(bloc)
        titre = _texte(m.group(1)) if m else ""
        brut = _SORTIE.search(bloc)
        date, fenetre = date_steam(brut.group(1) if brut else "")
        if rang > RANG_MAX:
            break
        if not titre or appid in vus or not (date or fenetre):
            continue
        vus.add(appid)
        out.append(Sortie(
            id=f"steam-{appid}", titre=titre, date=date, fenetre=fenetre,
            plateformes=("pc",), steam=appid, couleurs=couleurs_de(titre),
            attente=max(20, 90 - rang), rang=rang,
            source=f"https://store.steampowered.com/app/{appid}/"))
    return out


def charger_steam() -> list[Sortie]:
    from .core import reseau, steam_limite
    try:
        corps = reseau.get_json(
            STEAM_URL, garder=STEAM_GARDER, timeout=15, headers=steam_limite.NAVIGATEUR,
            params={"query": "", "start": 0, "count": 100, "filter": "popularwishlist",
                    "infinite": 1, "l": "english", "cc": region.cc()})
    except Exception as exc:
        log.info("Jeux a venir Steam indisponibles : %s", exc)
        return []
    try:
        return lire_steam(corps)
    except Exception as exc:                       # format change : on s'en passe
        log.info("Jeux a venir Steam illisibles : %s", exc)
        return []


def _cle_titre(titre: str) -> str:
    """Cle de comparaison des titres (ponctuation, ™ ®, accents, chiffres
    romains ignores). VIDE pour un titre sans lettre latine ni chiffre :
    une cle vide ne sert jamais a dire que deux jeux sont les memes."""
    from .core.recherche import cle_titre
    return cle_titre(titre)


def fusionner(officielles: list[Sortie], steam: list[Sortie]) -> list[Sortie]:
    """Liste officielle d'abord (elle connait les consoles), completee par Steam.
    Un jeu present des deux cotes garde la fiche officielle et prend le rang Steam."""
    def cles(s: Sortie) -> set[str]:
        k = _cle_titre(s.titre)
        return {c for c in (f"app:{s.steam}" if s.steam else "", f"t:{k}" if k else "") if c}

    rangs: dict[str, int] = {}
    for s in steam:
        for c in cles(s):
            rangs.setdefault(c, s.rang)
    out = []
    for s in officielles:
        c = cles(s)
        rang = rangs.get(f"app:{s.steam}") if s.steam else None
        if not rang:
            rang = next((rangs[x] for x in c if x.startswith("t:") and x in rangs), 0)
        out.append(replace(s, rang=rang or 0))
    deja: set[str] = set()
    for s in officielles:
        deja |= cles(s)
    for s in steam:
        c = cles(s)
        if c & deja:
            continue
        out.append(s)
        deja |= c
    return out


# ----------------------------------------------------------------------
def restant(s: Sortie, maintenant: dt.datetime | None = None) -> dt.timedelta | None:
    """Temps avant la sortie (negatif si deja sorti), None sans date exacte."""
    i = s.instant
    if i is None:
        return None
    return i - (maintenant or dt.datetime.now())


def a_venir(liste: list[Sortie], maintenant: dt.datetime | None = None
            ) -> tuple[list[Sortie], list[Sortie]]:
    """(datees, sans date) : sorties a venir ou recentes, dans l'ordre."""
    maintenant = maintenant or dt.datetime.now()
    datees = [s for s in liste if s.instant is not None
              and restant(s, maintenant) > -dt.timedelta(days=DISPONIBLE_JOURS)]
    datees.sort(key=lambda s: (s.instant, s.titre.lower()))
    sans = [s for s in liste if s.instant is None]
    return datees, sans


def selection(datees: list[Sortie], sans: list[Sortie]) -> tuple[list[Sortie], list[Sortie]]:
    """Ce que la page montre : toutes les sorties officielles, completees par
    les jeux Steam les plus attendus jusqu'a `AFFICHEES` sorties datees (et
    `ANNONCES` sans date precise). Quand un jeu sort puis quitte la page, le
    suivant du classement prend sa place."""
    def garder(liste, maximum):
        officielles = [s for s in liste if not s.id.startswith("steam-")]
        steam = sorted((s for s in liste if s.id.startswith("steam-")),
                       key=lambda s: (-s.attente, s.rang))
        choix = set(id(s) for s in officielles + steam[:max(0, maximum - len(officielles))])
        return [s for s in liste if id(s) in choix]
    return garder(datees, AFFICHEES), garder(sans, ANNONCES)


def vedette(datees: list[Sortie], maintenant: dt.datetime | None = None,
            horizon_jours: int = 120) -> Sortie | None:
    """La sortie mise en avant : la plus attendue parmi celles des 4 prochains
    mois (a egalite, la plus proche), sinon la prochaine. Une fois sortie,
    elle passe la main automatiquement."""
    # « a la une » : choisie par l'auteur (sorties.json), avant la sortie et
    # pendant les jours ou elle est « disponible » (ventes du lancement)
    unes = [s for s in datees if s.une
            and restant(s, maintenant) > -dt.timedelta(days=DISPONIBLE_JOURS)]
    if unes:
        return min(unes, key=lambda s: s.instant)
    futures = [s for s in datees if restant(s, maintenant) > dt.timedelta(0)]
    if not futures:
        return None
    proches = [s for s in futures if restant(s, maintenant) <= dt.timedelta(days=horizon_jours)]
    if proches:
        return max(proches, key=lambda s: (s.attente, -s.instant.timestamp()))
    return futures[0]


def filtrer(liste: list[Sortie], plateforme: str) -> list[Sortie]:
    if not plateforme or plateforme == "toutes":
        return list(liste)
    return [s for s in liste if plateforme in s.plateformes]


def decompte(delta: dt.timedelta | None) -> tuple[int, int, int, int] | None:
    """(jours, heures, minutes, secondes) restants, None si sorti ou sans date."""
    if delta is None or delta.total_seconds() <= 0:
        return None
    total = int(delta.total_seconds())
    j, reste = divmod(total, 86400)
    h, reste = divmod(reste, 3600)
    m, sec = divmod(reste, 60)
    return j, h, m, sec


def texte_decompte(delta: dt.timedelta | None) -> str:
    d = decompte(delta)
    if delta is None:
        return ""
    en = anglais()
    if d is None:
        jours = int(-delta.total_seconds() // 86400)
        if jours <= 0:
            return "Out today" if en else "Disponible aujourd'hui"
        if jours == 1:
            return "Out since yesterday" if en else "Disponible depuis hier"
        return f"Out for {jours} days" if en else f"Disponible depuis {jours} jours"
    j, h, m, s = d
    if j:
        return f"{j} {'d' if en else 'j'}  {h:02d} h  {m:02d} min  {s:02d} s"
    return f"{h:02d} h  {m:02d} min  {s:02d} s"


def date_lisible(s: Sortie) -> str:
    j = s.jour
    if j is None:
        return _t(s.fenetre or "Date non annoncee")
    if anglais():
        return f"{MONTHS[j.month - 1]} {j.day}, {j.year}"
    return f"{j.day if j.day > 1 else '1er'} {MOIS[j.month - 1]} {j.year}"


def noms_plateformes(s: Sortie) -> list[str]:
    return [PLATEFORMES[p] for p in s.plateformes if p in PLATEFORMES]


# ----------------------------------------------------------------------
# Visuels (fiche Steam), mis en cache sur le disque
# ----------------------------------------------------------------------
def dossier_visuels() -> Path:
    from .core.paths import CACHE_DIR
    return CACHE_DIR / "sorties"


VIDE_GARDER = 24 * 3600                 # fiche Steam sans visuel : reessai apres 24 h


def _nom(s: Sortie) -> str:
    return s.steam or re.sub(r"[^A-Za-z0-9_-]", "_", s.id)[:80] or "sortie"


def visuels(s: Sortie) -> dict[str, str]:
    """{'carte': chemin, 'fond': chemin} deja telecharges, ou {}."""
    out = {}
    for cle in ("carte", "fond"):
        p = dossier_visuels() / f"{_nom(s)}-{cle}.jpg"
        try:
            if p.exists() and p.stat().st_size > 1000:
                out[cle] = str(p)
        except OSError:
            pass
    meta = dossier_visuels() / f"{_nom(s)}-meta.json"
    try:
        lu = json.loads(meta.read_text(encoding="utf-8")) if meta.exists() else {}
    except (OSError, ValueError):
        lu = {}
    if isinstance(lu, dict):
        out.update({k: v for k, v in lu.items()
                    if k in ("studio", "genre") and isinstance(v, str) and v})
    if not s.steam and "fond" in out:
        out.setdefault("carte", out["fond"])    # visuel officiel : le meme partout
    return out


def _marque_vide(s: Sortie):
    return dossier_visuels() / f"{_nom(s)}-vide.txt"


def sans_visuel_recent(s: Sortie, maintenant: dt.datetime | None = None) -> bool:
    """Vrai si la fiche Steam n'avait aucun visuel il y a moins de 24 h :
    inutile de la redemander a chaque visite de la page."""
    try:
        quand = dt.datetime.fromisoformat(_marque_vide(s).read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        return False
    age = ((maintenant or dt.datetime.now()) - quand).total_seconds()
    return 0 <= age < VIDE_GARDER


def _noter_vide(s: Sortie) -> None:
    try:
        dossier_visuels().mkdir(parents=True, exist_ok=True)
        _marque_vide(s).write_text(dt.datetime.now().isoformat(timespec="seconds"),
                                   encoding="utf-8")
    except OSError:
        pass


def telecharger_visuels(s: Sortie, arreter=None) -> dict[str, str]:
    """Recupere l'en-tete et une capture de la fiche Steam (une fois).

    * fiche sans donnees ni image : memorise 24 h (pas de nouvel appel) ;
    * reponse vide de Steam : c'est une limitation, Steam est mis en pause
      (`steam_limite.signaler_refus`) et les jeux suivants attendront."""
    deja = visuels(s)
    if not s.steam and s.image and "fond" not in deja:
        return _telecharger_image(s, deja, arreter)
    if not s.steam or ("carte" in deja and "fond" in deja):
        return deja
    from .core import reseau, steam_limite
    if steam_limite.en_pause() or sans_visuel_recent(s):
        return deja
    try:
        r = reseau.get("https://store.steampowered.com/api/appdetails",
                       params={"appids": s.steam, "l": region.langue_steam()},
                       headers=steam_limite.NAVIGATEUR, timeout=12)
    except Exception as exc:
        log.info("Visuels de %s indisponibles : %s", s.titre, exc)
        return deja
    if r.status_code in (403, 429):              # `reseau` a deja mis Steam en pause
        return deja
    try:
        corps = r.json()
    except Exception:
        corps = None
    if not isinstance(corps, dict) or not corps:
        log.info("Visuels de %s : reponse vide, Steam limite les demandes", s.titre)
        steam_limite.signaler_refus()
        return deja
    bloc = steam_limite.fiche(corps, s.steam) or {}
    data = bloc.get("data") if bloc.get("success") else None
    data = data if isinstance(data, dict) else {}
    from . import contenu_adulte
    if contenu_adulte.fiche_adulte(data):        # jamais d'image de ces jeux
        contenu_adulte.marquer(s.steam)
        return deja
    captures = [c.get("path_full") for c in data.get("screenshots") or []
                if isinstance(c, dict) and isinstance(c.get("path_full"), str)
                and c.get("path_full")]
    adresses = {"carte": data.get("header_image") or "",
                "fond": captures[0] if captures else (data.get("background_raw") or "")}
    adresses = {k: v for k, v in adresses.items() if isinstance(v, str) and v}
    if not data or not adresses:
        _noter_vide(s)
        return deja

    def noms(cle):
        return ", ".join(str(x.get("description", "") if isinstance(x, dict) else x)
                         for x in (data.get(cle) or [])[:2] if x)
    meta = {"studio": ", ".join(str(x) for x in (data.get("developers") or [])[:1]),
            "genre": noms("genres")}
    try:
        dossier_visuels().mkdir(parents=True, exist_ok=True)
        (dossier_visuels() / f"{s.steam}-meta.json").write_text(
            json.dumps(meta, ensure_ascii=False), encoding="utf-8")
        deja.update({k: v for k, v in meta.items() if v})
    except OSError:
        pass
    absents = 0
    for cle, url in adresses.items():
        if cle in deja:
            continue
        if _arret_demande(arreter) or steam_limite.en_pause():
            break                            # partie commencee, ou Steam limite
        cible = dossier_visuels() / f"{s.steam}-{cle}.jpg"
        try:
            reseau.telecharger(url, cible, timeout=30)
            deja[cle] = str(cible)
        except Exception as exc:
            code = getattr(getattr(exc, "response", None), "status_code", 0) or 0
            if 400 <= code < 500 and code not in (403, 429):
                absents += 1                 # image retiree : inutile d'insister
            log.info("Visuel %s de %s : %s", cle, s.titre, exc)
    if absents and "carte" not in deja and "fond" not in deja:
        _noter_vide(s)
    return deja


IMAGE_MAXI = 8 * 1024 * 1024
_SIGNATURES = (b"\xff\xd8\xff", b"\x89PNG\r\n\x1a\n", b"RIFF")     # JPEG, PNG, WebP


def _telecharger_image(s: Sortie, deja: dict[str, str], arreter=None) -> dict[str, str]:
    """Visuel officiel d'un jeu absent de Steam (champ « image » du fichier).
    Le fichier vient d'internet : seul un vrai JPEG, PNG ou WebP de taille
    raisonnable est garde ; un echec est memorise 24 h."""
    if _arret_demande(arreter) or sans_visuel_recent(s):
        return deja
    from .core import reseau
    cible = dossier_visuels() / f"{_nom(s)}-fond.jpg"
    try:
        reseau.telecharger(s.image, cible, timeout=30)
        with open(cible, "rb") as f:
            tete = f.read(12)
        if not tete.startswith(_SIGNATURES) or not 1000 < cible.stat().st_size <= IMAGE_MAXI:
            cible.unlink(missing_ok=True)
            raise ValueError("ce n'est pas une image utilisable")
    except Exception as exc:
        log.info("Visuel de %s indisponible : %s", s.titre, exc)
        _noter_vide(s)
        return deja
    deja["fond"] = deja["carte"] = str(cible)
    return deja


def _arret_demande(arreter) -> bool:
    if arreter is None:
        return False
    try:
        return bool(arreter())
    except Exception:
        return True


def illustrer(liste: list[Sortie], arreter=None, pret=None) -> dict[str, dict[str, str]]:
    """Visuels de plusieurs sorties, a la suite, en tache de fond.

    S'arrete des que `arreter()` est vrai (une partie vient de commencer) ou
    que Steam limite les demandes : les sorties restantes seront illustrees
    plus tard."""
    from .core import steam_limite
    out: dict[str, dict[str, str]] = {}
    for s in liste:
        if _arret_demande(arreter) or (s.steam and steam_limite.en_pause()):
            break
        try:
            out[s.id] = telecharger_visuels(s, arreter)
        except Exception as exc:                  # filet : une sortie ne bloque pas les autres
            log.info("Visuels de %s : %s", getattr(s, "titre", "?"), exc)
            continue
        if pret is not None and out[s.id]:
            try:                                  # chaque affiche s'affiche des qu'elle arrive
                pret(s.id, out[s.id])
            except Exception:
                pass
    return out
