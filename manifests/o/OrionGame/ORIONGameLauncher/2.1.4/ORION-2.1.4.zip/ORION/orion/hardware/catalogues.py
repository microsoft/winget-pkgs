"""Catalogues de pilotes des constructeurs de PC (Dell, Lenovo, HP).

Sur un PC de marque, le bon pilote reseau, audio, chipset ou graphique est
celui que le constructeur a valide pour *ce modele*, et il le publie dans un
catalogue par modele, le meme que lisent Dell Command Update, Lenovo System
Update et HP Image Assistant :

* **Dell** : `downloads.dell.com/catalog/CatalogIndexPC.cab` (index de 1 700
  modeles, cle = « System ID » de quatre caracteres hexa, celui que Windows
  donne comme numero de produit), puis un catalogue par modele (`.cab` d'un
  XML UTF-16, composants `SoftwareComponent` avec leurs `PCIInfo`).
* **Lenovo** : `download.lenovo.com/catalog/<type machine>_Win11.xml` (index
  des paquets du modele, avec leur categorie), puis une fiche XML par paquet
  (`DetectInstall/_Driver` : identifiants materiels, version, date).
* **HP** : `hpia.hpcloud.hp.com/ref/<plateforme>/<plateforme>_64_11.0.<release>.cab`
  (fichier de reference de la plateforme, la plateforme etant le modele de la
  carte mere, « 83E0 »).

Ce module ne telecharge que sur un PC de marque, une fois tous les trois
jours, dans un fil de fond (`lancer`) ; le resultat (`cache/pilotes-constructeur.json`)
ne contient que des versions et des identifiants de puces. Les `.cab` sont
ouverts avec `expand.exe` de Windows. Les lectures (`lire_dell`,
`lire_lenovo_index`, `lire_lenovo_paquet`, `lire_hp`) sont des fonctions
pures, testees sur de vrais fichiers des trois constructeurs (8 octobre 2026).
"""
from __future__ import annotations

import datetime as _dt
import json
import re
import subprocess
import tempfile
import threading
import time
import xml.etree.ElementTree as ET
from dataclasses import asdict, dataclass, field
from pathlib import Path

from ..core.events import BUS
from ..core.logging_setup import get
from ..core.paths import CACHE_DIR, is_windows

log = get("hardware.catalogues")

FICHIER = CACHE_DIR / "pilotes-constructeur.json"
FRAICHEUR = 3 * 24 * 3600
EVENEMENT = "pilotes.maj"
DELAI = 60
CREATE_NO_WINDOW = 0x08000000

DELL_INDEX = "https://downloads.dell.com/catalog/CatalogIndexPC.cab"
DELL_BASE = "https://downloads.dell.com/"
DELL_PAGE = "https://www.dell.com/support/home/fr-fr/drivers/driversdetails?driverid={id}"
LENOVO_INDEX = "https://download.lenovo.com/catalog/{mt}_{os}.xml"
LENOVO_PAGE = "https://pcsupport.lenovo.com/fr/fr/products/{mt}/downloads/driver-list"
HP_REF = "https://hpia.hpcloud.hp.com/ref/{pf}/{pf}_64_{os}.cab"
HP_PAGE = "https://support.hp.com/fr-fr/drivers"

#: categories Lenovo qui nous concernent (les autres : BIOS, firmware,
#: utilitaires, camera, empreinte... ne sont pas des pilotes de jeu)
LENOVO_CATEGORIES = ("audio", "networking", "bluetooth", "display and video", "storage",
                     "motherboard devices", "usb device", "chipset")
#: releases de Windows 11 par numero de build (pour l'adresse HP)
RELEASES = {"22000": "21H2", "22621": "22H2", "22631": "23H2", "26100": "24H2", "26200": "25H2"}
RELEASES_ORDRE = ("25H2", "24H2", "23H2", "22H2", "21H2")

_MOIS_EN = {m: i for i, m in enumerate(
    ("january", "february", "march", "april", "may", "june", "july", "august",
     "september", "october", "november", "december"), 1)}
_ID = re.compile(r"(PCI|USB|HDAUDIO|INTELAUDIO|ACPI)?\\?.*?(VEN|VID)_([0-9A-F]{4})&(DEV|PID)_([0-9A-F]{4})"
                 r"(?:&SUBSYS_([0-9A-F]{8}))?", re.I)


# --------------------------------------------------------------------------
# modele
# --------------------------------------------------------------------------

@dataclass
class Offre:
    """Un pilote publie par le constructeur pour ce modele."""
    source: str                       # Dell | Lenovo | HP
    nom: str
    version: str
    date: str = ""                    # AAAA-MM-JJ
    categorie: str = ""               # categorie du constructeur, texte
    ids: list[str] = field(default_factory=list)   # « 8086:15BB » ou « 8086:15BB:1028:09CD »
    details: str = ""                 # page officielle du pilote (ou du modele)
    fichier: str = ""                 # fichier officiel

    def convient(self, cle: str, sous_systeme: str = "") -> int:
        """0 : pas pour cette puce ; 1 : meme puce ; 2 : meme puce et meme
        sous-systeme (la version exacte de ce modele)."""
        c = _normaliser(cle)
        if not c:
            return 0
        exact = f"{c}:{sous_systeme.upper()}" if sous_systeme else ""
        score = 0
        for i in self.ids:
            if exact and i == exact:
                return 2
            if i == c or i.startswith(c + ":"):
                score = 1
        return score


def _normaliser(identifiant: str) -> str:
    """« PCI\\VEN_8086&DEV_15BB&SUBSYS_83E0103C&REV_10 » -> « 8086:15BB » ;
    le sous-systeme n'est garde que par `sous_systeme()`."""
    m = _ID.search((identifiant or "").strip())
    return f"{m.group(3).upper()}:{m.group(5).upper()}" if m else ""


def sous_systeme(identifiant: str, bus: str = "") -> str:
    """Le sous-systeme dans l'ordre fabricant:modele quel que soit le bus :
    PCI ecrit « SUBSYS_<modele><fabricant> », HDAUDIO « SUBSYS_<fabricant><modele> »."""
    m = _ID.search((identifiant or "").strip())
    if not m or not m.group(6):
        return ""
    s = m.group(6).upper()
    b = (bus or m.group(1) or "").upper()
    return f"{s[:4]}:{s[4:]}" if b in ("HDAUDIO", "INTELAUDIO") else f"{s[4:]}:{s[:4]}"


def plus_recente(installee: str, publiee: str) -> bool:
    """Vrai si `publiee` est strictement plus recente (comparaison numerique,
    composant par composant : « 1168.009.0614.2022 » vaut « 1168.9.614.2022 »)."""
    try:
        a = [int(x) for x in re.findall(r"\d+", installee or "")]
        b = [int(x) for x in re.findall(r"\d+", publiee or "")]
    except ValueError:
        return False
    if not a or not b or len(a) != len(b):
        return False                     # deux schemas de numerotation : rien a comparer
    for x, y in zip(a, b):
        if y != x:
            return y > x
    return False


@dataclass
class Catalogue:
    source: str
    modele: str                       # identifiant du modele chez le constructeur
    lu: float
    offres: list[Offre] = field(default_factory=list)
    erreur: str = ""

    @property
    def date(self) -> _dt.date:
        return _dt.date.fromtimestamp(self.lu)

    def pour(self, pilote) -> Offre | None:
        """L'offre la plus recente du constructeur pour cette puce, si elle
        est plus recente que le pilote installe ; le sous-systeme exact
        l'emporte sur la puce seule."""
        cle = getattr(pilote, "id_materiel", "") or ""
        if not cle:
            return None
        ss = sous_systeme(cle, getattr(pilote, "bus", ""))
        meilleure: tuple[int, list[int], Offre] | None = None
        for o in self.offres:
            score = o.convient(cle, ss)
            if not score or not plus_recente(pilote.version, o.version):
                continue
            rang = (score, [int(x) for x in re.findall(r"\d+", o.version)])
            if meilleure is None or rang > meilleure[:2]:
                meilleure = (score, rang[1], o)
        return meilleure[2] if meilleure else None

    def vers_json(self) -> dict:
        return {"source": self.source, "modele": self.modele, "lu": self.lu, "erreur": self.erreur,
                "offres": [asdict(o) for o in self.offres]}

    @classmethod
    def depuis_json(cls, d: dict) -> "Catalogue":
        c = cls(source=str(d.get("source") or ""), modele=str(d.get("modele") or ""),
                lu=float(d.get("lu") or 0), erreur=str(d.get("erreur") or ""))
        for o in d.get("offres") or []:
            if isinstance(o, dict) and o.get("version"):
                c.offres.append(Offre(**{k: o.get(k, "") for k in ("source", "nom", "version", "date",
                                                                   "categorie", "details", "fichier")},
                                      ids=[str(x) for x in o.get("ids") or []]))
        return c


# --------------------------------------------------------------------------
# lectures (fonctions pures)
# --------------------------------------------------------------------------

def _date_en(texte: str) -> str:
    """« January 15, 2023 » -> « 2023-01-15 » ; sinon les dix premiers
    caracteres d'une date ISO, ou ""."""
    t = (texte or "").strip()
    m = re.match(r"([A-Za-z]+)\s+(\d{1,2}),?\s*(\d{4})", t)
    if m and m.group(1).lower() in _MOIS_EN:
        return f"{m.group(3)}-{_MOIS_EN[m.group(1).lower()]:02d}-{int(m.group(2)):02d}"
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})", t)
    return m.group(0) if m else ""


def _texte(donnees) -> str:
    if isinstance(donnees, bytes):
        for enc in ("utf-8-sig", "utf-16"):
            try:
                return donnees.decode(enc)
            except UnicodeDecodeError:
                continue
        return donnees.decode("utf-8", errors="replace")
    return str(donnees or "")


def lire_dell_index(donnees) -> dict[str, tuple[str, str]]:
    """CatalogIndexPC.xml -> {System ID: (nom du modele, chemin du catalogue)}."""
    root = ET.fromstring(_texte(donnees).encode("utf-8") if not isinstance(donnees, bytes) else donnees)
    ns = "{openmanage/cm/dm}"
    out: dict[str, tuple[str, str]] = {}
    for g in root.iter(ns + "GroupManifest"):
        mi = g.find(ns + "ManifestInformation")
        chemin = (mi.get("path") if mi is not None else "") or ""
        if not chemin:
            continue
        for m in g.iter(ns + "Model"):
            sid = (m.get("systemID") or "").strip().upper()
            if sid:
                out[sid] = ((m.findtext(ns + "Display") or "").strip(), chemin)
    return out


def lire_dell(donnees) -> list[Offre]:
    """Catalogue d'un modele Dell -> offres (pilotes seulement)."""
    root = ET.fromstring(donnees if isinstance(donnees, bytes) else _texte(donnees).encode("utf-8"))
    ns = "{openmanage/cm/dm}"
    out: list[Offre] = []
    for c in root.iter(ns + "SoftwareComponent"):
        ct = c.find(ns + "ComponentType")
        if ct is None or (ct.get("value") or "") != "DRVR":
            continue
        nom = (c.findtext(ns + "Name/" + ns + "Display") or "").strip()
        cat = (c.findtext(ns + "Category/" + ns + "Display") or "").strip()
        date = _date_en(c.get("releaseDate") or "") or _date_en(c.get("dateTime") or "")
        chemin = c.get("path") or ""
        page = DELL_PAGE.format(id=c.get("releaseID")) if c.get("releaseID") else ""
        par_version: dict[str, list[str]] = {}
        for d in c.iter(ns + "Device"):
            v = (d.get("version") or c.get("vendorVersion") or "").strip()
            if not v:
                continue
            ids = par_version.setdefault(v, [])
            for p in d.iter(ns + "PCIInfo"):
                ven, dev = (p.get("vendorID") or "").upper(), (p.get("deviceID") or "").upper()
                if len(ven) == 4 and len(dev) == 4:
                    sv, sd = (p.get("subVendorID") or "").upper(), (p.get("subDeviceID") or "").upper()
                    ids.append(f"{ven}:{dev}:{sv}:{sd}" if sv and sd else f"{ven}:{dev}")
            for g in d.iter(ns + "Generic"):
                n = _normaliser(g.text or "")
                if n:
                    ids.append(n)
        for v, ids in par_version.items():
            if ids:
                out.append(Offre("Dell", nom, v, date, cat, sorted(set(ids)), page,
                                 DELL_BASE + chemin if chemin else ""))
    return out


def lire_lenovo_index(donnees) -> list[tuple[str, str]]:
    """<type>_Win11.xml -> [(categorie, adresse de la fiche)], categories
    utiles seulement."""
    root = ET.fromstring(_texte(donnees).encode("utf-8"))
    out = []
    for p in root.iter("package"):
        cat = (p.findtext("category") or "").strip()
        url = (p.findtext("location") or "").strip()
        if url and any(c in cat.lower() for c in LENOVO_CATEGORIES):
            out.append((cat, url))
    return out


def lire_lenovo_paquet(donnees, adresse: str = "", categorie: str = "") -> list[Offre]:
    """Fiche d'un paquet Lenovo -> offres (une par bloc `_Driver` apparie par
    identifiant materiel : la fiche audio porte le codec Realtek et, a part,
    le composant Dolby). Vide si ce n'est pas un pilote."""
    texte = _texte(donnees)
    try:
        root = ET.fromstring(texte.encode("utf-8"))
    except ET.ParseError:
        return []
    nom = (root.findtext("Title/Desc") or root.get("name") or "").strip()
    sortie = _date_en(root.findtext("ReleaseDate") or "")
    base = adresse.rsplit("/", 1)[0] + "/" if "/" in adresse else ""
    fichier = page = ""
    for f in root.iter("File"):
        n = (f.findtext("Name") or "").strip()
        if n.lower().endswith(".exe") and not fichier:
            fichier = base + n
        elif n.lower().endswith(".html") and not page:
            page = base + n
    out: list[Offre] = []
    detect = root.find("DetectInstall")
    for d in (detect.iter("_Driver") if detect is not None else []):
        v = (d.findtext("Version") or "").strip().split("^")[0]
        if not v or v in ("0.1", "0"):
            continue
        ids: list[str] = []
        for h in d.findall("HardwareID"):
            n = _normaliser(h.text or "")
            if n:
                ss = sous_systeme(h.text or "")
                ids.append(f"{n}:{ss}" if ss else n)
        if ids:
            out.append(Offre("Lenovo", nom, v, _date_en(d.findtext("Date") or "") or sortie,
                             categorie, sorted(set(ids)), page, fichier))
    return out


def lire_hp(donnees) -> list[Offre]:
    """Fichier de reference HP Image Assistant d'une plateforme -> offres.
    (Forme a confirmer sur le fichier reel de la plateforme 83E0.)"""
    root = ET.fromstring(donnees if isinstance(donnees, bytes) else _texte(donnees).encode("utf-8"))
    out: list[Offre] = []
    for u in root.iter("UpdateInfo"):
        cat = (u.findtext("Category") or "").strip()
        if not cat.lower().startswith("driver"):
            continue
        version = (u.findtext("Version") or "").strip()
        ids = []
        for d in u.iter("DeviceID"):
            n = _normaliser(d.text or "")
            if n:
                ss = sous_systeme(d.text or "")
                ids.append(f"{n}:{ss}" if ss else n)
        if not ids or not version:
            continue
        url = (u.findtext("Url") or "").strip()
        if url and not url.startswith("http"):
            url = "https://" + url
        notes = (u.findtext("ReleaseNotesUrl") or "").strip()
        if notes and not notes.startswith("http"):
            notes = "https://" + notes
        out.append(Offre("HP", (u.findtext("Name") or "").strip(), version,
                         _date_en(u.findtext("DateReleased") or ""), cat, sorted(set(ids)),
                         notes or HP_PAGE, url))
    return out


# --------------------------------------------------------------------------
# identite du PC chez son constructeur
# --------------------------------------------------------------------------

def identite(etat) -> tuple[str, str]:
    """(constructeur, identifiant du modele) : (« Dell », « 0BEB »),
    (« Lenovo », « 20U9 »), (« HP », « 83E0 ») ; ("", "") sinon."""
    if etat is None:
        return "", ""
    from .systeme import simple
    fab = simple(etat.pc[0] if etat.pc else "")
    sku = (getattr(etat, "pc_sku", "") or "").strip()
    modele = (etat.pc[1] if etat.pc else "") or ""
    if "dell" in fab or "alienware" in fab:
        if re.fullmatch(r"[0-9A-Fa-f]{4}", sku):
            return "Dell", sku.upper()
        return "", ""
    if "lenovo" in fab:
        m = re.search(r"MT_([0-9A-Za-z]{4})", sku) or re.match(r"([0-9A-Za-z]{4})", modele.strip())
        return ("Lenovo", m.group(1).upper()) if m else ("", "")
    if "hewlett" in fab or fab.startswith("hp"):
        cm = (etat.carte_mere[1] if etat.carte_mere else "") or ""
        if re.fullmatch(r"[0-9A-Fa-f]{4}", cm.strip()):
            return "HP", cm.strip().upper()
    return "", ""


# --------------------------------------------------------------------------
# collecte (reseau, Windows)
# --------------------------------------------------------------------------

def _ouvrir_cab(contenu: bytes) -> bytes:
    """Le premier fichier d'un .cab, par expand.exe de Windows."""
    from ..core.lancement import popen_propre
    with tempfile.TemporaryDirectory(prefix="orion-cab-") as tmp:
        cab = Path(tmp) / "catalogue.cab"
        cab.write_bytes(contenu)
        sortie = Path(tmp) / "sortie"
        sortie.mkdir()
        proc = popen_propre(["expand.exe", str(cab), "-F:*", str(sortie)],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                            stdin=subprocess.DEVNULL, creationflags=CREATE_NO_WINDOW)
        proc.communicate(timeout=DELAI)
        fichiers = sorted(sortie.glob("*"))
        if not fichiers:
            raise RuntimeError("cab vide")
        return fichiers[0].read_bytes()


def _prendre(url: str) -> bytes:
    from ..core import reseau
    r = reseau.get(url, timeout=DELAI)
    if r.status_code != 200:
        raise RuntimeError(f"HTTP {r.status_code}")
    return r.content


def collecter(etat, os_build: str = "") -> Catalogue | None:
    """Le catalogue du constructeur pour ce PC, dans le fil appelant (long).
    None si ce PC n'est pas un Dell, Lenovo ou HP identifiable."""
    source, modele = identite(etat)
    if not source:
        return None
    cat = Catalogue(source=source, modele=modele, lu=time.time())
    try:
        if source == "Dell":
            index = lire_dell_index(_ouvrir_cab(_prendre(DELL_INDEX)))
            nom, chemin = index.get(modele, ("", ""))
            if not chemin:
                raise RuntimeError(f"modele {modele} absent de l'index Dell")
            cat.offres = lire_dell(_ouvrir_cab(_prendre(DELL_BASE + chemin)))
        elif source == "Lenovo":
            os_ = "Win11" if (os_build or "22000") >= "22000" else "Win10"
            fiches = lire_lenovo_index(_prendre(LENOVO_INDEX.format(mt=modele, os=os_)))
            for categorie, url in fiches[:40]:
                try:
                    cat.offres += lire_lenovo_paquet(_prendre(url), url, categorie)
                except Exception as exc:
                    log.debug("Fiche Lenovo illisible (%s) : %s", url, exc)
        elif source == "HP":
            actuelle = RELEASES.get(os_build, "25H2")
            essais = RELEASES_ORDRE[RELEASES_ORDRE.index(actuelle):] if actuelle in RELEASES_ORDRE else RELEASES_ORDRE
            contenu = None
            for rel in essais:
                for pf in (modele.lower(), modele.upper()):
                    try:
                        contenu = _ouvrir_cab(_prendre(HP_REF.format(pf=pf, os=f"11.0.{rel}")))
                        break
                    except Exception:
                        continue
                if contenu:
                    break
            if not contenu:
                raise RuntimeError(f"aucun fichier de reference HP pour {modele}")
            cat.offres = lire_hp(contenu)
        log.info("Catalogue %s (%s) : %d pilote(s)", source, modele, len(cat.offres))
    except Exception as exc:
        cat.erreur = str(exc) or exc.__class__.__name__
        log.info("Catalogue %s (%s) non lu : %s", source, modele, cat.erreur)
    return cat


# --------------------------------------------------------------------------
# cache et fil de fond
# --------------------------------------------------------------------------
_DERNIER: Catalogue | None = None
_VERROU = threading.Lock()
_EN_COURS = False


def dernier() -> Catalogue | None:
    global _DERNIER
    with _VERROU:
        if _DERNIER is None:
            try:
                _DERNIER = Catalogue.depuis_json(json.loads(FICHIER.read_text(encoding="utf-8")))
            except Exception:
                return None
        return _DERNIER


def frais(c: Catalogue | None, etat=None) -> bool:
    if c is None or time.time() - c.lu >= FRAICHEUR:
        return False
    return etat is None or (c.source, c.modele) == identite(etat)


def lancer(etat, os_build: str = "", force: bool = False) -> bool:
    """Lit le catalogue du constructeur en fond si celui connu est perime ;
    `pilotes.maj` est emis a la fin. Rien hors Windows ni hors PC de marque."""
    global _EN_COURS
    if not is_windows() or not identite(etat)[0]:
        return False
    connu = dernier()
    with _VERROU:
        if _EN_COURS or (not force and frais(connu, etat)):
            return False
        _EN_COURS = True

    def travail() -> None:
        global _EN_COURS, _DERNIER
        try:
            c = collecter(etat, os_build)
            if c is not None:
                with _VERROU:
                    _DERNIER = c
                if c.offres:
                    try:
                        FICHIER.parent.mkdir(parents=True, exist_ok=True)
                        FICHIER.write_text(json.dumps(c.vers_json(), ensure_ascii=False), encoding="utf-8")
                    except Exception:
                        log.debug("Cache du catalogue constructeur non ecrit")
        finally:
            with _VERROU:
                _EN_COURS = False
            try:
                BUS.emit(EVENEMENT)
            except Exception:
                pass

    threading.Thread(target=travail, name="orion-catalogue-constructeur", daemon=True).start()
    return True
