"""Liens partenaires (affiliation) — 1.8.1.

Quand le joueur ouvre la page d'un jeu sur une boutique partenaire, ORION
ajoute l'identifiant partenaire du projet au lien. Le prix paye ne change
pas ; une petite commission revient au developpement d'ORION.

Regles :

* les identifiants sont ecrits ICI, dans le code : ce sont des
  identifiants publics (ils apparaissent dans l'adresse), qui ne donnent
  acces a rien. Aucune coordonnee, aucun compte, aucune page de gestion
  n'est dans ORION, et un joueur ne peut ni les voir ni les remplacer
  depuis l'application (comme le lien de don) ;
* les liens fournis par IsThereAnyDeal (itad.link) ne sont JAMAIS
  modifies : leurs conditions d'utilisation l'interdisent ;
* le joueur peut couper les liens partenaires (Reglages > Boutique) ;
* un site sans identifiant renseigne recoit le lien tel quel.

Deux formes de liens selon les programmes :
* « parametre » : on ajoute ?cle=valeur a l'adresse de la boutique ;
* « gabarit »   : le reseau d'affiliation (Impact, CJ, Awin...) enveloppe
  l'adresse : https://reseau/.../?u={url} (adresse encodee).
"""
from __future__ import annotations

import urllib.parse
import webbrowser
from dataclasses import dataclass, field

from .core.config import CONFIG

#: domaines jamais modifies (conditions d'utilisation des fournisseurs)
INTOUCHABLES = ("itad.link", "isthereanydeal.com")


@dataclass(frozen=True)
class Programme:
    id: str
    nom: str
    domaines: tuple[str, ...]
    parametres: dict = field(default_factory=dict)   # forme « parametre »
    gabarit: str = ""                                 # forme « gabarit », {url}

    @property
    def actif(self) -> bool:
        """Vrai seulement avec un identifiant renseigne : un parametre prevu
        mais encore vide (programme en attente) laisse le lien intact."""
        return bool(self.gabarit or any(v for v in self.parametres.values()))


#: identifiants a renseigner une fois les programmes valides.
#: Etat des candidatures :
#: * Eneba : refusee -> aucun identifiant, liens laisses intacts, ORION ne
#:   la presente nulle part comme partenaire ;
#: * AllKeyShop : refusee (comparateur, absent de cette table : liens intacts) ;
#: * Gamesplanet : acceptee (commission 10 % / 5 %, cookie de 30 jours),
#:   identifiant « ref=orion » delivre le 30/09/2026 ;
#: * G2A et Gamivo : identifiants obtenus, mais ces places de marche sont
#:   ecartees (`marche_gris.RETENUS` : Instant Gaming, Kinguin, Loaded) :
#:   ORION n'affiche aucun de leurs liens, l'identifiant ne sert a rien tant
#:   que cette regle tient.
PROGRAMMES: tuple[Programme, ...] = (
    Programme("instant-gaming", "Instant Gaming", ("instant-gaming.com",), {"igr": "Sikher"}),
    Programme("eneba", "Eneba", ("eneba.com",)),                 # candidature refusee
    Programme("kinguin", "Kinguin", ("kinguin.net",), {"r": "w0405u433koc0"}),
    Programme("g2a", "G2A", ("g2a.com",), {"gtag": "6ce1b9d684"}),
    Programme("gamivo", "Gamivo", ("gamivo.com",), {"glv": "Oriongames"}),
    # accepte le 05/10/2026 par le reseau Impact (2 a 5 %, suivi de 30 jours).
    # Lien de suivi du programme ; « u » porte la page d'arrivee (essaye le
    # 05/10 : la recherche demandee s'ouvre bien).
    Programme("loaded", "Loaded", ("loaded.com",),
              gabarit="https://go.loaded.com/xJDad5?u={url}"),
    Programme("driffle", "Driffle", ("driffle.com",)),
    Programme("humble", "Humble Bundle", ("humblebundle.com",)),
    Programme("fanatical", "Fanatical", ("fanatical.com",)),
    Programme("gmg", "Green Man Gaming", ("greenmangaming.com",)),
    # identifiant attribue par Gamesplanet le 30/09/2026 (cookie 30 jours)
    Programme("gamesplanet", "Gamesplanet", ("gamesplanet.com",), {"ref": "orion"}),
    # materiel neuf (2.1.0, `materiel`) : aucun programme signe pour l'instant,
    # liens de recherche laisses intacts et jamais presentes comme partenaires
    Programme("ldlc", "LDLC", ("ldlc.com",)),
    Programme("materiel-net", "Materiel.net", ("materiel.net",)),
)


def actifs() -> bool:
    return bool(CONFIG.get("boutique.liens_partenaires", True))


#: adresse -> programme, pour la table en vigueur. La Boutique pose la
#: question pour chaque offre a chaque arrivee du catalogue (2 500 adresses
#: analysees, les memes toutes les douze minutes).
_memo: dict[str, "Programme | None"] = {}
_memo_table: tuple | None = None
_MEMO_MAX = 20000


def programme_de(url: str, table: tuple[Programme, ...] | None = None) -> Programme | None:
    global _memo_table
    if table is None:
        if _memo_table is not PROGRAMMES:        # table remplacee : on repart de rien
            _memo.clear()
            _memo_table = PROGRAMMES
        try:
            return _memo[url]
        except (KeyError, TypeError):
            pass
    trouve = _programme_de(url, table if table is not None else PROGRAMMES)
    if table is None and isinstance(url, str):
        if len(_memo) >= _MEMO_MAX:
            _memo.clear()
        _memo[url] = trouve
    return trouve


def _programme_de(url: str, table: tuple[Programme, ...]) -> Programme | None:
    hote = (urllib.parse.urlparse(url or "").hostname or "").lower()
    if not hote or any(hote == d or hote.endswith("." + d) for d in INTOUCHABLES):
        return None
    for p in table:
        if any(hote == d or hote.endswith("." + d) for d in p.domaines):
            return p
    return None


def affilier(url: str, table: tuple[Programme, ...] | None = None) -> str:
    """Adresse avec l'identifiant partenaire si la boutique en a un."""
    if not url or not actifs():
        return url
    p = programme_de(url, table)
    if p is None or not p.actif:
        return url
    if p.gabarit:
        # deja enveloppee (un lien affilie rouvert) : jamais deux fois
        if url.startswith(p.gabarit.split("{url}")[0]):
            return url
        return p.gabarit.replace("{url}", urllib.parse.quote(url, safe=""))
    morceaux = urllib.parse.urlsplit(url)
    remplis = {k: v for k, v in p.parametres.items() if v}
    requete = [(k, v) for k, v in urllib.parse.parse_qsl(morceaux.query, keep_blank_values=True)
               if k not in remplis]
    requete += list(remplis.items())
    return urllib.parse.urlunsplit(morceaux._replace(query=urllib.parse.urlencode(requete, safe=",")))


#: liens partenaires du SITE : via le service, qui ajoute l'identifiant et
#: compte le clic (16 octobre 2026). Les adresses partenaires ecrites en
#: clair dans 1 100 fiches etaient suivies par Googlebot : 99 des 100
#: derniers « clics » Kinguin venaient de 66.249.x.x. `/aller/` est interdit
#: aux robots par le robots.txt du service. L'application, elle, ouvre les
#: liens directement (`affilier`) : pas de robot dans ORION.
ALLER_SITE = "https://api.orion-launcher.com/aller/"
VIA_LE_SITE = ("kinguin", "instant-gaming", "loaded", "gamesplanet")


def lien_site(url: str, page: str = "") -> str:
    """Adresse a ecrire dans une page du site pour `url` : via `/aller/` pour
    les partenaires suivis par le service (identifiant ajoute la-bas, lien
    sans identifiant ici), sinon `affilier(url)`."""
    if not url:
        return url
    p = programme_de(url)
    if p is None or p.id not in VIA_LE_SITE:
        return affilier(url)
    nu = sans_identifiant(url, p)
    requete = "u=" + urllib.parse.quote(nu, safe="") + (f"&p={page}" if page else "")
    return f"{ALLER_SITE}{p.id}?{requete}"


def sans_identifiant(url: str, p: Programme | None = None) -> str:
    """L'adresse sans l'identifiant partenaire (le service le remet)."""
    p = p or programme_de(url)
    if p is None:
        return url
    if p.gabarit:
        tete = p.gabarit.split("{url}")[0]
        if url.startswith(tete):
            return urllib.parse.unquote(url[len(tete):])
        return url
    morceaux = urllib.parse.urlsplit(url)
    requete = [(k, v) for k, v in urllib.parse.parse_qsl(morceaux.query, keep_blank_values=True)
               if not (k in p.parametres and v == p.parametres[k])]
    return urllib.parse.urlunsplit(morceaux._replace(query=urllib.parse.urlencode(requete, safe=",")))


def est_partenaire(url: str) -> bool:
    p = programme_de(url)
    return bool(actifs() and p is not None and p.actif)


def ouvrir(url: str, origine: str = "") -> None:
    """Ouvre un lien de boutique (avec l'identifiant partenaire s'il existe).
    Tout lien de boutique d'ORION passe par ici : c'est donc ici que le clic
    est compte (nom de la boutique seulement, si le joueur a dit oui)."""
    webbrowser.open(affilier(url))
    try:
        from . import compteur
        compteur.clic(url, origine)
    except Exception:
        pass


def ouvreur(origine: str):
    """`ouvrir` pour une page donnee : chaque page declare d'ou vient le clic."""
    def _ouvrir(url: str) -> None:
        ouvrir(url, origine)
    return _ouvrir
