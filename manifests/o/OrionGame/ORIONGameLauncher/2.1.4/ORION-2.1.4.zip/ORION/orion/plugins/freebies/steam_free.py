"""Gratuites reperees directement sur Steam.

Trois cas sont couverts sans cle d'API :

* une promotion a -100 %, c'est-a-dire un jeu offert pour un temps limite
  mais garde a vie une fois ajoute au compte ;
* les jeux dont le prix est simplement zero, gratuits pour toujours ;
* les week-ends gratuits, annonces par Steam dans les encarts de sa page
  d'accueil (« Weekend gratuit »). C'est la seule gratuite qui s'arrete
  vraiment : passee la periode, il faut acheter le jeu pour continuer.

Le catalogue free-to-play complet se compte en milliers de titres : seules
les mises en avant de la boutique sont retenues, pour que la page reste
lisible. Le reste se trouve par la recherche.
"""
from __future__ import annotations

from orion.core import region

import re

from ...core import steam_limite
from ...core.logging_setup import get
from .base import (A_GARDER, DEFINITIF, TEMPORAIRE, Freebie, FreebieSource,
                   SourceUnavailable, fetch_json, looks_temporary)

log = get("gratuits.steam")

FEATURED = "https://store.steampowered.com/api/featuredcategories"
DETAILS = "https://store.steampowered.com/api/appdetails"
STORE = "https://store.steampowered.com/app/{appid}"

#: rubriques de la boutique inspectees
SECTIONS = ("specials", "top_sellers", "new_releases", "coming_soon")

#: encarts de la page d'accueil : les cles sont numerotees (0, 1, 2...)
_APPID = re.compile(r"/app/(\d+)")


class SteamFreebies(FreebieSource):
    id = "steam_free"
    label = "Steam"
    priority = 70

    filtre_adulte = ("Steam ne montre pas ces jeux aux visiteurs non connectes ; la "
                     "fiche Steam lue ensuite (descripteur 3) marque le jeu")

    def fetch(self) -> list[Freebie]:
        country = region.cc()
        payload = fetch_json(FEATURED, {"cc": country, "l": region.langue_steam()}) or {}

        seen: set[str] = set()
        out: list[Freebie] = []
        # les week-ends gratuits d'abord : leur appid prime sur une
        # eventuelle promotion du meme jeu reperee plus bas.
        out.extend(self._weekends(payload, seen, country))
        for section in SECTIONS:
            block = payload.get(section) or {}
            for item in (block.get("items") or []):
                try:
                    fb = self._one(item, seen)
                except Exception:
                    continue
                if fb is not None:
                    out.append(fb)
        log.info("Steam : %d offre(s)", len(out))
        return out

    # ------------------------------------------------------------------
    def _weekends(self, payload: dict, seen: set[str],
                  country: str) -> list[Freebie]:
        """Week-ends gratuits annonces dans les encarts de la page d'accueil.

        Steam ne publie pas de date de fin exploitable pour ces offres : le
        texte de l'encart est un gabarit de traduction. ORION laisse donc la
        date vide et considere l'offre terminee le jour ou Steam cesse de
        l'annoncer — ce qui est exactement le moment ou le jeu redevient
        payant.
        """
        out: list[Freebie] = []
        for key, block in payload.items():
            if not key.isdigit() or not isinstance(block, dict):
                continue
            for item in block.get("items") or []:
                name = str(item.get("name") or "")
                if not looks_temporary(name, str(block.get("name") or "")):
                    continue
                found = _APPID.search(str(item.get("url") or ""))
                if not found:
                    continue
                appid = found.group(1)
                if appid in seen:
                    continue
                title = self._title(appid, country)
                if not title:
                    continue
                seen.add(appid)
                url = STORE.format(appid=appid)
                out.append(Freebie(
                    key=f"steam:{appid}",
                    title=title,
                    source=self.id,
                    shop="Steam",
                    url=url,
                    buy_url=url,
                    kind=TEMPORAIRE,
                    image=str(item.get("header_image") or ""),
                    steam_appid=appid,
                    description="Week-end gratuit : le jeu est jouable "
                                "gratuitement pendant toute la duree annoncee "
                                "par Steam, puis redevient payant.",
                ))
        if out:
            log.info("Steam : %d week-end(s) gratuit(s)", len(out))
        return out

    @staticmethod
    def _title(appid: str, country: str) -> str:
        """Nom du jeu : l'encart ne porte que le libelle de l'offre."""
        try:
            payload = steam_limite.fiche(
                fetch_json(DETAILS, {"appids": appid, "cc": country,
                                     "l": region.langue_steam(), "filters": "basic"},
                           timeout=9), appid)
        except SourceUnavailable:
            return ""
        if not payload.get("success"):
            return ""
        return str((payload.get("data") or {}).get("name") or "").strip()

    # ------------------------------------------------------------------
    def _one(self, item: dict, seen: set[str]) -> Freebie | None:
        appid = str(item.get("id") or "")
        if not appid or appid in seen:
            return None
        title = str(item.get("name") or "").strip()
        if not title:
            return None

        final = item.get("final_price")
        original = item.get("original_price")
        cut = int(item.get("discount_percent") or 0)

        if cut >= 100 and original:
            kind = A_GARDER
            worth = round(int(original) / 100, 2)
        elif final == 0 and not cut:
            kind = DEFINITIF
            worth = 0.0
        else:
            return None

        seen.add(appid)
        url = STORE.format(appid=appid)
        return Freebie(
            key=f"steam:{appid}",
            title=title,
            source=self.id,
            shop="Steam",
            url=url,
            buy_url=url,
            kind=kind,
            ends_at=float(item.get("discount_expiration") or 0),
            worth=worth,
            currency=str(item.get("currency") or "EUR"),
            image=str(item.get("large_capsule_image")
                      or item.get("header_image") or ""),
            steam_appid=appid,
        )
