"""Contrat commun a toutes les sources de jeux.

Pour ajouter une plateforme, creer un module dans ce dossier avec une classe
heritant de `Scanner`. Le registre la decouvre automatiquement.
"""
from __future__ import annotations

import re
from pathlib import Path

from ...core.logging_setup import get
from ...core.models import Game
from ...core.winutil import iter_exes

log = get("scanner")

#: Fichiers a ne jamais considerer comme l'executable principal d'un jeu.
EXE_BLACKLIST = re.compile(
    r"(unins|setup|install|redist|vcredist|directx|dxsetup|dotnet|oalinst|"
    r"crashreport|crashhandler|launcher_helper|bug|report|updater|patcher|"
    r"benchmark|config_tool|touchup|cleanup|activation|steamerrorreporter|"
    r"eac|easyanticheat|battleye|vc_|ue4prereq|ue5prereq|epicwebhelper|"
    r"quickspecs|notification_helper|dwhelper)", re.I)

#: Dossiers a ignorer lors de la recherche d'executables.
DIR_BLACKLIST = re.compile(
    r"(redist|_?commonredist|directx|vcredist|dotnet|support|prereq|"
    r"anticheat|easyanticheat|battleye|crashreport|tools|sdk|__installer)", re.I)


class Scanner:
    """Source de jeux. Sous-classer et implementer `available` et `scan`."""

    abstract = True
    id: str = ""
    label: str = ""
    icon: str = ""          # emoji ou nom d'icone, affiche dans l'interface
    priority: int = 50      # ordre d'execution (plus grand = plus tot)

    def available(self) -> bool:
        """La plateforme est-elle installee sur cette machine ?"""
        return False

    def scan(self) -> list[Game]:
        """Retourne les jeux detectes. Ne doit jamais lever d'exception."""
        return []

    # -- outils partages ------------------------------------------------
    def _mk(self, **kw) -> Game:
        kw.setdefault("source", self.id)
        return Game(**kw)

    def __repr__(self) -> str:          # pragma: no cover
        return f"<Scanner {self.id}>"


# --------------------------------------------------------------------------
# Heuristiques communes
# --------------------------------------------------------------------------

def _enfants(dossier: Path) -> set[str]:
    """Noms (en minuscules) du contenu d'un dossier, vide si illisible."""
    try:
        return {p.name.lower() for p in dossier.iterdir()}
    except Exception:
        return set()


#: ce que contient le dossier « Engine » d'un jeu Unreal, et lui seul
_UNREAL_ENGINE = {"binaries", "content", "extras", "plugins", "shaders"}


def _unreal(dirs: list[Path]) -> bool:
    """Signatures propres a Unreal : un dossier Engine fait comme celui
    d'Unreal, ou un projet avec Binaries/Win64 ou Content/Paks."""
    for d in dirs[:60]:
        contenu = _enfants(d)
        if d.name.lower() == "engine":
            if contenu & _UNREAL_ENGINE:
                return True
            continue
        if "binaries" in contenu and _enfants(d / "Binaries") & {"win64", "win32", "wingdk"}:
            return True
        if "content" in contenu and "paks" in _enfants(d / "Content"):
            return True
        if "engine" in contenu and "binaries" in _enfants(d / "Engine"):
            return True
    return False


def detect_engine(install_dir: Path) -> str:
    """Devine le moteur du jeu d'apres l'arborescence installee.

    La detection est volontairement tolerante : les jeux Unreal rangent leur
    projet differemment selon l'editeur (Engine a la racine, sous-dossier de
    projet, executable *-Win64-Shipping...).
    """
    try:
        if not install_dir.is_dir():
            return ""
        entries = list(install_dir.iterdir())
    except Exception:
        return ""

    names = {p.name.lower() for p in entries}
    dirs = [p for p in entries if p.is_dir()]

    # Regle : un moteur n'est reconnu que sur une signature qui lui est
    # propre. Un nom de dossier banal (« engine », « bin », « data ») ne
    # suffit jamais seul : plusieurs moteurs en ont un (REDengine, CryEngine,
    # moteurs maison), et un moteur mal devine applique la mauvaise recette.
    # Dans le doute, la fonction rend "" : ORION dit « moteur inconnu ».
    if _unreal(dirs):
        return "unreal"

    # -- Unity ----------------------------------------------------------
    if "unityplayer.dll" in names or any(n.endswith("_data") for n in names):
        return "unity"

    # -- Autres moteurs reconnaissables a la racine ----------------------
    if "bin" in names and ("hl2.exe" in names or "game" in names):
        return "source"
    if "r6" in names and "archive" in names:
        return "redengine"
    if "bin" in names and "data_win64" in names:
        return "dunia"
    if "cryengine" in names or "engine.pak" in names:
        return "cryengine"
    if "skse64_loader.exe" in names or "creationkit.exe" in names:
        return "creation"
    if "x64a.rpf" in names or ("gta5.exe" in names and "x64" in names):
        return "rage"                        # GTA V ; RDR2 a ses propres .rpf
    if "rdr2.exe" in names and any(n.endswith(".rpf") for n in names):
        return "rage"
    if "re_chunk_000.pak" in names or "re_chunk_000.pak.patch_001.pak" in names:
        return "re"                          # RE Engine (Capcom) : pas de recette, le guide

    # -- Dernier recours : le nom des executables ------------------------
    try:
        for exe in iter_exes(install_dir, max_depth=3):
            n = exe.name.lower()
            if n.endswith(("-win64-shipping.exe", "-win32-shipping.exe")):
                return "unreal"
            if n in ("unitycrashhandler64.exe", "unityplayer.dll"):
                return "unity"
    except Exception:
        pass
    return ""


def pick_main_exe(install_dir: Path, hint: str = "", min_mb: float = 0.4) -> str:
    """Choisit l'executable le plus vraisemblable dans un dossier de jeu.

    Strategie : score combinant la ressemblance avec le nom du dossier,
    la profondeur, la taille et l'absence de mots-cles d'outillage.
    """
    try:
        if not install_dir.is_dir():
            return ""
    except Exception:
        return ""

    hint_key = re.sub(r"[^a-z0-9]", "", (hint or install_dir.name).lower())
    best: tuple[float, str] = (-1e9, "")

    for exe in iter_exes(install_dir, max_depth=4):
        name = exe.name
        if EXE_BLACKLIST.search(name):
            continue
        if any(DIR_BLACKLIST.search(p) for p in exe.parts[len(install_dir.parts):-1]):
            continue
        try:
            size_mb = exe.stat().st_size / (1024 * 1024)
        except OSError:
            continue
        if size_mb < min_mb:
            continue

        stem = re.sub(r"[^a-z0-9]", "", exe.stem.lower())
        score = 0.0
        if stem and (stem in hint_key or hint_key in stem):
            score += 60
        elif stem and hint_key and stem[:6] == hint_key[:6]:
            score += 30
        score += min(size_mb / 8.0, 25)                     # les gros exe gagnent
        score -= (len(exe.parts) - len(install_dir.parts)) * 6   # la racine gagne
        if re.search(r"(shipping|win64|x64)", name, re.I):
            score += 12
        if re.search(r"launcher", name, re.I):
            score -= 18
        if score > best[0]:
            best = (score, str(exe))

    return best[1]


def looks_like_game_folder(folder: Path) -> bool:
    """Filtre grossier : le dossier ressemble-t-il a un jeu installe ?"""
    try:
        entries = list(folder.iterdir())
    except Exception:
        return False
    if not entries:
        return False
    names = {e.name.lower() for e in entries}
    markers = ("engine", "data", "bin", "content", "game", "assets", "gamedata")
    if any(m in names for m in markers):
        return True
    return any(e.suffix.lower() == ".exe" for e in entries)
