"""Fournisseurs de prix et d evaluations."""
