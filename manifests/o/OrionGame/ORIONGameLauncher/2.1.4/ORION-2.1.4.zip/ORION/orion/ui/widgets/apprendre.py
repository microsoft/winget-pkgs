"""Fenetre « Apprendre les niveaux de ce jeu » (apprentissage par l'exemple).

Le joueur lance le jeu, choisit un niveau dans son menu, quitte ; ORION
photographie ce que le jeu a ecrit. Quatre etapes, deux facultatives. Rien
n'est ecrit dans le jeu pendant l'apprentissage. Voir `optimizer/exemple.py`.
"""
from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import QDialog, QHBoxLayout, QLabel, QPushButton, QVBoxLayout

from ...core.logging_setup import get
from ...i18n import t
from ...optimizer import exemple

log = get("ui.apprendre")


class ApprendreNiveaux(QDialog):
    """Guide pas a pas. `appris(str)` : chemin de la recette enregistree."""
    appris = Signal(str)

    def __init__(self, game, parent=None) -> None:
        super().__init__(parent)
        self.game = game
        self.setWindowTitle(t("Apprendre les niveaux de {0}").replace("{0}", game.title))
        self.setMinimumWidth(560)
        self.photos: dict[str, dict] = {}
        self.etape = 0
        self.base = exemple.base_du_jeu(game)
        self.avant = exemple.photographier(game, self.base)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(22, 20, 22, 18)
        lay.setSpacing(12)
        intro = QLabel(t("ORION regarde ce que le menu du jeu ecrit pour chaque niveau de graphismes, "
                         "puis l'ecrira lui-meme. Rien n'est modifie dans le jeu pendant l'apprentissage."))
        intro.setWordWrap(True)
        lay.addWidget(intro)
        self.titre = QLabel("")
        self.titre.setStyleSheet("font-size: 15px; font-weight: 800;")
        lay.addWidget(self.titre)
        self.consigne = QLabel("")
        self.consigne.setWordWrap(True)
        lay.addWidget(self.consigne)
        self.etat = QLabel("")
        self.etat.setWordWrap(True)
        self.etat.setStyleSheet("color: #FFB454; font-weight: 600;")
        lay.addWidget(self.etat)

        bas = QHBoxLayout()
        self.lancer = QPushButton(t("Lancer le jeu"))
        self.lancer.setObjectName("Ghost")
        self.lancer.clicked.connect(self._lancer)
        bas.addWidget(self.lancer)
        bas.addStretch(1)
        self.passer = QPushButton(t("Passer cette etape"))
        self.passer.setObjectName("Ghost")
        self.passer.clicked.connect(self._passer)
        bas.addWidget(self.passer)
        self.fait = QPushButton(t("C'est fait, j'ai quitte le jeu"))
        self.fait.setDefault(True)
        self.fait.clicked.connect(self._fait)
        bas.addWidget(self.fait)
        lay.addLayout(bas)
        self._montrer()

    # ------------------------------------------------------------------
    def _nom(self) -> str:
        return exemple.ETAPES[self.etape]

    def _montrer(self) -> None:
        nom = self._nom()
        self.titre.setText(t("Etape {0} sur {1}").replace("{0}", str(self.etape + 1))
                           .replace("{1}", str(len(exemple.ETAPES))))
        self.consigne.setText(
            t("Lancez le jeu, choisissez {0} dans son menu Video (le reglage general, pas option par "
              "option), appliquez, puis quittez le jeu.").replace("{0}", t(exemple.NOMS_ETAPES[nom])))
        self.passer.setVisible(nom in exemple.FACULTATIVES)
        self.etat.setText("")

    def _lancer(self) -> None:
        """Lance le jeu tel quel : sans ecrire de reglages avant (sinon ORION
        apprendrait ses propres valeurs)."""
        try:
            from ...launch.launcher import launch_target
            ok, msg = launch_target(self.game)
            if not ok:
                self.etat.setText(t(msg))
        except Exception:
            log.exception("Lancement impossible pendant l'apprentissage")

    def _fait(self) -> None:
        from ...optimizer.securite import jeu_ouvert
        if jeu_ouvert(self.game):
            self.etat.setText(t("Le jeu est encore ouvert : quittez-le, il enregistre ses reglages en se fermant."))
            return
        photo = exemple.photographier(self.game, self.base)
        precedente = self.photos.get(exemple.ETAPES[self.etape - 1]) if self.etape else self.avant
        if self.etape and photo == precedente:
            self.etat.setText(t("Rien n'a change depuis l'etape d'avant : le niveau a-t-il bien ete "
                                "applique avant de quitter ? Recommencez cette etape."))
            return
        self.photos[self._nom()] = photo
        self._suivante()

    def _passer(self) -> None:
        self._suivante()

    def _suivante(self) -> None:
        self.etape += 1
        if self.etape < len(exemple.ETAPES):
            self._montrer()
            return
        self._terminer()

    def _terminer(self) -> None:
        self.lancer.hide()
        self.passer.hide()
        self.fait.setText(t("Fermer"))
        self.fait.clicked.disconnect()
        self.fait.clicked.connect(self.accept)
        self.titre.setText(t("Resultat"))
        r = exemple.recette(self.game, self.photos, self.base)
        if r is None:
            self.consigne.setText(t(
                "ORION n'a trouve aucun reglage qui change avec le niveau. Ce jeu range sans doute ses "
                "reglages ailleurs (dossier d'installation, fichier binaire, compte en ligne) : il se regle "
                "dans son menu, le guide de la fiche dit quoi choisir."))
            return
        chemin = exemple.enregistrer(r)
        n = int((r.get("_appris") or {}).get("cles") or 0)
        texte = t("Appris : {0} reglage(s) changent avec le niveau. ORION les ecrira desormais pour "
                  "chaque niveau, avec les valeurs du jeu lui-meme.").replace("{0}", str(n))
        from ... import partage
        if partage.actif():
            texte += " " + t("Comme vous partagez vos mesures, la recette est aussi proposee aux autres "
                             "joueurs d'ORION (rien de personnel : des noms et des valeurs de reglages).")
            try:
                import threading
                threading.Thread(target=partage.envoyer_recette, args=(r,), daemon=True).start()
            except Exception:
                log.debug("Proposition de la recette impossible")
        self.consigne.setText(texte)
        self.etat.setText("")
        self.appris.emit(str(chemin))
