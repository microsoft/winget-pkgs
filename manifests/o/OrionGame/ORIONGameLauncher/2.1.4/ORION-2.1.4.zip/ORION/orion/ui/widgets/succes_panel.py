"""Panneau « Succes » de la fiche d'un jeu (1.8, compact depuis la 1.9).

Replie par defaut : une ligne de resume, la barre de progression et une
petite grille de six succes a viser (les plus courants parmi ceux qui
manquent). « Voir tout »
deplie la liste complete, avec ses filtres : manquants (du plus courant au
plus rare), obtenus (du plus recent au plus ancien) ou tous, et la rarete
mondiale de chacun. Un succes secret non obtenu garde sa description cachee.
"""
from __future__ import annotations

import time

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (QButtonGroup, QFrame, QGridLayout, QHBoxLayout,
                               QLabel, QProgressBar, QPushButton, QVBoxLayout)

from ...comptes import resume_succes
from .layouts import clear_layout

MAX_LIGNES = 60
_DIM = "#AAB4C8"    # PALETTE["text_dim"]
APERCU = 6          # succes montres panneau replie (grille de 2 colonnes)


class SuccesPanel(QFrame):
    connexion_demandee = Signal(str)       # id de plateforme
    #: resume pour le panneau « Infos » : {obtenus, total, pourcentage, ...}
    #: ou {} quand rien n'est connu
    resume_change = Signal(dict)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("Panel")
        self._liste: list = []
        self._filtre = "manquants"
        self.deplie = False
        lay = QVBoxLayout(self)
        lay.setContentsMargins(18, 14, 18, 14)
        lay.setSpacing(8)

        tete = QHBoxLayout()
        tete.setSpacing(10)
        t = QLabel("Succes")
        t.setObjectName("PanelTitle")
        tete.addWidget(t)
        self.source = QLabel("")
        self.source.setObjectName("Faint")
        tete.addWidget(self.source)
        tete.addStretch(1)
        self.resume = QLabel("")
        self.resume.setObjectName("Value")
        tete.addWidget(self.resume)
        self.b_tout = QPushButton("Voir tout")
        self.b_tout.setObjectName("Ghost")
        self.b_tout.setCursor(Qt.CursorShape.PointingHandCursor)
        self.b_tout.clicked.connect(lambda: self.deplier(not self.deplie))
        self.b_tout.hide()
        tete.addWidget(self.b_tout)
        lay.addLayout(tete)

        self.barre = QProgressBar()
        self.barre.setRange(0, 100)
        self.barre.setTextVisible(False)
        self.barre.setFixedHeight(5)
        lay.addWidget(self.barre)

        self.message = QLabel("")
        self.message.setObjectName("Dim")
        self.message.setWordWrap(True)
        lay.addWidget(self.message)
        self.b_connecter = QPushButton("Connecter mon compte")
        self.b_connecter.setObjectName("Primary")
        self.b_connecter.clicked.connect(lambda: self.connexion_demandee.emit(self._pid))
        self.b_connecter.hide()
        ligne = QHBoxLayout()
        ligne.addWidget(self.b_connecter)
        ligne.addStretch(1)
        lay.addLayout(ligne)
        self._pid = ""

        self.sous_titre = QLabel("")
        self.sous_titre.setObjectName("Faint")
        lay.addWidget(self.sous_titre)

        filtres = QHBoxLayout()
        filtres.setContentsMargins(0, 0, 0, 0)
        self.groupe = QButtonGroup(self)
        self.boutons = {}
        for cle, texte in (("manquants", "Manquants"), ("obtenus", "Obtenus"),
                           ("tous", "Tous")):
            b = QPushButton(texte)
            b.setObjectName("Chip")
            b.setCheckable(True)
            b.clicked.connect(lambda _=False, c=cle: self._filtrer(c))
            self.groupe.addButton(b)
            filtres.addWidget(b)
            self.boutons[cle] = b
        filtres.addStretch(1)
        self.filtres = QFrame()
        self.filtres.setLayout(filtres)
        lay.addWidget(self.filtres)

        self.lignes = QVBoxLayout()
        self.lignes.setSpacing(2)
        lay.addLayout(self.lignes)
        # vue repliee : grille compacte de quelques succes
        self.grille = QGridLayout()
        self.grille.setHorizontalSpacing(28)
        self.grille.setVerticalSpacing(2)
        self.grille.setColumnStretch(0, 1)
        self.grille.setColumnStretch(1, 1)
        lay.addLayout(self.grille)
        self.vider()

    # ------------------------------------------------------------------
    def vider(self) -> None:
        self._liste = []
        self.deplie = False
        clear_layout(self.lignes)
        clear_layout(self.grille)
        self.hide()
        self.resume_change.emit({})

    def _etat_simple(self, texte: str, source: str = "", connecter: str = "") -> None:
        self.show()
        self._liste = []
        self.source.setText(source)
        self.resume.setText("")
        self.barre.hide()
        self.filtres.hide()
        self.sous_titre.hide()
        self.b_tout.hide()
        clear_layout(self.lignes)
        clear_layout(self.grille)
        self.message.setText(texte)
        self.message.show()
        self._pid = connecter
        self.b_connecter.setVisible(bool(connecter))
        self.resume_change.emit({})

    def chargement(self, source: str) -> None:
        self._etat_simple("Chargement des succes...", source)

    def non_connecte(self, pid: str, nom: str) -> None:
        self._etat_simple(f"Connectez votre compte {nom} pour voir vos succes obtenus et "
                          "manquants, avec leur rarete.", nom, connecter=pid)

    def erreur(self, texte: str, source: str) -> None:
        self._etat_simple(texte, source)

    def definir(self, liste: list, source: str) -> None:
        if not liste:
            self._etat_simple("Ce jeu n'a pas de succes sur cette plateforme.", source)
            return
        self.show()
        self._liste = liste
        self.deplie = False
        self.source.setText(source)
        r = resume_succes(liste)
        texte = f"{r['obtenus']}/{r['total']} · {r['pourcentage']} %"
        n = r["rares_obtenus"]
        if n:
            texte += f" · {n} rares" if n > 1 else " · 1 rare"
        self.resume.setText(texte)
        self.barre.show()
        self.barre.setValue(r["pourcentage"])
        self.message.hide()
        self.b_connecter.hide()
        self.b_tout.show()
        self.b_tout.setText(f"Voir tout ({r['total']})")
        self._filtre = "manquants" if r["manquants"] else "obtenus"
        self._rendre()
        self.resume_change.emit(dict(r, source=source))

    # ------------------------------------------------------------------
    def deplier(self, oui: bool) -> None:
        if not self._liste:
            return
        self.deplie = bool(oui)
        self._rendre()

    def _rendre(self) -> None:
        r = resume_succes(self._liste)
        self.b_tout.setText("Reduire" if self.deplie else f"Voir tout ({r['total']})")
        self.filtres.setVisible(self.deplie)
        clear_layout(self.grille)
        if self.deplie:
            self.sous_titre.hide()
            self._filtrer(self._filtre)
            return
        clear_layout(self.lignes)
        manquants = self._tries("manquants")
        if manquants:
            self.sous_titre.setText("A viser ensuite : les plus accessibles parmi ceux "
                                    "qui manquent")
            choix = manquants[:APERCU]
        else:
            self.sous_titre.setText("Tous les succes sont obtenus ! Les plus recents :")
            choix = self._tries("obtenus")[:APERCU]
        self.sous_titre.show()
        for i, s in enumerate(choix):
            self.grille.addWidget(self._ligne(s, compacte=True), i // 2, i % 2)

    def _tries(self, cle: str) -> list:
        if cle == "manquants":
            choix = [s for s in self._liste if not s.obtenu]
            # les plus accessibles d'abord (les plus courants)
            choix.sort(key=lambda s: -(s.rarete if s.rarete is not None else -1))
            return choix
        if cle == "obtenus":
            return sorted((s for s in self._liste if s.obtenu), key=lambda s: -s.date)
        return list(self._liste)

    def _filtrer(self, cle: str) -> None:
        self._filtre = cle
        self.boutons[cle].setChecked(True)
        if not self.deplie:
            return
        clear_layout(self.lignes)
        choix = self._tries(cle)
        if not choix:
            vide = QLabel("Tous les succes sont obtenus !" if cle == "manquants"
                          else "Aucun succes obtenu pour l'instant.")
            vide.setObjectName("Faint")
            self.lignes.addWidget(vide)
            return
        for s in choix[:MAX_LIGNES]:
            self.lignes.addWidget(self._ligne(s))
        if len(choix) > MAX_LIGNES:
            reste = QLabel(f"... et {len(choix) - MAX_LIGNES} autres")
            reste.setObjectName("Faint")
            self.lignes.addWidget(reste)

    @staticmethod
    def _description(s) -> str:
        if s.cache and not s.obtenu:
            return "Succes secret : description cachee jusqu'a son obtention."
        return s.description or ""

    @classmethod
    def _ligne(cls, s, compacte: bool = False) -> QFrame:
        f = QFrame()
        h = QHBoxLayout(f)
        h.setContentsMargins(0, 2 if compacte else 3, 0, 2 if compacte else 3)
        h.setSpacing(10)
        marque = QLabel("✔" if s.obtenu else "○")
        marque.setObjectName("SuccesObtenu" if s.obtenu else "SuccesManquant")
        marque.setFixedWidth(16)
        h.addWidget(marque, 0, Qt.AlignmentFlag.AlignTop if not compacte
                    else Qt.AlignmentFlag.AlignVCenter)
        nom_txt = s.nom if not (s.cache and not s.obtenu) or s.nom else "Succes secret"
        desc = cls._description(s)
        if compacte:
            # une ligne : nom, puis description estompee coupee a la largeur
            nom = QLabel(nom_txt)
            nom.setObjectName("SuccesObtenu" if s.obtenu else "SuccesManquant")
            # a viser : lisible (le gris tres estompe est garde pour la liste)
            nom.setStyleSheet("font-weight: 600;" + ("" if s.obtenu else
                                                     f"color: {_DIM};"))
            h.addWidget(nom)
            if desc:
                d = _Coupe(desc)
                d.setObjectName("Faint")
                d.setToolTip(desc)
                h.addWidget(d, 1)
            else:
                h.addStretch(1)
        else:
            texte = QVBoxLayout()
            texte.setSpacing(0)
            nom = QLabel(nom_txt)
            nom.setObjectName("SuccesObtenu" if s.obtenu else "SuccesManquant")
            nom.setStyleSheet("font-weight: 600;")
            texte.addWidget(nom)
            if desc:
                d = QLabel(desc)
                d.setObjectName("Faint")
                d.setWordWrap(True)
                texte.addWidget(d)
            h.addLayout(texte, 1)
        droite = QHBoxLayout() if compacte else QVBoxLayout()
        droite.setSpacing(8 if compacte else 0)
        if s.rarete is not None:
            r = QLabel(f"{s.rarete:.1f} %".replace(".", ","))
            r.setObjectName("Rare" if s.rare else "Faint")
            r.setToolTip("Part des joueurs qui ont ce succes.")
            droite.addWidget(r)
        if s.obtenu and s.date:
            dt = QLabel(time.strftime("%d/%m/%Y", time.localtime(s.date)))
            dt.setObjectName("Faint")
            droite.addWidget(dt)
        h.addLayout(droite)
        return f


class _Coupe(QLabel):
    """Texte sur une ligne, coupe proprement (« ... ») a la largeur dispo."""

    def __init__(self, texte: str, parent=None) -> None:
        super().__init__(parent)
        self._texte = texte
        from PySide6.QtWidgets import QSizePolicy
        self.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.setText(texte)

    def resizeEvent(self, event) -> None:           # noqa: N802
        super().resizeEvent(event)
        coupe = self.fontMetrics().elidedText(self._texte, Qt.TextElideMode.ElideRight,
                                              max(10, self.width() - 4))
        if coupe != self.text():
            self.setText(coupe)
