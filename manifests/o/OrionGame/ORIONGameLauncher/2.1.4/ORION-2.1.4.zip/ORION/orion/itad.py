"""Acces a IsThereAnyDeal : par le relais du service d'ORION, ou en direct.

IsThereAnyDeal donne une cle par application, pas par joueur. Celle d'ORION
est rangee dans son service (jamais dans ce programme, ou n'importe qui
pourrait la lire) : ORION interroge `api.orion-launcher.com/itad/...`, qui
relaie quelques demandes precises et rend la reponse telle quelle. Le joueur
n'a donc rien a configurer. Sa demande ne porte aucun identifiant : seulement
le jeu ou le texte cherche, et son pays.

Un joueur qui a sa propre cle (Reglages) passe en direct, comme avant.

Si le relais n'est pas en service, ORION le note et se contente de Steam et
GOG ; il reessaie quelques heures plus tard.
"""
from __future__ import annotations

import time

from .core.config import CONFIG
from .core.logging_setup import get as _journal
from .partage import SERVICE

log = _journal("itad")

API = "https://api.isthereanydeal.com"
RELAIS = SERVICE + "/itad"
#: apres un relais trouve ferme, delai avant de le reinterroger (secondes)
RETENTER = 6 * 3600
ETAT = "market.itad_relais"


#: Vitrines d'une meme enseigne pour d'autres pays, par identifiant
#: IsThereAnyDeal : (enseigne, devise de la vitrine, pays). IsThereAnyDeal
#: convertit leurs prix dans la devise du joueur ; le 10 octobre, sur la page
#: Sorties, GamesPlanet US (44,62 €, vendu 49,99 $) et WinGameStore (vendu en
#: dollars) passaient en tete pour un joueur francais, qui aurait paye en
#: dollars avec des frais de change. GamesPlanet DE doublait GamesPlanet FR.
VITRINES = {28: ("gamesplanet", "EUR", "FR"), 27: ("gamesplanet", "EUR", "DE"),
            26: ("gamesplanet", "GBP", "GB"), 29: ("gamesplanet", "USD", "US"),
            64: ("wingamestore", "USD", "US")}
_EURO = {"AT", "BE", "CY", "DE", "EE", "ES", "FI", "FR", "GR", "HR", "IE", "IT", "LT", "LU",
         "LV", "MT", "NL", "PT", "SI", "SK", "MC", "AD", "SM", "VA", "ME", "XK"}
_DEVISES = {"GB": "GBP", "US": "USD", "CA": "CAD", "AU": "AUD", "CH": "CHF", "PL": "PLN",
            "SE": "SEK", "NO": "NOK", "DK": "DKK", "BR": "BRL", "JP": "JPY"}


def devise_du_pays(pays: str) -> str:
    pays = str(pays or "FR").upper()
    return "EUR" if pays in _EURO else _DEVISES.get(pays, "")


def du_pays(deals: list, pays: str) -> list:
    """Les offres que le joueur de `pays` paie dans sa devise : vitrines
    etrangeres retirees, une seule vitrine par enseigne (celle de son pays si
    elle est la, sinon la moins chere)."""
    devise = devise_du_pays(pays)
    gardees, par_enseigne = [], {}
    for d in deals or []:
        ident = (d.get("shop") or {}).get("id") if isinstance(d, dict) else None
        v = VITRINES.get(ident)
        if v is None:
            gardees.append(d)
            continue
        if devise and v[1] != devise:
            continue
        par_enseigne.setdefault(v[0], []).append(d)
    for liste in par_enseigne.values():
        chez_lui = [d for d in liste if VITRINES[d["shop"]["id"]][2] == str(pays).upper()]
        gardees.append(chez_lui[0] if chez_lui else min(
            liste, key=lambda d: float((d.get("price") or {}).get("amount") or 0)))
    return [d for d in deals or [] if any(d is g for g in gardees)]


class Indisponible(Exception):
    """IsThereAnyDeal ne peut pas repondre maintenant."""


def cle() -> str:
    """La cle personnelle du joueur, s'il en a saisi une."""
    return str(CONFIG.get("market.itad_key") or "").strip()


def actif() -> bool:
    """Le comparateur complet peut-il etre interroge ? Oui avec une cle
    personnelle ; sinon oui tant que le relais n'a pas ete trouve ferme
    recemment. Ne fait aucun appel reseau."""
    if cle():
        return True
    etat = CONFIG.get(ETAT) or {}
    ferme = isinstance(etat, dict) and etat.get("actif") is False
    return not (ferme and time.time() - float(etat.get("vu") or 0) < RETENTER)


def _noter(ouvert: bool) -> None:
    """Retient l'etat du relais (ecrit seulement quand il change)."""
    etat = CONFIG.get(ETAT) or {}
    if isinstance(etat, dict) and etat.get("actif") is ouvert and ouvert:
        return
    CONFIG.set(ETAT, {"actif": ouvert, "vu": time.time()})
    log.info("Relais IsThereAnyDeal : %s", "en service" if ouvert else "pas en service")


def demander(methode: str, chemin: str, params: dict | None = None, corps=None,
             timeout: float = 15):
    """La reponse d'IsThereAnyDeal a `chemin`, decodee. Leve `Indisponible`."""
    from .core import reseau
    p = {k: v for k, v in (params or {}).items() if v not in (None, "")}
    direct = cle()
    if direct:
        p["key"] = direct
    url = (API if direct else RELAIS) + chemin
    try:
        r = reseau.requete(methode, url, params=p, json=corps, timeout=timeout)
    except Exception as exc:
        raise Indisponible(f"IsThereAnyDeal injoignable : {exc}") from exc
    if r.status_code != 200:
        if not direct and r.status_code == 503:
            try:
                raison = str((r.json() or {}).get("erreur") or "")
            except ValueError:
                raison = ""
            if raison == "relais non configure":
                _noter(False)
            raise Indisponible(f"relais IsThereAnyDeal : {raison or 503}")
        raise Indisponible(f"IsThereAnyDeal : reponse {r.status_code}")
    try:
        donnees = r.json()
    except ValueError as exc:
        raise Indisponible("IsThereAnyDeal : reponse illisible") from exc
    if not direct:
        _noter(True)
    return donnees
