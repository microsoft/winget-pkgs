"""Point d'entree de l'application."""
from __future__ import annotations

from .ui.minuteur import plus_tard

import os
import sys
from pathlib import Path

from .core.config import CONFIG
from .core.logging_setup import setup
from .core.paths import DATA_DIR, ensure_dirs
from .version import APP_NAME, APP_VERSION


def dossier_courant_neutre() -> Path | None:
    """Quitte le dossier de demarrage pour le dossier des donnees.

    Lance par un raccourci ou par l'installateur, ORION demarrait dans son
    propre dossier d'installation, et tout ce qu'il lancait (jeux, Steam,
    installateur) en heritait. Or Windows refuse de renommer un dossier qui
    est le dossier courant d'un processus : la mise a jour echouait tant
    qu'un de ces programmes tournait. Rend le dossier choisi (None si aucun
    changement n'a ete possible)."""
    for dossier in (DATA_DIR, Path.home()):
        try:
            dossier.mkdir(parents=True, exist_ok=True)
            os.chdir(dossier)
            return dossier
        except Exception:
            continue
    return None


def main(argv: list[str] | None = None) -> int:
    import time
    depart = time.perf_counter()
    ensure_dirs()
    dossier_courant_neutre()
    log = setup()

    # Windows appelle l'application elle-meme pour la desinstaller : c'est
    # l'adresse enregistree dans « Applications installees ».
    if "--desinstaller" in (argv if argv is not None else sys.argv):
        from .deploiement.interface import main as fenetre_retrait
        log.info("Desinstallation demandee")
        return fenetre_retrait("desinstaller")

    # Verification de l'application compilee : le registre de plugins
    # repose sur l'exploration d'un paquet, ce qui ne se comporte pas de la
    # meme facon une fois l'application figee dans un executable. Ce mode
    # le controle sans ouvrir de fenetre et ecrit un compte rendu.
    if "--autotest" in (argv if argv is not None else sys.argv):
        return _autotest(log)

    # Lance par Windows a l'ouverture de session (2.1.2) ? La question part
    # tout de suite : pour le paquet du Store, Windows y repond pendant que
    # Qt demarre, sans retarder l'ouverture.
    from . import demarrage
    question_demarrage = demarrage.interroger(argv if argv is not None else sys.argv)

    from PySide6.QtCore import Qt
    from PySide6.QtGui import QIcon
    from PySide6.QtWidgets import QApplication

    QApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    app = QApplication(argv if argv is not None else sys.argv)
    app.setApplicationName(APP_NAME)
    from .core import tasks as _taches
    app.aboutToQuit.connect(_taches.fermer)     # plus de tache lancee ni d'erreur notee a la fermeture
    from .core import base as _base
    app.aboutToQuit.connect(_base.ecrire_en_attente)   # documents deposes, meme sans closeEvent (quit)
    # Windows qui s'eteint ou se deconnecte ferme ORION sans passer par la
    # fenetre (surtout quand elle est cachee en mode discret) : le temoin de
    # session restait, et le demarrage suivant parlait d'un « arret brutal »
    from . import signalement as _signalement
    app.aboutToQuit.connect(_signalement.fermer_session)
    app.commitDataRequest.connect(lambda _m: _signalement.fermer_session())
    app.setApplicationVersion(APP_VERSION)
    app.setOrganizationName(APP_NAME)

    from .ui.icon import app_icon
    app.setWindowIcon(QIcon(app_icon()))

    # premier lancement : langue et pays des prix d'apres Windows
    try:
        from .core import region
        if region.premier_lancement():
            log.info("Premier lancement : langue %s, pays %s", CONFIG.get("langue"),
                     CONFIG.get("market.country"))
    except Exception:
        log.exception("Detection de la region impossible")

    # interface en anglais si choisie (Reglages > Langue)
    try:
        from . import i18n
        i18n.activer()
    except Exception:
        log.exception("Traduction de l'interface indisponible")

    # Un seul ORION a la fois : un deuxieme lancement rappelle la fenetre
    # existante au lieu d'ouvrir une seconde veille des prix et une seconde
    # mesure de performance sur la meme partie.
    verrou = None
    if CONFIG.get("ui.single_instance", True):
        try:
            from .core.instance import SingleInstance
            verrou = SingleInstance(app)
            if verrou.already_running():
                return 0
            verrou.listen()
        except Exception:
            log.debug("Verrou d'instance indisponible")
            verrou = None

    # a partir d'ici, cette instance est bien celle qui demarre : la ligne
    # de journal n'apparait donc jamais pour un lancement qui s'efface
    # devant une fenetre deja ouverte.
    log.info("Demarrage de %s %s", APP_NAME, APP_VERSION)

    # L'ecran de demarrage s'affiche avant la construction de la fenetre :
    # le chargement de la bibliotheque et la detection du materiel prennent
    # quelques secondes, pendant lesquelles l'utilisateur doit voir autre
    # chose qu'un ecran vide.
    par_windows = question_demarrage(2.0)
    splash = None
    if CONFIG.get("ui.splash", True) and not par_windows:
        try:
            from .ui.splash import Splash
            splash = Splash()
            splash.show()
            app.processEvents()
        except Exception:
            log.debug("Ecran de demarrage indisponible")

    def etape(texte: str) -> None:
        if splash is not None:
            splash.message(texte)

    etape("Chargement de la bibliotheque...")
    from .ui.main_window import MainWindow
    try:                                   # molette plus ample et glissee
        from .ui import defilement
        defilement.installer(app)
        from .ui import boites
        boites.installer(app)        # « Oui / Non » au lieu de « Yes / No »
    except Exception:
        log.exception("Defilement glisse indisponible")
    window = MainWindow(on_progress=etape)

    etape("Pret")
    if par_windows:
        # ouverture de session : reduit dans la barre des taches, sans passer
        # devant ce que l'on ouvre en arrivant ; un clic le rouvre en grand
        if CONFIG.get("ui.start_maximized", True):
            window.setWindowState(Qt.WindowState.WindowMaximized)
        window.showMinimized()
        log.info("Lance par Windows a l'ouverture de session : fenetre reduite")
    elif CONFIG.get("ui.start_maximized", True):
        window.showMaximized()
    else:
        window.show()
    if splash is not None:
        splash.finish(window)

    # en service normal, les resultats des taches de fond attendent que le
    # joueur ait fini son geste (voir `ui/repos.py`)
    window.mises_a_jour_au_repos = True
    window.free_view.etaler = True          # lignes des jeux gratuits par lots

    # la fenetre est la : a partir d'ici, tout arret du fil d'affichage est
    # un accrochage pour le joueur, et il est note avec sa cause
    if CONFIG.get("diagnostic.fluidite", True):
        try:
            from .core import fluidite
            fluidite.noter_demarrage((time.perf_counter() - depart) * 1000)
            fluidite.installer(app)
        except Exception:
            log.debug("Mesure de fluidite indisponible")

    if verrou is not None:
        verrou.raise_requested.connect(lambda: rappeler(window))
    code = app.exec()
    # la fenetre a disparu : le dernier envoi du compteur (bilan de fluidite)
    # finit en fond, sans jamais retenir la fenetre a l'ecran
    try:
        from . import compteur
        compteur.attendre(2.0)
    except Exception:
        pass
    # Qt attend toutes les taches de fond avant de rendre la main : un
    # telechargement encore en cours (outil de mesure, jaquettes...) gardait
    # le processus en vie, sans fenetre, avec le verrou d'instance unique ;
    # un nouveau lancement ne montrait alors rien. Au bout de 3 s, ORION part.
    try:
        from PySide6.QtCore import QThreadPool
        if not QThreadPool.globalInstance().waitForDone(3000):
            log.info("Fermeture : taches de fond encore en cours, arret sans les attendre")
            import logging
            import os
            logging.shutdown()
            os._exit(code)
    except Exception:
        pass
    return code


def rappeler(window) -> None:
    """Un second lancement rappelle la fenetre existante. Reduite (ORION
    lance par Windows, ou reduit a la main), elle revient comme elle etait,
    en grand si elle l'etait : `showNormal` la rendait plus petite."""
    from PySide6.QtCore import Qt
    etat = window.windowState() & ~Qt.WindowState.WindowMinimized
    window.setWindowState(etat | Qt.WindowState.WindowActive)
    window.show()
    window.raise_()
    window.activateWindow()


def _essai_navigateur() -> str:
    """Charge une vraie page dans le navigateur integre (preuve qu'il
    fonctionne apres l'allegement de la compilation)."""
    try:
        from PySide6.QtCore import QEventLoop
        from PySide6.QtWebEngineCore import QWebEnginePage, QWebEngineProfile
        from PySide6.QtWidgets import QApplication
        app = QApplication.instance() or QApplication(["orion-autotest"])
        profil = QWebEngineProfile()
        page = QWebEnginePage(profil)
        profil.setParent(page)
        boucle, resultat = QEventLoop(), {"ok": None}

        def fini(ok):
            resultat["ok"] = ok
            boucle.quit()
        page.loadFinished.connect(fini)
        plus_tard(boucle, 30000, boucle.quit)
        page.setHtml("<html><body>ORION</body></html>")
        boucle.exec()
        page.deleteLater()
        app.processEvents()
        if resultat["ok"]:
            return "fonctionne (page chargee)"
        return "ECHEC (page non chargee)" if resultat["ok"] is False else "ECHEC (delai depasse)"
    except Exception as exc:
        return f"ECHEC {exc}"


def _autotest(log) -> int:
    """Controle qu'une application compilee retrouve tout ce qu'elle embarque."""
    from .core.paths import ASSETS_DIR, FROZEN, RECIPE_BUILTIN_DIR
    from .core.registry import discover

    lignes: list[str] = [f"{APP_NAME} {APP_VERSION} - verification",
                         f"execution compilee : {'oui' if FROZEN else 'non'}",
                         ""]
    souci = 0

    familles = [
        ("sources de jeux", "orion.plugins.scanners", "base", "Scanner"),
        ("jaquettes", "orion.plugins.artwork", "base", "ArtworkProvider"),
        ("formats de reglages", "orion.plugins.tweaks", "base", "TweakWriter"),
        ("prix", "orion.plugins.market", "base", "MarketProvider"),
        ("jeux gratuits", "orion.plugins.freebies", "base", "FreebieSource"),
    ]
    import importlib
    for label, paquet, module, classe in familles:
        try:
            base = getattr(importlib.import_module(f"{paquet}.{module}"), classe)
            trouves = discover(base, paquet)
            noms = ", ".join(sorted(getattr(p, "id", "?") for p in trouves))
            lignes.append(f"{label:22s} : {len(trouves)} -> {noms}")
            if not trouves:
                souci += 1
        except Exception as exc:
            lignes.append(f"{label:22s} : ECHEC {exc}")
            souci += 1

    from .optimizer.engine import load_recipes
    recettes = load_recipes()
    lignes.append(f"{'recettes':22s} : {len(recettes)}")
    if not recettes:
        souci += 1

    for nom in ("fond.jpg", "orion.ico", "orion.png"):
        present = (ASSETS_DIR / nom).exists()
        lignes.append(f"{'image ' + nom:22s} : {'presente' if present else 'MANQUANTE'}")
        souci += 0 if present else 1
    # navigateur integre (connexion aux comptes, 1.8) : module ET processus
    try:
        from PySide6.QtWebEngineWidgets import QWebEngineView  # noqa: F401
        from PySide6.QtCore import QLibraryInfo
        import os as _os
        import sys as _sys
        processus = [p for p in (
            _os.path.join(QLibraryInfo.path(QLibraryInfo.LibraryPath.LibraryExecutablesPath),
                          "QtWebEngineProcess.exe"),
            _os.path.join(getattr(_sys, "_MEIPASS", ""), "PySide6", "QtWebEngineProcess.exe"))
            if _os.path.exists(p)]
        etat = "present" if (processus or not FROZEN) else "processus MANQUANT"
        if etat == "present":
            etat = _essai_navigateur()
        souci += 0 if etat.startswith("fonctionne") or etat == "present" else 1
    except Exception as exc:
        etat = f"ECHEC {exc}"
        souci += 1
    lignes.append(f"{'navigateur integre':22s} : {etat}")
    # lancement au demarrage du paquet du Store (2.1.2) : le module winrt
    # doit etre embarque (importe hors du fil de Qt, comme en service)
    if sys.platform.startswith("win"):
        try:
            from . import demarrage as _demarrage

            def _modules() -> bool:
                import winrt.windows.applicationmodel  # noqa: F401
                import winrt.windows.applicationmodel.activation  # noqa: F401
                import winrt.windows.foundation  # noqa: F401
                return True
            _demarrage._dans_un_fil(_modules, 20.0)
            etat = "present"
        except Exception as exc:
            etat = f"ECHEC {exc}"
            souci += 1
        lignes.append(f"{'demarrage (Store)':22s} : {etat}")
    lignes.append(f"{'dossier recettes':22s} : {RECIPE_BUILTIN_DIR}")
    lignes.append("")
    lignes.append("RESULTAT : " + ("tout est en place" if not souci
                                   else f"{souci} probleme(s)"))

    rapport = "\n".join(lignes)
    try:
        (DATA_DIR / "_autotest.txt").write_text(rapport + "\n", encoding="utf-8")
    except Exception:
        pass
    log.info("Verification : %s", lignes[-1])
    print(rapport)
    return 0 if not souci else 1
