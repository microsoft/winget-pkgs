"""Calculateur de puissance cote fenetre principale (1.8).

Les configurations des jeux sont lues sur Steam par petits paquets, en
tache de fond, jamais pendant une partie (mode discret), jusqu'a ce que
tous les jeux connus d'ORION soient evalues. L'evaluation elle-meme est
locale et instantanee.
"""
from __future__ import annotations

from .minuteur import plus_tard

from PySide6.QtCore import QTimer

from .. import puissance
from ..core.logging_setup import get
from ..core.tasks import Task

log = get("ui.puissance")


class PuissanceMixin:
    def _init_puissance(self) -> None:
        p = self.hardware_view.puissance
        p.analyser_demande.connect(lambda: self.analyser_puissance(auto=False))
        p.ouvrir_jeu.connect(self.open_game)
        self._puissance_occupe = False
        self._communaute: list = []

    def _boot_puissance(self) -> None:
        plus_tard(self, 8000, self.actualiser_puissance)
        plus_tard(self, 120000, self.analyser_puissance)
        self._timer_puissance = QTimer(self)
        self._timer_puissance.timeout.connect(self.analyser_puissance)
        self._timer_puissance.start(3600 * 1000)

    def _listes(self) -> tuple:
        """Copie des listes dont le calculateur a besoin, prise dans le fil
        d'affichage ; tout le reste se fait en tache de fond."""
        return (list(self.library.games(include_hidden=True)), list(self.possedes.tous()),
                list(self.wishlist.items.values()),
                list(getattr(self.boutique, "fiches", []) or []))

    def _candidats(self):
        return puissance.candidats(*self._listes())

    def actualiser_puissance(self) -> None:
        """Re-evalue tout (local) et met le panneau a jour."""
        machine = puissance.machine_depuis(self.hw)
        panneau = self.hardware_view.puissance
        panneau.set_machine(machine)
        listes = self._listes()

        def travail():
            # rassembler les jeux (deux mille titres a normaliser) puis relire
            # leurs configurations dans la base : un dixieme de seconde a un
            # tiers de seconde, qui se passait dans le fil d'affichage
            liste = puissance.candidats(*listes)
            if not self._communaute:
                self._communaute = puissance.mesures_communaute()
            return puissance.evaluer_tout(liste, machine, self.perf, self._communaute), \
                len(puissance.a_lire(liste))

        t = Task(travail)
        t.signals.finished.connect(self._puissance_evaluee)
        t.signals.failed.connect(self._puissance_echec)
        t.start()

    def _puissance_echec(self, message: str) -> None:
        """Evaluation en echec : on le dit, et le bouton redevient utilisable
        (sinon il restait grise apres la lecture des configurations)."""
        log.warning("Calculateur de puissance : %s", message)
        self.hardware_view.puissance.set_etat(
            "Evaluation impossible pour le moment", self._puissance_occupe)

    def _puissance_evaluee(self, resultat) -> None:
        resultats, restants = resultat
        self._puissance_resultats = resultats          # pour le bilan en une minute
        panneau = self.hardware_view.puissance
        # le tableau (pres de deux mille lignes) se remplit au repos : arrive
        # pendant un defilement, il figeait la fenetre une demi-seconde
        # (cle a part : l'analyse du materiel attend elle aussi sous « hardware »,
        # et une cle ne garde que la derniere mise a jour)
        self._au_repos("hardware:puissance", lambda: panneau.set_resultats(resultats))
        evalues = sum(1 for _c, e in resultats if e.source != puissance.INCONNU)
        from ..i18n import t
        texte = t(f"{evalues} jeux evalues")
        if restants:
            texte += t(f" · {restants} configurations a lire")
        panneau.set_etat(texte, self._puissance_occupe)

    def analyser_puissance(self, auto: bool = True) -> None:
        if self._puissance_occupe:
            return
        if auto and self._differer("puissance"):
            return
        self._puissance_occupe = True
        panneau = self.hardware_view.puissance
        panneau.set_etat("Lecture des configurations...", True)
        listes = self._listes()

        def travail(progress_cb=None):
            a_lire = puissance.a_lire(puissance.candidats(*listes))
            return puissance.lire_configurations(a_lire, 45, progress_cb) if a_lire else 0

        t = Task(travail)
        t.signals.progress.connect(lambda m, p: panneau.set_etat(f"{m} : {p} %", True))
        t.signals.finished.connect(self._configurations_lues)
        t.signals.failed.connect(self._configurations_lues)
        t.start()

    def _configurations_lues(self, _r=None) -> None:
        self._puissance_occupe = False
        self.actualiser_puissance()
