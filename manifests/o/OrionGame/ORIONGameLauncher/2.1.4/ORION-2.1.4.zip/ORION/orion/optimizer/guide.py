"""Guide « a faire dans le jeu » : les reglages a recopier a la main.

Certains jeux ne laissent aucun fichier de reglages modifiable de
l'exterieur (moteur maison, reglages en ligne). ORION ne peut alors rien
ecrire ; il dit quoi regler, ligne par ligne, avec des mots simples : le nom
du reglage tel qu'on le trouve dans les menus, la valeur a choisir, et une
aide courte. Le guide doit etre lisible par un enfant comme par une
grand-mere : pas de jargon, une action par ligne.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

QUALITES = {0: "Basse", 1: "Moyenne", 2: "Haute", 3: "Ultra"}
FAMILLES = {"dlss": "DLSS", "fsr": "FSR", "xess": "XeSS"}
MODES = {"quality": "Qualite", "balanced": "Equilibre",
         "performance": "Performance", "dlaa": "Native (DLAA)"}

#: ou trouver les reglages, dit simplement
ETAPES_MENU = (
    "Lancez le jeu.",
    "Ouvrez le menu Options (ou Parametres), puis la page Graphismes, "
    "Video ou Affichage.",
    "Recopiez les reglages ci-dessous, puis validez (Appliquer ou Enregistrer).",
)


@dataclass
class Ligne:
    nom: str            # nom du reglage dans les menus du jeu
    valeur: str         # ce qu'il faut choisir
    aide: str = ""      # une phrase simple, facultative
    essentiel: bool = True

    def texte(self) -> str:
        return f"{self.nom} : {self.valeur}"


def lignes(settings: dict[str, Any]) -> list[Ligne]:
    """Les reglages a faire dans le jeu, les plus importants d'abord."""
    s = settings or {}
    sortie = [
        Ligne("Mode d'affichage",
              "Plein ecran" if s.get("window_mode") == "fullscreen"
              else "Fenetre sans bordure",
              "Parfois appele « Mode fenetre » ou « Display mode »."),
        Ligne("Resolution",
              f"{s.get('resolution_w', 1920)} x {s.get('resolution_h', 1080)}",
              "C'est la taille de l'image. Choisissez exactement ces chiffres."),
        Ligne("Frequence",
              f"{s.get('refresh', 60)} Hz",
              "Parfois appelee « Taux de rafraichissement ». Si le jeu ne la "
              "propose pas, passez a la ligne suivante."),
        Ligne("Qualite graphique",
              QUALITES.get(int(s.get("quality", 2)), "Haute"),
              "Parfois appelee « Qualite globale » ou « Prereglage ». Un seul "
              "choix regle tous les details d'un coup."),
    ]
    up = str(s.get("upscaler", "off"))
    echelle = int(s.get("resolution_scale") or 100)
    if up != "off" and "_" in up:
        fam, mode = up.split("_", 1)
        sortie.append(Ligne(
            FAMILLES.get(fam, fam.upper()), MODES.get(mode, mode),
            "Donne plus d'images sans abimer l'image. Si le jeu ne propose pas "
            "ce reglage, cherchez FSR ou XeSS a la place ; sinon passez."))
    elif echelle < 100:
        sortie.append(Ligne(
            "Echelle de rendu", f"{echelle} %",
            "Parfois appelee « Resolution de rendu ». Si le jeu ne la propose "
            "pas, passez."))
    else:
        sortie.append(Ligne(
            "DLSS, FSR ou XeSS", "Desactive",
            "Votre PC n'en a pas besoin ici. Si le jeu ne propose pas ce "
            "reglage, passez."))
    cap = int(s.get("fps_cap") or 0)
    sortie.append(Ligne(
        "Limite d'images par seconde", f"{cap}" if cap else "Aucune limite",
        "Parfois appelee « Limite de FPS ». Si le jeu ne la propose pas, passez."))
    sortie += [
        Ligne("Synchronisation verticale",
              "Activee" if s.get("vsync") else "Desactivee",
              "Souvent ecrite « V-Sync ».", essentiel=False),
        Ligne("Flou de mouvement",
              "Active" if s.get("fx_motion_blur") else "Desactive",
              "Souvent ecrit « Motion blur ».", essentiel=False),
        Ligne("Ray tracing",
              "Desactive" if s.get("ray_tracing", "off") == "off" else "Active",
              "Si le jeu ne le propose pas, passez.", essentiel=False),
    ]
    return sortie


def texte(titre: str, liste: list[Ligne]) -> str:
    """Le guide en texte simple, pour le copier (telephone, papier)."""
    entete = [f"Reglages a faire dans {titre}" if titre else "Reglages a faire dans le jeu",
              ""]
    entete += [f"{i}. {e}" for i, e in enumerate(ETAPES_MENU, 1)]
    return "\n".join(entete + [""] + [f"- {l.texte()}" for l in liste])
