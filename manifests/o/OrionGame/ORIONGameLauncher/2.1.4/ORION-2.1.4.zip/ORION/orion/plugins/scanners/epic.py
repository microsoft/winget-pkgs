"""Detection des jeux Epic Games (manifestes .item)."""
from __future__ import annotations

import json
from pathlib import Path

from ...core.logging_setup import get
from ...core.models import Game
from .base import Scanner, detect_engine

log = get("scan.epic")

MANIFEST_DIR = Path(r"C:\ProgramData\Epic\EpicGamesLauncher\Data\Manifests")


class EpicScanner(Scanner):
    id = "epic"
    label = "Epic Games"
    icon = "EPC"
    priority = 90

    def available(self) -> bool:
        return MANIFEST_DIR.is_dir()

    def scan(self) -> list[Game]:
        games: list[Game] = []
        for item in MANIFEST_DIR.glob("*.item"):
            try:
                d = json.loads(item.read_text("utf-8", errors="ignore"))
            except Exception:
                continue
            title = d.get("DisplayName") or d.get("AppName") or ""
            install = d.get("InstallLocation") or ""
            if not title or not install:
                continue
            if d.get("AppCategories") and "addons" in [
                str(c).lower() for c in d.get("AppCategories", [])
            ] and "games" not in [str(c).lower() for c in d.get("AppCategories", [])]:
                continue    # DLC ou module, pas un jeu

            exe = d.get("LaunchExecutable") or ""
            full_exe = str(Path(install) / exe) if exe else ""
            ns = d.get("CatalogNamespace", "")
            cid = d.get("CatalogItemId", "")
            app = d.get("AppName", "")
            uri = (f"com.epicgames.launcher://apps/{ns}%3A{cid}%3A{app}"
                   f"?action=launch&silent=true") if ns and cid and app else ""

            games.append(self._mk(
                title=title,
                source_id=app,
                install_dir=install,
                executable=full_exe,
                launch_uri=uri,
                size_bytes=int(d.get("InstallSize") or 0),
                engine=detect_engine(Path(install)),
                extra={"namespace": ns, "catalog_item": cid,
                       "version": d.get("AppVersionString", "")},
            ))
        log.info("%d jeux Epic", len(games))
        return games
