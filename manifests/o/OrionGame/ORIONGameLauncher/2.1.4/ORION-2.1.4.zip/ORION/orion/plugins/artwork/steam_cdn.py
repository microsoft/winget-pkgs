"""Visuels officiels Steam.

Fonctionne pour les jeux Steam (identifiant connu) et, pour les autres
sources, en retrouvant l'identifiant Steam a partir du titre. Aucune cle
d'API n'est necessaire.
"""
from __future__ import annotations

from orion.core import region

import json
import re
import threading

from ...core.logging_setup import get
from ...core.models import Game, normalize_title
from ...core.paths import CACHE_DIR
from .base import ArtworkProvider, cache_path, download

log = get("artwork.steam")

CDN = "https://cdn.cloudflare.steamstatic.com/steam/apps/{appid}/{file}"
SEARCH = "https://steamcommunity.com/actions/SearchApps/{query}"
#: Recherche de la boutique : contient les nouveautes des leur mise en ligne,
#: la ou l'index communautaire met parfois plusieurs jours a se mettre a jour.
STORE_SEARCH = "https://store.steampowered.com/api/storesearch/"

FILES = {
    "cover": ("library_600x900_2x.jpg", "library_600x900.jpg"),
    "hero": ("library_hero.jpg", "page_bg_generated_v6b.jpg", "header.jpg"),
    "logo": ("logo.png", "logo_2x.png"),
}

_LOCK = threading.Lock()
_RESOLVED_FILE = CACHE_DIR / "steam_ids.json"


def _doc():
    from ...core.base import Document
    return Document("steam_ids", _RESOLVED_FILE)


#: version de la comparaison des titres : les identifiants retrouves par
#: une version plus ancienne (comparaison trop permissive : « Fable » pouvait
#: donner « Fable Anniversary ») sont oublies et recherches de nouveau.
VERSION_IDS = 3


def _load_resolved() -> dict:
    try:
        data = _doc().lire({}) or {}
    except Exception:
        data = {}
    if not isinstance(data, dict) or data.get("__v__") != VERSION_IDS:
        return {"__v__": VERSION_IDS}
    return data


def _save_resolved(data: dict) -> None:
    _doc().ecrire(data)


def appid_deja_trouve(titre: str) -> str:
    """Identifiant Steam deja retrouve pour ce titre par la recherche des
    visuels, ou "". Lecture locale, sans reseau : la fiche d'un jeu installe
    hors Steam peut ainsi montrer tout de suite sa bande-annonce."""
    cle = normalize_title(titre or "")
    if not cle:
        return ""
    try:
        with _LOCK:
            valeur = str(_load_resolved().get(cle) or "")
    except Exception:
        return ""
    return valeur if valeur.isdigit() else ""


class SteamArtworkProvider(ArtworkProvider):
    id = "steam_cdn"
    label = "Steam (officiel)"
    priority = 90

    def fetch(self, game: Game, want: set[str]) -> dict[str, str]:
        appid = self._appid(game)
        if not appid:
            return {}
        out: dict[str, str] = {}
        for kind in ("cover", "hero", "logo"):
            if kind not in want:
                continue
            for fname in FILES[kind]:
                ext = "png" if fname.endswith(".png") else "jpg"
                dest = cache_path(game, kind, ext)
                if download(CDN.format(appid=appid, file=fname), dest):
                    out[kind] = str(dest)
                    break
        # jeux recents : leurs visuels sont ranges a une adresse contenant
        # une empreinte, que seule l'API de la boutique donne. L'ancienne
        # adresse renvoie alors une image grise, ecartee par download().
        manquants = [k for k in ("cover", "hero", "logo") if k in want and k not in out]
        if manquants:
            for kind, url in self._assets(appid).items():
                if kind in manquants:
                    ext = "png" if url.split("?")[0].endswith(".png") else "jpg"
                    dest = cache_path(game, kind, ext)
                    if download(url, dest):
                        out[kind] = str(dest)
        if out:
            game.extra.setdefault("steam_appid", appid)
        return out

    #: correspondance visuel ORION -> champs de l'API, par ordre de preference
    ASSETS = {
        "cover": ("library_capsule_2x", "library_capsule"),
        "hero": ("library_hero_2x", "library_hero", "page_background", "header"),
        "logo": ("library_logo_2x", "library_logo"),
    }
    ASSET_BASE = "https://shared.akamai.steamstatic.com/store_item_assets/"

    @classmethod
    def _assets(cls, appid: str) -> dict[str, str]:
        """Adresses actuelles des visuels d'un jeu, via IStoreBrowseService."""
        from orion.core import reseau
        from ...core.steam_limite import NAVIGATEUR, attendre, en_pause
        if en_pause():
            return {}
        requete = json.dumps({"ids": [{"appid": int(appid)}],
                              "context": {"language": region.langue_steam(), "country_code": region.pays()},
                              "data_request": {"include_assets": True}})
        attendre()
        try:
            r = reseau.get(
                "https://api.steampowered.com/IStoreBrowseService/GetItems/v1/",
                params={"input_json": requete}, headers=NAVIGATEUR, timeout=12)
            items = ((r.json() or {}).get("response") or {}).get("store_items") or []
        except Exception:
            log.debug("Visuels Steam (API) indisponibles pour %s", appid)
            return {}
        if not items:
            return {}
        assets = items[0].get("assets") or {}
        modele = assets.get("asset_url_format") or f"steam/apps/{appid}/${{FILENAME}}"
        out: dict[str, str] = {}
        for kind, champs in cls.ASSETS.items():
            for champ in champs:
                fichier = assets.get(champ)
                if isinstance(fichier, str) and fichier:
                    out[kind] = cls.ASSET_BASE + modele.replace("${FILENAME}", fichier)
                    break
        return out

    # ------------------------------------------------------------------
    def _appid(self, game: Game) -> str:
        from ...core.liens import appid_steam
        known = appid_steam(game)               # Steam, registre, deja retrouve
        if known:
            return known

        key = normalize_title(game.title)
        if not key:
            return ""
        with _LOCK:
            cache = _load_resolved()
            if key in cache and key not in ("__misses__", "__v__"):
                return str(cache[key] or "")

        appid = self._search(game.title, key)
        with _LOCK:
            cache = _load_resolved()
            if appid:
                cache[key] = appid
            else:
                # echec memorise avec un compteur : ORION reessaiera plus tard,
                # le temps que la fiche du jeu apparaisse en ligne.
                misses = cache.get("__misses__", {})
                misses[key] = int(misses.get(key, 0)) + 1
                cache["__misses__"] = misses
            _save_resolved(cache)
        return appid

    @classmethod
    def _search(cls, title: str, key: str) -> str:
        appid = cls._search_store(title, key)
        if appid:
            return appid
        return cls._search_community(title, key)

    @staticmethod
    def _search_store(title: str, key: str) -> str:
        """Recherche dans la boutique Steam (inclut les sorties du jour).

        Meme comparaison que pour les prix (`recherche.meilleur_candidat`) :
        ponctuation, separateurs (« RuneScape - Dragonwilds » / « RuneScape:
        Dragonwilds »), ™ ®, accents et chiffres romains ignores ; jamais un
        DLC, une bande originale ou un autre numero (« Hades » / « Hades II »)."""
        from orion.core import reseau
        from ...core.recherche import meilleur_candidat, termes_recherche
        for terme in termes_recherche(title, maximum=2):
            try:
                r = reseau.get(STORE_SEARCH,
                               params={"term": terme, "l": region.langue_steam(), "cc": region.cc()},
                               timeout=10,
                               headers={"User-Agent": "ORION-Launcher/1.0"})
                if r.status_code != 200:
                    return ""
                items = [i for i in (r.json() or {}).get("items") or []
                         if isinstance(i, dict) and i.get("id")]
            except Exception:
                log.debug("Recherche boutique Steam impossible pour %s", title)
                return ""
            choix = meilleur_candidat(title, items)
            if choix is not None:
                return str(choix.get("id", ""))
        return ""

    @staticmethod
    def _search_community(title: str, key: str) -> str:
        import requests
        from orion.core import reseau
        from ...core.recherche import meilleur_candidat, titre_recherche
        try:
            query = re.sub(r"[^\w\s]", " ", titre_recherche(title)).strip()
            if not query:
                return ""
            r = reseau.get(SEARCH.format(query=requests.utils.quote(query)),
                           timeout=10,
                           headers={"User-Agent": "ORION-Launcher/1.0"})
            if r.status_code != 200:
                return ""
            items = [i for i in r.json() or [] if isinstance(i, dict) and i.get("appid")]
        except Exception:
            log.debug("Recherche communautaire Steam impossible pour %s", title)
            return ""
        choix = meilleur_candidat(title, items, genre=lambda i: None)
        return str(choix.get("appid", "")) if choix is not None else ""
