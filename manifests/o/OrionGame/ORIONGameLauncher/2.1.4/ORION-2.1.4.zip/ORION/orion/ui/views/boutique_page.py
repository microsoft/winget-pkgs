"""Page « Boutique » : les offres payantes et les jeux gratuits, reunis.

La Boutique et l'ancienne page « Jeux gratuits » montraient en partie la
meme chose (les gratuits apparaissaient dans les deux). Elles forment
desormais une seule page a deux onglets :

* **Offres** : le comparateur de prix (`BoutiqueView`), sans les gratuits ;
* **Gratuits** : ce qui est offert en ce moment (`FreeView`), avec ses
  filtres, ses alertes de fin de gratuite et ses actions.

La barre de recherche des offres est posee dans l'en-tete, a cote des
onglets : elle s'ouvre sur une liste de jeux (prix, remise) des la premiere
lettre (`widgets/recherche_popup.py`).

L'onglet « Gratuits » porte le nombre d'offres a saisir ; l'entree de la
barre laterale aussi. Les deux vues gardent leurs signaux : la fenetre
principale s'y branche comme avant.
"""
from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtWidgets import (QButtonGroup, QFrame, QHBoxLayout, QLabel,
                               QStackedWidget, QVBoxLayout, QWidget)

from ..theme import PALETTE
from ..widgets.pastille import BoutonPastille

OFFRES, GRATUITS = "offres", "gratuits"
ONGLETS = ((OFFRES, "Offres"), (GRATUITS, "Gratuits en ce moment"))


class BoutiquePage(QWidget):
    onglet_change = Signal(str)

    def __init__(self, offres: QWidget, gratuits: QWidget, parent=None) -> None:
        super().__init__(parent)
        self.offres, self.gratuits = offres, gratuits
        self._onglet = OFFRES

        racine = QVBoxLayout(self)
        racine.setContentsMargins(0, 0, 0, 0)
        racine.setSpacing(0)

        # -- en-tete commun : titre et onglets ------------------------------
        tete = QHBoxLayout()
        tete.setContentsMargins(24, 18, 24, 4)       # meme en-tete que les autres pages
        tete.setSpacing(18)
        titre = QLabel("Boutique")
        titre.setObjectName("PageTitle")
        tete.addWidget(titre)

        barre = QFrame()
        barre.setObjectName("Segments")
        segments = QHBoxLayout(barre)
        segments.setContentsMargins(3, 3, 3, 3)
        segments.setSpacing(2)
        self.groupe = QButtonGroup(self)
        self.groupe.setExclusive(True)
        self.boutons: dict[str, BoutonPastille] = {}
        for cle, libelle in ONGLETS:
            b = BoutonPastille(libelle, marge_texte=16)
            b.setObjectName("Segment")
            b.setCheckable(True)
            b.clicked.connect(lambda _=False, c=cle: self.montrer(c))
            self.groupe.addButton(b)
            segments.addWidget(b)
            self.boutons[cle] = b
        tete.addWidget(barre)
        # la barre de recherche en haut de la page, a cote des onglets, comme
        # sur les sites de vente de jeux (14 octobre) : elle sert depuis les deux
        # onglets ; une saisie depuis « Gratuits » ramene aux offres
        champ = getattr(offres, "recherche", None)
        if champ is not None:
            tete.addSpacing(6)
            champ.setMinimumWidth(320)
            champ.setMaximumWidth(680)
            tete.addWidget(champ, 3)
            bouton = getattr(offres, "bouton_chercher", None)
            if bouton is not None:
                tete.addWidget(bouton)
            champ.textEdited.connect(self._saisie_ailleurs)
        tete.addStretch(1)
        racine.addLayout(tete)

        self.pile = QStackedWidget()
        for vue in (offres, gratuits):
            if hasattr(vue, "integrer"):
                vue.integrer()          # plus de titre propre : celui de la page suffit
            self.pile.addWidget(vue)
        racine.addWidget(self.pile, 1)
        # « Voir les gratuits », dans la vitrine des offres, ouvre l'onglet
        signal = getattr(offres, "voir_gratuits", None)
        if signal is not None:
            signal.connect(lambda: self.montrer(GRATUITS))
        self.montrer(OFFRES)

    # ------------------------------------------------------------------
    @property
    def onglet(self) -> str:
        return self._onglet

    def montrer(self, onglet: str) -> None:
        onglet = onglet if onglet in self.boutons else OFFRES
        self._onglet = onglet
        self.boutons[onglet].setChecked(True)
        self.pile.setCurrentWidget(self.gratuits if onglet == GRATUITS else self.offres)
        self.onglet_change.emit(onglet)

    def _saisie_ailleurs(self, _texte: str) -> None:
        if self._onglet != OFFRES:
            self.montrer(OFFRES)
            champ = getattr(self.offres, "recherche", None)
            if champ is not None:
                champ.setFocus()

    def set_gratuits(self, nombre: int, urgent: bool = False) -> None:
        """Nombre d'offres gratuites a saisir, affiche sur l'onglet."""
        self.boutons[GRATUITS].set_pastille(
            str(nombre) if nombre else "",
            PALETTE["warn"] if urgent else PALETTE["ok"])
