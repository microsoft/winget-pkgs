"""Boutique ultime : tous les jeux, toutes les boutiques sures, le prix le plus bas.

Le service rassemble les offres de chaque source (voir
`plugins/boutique/`), fusionne celles qui designent le meme jeu en une
`Fiche`, et retient comme meilleur prix la moins chere des offres venant
d'une boutique **sure** (officielle ou revendeur agree, voir
`plugins/boutique/confiance.py`). Une place de marche de cles n'est jamais
« le meilleur prix », meme si elle est moins chere.

Trois usages :

* `actualiser()` : la vitrine (promotions, gratuits, meilleures ventes),
  rejouee toutes les 10 a 15 minutes par la fenetre principale ;
* `chercher(terme)` : n'importe quel jeu, en promotion ou non ;
* `comparer(fiche)` : toutes les boutiques pour un jeu precis.

Rien n'est envoye : la boutique ne fait que lire des catalogues publics.
"""
from __future__ import annotations

import functools
import hashlib
import itertools
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field

from .core import recherche, region
from .core.config import CONFIG
from .core.logging_setup import get
from .core.paths import ART_DIR, DATA_DIR, ensure_dirs
from .core.recherche import sans_bruit
from .core.registry import available as only_available
from .core.registry import discover
from .contenu_adulte import visibles
from .plugins.boutique.base import Offre, SourceBoutique, SourceUnavailable

log = get("boutique")

FICHIER = DATA_DIR / "boutique.json"
IMAGES = ART_DIR / "boutique"

#: intervalle par defaut entre deux actualisations, en minutes
INTERVALLE = 12


# ---------------------------------------------------------------------------
# Fiches figees le temps d'un calcul d'affichage
# ---------------------------------------------------------------------------
# Tout ce qu'une fiche dit d'elle-meme (meilleure offre, remise, type, numero
# Steam...) est recalcule a chaque question, a partir de ses offres : c'est
# ce qui garde ces reponses justes quand une offre change. Mais l'affichage de
# la Boutique pose ces questions des centaines de milliers de fois d'affilee
# (trier, filtrer, remplir vingt rangees), sans que rien ne change entre deux
# questions : 0,5 s de fil d'affichage a chaque actualisation, mesure du 7
# octobre 2026. `gele()` dit « pendant ce calcul, les fiches ne bougent pas » :
# chaque reponse n'est alors calculee qu'une fois. Vaut pour le fil qui
# l'ouvre seulement ; les taches de fond, elles, recalculent toujours.
_gel = threading.local()
_epoques = itertools.count(1)


@contextmanager
def gele():
    if getattr(_gel, "epoque", 0):
        yield                       # deja fige par l'appelant
        return
    _gel.epoque = next(_epoques)
    try:
        yield
    finally:
        _gel.epoque = 0


def fige(fonction):
    """Decorateur : la fonction s'execute fiches figees (voir `gele`)."""
    @functools.wraps(fonction)
    def enveloppe(*args, **kwargs):
        with gele():
            return fonction(*args, **kwargs)
    return enveloppe


def _gardee(lecture):
    """Propriete d'une fiche, gardee le temps d'un calcul fige."""
    nom = lecture.__name__

    @functools.wraps(lecture)
    def lire(self):
        epoque = getattr(_gel, "epoque", 0)
        if not epoque:
            return lecture(self)
        memoire = self.__dict__.get("_fige")
        if memoire is None or memoire[0] != epoque:
            memoire = (epoque, {})
            self.__dict__["_fige"] = memoire
        try:
            return memoire[1][nom]
        except KeyError:
            valeur = memoire[1][nom] = lecture(self)
            return valeur
    return property(lire)


@dataclass
class Fiche:
    """Un jeu et toutes ses offres connues."""
    titre: str
    offres: list[Offre] = field(default_factory=list)
    image_locale: str = ""
    #: meilleure cle verifiee chez un revendeur, quand elle bat les boutiques
    #: sures : {"site", "nom", "prix", "url", ...} (voir `prix_revendeurs`).
    #: Jamais « la meilleure offre » : une mention a part, sur la carte.
    revendeur = None

    # -- identite --------------------------------------------------------
    @property
    def cle(self) -> str:
        # demandee a chaque dessin de carte, a chaque tri, a chaque filtre :
        # gardee tant que le titre et les identifiants n'ont pas change
        etat = (self.titre, self.steam_appid, self.itad_id)
        garde = self.__dict__.get("_cle")
        if garde is None or garde[0] != etat:
            garde = (etat, cle_jeu(*etat))
            self.__dict__["_cle"] = garde
        return garde[1]

    def _premier(self, champ: str):
        for o in self.offres:
            v = getattr(o, champ)
            if v:
                return v
        return type(getattr(self.offres[0], champ))() if self.offres else ""

    @_gardee
    def steam_appid(self) -> str:
        return self._premier("steam_appid")

    @_gardee
    def itad_id(self) -> str:
        return self._premier("itad_id")

    @_gardee
    def image(self) -> str:
        # les bannieres Steam sont les plus nettes, puis GOG, puis ITAD
        for source in ("steam", "gog", "itad"):
            for o in self.offres:
                if o.source == source and o.image:
                    return o.image
        return self._premier("image")

    @_gardee
    def genres(self) -> list[str]:
        return self._premier("genres") or []

    @_gardee
    def sortie(self) -> str:
        return self._premier("sortie")

    @_gardee
    def note(self) -> int:
        # la note d'une source, sinon le pourcentage d'avis Steam positifs
        return self._premier("note") or int(self.details.get("positifs") or 0)

    # -- fiche Steam detaillee (etiquettes, studios, avis, visuels) -------
    @_gardee
    def details(self) -> dict:
        return MEMO.get(self.steam_appid) if self.steam_appid else {}

    @_gardee
    def adulte(self) -> bool:
        """Jeu reserve aux adultes : une source l'a signale, ou sa fiche
        Steam (descripteur, etiquettes) le dit. Vaut pour toutes les
        boutiques du jeu : la Boutique ne montre pas la fiche."""
        from .contenu_adulte import signale
        if any(o.adulte for o in self.offres):
            return True
        d = self.details
        if "adulte" in d:               # Steam a tranche (descripteurs)
            return bool(d["adulte"])
        return signale(d.get("tags"), self.genres)

    @property
    def etiquettes(self) -> list[str]:
        """Genres et etiquettes, sans doublon, les plus parlants d'abord.
        La liste rendue est gardee : ne pas la modifier."""
        genres = self.genres
        tags = self.details.get("tags") or ()
        etat = (tuple(genres), id(tags), len(tags))
        garde = self.__dict__.get("_etiquettes")
        if garde is not None and garde[0] == etat:
            return garde[1]
        vus, out = set(), []
        for g in list(genres) + list(tags):
            k = (g or "").strip().lower()
            if k and k not in vus and not k.startswith("tag"):
                vus.add(k)
                out.append(g.strip())
        self.__dict__["_etiquettes"] = (etat, out)
        return out

    @_gardee
    def studios(self) -> list[str]:
        return list(self.details.get("devs") or [])

    @_gardee
    def avis(self) -> int:
        """Nombre d'avis Steam (0 = inconnu) : mesure de notoriete."""
        return int(self.details.get("avis") or 0)

    @_gardee
    def populaire(self) -> int:
        return max((o.populaire for o in self.offres), default=0)

    def visuels(self, format: str = "carte") -> list[str]:
        """Adresses d'images a essayer dans l'ordre, la plus belle d'abord.

        `format` : « une » (grande banniere sans texte, pour le carrousel)
        ou « carte » (capsule paysage)."""
        d, a = self.details, self.steam_appid
        legacy = f"https://cdn.akamai.steamstatic.com/steam/apps/{a}/" if a else ""
        if format == "une":
            urls = [d.get("hero"), legacy and legacy + "library_hero.jpg",
                    d.get("capsule"), legacy and legacy + "capsule_616x353.jpg",
                    d.get("header"), self.image]
        else:
            urls = [d.get("capsule"), legacy and legacy + "capsule_616x353.jpg",
                    d.get("header"), self.image]
        vus, out = set(), []
        for u in urls:
            if u and u not in vus:
                vus.add(u)
                out.append(u)
        return out

    # -- prix ------------------------------------------------------------
    @_gardee
    def offres_sures(self) -> list[Offre]:
        """Les offres des boutiques sures, la moins chere d'abord.

        Demande des dizaines de fois par jeu a chaque affichage de la
        Boutique (meilleure offre, remise, gratuite...) : le classement est
        garde tant que les offres et leurs prix n'ont pas change."""
        etat = tuple((id(o), o.prix, o.boutique) for o in self.offres)
        garde = self.__dict__.get("_sures")
        if garde is None or garde[0] != etat:
            # a prix egal, la boutique partenaire d'abord (meme prix pour le
            # joueur, meme surete : la commission fait vivre ORION), puis la
            # boutique officielle
            from .affiliation import est_partenaire
            garde = (etat, sorted((o for o in self.offres if o.sure),
                                  key=lambda o: (o.prix, not est_partenaire(o.url),
                                                 o.confiance.cle != "officiel")))
            self.__dict__["_sures"] = garde
        return list(garde[1])

    @_gardee
    def meilleure(self) -> Offre | None:
        sures = self.offres_sures
        return sures[0] if sures else None

    @_gardee
    def prix_normal(self) -> float:
        normaux = [o.prix_normal for o in self.offres_sures if o.prix_normal]
        return max(normaux) if normaux else 0.0

    @_gardee
    def remise(self) -> int:
        m, normal = self.meilleure, self.prix_normal
        if not m or not normal or m.prix >= normal:
            return 0
        return int(round(100 - m.prix * 100 / normal))

    @_gardee
    def gratuit(self) -> bool:
        m = self.meilleure
        return bool(m and m.gratuit)

    @_gardee
    def economie(self) -> float:
        m = self.meilleure
        return round(self.prix_normal - m.prix, 2) if m else 0.0

    @_gardee
    def plus_bas_historique(self) -> float:
        bas = [o.plus_bas_historique for o in self.offres if o.plus_bas_historique]
        return min(bas) if bas else 0.0

    @_gardee
    def au_plus_bas(self) -> bool:
        """Vrai si le prix actuel egale (ou bat) le plus bas jamais releve."""
        m, bas = self.meilleure, self.plus_bas_historique
        # jamais un jeu a son prix normal : un jeu qui n'a jamais ete solde
        # est « au plus bas » depuis sa sortie, et cela ne dit rien
        return bool(m and bas and m.prix <= bas + 0.01 and not m.gratuit
                    and m.prix < self.prix_normal - 0.005)

    @_gardee
    def est_application(self) -> bool:
        """Vrai pour ce qui n'est pas un jeu : logiciel, formation, livre,
        bande originale, DLC... (masque par defaut dans la Boutique)."""
        types = {(o.type_article or "").lower() for o in self.offres} - {""}
        d = self.details
        if "jeu" in d:
            # la fiche Steam detaillee dit ce qu'est l'article ; la
            # recherche Steam, elle, repond « app » pour tout
            types = (types - {"app"}) | ({"game"} if d["jeu"] else {"app"})
        return est_application(self.titre, self.genres, types)

    @_gardee
    def nb_boutiques(self) -> int:
        return len({o.boutique for o in self.offres_sures})

    @_gardee
    def fin_promo(self) -> float:
        m = self.meilleure
        return m.fin_promo if m else 0.0

    def ajouter(self, offre: Offre) -> None:
        """Une offre par boutique : la plus recente remplace l'ancienne."""
        for i, o in enumerate(self.offres):
            if o.boutique.lower() == offre.boutique.lower():
                # garde les informations que la nouvelle offre n'a pas
                for champ in ("image", "genres", "sortie", "note", "steam_appid",
                              "itad_id", "plus_bas_historique", "fin_promo",
                              "type_article", "populaire"):
                    if not getattr(offre, champ) and getattr(o, champ):
                        setattr(offre, champ, getattr(o, champ))
                self.offres[i] = offre
                return
        self.offres.append(offre)

    def to_dict(self) -> dict:
        return {"titre": self.titre, "image_locale": self.image_locale,
                "offres": [o.to_dict() for o in self.offres]}

    @classmethod
    def from_dict(cls, d: dict) -> "Fiche":
        return cls(titre=d.get("titre", ""),
                   image_locale=d.get("image_locale", ""),
                   offres=[Offre.from_dict(o) for o in d.get("offres") or []])


# -- jeux ou applications ----------------------------------------------------
#: natures donnees par les sources (IsThereAnyDeal, Steam, GOG)
TYPES_JEU = {"game", "jeu", "pack", "0"}
TYPES_AUTRES = {"dlc", "app", "application", "software", "logiciel", "music",
                "soundtrack", "video", "series", "episode", "hardware", "mod",
                "demo", "advertising", "tool", "course", "ebook", "book", "comic"}

#: genres Steam propres aux logiciels (une fiche qui n'a QUE ceux-la n'est
#: pas un jeu)
GENRES_LOGICIELS = {
    "utilities", "utilitaires", "software training", "formation logicielle",
    "design & illustration", "design et illustration", "animation & modeling",
    "animation et modelisation", "animation et modélisation", "audio production",
    "production audio", "video production", "production video",
    "production vidéo", "web publishing", "publication web", "photo editing",
    "retouche photo", "education", "éducation", "accounting", "comptabilite",
    "comptabilité", "game development", "developpement de jeux",
    "développement de jeux", "software", "logiciel"}

import re as _re                                              # noqa: E402

#: mots qui designent a coup sur autre chose qu'un jeu
_FORTS = _re.compile(
    r"\b(certifications?|bootcamps?|masterclass(es)?|tutorials?|"
    r"e-?books?|audiobooks?|soundtracks?|o\.?s\.?t|artbooks?|art\s+book|"
    r"softwares?|udemy|programming|coding|photoshop|vpn|antivirus|"
    r"wallpapers?|cursus|e-?learning|kali\s+linux)\b", _re.I)
#: mots ambigus (« Business Tour », « Comic Jumper », « Excel Saga » sont des
#: jeux) : ils ne comptent qu'avec un second indice, lot ou formation
_FAIBLES = _re.compile(
    r"\b(business|learn(ing)?|developers?|development|design|marketing|"
    r"finance|cyber\s*security|comics?|books?|manga|productivity|office|"
    r"python|java(script)?|excel|linux|kali|hacking|networking|devops|"
    r"aws|azure|sql|machine\s+learning)\b", _re.I)
_CONTEXTE = _re.compile(r"\b(bundle|courses?|formations?|training|class(es)?|"
                        r"masterclass|lessons?)\b", _re.I)


def est_application(titre: str, genres=(), types=()) -> bool:
    """Un article de boutique est-il autre chose qu'un jeu ?

    La nature donnee par la source prime (« game » contre « dlc », « app »...).
    A defaut : les genres Steam propres aux logiciels, puis le titre."""
    types = {str(t).lower() for t in (types or ()) if t}
    if types & TYPES_AUTRES and not types & TYPES_JEU:
        return True
    if types & TYPES_JEU and not types & TYPES_AUTRES:
        # la source dit « jeu » : seul un titre sans equivoque la contredit
        # (les lots de formations sont parfois classes « game »)
        return bool(_FORTS.search(titre or ""))
    genres = {str(g).strip().lower() for g in (genres or ()) if g}
    if genres and genres <= GENRES_LOGICIELS:
        return True
    titre = titre or ""
    if _FORTS.search(titre):
        return True
    return bool(_FAIBLES.search(titre) and _CONTEXTE.search(titre))


def cle_jeu(titre: str, appid: str = "", itad_id: str = "") -> str:
    return sans_bruit(titre) or (f"steam:{appid}" if appid else f"itad:{itad_id}")


def fusionner(offres: list[Offre], fiches: list[Fiche] | None = None) -> list[Fiche]:
    """Regroupe les offres par jeu.

    Un jeu est reconnu par son appid Steam, son identifiant IsThereAnyDeal ou
    son titre debarrasse des mentions d'edition (« GOTY », « Deluxe »...).
    """
    fiches = list(fiches or [])
    index: dict[str, Fiche] = {}

    def indexer(f: Fiche, o: Offre) -> None:
        for k in _cles(o):
            index.setdefault(k, f)

    for f in fiches:
        for o in f.offres:
            indexer(f, o)
    for o in offres:
        if not o.titre:
            continue
        fiche = next((index[k] for k in _cles(o) if k in index), None)
        if fiche is None:
            fiche = Fiche(titre=o.titre)
            fiches.append(fiche)
        elif o.source == "steam" and o.titre:
            fiche.titre = o.titre     # le nom Steam est le plus propre
        fiche.ajouter(o)
        indexer(fiche, o)
    return fiches


def _cles(o: Offre) -> list[str]:
    cles = []
    if o.steam_appid:
        cles.append(f"steam:{o.steam_appid}")
    if o.itad_id:
        cles.append(f"itad:{o.itad_id}")
    t = sans_bruit(o.titre)
    if t:
        cles.append(f"t:{t}")
    return cles


class MemoSteam:
    """Fiches Steam detaillees, gardees en base locale (14 jours).

    Lues une fois en memoire : les fiches de la Boutique et les suggestions
    les consultent sans appel reseau ni acces disque."""

    DUREE = 14 * 86400

    def __init__(self) -> None:
        self._donnees: dict[str, dict] | None = None
        self._table = None

    def _charger(self) -> dict[str, dict]:
        if self._donnees is None:
            try:
                from .core.base import Table
                self._table = Table("boutique_steam", maximum=6000)
                self._donnees = {k: v for k, v in self._table.tout().items()
                                 if isinstance(v, dict)}
            except Exception:
                log.debug("Fiches Steam detaillees illisibles")
                self._donnees = {}
        return self._donnees

    def get(self, appid: str) -> dict:
        return self._charger().get(str(appid)) or {}

    def tout(self) -> dict[str, dict]:
        return self._charger()

    def manquants(self, appids) -> list[str]:
        d, maintenant = self._charger(), time.time()
        return [a for a in dict.fromkeys(str(x) for x in appids if str(x).isdigit())
                if maintenant - float((d.get(a) or {}).get("le") or 0) > self.DUREE]

    def ajouter(self, fiches: dict[str, dict]) -> None:
        d = self._charger()
        maintenant = time.time()
        for a, f in fiches.items():
            d[str(a)] = {**f, "le": maintenant}
        try:
            if self._table is not None and fiches:
                self._table.update({str(a): d[str(a)] for a in fiches})
        except Exception:
            log.debug("Fiches Steam detaillees non enregistrees")

    def vider(self) -> None:
        """Oublie le contenu en memoire (tests)."""
        self._donnees = {}


MEMO = MemoSteam()


class BoutiqueService:
    def __init__(self) -> None:
        ensure_dirs()
        #: appids Steam des jeux possedes : leurs fiches detaillees nourrissent
        #: les suggestions « Pour vous » (renseigne par la fenetre principale)
        self.appids_bibliotheque: set[str] = set()
        self._etiquettes: dict[int, str] = {}
        self.fiches: list[Fiche] = []
        self.actualise_le: float = 0.0
        self.etat_sources: dict[str, str] = {}
        self._sources: list[SourceBoutique] | None = None
        self.charger()

    # -- sources -------------------------------------------------------
    @property
    def sources(self) -> list[SourceBoutique]:
        if self._sources is None:
            self._sources = discover(SourceBoutique, "orion.plugins.boutique",
                                     "boutique")
            if not self._sources:
                # arrive si le paquet n'a pas ete embarque dans l'executable
                log.error("Aucune source de prix chargee : la Boutique ne "
                          "montrera que les jeux gratuits")
                self.etat_sources["boutique"] = "aucune source de prix chargee"
        return only_available(self._sources)


    def source(self, sid: str) -> SourceBoutique | None:
        return next((s for s in self.sources if s.id == sid), None)

    @property
    def comparateur_actif(self) -> bool:
        return self.source("itad") is not None

    # -- persistance ---------------------------------------------------
    def charger(self) -> None:
        from .core.base import Document
        self._doc = Document("boutique", FICHIER)
        try:
            d = self._doc.lire(None)
            if not d:
                return
            self.fiches = visibles([Fiche.from_dict(f) for f in d.get("fiches") or []])
            self.actualise_le = float(d.get("actualise_le") or 0)
            self.etat_sources = dict(d.get("sources") or {})
        except Exception:
            log.exception("Boutique illisible, elle sera reconstruite")

    def enregistrer(self) -> None:
        self._doc.ecrire(
            {"actualise_le": self.actualise_le, "sources": self.etat_sources,
             "fiches": [f.to_dict() for f in self.fiches]})

    # -- vitrine -------------------------------------------------------
    @staticmethod
    def intervalle_minutes() -> int:
        return max(5, int(CONFIG.get("boutique.refresh_minutes", INTERVALLE)
                          or INTERVALLE))

    def actualiser(self, gratuits=None, progress_cb=None) -> list[Fiche]:
        """Releve la vitrine de chaque source et reconstruit le catalogue.

        C'est la partie RAPIDE : les vitrines sont demandees en meme temps
        (quelques secondes), puis assemblees avec ce qu'ORION sait deja (jeux
        par type, fiches detaillees, plus bas historiques gardes). Tout ce
        qui est long et ne change pas les prix du jour (types a relire,
        fiches manquantes, plus bas historiques) est fait ensuite par
        `completer`, catalogue deja affiche. Avant le 7 octobre 2026 tout
        etait fait d'une traite, source apres source : 95 secondes.

        Une source injoignable garde ses offres precedentes : une coupure
        reseau ne doit pas vider la boutique.
        """
        from concurrent.futures import ThreadPoolExecutor
        from . import prix_gamesplanet
        debut = time.time()
        anciennes: dict[str, list[Offre]] = {}
        for f in self.fiches:
            for o in f.offres:
                anciennes.setdefault(o.source, []).append(o)
        sources = self.sources
        if progress_cb:
            progress_cb("Boutique : prix du jour...", 10)
        durees: dict[str, float] = {}

        def vitrine(s):
            t0 = time.time()
            try:
                recues = list(s.vitrine())
                self.etat_sources[s.id] = f"{len(recues)} offres"
                return recues, True
            except SourceUnavailable as exc:
                log.warning("Source boutique indisponible : %s", exc)
                self.etat_sources[s.id] = "injoignable, offres precedentes gardees"
            except Exception:
                log.exception("Source boutique en echec : %s", s.id)
                self.etat_sources[s.id] = "erreur, offres precedentes gardees"
            finally:
                durees[s.id] = time.time() - t0
            return anciennes.get(s.id, []), False

        def gamesplanet():
            t0 = time.time()
            prix_gamesplanet.actualiser()          # fichier garde deux heures
            durees[prix_gamesplanet.SOURCE] = time.time() - t0

        offres: list[Offre] = []
        reussies = 0
        with ThreadPoolExecutor(max_workers=max(1, min(6, len(sources) + 1))) as ensemble:
            fichier = ensemble.submit(gamesplanet)
            for recues, ok in ensemble.map(vitrine, sources):
                offres += recues
                reussies += ok
            fichier.result()
        self._offres_vitrine = offres
        self._gratuits = gratuits
        self._assembler()
        if reussies:
            # l'heure affichee est celle des derniers prix vraiment releves
            self.actualise_le = time.time()
        self.enregistrer()
        log.info("Boutique actualisee : %d jeux, %d offres en %.1f s (%s)",
                 len(self.fiches), len(offres), time.time() - debut,
                 ", ".join(f"{k} {v:.1f} s" for k, v in sorted(durees.items())))
        return self.fiches

    def _assembler(self) -> None:
        """Le catalogue, a partir des vitrines relevees et de tout ce qui est
        deja connu. Aucun appel reseau."""
        from . import prix_gamesplanet
        offres = list(getattr(self, "_offres_vitrine", None) or [])
        offres += self.offres_par_type(relire=False)
        offres += self._suite_gardee()
        offres += self._offres_gratuites(getattr(self, "_gratuits", None))
        images = {f.cle: f.image_locale for f in self.fiches if f.image_locale}
        fiches = fusionner(offres)
        # prix de Gamesplanet (distributeur officiel partenaire), par numero Steam
        self.etat_sources[prix_gamesplanet.SOURCE] = (
            f"{prix_gamesplanet.completer(fiches)} offres"
            if prix_gamesplanet.valable() else "prix indisponibles")
        for f in fiches:
            f.image_locale = images.get(f.cle, "")
        self.appliquer_plus_bas(fiches)
        # la decision se prend ici, avec les fiches detaillees connues, pour
        # toutes les sources a la fois
        avant = len(fiches)
        fiches = visibles(fiches)
        if len(fiches) != avant:
            log.info("Boutique : %d jeu(x) reserve(s) aux adultes ecarte(s)", avant - len(fiches))
        self.fiches = fiches

    def _empreinte(self) -> tuple:
        """Ce qui change a l'ecran quand le catalogue est complete."""
        connues = MEMO.tout()
        return (len(self.fiches), sum(len(f.offres) for f in self.fiches),
                sum(1 for f in self.fiches if f.plus_bas_historique),
                sum(1 for f in self.fiches if f.steam_appid in connues))

    def completer(self, progress_cb=None) -> bool:
        """La partie LENTE de l'actualisation, catalogue deja affiche : types
        de jeu a relire, fiches detaillees manquantes (etiquettes, avis,
        visuels), plus bas historiques. Rend vrai si le catalogue a change et
        doit etre reaffiche. Jamais bloquant."""
        debut = time.time()
        avant = self._empreinte()
        etapes: list[str] = []

        def etape(nom: str, fonction) -> None:
            t0 = time.time()
            try:
                fonction()
            except Exception:
                log.exception("Boutique : etape « %s » en echec", nom)
            etapes.append(f"{nom} {time.time() - t0:.1f} s")
        etape("types", lambda: self.offres_par_type())
        etape("fiches", lambda: self.enrichir([f.steam_appid for f in self.fiches]
                                              + sorted(self.appids_bibliotheque)))
        etape("plus bas", self.relever_plus_bas)
        self._assembler()
        apres = self._empreinte()
        if apres != avant:
            self.enregistrer()
        log.info("Boutique completee en %.1f s (%s)%s", time.time() - debut, ", ".join(etapes),
                 "" if apres != avant else ", rien de neuf")
        return apres != avant

    #: types de jeu relus par passage, et duree de garde de chacun
    # tous d'un coup : la relecture se fait apres l'affichage (`completer`),
    # et un nouveau joueur n'attend plus une heure que ses pages se remplissent
    TYPES_PAR_PASSAGE = 30
    TYPES_DUREE = 6 * 3600

    def offres_par_type(self, relire: bool = True) -> list[Offre]:
        """Les jeux les plus en vue de chaque type de jeu (FPS, MOBA, Battle
        Royale...), en promotion ou non.

        Sans eux, la page d'un type ne montrerait que ses promotions du
        moment : cinq MOBA, six Battle Royale. Chaque type est relu toutes
        les six heures, quelques types par passage (le premier remplissage
        prend donc quelques actualisations) ; entre-temps ses jeux viennent
        de la memoire. Jamais bloquant : une erreur laisse ce qui est connu."""
        if not CONFIG.get("boutique.types_complets", True):
            return []
        from .core.base import Table
        from .plugins.boutique import steam
        if getattr(self, "_types", None) is None:
            self._types = Table("boutique_types")
        maintenant = time.time()

        def age(cle: str) -> float:
            return maintenant - float((self._types.get(cle) or {}).get("le") or 0)
        # `relire=False` : seulement ce qui est garde, sans appel reseau
        perimes = sorted((c for c in steam.ETIQUETTES_TYPES if age(c) > self.TYPES_DUREE),
                         key=lambda c: -age(c))[:self.TYPES_PAR_PASSAGE] if relire else []
        if perimes and not self._etiquettes:
            try:
                self._etiquettes = steam.noms_etiquettes()
            except SourceUnavailable as exc:
                log.info("%s", exc)
        for cle in perimes:
            try:
                recues, fiches = steam.par_type(cle, etiquettes=self._etiquettes or None)
            except SourceUnavailable as exc:
                log.info("%s", exc)
                break                      # Steam ne repond pas : inutile d'insister
            except Exception:
                log.exception("Jeux du type %s en echec", cle)
                break
            if recues:
                self._types.set(cle, {"le": maintenant, "offres": [o.to_dict() for o in recues]})
                MEMO.ajouter(fiches)
        offres: list[Offre] = []
        for cle in steam.ETIQUETTES_TYPES:
            for d in (self._types.get(cle) or {}).get("offres") or []:
                try:
                    offres.append(Offre.from_dict(d))
                except (TypeError, ValueError):
                    continue
        return offres

    # -- cles verifiees des revendeurs, pour les cartes --------------------
    def cles_revendeurs(self, fiches: list[Fiche]) -> int:
        """Pose sur chaque fiche la cle verifiee la moins chere d'un
        revendeur retenu, si elle bat la meilleure boutique sure (voir
        `prix_revendeurs.lot`). Rend le nombre de fiches qui en portent une.
        Jamais bloquant ; rien si l'encart des revendeurs est coupe."""
        from . import prix_revendeurs
        if not CONFIG.get("marche_gris.afficher", True):
            for f in fiches:
                f.revendeur = None
            return 0
        voulues = [f for f in fiches if str(f.steam_appid).isdigit() and f.meilleure
                   and not f.gratuit]
        try:
            connus = prix_revendeurs.lot([(f.steam_appid, f.titre) for f in voulues])
        except Exception:
            log.exception("Prix des revendeurs par lot en echec")
            return 0
        n = 0
        for f in voulues:
            f.revendeur = prix_revendeurs.meilleure_cle(
                connus.get(f.steam_appid) or {}, f.meilleure.prix,
                max((o.prix_normal or 0 for o in f.offres_sures), default=0))
            n += f.revendeur is not None
        return n

    # -- la suite du magasin, a la demande ---------------------------------
    #: jeux demandes a chaque fois, et plafond par page et par session
    SUITE_LOT = 100
    SUITE_MAX = 5000
    #: une suite chargee reste dans le catalogue jusqu'a cet age
    SUITE_DUREE = 6 * 3600

    def _etat_suite(self, cle: str) -> dict:
        if getattr(self, "_suites", None) is None:
            self._suites: dict[str, dict] = {}
            self._offres_suite: dict[str, Offre] = {}
        etat = self._suites.get(cle)
        if etat is None:
            # les cent premiers d'un type sont deja la (voir `offres_par_type`)
            deja = bool(cle and (getattr(self, "_types", None) is not None)
                        and (self._types.get(cle) or {}).get("offres"))
            debut = self.SUITE_LOT if deja else 0
            if cle == "promos":
                debut = 200               # la vitrine releve deja les deux cents premieres
            etat = self._suites[cle] = {"debut": debut, "fini": False, "total": 0}
        return etat

    def suite_possible(self, cle: str) -> bool:
        """Vrai tant que le magasin a encore des jeux a donner pour ce type
        (tout le magasin si `cle` est vide, les promotions pour « promos »)."""
        etat = self._etat_suite(cle or "")
        return not etat["fini"] and etat["debut"] < self.SUITE_MAX

    #: « Plus de jeux » doit en amener : si un lot n'apporte presque rien de
    #: nouveau (jeux deja la, ecartes ou sans prix), le suivant est demande
    #: dans la foulee. Vu le 7 octobre 2026 : trois jeux pour un clic.
    SUITE_UTILE = 20
    SUITE_LOTS_PAR_DEMANDE = 3

    def suite(self, cle: str = "") -> list[Fiche]:
        """Les jeux suivants d'un type, des promotions (« promos ») ou de
        tout le magasin, ajoutes au catalogue. Rend les jeux nouveaux pour la
        Boutique.

        Le catalogue releve d'avance ne tient que les vitrines, les
        promotions et les cent jeux les plus en vue de chaque type. Le reste
        du magasin (plus de cent mille jeux) vient ici, a la demande, quand
        le joueur arrive au bout d'une page : rien n'est hors de portee, et
        ORION ne telecharge pas tout le magasin pour autant. Jamais bloquant :
        Steam muet, la page garde ce qu'elle a."""
        from .plugins.boutique import steam
        cle = cle if cle in steam.ETIQUETTES_TYPES or cle == steam.PROMOS else ""
        etat = self._etat_suite(cle)
        toutes: list[Fiche] = []
        for _ in range(self.SUITE_LOTS_PAR_DEMANDE):
            if not self.suite_possible(cle):
                break
            lot = self._lot_de_suite(cle, etat)
            if lot is None:
                break                       # Steam muet : on garde ce qu'on a
            toutes += lot
            if len(toutes) >= self.SUITE_UTILE:
                break
        return toutes

    def _lot_de_suite(self, cle: str, etat: dict) -> list[Fiche] | None:
        """Un lot de `SUITE_LOT` jeux a partir du rang courant. None si Steam
        ne repond pas."""
        from .plugins.boutique import steam
        try:
            if not self._etiquettes:
                self._etiquettes = steam.noms_etiquettes()
        except SourceUnavailable as exc:
            log.info("%s", exc)
        try:
            if cle == steam.PROMOS:
                recues, fiches, total = steam.page_promotions(
                    etat["debut"], self.SUITE_LOT, self._etiquettes or None)
            else:
                recues, fiches, total = steam.page_magasin(
                    cle, etat["debut"], self.SUITE_LOT, self._etiquettes or None)
        except SourceUnavailable as exc:
            log.info("%s", exc)
            return None
        except Exception:
            log.exception("Suite du magasin en echec (%s)", cle or "tout")
            return None
        etat["total"] = total or etat["total"]
        etat["debut"] += self.SUITE_LOT
        # moins qu'une page pleine cote Steam, ou le bout annonce : c'est fini
        if (total and etat["debut"] >= total) or not recues:
            etat["fini"] = True
        MEMO.ajouter(fiches)
        connus = {f.steam_appid for f in self.fiches if f.steam_appid}
        neuves = [o for o in recues if o.steam_appid not in connus]
        for o in neuves:
            self._offres_suite[o.steam_appid] = o
        nouvelles = fusionner(neuves)
        from . import prix_gamesplanet
        prix_gamesplanet.completer(nouvelles)
        self.relever_plus_bas(nouvelles)
        self.appliquer_plus_bas(nouvelles)
        nouvelles = visibles(nouvelles)
        self.fiches = self.fiches + nouvelles
        log.info("Boutique : %d jeux de plus (%s, rang %d sur %d)", len(nouvelles),
                 cle or "tout le magasin", etat["debut"], etat["total"])
        return nouvelles

    def _suite_gardee(self) -> list[Offre]:
        """Les jeux charges a la demande restent dans le catalogue d'une
        actualisation a l'autre : la page que le joueur feuillette ne doit pas
        raccourcir sous ses yeux. Six heures au plus (prix releves alors)."""
        gardees = getattr(self, "_offres_suite", None) or {}
        limite = time.time() - self.SUITE_DUREE
        for a in [a for a, o in gardees.items() if o.releve_le < limite]:
            del gardees[a]
        if not gardees and getattr(self, "_suites", None):
            self._suites.clear()            # tout a expire : on repartira du debut
        return list(gardees.values())

    # -- plus bas historique (IsThereAnyDeal) ----------------------------
    #: numero du magasin Steam chez IsThereAnyDeal
    ITAD_STEAM = 61
    #: jeux par demande : identifiants, puis plus bas (le relais en prend 60)
    BAS_LOT_IDS = 90        # le relais lit ses jeux gardes par cent au plus (reponse 500 au-dela)
    BAS_LOT = 60
    #: jeux dont le plus bas est relu par actualisation
    BAS_PAR_PASSAGE = 600
    #: garde du plus bas : un jeu en promotion peut battre son record du jour
    #: au lendemain, un jeu a prix normal non
    BAS_DUREE_PROMO = 86400
    BAS_DUREE = 7 * 86400
    #: un jeu inconnu d'IsThereAnyDeal n'est pas redemande avant un mois
    BAS_INCONNU = 30 * 86400

    def _table_bas(self):
        if getattr(self, "_bas", None) is None:
            from .core.base import Table
            self._bas = Table("boutique_bas", maximum=8000)
            self._bas_memo = None
        if self._bas_memo is None:
            try:
                self._bas_memo = dict(self._bas.tout())
            except Exception:
                log.exception("Plus bas historiques illisibles")
                self._bas_memo = {}
        return self._bas

    def relever_plus_bas(self, fiches: list[Fiche] | None = None) -> int:
        """Le plus bas prix jamais releve de chaque jeu Steam du catalogue,
        demande a IsThereAnyDeal (par le relais d'ORION, sans cle a saisir).

        Avant, seules les offres venues de la vitrine d'IsThereAnyDeal
        portaient ce prix : « Au plus bas historique » ne montrait que huit
        jeux. Deux demandes groupees : appids Steam -> identifiants (gardes),
        puis identifiants -> plus bas. Les jeux en promotion passent d'abord.
        Rend le nombre de plus bas recus. Jamais bloquant."""
        if not CONFIG.get("boutique.plus_bas", True):
            return 0
        from . import itad as acces
        if not acces.actif():
            return 0
        table = self._table_bas()
        memo = self._bas_memo
        maintenant = time.time()
        fiches = self.fiches if fiches is None else fiches
        voulus = [f for f in fiches if str(f.steam_appid).isdigit() and not f.gratuit]
        voulus.sort(key=lambda f: -f.remise)
        nouveaux: dict[str, dict] = {}
        pays = region.pays()

        # 1. identifiants IsThereAnyDeal des jeux encore inconnus
        sans_id = [f.steam_appid for f in voulus
                   if not (memo.get(f.steam_appid) or {}).get("id")
                   and maintenant - float((memo.get(f.steam_appid) or {}).get("vu") or 0)
                   > self.BAS_INCONNU]
        sans_id = list(dict.fromkeys(sans_id))[:self.BAS_PAR_PASSAGE * 2]
        try:
            for i in range(0, len(sans_id), self.BAS_LOT_IDS):
                lot = sans_id[i:i + self.BAS_LOT_IDS]
                recus = acces.demander("POST", f"/lookup/id/shop/{self.ITAD_STEAM}/v1",
                                       None, [f"app/{a}" for a in lot]) or {}
                if not isinstance(recus, dict):
                    break
                for a in lot:
                    ident = recus.get(f"app/{a}")
                    nouveaux[a] = {**(memo.get(a) or {}), "vu": maintenant,
                                   "id": ident if isinstance(ident, str) else ""}
                memo.update({a: nouveaux[a] for a in lot})
        except acces.Indisponible as exc:
            log.info("Plus bas historiques : identifiants indisponibles (%s)", exc)

        # 2. plus bas des jeux dont l'identifiant est connu
        def perime(f: Fiche) -> bool:
            e = memo.get(f.steam_appid) or {}
            if not e.get("id"):
                return False
            duree = self.BAS_DUREE_PROMO if f.remise else self.BAS_DUREE
            return e.get("pays") != pays or maintenant - float(e.get("le") or 0) > duree
        a_lire = [f.steam_appid for f in voulus if perime(f)]
        a_lire = list(dict.fromkeys(a_lire))[:self.BAS_PAR_PASSAGE]
        recus_n = 0
        try:
            for i in range(0, len(a_lire), self.BAS_LOT):
                lot = a_lire[i:i + self.BAS_LOT]
                par_id = {memo[a]["id"]: a for a in lot}
                lignes = acces.demander("POST", "/games/historylow/v1",
                                        {"country": pays}, list(par_id)) or []
                bas = {}
                for ligne in lignes if isinstance(lignes, list) else []:
                    prix = ((ligne or {}).get("low") or {}).get("price") or {}
                    try:
                        bas[ligne.get("id")] = (round(float(prix.get("amount") or 0), 2),
                                                str(prix.get("currency") or ""))
                    except (TypeError, ValueError, AttributeError):
                        continue
                for ident, a in par_id.items():
                    montant, devise = bas.get(ident, (0.0, ""))
                    nouveaux[a] = {**(memo.get(a) or {}), "le": maintenant, "pays": pays,
                                   "bas": montant, "devise": devise}
                    memo[a] = nouveaux[a]
                    recus_n += 1 if montant else 0
        except acces.Indisponible as exc:
            log.info("Plus bas historiques indisponibles (%s)", exc)
        if nouveaux:
            try:
                table.update(nouveaux)
            except Exception:
                log.exception("Plus bas historiques non enregistres")
        return recus_n

    def appliquer_plus_bas(self, fiches: list[Fiche]) -> int:
        """Pose le plus bas historique connu sur l'offre Steam de chaque jeu
        (jamais sur une offre qui porte deja le sien, ni dans une autre
        monnaie). Sans appel reseau. Rend le nombre de jeux completes."""
        try:
            self._table_bas()
        except Exception:
            return 0
        memo, n = self._bas_memo or {}, 0
        for f in fiches:
            e = memo.get(str(f.steam_appid or ""))
            if not e or not e.get("bas"):
                continue
            for o in f.offres:
                if o.source == "steam" and not o.plus_bas_historique \
                        and (e.get("devise") or o.devise) == o.devise:
                    o.plus_bas_historique = float(e["bas"])
                    n += 1
                    break
        return n

    @staticmethod
    def _offres_gratuites(gratuits) -> list[Offre]:
        """Les jeux gratuits deja surveilles rejoignent la boutique."""
        out: list[Offre] = []
        for fb in gratuits or []:
            try:
                if getattr(fb, "expired", False):
                    continue
                boutique = fb.shop or ""
                # GamerPower ne connait parfois que la plateforme (« PC »,
                # « Sans DRM ») : on nomme alors l'intermediaire, pas un
                # magasin qui n'existe pas
                if boutique.lower() in ("", "?", "pc", "sans drm", "drm-free",
                                        "drm free", "other", "autre"):
                    boutique = "Offre relayee par GamerPower"
                out.append(Offre(
                    titre=fb.title, boutique=boutique, prix=0.0,
                    prix_normal=float(fb.worth or fb.price_before or 0),
                    remise=100 if fb.worth else 0, url=fb.url,
                    source="gratuits", steam_appid=str(fb.steam_appid or ""),
                    image=(fb.screenshots or [""])[0] if not fb.image else fb.image,
                    genres=list(fb.genres or [])[:3], sortie=fb.release_date or "",
                    note=int(fb.review_score or 0), fin_promo=float(fb.ends_at or 0)))
            except Exception:
                log.debug("Offre gratuite ignoree : %r", fb)
        return out

    # -- recherche -----------------------------------------------------
    #: en dessous, la recherche est retentee sans son dernier mot
    PEU_DE_RESULTATS = recherche.PEU_DE_RESULTATS
    SEUIL_RECHERCHE = 0.55

    def _offres_recherche(self, termes, muettes: set | None = None) -> list[Offre]:
        """Les offres de toutes les sources pour un ou plusieurs termes,
        demandees EN MEME TEMPS : une recherche ne dure que le temps de la
        source la plus lente, pas la somme de toutes (vingt secondes
        constatees le 7 octobre 2026, sources interrogees une a une)."""
        from concurrent.futures import ThreadPoolExecutor
        termes = [termes] if isinstance(termes, str) else list(termes)
        travaux = [(s, t) for t in termes for s in self.sources]
        if not travaux:
            return []

        def un(travail):
            source, terme = travail
            try:
                return list(source.chercher(terme))
            except SourceUnavailable as exc:
                log.info("Recherche indisponible sur %s : %s", source.id, exc)
            except Exception:
                log.exception("Recherche en echec sur %s", source.id)
            if muettes is not None:
                muettes.add(source.label)
            return []
        debut = time.time()
        with ThreadPoolExecutor(max_workers=min(8, len(travaux))) as ensemble:
            lots = list(ensemble.map(un, travaux))
        for source in self.sources:
            self._memoriser_articles(source)
        log.info("Recherche « %s » : %d offres de %d source(s) en %.1f s", " | ".join(termes),
                 sum(len(l) for l in lots), len(self.sources), time.time() - debut)
        return [o for lot in lots for o in lot]

    def sources_muettes(self, terme: str) -> list[str]:
        """Les boutiques qui n'ont pas repondu a la derniere recherche de
        `terme` (Steam en maintenance, coupure...). « Aucune boutique ne vend
        ce jeu » serait faux : il faut pouvoir dire « Steam n'a pas repondu »."""
        return list(getattr(self, "_muettes", {}).get((terme or "").strip(), ()))

    def _memoriser_articles(self, source) -> None:
        """Les fiches que la recherche Steam vient de lire rejoignent la
        memoire : elles ne seront pas redemandees une a une."""
        recus = getattr(source, "articles_recus", None) or {}
        if recus:
            source.articles_recus = {}          # lus une fois
        manquants = MEMO.manquants(recus) if recus else []
        if not manquants or not CONFIG.get("boutique.fiches_detaillees", True):
            return
        from .plugins.boutique import steam
        try:
            if not self._etiquettes:
                self._etiquettes = steam.noms_etiquettes()
            MEMO.ajouter({a: steam.lire_item(recus[a], self._etiquettes) for a in manquants})
        except SourceUnavailable as exc:
            log.info("%s", exc)                 # `enrichir` reessaiera
        except Exception:
            log.exception("Fiches de la recherche Steam illisibles")

    def chercher(self, terme: str) -> list[Fiche]:
        """Tous les jeux correspondant a `terme`, sur toutes les sources.

        Une boutique ne comprend que ce qu'elle a dans ses titres. ORION lui
        pose donc aussi la question autrement, et note chaque jeu sur la
        meilleure lecture :
          - sigle de serie developpe : « bo3 » -> « black ops 3 » ;
          - sans le dernier mot, quand presque rien ne sort : « F1 202 » ->
            « F1 » (saisie en cours, ou numero que la boutique ecrit « 25 »).
        """
        terme = (terme or "").strip()
        if not terme:
            return []
        self._terme_voulu = terme           # une recherche plus recente annule celle-ci
        variantes = recherche.variantes(terme)
        # un sigle seul (« bo3 », « bf3 ») ne dit rien a une boutique : seule sa
        # forme developpee lui est posee. Le sigle sert toujours a noter.
        muettes: set[str] = set()
        offres = self._offres_recherche(recherche.termes_a_poser(terme), muettes)
        if getattr(self, "_muettes", None) is None or len(self._muettes) > 50:
            self._muettes = {}
        self._muettes[terme] = sorted(muettes)

        def trouver() -> list[Fiche]:
            # le catalogue deja releve complete les resultats (gratuits, ITAD)
            pool = list(offres)
            for f in self.fiches:
                if recherche.note_variantes(variantes, f.titre) >= recherche.SEUIL:
                    pool += f.offres
            from .suggestions import notoriete
            return recherche.classer_variantes(variantes, fusionner(pool),
                                               cle=lambda f: f.titre, seuil=self.SEUIL_RECHERCHE,
                                               departage=notoriete)

        fiches = trouver()
        # lecture raccourcie : voir `recherche.faut_raccourcir`
        vues = visibles(fiches)
        meilleure = recherche.note_variantes(variantes, vues[0].titre) if vues else 0.0
        if recherche.faut_raccourcir(terme, len(vues), meilleure) \
                and self._terme_voulu == terme:
            suite = recherche.variantes(terme, raccourcie=True)[len(variantes):]
            if suite:
                variantes += suite
                offres += self._offres_recherche([v for v, _ in suite])
                fiches = trouver()
        if self._terme_voulu != terme:
            return []                       # le joueur a deja tape autre chose
        from . import prix_gamesplanet
        prix_gamesplanet.completer(fiches)
        # rien de lent ici : les fiches Steam viennent de la recherche, les
        # plus bas historiques deja connus sont poses, les autres sont
        # releves ensuite (`plus_bas_des_resultats`), sans retarder l'affichage
        self.appliquer_plus_bas(fiches)
        return visibles(fiches)

    # -- « dans le meme esprit » --------------------------------------------
    #: une graine n'est prise que si Steam vend bien CE jeu
    GRAINE_SURE = 0.8
    #: duree de garde d'une reponse « meme esprit », en secondes
    ESPRIT_GARDE = 1800
    #: etiquettes d'un jeu retire de la vente qui servent a trouver ses proches
    ETIQUETTES_PROCHES = 3

    def dans_l_esprit(self, terme: str, sans_resultat: bool = False) -> dict | None:
        """Quand la recherche ne peut pas donner le jeu : pourquoi, et des
        jeux PC du meme esprit avec leurs prix (voir `orion.esprit`).

        Rend {"terme", "nom", "raison", "ou", "fiches", "origine"} ou None.
        `sans_resultat` : la recherche n'a rien trouve ; les etages 2 (jeu
        retire de la vente) et 3 (service d'ORION) ne servent que dans ce
        cas. La table, elle, repond toujours (« pokemon », « fortnite »).
        Jamais bloquant."""
        from . import esprit
        terme = (terme or "").strip()
        if not terme or not CONFIG.get("boutique.meme_esprit", True):
            return None
        debut = time.time()
        # la meme question dans la demi-heure : meme reponse, sans rien
        # redemander (le joueur efface, retape, revient)
        garde = getattr(self, "_esprits", None)
        if garde is None:
            garde = self._esprits = {}
        cle = recherche.normaliser(terme)
        connu = garde.get(cle)
        if connu and debut - connu[0] < self.ESPRIT_GARDE \
                and (sans_resultat or connu[1]["origine"] == "table"):
            return dict(connu[1], terme=terme)
        piste, origine = esprit.chercher_piste(terme), "table"
        if piste is None and sans_resultat:
            piste, origine = self._piste_retiree(terme), "retire"
        if piste is None and sans_resultat:
            piste, origine = esprit.demander(terme), "service"
        if piste is None:
            return None
        try:
            fiches = self._fiches_esprit(piste)
        except Exception:
            log.exception("Jeux du meme esprit en echec pour « %s »", terme)
            fiches = []
        log.info("Meme esprit « %s » (%s) : %d jeux en %.1f s", terme, origine, len(fiches),
                 time.time() - debut)
        if not fiches and piste.ou is None:
            return None
        resultat = {"terme": terme, "nom": piste.nom, "raison": piste.raison, "ou": piste.ou,
                    "fiches": fiches, "origine": origine}
        if fiches:                          # une reponse vide (Steam muet) n'est pas gardee
            if len(garde) > 60:
                garde.clear()
            garde[cle] = (debut, resultat)
        return resultat

    def _piste_retiree(self, terme: str):
        """Etage 2 : la recherche a croise sur Steam un jeu fiche mais sans
        prix (retire de la vente) qui porte ce nom. Ses etiquettes les plus
        fortes decrivent ses proches."""
        from . import esprit
        source = self.source("steam")
        sans_prix = getattr(source, "sans_prix", None) or {}
        lectures = recherche.variantes(terme)
        meilleur, note_max = None, 0.9
        for it in sans_prix.values():
            note = recherche.note_variantes(lectures, str(it.get("name") or ""))
            if note >= note_max:
                meilleur, note_max = it, note
        if meilleur is None:
            return None
        tags = sorted(meilleur.get("tags") or [], key=lambda t: -int(t.get("weight") or 0))
        ids = [int(t["tagid"]) for t in tags if str(t.get("tagid", "")).isdigit()]
        if not ids:
            return None
        nom = " ".join(str(meilleur.get("name") or "").split())
        return esprit.Piste(f"« {nom} » n'est plus en vente.", (),
                            tuple(ids[:self.ETIQUETTES_PROCHES]), None, nom)

    def _fiches_esprit(self, piste) -> list[Fiche]:
        """Les jeux d'une piste, tels que Steam les vend aujourd'hui : les
        graines d'abord (dans l'ordre choisi), puis les jeux les plus en vue
        qui portent ses etiquettes. Un titre que Steam ne vend pas n'apparait
        pas."""
        from concurrent.futures import ThreadPoolExecutor
        from . import esprit, prix_gamesplanet
        from .plugins.boutique import steam
        try:
            if not self._etiquettes:
                self._etiquettes = steam.noms_etiquettes()
        except SourceUnavailable as exc:
            log.info("%s", exc)
        details: dict[str, dict] = {}

        def graine(titre: str):
            try:
                items = steam.suggestions(titre, 6)
            except SourceUnavailable as exc:
                log.debug("%s", exc)
                return None
            for it in items:
                o = steam.offre_item(it)
                if o is not None and recherche.proximite(titre, o.titre) >= self.GRAINE_SURE:
                    fiche = steam.lire_item(it, self._etiquettes or None)
                    o.adulte = bool(fiche.get("adulte"))
                    if self._etiquettes:
                        details[o.steam_appid] = fiche
                    return o
            return None

        def proches():
            noms = [e for e in piste.etiquettes if not isinstance(e, int)]
            ids = [e for e in piste.etiquettes if isinstance(e, int)]
            if noms:
                connues = steam.etiquettes_anglaises()
                inconnues = [n for n in noms if n.lower() not in connues]
                if inconnues:
                    log.info("Etiquettes Steam inconnues, ignorees : %s", ", ".join(inconnues))
                ids += [connues[n.lower()] for n in noms if n.lower() in connues]
            if not ids:
                return []
            recues, fiches, _total = steam.page_magasin(
                "", 0, 40, self._etiquettes or None, tagids=ids, sans=steam.ETIQUETTES_ADULTES)
            details.update(fiches)
            return recues

        offres: list[Offre] = []
        with ThreadPoolExecutor(max_workers=8) as ensemble:
            suite = ensemble.submit(proches)
            for o in ensemble.map(graine, piste.graines):
                if o is not None:
                    offres.append(o)
            try:
                offres += suite.result()
            except SourceUnavailable as exc:
                log.info("%s", exc)
            except Exception:
                log.exception("Jeux par etiquettes en echec")
        MEMO.ajouter(details)
        vues: set[str] = set()
        uniques = [o for o in offres if not (o.steam_appid in vues or vues.add(o.steam_appid))]
        fiches = fusionner(uniques)[:esprit.MAXIMUM]
        prix_gamesplanet.completer(fiches)
        self.appliquer_plus_bas(fiches)
        return visibles(fiches)

    def plus_bas_des_resultats(self, fiches: list[Fiche]) -> int:
        """Releve puis pose le plus bas historique des jeux trouves par une
        recherche (deux demandes groupees au plus). Apres l'affichage."""
        self.relever_plus_bas(fiches)
        return self.appliquer_plus_bas(fiches)

    def comparer(self, fiche: Fiche) -> Fiche:
        """Complete une fiche avec les offres de toutes les boutiques."""
        offres: list[Offre] = []
        itad = self.source("itad")
        if itad is not None:
            jeux = {}
            if fiche.itad_id:
                jeux = {fiche.itad_id: {"title": fiche.titre, "assets": {}}}
            else:
                jeux = itad.trouver(fiche.titre, fiche.steam_appid)
            try:
                offres += itad.prix(jeux)
            except SourceUnavailable as exc:
                log.info("%s", exc)
        cible = sans_bruit(fiche.titre)
        for s in self.sources:
            if s.id == "itad":
                continue
            try:
                offres += [o for o in s.chercher(fiche.titre)
                           if sans_bruit(o.titre) == cible
                           or (o.steam_appid and o.steam_appid == fiche.steam_appid)]
            except Exception:
                log.debug("Comparaison partielle sur %s", s.id)
        for o in offres:
            if o.titre and sans_bruit(o.titre) != cible and not (
                    o.steam_appid and o.steam_appid == fiche.steam_appid):
                o.titre = fiche.titre     # meme jeu, nom de lot different
            fiche.ajouter(o)
        # apres le comparateur : notre offre Gamesplanet remplace la sienne
        from . import prix_gamesplanet
        prix_gamesplanet.completer([fiche])
        self.enregistrer()
        return fiche

    # -- fiches detaillees ---------------------------------------------
    def enrichir(self, appids, limite: int = 600) -> int:
        """Etiquettes, avis, studios et visuels des jeux Steam encore inconnus.

        Un appel pour 100 jeux, garde 14 jours : quelques appels suffisent
        pour toute la vitrine et la bibliotheque. Jamais bloquant : une
        erreur laisse simplement les fiches sans details."""
        if not CONFIG.get("boutique.fiches_detaillees", True):
            return 0
        manquants = MEMO.manquants(a for a in appids if a)[:limite]
        if not manquants:
            return 0
        from .plugins.boutique import steam
        try:
            if not self._etiquettes:
                self._etiquettes = steam.noms_etiquettes()
        except SourceUnavailable as exc:
            log.info("%s", exc)
        try:
            recues = steam.details(manquants, self._etiquettes)
        except SourceUnavailable as exc:
            log.info("%s", exc)
            return 0
        except Exception:
            log.exception("Fiches Steam detaillees en echec")
            return 0
        # un jeu sans fiche n'est pas redemande avant 14 jours
        for a in manquants:
            recues.setdefault(a, {"absent": True})
        MEMO.ajouter(recues)
        return len(recues)

    # -- images --------------------------------------------------------
    def vignettes(self, fiches: list[Fiche], limite: int = 60) -> int:
        """Telecharge les images manquantes des fiches affichees."""
        from .plugins.artwork.base import download
        IMAGES.mkdir(parents=True, exist_ok=True)
        n = 0
        for f in fiches[:limite]:
            if f.image_locale or not f.image:
                continue
            cible = IMAGES / (hashlib.sha1(f.image.encode()).hexdigest()[:16] + ".jpg")
            try:
                if cible.exists() or download(f.image, cible):
                    f.image_locale = str(cible)
                    n += 1
            except Exception:
                log.debug("Image boutique indisponible : %s", f.image)
        if n:
            self.enregistrer()
        return n
