"""Prix et evaluations Steam : aucune cle d'API necessaire.

C'est la source de base d'ORION : elle fonctionne pour tout jeu presente sur
Steam, meme si la copie installee vient d'ailleurs, puisque l'identifiant
Steam est retrouve a partir du titre par le module de jaquettes.
"""
from __future__ import annotations

from orion.core import region

import time

from ...core.logging_setup import get
from ...core.models import Game
from .base import MarketInfo, MarketProvider, Offer

log = get("market.steam")

DETAILS = "https://store.steampowered.com/api/appdetails"
REVIEWS = "https://store.steampowered.com/appreviews/{appid}"
STORE = "https://store.steampowered.com/app/{appid}"
NEWS = "https://api.steampowered.com/ISteamNews/GetNewsForApp/v2/"

from ...core.steam_limite import NAVIGATEUR as HEADERS  # noqa: E402


def texte_lisible(brut: str) -> str:
    """Actualite Steam (BBCode ou HTML) -> texte avec paragraphes et puces."""
    import html
    import re
    t = html.unescape(brut or "")
    t = re.sub(r"\[img[^\]]*\].*?\[/img\]", "", t, flags=re.I | re.S)
    t = re.sub(r"\{STEAM_CLAN_IMAGE\}[^\s\[<]*", "", t)
    t = re.sub(r"\[(?:previewyoutube|video)[^\]]*\].*?\[/(?:previewyoutube|video)\]",
               "", t, flags=re.I | re.S)
    t = re.sub(r"\[\*\]|<li[^>]*>", "\n• ", t, flags=re.I)
    t = re.sub(r"\[/?(?:p|h\d|list|olist|hr|br|quote|table|tr)[^\]]*\]", "\n", t,
               flags=re.I)
    t = re.sub(r"<(?:br|/?p|/?h\d|/?ul|/?ol|/?div|hr)[^>]*>", "\n", t, flags=re.I)
    t = re.sub(r"\[/?[^\]\n]{1,40}\]", "", t)               # autres balises BBCode
    t = re.sub(r"<[^>]+>", "", t)                               # autres balises HTML
    t = re.sub(r"https?://\S+", "", t)
    t = re.sub(r"[ \t\u00a0]+", " ", t)
    t = re.sub(r" *\n *", "\n", t)
    t = re.sub(r"\n{3,}", "\n\n", t)
    t = re.sub(r"(?:\n• *(?=\n|$))+", "", t)                    # puces vides
    return t.strip()


def steam_appid(game: Game) -> str:
    """Identifiant Steam du jeu, s'il est connu (y compris via le registre)."""
    from ...core.liens import appid_steam
    return appid_steam(game)


class SteamStoreProvider(MarketProvider):
    id = "steam_store"
    label = "Steam"
    priority = 80

    filtre_adulte = "descripteur de contenu n° 3 et etiquettes de la fiche Steam"

    #: captures d'ecran : seule source publique sans cle, la fiche Steam.
    #: SteamGridDB n'en a pas, IGDB demande une cle, et les images des pages
    #: d'editeurs (og:image, galeries) ne sont ni stables ni fiables : un jeu
    #: absent de Steam n'a donc pas de captures, et la fiche le dit.
    SANS_CAPTURES = "Captures indisponibles : jeu absent de Steam."
    FICHE_SANS_CAPTURES = "Captures indisponibles : la fiche Steam de ce jeu n'en a pas."

    def fetch(self, game: Game, info: MarketInfo) -> None:
        appid = steam_appid(game) or self._retrouver_appid(game)
        if not appid:
            if game.extra.get(self.MARQUEUR):
                info.captures_note = self.SANS_CAPTURES
            else:                                # recherche pas encore faite
                info.incomplet = True
            return
        self._details(appid, info)
        self._reviews(appid, info)
        self._news(appid, info)
        if self.id in info.sources and not info.screenshots and not info.adulte:
            info.captures_note = self.FICHE_SANS_CAPTURES
        if info.sources:
            info.fetched_at = time.time()

    # ------------------------------------------------------------------
    #: memoire « recherche par le titre deja faite ». La v2 (jusqu'a la
    #: 1.8.1) ratait les titres a ponctuation differente (« RuneScape -
    #: Dragonwilds » / « RuneScape: Dragonwilds ») : les jeux marques v2
    #: sans identifiant sont recherches une fois de plus.
    #: v4 : les editions nommees (« ... – Infernal Edition ») sont reconnues ;
    #: les jeux restes sans fiche Steam sont recherches de nouveau
    MARQUEUR = "steam_lookup_v4"
    ANCIENS_MARQUEURS = ("steam_lookup_v2", "steam_lookup_v3")

    @classmethod
    def _retrouver_appid(cls, game: Game) -> str:
        """Jeu installe hors de Steam (dossier, registre, autre boutique) :
        son identifiant Steam, retrouve par le titre, donne acces aux
        captures, aux avis et aux actualites.

        Le titre est compare lettres et chiffres seulement (ponctuation,
        separateurs, ™ ®, accents, casse, chiffres romains, mentions
        d'edition ignores), puis, en dernier recours, mot a mot avec un seuil
        eleve. Un DLC, une bande originale ou une demo ne correspondent
        jamais, ni un autre numero (« Hades » n'est pas « Hades II »)."""
        from orion.core import reseau
        from ...core import steam_limite
        from ...core.recherche import meilleur_candidat, termes_recherche
        if game.extra.get(cls.MARQUEUR):
            return ""
        appid = ""
        # la recherche des visuels a peut-etre deja trouve la fiche Steam de
        # ce jeu : meme identifiant pour les captures, avis et bandes-annonces
        try:
            from ...core.models import normalize_title
            from ..artwork.steam_cdn import _LOCK, _load_resolved
            with _LOCK:
                connu = str(_load_resolved().get(normalize_title(game.title)) or "")
            if connu.isdigit():
                appid = connu
        except Exception:
            log.debug("Identifiants Steam deja retrouves illisibles", exc_info=True)
        for terme in ([] if appid else termes_recherche(game.title)):
            if steam_limite.en_pause():
                return ""                        # pas de marque : on reessaiera
            try:
                r = reseau.get("https://store.steampowered.com/api/storesearch/",
                               params={"term": terme, "cc": region.cc(), "l": region.langue_steam()},
                               headers=HEADERS, timeout=12)
            except Exception:
                log.debug("Recherche Steam impossible pour %s", game.title)
                return ""
            if r.status_code != 200:                 # 429/403 : `reseau` met en pause
                return ""
            try:
                corps = r.json()
            except Exception:
                corps = None
            if not isinstance(corps, dict):          # corps vide : Steam limite
                steam_limite.signaler_refus()
                return ""
            items = [i for i in corps.get("items") or []
                     if isinstance(i, dict) and i.get("id")
                     and i.get("type") in (None, "app", "game")]
            choix = meilleur_candidat(game.title, items)
            if choix is not None:
                appid = str(choix["id"])
                break
        # resultat memorise, trouve ou non, pour ne pas redemander
        game.extra[cls.MARQUEUR] = True
        for ancien in cls.ANCIENS_MARQUEURS:
            game.extra.pop(ancien, None)
        if appid:
            game.extra["steam_appid"] = appid
            # la fiche vient d'etre trouvee : les visuels notes « absents »
            # sont a redemander tout de suite, pas dans trois jours
            game.extra.pop("art_absent", None)
        return appid

    def _details(self, appid: str, info: MarketInfo) -> None:
        from orion.core import reseau
        from ...core import steam_limite
        data = {}
        if steam_limite.en_pause():
            info.incomplet = True
            return
        # Deux reponses tres differentes sont a distinguer :
        # * « success: false » (HTTP 200) : CE jeu n'a pas de fiche (retire de
        #   la vente, non vendu dans le pays) -> on essaie sans pays, puis on
        #   abandonne pour ce jeu seulement ;
        # * HTTP 429/403 ou corps vide : Steam limite la connexion -> pause
        #   generale, pour ne pas prolonger le blocage.
        for params in ({"cc": region.cc(), "l": region.langue_steam()}, {"l": region.langue_steam()}, {}):
            steam_limite.attendre()
            try:
                r = reseau.get(DETAILS, params={"appids": appid, **params},
                                 headers=HEADERS, timeout=12)
            except Exception as exc:
                log.info("Fiche Steam %s injoignable : %s", appid, exc)
                info.incomplet = True
                return
            try:
                corps = r.json()
            except Exception:
                corps = None
            if r.status_code in (403, 429) or corps is None:
                log.info("Fiche Steam %s : Steam limite les demandes (HTTP %s)",
                         appid, r.status_code)
                steam_limite.signaler_refus()
                info.incomplet = True
                return
            payload = steam_limite.fiche(corps, appid)
            if payload.get("success"):
                data = payload.get("data") or {}
                if params.get("cc") != "fr":
                    log.info("Fiche Steam %s obtenue avec %s", appid, params or "{}")
                break
            log.info("Fiche Steam %s absente avec %s (HTTP %s : %s)", appid,
                     params or "{}", r.status_code, str(corps)[:120])
        if not data:
            # pas de fiche pour ce jeu : inutile de redemander toutes les
            # 10 minutes, le cache normal (12 h) s'applique
            info.sources.append("steam_sans_fiche")
            return

        # la fiche complete nomme les DLC du jeu : retenus pour le panneau
        # des DLC, qui n'aura pas a redemander la fiche
        try:
            from ... import dlc
            dlc.memoriser(appid, data.get("dlc"))
        except Exception:
            pass
        info.title = info.title or data.get("name", "")
        info.free = bool(data.get("is_free"))
        info.release_date = (data.get("release_date") or {}).get("date", "")
        info.developer = ", ".join(data.get("developers") or [])
        info.publisher = ", ".join(data.get("publishers") or [])
        info.genres = [g.get("description", "") for g in data.get("genres") or []]
        info.categories = [int(c["id"]) for c in data.get("categories") or []
                           if str(c.get("id", "")).isdigit()]
        # jeu reserve aux adultes : ni captures ni bandes-annonces
        from ... import contenu_adulte
        adulte = contenu_adulte.fiche_adulte(data)
        contenu_adulte.marquer(appid, adulte)
        info.adulte = info.adulte or adulte
        info.screenshots = [] if info.adulte else \
            self._captures(appid, data.get("screenshots") or [])

        meta = data.get("metacritic") or {}
        if meta.get("score"):
            info.metacritic = int(meta["score"])
            info.metacritic_url = meta.get("url", "")

        price = data.get("price_overview") or {}
        if price:
            currency = price.get("currency", "EUR")
            info.base_price = round(int(price.get("initial", 0)) / 100, 2)
            info.current = Offer(
                shop="Steam",
                price=round(int(price.get("final", 0)) / 100, 2),
                currency=currency,
                cut=int(price.get("discount_percent", 0)),
                url=STORE.format(appid=appid),
                drm="Steam",
            )
        elif info.free:
            info.current = Offer(shop="Steam", price=0.0,
                                 url=STORE.format(appid=appid), drm="Steam")
        info.sources.append(self.id)

    def _reviews(self, appid: str, info: MarketInfo) -> None:
        from orion.core import reseau
        try:
            r = reseau.get(REVIEWS.format(appid=appid),
                             params={"json": 1, "language": "all",
                                     "purchase_type": "all", "num_per_page": 0},
                             headers=HEADERS, timeout=12)
            summary = (r.json() or {}).get("query_summary") or {}
        except Exception:
            log.debug("Avis Steam indisponibles pour %s", appid)
            return

        total = int(summary.get("total_reviews") or 0)
        positive = int(summary.get("total_positive") or 0)
        if total:
            info.review_count = total
            info.review_score = round(positive / total * 100)
            info.review_label = self._translate(
                str(summary.get("review_score_desc") or ""))

    @staticmethod
    def _captures(appid: str, brutes: list, maximum: int = 12) -> list[dict]:
        """Captures d'ecran : vignettes telechargees tout de suite, images
        en grand a la demande (elles pesent plusieurs centaines de Ko)."""
        from ...core.paths import ART_DIR
        from ..artwork.base import download
        dossier = ART_DIR / "captures" / str(appid)
        out: list[dict] = []
        for shot in brutes[:maximum]:
            thumb = shot.get("path_thumbnail") or ""
            full = shot.get("path_full") or thumb
            if not thumb:
                continue
            local = dossier / f"{shot.get('id', len(out))}_mini.jpg"
            try:
                dossier.mkdir(parents=True, exist_ok=True)
                ok = download(thumb, local)
            except Exception:
                ok = False
            out.append({"thumb": thumb, "full": full,
                        "local": str(local) if ok else "",
                        "full_local": str(dossier / f"{shot.get('id', len(out))}.jpg")})
        return out

    def _news(self, appid: str, info: MarketInfo) -> None:
        """Actualites et notes de mise a jour, en entier.

        La traduction est faite plus tard, a l'ouverture de la fiche du jeu
        (voir `MarketService.traduire_actus`).
        """
        from orion.core import reseau
        try:
            r = reseau.get(NEWS, params={"appid": appid, "count": 5,
                                           "maxlength": 0, "format": "json"},
                             headers=HEADERS, timeout=12)
            items = ((r.json() or {}).get("appnews") or {}).get("newsitems") or []
        except Exception:
            log.debug("Actualites Steam indisponibles pour %s", appid)
            return

        for item in items[:5]:
            corps = texte_lisible(str(item.get("contents") or ""))
            info.news.append({
                "title": str(item.get("title") or "").strip(),
                "url": item.get("url", ""),
                "date": int(item.get("date") or 0),
                "source": item.get("feedlabel", ""),
                "body": corps,
                "summary": corps[:320],
            })

    @staticmethod
    def _translate(label: str) -> str:
        table = {
            "Overwhelmingly Positive": "Extremement positives",
            "Very Positive": "Tres positives",
            "Positive": "Positives",
            "Mostly Positive": "Plutot positives",
            "Mixed": "Moyennes",
            "Mostly Negative": "Plutot negatives",
            "Negative": "Negatives",
            "Very Negative": "Tres negatives",
            "Overwhelmingly Negative": "Extremement negatives",
        }
        return table.get(label, label)
