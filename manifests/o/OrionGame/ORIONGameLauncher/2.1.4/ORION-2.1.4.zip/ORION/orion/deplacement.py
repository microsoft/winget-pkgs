"""Deplacer un jeu installe vers un autre disque (1.8).

Methode : copie verifiee puis jonction Windows. Elle marche pour tous les
launchers (Steam, Epic, GOG, Ubisoft, EA...) parce que le jeu reste
visible a son ancien emplacement : une jonction est un raccourci du
systeme de fichiers, transparent pour les programmes.

Etapes, dans cet ordre, sans jamais perdre le jeu :

1. controles : le jeu existe, n'est pas en cours, le disque cible a la
   place (taille du jeu + 5 % + 1 Go de marge), les dossiers concernes
   sont modifiables et aucun reste d'un deplacement precedent ne gene ;
2. copie complete vers `<disque>:\\Jeux ORION\\<dossier>.copie-en-cours` ;
3. verification : memes fichiers, memes tailles, memes dates ; puis le
   jeu d'origine est remesure : s'il a change pendant la copie (launcher
   qui met a jour, partie lancee), on s'arrete ;
4. l'original est renomme (`.ancien-orion`) — ce renommage echoue si un
   programme utilise encore le jeu : on s'arrete alors, rien n'est perdu ;
5. la copie prend son nom definitif et la jonction est creee a l'ancien
   emplacement ; en cas d'echec, retour a l'etat de depart ;
6. seulement ensuite, l'original est supprime. Ce qui n'a pas pu l'etre
   est signale, jamais ignore en silence.

`ramener()` fait le chemin inverse avec les memes garanties (copie vers le
disque d'origine, verification, renommage de la destination pour s'assurer
que rien ne l'utilise, retrait de la jonction, retour arriere si besoin).

Chaque echec leve `DeplacementImpossible`, dont le texte se termine par
l'etat reel du jeu (« Etat du jeu : ... »). `reparer_restes()`, appele au
demarrage, remet en ordre ce qu'un arret brutal aurait laisse.

Depuis la 1.9, l'interface ne propose plus de nouveau deplacement : les
launchers (Steam en tete) ne reconnaissent pas un jeu derriere une
jonction comme un jeu transfere. Elle propose a la place une sauvegarde
sur un autre disque (`orion.sauvegarde_disque`), qui ne touche pas au jeu.
`ramener()` et `reparer_restes()` restent pour les jeux deja deplaces.
`Suivi` (avancement detaille d'une copie) sert aux deux modules.
"""
from __future__ import annotations

import os
import shutil
import stat
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path

from .core.fichiers import existe
from .core.logging_setup import get

log = get("deplacement")

DOSSIER = "Jeux ORION"
MARGE = 1.05
MARGE_FIXE = 1024 ** 3

SUFFIXE_COPIE = ".copie-en-cours"
SUFFIXE_ANCIEN = ".ancien-orion"
SUFFIXE_RETOUR = ".retour-en-cours"

#: ecart de date tolere entre un fichier et sa copie (FAT/exFAT : 2 s)
TOLERANCE_NS = 2_000_000_000

#: debut de la phrase qui decrit l'etat du jeu apres un echec
ETAT = "Etat du jeu :"


class DeplacementImpossible(Exception):
    """Echec d'un deplacement ; `etat` dit ou se trouve le jeu maintenant."""

    def __init__(self, message: str, etat: str = "") -> None:
        super().__init__(message)
        self.message = message
        self.etat = etat

    def __str__(self) -> str:
        return f"{self.message}\n\n{self.etat}" if self.etat else self.message


@dataclass
class Bilan:
    fichiers: int = 0
    octets: int = 0
    #: chemin relatif -> (taille, date de modification en ns)
    details: dict = field(default_factory=dict)


def mesurer(dossier: Path) -> Bilan:
    b = Bilan()
    dossier = str(dossier)
    for racine, _dossiers, fichiers in os.walk(dossier):
        for f in fichiers:
            chemin = os.path.join(racine, f)
            try:
                st = os.stat(chemin)
            except OSError:
                continue
            b.octets += st.st_size
            b.fichiers += 1
            b.details[os.path.relpath(chemin, dossier)] = (st.st_size, st.st_mtime_ns)
    return b


def est_jonction(chemin: Path) -> bool:
    try:
        if sys.platform.startswith("win"):
            return os.path.isjunction(chemin) if hasattr(os.path, "isjunction") \
                else bool(os.readlink(chemin))
        return Path(chemin).is_symlink()
    except OSError:
        return False


def creer_lien(cible: Path, lien: Path) -> None:
    """Jonction Windows (sans droits administrateur) ; lien symbolique ailleurs."""
    if sys.platform.startswith("win"):
        import _winapi
        _winapi.CreateJunction(str(cible), str(lien))
    else:
        os.symlink(cible, lien, target_is_directory=True)


def retirer_lien(lien: Path) -> None:
    if sys.platform.startswith("win"):
        os.rmdir(lien)                 # retire la jonction, pas son contenu
    else:
        os.unlink(lien)


def espace_libre(chemin: Path) -> int:
    racine = Path(chemin.anchor or chemin)
    return shutil.disk_usage(racine).free


def destination(install_dir: Path, disque: str) -> Path:
    """`disque` : « D: », « E:\\ »... ou un dossier racine (tests)."""
    d = disque.rstrip("\\/")
    racine = Path(d + "\\") if len(d) == 2 and d[1] == ":" else Path(d)
    return racine / DOSSIER / install_dir.name


# ----------------------------------------------------------------------
# outils
# ----------------------------------------------------------------------
def _detail(exc: BaseException) -> str:
    """Erreur systeme lisible, avec son code (errno ou code Windows)."""
    code = getattr(exc, "winerror", None) or getattr(exc, "errno", None)
    texte = getattr(exc, "strerror", None) or str(exc) or type(exc).__name__
    return f"[{code}] {texte}" if code else texte


def _normal(chemin) -> str:
    return os.path.normcase(os.path.normpath(os.path.abspath(str(chemin))))


def _meme_chemin(a, b) -> bool:
    return bool(a) and bool(b) and _normal(a) == _normal(b)


def _meme_dossier(a, b) -> bool:
    """Meme dossier sur le disque (suit les jonctions ; tolere les lecteurs
    montes dans un dossier ou `subst`, ou les chemins ecrits different)."""
    if not a or not b:
        return False
    try:
        return os.path.samefile(a, b)
    except OSError:
        return _meme_chemin(os.path.realpath(a), os.path.realpath(b))


def _etat_intact(chemin: Path) -> str:
    return f"{ETAT} intact a son emplacement d'origine ({chemin})."


def _supprimer(chemin: Path) -> list[str]:
    """Supprime un dossier d'ORION ; rend ce qui n'a pas pu l'etre (jamais
    d'echec silencieux). Une jonction est retiree sans toucher sa cible."""
    chemin = Path(chemin)
    if est_jonction(chemin):
        try:
            retirer_lien(chemin)
            return []
        except OSError as exc:
            return [f"{chemin} : {_detail(exc)}"]
    if not chemin.exists():
        return []
    erreurs: list[str] = []

    def gerer(fonction, cible, exc) -> None:
        # fichiers en lecture seule (frequents dans les jeux) : on retire
        # l'attribut puis on reessaie une fois
        try:
            os.chmod(cible, stat.S_IWRITE | stat.S_IREAD)
            fonction(cible)
        except Exception as exc2:                  # noqa: BLE001
            erreurs.append(f"{cible} : {_detail(exc2)}")

    if sys.version_info >= (3, 12):
        shutil.rmtree(chemin, onexc=gerer)
    else:
        shutil.rmtree(chemin, onerror=lambda f, c, info: gerer(f, c, info[1]))
    if chemin.exists() and not erreurs:
        erreurs.append(f"{chemin} : non supprime")
    for e in erreurs[:20]:
        log.warning("Suppression incomplete : %s", e)
    return erreurs


def _dossier_modifiable(dossier: Path, etat: str) -> None:
    """Verifie avant la copie qu'ORION pourra renommer et creer dans ce
    dossier (Program Files, WindowsApps... demandent des droits)."""
    essai = Path(dossier) / f".orion-essai-{os.getpid()}"
    try:
        essai.mkdir()
        essai.rmdir()
    except OSError as exc:
        raise DeplacementImpossible(
            f"ORION ne peut pas modifier « {dossier} » ({_detail(exc)}) : dossier "
            "protege (Program Files, WindowsApps...) ou droits insuffisants", etat) from exc


def _abandonner(temp: Path, message: str, etat: str) -> None:
    """Supprime la copie de travail puis leve l'erreur (le jeu n'a pas bouge)."""
    restes = _supprimer(temp)
    if restes:
        message += (f"\nLa copie partielle « {temp} » n'a pas pu etre supprimee "
                    f"entierement ({len(restes)} element(s)) : supprimez-la a la main.")
    raise DeplacementImpossible(message, etat)


def _ecarts(reference: Bilan, autre: Bilan, tolerance_ns: int) -> list[str]:
    if not reference.details or not autre.details:
        # mesure sans detail : on s'en tient aux totaux
        if (reference.fichiers, reference.octets) == (autre.fichiers, autre.octets):
            return []
        return ["totaux differents"]
    ecarts = []
    for rel, (taille, date) in reference.details.items():
        vu = autre.details.get(rel)
        if vu is None:
            ecarts.append(f"{rel} manquant")
        elif vu[0] != taille:
            ecarts.append(f"{rel} : taille differente")
        elif abs(vu[1] - date) > tolerance_ns:
            ecarts.append(f"{rel} : date differente")
    for rel in sorted(autre.details.keys() - reference.details.keys()):
        ecarts.append(f"{rel} en trop")
    return ecarts


def _verifier(reference: Bilan, autre: Bilan, temp: Path, etat: str,
              message: str, tolerance_ns: int) -> None:
    if (autre.fichiers, autre.octets) != (reference.fichiers, reference.octets):
        _abandonner(temp, f"{message} ({autre.fichiers}/{reference.fichiers} fichiers)",
                    etat)
    ecarts = _ecarts(reference, autre, tolerance_ns)
    if ecarts:
        exemples = ", ".join(ecarts[:3]) + (" ..." if len(ecarts) > 3 else "")
        _abandonner(temp, f"{message} : {len(ecarts)} fichier(s) different(s) ({exemples})",
                    etat)


def _vider_temp(temp: Path, etat: str) -> None:
    """Copie de travail laissee par une tentative precedente : on repart de zero."""
    if temp.exists() or est_jonction(temp):
        restes = _supprimer(temp)
        if restes:
            raise DeplacementImpossible(
                f"une copie d'une tentative precedente (« {temp} ») n'a pas pu etre "
                "supprimee : supprimez-la a la main puis reessayez", etat)


def _signaler(restes: list | None, note: str) -> None:
    log.warning(note)
    if restes is not None:
        restes.append(note)


# ----------------------------------------------------------------------
# aller
# ----------------------------------------------------------------------
def verifier_possible(install_dir: Path, disque: str) -> tuple[Path, Bilan]:
    src = Path(install_dir)
    etat = _etat_intact(src)
    if not src.is_dir():
        raise DeplacementImpossible("dossier du jeu introuvable", f"{ETAT} introuvable ({src}).")
    if est_jonction(src):
        raise DeplacementImpossible("ce jeu a deja ete deplace par ORION : "
                                    "ramenez-le d'abord", f"{ETAT} inchange.")
    dst = destination(src, disque)
    lettre = lambda p: p.anchor[:2].upper() if p.anchor[1:2] == ":" else ""  # noqa: E731
    if lettre(src) and lettre(src) == lettre(dst):
        raise DeplacementImpossible("le jeu est deja sur ce disque", etat)
    if dst.exists() or est_jonction(dst):
        raise DeplacementImpossible(f"« {dst} » existe deja", etat)
    ancien = src.with_name(src.name + SUFFIXE_ANCIEN)
    if ancien.exists() or est_jonction(ancien):
        raise DeplacementImpossible(
            f"« {ancien} » existe deja (reste d'un deplacement precedent) : verifiez "
            "son contenu puis supprimez-le avant de reessayer", etat)
    _dossier_modifiable(src.parent, etat)
    bilan = mesurer(src)
    besoin = int(bilan.octets * MARGE) + MARGE_FIXE
    try:
        dst.parent.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise DeplacementImpossible(
            f"impossible de creer « {dst.parent} » ({_detail(exc)})", etat) from exc
    _dossier_modifiable(dst.parent, etat)
    libre = espace_libre(dst.parent)
    if libre < besoin:
        raise DeplacementImpossible(
            f"place insuffisante : {besoin / 1024**3:.1f} Go necessaires, "
            f"{libre / 1024**3:.1f} Go libres", etat)
    return dst, bilan


def taille_lisible(octets: float) -> str:
    """« 48,2 Go », « 730 Mo », « 12 Ko » (virgule decimale, a la francaise)."""
    octets = max(0.0, float(octets or 0))
    for unite, valeur in (("To", 1024 ** 4), ("Go", 1024 ** 3), ("Mo", 1024 ** 2)):
        if octets >= valeur:
            nombre = octets / valeur
            texte = f"{nombre:.1f}" if nombre < 100 else f"{nombre:.0f}"
            return f"{texte.replace('.', ',')} {unite}"
    return f"{octets / 1024:.0f} Ko"


def duree_lisible(secondes: float) -> str:
    """« 42 s », « 6 min 12 s », « 1 h 05 min »."""
    s = max(0, int(round(secondes or 0)))
    if s < 60:
        return f"{s} s"
    if s < 3600:
        return f"{s // 60} min {s % 60:02d} s"
    return f"{s // 3600} h {(s % 3600) // 60:02d} min"


class Suivi:
    """Avancement d'une copie : pourcentage, taille copiee, temps restant
    estime et fichier en cours, transmis par `progression(message, %)`.

    Le message tient sur deux lignes : « 12,4 Go sur 48,0 Go · environ
    6 min restantes », puis le fichier en cours. Les envois sont espaces
    (`PAS` secondes) : l'interface n'a pas a redessiner mille fois par
    seconde.
    """

    PAS = 0.25

    def __init__(self, total: int, progression=None) -> None:
        self.total = max(int(total or 0), 0)
        self.progression = progression
        self.fait = 0
        self.courant = ""
        self.debut = time.monotonic()
        self._dernier = 0.0

    def fichier(self, rel: str) -> None:
        self.courant = rel
        self._envoyer()

    def ajouter(self, octets: int) -> None:
        self.fait += int(octets)
        self._envoyer()

    @property
    def pourcent(self) -> int:
        return min(99, int(self.fait * 100 / max(self.total, 1)))

    def restant(self) -> str:
        ecoule = time.monotonic() - self.debut
        if ecoule < 2 or self.fait <= 0:
            return "calcul du temps restant..."
        vitesse = self.fait / ecoule
        reste = max(0, self.total - self.fait) / max(vitesse, 1)
        if reste < 5:
            return "quelques secondes restantes"
        if reste < 60:
            return f"environ {int(round(reste / 5) * 5)} s restantes"
        return f"environ {duree_lisible(reste)} restantes"

    def message(self) -> str:
        ligne = (f"{taille_lisible(self.fait)} sur {taille_lisible(self.total)}"
                 f"  ·  {self.restant()}")
        return f"{ligne}\n{self.courant}" if self.courant else ligne

    def _envoyer(self, force: bool = False) -> None:
        if not self.progression:
            return
        maintenant = time.monotonic()
        if force or maintenant - self._dernier >= self.PAS:
            self._dernier = maintenant
            self.progression(self.message(), self.pourcent)


def _copier(src: Path, dst: Path, total: int, progression) -> None:
    suivi = Suivi(total, progression)

    def copier(a, b):
        suivi.fichier(os.path.relpath(a, src))
        shutil.copy2(a, b)
        try:
            suivi.ajouter(os.path.getsize(b))
        except OSError:
            pass
    shutil.copytree(src, dst, copy_function=copier, symlinks=True)


_MSG_UTILISE = ("le jeu est encore utilise ou verrouille (jeu, launcher ou antivirus "
                "ouvert ?) : fermez-le puis reessayez")


def deplacer(install_dir: str, disque: str, progress_cb=None,
             restes: list | None = None) -> str:
    """Deplace le jeu ; rend son nouvel emplacement reel.

    `restes` (liste) recoit ce qui n'a pas pu etre nettoye apres un
    deplacement reussi (ancien dossier partiellement supprime...).
    """
    src = Path(install_dir)
    dst, bilan = verifier_possible(src, disque)
    etat = _etat_intact(src)
    temp = dst.with_name(dst.name + SUFFIXE_COPIE)
    ancien = src.with_name(src.name + SUFFIXE_ANCIEN)
    _vider_temp(temp, etat)
    log.info("Deplacement de %s vers %s (%d fichiers, %.1f Go)", src, dst,
             bilan.fichiers, bilan.octets / 1024 ** 3)
    try:
        _copier(src, temp, bilan.octets, progress_cb)
    except Exception as exc:
        log.warning("Copie impossible : %s", exc)
        _abandonner(temp, f"copie impossible : {_detail(exc)}", etat)

    if progress_cb:
        progress_cb("Verification de la copie", 100)
    _verifier(bilan, mesurer(temp), temp, etat, "copie incomplete ou differente",
              TOLERANCE_NS)
    # le jeu a-t-il change pendant la copie (mise a jour, partie lancee) ?
    _verifier(bilan, mesurer(src), temp, etat,
              "le jeu a ete modifie pendant la copie (launcher ou jeu ouvert ?) : "
              "reessayez une fois tout ferme", 0)

    try:
        src.rename(ancien)
    except OSError as exc:
        _abandonner(temp, f"{_MSG_UTILISE} — detail : {_detail(exc)}", etat)

    try:
        temp.rename(dst)
        creer_lien(dst, src)
        if not _meme_dossier(src, dst):
            raise OSError(f"la jonction ne mene pas a « {dst} »")
    except Exception as exc:
        log.exception("Mise en place impossible, retour en arriere")
        _annuler_aller(src, ancien, dst, temp, exc)

    fin = _supprimer(ancien)
    if fin:
        _signaler(restes, f"L'ancien dossier « {ancien} » n'a pas pu etre supprime "
                          f"entierement ({len(fin)} element(s)). Le jeu fonctionne depuis "
                          f"« {dst} » ; supprimez ce dossier a la main pour recuperer la place.")
    log.info("Jeu deplace : %s -> %s", src, dst)
    return str(dst)


def _annuler_aller(src: Path, ancien: Path, dst: Path, temp: Path, exc) -> None:
    """Remet l'original a sa place apres un echec de la bascule ; leve toujours."""
    try:
        if est_jonction(src):
            retirer_lien(src)
        elif src.exists():
            src.rmdir()                  # dossier vide laisse par une jonction ratee
        ancien.rename(src)
    except OSError as exc2:
        copie = temp if temp.exists() else dst
        raise DeplacementImpossible(
            f"mise en place impossible ({_detail(exc)}), puis retour en arriere "
            f"impossible ({_detail(exc2)})",
            f"{ETAT} A REPARER — le jeu complet se trouve dans « {ancien} » (une copie "
            f"verifiee est aussi dans « {copie} »). Renommez « {ancien.name} » en "
            f"« {src.name} » pour le retrouver.") from exc
    # la copie n'a servi a rien : on la retire (temp si le renommage n'a pas eu lieu)
    copie = temp if temp.exists() else dst
    _abandonner(copie, f"mise en place impossible : {_detail(exc)}", _etat_intact(src))


# ----------------------------------------------------------------------
# retour
# ----------------------------------------------------------------------
def ramener(install_dir: str, progress_cb=None, attendu: str = "",
            restes: list | None = None) -> None:
    """Ramene un jeu deplace par ORION a son emplacement d'origine.

    `attendu` : destination enregistree lors du deplacement ; la jonction
    doit y mener, sinon rien n'est fait (on ne supprime jamais un dossier
    qu'ORION n'a pas cree).
    """
    lien = Path(install_dir)
    if not est_jonction(lien):
        raise DeplacementImpossible("ce jeu n'a pas ete deplace par ORION (aucune "
                                    "jonction a son emplacement)", f"{ETAT} inchange.")
    reel = Path(os.path.realpath(lien))
    etat = (f"{ETAT} inchange — toujours sur « {reel} », accessible a son emplacement "
            f"habituel ({lien}).")
    if attendu and not _meme_dossier(reel, attendu):
        raise DeplacementImpossible(
            f"la jonction mene a « {reel} » et non a « {attendu} » enregistre par ORION : "
            "par securite, rien n'est fait", etat)
    if reel.parent.name != DOSSIER or _meme_chemin(reel, lien):
        raise DeplacementImpossible(
            f"« {reel} » n'est pas dans un dossier « {DOSSIER} » : ce n'est pas un "
            "deplacement fait par ORION, rien n'est fait", etat)
    if not reel.is_dir():
        raise DeplacementImpossible(f"« {reel} » est introuvable (disque debranche ?)",
                                    f"{ETAT} inaccessible tant que ce disque manque.")
    ancien = reel.with_name(reel.name + SUFFIXE_ANCIEN)
    if ancien.exists() or est_jonction(ancien):
        raise DeplacementImpossible(
            f"« {ancien} » existe deja (reste d'une operation precedente) : verifiez "
            "son contenu puis supprimez-le avant de reessayer", etat)
    _dossier_modifiable(lien.parent, etat)
    _dossier_modifiable(reel.parent, etat)

    bilan = mesurer(reel)
    besoin = int(bilan.octets * MARGE) + MARGE_FIXE
    if espace_libre(lien.parent) < besoin:
        raise DeplacementImpossible("place insuffisante sur le disque d'origine", etat)
    temp = lien.with_name(lien.name + SUFFIXE_RETOUR)
    _vider_temp(temp, etat)
    log.info("Retour de %s vers %s (%d fichiers)", reel, lien, bilan.fichiers)
    try:
        _copier(reel, temp, bilan.octets, progress_cb)
    except Exception as exc:
        log.warning("Copie impossible : %s", exc)
        _abandonner(temp, f"copie impossible : {_detail(exc)}", etat)
    if progress_cb:
        progress_cb("Verification de la copie", 100)
    _verifier(bilan, mesurer(temp), temp, etat, "copie incomplete ou differente",
              TOLERANCE_NS)
    _verifier(bilan, mesurer(reel), temp, etat,
              "le jeu a ete modifie pendant la copie (launcher ou jeu ouvert ?) : "
              "reessayez une fois tout ferme", 0)

    # comme a l'aller : le renommage echoue si un programme utilise le jeu
    try:
        reel.rename(ancien)
    except OSError as exc:
        _abandonner(temp, f"{_MSG_UTILISE} — detail : {_detail(exc)}", etat)

    try:
        retirer_lien(lien)
        temp.rename(lien)
    except Exception as exc:
        log.exception("Retour impossible, retour en arriere")
        _annuler_retour(lien, reel, ancien, temp, exc)

    fin = _supprimer(ancien)
    if fin:
        _signaler(restes, f"Le dossier « {ancien} » n'a pas pu etre supprime entierement "
                          f"({len(fin)} element(s)). Le jeu fonctionne depuis « {lien} » ; "
                          "supprimez ce dossier a la main pour recuperer la place.")
    log.info("Jeu ramene : %s", lien)


def _annuler_retour(lien: Path, reel: Path, ancien: Path, temp: Path, exc) -> None:
    """Remet la destination et la jonction en place ; leve toujours."""
    try:
        if not reel.exists():
            ancien.rename(reel)
        if not est_jonction(lien):
            if lien.exists():
                lien.rmdir()             # dossier vide inattendu
            creer_lien(reel, lien)
    except OSError as exc2:
        raise DeplacementImpossible(
            f"retour impossible ({_detail(exc)}), puis retour en arriere impossible "
            f"({_detail(exc2)})",
            f"{ETAT} A REPARER — une copie complete et verifiee se trouve dans « {temp} » "
            f"(l'original est dans « {ancien if ancien.exists() else reel} »). Renommez "
            f"« {temp.name} » en « {lien.name} » pour retrouver le jeu.") from exc
    _abandonner(temp, f"retour impossible : {_detail(exc)}",
                f"{ETAT} inchange — toujours sur « {reel} », accessible a son "
                f"emplacement habituel ({lien}).")


# ----------------------------------------------------------------------
# remise en ordre au demarrage
# ----------------------------------------------------------------------
@dataclass
class Reparation:
    actions: list[str] = field(default_factory=list)   # remis en ordre par ORION
    restes: list[str] = field(default_factory=list)    # a regler par le joueur
    absents: list[str] = field(default_factory=list)   # jeux sur un disque absent : rien a regler
    modifie: bool = False                              # fiches a enregistrer


def reparer_restes(games, racines=()) -> Reparation:
    """Remet en ordre ce qu'un arret brutal pendant un deplacement a laisse.

    `games` : fiches de la bibliotheque (leur `extra["deplace"]` peut etre
    corrige : enregistrer si `modifie`) ; `racines` : lettres ou racines des
    disques, pour retrouver les copies de travail « Jeux ORION ». L'etat
    retenu est toujours le plus sur : l'original la ou il etait.
    """
    r = Reparation()
    manquants: set[str] = set()
    for g in games:
        if not getattr(g, "install_dir", ""):
            continue
        src = Path(g.install_dir)
        vers = (g.extra.get("deplace") or {}).get("vers") if hasattr(g, "extra") else None
        if est_jonction(src) and not existe(src):
            # jonction vers un disque qui ne repond pas (externe debranche) :
            # rien a reparer, le jeu reviendra avec son disque (15 octobre :
            # `Path.exists()` levait « Fonction incorrecte » et tout s'arretait).
            # Ce n'est pas une copie interrompue : a part (16 octobre, la boite
            # « Copie de jeu interrompue » s'ouvrait a chaque lancement).
            r.absents.append(f"{g.title} : deplace sur « {vers or os.path.realpath(src)} », "
                             "disque absent pour le moment")
            continue
        try:
            _reparer_jeu(g, r)
        except Exception as exc:                  # noqa: BLE001
            log.warning("Remise en ordre impossible : %s (%s)", g.install_dir, _detail(exc))
            r.restes.append(f"{g.title} : verification impossible ({_detail(exc)})")
        if not existe(src) and not est_jonction(src):
            manquants.add(src.name.lower())

    for racine in racines:
        if not racine:
            continue
        base = destination(Path("x"), str(racine)).parent
        try:
            entrees = list(base.iterdir()) if base.is_dir() else []
        except OSError:
            continue
        for d in entrees:
            if d.name.endswith(SUFFIXE_COPIE):
                nom = d.name[:-len(SUFFIXE_COPIE)]
                if nom.lower() in manquants:
                    r.restes.append(f"Copie de travail « {d} » conservee : le jeu "
                                    f"« {nom} » est introuvable a son emplacement.")
                    continue
                fin = _supprimer(d)
                if fin:
                    r.restes.append(f"Copie de travail « {d} » non supprimee : "
                                    "supprimez-la a la main.")
                else:
                    r.actions.append(f"Copie de travail inachevee supprimee : {d}")
            elif d.name.endswith(SUFFIXE_ANCIEN):
                r.restes.append(f"Dossier « {d} » laisse par un deplacement : verifiez-le "
                                "puis supprimez-le.")
    for texte in r.actions:
        log.info("Remise en ordre : %s", texte)
    for texte in r.restes:
        log.warning("A regler : %s", texte)
    return r


def _nettoyer(chemin: Path, r: Reparation, action: str) -> None:
    fin = _supprimer(chemin)
    if fin:
        r.restes.append(f"« {chemin} » n'a pas pu etre supprime ({len(fin)} element(s)) : "
                        "supprimez-le a la main.")
    else:
        r.actions.append(action)


def _reparer_jeu(g, r: Reparation) -> None:
    src = Path(g.install_dir)
    titre = getattr(g, "title", src.name)
    ancien = src.with_name(src.name + SUFFIXE_ANCIEN)
    retour = src.with_name(src.name + SUFFIXE_RETOUR)
    info = g.extra.get("deplace") or {}
    vers = Path(info["vers"]) if info.get("vers") else None
    jonction = est_jonction(src)

    # aller interrompu entre le renommage de l'original et la jonction
    if not jonction and not src.exists() and ancien.is_dir():
        ancien.rename(src)
        r.actions.append(f"{titre} : deplacement interrompu, jeu remis a sa place ({src})")
        if info:
            g.extra.pop("deplace", None)
            r.modifie = True
        return

    if jonction:
        cible = Path(os.path.realpath(src))
        cible_ancien = cible.with_name(cible.name + SUFFIXE_ANCIEN)
        # retour interrompu apres le renommage de la destination
        if not cible.exists() and cible_ancien.is_dir():
            cible_ancien.rename(cible)
            r.actions.append(f"{titre} : retour interrompu, jeu remis sur « {cible} »")
        if cible.is_dir():
            if retour.exists():
                _nettoyer(retour, r, f"{titre} : copie de retour inachevee supprimee")
            if cible.parent.name == DOSSIER and not _meme_dossier(info.get("vers"), cible):
                g.extra["deplace"] = {"vers": str(cible), "le": info.get("le") or time.time()}
                r.modifie = True
                r.actions.append(f"{titre} : deplacement vers « {cible} » enregistre")
            if ancien.exists():
                _nettoyer(ancien, r, f"{titre} : ancien dossier supprime ({ancien})")
        else:
            r.restes.append(f"{titre} : « {cible} » est introuvable (disque debranche ?)")
        return

    if not src.exists():
        if retour.is_dir() and vers is not None:
            # retour interrompu entre le retrait de la jonction et le renommage
            vers_ancien = vers.with_name(vers.name + SUFFIXE_ANCIEN)
            if not vers.exists() and vers_ancien.is_dir():
                vers_ancien.rename(vers)
            if vers.is_dir():
                creer_lien(vers, src)
                r.actions.append(f"{titre} : retour interrompu, jeu remis sur « {vers} »")
                _nettoyer(retour, r, f"{titre} : copie de retour inachevee supprimee")
                return
        if retour.is_dir():
            r.restes.append(f"{titre} : introuvable, mais une copie existe dans « {retour} » : "
                            f"renommez-la en « {src.name} » pour retrouver le jeu.")
        return

    # dossier ordinaire : l'aller n'a pas eu lieu ou le retour a abouti
    if info:
        g.extra.pop("deplace", None)
        r.modifie = True
        r.actions.append(f"{titre} : retour sur le disque d'origine enregistre")
        if vers is not None:
            vers_ancien = vers.with_name(vers.name + SUFFIXE_ANCIEN)
            if vers_ancien.exists():
                _nettoyer(vers_ancien, r, f"{titre} : ancienne destination supprimee "
                                          f"({vers_ancien})")
    if retour.exists():
        r.restes.append(f"{titre} : dossier « {retour} » laisse par un retour : "
                        "verifiez-le puis supprimez-le.")
    if ancien.exists():
        r.restes.append(f"{titre} : dossier « {ancien} » laisse par un deplacement : "
                        "verifiez-le puis supprimez-le.")

