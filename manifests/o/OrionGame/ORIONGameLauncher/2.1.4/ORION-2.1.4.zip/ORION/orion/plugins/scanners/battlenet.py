"""Detection des jeux Blizzard / Battle.net.

Battle.net ne tient pas de manifeste lisible : on s'appuie sur la liste des
programmes installes, en reconnaissant les jeux par leur nom et par leur
emplacement, puis on retrouve le code de lancement `battlenet://`.
"""
from __future__ import annotations

import re
from pathlib import Path

from ...core.logging_setup import get
from ...core.models import Game
from ...core.winutil import HKLM, dir_size, reg_subkeys, reg_values
from .base import Scanner, detect_engine, pick_main_exe

log = get("scan.battlenet")

UNINSTALL = (
    r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
    r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall",
)

#: Titre (normalise) -> code de protocole battlenet://
KNOWN_GAMES = {
    "diablo ii resurrected": "OSI",
    "diablo ii": "OSI",
    "diablo iii": "D3",
    "diablo iv": "Fen",
    "diablo immortal": "ANBS",
    "overwatch": "Pro",
    "overwatch 2": "Pro",
    "world of warcraft": "WoW",
    "world of warcraft classic": "WoW_classic",
    "hearthstone": "WTCG",
    "heroes of the storm": "Hero",
    "starcraft": "S1",
    "starcraft ii": "S2",
    "warcraft iii": "W3",
    "warcraft iii reforged": "W3",
    "warcraft rumble": "GRY",
    "call of duty": "ODIN",
    "call of duty hq": "ODIN",
    "crash bandicoot 4": "WLBY",
}

#: uid interne Blizzard -> code de protocole (quand l'uid est lisible)
PRODUCT_CODES = {
    "wow": "WoW", "wow_classic": "WoW_classic", "wow_classic_era": "WoW_classic_era",
    "d3": "D3", "osi": "OSI", "fenris": "Fen", "pro": "Pro", "prometheus": "Pro",
    "s2": "S2", "s1": "S1", "hero": "Hero", "hsb": "WTCG", "w3": "W3",
    "anbs": "ANBS", "zeus": "ZEUS", "lazarus": "LAZR", "viper": "VIPR",
    "odin": "ODIN", "auks": "AUKS", "rtro": "RTRO", "wlby": "WLBY", "gryphon": "GRY",
}

BLIZZARD_PATH = re.compile(r"(battle\.?net|blizzard)", re.I)


def _norm(title: str) -> str:
    t = re.sub(r"[^a-z0-9 ]", " ", (title or "").lower())
    return re.sub(r"\s+", " ", t).strip()


class BattleNetScanner(Scanner):
    id = "battlenet"
    label = "Battle.net"
    icon = "BNT"
    priority = 60

    def available(self) -> bool:
        return (Path(r"C:\ProgramData\Battle.net").is_dir()
                or bool(self._entries()))

    # ------------------------------------------------------------------
    def _entries(self) -> list[dict]:
        """Entrees de desinstallation qui correspondent a un jeu Blizzard."""
        out: list[dict] = []
        for base in UNINSTALL:
            for sub in reg_subkeys(HKLM, base):
                v = reg_values(HKLM, f"{base}\\{sub}")
                name = str(v.get("DisplayName") or "")
                loc = str(v.get("InstallLocation") or "")
                pub = str(v.get("Publisher") or "")
                key_low = sub.lower()
                if not name or not loc:
                    continue
                looks_blizzard = (
                    _norm(name) in KNOWN_GAMES
                    or key_low.startswith(("battle.net", "blizzard"))
                    or "blizzard" in pub.lower()
                    or BLIZZARD_PATH.search(loc) is not None
                )
                if not looks_blizzard:
                    continue
                v["_key"] = sub
                out.append(v)
        return out

    def scan(self) -> list[Game]:
        games: list[Game] = []
        seen: set[str] = set()

        for v in self._entries():
            title = str(v.get("DisplayName") or "").strip()
            loc = str(v.get("InstallLocation") or "").rstrip("\\")
            if not title or title.lower() == "battle.net":
                continue
            p = Path(loc)
            if not p.is_dir() or loc.lower() in seen:
                continue
            seen.add(loc.lower())

            code = KNOWN_GAMES.get(_norm(title), "")
            if not code:
                m = re.search(r"--uid=([a-z0-9_]+)",
                              str(v.get("UninstallString", "")), re.I)
                if m:
                    uid = m.group(1).lower()
                    code = PRODUCT_CODES.get(uid, "")
                    for prefix, c in PRODUCT_CODES.items():
                        if not code and uid.startswith(prefix):
                            code = c

            games.append(self._mk(
                title=title,
                source_id=code or v["_key"],
                install_dir=loc,
                executable=pick_main_exe(p, title),
                launch_uri=f"battlenet://{code}" if code else "",
                size_bytes=int(v.get("EstimatedSize", 0) or 0) * 1024
                or dir_size(p, 6000),
                engine=detect_engine(p),
                extra={"blizzard_code": code,
                       "version": v.get("DisplayVersion", "")},
            ))
        log.info("%d jeux Battle.net", len(games))
        return games
