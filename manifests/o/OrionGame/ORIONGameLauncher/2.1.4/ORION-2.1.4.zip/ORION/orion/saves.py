"""Sauvegarde des parties : detection, archivage, restauration.

Les jeux dispersent leurs sauvegardes entre Documents, %LOCALAPPDATA%,
%APPDATA%, Saved Games et leur propre dossier d'installation. ORION cherche
aux bons endroits, montre ce qu'il a trouve, et archive au format zip avec
horodatage. Chaque archive est autonome et relisible sans ORION.

Rien n'est archive sans que l'utilisateur ait valide l'emplacement detecte.
"""
from __future__ import annotations

import json
import re
import shutil
import time
import zipfile
from dataclasses import asdict, dataclass
from pathlib import Path

from .core.config import CONFIG
from .core.logging_setup import get
from .core.models import Game, normalize_title
from .core.paths import DATA_DIR, ensure_dirs
from .optimizer.discovery import context_for

log = get("sauvegardes")

SAVE_DIR = DATA_DIR / "sauvegardes"
INDEX_FILE = SAVE_DIR / "_index.json"

#: dossiers ou les jeux rangent leurs sauvegardes
ROOTS = ("saved_games", "documents", "localappdata", "appdata")

#: sous-dossiers qui contiennent typiquement une sauvegarde
SAVE_HINTS = re.compile(
    r"(save|saves|savegame|savegames|savedata|saved|sauvegarde|profile|"
    r"profiles|player|slot)", re.I)

#: ce qui n'est jamais une sauvegarde
SKIP = re.compile(r"(crash|log|logs|cache|shader|temp|video|screenshot|"
                  r"replay|demo|telemetry)", re.I)

SAVE_EXT = {".sav", ".save", ".dat", ".json", ".xml", ".bin", ".db", ".sl2",
            ".ess", ".fos", ".profile", ".cfg", ".slot", ".sgd", ".rpgsave"}


@dataclass
class SaveLocation:
    """Un dossier de sauvegarde detecte."""
    path: str
    files: int
    bytes: int
    modified: float
    score: int = 0

    @property
    def size_mb(self) -> float:
        return round(self.bytes / (1024 * 1024), 1)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Archive:
    """Une archive de sauvegarde deja creee."""
    game_uid: str
    title: str
    path: str
    source: str
    at: float
    bytes: int

    @property
    def size_mb(self) -> float:
        return round(self.bytes / (1024 * 1024), 1)

    @property
    def when(self) -> str:
        return time.strftime("%d/%m/%Y a %H:%M", time.localtime(self.at))

    def to_dict(self) -> dict:
        return asdict(self)


# --------------------------------------------------------------------------
# Detection
# --------------------------------------------------------------------------

def _inspect(folder: Path, limit: int = 4000) -> tuple[int, int, float]:
    """(nombre de fichiers, octets, date de modification la plus recente)."""
    files = total = 0
    newest = 0.0
    try:
        for path in folder.rglob("*"):
            if not path.is_file():
                continue
            files += 1
            try:
                stat = path.stat()
                total += stat.st_size
                newest = max(newest, stat.st_mtime)
            except OSError:
                pass
            if files > limit:
                break
    except Exception:
        pass
    return files, total, newest


def detect(game: Game, limit: int = 6) -> list[SaveLocation]:
    """Emplacements de sauvegarde plausibles pour ce jeu."""
    ctx = context_for(game)
    key = normalize_title(game.title)
    found: dict[str, SaveLocation] = {}

    def consider(folder: Path, bonus: int = 0) -> None:
        if not folder.is_dir() or str(folder).lower() in found:
            return
        if SKIP.search(folder.name):
            return
        files, size, modified = _inspect(folder)
        if not files or size > 3 * 1024 ** 3:      # un dossier de 3 Go n'est
            return                                  # pas une sauvegarde
        score = bonus
        if SAVE_HINTS.search(folder.name):
            score += 40
        try:
            for child in list(folder.iterdir())[:60]:
                if child.suffix.lower() in SAVE_EXT:
                    score += 20
                    break
                if child.is_dir() and SAVE_HINTS.search(child.name):
                    score += 15
                    break
        except OSError:
            pass
        if size < 200 * 1024 * 1024:
            score += 10
        found[str(folder).lower()] = SaveLocation(
            str(folder), files, size, modified, score)

    # 1) dossiers du jeu dans les emplacements standards
    for root_key in ROOTS:
        base = ctx.get(root_key)
        if not base:
            continue
        root = Path(base)
        if not root.is_dir():
            continue
        try:
            for child in root.iterdir():
                if not child.is_dir():
                    continue
                name = normalize_title(child.name)
                if not key or not name:
                    continue
                if name == key or (len(name) > 3 and
                                   (name in key or key in name)):
                    consider(child, bonus=30)
                    for sub in list(child.iterdir())[:30]:
                        if sub.is_dir() and SAVE_HINTS.search(sub.name):
                            consider(sub, bonus=45)
        except OSError:
            continue

    # 2) sauvegardes rangees dans le dossier du jeu
    if game.install_dir:
        install = Path(game.install_dir)
        try:
            for sub in list(install.iterdir())[:60]:
                if sub.is_dir() and SAVE_HINTS.search(sub.name):
                    consider(sub, bonus=35)
        except Exception:
            pass

    # 3) Steam Cloud local
    if game.source == "steam" and game.source_id:
        from .plugins.scanners.steam import steam_root
        root = steam_root()
        if root is not None:
            userdata = Path(root) / "userdata"
            try:
                for account in userdata.iterdir():
                    folder = account / str(game.source_id)
                    if folder.is_dir():
                        consider(folder, bonus=50)
            except OSError:
                pass

    out = sorted(found.values(), key=lambda s: (-s.score, -s.modified))
    return out[:limit]


# --------------------------------------------------------------------------
# Archivage
# --------------------------------------------------------------------------

class SaveManager:
    def __init__(self) -> None:
        ensure_dirs()
        SAVE_DIR.mkdir(parents=True, exist_ok=True)
        self.index: dict = {}
        self._load()

    def _load(self) -> None:
        try:
            if INDEX_FILE.exists():
                self.index = json.loads(INDEX_FILE.read_text("utf-8"))
        except Exception:
            self.index = {}

    def _save_index(self) -> None:
        try:
            from .core.paths import ecrire_atomique
            ecrire_atomique(INDEX_FILE, json.dumps(self.index, indent=1,
                                                   ensure_ascii=False))
        except Exception:
            log.debug("Index des sauvegardes non enregistre")

    # ------------------------------------------------------------------
    def location_for(self, game: Game) -> str:
        """Emplacement retenu pour ce jeu (choisi ou detecte)."""
        return str((self.index.get("games") or {}).get(game.uid, {}).get(
            "location") or "")

    def set_location(self, game: Game, path: str) -> None:
        games = self.index.setdefault("games", {})
        games.setdefault(game.uid, {})["location"] = path
        games[game.uid]["title"] = game.title
        self._save_index()

    def archives(self, game: Game | None = None) -> list[Archive]:
        out: list[Archive] = []
        connus: set[str] = set()
        for entry in self.index.get("archives") or []:
            if game is not None and entry.get("game_uid") != game.uid:
                continue
            if not Path(entry.get("path", "")).exists():
                continue
            out.append(Archive(**{k: entry.get(k) for k in
                                  Archive.__dataclass_fields__}))
            connus.add(Path(entry["path"]).name)
        # archives du dossier synchronise (autre PC, reinstallation) : meme
        # jeu reconnu par son identifiant ou, a defaut, par son titre
        racine = CONFIG.get("saves.cloud_dir", "") or ""
        if racine:
            from . import nuage
            for entry in nuage.archives(racine):
                if Path(entry["path"]).name in connus:
                    continue
                if game is not None and entry.get("game_uid") != game.uid and \
                        normalize_title(entry.get("title", "")) != normalize_title(game.title):
                    continue
                out.append(Archive(**{k: entry.get(k) for k in
                                      Archive.__dataclass_fields__}))
        out.sort(key=lambda a: a.at, reverse=True)
        return out

    # ------------------------------------------------------------------
    def backup(self, game: Game, source: str = "") -> tuple[bool, str]:
        """Archive la sauvegarde du jeu au format zip."""
        folder = Path(source or self.location_for(game))
        if not folder.is_dir():
            return False, "Aucun emplacement de sauvegarde valide."

        safe = re.sub(r"[^A-Za-z0-9 _-]+", "", game.title)[:50].strip() or game.uid
        target_dir = SAVE_DIR / safe
        target_dir.mkdir(parents=True, exist_ok=True)
        stamp = time.strftime("%Y-%m-%d_%H-%M-%S")
        archive_path = target_dir / f"{stamp}.zip"

        count = 0
        try:
            with zipfile.ZipFile(archive_path, "w",
                                 zipfile.ZIP_DEFLATED) as zf:
                for path in folder.rglob("*"):
                    if not path.is_file():
                        continue
                    try:
                        zf.write(path, path.relative_to(folder))
                        count += 1
                    except Exception:
                        continue
                zf.writestr("_orion.json", json.dumps({
                    "jeu": game.title, "uid": game.uid,
                    "source": str(folder), "date": stamp,
                    "fichiers": count}, indent=2, ensure_ascii=False))
        except Exception as exc:
            return False, f"Archivage impossible : {exc}"

        if not count:
            try:
                archive_path.unlink()
            except OSError:
                pass
            return False, "Aucun fichier a archiver dans cet emplacement."

        size = archive_path.stat().st_size
        self.index.setdefault("archives", []).append({
            "game_uid": game.uid, "title": game.title,
            "path": str(archive_path), "source": str(folder),
            "at": time.time(), "bytes": size})
        self.set_location(game, str(folder))
        self._prune(game)
        self._save_index()
        log.info("Sauvegarde archivee : %s (%d fichiers)", archive_path, count)
        message = (f"{count} fichier(s) archive(s) - "
                   f"{round(size / (1024 * 1024), 1)} Mo")
        racine = CONFIG.get("saves.cloud_dir", "") or ""
        if racine:
            from . import nuage
            if nuage.copier(archive_path, safe, racine,
                            int(CONFIG.get("saves.keep", 10) or 10)):
                message += " · copie dans le dossier synchronise"
        return True, message

    def _prune(self, game: Game) -> None:
        """Ne conserve que les N dernieres archives d'un jeu."""
        keep = int(CONFIG.get("saves.keep", 10) or 10)
        entries = [e for e in self.index.get("archives") or []
                   if e.get("game_uid") == game.uid]
        entries.sort(key=lambda e: e.get("at", 0), reverse=True)
        for old in entries[keep:]:
            try:
                Path(old["path"]).unlink()
            except OSError:
                pass
            self.index["archives"].remove(old)

    def restore(self, archive: Archive, target: str = "") -> tuple[bool, str]:
        """Restaure une archive, apres avoir mis l'existant de cote."""
        path = Path(archive.path)
        if not path.exists():
            return False, "Archive introuvable."
        destination = Path(target or archive.source)
        if not destination.parent.exists():
            return False, "Emplacement de restauration introuvable."

        if destination.exists():
            backup = destination.with_name(
                destination.name + time.strftime("_avant_restauration_%H%M%S"))
            try:
                shutil.move(str(destination), str(backup))
            except Exception as exc:
                return False, f"Impossible de mettre l'existant de cote : {exc}"

        destination.mkdir(parents=True, exist_ok=True)
        try:
            with zipfile.ZipFile(path) as zf:
                for member in zf.namelist():
                    if member == "_orion.json":
                        continue
                    zf.extract(member, destination)
        except Exception as exc:
            return False, f"Restauration impossible : {exc}"
        log.info("Sauvegarde restauree : %s -> %s", path, destination)
        return True, f"Sauvegarde du {archive.when} restauree."

