"""Adresses utiles d'un jeu : sa page boutique, sa fiche dans son lanceur."""
from __future__ import annotations

import urllib.parse

from .models import Game


def appid_steam(game: Game) -> str:
    if game.source == "steam" and game.source_id:
        return str(game.source_id)
    natif = game.extra.get("native") or ()
    if len(natif) == 2 and natif[0] == "steam":
        return str(natif[1])
    return str(game.extra.get("steam_appid") or "")


def page_magasin(game: Game) -> str:
    """Fiche boutique du jeu, ou a defaut une recherche sur sa plateforme."""
    if game.store_url:
        return game.store_url
    appid = appid_steam(game)
    if appid:
        return f"https://store.steampowered.com/app/{appid}"
    # titre sans separateurs ni ™ ® : « RuneScape - Dragonwilds » cherche
    # « RuneScape Dragonwilds » (un « - » isole exclut le mot suivant sur
    # certaines boutiques)
    from .recherche import titre_recherche
    q = urllib.parse.quote(titre_recherche(game.title) or game.title)
    bases = {
        "epic": f"https://store.epicgames.com/fr/browse?q={q}",
        "gog": f"https://www.gog.com/fr/games?query={q}",
        "ubisoft": f"https://store.ubisoft.com/fr/search?q={q}",
        "ea": f"https://www.ea.com/fr-fr/search?query={q}",
        "battlenet": f"https://shop.battle.net/fr-fr/search?q={q}",
        "xbox": f"https://www.xbox.com/fr-FR/search/results/games?q={q}",
    }
    return bases.get(game.source,
                     f"https://store.steampowered.com/search/?term={q}")


def fiche_lanceur(game: Game) -> tuple[str, str]:
    """(adresse, libelle) de la page du jeu dans son lanceur, si elle existe."""
    appid = appid_steam(game)
    if appid:
        return f"steam://nav/games/details/{appid}", "Ouvrir dans Steam"
    if game.source == "gog" and game.source_id:
        return f"goggalaxy://openGameView/{game.source_id}", "Ouvrir dans GOG Galaxy"
    if game.source == "epic":
        return "com.epicgames.launcher://store/", "Ouvrir Epic Games Launcher"
    if game.source == "ubisoft":
        return "uplay://", "Ouvrir Ubisoft Connect"
    if game.source == "battlenet":
        return "battlenet://", "Ouvrir Battle.net"
    if game.source == "ea":
        return "origin2://", "Ouvrir l'application EA"
    return "", ""
