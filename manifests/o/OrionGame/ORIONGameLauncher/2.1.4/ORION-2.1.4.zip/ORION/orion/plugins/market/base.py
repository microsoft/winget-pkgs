"""Contrat commun aux fournisseurs de prix et d'evaluations.

Un fournisseur renseigne tout ou partie d'une `MarketInfo` : note des
joueurs, prix actuel, meilleure offre du moment, plus bas historique.
Le service les interroge dans l'ordre de priorite et fusionne ce que
chacun sait, ce qui permet d'en ajouter un sans toucher aux autres.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field

from ...core.logging_setup import get
from ...core.models import Game

log = get("market")


@dataclass
class Offer:
    """Une offre d'achat sur une boutique."""
    shop: str
    price: float
    currency: str = "EUR"
    cut: int = 0                 # reduction en pourcentage
    url: str = ""
    drm: str = ""                # Steam, Epic, GOG, sans DRM...

    @property
    def label(self) -> str:
        cut = f"  -{self.cut}%" if self.cut else ""
        return f"{self.price:.2f} {self.symbol}{cut}"

    @property
    def symbol(self) -> str:
        from orion.core import region
        return region.symbole(self.currency)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class MarketInfo:
    """Ce qu'ORION sait du prix et de la reception d'un jeu."""
    game_uid: str = ""
    title: str = ""

    # -- evaluation ------------------------------------------------------
    review_score: int = 0            # pourcentage d'avis positifs
    review_count: int = 0
    review_label: str = ""           # "Tres positives", ...
    metacritic: int = 0
    metacritic_url: str = ""

    # -- prix ------------------------------------------------------------
    base_price: float = 0.0          # prix de reference (sans promotion)
    current: Offer | None = None     # prix sur la boutique d'origine
    best: Offer | None = None        # meilleure offre trouvee
    historical_low: float = 0.0      # plus bas prix jamais releve
    historical_shop: str = ""
    offers: list[Offer] = field(default_factory=list)
    deals_url: str = ""              # page de comparaison complete

    # -- divers ----------------------------------------------------------
    news: list[dict] = field(default_factory=list)   # actualites du jeu
    screenshots: list[dict] = field(default_factory=list)  # {thumb, full, local}
    schema: int = 5                  # version du format en cache
    incomplet: bool = False          # une source n'a pas repondu : a refaire vite
    release_date: str = ""
    developer: str = ""
    publisher: str = ""
    genres: list[str] = field(default_factory=list)
    categories: list[int] = field(default_factory=list)   # categories Steam (1.8.1)
    free: bool = False
    fetched_at: float = 0.0
    sources: list[str] = field(default_factory=list)
    note: str = ""                   # message a afficher (cle manquante...)
    captures_note: str = ""          # pourquoi il n'y a pas de captures
    adulte: bool = False             # jeu reserve aux adultes : ni captures ni videos


    def to_dict(self) -> dict:
        d = asdict(self)
        d["current"] = self.current.to_dict() if self.current else None
        d["best"] = self.best.to_dict() if self.best else None
        d["offers"] = [o.to_dict() for o in self.offers]
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "MarketInfo":
        info = cls(**{k: v for k, v in d.items()
                      if k in cls.__dataclass_fields__ and
                      k not in ("current", "best", "offers")})
        if d.get("current"):
            info.current = Offer(**d["current"])
        if d.get("best"):
            info.best = Offer(**d["best"])
        info.offers = [Offer(**o) for o in d.get("offers") or []]
        return info


class MarketProvider:
    """Sous-classer et implementer `fetch`. Decouverte automatique."""

    abstract = True
    id: str = ""
    label: str = ""
    priority: int = 50
    needs_key: bool = False
    #: OBLIGATOIRE : comment ce fournisseur signale un jeu reserve aux
    #: adultes (`info.adulte = True`). Sans declaration, les tests echouent.
    filtre_adulte: str = ""

    @staticmethod
    def adulte(brut: dict) -> bool:
        """A appeler sur le produit brut : `info.adulte = info.adulte or self.adulte(p)`."""
        from ...contenu_adulte import produit_adulte
        return produit_adulte(brut)

    def available(self) -> bool:
        return True

    def fetch(self, game: Game, info: MarketInfo) -> None:
        """Complete `info` sur place. Ne doit jamais lever d'exception."""
