"""Fichiers de reglages XML (2.1.0), modifies sur place.

Le fichier n'est pas reconstruit (ElementTree perdrait commentaires et
mise en forme) : seule la valeur visee est remplacee. Une cle absente n'est
jamais creee.

Adresse d'un reglage (`key` de l'entree de recette) :

- « Graphics/ShadowQuality » : texte de l'element <ShadowQuality> sous un
  element <Graphics> (le chemin est une suite de balises, le dernier segment
  est l'element dont le texte change) ;
- « Graphics/ShadowQuality@value » : l'attribut `value` de cet element
  (GTA V : <ShadowQuality value="2" />) ;
- « attribute[id=ShadowQuality]@value » : l'element <attribute> dont
  l'attribut `id` vaut ShadowQuality, attribut `value` (Baldur's Gate 3) ;
- « RenderProfile@ResolutionX » : attribut d'un element designe par sa balise.
Le premier segment peut etre n'importe ou dans le fichier (pas besoin de
partir de la racine).
"""
from __future__ import annotations

import os
import re
from pathlib import Path

from ...core.logging_setup import get
from ...core.models import TweakOp
from .base import TweakWriter
from .ini_writer import lire_texte

log = get("tweaks.xml")

#: valeur « reglage absent du fichier » : Baldur's Gate 3 (Larian) n'ecrit dans
#: graphicSettings.lsx que les reglages qui different de leur valeur par
#: defaut. Ecrire ABSENT retire l'entree (le jeu reprend sa valeur par
#: defaut) ; lire une entree Larian absente rend ABSENT (10 octobre :
#: l'apprentissage ne gardait que les cles presentes a tous les niveaux et ne
#: retenait que CurrentSettings, que le jeu recalcule lui-meme au demarrage).
#: Commence par une lettre : le service n'accepte dans une recette partagee
#: que des valeurs simples (lettre, chiffres, souligne), « __absent__ » y
#: etait refuse et les niveaux appris de Baldur's Gate 3 ne se partageaient pas.
ABSENT = "orion_absent"
#: TweakOp.section d'une entree Larian : « larian=<Type>:<type de Value> »,
#: de quoi recreer le noeud ConfigEntry s'il manque
_LARIAN = re.compile(r"^larian=(-?\d+):([A-Za-z0-9_]+)$")
_CLE_LARIAN = re.compile(r"^attribute\[value=([^\]]+)\]/attribute\[id=Value\]@value$")

_ADRESSE = re.compile(r"^(?P<chemin>[^@]+?)(?:@(?P<attr>[A-Za-z_][\w.:-]*))?$")
_SEGMENT = re.compile(r"^(?P<balise>[A-Za-z_][\w.:-]*)(?:\[(?P<cle>[\w.:-]+)=(?P<val>[^\]]*)\])?$")


def _ouvrante(balise: str, cle: str, val: str) -> re.Pattern:
    """La balise ouvrante <balise ...> (avec un attribut cle="val" si demande)."""
    if cle:
        return re.compile(r"<" + re.escape(balise) + r"\b(?=[^>]*\b" + re.escape(cle)
                          + r"\s*=\s*([\"'])" + re.escape(val) + r"\1)[^>]*>", re.S)
    return re.compile(r"<" + re.escape(balise) + r"\b[^>]*>", re.S)


def _trouver(texte: str, chemin: str) -> tuple[int, int] | None:
    """(debut, fin) de la balise ouvrante de l'element vise, en descendant
    segment par segment (chaque segment est cherche apres le precedent)."""
    pos = 0
    span = None
    for seg in chemin.strip("/").split("/"):
        m = _SEGMENT.match(seg.strip())
        if not m:
            return None
        trouve = _ouvrante(m.group("balise"), m.group("cle") or "", m.group("val") or "").search(texte, pos)
        if not trouve:
            return None
        span = (trouve.start(), trouve.end())
        pos = trouve.end()
    return span


def _position_valeur(texte: str, adresse: str) -> tuple[int, int] | None:
    """(debut, fin) de la valeur a remplacer, ou None si l'adresse ne
    designe rien dans ce fichier."""
    m = _ADRESSE.match(adresse.strip())
    if not m:
        return None
    span = _trouver(texte, m.group("chemin"))
    if span is None:
        return None
    debut, fin = span
    attr = m.group("attr")
    if attr:
        ouvrante = texte[debut:fin]
        a = re.search(r"\b" + re.escape(attr) + r"\s*=\s*([\"'])(.*?)\1", ouvrante, re.S)
        if not a:
            return None
        return debut + a.start(2), debut + a.end(2)
    if texte[fin - 2:fin] == "/>":
        return None                          # element vide : pas de texte
    fermante = texte.find("<", fin)
    if fermante < 0:
        return None
    return fin, fermante


def lire_valeur(texte: str, adresse: str) -> str | None:
    pos = _position_valeur(texte, adresse)
    return texte[pos[0]:pos[1]].strip() if pos else None


def _noeud_larian(texte: str, cle: str) -> re.Match | None:
    """Le noeud <node id="ConfigEntry"> dont MapKey vaut `cle`, ligne comprise."""
    return re.search(r'[ \t]*<node id="ConfigEntry">(?:(?!</node>).)*?id="MapKey"[^>]*\bvalue="'
                     + re.escape(cle) + r'"(?:(?!</node>).)*</node>[ \t]*\r?\n?', texte, re.S)


def _ajouter_larian(texte: str, cle: str, type_code: str, type_valeur: str, valeur: str) -> str | None:
    """Ajoute l'entree, sur le modele (et l'indentation) des entrees deja la."""
    noeuds = list(re.finditer(r'([ \t]*)<node id="ConfigEntry">(?:(?!</node>).)*</node>[ \t]*(\r?\n)?',
                              texte, re.S))
    if not noeuds:
        return None
    dernier = noeuds[-1]
    retrait, fin_ligne = dernier.group(1), dernier.group(2) or "\n"
    interieur = retrait + ("\t" if "\t" in retrait else "    ")
    v = str(valeur).replace("&", "&amp;").replace("<", "&lt;").replace('"', "&quot;")
    bloc = (f'{retrait}<node id="ConfigEntry">{fin_ligne}'
            f'{interieur}<attribute id="MapKey" type="FixedString" value="{cle}"/>{fin_ligne}'
            f'{interieur}<attribute id="Type" type="int32" value="{type_code}"/>{fin_ligne}'
            f'{interieur}<attribute id="Value" type="{type_valeur}" value="{v}"/>{fin_ligne}'
            f'{retrait}</node>{fin_ligne}')
    return texte[:dernier.end()] + bloc + texte[dernier.end():]


def modifier(texte: str, valeurs) -> tuple[str, list[str]]:
    """`valeurs` : (adresse, valeur) ou (adresse, valeur, section). Une entree
    Larian (section « larian=... ») peut etre ajoutee si elle manque, ou
    retiree avec la valeur ABSENT."""
    absentes: list[str] = []
    for item in valeurs:
        adresse, valeur = item[0], item[1]
        section = item[2] if len(item) > 2 else ""
        larian, cle_l = _LARIAN.match(section or ""), _CLE_LARIAN.match(adresse.strip())
        if larian and cle_l:
            noeud = _noeud_larian(texte, cle_l.group(1))
            if str(valeur) == ABSENT:
                if noeud:
                    texte = texte[:noeud.start()] + texte[noeud.end():]
                continue
            if noeud is None:
                ajoute = _ajouter_larian(texte, cle_l.group(1), larian.group(1), larian.group(2), str(valeur))
                if ajoute is None:
                    absentes.append(adresse)
                else:
                    texte = ajoute
                continue
        elif str(valeur) == ABSENT:
            absentes.append(adresse)          # jamais rien retire hors des entrees Larian
            continue
        pos = _position_valeur(texte, adresse)
        if pos is None:
            absentes.append(adresse)
            continue
        v = str(valeur).replace("&", "&amp;").replace("<", "&lt;").replace('"', "&quot;")
        texte = texte[:pos[0]] + v + texte[pos[1]:]
    return texte, absentes


class XmlWriter(TweakWriter):
    id = "xml"
    label = "Fichier XML"

    def read(self, op: TweakOp) -> str | None:
        texte, _enc, _eol = lire_texte(Path(op.target))
        if not texte:
            return None
        v = lire_valeur(texte, op.key)
        if v is None and _LARIAN.match(op.section or "") and _CLE_LARIAN.match(op.key.strip()):
            return ABSENT                     # entree Larian absente : valeur par defaut du jeu
        return v

    def write(self, ops: list[TweakOp]) -> tuple[int, str]:
        by_file: dict[str, list[TweakOp]] = {}
        for op in ops:
            by_file.setdefault(op.target, []).append(op)
        written, erreurs = 0, []
        for target, items in by_file.items():
            path = Path(target)
            if not path.exists():
                erreurs.append(f"{path.name} introuvable : rien n'est cree a sa place.")
                continue
            if not os.access(path, os.W_OK):
                erreurs.append(f"{path.name} est en lecture seule : ORION ne le force pas.")
                continue
            try:
                texte, enc, _eol = lire_texte(path)
                nouveau, absentes = modifier(texte, [(o.key, str(o.value), o.section or "") for o in items])
                if absentes:
                    log.info("%s : reglage(s) absent(s), non cree(s) : %s", path.name, absentes)
                if nouveau != texte:
                    provisoire = path.with_name(path.name + ".orion.tmp")
                    provisoire.write_bytes(nouveau.encode(enc))
                    os.replace(provisoire, path)
                written += len(items) - len(absentes)
            except Exception as exc:
                log.exception("Ecriture XML impossible : %s", path)
                erreurs.append(f"Ecriture impossible dans {path.name} : {exc}")
        return written, (" ; ".join(erreurs) if erreurs else "Reglages ecrits")
