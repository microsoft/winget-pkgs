"""Version et identite de l'application."""

APP_NAME = "ORION"
APP_TAGLINE = "Game Launcher"
APP_VERSION = "2.1.4"
CONFIG_SCHEMA = 1
