"""Service prix et evaluations : orchestre les fournisseurs et le cache.

Les tarifs bougent lentement : le resultat est garde en cache quelques
heures pour ne pas solliciter les boutiques a chaque ouverture de fiche.
"""
from __future__ import annotations

import time

from .core import registry
from .core.config import CONFIG
from .core.base import Table
from .core.logging_setup import get
from .core.models import Game
from .core.paths import CACHE_DIR, ensure_dirs
from .plugins.market.base import MarketInfo, MarketProvider

log = get("market.service")

CACHE_FILE = CACHE_DIR / "market.json"


class MarketService:
    def __init__(self) -> None:
        self._providers: list[MarketProvider] | None = None
        self._cache: dict[str, dict] = {}
        self._load()

    # -- cache ----------------------------------------------------------
    def _load(self) -> None:
        ensure_dirs()
        self._table = Table("prix", CACHE_FILE, maximum=1500)
        try:
            self._cache = self._table.tout()
        except Exception:
            self._cache = {}

    def _save(self, uid: str) -> None:
        """Seule la fiche modifiee est reecrite."""
        if uid in self._cache:
            self._table.set(uid, self._cache[uid])

    # -- plugins --------------------------------------------------------
    @property
    def providers(self) -> list[MarketProvider]:
        if self._providers is None:
            found = registry.discover(MarketProvider, "orion.plugins.market",
                                      "market")
            self._providers = registry.available(found)
            log.info("Fournisseurs de prix : %s", [p.id for p in self._providers])
        return self._providers

    def reload_plugins(self) -> None:
        self._providers = None

    # -- acces ----------------------------------------------------------
    def en_cache(self, game: Game, meme_perime: bool = False) -> MarketInfo | None:
        """Ce qui est deja connu, sans aucun appel reseau.

        Sert a l'affichage instantane d'une fiche : pas besoin d'attendre la
        file des taches pour montrer des donnees deja sur le disque.
        `meme_perime` rend aussi un releve trop ancien (a rafraichir ensuite).
        """
        cached = self._cache.get(game.uid)
        if not cached:
            return None
        # un cache d'un ancien format (sans captures ni traduction) est rejoue
        if int(cached.get("schema") or 1) < MarketInfo().schema:
            return None
        perime = False
        # jeu hors Steam dont l'identifiant Steam n'a jamais ete cherche (ou
        # cherche avec l'ancienne comparaison des titres, avant la v3)
        from .core.liens import appid_steam
        from .plugins.market.steam_store import SteamStoreProvider
        if (not cached.get("screenshots") and not appid_steam(game)
                and not game.extra.get(SteamStoreProvider.MARQUEUR)):
            perime = True
        hours = float(CONFIG.get("market.cache_hours", 12) or 12)
        age = time.time() - float(cached.get("fetched_at") or 0)
        # un releve incomplet (Steam en pause) est refait apres 10 minutes
        incomplet = cached.get("incomplet") or (
            (game.source == "steam" or game.extra.get("steam_appid"))
            and not {"steam_store", "steam_sans_fiche"} & set(cached.get("sources") or []))
        if age >= (600 if incomplet else hours * 3600):
            perime = True
        # releve d'avant la 1.8.1 : sans les categories Steam (jeu en ligne ?)
        if "steam_store" in (cached.get("sources") or []) and "categories" not in cached:
            perime = True
        # releve d'avant la 1.9.6 : jamais verifie pour le contenu adulte
        if "adulte" not in cached:
            perime = True
        # releve fait pour un autre pays : ses prix sont dans l'ancienne devise
        from .core import region
        if cached.get("pays") and cached.get("pays") != region.pays():
            perime = True
        if perime and not meme_perime:
            return None
        try:
            info = MarketInfo.from_dict(cached)
        except Exception:
            return None
        # meme regle a l'affichage d'un releve deja sur le disque
        from . import contenu_adulte
        if info.adulte or contenu_adulte.jeu_adulte(game):
            info.adulte = True
            info.screenshots = []
            info.captures_note = contenu_adulte.NOTE
        return info

    def get(self, game: Game, force: bool = False) -> MarketInfo:
        """Informations de prix et d'evaluation, depuis le cache si possible."""
        if not CONFIG.get("market.enabled", True):
            info = MarketInfo(game_uid=game.uid, title=game.title)
            info.note = "Comparateur desactive dans les reglages."
            return info

        if not force:
            frais = self.en_cache(game)
            if frais is not None:
                return frais

        info = MarketInfo(game_uid=game.uid, title=game.title)
        for provider in self.providers:
            try:
                provider.fetch(game, info)
            except Exception:
                log.exception("Fournisseur de prix en echec : %s", provider.id)

        self._decider_adulte(game, info)
        if not info.fetched_at:
            info.fetched_at = time.time()
        from .core import region
        self._cache[game.uid] = dict(info.to_dict(), pays=region.pays())
        self._save(game.uid)
        return info

    @staticmethod
    def _decider_adulte(game: Game, info: MarketInfo) -> None:
        """Decision unique pour la fiche d'un jeu, quel que soit le
        fournisseur qui a signale : un jeu reserve aux adultes n'a ni
        captures ni videos. Le marquage suit le jeu (`game.extra`) pour que
        le lecteur video le sache sans attendre la fiche."""
        from . import contenu_adulte
        info.adulte = bool(info.adulte or contenu_adulte.signale(info.genres))
        if info.adulte:
            info.screenshots = []
            info.captures_note = contenu_adulte.NOTE
            game.extra[contenu_adulte.CLE] = True
        elif info.sources:
            # verifie et sain : un ancien marquage errone est leve
            game.extra.pop(contenu_adulte.CLE, None)

    # -- traduction des actualites --------------------------------------
    @staticmethod
    def a_traduire(info: MarketInfo) -> bool:
        if not CONFIG.get("market.translate_news", True):
            return False
        return any("traduit" not in n for n in info.news or [])

    def traduire_actus(self, uid: str, info: MarketInfo) -> MarketInfo:
        """Traduit titres et textes des actualites, puis met le cache a jour.

        Chaque actualite est marquee (`traduit` vrai ou faux) : elle n'est
        plus jamais retraduite, meme si le texte etait deja en francais.
        """
        from .core.traduction import semble_francais, traduire
        for n in info.news or []:
            if "traduit" in n:
                continue
            titre = n.get("title", "")
            corps = n.get("body") or n.get("summary", "")
            titre_fr, corps_fr = traduire(titre), traduire(corps)
            change = titre_fr != titre or corps_fr != corps
            if not change and not semble_francais(corps or titre):
                continue      # service injoignable : on reessaiera
            n["title_fr"], n["body_fr"], n["traduit"] = titre_fr, corps_fr, change
        if uid in self._cache:
            self._cache[uid]["news"] = info.news
            self._save(uid)
        return info
