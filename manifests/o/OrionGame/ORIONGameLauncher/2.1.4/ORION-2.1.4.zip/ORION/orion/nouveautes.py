"""Journal des nouveautes, affiche apres chaque mise a jour.

A tenir a jour a chaque version (regle du projet : chaque modification est
reportee dans l'application, dans l'installateur et sur le site). La
premiere entree est la version courante.
"""
from __future__ import annotations

JOURNAL: list[dict] = [
    {
        "version": "2.1.4",
        "titre": "Fermeture sans fausse alerte",
        "points": [
            "Correction : une session coupee pendant sa fermeture (fermeture lente arretee par Windows ou par le Gestionnaire des taches) etait presentee au lancement suivant comme un plantage, avec la question « ORION s'est arrete brutalement ». La fermeture est maintenant notee des qu'elle est demandee : seul un vrai arret pendant l'utilisation ouvre la question.",
            "Nouveau : si ORION plante vraiment (erreur de Windows, d'un pilote ou d'une bibliotheque, hors de Python), la trace du plantage est gardee et jointe au rapport de signalement, avec la facon dont la session precedente s'est terminee et la provenance d'ORION (Microsoft Store ou installateur). Rien ne part sans votre accord.",
            "Correction : apres la fermeture de la fenetre, un telechargement encore en cours (outil de mesure des images par seconde, visuels) gardait ORION en vie sans fenetre jusqu'a sa fin : un nouveau lancement ne montrait rien. ORION s'arrete au plus tard 3 s apres la fermeture.",
        ],
    },
    {
        "version": "2.1.3",
        "titre": "Fermeture nette",
        "points": [
            "Correction : ORION mettait cinq secondes a se fermer, a chaque fois (il attendait le fil d'ecriture de la base, qui ne se termine jamais). Il se ferme des que tout est ecrit, en general aussitot.",
            "Correction : a la fermeture, la derniere version de la bibliotheque pouvait etre recouverte par une version plus ancienne encore en cours d'ecriture. Une seule file d'ecriture, dans l'ordre des depots.",
            "Correction : apres une partie mesuree, la fiche ouverte sur ce jeu n'etait pas recalculee (le calcul partait du fil de surveillance de la partie, et son resultat n'etait jamais livre) : « Jouer » reprenait le plan d'avant la partie.",
            "Correction : la bibliotheque est ecrite avant le redemarrage pour une mise a jour, et un appel differe demande depuis un fil de fond est maintenant honore (il ne partait jamais).",
            "Correction : la fiche d'un jeu dont le dossier est sur un disque debranche (jonction vers un disque externe) affichait « Erreur : Fonction incorrecte » a chaque calcul des reglages (281 fois dans un journal). Le dossier est tenu pour absent et les reglages se calculent quand meme ; ils seront ecrits quand le disque sera de retour.",
            "Correction : la boite « Copie de jeu interrompue » s'ouvrait a chaque lancement d'ORION quand un jeu deplace etait sur un disque externe debranche. Ce n'est pas une copie interrompue : une notification discrete le dit (« Disque absent pour le moment »), et la boite ne sert plus qu'aux vraies copies a verifier.",
            "Correction : les conseils des recettes (Rocket League, Apex Legends, Counter-Strike 2, Elden Ring, GTA V...) et les messages « X : en cours » et « X demarre... » sont traduits en anglais.",
            "Retouche : dans la fiche d'un jeu, l'ancrage des cartes de graphismes apres un clic marche aussi quand le joueur n'a pas encore fait defiler la page.",
        ],
    },
    {
        "version": "2.1.2",
        "titre": "Retouches",
        "points": [
            "Nouveau : ORION se lance au demarrage de Windows, reduit dans la barre des taches : la veille des prix et de vos jeux tourne sans que vous l'ouvriez, et un clic le rouvre en grand. Pour l'eviter, decochez « Lancer ORION au demarrage de Windows », en tete des Reglages (la meme case est dans l'installateur) ; ORION figure aussi dans le Gestionnaire des taches, onglet Applications de demarrage, ou il se coupe d'un clic.",
            "Nouveau : la recherche de la Boutique, comme sur un site de vente de jeux. La barre est en haut de la page, a cote des onglets, et sert aussi depuis « Gratuits en ce moment ». Des la premiere lettre, une liste s'ouvre sous la barre : les jeux trouves avec leur visuel, leur boutique, la remise et le prix, les types de jeux qui correspondent, puis « Voir les resultats » pour la page complete, avec ses filtres et son tri. Champ vide : les fiches vues recemment, ou les jeux du moment. Fautes et sigles acceptes (gta, bg3, cyberpounk), fleches du clavier et Entree.",
            "Correction : les estimations suivent tout ce que l'editeur promet. Monster Hunter Wilds donne sa configuration recommandee pour 60 images par seconde avec la generation d'images, en reglages Moyens : ORION lisait 60 images par seconde en Haute et annoncait deux fois trop. Le prereglage, la generation d'images et la mise a l'echelle ecrits par l'editeur sont maintenant comptes (Stalker 2, Silent Hill 2, Stellar Blade, Nioh 3...), et les jeux bloques a 60 images par seconde (Elden Ring, Dark Souls, Sekiro, les jeux de combat) ne sont plus annonces au-dela. Les jeux qui exigent une carte graphique avec ray tracing materiel (DOOM: The Dark Ages, Indiana Jones et le Cercle Ancien, Ace Combat 8) etaient annonces jouables sur des cartes qui ne le calculent pas, ou ils ne se lancent pas : ORION le dit maintenant, et indique quelle carte il faudrait.",
            "Nouveau : les codes promo des revendeurs partenaires. Quand Kinguin, Instant Gaming ou Loaded envoie un code de reduction, il s'affiche sous son lien dans la fiche du jeu, avec ses conditions, tant qu'il est valable, puis disparait seul. Premier code : SPOOK5, -5 % chez Kinguin jusqu'au 31 octobre. Un code annonce apres cette version arrive quand meme : ORION relit la liste sur son site au plus une fois par six heures.",
            "Nouveau : les jeux pretes par votre famille Steam sont marques « (Steam Family) » sur la carte de joueur et dans la valeur de la bibliotheque (ils restent comptes), et la case « Steam Family » de la bibliotheque les affiche ou les cache.",
            "Correction : les jeux offerts par IndieGala etaient presentes comme un telechargement direct sans compte ; il faut en fait un compte IndieGala gratuit, et ORION le dit. Leur valeur annoncee par IndieGala (29,99 $ pour des jeux sans rapport entre eux) n'est plus affichee.",
            "Plus fluide : la fenetre « Valeur estimee de ma bibliotheque » s'ouvre tout de suite (elle restait figee plus d'une seconde avec 400 jeux), la liste se complete en un instant. Et la mesure de fluidite ne compte plus comme accrochages les arrets quand ORION est derriere un jeu, ni le temps passe dans une fenetre de Windows (choisir un fichier ou un dossier).",
            "Nouveau : « Donnez votre avis », un petit lien discret sous l'encart de version, en bas a gauche. Trois questions courtes (ce qui vous sert, ce qui vous gene, ce qui manque) et un choix : ORION a la place de votre launcher habituel, oui, peut-etre ou non. La fenetre ne s'ouvre jamais d'elle-meme ; rien ne part sans le bouton Envoyer, sans rapport technique.",
            "Correction : une partie mesuree pendant que le jeu etait en arriere-plan (bride par Windows a 15 ou 30 images par seconde) pouvait servir de reference : Aniimo etait annonce a ~20 i/s en Basse au lieu de ~115. ORION ne compte plus que les moments ou le jeu est au premier plan, et une mesure douteuse ne remplace jamais une bonne.",
            "Correction : la fiche d'un jeu sautait jusqu'aux cartes de graphismes a l'ouverture, puis remontait (le plan arrivait avant les captures et les videos, et les cartes etaient ancrees sur une page encore courte). L'ancrage ne sert plus qu'apres un clic sur une carte.",
            "Plus fluide : l'ouverture d'une fiche ne fige plus la fenetre. La bibliotheque n'est plus reecrite a chaque fiche ouverte (et jamais depuis le fil de l'interface), la liste des jeux reserves aux adultes est gardee en memoire, les vignettes des captures sont lues hors de l'interface, et la bande-annonce ne demarre qu'une fois la fiche posee.",
            "Correction : au lancement d'un jeu, ORION ne se reduit plus apres 1,5 s mais quand la fenetre du jeu apparait (Rocket League et Steam mettaient 40 s : bureau vide). En attendant, « X demarre... » reste affiche.",
            "Nouveau : Rocket League est regle par ORION (TASystemSettings.ini : definition, plein ecran, synchronisation verticale, ombres, filtrage, effets). La limite d'images et l'anticrenelage restent dans le menu du jeu.",
            "Correction : « Reglage utilise » n'apparait plus sur la carte d'un jeu qu'ORION ne regle pas lui-meme (jeu qui gere ses reglages) : la carte est un conseil.",
            "Correction : si le joueur accepte le partage anonyme apres la 12e seconde, l'ouverture de sa premiere session est maintenant comptee.",
            "Correction : ORION plantait quand une rangee de DLC debordait de la fenetre et se redessinait, par exemple au passage en affichage salon avec la manette (signalement n° 5). La rangee peint maintenant ses propres cartes.",
            "Correction : un jeu deplace sur un disque qui ne repond plus (jonction vers un disque externe debranche) arretait net l'analyse de la bibliotheque, la veille des installations et la remise en ordre : plus aucun jeu n'etait reexamine. ORION le note « disque absent pour le moment » et passe au suivant ; le jeu revient avec son disque.",
            "Correction : la manette agit seulement quand ORION est au premier plan. Derriere un jeu, X relancait le jeu (« deja lance » six fois de suite) et Start basculait ORION en affichage salon. Les boutons A et B repondaient aux gachettes LB et RB : les vrais A et B sont lus.",
            "Correction : une seule partie mesuree moins bonne que prevu (enregistrement d'ecran, autre fenetre devant) divisait toutes les estimations du PC, parfois par deux. Une partie hachee ou douteuse ne sert plus de reference, et une seule partie n'abaisse les estimations que de 25 % au plus ; il en faut deux qui s'accordent pour aller plus bas.",
            "Correction : sans recette, ORION supposait que tout jeu regle dans son menu proposait DLSS, FSR ou XeSS (Rocket League se voyait conseiller « Ultra + DLSS »). La super-resolution n'est proposee que si la recette ou la fiche Steam du jeu la cite.",
            "Retouche : sur la carte de joueur, un point du fond place devant le logo ORION se lisait comme une puce ; il a ete retire.",
            "Retouche : dans la fiche d'un jeu, la carte « Votre ecran » retrouve son accent, et la note des modifications prevues ne parle plus du bouton Restaurer, remplace en 2.1.0 par « Redefinir les parametres par defaut ».",
            "Retouche : les jeux gratuits sans DRM ne sont plus annonces « sur Sans DRM », et leur prix habituel s'ecrit comme les autres prix (29,99 $ et non 29.99 USD).",
        ],
    },
    {
        "version": "2.1.1",
        "titre": "On travaille aussi le dimanche 😅",
        "points": [
            "Nouveau : « Valeur estimee de ma bibliotheque ». En haut de la bibliotheque, un clic ouvre la liste des jeux comptes, du plus cher au moins cher, avec la boutique d'ou vient chaque prix, et votre carte de joueur : pseudo et photo de profil si vous le voulez, le total et vos trois jeux les plus chers. « Enregistrer l'image » la range ou vous voulez, prete a poster.",
            "Correction : la consigne d'achat des cles suit votre pays. Elle disait « region Global ou Europe » a tout le monde, alors qu'une cle Europe ne s'active pas aux Etats-Unis. Elle dit maintenant Global ou Europe, Etats-Unis, Royaume-Uni ou Amerique du Nord, selon le pays choisi dans les Reglages.",
        ],
    },
    {
        "version": "2.1.0",
        "titre": "Votre ecran ou votre choix, et tous les jeux",
        "points": [
            "Nouveau : une case DLSS (ou FSR, XeSS) sur les deux cartes de graphismes, quand le jeu et la carte graphique le permettent. Cochee, le jeu gagne des images par seconde ; la carte affiche tout de suite le gain. Pour Baldur's Gate 3, ORION ecrit maintenant le niveau de graphismes du jeu.",
            "Correction : la mesure des images par seconde ne compte plus les ecrans de chargement, ne suit plus le navigateur d'un lanceur au lieu du jeu et ne coupe plus FrameView. Chaque jeu mesure sur votre PC corrige les estimations de tous les autres (Baldur's Gate 3 : 55 i/s estimees, 130 vues).",
            "Anti-triche : ORION n'ecrit jamais pendant une partie (le jeu ou son lanceur ouvert : rien n'est ecrit, la fiche le dit) et ne cherche plus de fichier de reglages dans le dossier d'installation d'un jeu inconnu, la ou les anti-triches verifient les fichiers. Rien n'est jamais injecte dans un jeu.",
            "Correction : Aniimo ne relit pas son niveau general au demarrage mais chaque option. ORION ecrit maintenant le niveau et toutes ses options (illumination, ombres, reflets, occlusion, animations, DLSS), comme le menu du jeu.",
            "Nouveau : ORION regle bien plus de jeux que Steam et Unreal. Nouveaux formats lus et ecrits sur place (XML, KeyValues de Valve, texte « cle valeur ») et recettes pour GTA V et Red Dead Redemption 2, Far Cry, Battlefield et les jeux EA (Frostbite), Skyrim, Fallout et Starfield, Elden Ring, Baldur's Gate 3, The Witcher 3, Apex Legends et Minecraft. Pour un jeu inconnu, ORION cherche son fichier de reglages et n'y touche qu'aux cles sures (definition, plein ecran, synchronisation, limite d'images) ; les niveaux restent au guide. Jamais une cle inventee, jamais une valeur d'une autre forme que celle en place, sauvegarde avant, relecture apres.",
            "Nouveau : les graphismes d'un jeu, en deux cartes et rien d'autre. « Votre ecran » : votre ecran affiche 60, 144, 165 ou 240 images par seconde, ORION lit vos composants et cherche, du plus beau au plus leger (Ultra, Haute, Moyenne, Basse, avec DLSS, FSR ou XeSS quand ca aide), le premier reglage qui tient cet objectif de facon stable ; si meme Basse ne le tient pas, il descend par paliers. Apres une partie mesuree, il repart des images par seconde reellement vues et se corrige tout seul. « Mon choix » : vous choisissez les graphismes (Ultra par defaut) et les images par seconde ; ORION montre ce que ca donne sur votre PC, puis ecrit ce niveau et bride le jeu sur les images demandees. Un clic ecrit tout de suite, apres sauvegarde ; « Redefinir les parametres par defaut » remet le jeu dans l'etat d'avant la premiere intervention d'ORION. Les profils Esport, Detente et Photorealiste disparaissent.",
            "Nouveau : les precommandes dans la page Sorties, et Call of Duty: Modern Warfare 4 a la une. Chaque sortie en precommande sur Steam affiche son prix. La sortie a la une a son bloc prix, relu toutes les 10 minutes : le prix officiel d'abord, puis, a part, la cle Steam verifiee la moins chere chez un revendeur quand elle existe, et l'offre de fidelite de Steam (-10 % sur l'edition Coffre d'armes) si un Call of Duty est dans votre bibliotheque. Le jour de la sortie, une notification, une seule. Kingmakers rejoint la liste, sans date : l'editeur n'en a pas annonce.",
            "Nouveau : quand votre PC retient un jeu, des pieces neuves qui vont dans votre PC. Sous « ce qu'il manque » dans Ma machine, ORION cite des pieces compatibles avec ce qu'il a lu : une carte graphique sur un PC de bureau seulement, un processeur du meme support que le votre, de la memoire du meme type que vos barrettes. Chaque piece ouvre une recherche chez un revendeur de materiel neuf (LDLC, Materiel.net) ; sans compatibilite verifiee, pas de lien. Aucun programme partenaire n'est signe : le jour ou l'un le devient, le lien sera marque « lien partenaire ».",
            "Corrections : la Boutique ne compte plus qu'une vitrine par enseigne, dans la monnaie de votre pays, et un jeu deja possede ouvre « Voir dans ma bibliotheque » ; Ma machine reconnait la memoire « optimisee AMD » sur un processeur Intel (pas de XMP a activer) ; les jeux Ankama se desinstallent par leur lanceur ; la fiche ne saute plus quand on choisit une carte ; les Tutos sont revus.",
        ],
    },
    {
        "version": "2.0.2",
        "titre": "Votre PC en une minute, et les bons pilotes pour votre modele",
        "points": [
            "Nouveau : « Votre PC, en une minute ». A la premiere installation, apres l'analyse, ORION dit en quatre phrases ce qu'il sait faire pour vous : combien de vos jeux tournent en qualite Haute, combien de pilotes sont a mettre a jour, ce que vaut votre bibliotheque, et si des jeux de votre liste d'envies ont baisse. Un bouton par phrase ouvre la page qui va avec ; le bilan reste accessible depuis Ma machine.",
            "Nouveau : une image a partager. Depuis le bilan, « Partager en image » fabrique une carte — « Mon PC fait tourner 38 de mes 52 jeux en qualite Haute », la valeur de la bibliotheque, les pilotes a mettre a jour, processeur et carte graphique — enregistree ou vous voulez et copiee dans le presse-papiers. Rien de personnel dessus.",
            "Correction : sur un portable ou un PC de marque (HP, Dell, Lenovo, Acer...), ORION envoyait chercher les pilotes reseau, audio et stockage chez Intel ou sur la page d'accueil du constructeur. Il renvoie maintenant vers la page support du constructeur pour votre modele, avec le numero de produit qu'elle demande. Merci au joueur qui l'a signale.",
            "Nouveau : ORION regarde ce que Windows Update propose pour votre materiel. Quand un pilote plus recent y attend (reseau, audio, stockage...), le conseil le dit avec la version et ouvre la page des mises a jour facultatives. Quand Windows Update n'a rien, le conseil le dit aussi, avec la date de la verification.",
            "Nouveau : sur un PC Dell, Lenovo ou HP, ORION lit le catalogue de pilotes de votre modele, la source de Dell Command Update, Lenovo System Update et HP Image Assistant. Quand votre reseau, votre audio, votre chipset ou votre carte graphique Intel/AMD a une version plus recente validee pour votre modele, le conseil la nomme, avec sa date, la page officielle et le fichier.",
            "Nouveau : pour une carte NVIDIA, ORION connait la derniere version de votre serie. GeForce 10, 16, 20, 30, 40 ou 50, de bureau ou de portable : « 561.74 installee, 617.42 disponible », avec la page du bon pilote.",
            "Amelioration : les pilotes sont identifies par leur puce, plus par leur nom. Le son HDMI de la carte graphique n'est plus compte comme un pilote audio a mettre a jour, une carte ajoutee dans le PC (reseau ASUS, son Creative, Wi-Fi TP-Link...) renvoie vers son fabricant, et deux cartes de marques differentes donnent deux conseils distincts.",
            "Correction : sur certains jeux Unreal (Ready or Not, Aniimo...), les reglages ecrits par ORION ne changeaient rien, le jeu restait en Epique. Unreal range les reglages sous le nom de la classe propre a chaque jeu ; ORION n'ecrivait que la section generique. Il ecrit maintenant dans la section que le jeu relit, niveaux de qualite compris.",
            "Amelioration : la fenetre « Quoi de neuf » se lit mieux. Un espace entre chaque point, des phrases de tous les jours, et le gras des notes de version rendu dans la fenetre de mise a jour.",
        ],
    },
    {
        "version": "2.0.1",
        "titre": "ORION ne disparait plus derriere votre navigateur",
        "points": [
            "Correction : ORION confondait certains navigateurs (Opera, Chrome, Firefox, Edge...) et logiciels toujours ouverts (Discord, Spotify...) avec des jeux. Il se cachait alors cinq secondes apres le demarrage, comme pendant une partie, et ne revenait plus. Merci au joueur qui l'a signale.",
            "Correction : sur les jeux Unreal (Aniimo, par exemple), les images par seconde n'etaient pas mesurees. ORION regardait le petit programme de lancement au lieu du jeu lui-meme.",
            "Nouveau : un bilan de fluidite, si vous le voulez. A la fermeture, ORION peut envoyer combien de fois l'affichage s'est fige et quelle fonction etait en cause, jamais le jeu, jamais un chemin. La question du partage vous est reposee une fois.",
            "Correction : le rapport d'un signalement indique maintenant la memoire video et les ecrans, et eteindre Windows pendant qu'ORION tourne n'est plus compte comme un arret brutal.",
        ],
    },
    {
        "version": "2.0.0",
        "titre": "Votre PC lu jeu par jeu, et les vrais prix",
        "points": [
            "Nouveau : La lecture de votre PC. Carte graphique, processeur, memoire video et memoire vive ont chacun leur verdict, et un clic sur un jeu explique son niveau, composant par composant.",
            "Amelioration : Les portables aussi. Cartes de portable et puces integrees sont reconnues. Quand c'est le processeur qui plafonne, ORION garde le plus beau niveau au lieu de conseiller de tout baisser.",
            "Nouveau : Les DLC de vos jeux. Ceux que vous avez sont marques « Deja acquis », lus dans les fichiers de Steam de ce PC, sans compte ni mot de passe. Les autres s'affichent a leur meilleur prix.",
            "Nouveau : Le comparateur, sans rien configurer. Plus de trente boutiques agreees et le plus bas prix historique, sans cle a creer. Gamesplanet releve toutes les vingt minutes, Loaded rejoint les revendeurs de cles.",
            "Amelioration : Tout le magasin a portee. Chaque type de jeu a sa page, sans fin : arrive au bout, ORION va chercher les jeux suivants.",
            "Amelioration : Une recherche qui comprend. « bo3 » trouve Black Ops III, « cs2 » Counter-Strike 2. Un jeu absent du PC mene a des jeux du meme esprit.",
            "Amelioration : Des reglages qui s'appliquent tout de suite. Plus de redemarrage. Les Reglages ont une recherche, et la molette ne change plus une valeur en passant dessus.",
            "Amelioration : Plus fluide. Le defilement ne saccade plus, les mises a jour de fond attendent que vous ayez fini votre geste, et le demarrage est plus court.",
        ],
    },
    {
        "version": "1.9.8",
        "titre": "Cyberpunk a la bonne taille",
        "points": [
            "Cyberpunk 2077 : ORION met aussi le jeu a la definition de votre ecran et choisit le mode d'affichage. Avant, le jeu pouvait garder une ancienne definition plus grande que l'ecran : l'image debordait sur le second ecran.",
            "Cyberpunk 2077 : avec une carte NVIDIA, ORION regle aussi le niveau de DLSS selon le profil choisi.",
        ],
    },
    {
        "version": "1.9.7",
        "titre": "Compteur et reglages de Cyberpunk 2077",
        "points": [
            "Cyberpunk 2077 : ORION ecrit desormais ses reglages (textures, ombres, reflets, brouillard, foule, ray tracing) au lieu de seulement vous guider. Il s'en tient aux valeurs que le jeu propose et ne touche ni a la definition, ni a DLSS, ni a vos effets de camera.",
            "Recettes partagees : elles sont de nouveau chargees sous Windows. Elles etaient ecartees a tort, comme si elles avaient ete modifiees.",
            "Compteur anonyme : le service note desormais le pays et la region d'ou vient chaque envoi, jamais la ville ni l'adresse. Le texte de la question ayant change, elle est reposee une fois ; sans nouveau oui, plus rien n'est compte.",
            "Aide : la page « Mes donnees partent-elles quelque part ? » precise que le prix d'un revendeur de cles passe par le service d'ORION, qui ne recoit que le jeu demande.",
        ],
    },
    {
        "version": "1.9.6",
        "titre": "Retouches et filtre des jeux pour adultes",
        "points": [
            "Jeux reserves aux adultes : une seule regle pour toutes les boutiques et plateformes. Ni captures ni videos dans leur fiche, et plus aucune apparition dans la Boutique, les jeux gratuits, les Sorties et la recherche des Envies. Les jeux grand public classes 18 ans ne sont pas concernes.",
            "Curseur des graphismes : un niveau plus leger n'affiche plus jamais moins d'images par seconde qu'un niveau plus lourd.",
            "Moteur du jeu : il n'est reconnu que sur une signature sure. Un jeu d'un autre moteur (Cyberpunk 2077 par exemple) n'est plus pris pour un jeu Unreal.",
            "Les pages ne sautent plus toutes seules : la fiche d'un jeu s'ouvre en haut et y reste.",
            "Petite fenetre : la liste des sources defile au lieu de s'ecraser.",
            "Recherche de la bibliotheque : un mot court ne fait plus remonter de jeux sans rapport.",
            "Captures d'ecran : les fleches du clavier font defiler les images.",
            "Toutes les fenetres : boutons dans la langue d'ORION (« Oui », « Annuler », « Enregistrer »...) au lieu de l'anglais.",
            "Bande-annonce terminee : retour a l'affiche du jeu au lieu d'une image noire.",
            "Jeux gratuits et Ma machine : la recherche accepte les fautes de frappe et les sigles (gta, bg3).",
            "Images par seconde : au-dela de 300, ORION ecrit « plus de 300 » partout (fiche d'un jeu, guide des reglages, Ma machine).",
            "Recherche de la Boutique : un jeu vendu seulement sur Steam n'est plus masque comme une application.",
            "Boutique : dans la fiche d'un jeu, les revendeurs de cles (Instant Gaming, Kinguin) ont leur propre bloc, sous les boutiques officielles et bien separe d'elles. Le bouton « Cles Steam moins cheres » disparait.",
            "Boutique : quand Kinguin vend la cle Steam du jeu moins cher que les boutiques officielles, chez un vendeur tres bien note, ORION affiche ce prix et ouvre directement la bonne fiche. Sinon : « Prix sur le site ».",
            "Boutique : la fiche d'un jeu s'agrandit avec le nombre de boutiques, pour tout lire sans defiler.",
            "Cles moins cheres : le lien Kinguin ecarte les offres « Account », le lien Instant Gaming ne montre plus que les cles PC.",
            "Fermer une page ou ORION ne declenche plus d'« erreur imprevue » : une action differee est abandonnee quand sa fenetre n'existe plus.",
            "Compteur anonyme, seulement si vous dites oui : ORION compte ses ouvertures, les pages utilisees et le nom de la boutique ouverte depuis une offre. Jamais le jeu, jamais rien de personnel. La question est posee une fois ; le choix se change dans Reglages.",
        ],
    },
    {
        "version": "1.9.5",
        "titre": "Reglages : l'ecran d'abord",
        "points": [
            "Boutique : une colonne « Types de jeux » (FPS, MOBA, MMORPG, RTS, RPG, survie...). Dans chaque type, les plus gros jeux d'abord, puis une selection au hasard qui change a chaque ouverture.",
            "Boutique : sous chaque jeu, « Cles Steam moins cheres » ouvre la recherche chez Instant Gaming et Kinguin, deja filtree sur les cles Steam Europe ou Global.",
            "Videos : la bande-annonce passe en tete et demarre toute seule, son coupe. Reglable dans Reglages.",
            "Deux propositions quand votre PC ne peut pas tout avoir : « Le plus d'images » (qualite reduite) ou « La plus belle image » (images reduites, jamais sous 60 par seconde). Un clic choisit, pour chaque jeu.",
            "Avant la premiere partie d'un jeu qu'ORION ne peut pas regler, il conseille un tour dans les reglages et montre la liste.",
            "Mesures partagees entre joueurs : si vous dites oui (ORION pose la question une fois), vos parties mesurees aident les joueurs equipes comme vous, et les leurs vous aident. Rien de personnel n'est envoye ; le choix se change dans Reglages.",
            "Quand ORION ne peut pas regler un jeu lui-meme, la fiche du jeu propose « Voir les reglages » : la liste de ce qu'il faut choisir dans les menus du jeu, ligne par ligne, avec des mots simples. Chaque ligne se coche, et la liste se copie.",
            "Profil « Recommande » : ORION vise maintenant la frequence de votre ecran pour tous les jeux (144 images par seconde sur un ecran 144 Hz), plus seulement 60. Si le materiel ne suit pas, il regle le jeu et la limite d'images sur le plus haut palier que votre PC tient. Chaque niveau du curseur (Basse, Moyenne, Haute, Ultra) est pousse au maximum d'images.",
            "Signaler un probleme : un seul bouton « Envoyer ». Plus besoin de compte ni de fichier a joindre ; le signalement arrive directement a l'equipe.",
        ],
    },
    {
        "version": "1.9.4",
        "titre": "Plus fluide, et une affiche pour GTA VI",
        "points": [
            "Affiches : les jaquettes s'affichent une a une des qu'elles arrivent, celles des jeux visibles en premier, au lieu d'attendre la fin du lot.",
            "Bibliotheque : ouverture bien plus rapide, les jaquettes sont gardees a la taille des tuiles.",
            "Molette : le defilement est plus ample et glisse, dans toutes les pages.",
            "Boutique et Sorties allegees ; la recherche de la bibliotheque attend la fin de la frappe.",
            "Accents : un titre de jeu n'est plus jamais modifie.",
            "Premier lancement : la langue et le pays des prix sont pris sur Windows (anglais et dollars pour un joueur americain).",
            "Prix : chaque montant s'affiche dans la devise du pays choisi ($, £, CHF...), et les jeux gratuits suivent le meme pays.",
            "Anglais : les textes venus de Steam (genres, descriptions, succes) arrivent en anglais.",
            "Sorties : un jeu absent de Steam (GTA VI en tete) affiche maintenant son visuel officiel.",
            "Sorties : une remarque peut accompagner une sortie. GTA VI ouvre le bal.",
        ],
    },
    {
        "version": "1.9.3",
        "titre": "Les accents sont de retour",
        "points": [
            "Toute l'interface affiche desormais les accents du francais : menus, "
            "reglages, conseils, tuto et installateur.",
        ],
    },
    {
        "version": "1.9.2",
        "titre": "Nouvelle adresse : orion-launcher.com",
        "points": [
            "Le site d'ORION demenage sur orion-launcher.com : aide, reglages et "
            "calendrier des sorties pointent vers la nouvelle adresse.",
            "Lien partenaire Gamesplanet, distributeur officiel (le prix ne change pas).",
        ],
    },
    {
        "version": "1.9.1",
        "titre": "Connexion GOG avec Google",
        "points": [
            "Comptes : nouveau bouton « Se connecter avec mon navigateur » pour GOG. "
            "Google refuse les fenetres integrees aux applications ; la connexion se "
            "fait dans votre navigateur habituel, puis ORION reconnait l'adresse de "
            "fin de connexion des que vous la copiez.",
            "Lecteur video : la page de consentement de YouTube n'apparait plus.",
            "Boutique : les lots de formations n'apparaissent plus parmi les jeux.",
            "Conseils : plus de faux conseil sur le chipset ou les peripheriques "
            "audio virtuels.",
        ],
    },
    {
        "version": "1.9.0",
        "titre": "Une boutique, des fiches et des reglages entierement repenses",
        "points": [
            "Boutique repensee : « A la une » pour les gros jeux du moment, « Pour "
            "vous » avec des suggestions tirees de votre bibliotheque (jamais un jeu "
            "deja possede), grosses promos, plus bas historique, gratuits, et une "
            "recherche avec images.",
            "Les jeux gratuits rejoignent la Boutique (onglet « Gratuits en ce "
            "moment »). Logiciels et formations sont masques par defaut : case "
            "« Afficher les applications ».",
            "Fiche de jeu repensee : Infos (studio, editeur, sortie, genres, avis, "
            "succes), succes compacts, captures et videos dans un lecteur integre "
            "(gameplay en francais, lives, bande-annonce). Plus de prix ni de marche "
            "gris pour un jeu deja possede ; le lien Boutique reste la.",
            "Nouveau profil « Recommande » : le plus beau reglage qui tient environ "
            "60 images par seconde sur votre PC, avec DLSS ou FSR quand le jeu le "
            "permet. Un curseur Performances <-> Qualite pour ajuster.",
            "Reglages fiables : etat honnete (« Reglages appliques : 12 sur 14 »), "
            "relus juste avant le lancement, fichiers en lecture seule respectes, et "
            "plus de confirmation a chaque partie.",
            "Ma machine : « Ce que votre PC peut faire » en une seule liste claire, "
            "avec le niveau fluide de chaque jeu, les filtres Tous / Mes jeux / A "
            "acheter et le tri.",
            "Conseils : analyse de tous les pilotes (graphique, chipset, reseau, "
            "audio, stockage, USB, Bluetooth) et des reglages Windows et materiel : "
            "mode Jeu, planification GPU, alimentation, frequence d'ecran, XMP/EXPO, "
            "memoire en simple canal, disque plein, jeux sur disque dur, redemarrage "
            "en attente, fichier d'echange.",
            "Stockage : « Sauvegarder sur un autre disque » (copie verifiee, le jeu "
            "installe n'est jamais modifie, progression en %, restauration et "
            "suppression). « Recalculer » remesure vraiment. Les jeux deplaces avec "
            "l'ancienne fonction peuvent etre ramenes.",
            "Page Sorties : les grosses sorties toutes plateformes avec compte a "
            "rebours, renouvelees toutes seules d'apres les jeux Steam les plus "
            "suivis ; la liste des sorties consoles est mise a jour en ligne.",
            "Joueurs en ligne (Steam) dans la fiche des jeux en ligne, et valeur de "
            "la bibliotheque (prix actuels hors promotion, a titre d'information).",
            "Comptes : connexion Xbox sans cle de securite (le mot de passe est "
            "propose), connexion Google sur GOG mieux geree, avec un message clair "
            "si Google refuse les fenetres integrees.",
            "Titres reconnus sans tenir compte de la ponctuation (« RuneScape - "
            "Dragonwilds » = « RuneScape: Dragonwilds ») ; un jeu sans captures le "
            "dit au lieu de laisser un vide.",
            "Fiabilite : relecture complete du code ; installation et mises a jour "
            "plus sures (jamais dans un dossier existant, ORION toujours relance, "
            "mise a jour reportee apres la partie) ; base de donnees et reglages "
            "proteges contre les fichiers abimes ; aucun secret dans le journal.",
            "Liens partenaires sur certaines boutiques : le prix ne change pas, une "
            "petite commission finance ORION (desactivable dans Reglages).",
        ],
    },
    {
        "version": "1.8.0",
        "titre": "Vos comptes, vos succes et ce que votre PC peut faire",
        "points": [
            "Nouvelle page Comptes : Steam (connexion officielle), GOG et Xbox "
            "(connexions non officielles, signalees comme telles), dans une fenetre "
            "integree. ORION ne voit jamais votre mot de passe : seul un jeton, "
            "chiffre par Windows, est garde sur ce PC.",
            "Profil de chaque plateforme : niveau, XP, badges, Gamerscore, tous les "
            "jeux du compte et leur temps de jeu.",
            "Succes dans la fiche de chaque jeu : obtenus, manquants (les plus "
            "accessibles d'abord) et rarete mondiale.",
            "Les jeux de vos comptes rejoignent la bibliotheque (non installes) et "
            "leur temps de jeu est repris.",
            "Deplacer un jeu vers un autre disque (page Stockage) : copie verifiee "
            "avant de liberer la place, le jeu reste visible pour son launcher. "
            "Retour sur le disque d'origine en un clic.",
            "Ce que votre PC peut faire (page Ma machine) : note de la machine, jeux "
            "fluides en Ultra, Haute et Moyenne, images par seconde attendues et "
            "meilleure offre. Chaque resultat dit sa source : mesure sur votre PC, "
            "mesures de la communaute ou estimation prudente.",
            "Ubisoft, Rockstar, Battle.net, Epic et EA : ce qui est possible et "
            "pourquoi, clairement affiche.",
        ],
    },
    {
        "version": "1.7.2",
        "titre": "La version en bas a gauche, la mise a jour en un clic",
        "points": [
            "La version installee s'affiche en bas a gauche. ORION surveille "
            "la page officielle du projet et l'encart s'allume quand une "
            "nouvelle version sort.",
            "Un clic sur l'encart telecharge la nouvelle version, verifie son "
            "empreinte, l'installe et redemarre ORION. La progression "
            "s'affiche sur place.",
            "Plus de fenetre de mise a jour a chaque demarrage : un rappel "
            "discret suffit. L'encart peut etre masque dans Reglages > Mises "
            "a jour.",
            "Mise a jour tout ou rien : la nouvelle version est preparee a "
            "cote de l'ancienne, puis echangee d'un coup. Si c'est impossible, "
            "l'ancienne reste intacte et ORION redemarre dessus.",
        ],
    },
    {
        "version": "1.7.0",
        "titre": "Mises a jour automatiques, mode discret et bibliotheque complete",
        "points": [
            "Mise a jour automatique : ORION verifie les nouvelles versions, "
            "controle l'empreinte du fichier et s'installe en un clic.",
            "Mode discret en jeu : pendant une partie, meme lancee depuis Steam "
            "ou Epic, ORION met en pause ses taches de fond. Le temps de jeu "
            "est aussi compte hors d'ORION.",
            "Jeux possedes mais non installes (Steam, Epic, GOG) : visibles en "
            "grise, avec un bouton pour les installer.",
            "Bouton « Signaler un probleme » : un rapport sans donnees "
            "personnelles, pret a envoyer. Un plantage n'est plus silencieux.",
            "Sauvegardes de parties copiees dans OneDrive, Google Drive ou "
            "Dropbox si vous le souhaitez.",
            "Recettes communautaires verifiees avant usage : aucune ne peut "
            "ecrire hors du dossier du jeu.",
            "Interface disponible en anglais (Reglages > Langue).",
            "Donnees rangees dans une base locale : plus rapide, et plus de "
            "fichier abime si le PC s'eteint pendant une ecriture.",
            "Connexions mieux reparties entre les services, indicateur « hors "
            "ligne ».",
        ],
    },
    {
        "version": "1.6",
        "titre": "Fiches de jeu enrichies et premiere version publique",
        "points": [
            "Captures d'ecran dans la fiche de chaque jeu, avec visionneuse.",
            "Actualites et mises a jour des jeux traduites integralement en "
            "francais, texte d'origine a un clic.",
            "Encart « marche gris » : revendeurs de cles et leurs risques, "
            "toujours separes des offres sures.",
            "Un jeu desinstalle disparait tout seul, sans relancer d'analyse.",
            "Jaquettes des jeux tout juste sortis enfin recuperees.",
            "Premiere version publique, avec son site et ses telechargements.",
        ],
    },
    {
        "version": "1.5",
        "titre": "La Boutique et une bibliotheque plus propre",
        "points": [
            "Boutique : tous les jeux, le prix le plus bas sur des sites surs "
            "uniquement, actualisee toutes les 12 minutes.",
            "Recherche tolerante : fautes de frappe, phonetique et sigles "
            "(gta, bg3...).",
            "Menu rapide ⋮ sur chaque jaquette.",
            "Doublons fusionnes (un meme jeu vu par Steam et par Windows).",
            "Nouvelle source : Ankama (Dofus, Wakfu).",
            "Envies plus lisibles, jeux « a venir » reconnus.",
            "ORION menage les serveurs de Steam : pause automatique en cas de "
            "refus.",
        ],
    },
    {
        "version": "1.4",
        "titre": "Soutien au projet",
        "points": [
            "Fenetre de soutien avec QR code PayPal.",
            "Lien de don verrouille dans l'application : personne ne peut le "
            "detourner.",
        ],
    },
    {
        "version": "1.3",
        "titre": "Installateur et assistant IA",
        "points": [
            "Installateur autonome : raccourcis, entree dans « Applications "
            "installees », desinstallation propre.",
            "Un seul ORION a la fois : un second lancement rappelle la fenetre.",
            "Assistant IA facultatif (Claude, ChatGPT, Gemini, Mistral, "
            "Ollama) : il apprend un jeu inconnu a ORION et explique les "
            "baisses de performances.",
            "Banniere d'accueil, navigation a la manette et affichage salon.",
        ],
    },
    {
        "version": "1.2",
        "titre": "Jeux gratuits, prix et performances",
        "points": [
            "Jeux gratuits du moment : Epic, Steam, GOG, Prime Gaming et "
            "autres, avec leurs conditions.",
            "Prix, avis et plus bas historique ; liste d'envies avec alertes.",
            "Mesure des images par seconde reelles (PresentMon) et ajustements "
            "proposes.",
            "Sauvegardes de parties archivees et restaurables.",
        ],
    },
    {
        "version": "1.1",
        "titre": "Recettes partagees",
        "points": [
            "Recettes de reglages partagees par la communaute, telechargees "
            "automatiquement.",
        ],
    },
    {
        "version": "1.0",
        "titre": "Premiere version",
        "points": [
            "Detection des jeux Steam, Epic, GOG, Ubisoft, EA, Battle.net, "
            "Xbox, des dossiers de jeux et des programmes installes.",
            "Jaquettes, bannieres et logos recuperes automatiquement.",
            "Analyse du PC : processeur, carte graphique, memoire, ecrans et "
            "tous leurs modes.",
            "Trois profils de lancement (Esport, Detente, Photorealiste) qui "
            "reglent le jeu et l'ecran, avec sauvegarde et restauration.",
            "Temps de jeu par jeu, tri et filtres.",
        ],
    },
]


def entree(version: str) -> dict | None:
    for e in JOURNAL:
        if e["version"] == version:
            return e
    return None


def depuis(version_vue: str) -> list[dict]:
    """Entrees plus recentes que `version_vue` (toutes si vide)."""
    from .maj import version_tuple
    if not version_vue:
        return JOURNAL[:1]
    vue = version_tuple(version_vue)
    return [e for e in JOURNAL if version_tuple(e["version"]) > vue]
