"""Marche gris des cles de jeux : liens de recherche, et les risques en clair.

ORION ne classe jamais ces sites comme « meilleur prix » (voir
`plugins/boutique/confiance.py`). Mais ils existent, beaucoup de joueurs
les utilisent, et mieux vaut y aller en connaissant les risques qu'en les
decouvrant. La fiche d'un jeu propose donc des liens de recherche directs,
dans un encart separe et clairement signale.

Aucun prix n'est releve sur ces sites : ils n'offrent pas d'acces public,
et ORION n'aspire pas leurs pages.

Liens partenaires : voir `orion/affiliation.py` (identifiants dans le code,
jamais modifiables depuis l'application ; rien n'est ajoute sans identifiant).
"""
from __future__ import annotations

import re
import urllib.parse
from dataclasses import dataclass

from .affiliation import affilier

MARKETPLACE = "Place de marche"
REVENDEUR = "Revendeur de cles"
COMPARATEUR = "Comparateur"


@dataclass(frozen=True)
class Site:
    id: str
    nom: str
    modele: str          # adresse de recherche, {q} = titre encode
    genre: str
    note: str


SITES: tuple[Site, ...] = (
    # recherche limitee aux cles PC (platform[]=1) : sans ce filtre, les
    # cles Xbox, PlayStation et Switch se melent aux resultats. Le filtre
    # « Steam seul » (type[]=steam) a ete ecarte : il cache les cles GOG
    # officielles (Cyberpunk 2077). Verifie sur le site le 4 octobre 2026.
    # 10 octobre (trouve par l'auteur) : « product_types[]=game » ne garde
    # que les jeux (ni DLC, ni monnaie de jeu comme les CoD Points, ni
    # abonnement) et « os[]=1 » les versions Windows ; « query » est le nom
    # que le site donne lui-meme a la recherche. Plates-formes d'activation
    # PC (« type[] ») : la liste complete donnee par l'auteur, Steam compris
    # (une liste qui l'oublierait cacherait les cles Steam). Une plate-forme
    # que le site ajouterait plus tard serait cachee : a ajouter ici.
    # « preorder » (10 octobre) : sans lui, un jeu pas encore sorti n'a aucun
    # resultat et Instant Gaming renvoie sur sa page d'accueil (constate sur
    # Castlevania: Belmont's Curse, Phantom Blade Zero, Dawn of War IV).
    Site("instant-gaming", "Instant Gaming",
         "https://www.instant-gaming.com/fr/rechercher/?query={q}&platform%5B%5D=1"
         "&type%5B%5D=Steam&type%5B%5D=Rockstar&type%5B%5D=Ubisoft+Connect"
         "&type%5B%5D=Microsoft+Store&type%5B%5D=Instant+Gaming&type%5B%5D=GOG.com"
         "&type%5B%5D=Epic+Games&type%5B%5D=EA+App&type%5B%5D=Battle.net"
         "&product_types%5B%5D=game&product_types%5B%5D=preorder&os%5B%5D=1", REVENDEUR,
         "Vendeur unique (pas de particuliers), le plus sur du marche gris."),
    Site("eneba", "Eneba", "https://www.eneba.com/fr/store/all?text={q}",
         MARKETPLACE, "Vendeurs notes ; frais ajoutes au paiement."),
    # Recherche par le texte seul, sans aucun filtre du site. Verifie sur
    # Kinguin le 4 octobre 2026 :
    #  - le filtre de region (regions=1,3) cachait des jeux entiers :
    #    S.T.A.L.K.E.R. 2 rendait 0 resultat alors que 46 offres existent
    #    (leurs fiches ne portent pas la region attendue) ;
    #  - aucun filtre ne retire les offres « Steam Account », que Kinguin
    #    met en tete (Cyberpunk 2077, Baldur's Gate 3).
    # Regle : un filtre qui peut cacher le jeu est pire que pas de filtre.
    # « CD Key » dans la recherche ecarte les comptes et les « Gift », qui ne
    # portent pas ces mots dans leur nom. Pas « Steam CD Key » : cela cachait
    # les jeux vendus en cle Rockstar, Battle.net ou GOG (Red Dead
    # Redemption 2 : 2 resultats au lieu de 78 ; Call of Duty : 0 au lieu de
    # 74). Essaye sur S.T.A.L.K.E.R. 2, Red Dead Redemption 2, Call of Duty
    # Black Ops 6, Cyberpunk 2077 et Baldur's Gate 3 : le jeu sort, 0 compte.
    # Depuis le 7 octobre 2026 (essai de l'auteur, refait sur S.T.A.L.K.E.R. 2,
    # Red Dead Redemption 2, Cyberpunk 2077, Black Ops 6, Far Cry New Dawn) :
    # deux filtres du site qui, eux, ne cachent pas le jeu. « platforms » :
    # toutes les plates-formes PC (Steam, GOG, Rockstar, Battle.net, Ubisoft,
    # EA...), donc plus de versions Xbox ou PlayStation ; « countries » : cle
    # activable dans le pays du joueur ; « hideUnavailable » : pas de fiche en
    # rupture. S.T.A.L.K.E.R. 2 : 15 fiches, toutes en cle Steam PC.
    Site("kinguin", "Kinguin",
         "https://www.kinguin.net/listing?platforms=25,3,1,18,15,26,23,4,27,22,2,5"
         "&countries={pays}&active=1&hideUnavailable=1&type=all&phrase={q}+CD+Key"
         "&page=0&size=50&sort=bestseller.score,DESC",
         MARKETPLACE, "Protection acheteur payante proposee en option."),
    Site("g2a", "G2A", "https://www.g2a.com/fr/search?query={q}", MARKETPLACE,
         "Le plus grand, et le plus critique par les editeurs."),
    Site("gamivo", "Gamivo", "https://www.gamivo.com/search/{q}", MARKETPLACE,
         "Prix souvent bas avec l'abonnement SMART."),
    # « PC » dans la recherche : sans lui, Loaded met en tete les versions
    # Xbox et PlayStation (F1 25 : 3 versions PC noyees sous 11 versions
    # console). Ses fiches PC portent toutes ce mot. Pas le filtre « Steam »
    # du site : il cacherait les cles GOG, EA App ou Rockstar, seules en
    # vente pour certains jeux (Cyberpunk 2077, Red Dead Redemption 2).
    # Essaye le 6 octobre 2026 sur F1 25, Black Ops 4, Cyberpunk 2077 et Red
    # Dead Redemption 2 : que des versions PC, le jeu sort a chaque fois.
    Site("loaded", "Loaded (ex-CDKeys)",
         "https://www.loaded.com/catalogsearch/result/?q={q}+PC", REVENDEUR,
         "Vendeur unique (pas de particuliers) ; verifier la region de la cle."),
    Site("driffle", "Driffle", "https://driffle.com/search?q={q}", MARKETPLACE,
         "Place de marche recente."),
    Site("allkeyshop", "AllKeyShop",
         "https://www.allkeyshop.com/blog/catalogue/search-{q}/", COMPARATEUR,
         "Compare les prix de tous ces sites, frais compris."),
    Site("ggdeals", "GG.deals", "https://gg.deals/search/?title={q}", COMPARATEUR,
         "Separe clairement boutiques officielles et revendeurs de cles."),
)

# --------------------------------------------------------------------------
# Revendeurs de cles retenus
# --------------------------------------------------------------------------
#: Les seuls revendeurs de cles qu'ORION propose : ceux que l'auteur utilise
#: lui-meme depuis des annees sans incident, et Loaded (ajoute le 5 octobre
#: 2026, a sa demande, une fois ses prix disponibles). Toujours apres les
#: boutiques officielles, jamais comme « meilleur prix ».
RETENUS = ("instant-gaming", "kinguin", "loaded")

#: la regle a suivre sur ces sites, affichee a cote des liens. La region
#: de la cle depend du pays du joueur (11 octobre 2026 : un joueur americain
#: lisait « Global ou Europe », et une cle Europe ne s'active pas aux
#: Etats-Unis). Kinguin filtre deja par pays (« countries ») ; Instant Gaming
#: et Loaded non : la consigne est la seule garde.
CONSIGNES = {
    "europe": "Prenez une cle Steam, region Global ou Europe. Jamais d'offre « Gift » ni « Account ».",
    "US": "Prenez une cle Steam, region Global ou Etats-Unis (US). Jamais d'offre « Gift » ni « Account ».",
    "CA": "Prenez une cle Steam, region Global ou Amerique du Nord. Jamais d'offre « Gift » ni « Account ».",
    "GB": "Prenez une cle Steam, region Global ou Royaume-Uni (UK). Jamais d'offre « Gift » ni « Account ».",
    "autre": "Prenez une cle Steam, region Global ou celle de votre pays. Jamais d'offre « Gift » ni « Account ».",
}
#: pays de la liste des prix dont les cles « Europe » s'activent
PAYS_EUROPE = {"FR", "BE", "LU", "DE", "ES", "IT", "CH", "NL", "AT", "PT", "IE"}
CONSIGNE = CONSIGNES["europe"]


def consigne(pays: str | None = None) -> str:
    """La consigne de region pour le pays du joueur (reglage « market.country »)."""
    code = (pays or _pays()).upper()
    if code in PAYS_EUROPE:
        return CONSIGNES["europe"]
    return CONSIGNES.get(code, CONSIGNES["autre"])


def liens_revendeurs(titre: str) -> list[tuple[Site, str]]:
    """(revendeur, recherche du jeu) pour les revendeurs retenus, avec
    l'identifiant partenaire. Liste vide si l'option est coupee."""
    from .core.config import CONFIG
    if not (titre or "").strip() or not CONFIG.get("marche_gris.afficher", True):
        return []
    return liens(titre, tuple(s for s in SITES if s.id in RETENUS))


# --------------------------------------------------------------------------
# Boutiques officielles (cles vendues avec l'accord des editeurs)
# --------------------------------------------------------------------------
BOUTIQUE_OFFICIELLE = "Boutique officielle"

#: recherche directe du jeu sur les revendeurs officiels. Le lien passe par
#: `affiliation.affilier` : l'identifiant partenaire n'est ajoute que pour
#: un programme confirme (Gamesplanet : accepte, identifiant a venir).
OFFICIELLES: tuple[Site, ...] = (
    Site("gamesplanet", "Gamesplanet", "https://fr.gamesplanet.com/search?query={q}",
         BOUTIQUE_OFFICIELLE, "Revendeur officiel, cles fournies par les editeurs."),
    Site("gog", "GOG", "https://www.gog.com/fr/games?query={q}", BOUTIQUE_OFFICIELLE,
         "Boutique officielle, jeux sans DRM."),
    Site("humble", "Humble Bundle", "https://www.humblebundle.com/store/search?search={q}",
         BOUTIQUE_OFFICIELLE, "Revendeur officiel ; une part finance des associations."),
    Site("fanatical", "Fanatical", "https://www.fanatical.com/fr/search?search={q}",
         BOUTIQUE_OFFICIELLE, "Revendeur officiel de cles Steam."),
    Site("gmg", "Green Man Gaming", "https://www.greenmangaming.com/search?query={q}",
         BOUTIQUE_OFFICIELLE, "Revendeur officiel de cles Steam."),
)


def liens_officiels(titre: str) -> list[tuple[Site, str]]:
    """(boutique, adresse de recherche du jeu) sur les revendeurs officiels,
    avec l'identifiant partenaire quand le programme est confirme."""
    return liens(titre, OFFICIELLES)


def lien_officiel(site_id: str, titre: str) -> str:
    """Recherche du jeu sur une boutique officielle (« gamesplanet »...).

    A ouvrir avec `affiliation.ouvrir` : l'identifiant partenaire s'y ajoute
    des qu'il est renseigne dans `affiliation.PROGRAMMES`, sans autre
    changement ici."""
    site = next((s for s in OFFICIELLES if s.id == site_id), None)
    return liens(titre, (site,))[0][1] if site is not None and (titre or "").strip() else ""


def lien_gamesplanet(titre: str, appid="") -> str:
    """Recherche du jeu chez Gamesplanet, ou vide quand on sait qu'il ne le
    vend pas (son catalogue complet est connu, voir `prix_gamesplanet.vendu`)."""
    from . import prix_gamesplanet
    if prix_gamesplanet.vendu(appid, titre) is False:
        return ""
    return lien_officiel("gamesplanet", titre)


def recherche(titre: str) -> str:
    """Titre nettoye pour une recherche (sans ™ ®, sans « Edition GOTY »,
    sans separateurs : « RuneScape - Dragonwilds » -> « RuneScape Dragonwilds »)."""
    from .core.recherche import titre_recherche
    t = re.sub(r"[™®©]", "", titre or "")
    t = re.sub(r"\s*[-:–]\s*(game of the year|goty|deluxe|ultimate|"
               r"definitive|complete|gold|standard) edition\s*$", "", t, flags=re.I)
    return titre_recherche(t)


def _pays() -> str:
    """Pays du joueur (« FR », « BE »...) pour les filtres d'activation."""
    try:
        from .core import region
        code = (region.pays() or "FR").upper()[:2]
    except Exception:
        code = "FR"
    return code if len(code) == 2 and code.isalpha() else "FR"


def liens(titre: str, sites: tuple[Site, ...] | None = None) -> list[tuple[Site, str]]:
    """(site, adresse de recherche) pour chaque site, dans l'ordre de SITES."""
    q = recherche(titre)
    out = []
    for site in SITES if sites is None else sites:
        if "{q}/" in site.modele:                       # AllKeyShop : search-mot+mot/
            encode = urllib.parse.quote(q.lower().replace(" ", "+"), safe="+")
        elif "?" not in site.modele:                    # recherche dans le chemin : %20
            encode = urllib.parse.quote(q, safe="")
        else:
            encode = urllib.parse.quote_plus(q)
        url = site.modele.replace("{q}", encode).replace("{pays}", _pays())
        out.append((site, affilier(url)))
    return out
