"""Fenetre d'installation et de desinstallation d'ORION.

Un seul executable, une seule fenetre, trois informations : ou le programme
va s'installer, s'il faut un raccourci sur le bureau, et ce qui se passe
ensuite. Rien d'autre n'est demande.

L'application compilee voyage a l'interieur de cet executable : PyInstaller
la depose dans un dossier temporaire au lancement (`sys._MEIPASS`), et
l'installateur la recopie a l'emplacement choisi.

Il sert aussi de desinstalleur : lance avec `--desinstaller`, il retire les
raccourcis, la declaration Windows et le programme, en laissant a
l'utilisateur le choix de garder ou non sa bibliotheque.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtGui import QIcon, QPixmap
from PySide6.QtWidgets import (QApplication, QCheckBox, QFileDialog, QFrame,
                               QHBoxLayout, QLabel, QLineEdit, QMessageBox,
                               QProgressBar, QPushButton, QVBoxLayout, QWidget)

from . import installation as inst
from ..core import lancement
from ..ui.theme import build_qss
from ..version import APP_NAME, APP_TAGLINE, APP_VERSION

#: dossier ou PyInstaller depose l'application a installer
PAYLOAD_NAME = "programme"


def payload_dir() -> Path:
    """Dossier contenant l'application compilee a recopier."""
    base = getattr(sys, "_MEIPASS", "")
    if base:
        return Path(base) / PAYLOAD_NAME
    # hors executable : utile pour essayer l'installateur pendant le
    # developpement, avec le resultat d'une compilation a cote.
    return Path(__file__).resolve().parents[2] / "dist" / APP_NAME


def asset(name: str) -> Path:
    from ..core.paths import ASSETS_DIR
    return ASSETS_DIR / name


class Worker(QThread):
    """Execute l'installation sans figer la fenetre."""

    step = Signal(str, int)
    done = Signal(bool, str)

    def __init__(self, action, **kwargs) -> None:
        super().__init__()
        self.action, self.kwargs = action, kwargs

    def run(self) -> None:
        try:
            ok, message = self.action(progress=self.step.emit, **self.kwargs)
        except Exception as exc:                       # pragma: no cover
            ok, message = False, str(exc)
        self.done.emit(ok, message)


class Fenetre(QWidget):
    """Fenetre unique de l'installateur."""

    def __init__(self, mode: str = "installer") -> None:
        super().__init__()
        self.mode = mode
        self.worker: Worker | None = None
        self.setWindowTitle(f"{APP_NAME} — "
                            + ("desinstallation" if mode == "desinstaller"
                               else "installation"))
        self.setFixedSize(640, 520)
        icone = asset("orion.ico")
        if icone.exists():
            self.setWindowIcon(QIcon(str(icone)))

        # le fond ne vise que la fenetre elle-meme : une regle QWidget
        # generale peindrait aussi un rectangle derriere chaque libelle de
        # la banniere illustree.
        self.setObjectName("FenetreInstall")
        self.setAutoFillBackground(True)
        self.setStyleSheet("QWidget#FenetreInstall { background: #0A0D14; }")

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        root.addWidget(self._banniere())

        corps = QWidget()
        # la fenetre n'est ni QMainWindow ni QDialog : elle ne recoit pas le
        # fond du theme, on le lui donne explicitement.
        corps.setObjectName("Corps")
        corps.setStyleSheet("QWidget#Corps { background: #0A0D14; }")
        lay = QVBoxLayout(corps)
        lay.setContentsMargins(30, 22, 30, 22)
        lay.setSpacing(14)
        root.addWidget(corps, 1)

        if mode == "desinstaller":
            self._corps_desinstallation(lay)
        else:
            self._corps_installation(lay)

        self.barre = QProgressBar()
        self.barre.setTextVisible(False)
        self.barre.setVisible(False)
        lay.addWidget(self.barre)

        self.etat = QLabel("")
        self.etat.setObjectName("Faint")
        self.etat.setWordWrap(True)
        lay.addWidget(self.etat)
        lay.addStretch(1)

        boutons = QHBoxLayout()
        boutons.addStretch(1)
        self.fermer = QPushButton("Annuler")
        self.fermer.setObjectName("Ghost")
        self.fermer.clicked.connect(self.close)
        boutons.addWidget(self.fermer)

        self.valider = QPushButton("Desinstaller" if mode == "desinstaller"
                                   else "Installer")
        self.valider.clicked.connect(self._lancer)
        boutons.addWidget(self.valider)
        lay.addLayout(boutons)

    # ------------------------------------------------------------------
    def _banniere(self) -> QWidget:
        """En-tete illustre : le fond de l'application, son nom, sa version."""
        cadre = QFrame()
        cadre.setObjectName("Banniere")
        cadre.setFixedHeight(132)
        fond = asset("fond.jpg")
        if fond.exists():
            cadre.setStyleSheet(
                "QFrame#Banniere { border: none; border-bottom: 1px solid "
                "#232B3D; background-image: url('%s'); "
                "background-position: center; }" % str(fond).replace("\\", "/"))
        lay = QHBoxLayout(cadre)
        lay.setContentsMargins(26, 0, 26, 0)
        lay.setSpacing(16)

        logo = QLabel()
        marque = asset("orion.png")
        if marque.exists():
            logo.setPixmap(QPixmap(str(marque)).scaled(
                62, 62, Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation))
        lay.addWidget(logo)

        textes = QVBoxLayout()
        textes.setSpacing(2)
        titre = QLabel(APP_NAME)
        titre.setStyleSheet("font-size: 27px; font-weight: 700; "
                            "letter-spacing: 7px; color: #E7ECF5;")
        textes.addWidget(titre)
        sous = QLabel(f"{APP_TAGLINE}   ·   version {APP_VERSION}")
        sous.setStyleSheet("color: #AAB4C8; font-size: 12px; "
                           "letter-spacing: 2px;")
        textes.addWidget(sous)
        lay.addLayout(textes)
        lay.addStretch(1)
        return cadre

    # ------------------------------------------------------------------
    def _corps_installation(self, lay: QVBoxLayout) -> None:
        intro = QLabel(
            "ORION détecte vos jeux sur toutes les plateformes, récupère "
            "leurs jaquettes et les lance avec les réglages graphiques "
            "calculés pour votre machine.\n\n"
            "Rien n'est installé ailleurs que dans votre compte : ni droits "
            "administrateur, ni service. Le lancement au démarrage de Windows "
            "se décoche ici ou, plus tard, dans les Réglages.")
        intro.setObjectName("Dim")
        intro.setWordWrap(True)
        lay.addWidget(intro)

        ligne = QHBoxLayout()
        ligne.addWidget(QLabel("Dossier"))
        self.dossier = QLineEdit(str(inst.default_target()))
        ligne.addWidget(self.dossier, 1)
        parcourir = QPushButton("Parcourir")
        parcourir.setObjectName("Ghost")
        parcourir.clicked.connect(self._choisir)
        ligne.addWidget(parcourir)
        lay.addLayout(ligne)

        self.raccourci = QCheckBox("Créer un raccourci sur le bureau")
        self.raccourci.setChecked(True)
        lay.addWidget(self.raccourci)

        self.demarrage = QCheckBox("Lancer ORION au démarrage de Windows")
        self.demarrage.setToolTip(
            "À l'ouverture de votre session, ORION s'ouvre réduit dans la barre "
            "des tâches. Se change ensuite dans Réglages, ou dans le "
            "Gestionnaire des tâches (Applications de démarrage).")
        self.demarrage.setChecked(_demarrage_voulu())
        lay.addWidget(self.demarrage)

        self.ouvrir = QCheckBox("Lancer ORION à la fin de l'installation")
        self.ouvrir.setChecked(True)
        lay.addWidget(self.ouvrir)

        if inst.is_installed():
            deja = QLabel("Une version est déjà installée : elle sera "
                          "remplacée. Votre bibliothèque, vos réglages et vos "
                          "sauvegardes sont conservés.")
            deja.setObjectName("Faint")
            deja.setWordWrap(True)
            lay.addWidget(deja)

    def _corps_desinstallation(self, lay: QVBoxLayout) -> None:
        intro = QLabel(
            f"{APP_NAME} va être retiré de cette machine : le programme, ses "
            "raccourcis et sa déclaration dans Windows.\n\n"
            "Aucun jeu ne sera touché : ORION ne désinstalle jamais un jeu "
            "de lui-même.")
        intro.setObjectName("Dim")
        intro.setWordWrap(True)
        lay.addWidget(intro)

        self.donnees = QCheckBox(
            "Supprimer aussi ma bibliothèque, mes réglages et mes "
            "sauvegardes de configuration")
        lay.addWidget(self.donnees)

        detail = QLabel(f"Elles se trouvent dans {inst.DATA_DIR}.")
        detail.setObjectName("Faint")
        detail.setWordWrap(True)
        lay.addWidget(detail)

    # ------------------------------------------------------------------
    def _choisir(self) -> None:
        choisi = QFileDialog.getExistingDirectory(
            self, "Dossier d'installation", self.dossier.text())
        cible = dossier_cible(choisi) if choisi else None
        if cible is not None:
            self.dossier.setText(str(cible))

    def _lancer(self) -> None:
        self.valider.setEnabled(False)
        self.fermer.setEnabled(False)
        self.barre.setVisible(True)
        self.barre.setRange(0, 100)

        if self.mode == "desinstaller":
            self.worker = Worker(inst.uninstall,
                                 remove_data=self.donnees.isChecked())
        else:
            source = payload_dir()
            if not (source / inst.EXE_NAME).exists():
                self._echec(f"Programme introuvable ({source}).")
                return
            cible = dossier_cible(self.dossier.text())
            if cible is None:
                self._echec("Indiquez un dossier complet, par exemple "
                            f"{inst.default_target()}.")
                return
            self.dossier.setText(str(cible))
            self.worker = Worker(inst.install, payload=source, target=cible,
                                 desktop_shortcut=self.raccourci.isChecked(),
                                 demarrage=self.demarrage.isChecked())
        self.worker.step.connect(self._avance)
        self.worker.done.connect(self._fini)
        self.worker.start()

    def _avance(self, message: str, percent: int) -> None:
        self.etat.setText(message)
        self.barre.setValue(max(1, percent))

    def _echec(self, message: str) -> None:
        self.barre.setVisible(False)
        self.etat.setText(message)
        self.valider.setEnabled(True)
        self.fermer.setEnabled(True)

    def _fini(self, ok: bool, message: str) -> None:
        self.fermer.setEnabled(True)
        if not ok:
            self._echec(message)
            return
        if self.mode == "desinstaller":
            QMessageBox.information(
                self, APP_NAME,
                f"{APP_NAME} a été retiré de cette machine.\n\n{message}")
            self.close()
            return

        self.etat.setText(f"Installé dans {message}")
        self.fermer.setText("Fermer")
        self.valider.setVisible(False)
        if self.ouvrir.isChecked():
            lancer_detache([str(Path(message) / inst.EXE_NAME)])
        self.close()


def _demarrage_voulu() -> bool:
    """Cochee d'office (decision de l'auteur, 12 octobre 2026) ; une
    reinstallation reprend le choix deja fait, et un « non » reste un non."""
    if not inst.is_windows():
        return True
    try:
        from .. import demarrage
        if not demarrage.inscrit():
            return True
        return not demarrage.coupe_dans_le_gestionnaire()
    except Exception:
        return True


def dossier_cible(texte: str) -> Path | None:
    """Dossier d'installation reellement utilise pour un choix de l'utilisateur.

    Le dossier est remplace en entier par l'installation : ORION s'installe
    donc toujours dans un sous-dossier « ORION » (« D:\\Jeux » devient
    « D:\\Jeux\\ORION »), comme le fait deja le bouton Parcourir. Un chemin
    vide ou relatif est refuse (None)."""
    texte = (texte or "").strip().strip('"')
    if not texte:
        return None
    chemin = Path(os.path.expandvars(os.path.expanduser(texte)))
    if not chemin.is_absolute():
        return None
    if chemin.name.lower() != APP_NAME.lower():
        chemin = chemin / APP_NAME
    return chemin


def reinitialiser_dll() -> None:
    """Rend a Windows son chemin de recherche des DLL par defaut.

    Un programme compile avec PyInstaller ajoute son propre dossier a ce
    chemin, et les programmes qu'il lance en heritent. Sans cette remise a
    zero, l'installateur lance par ORION chargeait `VCRUNTIME140.dll`
    depuis le dossier d'ORION... et verrouillait ainsi le fichier qu'il
    devait remplacer (mise a jour 1.7.0 -> 1.7.1).
    """
    lancement.reinitialiser_dll()


def environnement_propre() -> dict:
    """Variables d'environnement sans les marqueurs internes de PyInstaller
    (voir `orion.core.lancement`)."""
    return lancement.environnement_propre()


def lancer_detache(args: list[str]) -> bool:
    """Lance un programme independant, sans heritage de DLL ni de dossier :
    son dossier courant est le dossier neutre (donnees d'ORION), jamais le
    dossier d'installation qu'une mise a jour devra renommer."""
    options = {}
    if sys.platform.startswith("win"):
        options["creationflags"] = 0x00000008 | 0x00000200   # DETACHED | NEW_GROUP
    try:
        lancement.popen_propre(args, **options)
        return True
    except Exception:
        inst.log.exception("Lancement impossible : %s", args[0])
        return False


def silencieux(mode: str) -> int:
    """Installe ou desinstalle sans ouvrir de fenetre, avec les valeurs par defaut.

    Sert aux mises a jour : l'utilisateur a deja choisi son emplacement la
    premiere fois, il n'y a rien a lui redemander. C'est aussi ce que
    Windows appelle quand il retire l'application sans interface
    (`QuietUninstallString`).

    La desinstallation silencieuse ne touche jamais aux donnees : personne
    n'est la pour confirmer, donc on conserve.
    """
    if mode == "desinstaller":
        ok, message = inst.uninstall(remove_data=False)
        print(("OK : " if ok else "ECHEC : ") + str(message))
        return 0 if ok else 1

    # Lance par ORION pour une mise a jour : on se relance une fois, proprement.
    # Les ORION jusqu'a la 1.7.1 transmettent leur chemin de DLL a
    # l'installateur, qui garderait alors un fichier d'ORION verrouille
    # pendant toute l'installation.
    if ("--attendre" in sys.argv and "--relance-propre" not in sys.argv
            and getattr(sys, "frozen", False) and sys.platform.startswith("win")):
        inst.log.info("Mise à jour : relance propre de l'installateur")
        if lancer_detache([sys.executable] + sys.argv[1:] + ["--relance-propre"]):
            return 0          # la copie relancee se charge de tout (et de relancer ORION)

    # Quoi qu'il arrive ensuite (programme absent de l'installateur,
    # exception imprevue), ORION est relance : l'utilisateur ne doit jamais
    # se retrouver sans ORION apres une mise a jour.
    ok, message = False, "installation interrompue"
    cible: Path | None = None
    attente = {"faite": False}

    def attendre_orion() -> None:
        # mise a jour lancee depuis ORION : attendre qu'il soit ferme, sans
        # quoi Windows refuse de remplacer un programme en cours d'execution,
        # et un ORION relance trop tot s'effacerait devant l'ancien (une
        # seule instance a la fois) qui finit de se fermer
        if attente["faite"]:
            return
        attente["faite"] = True
        pid = _argument("--attendre")
        if pid.isdigit():
            try:
                if not attendre_fin(int(pid)):
                    inst.log.warning("ORION (pid %s) ne s'est pas fermé à temps", pid)
            except Exception:
                inst.log.exception("Attente de la fermeture d'ORION impossible")
    try:
        attendre_orion()
        cible = cible_silencieuse()
        source = payload_dir()
        if not (source / inst.EXE_NAME).exists():
            message = f"Programme introuvable ({source})."
            inst.log.error("Installation silencieuse : programme introuvable (%s)", source)
            return 1
        inst.log.info("Installation silencieuse de %s %s dans %s",
                      APP_NAME, APP_VERSION, cible)
        ok, message = inst.install(payload=source, target=cible,
                                   desktop_shortcut=_raccourci_bureau_voulu())
        if not ok:
            inst.log.error("Installation silencieuse échouée : %s", message)
        return 0 if ok else 1
    except Exception as exc:
        ok, message = False, f"Installation impossible : {exc}"
        inst.log.exception("Installation silencieuse interrompue")
        return 1
    finally:
        if "--relancer" in sys.argv:
            # en cas d'echec, l'ancienne version est intacte : on la relance
            # (avec --maj-echouee) pour que l'utilisateur la retrouve
            attendre_orion()
            _relancer_orion(cible, ok)
        try:
            print(("OK : " if ok else "ECHEC : ") + str(message))
        except Exception:
            pass


def cible_silencieuse() -> Path:
    """Dossier a mettre a jour : celui transmis par ORION (`--cible`), sinon
    celui ou ORION est installe. Jamais le dossier par defaut a l'aveugle :
    une installation placee ailleurs etait doublee au lieu d'etre remplacee."""
    texte = _argument("--cible").strip().strip('"')
    if texte and not texte.startswith("--"):
        chemin = Path(os.path.expandvars(texte))
        if chemin.is_absolute():
            return chemin
        inst.log.warning("Dossier --cible ignoré (chemin relatif) : %s", texte)
    return inst.dossier_installe()


def _relancer_orion(cible: Path | None, ok: bool) -> bool:
    """Relance ORION apres une mise a jour (reussie ou non). Ne leve jamais."""
    try:
        candidats = []
        if cible is not None:
            candidats.append(Path(cible) / inst.EXE_NAME)
        candidats.append(inst.installed_exe())
        for exe in candidats:
            if exe.exists():
                relancer(exe, apres_maj=ok)
                return True
        inst.log.error("ORION introuvable après la mise à jour : rien à relancer")
    except Exception:
        inst.log.exception("Relance d'ORION impossible")
    return False


def _argument(nom: str) -> str:
    """Valeur qui suit `nom` sur la ligne de commande (« » si absent)."""
    try:
        i = sys.argv.index(nom)
        return sys.argv[i + 1]
    except (ValueError, IndexError):
        return ""


def _raccourci_bureau_voulu() -> bool:
    """Une mise a jour ne recree pas un raccourci que l'utilisateur a
    supprime : on ne le pose que s'il existait deja (ou premiere pose)."""
    try:
        lien = inst.desktop_dir() / f"{APP_NAME}.lnk"
        return lien.exists() or not inst.is_installed()
    except Exception:
        return False


def attendre_fin(pid: int, secondes: int = 90) -> bool:
    """Attend la fin du processus `pid`. Vrai s'il s'est bien arrete."""
    import time
    if sys.platform.startswith("win"):
        try:
            import ctypes
            k32 = ctypes.windll.kernel32
            h = k32.OpenProcess(0x00100000, False, pid)        # SYNCHRONIZE
            if not h:
                return True                                   # deja termine
            try:
                return k32.WaitForSingleObject(h, secondes * 1000) == 0
            finally:
                k32.CloseHandle(h)
        except Exception:
            pass
    fin = time.time() + secondes
    while time.time() < fin:
        try:
            os.kill(pid, 0)
        except OSError:
            return True
        time.sleep(0.5)
    return False


def relancer(exe, apres_maj: bool = True) -> None:
    lancer_detache([str(exe)] + (["--apres-maj"] if apres_maj else ["--maj-echouee"]))


def main(mode: str = "") -> int:
    """Ouvre la fenetre. `mode` vaut « installer » ou « desinstaller »."""
    mode = mode or ("desinstaller" if "--desinstaller" in sys.argv
                    else "installer")
    if "--silencieux" in sys.argv:
        return silencieux(mode)
    app = QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setStyleSheet(build_qss())
    fenetre = Fenetre(mode)
    fenetre.show()
    return app.exec()
