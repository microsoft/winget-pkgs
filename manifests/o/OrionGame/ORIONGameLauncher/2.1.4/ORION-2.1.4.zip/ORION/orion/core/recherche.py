"""Recherche tolerante : fautes de frappe, accents, et orthographe a l'oreille.

Un joueur cherche « cyberpounk », « assassin creed » ou « wakfou ». Une
recherche par sous-chaine exacte ne trouve rien, et l'utilisateur en conclut
que le jeu n'est pas la.

Trois niveaux, du plus sur au plus tolerant :

1. **exact** : la chaine normalisee (sans accents, casse ni ponctuation)
   contient la requete. C'est le cas courant, et il doit primer.
2. **approximatif** : distance d'edition, pour les fautes de frappe et les
   lettres interverties (« cyberpounk » -> « cyberpunk »).
3. **phonetique** : les deux ecritures se prononcent pareil (« wakfou » ->
   « wakfu », « fhotoshop » -> « photoshop »).

Le score final sert aussi a classer : un resultat exact remonte toujours
au-dessus d'un resultat trouve a l'oreille.
"""
from __future__ import annotations

import functools

import re
from functools import lru_cache
import unicodedata
from difflib import SequenceMatcher

#: en dessous de ce score, ce n'est plus une correspondance
SEUIL = 0.62

_NON_ALNUM = re.compile(r"[^a-z0-9]+")
_MARQUES = re.compile(r"[\u2122\u00ae\u00a9\u2120]")          # TM, (R), (C), SM
_APOSTROPHES = re.compile(r"[\u0027\u2018\u2019\u02bc\u0060\u00b4]")
#: lettres que la decomposition Unicode ne separe pas
_LIGATURES = str.maketrans({"\u0153": "oe", "\u0152": "oe", "\u00e6": "ae",
                            "\u00c6": "ae", "\u00df": "ss", "\u00f8": "o",
                            "\u00d8": "o", "\u0142": "l", "\u0141": "l"})

#: mentions d'edition qui ne distinguent pas deux jeux differents.
#: « <qualificatif...> edition » est retire partout ; les mots seuls de
#: `_FIN_SEULE` seulement en fin de titre (« Crimson Desert Enhanced »).
#: « Anniversary » seul n'en fait PAS partie : « Fable Anniversary » n'est
#: pas « Fable ».
_QUALIFICATIFS = frozenset({
    "definitive", "deluxe", "ultimate", "standard", "complete", "enhanced",
    "gold", "special", "anniversary", "collectors", "collector", "digital",
    "premium", "legendary", "platinum", "royal", "extended", "expanded",
    "launch", "limited", "goty", "steam"})
_FIN_SEULE = frozenset({"enhanced", "redux", "remastered", "remaster",
                        "definitive", "goty"})
_PARTOUT = frozenset({"goty", "remastered", "remaster"})

#: chiffres romains convertis (« Hades II » = « Hades 2 »). « I » et « X »
#: seuls ne le sont jamais (« I Am Bread », « Mega Man X » n'est pas
#: « Mega Man 10 ») ; « V » seulement apres le premier mot (« GTA V »).
_ROMAINS = {r: i for i, r in enumerate(
    ("", "i", "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix", "x", "xi", "xii",
     "xiii", "xiv", "xv", "xvi", "xvii", "xviii", "xix", "xx")) if r}


@lru_cache(maxsize=30000)
def _plier(texte: str) -> str:
    """Minuscules, sans accents ni marques deposees, apostrophes collees.
    Gardee en memoire : les memes titres sont relus a chaque frappe."""
    # ™ ® © avant la decomposition : sinon « ™ » devient les lettres « TM »
    # et « FOR HONOR™ » ne correspond plus a « For Honor »
    brut = _MARQUES.sub("", texte or "").translate(_LIGATURES)
    brut = unicodedata.normalize("NFKD", brut)
    brut = "".join(c for c in brut if not unicodedata.combining(c))
    return _APOSTROPHES.sub("", brut.lower())


def normaliser(texte: str) -> str:
    """Minuscules, sans accents, sans ponctuation ni espaces."""
    return _NON_ALNUM.sub("", _plier(texte))


def mots(texte: str) -> list[str]:
    """Mots d'un titre : lettres et chiffres seulement, « & » lu « and ».

    « Baldur's Gate 3 » et « Baldur’s Gate 3 » donnent les memes mots,
    comme « RuneScape - Dragonwilds » et « RuneScape: Dragonwilds »."""
    brut = _plier(texte).replace("&", " and ")
    return re.findall(r"[a-z0-9]+", brut)


def _sans_editions(liste: list[str]) -> list[str]:
    out: list[str] = []
    i = 0
    while i < len(liste):
        m = liste[i]
        # « game of the year (edition) »
        if liste[i:i + 4] == ["game", "of", "the", "year"]:
            i += 4
            if i < len(liste) and liste[i] == "edition":
                i += 1
            continue
        if m == "edition":
            avant = len(out)
            while out and out[-1] in _QUALIFICATIFS:
                out.pop()
            # « <un mot> Edition » en toute fin de titre, meme avec un
            # qualificatif propre au jeu (« Diablo II: Resurrected – Infernal
            # Edition », « Cyberpunk 2077: Phantom Edition ») : c'est une
            # mention d'edition, pas un autre jeu. Jamais si cela ne laisse
            # qu'un mot (« Minecraft Java Edition » reste entier... sauf « Java »).
            if len(out) == avant and i == len(liste) - 1 and len(out) >= 3:
                out.pop()
            i += 1
            continue
        if m in ("directors", "director") and liste[i + 1:i + 2] == ["cut"]:
            i += 2
            continue
        if m in _PARTOUT and len(liste) > 1:
            i += 1
            continue
        out.append(m)
        i += 1
    while len(out) > 1 and out[-1] in _FIN_SEULE:
        out.pop()
    # « Grand Theft Auto V Version améliorée » (nom francais de l'edition
    # « Enhanced » sur Steam), « ... Legacy » : meme jeu
    if len(out) > 2 and out[-2:] in (["version", "amelioree"], ["edition", "amelioree"]):
        out = out[:-2]
    elif len(out) > 1 and out[-1] == "legacy" and len(out) > 2:
        out.pop()
    return out or liste


def sans_bruit(texte: str) -> str:
    """Titre normalise, debarrasse des mentions d'edition."""
    return "".join(_sans_editions(mots(texte)))


def _romains(liste: list[str]) -> list[str]:
    out = []
    for i, m in enumerate(liste):
        if m in _ROMAINS and (len(m) > 1 or (m == "v" and i > 0)):
            out.append(str(_ROMAINS[m]))
        else:
            out.append(m)
    return out


def mots_cle(texte: str) -> list[str]:
    """Mots d'un titre sans mentions d'edition, chiffres romains en chiffres."""
    return _romains(_sans_editions(mots(texte)))


@functools.lru_cache(maxsize=16384)
def cle_titre(texte: str) -> str:
    """Cle d'egalite de deux titres de jeu : lettres et chiffres seulement,
    sans accents, marques, ponctuation ni separateurs (« - », « : », « – »),
    sans mention d'edition, chiffres romains convertis.

    Vide pour un titre sans lettre latine ni chiffre (titre japonais...) :
    une cle vide ne doit JAMAIS servir a dire que deux jeux sont les memes."""
    return "".join(mots_cle(texte))


def titre_recherche(titre: str) -> str:
    """Titre pour une recherche sur une boutique : sans ™ ® ni separateurs
    (« RuneScape - Dragonwilds » -> « RuneScape Dragonwilds » ; un « - »
    isole est lu comme une exclusion par certains moteurs)."""
    t = _MARQUES.sub("", titre or "")
    t = re.sub(r"\s+[-\u2013\u2014\u2015~|/:]+\s+|[:|\u2013\u2014\u2015]+", " ", t)
    return re.sub(r"\s+", " ", t).strip()


def termes_recherche(titre: str, maximum: int = 3) -> list[str]:
    """Termes a essayer, dans l'ordre, pour trouver un jeu sur une boutique :
    titre sans separateurs, titre d'origine, puis chiffres romains en chiffres
    (« Baldur's Gate III » -> « Baldur's Gate 3 »). Sans doublon."""
    propre = titre_recherche(titre)
    romain = " ".join(str(_ROMAINS[m.lower()]) if (m.lower() in _ROMAINS and len(m) > 1)
                      else m for m in propre.split())
    out: list[str] = []
    for t in (propre, (titre or "").strip(), romain):
        if t and t not in out:
            out.append(t)
    return out[:maximum]


# --------------------------------------------------------------------------
# Correspondance stricte titre -> fiche de boutique
# --------------------------------------------------------------------------

#: un candidat qui contient un de ces mots (absent du titre cherche) n'est
#: pas le jeu : DLC, bande originale, demo, serveur dedie...
_PAS_LE_JEU = frozenset({
    "soundtrack", "soundtracks", "ost", "demo", "dlc", "playtest", "artbook",
    "trailer", "season", "expansion", "server", "sdk", "editor", "upgrade",
    "costume", "costumes", "skin", "skins", "bundle", "wallpaper",
    "wallpapers", "benchmark", "prologue", "beta", "music", "comic", "comics"})
_TYPES_REFUSES = frozenset({"dlc", "music", "demo", "video", "mod", "advertising",
                            "series", "episode", "hardware", "tool", "config",
                            "application", "sub", "bundle"})
_VIDES = frozenset({"the", "a", "an", "of", "and", "le", "la", "les", "l", "de",
                    "des", "du", "d"})

#: au moins ce recouvrement de mots (Dice) pour le dernier recours
SEUIL_MOTS = 0.88


def _chiffres(liste) -> set[str]:
    return {m for m in liste if m.isdigit()}


def proximite(titre: str, candidat: str) -> float:
    """Ressemblance de deux titres de jeu, de 0 a 1, PRUDENTE.

    1.0  : memes lettres et chiffres (« RuneScape - Dragonwilds » /
           « RuneScape: Dragonwilds »)
    0.97 : meme titre a une mention d'edition ou un chiffre romain pres
    0.9x : memes mots a un article pres, ou presque tous les memes mots
    0    : tout le reste, en particulier des numeros differents
           (« Hades » / « Hades II ») ou un mot de plus qui change de jeu
           (« Fable » / « Fable Anniversary »).
    """
    a, b = normaliser(titre), normaliser(candidat)
    if not a or not b:
        return 0.0
    if a == b:
        return 1.0
    ma, mb = mots_cle(titre), mots_cle(candidat)
    if not ma or not mb:
        return 0.0
    if _chiffres(ma) != _chiffres(mb):
        return 0.0
    if "".join(ma) == "".join(mb):
        return 0.97
    sa = {m for m in ma if m not in _VIDES} or set(ma)
    sb = {m for m in mb if m not in _VIDES} or set(mb)
    if sa == sb:
        return 0.95
    dice = 2 * len(sa & sb) / (len(sa) + len(sb))
    if dice >= SEUIL_MOTS:
        return 0.80 + 0.1 * dice
    ka, kb = "".join(ma), "".join(mb)
    if min(len(ka), len(kb)) >= 10 and len(sa) == len(sb):
        ratio = SequenceMatcher(None, ka, kb).ratio()
        if ratio >= 0.94:
            return 0.75 + 0.1 * ratio
    return 0.0


def meilleur_candidat(titre: str, candidats, nom=lambda c: c.get("name", ""),
                      genre=lambda c: c.get("type"), seuil: float = 0.8):
    """Le candidat (fiche de boutique) qui est CE jeu, ou None.

    Les egalites strictes passent avant les ressemblances ; a note egale, un
    candidat de type « game » passe devant, puis l'ordre de la boutique.
    Les DLC, bandes originales, demos... sont ecartes (par leur type quand la
    boutique le donne, sinon par leur nom)."""
    if not cle_titre(titre) and not normaliser(titre):
        return None
    propres = set(mots(titre))
    meilleur, note_max = None, None
    for rang, c in enumerate(candidats or []):
        try:
            n = str(nom(c) or "")
            g = str(genre(c) or "").lower()
        except Exception:
            continue
        if g in _TYPES_REFUSES:
            continue
        if (set(mots(n)) - propres) & _PAS_LE_JEU:
            continue
        p = proximite(titre, n)
        if p < seuil:
            continue
        note = (p, g == "game", -rang)
        if note_max is None or note > note_max:
            meilleur, note_max = c, note
    return meilleur


# --------------------------------------------------------------------------
# Phonetique
# --------------------------------------------------------------------------

#: reecritures appliquees dans l'ordre, avant de retirer les voyelles.
#: Volontairement courtes : le but est de rapprocher le francais et l'anglais
#: tels qu'un joueur les tape, pas de reimplementer un Soundex complet.
_SONS = (
    ("eau", "o"), ("au", "o"), ("ou", "u"), ("oo", "u"), ("ee", "i"),
    ("ph", "f"), ("qu", "k"), ("q", "k"), ("ck", "k"), ("ch", "x"),
    ("sh", "x"), ("sch", "x"), ("th", "t"), ("gn", "n"), ("gh", "g"),
    ("wh", "w"), ("w", "v"), ("y", "i"), ("z", "s"), ("x", "ks"),
    ("ai", "e"), ("ei", "e"), ("oi", "oa"), ("in", "an"), ("ein", "an"),
    ("um", "on"), ("om", "on"), ("em", "an"), ("am", "an"),
)

_VOYELLES = re.compile(r"[aeiou]")


def cle_phonetique(texte: str) -> str:
    """Empreinte sonore approximative d'un titre.

    « wakfou » et « wakfu » donnent la meme cle ; « cyberpunk » et
    « ciberpunk » aussi. Les voyelles internes sont retirees en dernier,
    parce que ce sont elles qu'on ecrit le plus souvent de travers.
    """
    out = normaliser(texte)
    if not out:
        return ""
    for avant, apres in _SONS:
        out = out.replace(avant, apres)
    tete = out[0]
    reste = _VOYELLES.sub("", out[1:])
    # doublons : « bb » et « b » se prononcent pareil
    compact = tete
    for lettre in reste:
        if lettre != compact[-1]:
            compact += lettre
    return compact


# --------------------------------------------------------------------------
# Score
# --------------------------------------------------------------------------

def _limites(liste: list[str]) -> set[int]:
    """Positions ou commence chaque mot dans le texte colle « f125 » :
    {0, 2} pour « F1 25 »."""
    out, i = set(), 0
    for m in liste:
        out.add(i)
        i += len(m)
    return out


#: plus courte, une recherche ne se lit qu'au DEBUT d'un mot du titre :
#: « nba » n'est pas dans « DragoN BAll », ni « gta » dans « IGTAP ». Plus
#: longue, elle peut finir un mot compose : « craft » dans « Minecraft ».
MILIEU_DE_MOT = 5


def _mal_place(c: str, limites, debut: int, fin: int, ferme: bool) -> bool:
    """Vrai si c[debut:fin] ne peut pas etre ce que le joueur a ecrit.

    - Un texte court pris au milieu d'un mot : « nba » dans « dragonball ».
    - Un nombre tranche : « F1 » n'est ni « F11 », ni « F-16 », ni
      « F-117A », alors qu'il est bien dans « F1 25 » (deux mots). Un nombre
      n'est jamais entame par son milieu (des zeros devant n'y changent
      rien : « 1 » est « 01 ») ; sa fin peut rester ouverte (`ferme` faux)
      quand le joueur est en train de l'ecrire : « F1 202 » pour « F1 2024 ».
    """
    if debut not in limites:
        i = debut
        if c[debut].isdigit():
            while i > 0 and i not in limites and c[i - 1] == "0":
                i -= 1
        if i not in limites:
            if c[debut].isdigit() and c[i - 1].isdigit():
                return True
            if fin - debut < MILIEU_DE_MOT:
                return True
    return (ferme and fin < len(c) and fin not in limites
            and c[fin - 1].isdigit() and c[fin].isdigit())


def _position(q: str, c: str, limites, ferme: bool) -> int:
    """Premiere place acceptable de `q` dans `c` (voir `_mal_place`), ou -1."""
    i = c.find(q)
    while i >= 0:
        if limites is None or not _mal_place(c, limites, i, i + len(q), ferme):
            return i
        i = c.find(q, i + 1)
    return -1


def _direct(q: str, c: str, limites=None, ferme: bool = True) -> float:
    """Egalite, debut ou inclusion de deux textes normalises (0 sinon).
    `limites` (debuts des mots de `c`) ecarte les places impossibles."""
    if c == q:
        return 1.0
    i = _position(q, c, limites, ferme)
    if i == 0:
        return 0.97
    if i > 0:
        # plus la requete couvre la cible, plus la correspondance est sure
        return 0.88 + 0.06 * (len(q) / len(c))
    return 0.0


def _initiales(texte: str, romains: str) -> list[str]:
    """Un titre lu comme un sigle : l'initiale de chaque mot, un nombre en
    entier. « Baldur's Gate 3 » -> b, g, 3 ; « Counter-Strike 2 » -> c, s, 2 ;
    « Frontline 1942 » -> f, 1942 (ce n'est pas « F1 »).

    `romains` dit comment lire un chiffre romain : « chiffres » (XVI -> 16),
    « entiers » (XVI -> xvi) ou « lettres » (V -> v, un mot comme un autre)."""
    liste = mots(texte)

    def initiale(m: str) -> str:
        # « 117A » se lit 117, pas 1 : « F-117A » n'est pas « F1 »
        return re.match(r"\d+", m).group() if m[:1].isdigit() else m[:1]

    if romains == "lettres":
        return [initiale(m) for m in liste]
    convertis = _romains(liste)
    return [(c if romains == "chiffres" else m) if (c != m or m.isdigit()) else initiale(m)
            for m, c in zip(liste, convertis)]


_SEPARE = re.compile(r":|\s[-\u2013\u2014|]\s|[\u2013\u2014|]")
_ARTICLES_SIGLE = {"the", "a", "an", "le", "la", "les"}


def _debuts_de_partie(texte: str) -> set[int]:
    """Rangs des mots ou un sigle peut commencer : le debut du titre (article
    saute : « The Witcher 3 » -> w3) et le debut d'un sous-titre (« Call of
    Duty: Black Ops III » -> bo3). Pas le milieu d'une phrase : « gta »
    n'est pas « IGTAP: an Incremental Game That's Also a Platformer »."""
    out, n = {0}, 0
    for partie in _SEPARE.split(_plier(texte)):
        out.add(n)
        n += len(mots(partie))
    liste, i = mots(texte), 0
    while i < len(liste) - 1 and liste[i] in _ARTICLES_SIGLE:
        i += 1
    out.add(i)
    return out


@lru_cache(maxsize=12000)
def _sigles_cible(cible: str) -> tuple:
    """Ce que `sigle` lit d'un titre, calcule une fois par titre : les rangs
    ou un sigle peut commencer et les initiales selon les trois lectures des
    chiffres romains."""
    debuts = _debuts_de_partie(cible)
    return (tuple(sorted(debuts)),
            tuple(tuple(_initiales(cible, mode)) for mode in ("chiffres", "entiers", "lettres")))


def sigle(requete: str, cible: str) -> float:
    """Note d'un sigle : 0.90 s'il part du debut du titre (« gta », « bg3 »,
    « cs2 », « ff16 », « ffxvi »), 0.84 s'il designe la suite d'un titre
    (« bo3 » pour « Call of Duty: Black Ops III »), 0 sinon. C'est ainsi que
    les joueurs nomment la moitie des jeux."""
    q = normaliser(requete)
    if not (2 <= len(q) <= 6) or q.isdigit() or " " in (requete or "").strip():
        return 0.0
    chiffre = any(ch.isdigit() for ch in q)
    meilleure = 0.0
    debuts, lectures = _sigles_cible(cible or "")
    for titre in lectures:                                 # « gta5 », « gtav »
        for i in debuts:
            if i >= len(titre):
                continue
            lu = ""
            for j in range(i, len(titre)):
                lu += titre[j]
                if not q.startswith(lu):
                    break
                if lu != q:
                    continue
                if j == i:
                    break                       # un seul mot : pas un sigle
                if i == 0:
                    return 0.90
                # en cours de titre, deux lettres seules designeraient n'importe quoi
                if j - i >= 2 or chiffre:
                    meilleure = 0.84
                break
    if meilleure:
        return meilleure
    # debut de sigle : « gt » pour « Grand Theft Auto » (saisie en cours)
    titre = "".join(lectures[2])
    if not chiffre and len(titre) >= 3 and titre.startswith(q):
        return 0.90
    return 0.0


# --------------------------------------------------------------------------
# Variantes d'une recherche
# --------------------------------------------------------------------------
#: sigles de series que les joueurs tapent a la place du nom. Une boutique ne
#: les connait pas : « bo3 » ne rend rien sur Steam, « black ops 3 » si.
SERIES: dict[str, tuple[str, ...]] = {
    "ac": ("assassin's creed",), "aoe": ("age of empires",), "bf": ("battlefield",),
    "bg": ("baldur's gate",), "bl": ("borderlands",), "bo": ("black ops",),
    "civ": ("civilization",), "cod": ("call of duty",), "coh": ("company of heroes",),
    "cs": ("counter-strike",), "da": ("dragon age",), "dbd": ("dead by daylight",),
    "dl": ("dying light",), "dmc": ("devil may cry",), "dos": ("divinity original sin",),
    "ds": ("dark souls",), "ets": ("euro truck simulator",), "ff": ("final fantasy",),
    "fc": ("ea sports fc",), "fh": ("forza horizon",), "fifa": ("ea sports fc",),
    "fm": ("football manager",), "gow": ("god of war",),
    "gta": ("grand theft auto",), "hl": ("half-life",), "kcd": ("kingdom come deliverance",),
    "ksp": ("kerbal space program",), "l4d": ("left 4 dead",), "me": ("mass effect",),
    "mgs": ("metal gear solid",), "mh": ("monster hunter",), "mk": ("mortal kombat",),
    "mw": ("modern warfare",), "nfs": ("need for speed",), "nms": ("no man's sky",),
    "pes": ("efootball",),
    "poe": ("path of exile",), "r6": ("rainbow six",), "rdr": ("red dead redemption",),
    "re": ("resident evil",), "rl": ("rocket league",), "sf": ("street fighter",),
    "sot": ("sea of thieves",), "tes": ("the elder scrolls",), "tf": ("team fortress",),
    "tlou": ("the last of us",), "tw": ("the witcher", "total war"),
    "wd": ("watch dogs",), "wh": ("warhammer",),
}

#: note gardee par une variante : le jeu trouve par le nom developpe vaut
#: presque le terme tape ; celui trouve en retirant le dernier mot, moins
DEVELOPPEE = 0.98
RACCOURCIE = 0.75


def developper(terme: str) -> list[str]:
    """Le terme avec ses sigles de serie developpes : « bo3 » -> « black ops
    3 », « cod bo 4 » -> « call of duty black ops 4 ». Liste vide si rien a
    developper ; deux lectures au plus (« tw3 » : The Witcher, Total War)."""
    morceaux = _plier(terme or "").split()
    if not morceaux or len(morceaux) > 5:
        return []
    lectures: list[list[str]] = [[]]
    change = False
    for m in morceaux:
        noms: tuple[str, ...] = ()
        suite = ""
        # « r6 », « l4d » : le sigle porte un chiffre ; « bo3 », « l4d2 » : il
        # est suivi du numero du jeu
        nu = m.rstrip("0123456789")
        for tete, reste in ((m, ""), (nu, m[len(nu):])):
            if tete in SERIES:
                noms, suite = SERIES[tete], reste
                break
        if noms:
            change = True
            lectures = [l + [n] + ([suite] if suite else []) for l in lectures for n in noms][:2]
        else:
            lectures = [l + [m] for l in lectures]
    return [" ".join(l) for l in lectures] if change else []


def raccourcir(terme: str) -> str:
    """Le terme sans son dernier mot, pour une saisie en cours ou un numero
    que la boutique n'ecrit pas ainsi : « F1 202 » -> « F1 ». Vide s'il ne
    resterait rien d'utile."""
    morceaux = (terme or "").split()
    if len(morceaux) < 2:
        return ""
    court = " ".join(morceaux[:-1])
    return court if len(normaliser(court)) >= 2 else ""


#: en dessous, une recherche qui finit par un numero est aussi lue raccourcie
PEU_DE_RESULTATS = 3


def faut_raccourcir(terme: str, trouves: int, meilleure: float = 0.0) -> bool:
    """Faut-il relire `terme` sans son dernier mot ? `trouves` : nombre de
    jeux trouves ; `meilleure` : note du premier.

    Oui si rien ne sort. Oui aussi quand le dernier mot est un numero, que
    presque rien ne sort et qu'aucun jeu ne porte ce nom-la (« F1 202 » : la
    boutique ecrit « 25 »). Non pour « tropico 6 » ou « hades 2 », qui
    trouvent leur jeu : la lecture raccourcie y ramenait Tropico 5, 4 et 3.
    Non pour « red ded », qui trouve ses deux jeux."""
    morceaux = (terme or "").split()
    if len(morceaux) < 2:
        return False
    return trouves == 0 or (morceaux[-1].isdigit() and trouves < PEU_DE_RESULTATS
                            and meilleure < 0.9)


def variantes(terme: str, raccourcie: bool = False) -> list[tuple[str, float]]:
    """Les lectures d'une recherche tapee par un joueur : [(terme, poids)].
    Le terme tel quel, ses sigles de serie developpes, et sur demande le
    terme sans son dernier mot (lui aussi developpe)."""
    terme = (terme or "").strip()
    if not terme:
        return []
    out = [(terme, 1.0)] + [(v, DEVELOPPEE) for v in developper(terme)]
    court = raccourcir(terme) if raccourcie else ""
    if court:
        out += [(court, RACCOURCIE)] + [(v, RACCOURCIE) for v in developper(court)]
    return out


def termes_a_poser(terme: str) -> list[str]:
    """Ce qu'il faut demander aux boutiques pour `terme`. Un sigle seul
    (« bo3 », « bf3 ») ne leur dit rien : seule sa forme developpee leur est
    posee. Le sigle sert toujours a noter les resultats."""
    termes = [v for v, _ in variantes(terme)]
    if len(termes) > 1 and len((terme or "").split()) == 1:
        return termes[1:]
    return termes


def note_variantes(liste, cible: str) -> float:
    """Meilleure note de `cible` pour des variantes [(terme, poids)]."""
    return max((score(terme, cible) * poids for terme, poids in liste), default=0.0)


def classer_variantes(liste, elements, cle=lambda x: x, seuil: float = SEUIL,
                      departage=None):
    """Comme `classer`, mais chaque element est note sur sa meilleure lecture
    parmi les variantes [(terme, poids)]. A note egale, `departage(element)`
    (le plus grand d'abord) decide, puis l'ordre d'origine : « cyberpunk »
    doit montrer Cyberpunk 2077 avant un jeu inconnu du meme debut."""
    if not liste:
        return list(elements)
    notes = []
    for rang, element in enumerate(elements):
        note = note_variantes(liste, str(cle(element) or ""))
        if note >= seuil:
            poids = float(departage(element) or 0.0) if departage else 0.0
            notes.append((-round(note, 2), -poids, rang, element))
    notes.sort(key=lambda n: n[:3])
    return [n[3] for n in notes]


@lru_cache(maxsize=4096)
def _cle_mot(texte: str) -> str:
    return cle_phonetique(texte)


def _a_l_oreille(q: str, pq: str, mc: list[str]) -> float:
    """La recherche SONNE comme le titre, ou comme une suite de ses mots :
    « ciberpunk » pour « Cyberpunk 2077 », « asasin crid » pour « Assassin's
    Creed Shadows ». Deux garde-fous, poses apres avoir vu « mario » ramener
    Marvel et Mortal Kombat, « halo » Half-Life et Helldivers, « zelda »
    Metal Gear Solid (7 octobre 2026) : la cle sonore doit etre celle de
    mots ENTIERS du titre (pas un bout de cle n'importe ou), et les lettres
    elles-memes doivent se ressembler (« zelda » et « solid » ont la meme
    cle, pas les memes lettres)."""
    if len(pq) < 3:
        return 0.0          # « f », « mr », « hl » : une cle si courte ne designe rien
    for i in range(len(mc)):
        if _cle_mot(mc[i])[:1] != pq[:1]:
            continue
        suite = ""
        for j in range(i, len(mc)):
            suite += mc[j]
            if len(suite) > len(q) + 4:
                break
            cle = _cle_mot(suite)
            if cle != pq and not (len(pq) >= 5
                                  and SequenceMatcher(None, pq, cle).ratio() >= 0.85):
                continue
            if SequenceMatcher(None, q, suite).ratio() < 0.6:
                continue
            if i == 0 and j == len(mc) - 1:
                return 0.80
            return 0.74 if i == 0 else 0.72
    return 0.0


def _mots_plausibles(mq: list[str], mc: list[str]) -> bool:
    """Une faute change des lettres, pas un mot : chaque mot de la recherche
    doit ressembler a un mot du titre (ou a deux mots colles). Sans cela,
    « ea sports fc » passait pour « EA SPORTS WRC » et « red dead » pour
    « The Roottrees aRE DEAD »."""
    cibles = mc + [a + b for a, b in zip(mc, mc[1:])]
    for m in mq:
        if m.isdigit():
            continue                    # les numeros ont leurs propres regles
        if len(m) <= 2:
            if not any(t.startswith(m) for t in cibles):
                return False
        elif not any(SequenceMatcher(None, m, t[:len(m) + 2]).ratio() >= 0.6
                     # un mot court mal ecrit garde son initiale : « teh »
                     # pour « the », pas « red » pour « are »
                     and (len(m) >= 5 or t[:1] == m[:1])
                     for t in cibles):
            return False
    return True


@lru_cache(maxsize=12000)
def _lu(texte: str) -> tuple:
    """Les lectures d'un texte dont `score` a besoin, calculees une fois :
    (colle, mots, debuts des mots, mots en chiffres romains convertis, colle
    converti, debuts convertis, nombres entiers, tous les nombres, sans
    mention d'edition). Un catalogue de deux mille titres est compare a
    chaque lettre tapee : sans cette memoire, chaque frappe refaisait tout le
    travail de lecture de chaque titre."""
    c = normaliser(texte)
    m = tuple(mots(texte))
    lc = frozenset(_limites(re.findall(r"[a-z0-9]+", _plier(texte))))
    r = tuple(_romains(list(m)))
    return (c, m, lc, r, "".join(r), frozenset(_limites(r)),
            frozenset(x for x in r if x.isdigit()),
            frozenset(re.findall(r"\d+", " ".join(r))), sans_bruit(texte))


def _ratio(q: str, texte: str, seuil: float) -> float:
    """Ressemblance de deux textes (celle de `difflib`). Exacte si elle peut
    atteindre `seuil` ; sinon une borne superieure, plus basse que `seuil`,
    obtenue en comptant les longueurs puis les lettres communes : le calcul
    complet est de loin le plus couteux d'une comparaison, et il est inutile
    pour l'immense majorite des titres d'un catalogue."""
    total = len(q) + len(texte)
    if not total:
        return 1.0
    borne = 2.0 * min(len(q), len(texte)) / total
    if borne < seuil:
        return borne
    reste: dict[str, int] = {}
    for lettre in q:
        reste[lettre] = reste.get(lettre, 0) + 1
    communes = 0
    for lettre in texte:
        n = reste.get(lettre, 0)
        if n:
            reste[lettre] = n - 1
            communes += 1
    borne = 2.0 * communes / total
    if borne < seuil:
        return borne
    return SequenceMatcher(None, q, texte).ratio()


@lru_cache(maxsize=100000)
def score(requete: str, cible: str) -> float:
    """De 0 (rien a voir) a 1 (identique). Voir le seuil `SEUIL`."""
    requete, cible = requete or "", cible or ""
    q, mq_t, _lq, rq_t, q2, _lq2, nq, cq, sb_q = _lu(requete)
    c, mc_t, lc, rc_t, c2, lc2, nc, cc, sb_c = _lu(cible)
    if not q:
        return 1.0
    if not c:
        return 0.0
    mq, mc, rq, rc = list(mq_t), list(mc_t), list(rq_t), list(rc_t)

    # un nombre colle a des lettres (« f1 », « bo3 ») est complet ; seul un
    # nombre ecrit a part en fin de recherche peut etre en cours de saisie
    ferme = not (mq and mq[-1].isdigit())
    direct = _direct(q, c, lc, ferme)
    if direct:
        return direct
    # chiffres romains : « black ops 3 » est « Black Ops III »
    if (q2, c2) != (q, c) and q2 and c2:
        direct = _direct(q2, c2, lc2, ferme)
        if direct:
            return direct

    # meme titre a une mention d'edition pres
    if sb_q and sb_q == sb_c:
        return 0.93

    # sigle : « gta » pour « Grand Theft Auto », « bg3 » pour « Baldur's
    # Gate 3 », « bo3 » pour « Call of Duty: Black Ops III »
    note = sigle(requete, cible)
    if note:
        return note

    # tous les mots de la requete presents, dans le desordre. Le dernier
    # nombre peut etre en cours de saisie s'il a deja deux chiffres (« F1
    # 20 » pour « F1 Manager 2024 ») : un seul chiffre epars ne dit rien
    # (« battlefield 3 » n'est pas « War Dust : 32v32 Battlefield »).
    demandes = [normaliser(m) for m in requete.split() if normaliser(m)]

    def tous(liste, texte, limites):
        dernier = len(liste) - 1
        return all(_position(m, texte, limites,
                             not (i == dernier and m.isdigit() and len(m) >= 2)) >= 0
                   for i, m in enumerate(liste))

    if len(demandes) > 1 and (tous(demandes, c, lc)
                              or tous(_romains(demandes), c2, lc2)):
        return 0.86

    # Restent les a-peu-pres (faute de frappe, oreille). Un numero y fait
    # loi : « black ops 4 » n'est ni « Black Ops 7 » ni « Black Ops II »,
    # « F1 » n'est ni « F-16 » ni « Fallout 4 », meme a une lettre pres.
    autre_numero = bool(nq and nc and not nq & nc) or bool(cq and cc and not cq & cc)

    # faute de frappe : le titre entier, ou ce qui suit le debut d'un de
    # ses mots (une faute ne fait pas commencer au milieu d'un mot)
    proche = _ratio(q, c, 0.78)
    if len(q) >= 4 and len(c) > len(q):
        meilleure = max((_ratio(q, c[i:i + len(q) + 2], 0.78 / 0.96)
                         for i in lc if i < len(c)), default=proche)
        proche = max(proche, meilleure * 0.96)
    if autre_numero:
        return min(proche, 0.9) * 0.5
    a_peu_pres = 0.60 + 0.25 * proche if proche >= 0.78 else 0.0
    if not a_peu_pres:
        a_peu_pres = _a_l_oreille(q, _cle_mot(requete), mc)
    if a_peu_pres and not (_mots_plausibles(mq, mc) or _mots_plausibles(rq, rc)):
        a_peu_pres = 0.0
    if a_peu_pres and nq and not nc:
        # la recherche porte un numero, le titre aucun : ce n'est pas le
        # jeu demande. On garde, en fin de liste, les autres jeux de la
        # serie (« resident evil 4 » -> « Resident Evil Village », « bf3 »
        # -> « Battlefield REDSEC ») ; pas un titre qui ne fait que
        # contenir le nom (« Endless Battlefield »).
        serie = "".join(m for m in rq if not m.isdigit())
        if len(serie) >= 3 and (c.startswith(serie) or c2.startswith(serie)):
            return 0.64
        return min(proche, 0.9) * 0.5
    return a_peu_pres or min(proche, 0.77) * 0.5


def correspond(requete: str, cible: str, seuil: float = SEUIL) -> bool:
    return score(requete, cible) >= seuil


def classer(requete: str, elements, cle=lambda x: x, seuil: float = SEUIL):
    """Elements correspondant a la requete, du plus pertinent au moins.

    `cle` extrait le texte a comparer. Les egalites gardent l'ordre
    d'origine, ce qui evite qu'une liste deja triee se melange.
    """
    if not (requete or "").strip():
        return list(elements)
    notes = []
    for rang, element in enumerate(elements):
        note = score(requete, str(cle(element) or ""))
        if note >= seuil:
            notes.append((-note, rang, element))
    notes.sort(key=lambda t: (t[0], t[1]))
    return [element for _, _, element in notes]
