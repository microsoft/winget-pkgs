"""Theme visuel : palette et feuille de style.

Une seule source de verite pour les couleurs : changer `PALETTE` suffit a
retheme l'application entiere.
"""
from __future__ import annotations

from ..core.config import CONFIG

PALETTE = {
    "bg": "#0A0D14",
    "bg_alt": "#0E121C",
    "surface": "#141926",
    "surface_hi": "#1B2233",
    "border": "#232B3D",
    "border_hi": "#33405C",
    "text": "#E7ECF5",
    "text_dim": "#AAB4C8",
    "text_faint": "#7F8AA3",
    "accent": "#38E1FF",
    "accent_dim": "#1E7F94",
    "esport": "#FF5A5F",
    "detente": "#38E1FF",
    "photo": "#B98CFF",
    "ok": "#3DDC97",
    "warn": "#FFB454",
    "danger": "#FF5A5F",
}

#: Teintes translucides : l'interface flotte au-dessus du decor au lieu de
#: le masquer. Les valeurs sont volontairement proches des aplats ci-dessus,
#: pour que le contraste du texte ne change pas d'un fond a l'autre.
GLASS = {
    "glass_side": "rgba(10, 14, 22, 218)",     # barre laterale
    "glass_panel": "rgba(20, 25, 38, 200)",    # panneaux
    "glass_flat": "rgba(14, 18, 28, 186)",     # panneaux sobres
    "glass_card": "rgba(20, 25, 38, 214)",     # tuiles de jeu
    "glass_card_hi": "rgba(27, 34, 51, 240)",  # tuile survolee
    "glass_bar": "rgba(10, 14, 22, 170)",      # barres d'en-tete et d'etat
}


def accent() -> str:
    return CONFIG.get("ui.accent") or PALETTE["accent"]


def build_qss() -> str:
    p = dict(PALETTE)
    p.update(GLASS)
    p["accent"] = accent()
    return QSS_TEMPLATE.format(**p)


QSS_TEMPLATE = """
* {{
    font-family: "Segoe UI Variable Display", "Segoe UI", "Inter", sans-serif;
    font-size: 13px;
    color: {text};
}}
QWidget#Root {{ background: transparent; }}
QMainWindow, QDialog {{ background: {bg}; }}
QMessageBox {{ background: {bg}; }}
QMessageBox QLabel {{ color: {text}; }}

/* ---------- Barre laterale ---------- */
QWidget#Sidebar {{
    background: {glass_side};
    border-right: 1px solid {border};
}}
QLabel#Brand {{
    font-size: 21px; font-weight: 700; letter-spacing: 5px;
    color: {text}; padding: 20px 18px 0 18px;
}}
QLabel#BrandSub {{
    font-size: 10px; letter-spacing: 3px; color: {text_faint};
    padding: 0 18px 16px 20px; text-transform: uppercase;
}}
QPushButton#NavButton {{
    text-align: left; padding: 11px 16px; border: none; border-radius: 9px;
    background: transparent; color: {text_dim}; font-size: 13px;
    font-weight: 500; margin: 2px 10px;
}}
QPushButton#NavButton:hover {{ background: {surface}; color: {text}; }}
QPushButton#NavButton:checked {{
    background: {surface_hi}; color: {text}; font-weight: 600;
    border-left: 2px solid {accent};
}}
QPushButton#Donate {{
    background: transparent; border: 1px solid {border_hi}; border-radius: 9px;
    color: {text_dim}; margin: 6px 14px 4px 14px; padding: 9px 12px;
    font-size: 12px; font-weight: 500;
}}
QPushButton#Donate:hover {{
    border-color: {ok}; color: {ok}; background: {surface};
}}
QPushButton#NavLink {{
    background: transparent; border: none; color: {text_faint};
    margin: 0 14px 2px 14px; padding: 5px 6px; font-size: 11px;
    text-decoration: underline;
}}
QPushButton#NavLink:hover {{ color: {text}; }}
QPushButton#AvisDiscret {{
    background: transparent; border: none; color: {text_faint};
    margin: 0 14px 0 14px; padding: 1px 10px; font-size: 10px;
}}
QPushButton#AvisDiscret:hover {{ color: {text}; text-decoration: underline; }}
QLabel#HorsLigne {{ color: {warn}; font-size: 11px; font-weight: 600; }}
QLabel#EnLigne {{ color: {ok}; font-size: 13px; font-weight: 600; }}
QFrame#EncartVersion {{
    background: transparent; border: 1px solid transparent; border-radius: 8px;
    margin: 6px 14px 0 14px;
}}
QFrame#EncartVersion:hover {{ border-color: {border}; background: {surface}; }}
QFrame#EncartVersion[etat="disponible"] {{
    border-color: {accent_dim}; background: rgba(56, 225, 255, 22);
}}
QFrame#EncartVersion[etat="disponible"]:hover {{ border-color: {accent}; }}
QFrame#EncartVersion[etat="erreur"] {{ border-color: {warn}; }}
QFrame#EncartVersion[etat="telechargement"],
QFrame#EncartVersion[etat="installation"] {{ border-color: {border_hi}; }}
QLabel#EncartVersionTitre {{ color: {text_faint}; font-size: 11px; font-weight: 600; }}
QLabel#EncartVersionInfo {{ color: {text_faint}; font-size: 10px; font-weight: 500; }}
QFrame#EncartVersion[etat="disponible"] QLabel#EncartVersionTitre {{ color: {accent}; }}
QFrame#EncartVersion[etat="disponible"] QLabel#EncartVersionInfo {{ color: {text}; }}
QFrame#EncartVersion[etat="a_jour"] QLabel#EncartVersionInfo {{ color: {ok}; }}
QFrame#EncartVersion[etat="erreur"] QLabel#EncartVersionTitre {{ color: {warn}; }}
QFrame#EncartVersion[etat="telechargement"] QLabel#EncartVersionTitre,
QFrame#EncartVersion[etat="installation"] QLabel#EncartVersionTitre {{ color: {text}; }}
QLabel#NavSection {{
    color: {text_faint}; font-size: 10px; letter-spacing: 2px; font-weight: 600;
    padding: 18px 20px 6px 20px; text-transform: uppercase;
}}
QCheckBox#SourceFilter {{ color: {text_dim}; font-weight: 500; padding: 5px 20px; spacing: 9px; }}
QCheckBox#SourceFilter:hover {{ color: {text}; }}
QCheckBox::indicator {{
    width: 14px; height: 14px; border-radius: 4px;
    border: 1px solid {border_hi}; background: {surface};
}}
QCheckBox::indicator:checked {{ background: {accent}; border-color: {accent}; }}

/* ---------- En-tete ---------- */
QWidget#Header {{ background: {bg}; border-bottom: 1px solid {border}; }}
QLabel#PageTitle {{ font-size: 19px; font-weight: 600; min-height: 34px; }}
QLabel#SectionTitle {{
    color: {text_faint}; font-size: 11px; letter-spacing: 2px; font-weight: 600;
    padding-top: 10px; text-transform: uppercase;
}}
QLabel#Alerte {{
    color: {warn}; background: rgba(255, 180, 84, 18); border: 1px solid rgba(255, 180, 84, 60);
    border-radius: 8px; padding: 8px 10px; font-size: 12px;
}}
QLabel#Pastille {{
    font-size: 10.5px; font-weight: 700; border-radius: 4px; padding: 2px 7px;
    border: 1px solid {border_hi}; color: {text_dim};
}}
QLabel#Pastille[nature="officiel"] {{ color: {ok}; border-color: {ok}; }}
QLabel#Pastille[nature="tolere"] {{ color: {warn}; border-color: {warn}; }}
QLabel#BarreAdresse {{
    background: {surface}; border: 1px solid {border}; border-radius: 6px;
    padding: 5px 9px; font-size: 12px; color: {text_dim};
}}
QLabel#BarreAdresse[sur="true"] {{ color: {ok}; }}
QLabel#BarreAdresse[sur="false"] {{ color: {warn}; }}
QLabel#SuccesObtenu {{ color: {text}; }}
QLabel#SuccesManquant {{ color: {text_faint}; }}
QPushButton#Chip {{
    background: transparent; border: 1px solid {border}; border-radius: 12px;
    padding: 4px 12px; font-size: 12px; color: {text_dim};
}}
QPushButton#Chip:checked {{ border-color: {accent}; color: {accent}; }}
/* onglets segmentes (Boutique : Offres | Gratuits) */
QFrame#Segments {{
    background: {glass_flat}; border: 1px solid {border}; border-radius: 11px;
}}
QPushButton#Segment {{
    text-align: left; background: transparent; border: 1px solid transparent;
    border-radius: 8px; padding: 7px 15px; color: {text_dim}; font-size: 13px;
    font-weight: 600;
}}
QPushButton#Segment:hover {{ color: {text}; background: {surface}; }}
QPushButton#Segment:checked {{
    background: {surface_hi}; color: {accent}; border: 1px solid {border_hi};
}}
QPushButton#Segment:focus {{ border: 1px solid {accent}; }}
QLabel#Rare {{ color: {photo}; font-size: 11px; font-weight: 700; }}
QLabel#PageHint {{ color: {text_faint}; font-size: 12px; }}
QLineEdit#Search {{
    background: {surface}; border: 1px solid {border}; border-radius: 9px;
    padding: 8px 14px; color: {text}; selection-background-color: {accent_dim};
}}
QLineEdit#Search:focus {{ border-color: {accent}; }}

/* ---------- Boutons ---------- */
QPushButton {{
    background: {surface}; border: 1px solid {border}; border-radius: 8px;
    padding: 8px 15px; color: {text};
}}
QPushButton:hover {{ background: {surface_hi}; border-color: {border_hi}; }}
QPushButton:pressed {{ background: {bg_alt}; }}
QPushButton:focus {{ border-color: {accent}; }}
QPushButton:disabled {{ color: {text_faint}; background: {bg_alt}; }}
QPushButton#Primary {{
    background: {accent}; border: none; color: #04121A; font-weight: 700;
    padding: 12px 26px; border-radius: 9px; font-size: 14px;
}}
QPushButton#Primary:hover {{ background: {text}; }}
QPushButton#Ghost {{ background: transparent; border: 1px solid {border}; }}
QPushButton#Ghost:hover {{ border-color: {accent}; color: {accent}; }}
QPushButton#Ghost:checked {{
    /* pas de gras : Qt dimensionne le bouton avec la police normale, un
       texte gras serait coupe une fois le bouton coche */
    border-color: {accent}; color: {accent}; background: {surface};
}}

/* ---------- Bandeau d'information ---------- */
QFrame#Notice {{
    background: {glass_flat}; border: 1px solid {warn}; border-left: 3px solid {warn};
    border-radius: 10px;
}}

/* ---------- Cartes de disque (page Stockage) ---------- */
QFrame#DiskCard {{
    background: {glass_panel}; border: 1px solid {border}; border-radius: 12px;
}}
QFrame#DiskCard:hover {{ border-color: {border_hi}; }}
QFrame#DiskCard[actif="oui"] {{
    border: 1px solid {accent}; background: {surface_hi};
}}

/* ---------- Banniere d'accueil ---------- */
QFrame#Hero {{ border: none; border-radius: 14px; }}
QLabel#HeroEyebrow {{
    color: {accent}; font-size: 11px; font-weight: 700;
    letter-spacing: 2px; text-transform: uppercase;
}}
QLabel#HeroTitle {{
    color: {text}; font-size: 34px; font-weight: 800; letter-spacing: -0.5px;
}}
QLabel#HeroMeta {{ color: {text_dim}; font-size: 13px; }}
QPushButton#HeroProfile {{
    background: rgba(255, 255, 255, 22); border: 1px solid rgba(255,255,255,40);
    border-radius: 9px; padding: 11px 18px; color: {text}; font-size: 13px;
}}
QPushButton#HeroProfile:hover {{
    border-color: {accent}; color: {accent};
}}
QPushButton#HeroProfile:checked {{
    background: rgba(56, 225, 255, 38); border-color: {accent};
    color: {accent}; font-weight: 700;
}}
QPushButton#HeroGhost {{
    background: transparent; border: 1px solid rgba(255,255,255,46);
    border-radius: 9px; padding: 11px 18px; color: {text_dim}; font-size: 13px;
}}
QPushButton#HeroGhost:hover {{ color: {text}; border-color: rgba(255,255,255,90); }}

/* ---------- Tuiles de jeu ---------- */
QFrame#GameCard {{
    background: {glass_card}; border: 1px solid {border}; border-radius: 12px;
}}
QFrame#GameCard:hover {{ border-color: {accent}; background: {glass_card_hi}; }}
QFrame#GameCard:focus {{
    border: 2px solid {accent}; background: {surface_hi};
}}
QLabel#CardTitle {{ font-size: 12px; font-weight: 600; }}
QLabel#CardMeta {{ color: {text_faint}; font-size: 10px; }}
QLabel#CardBadge {{
    color: {text_dim}; font-size: 9px; font-weight: 700; letter-spacing: 1px;
    background: rgba(10,13,20,190); border-radius: 4px; padding: 2px 5px;
}}

/* ---------- Cartes et panneaux ---------- */
QFrame#Panel {{
    background: {glass_panel}; border: 1px solid {border}; border-radius: 12px;
}}
QFrame#PanelFlat {{ background: {glass_flat}; border-radius: 12px; }}
QLabel#PanelTitle {{ font-size: 15px; font-weight: 600; }}
QLabel#Key {{ color: {text_faint}; font-size: 12px; }}
QLabel#Value {{ font-size: 13px; font-weight: 600; }}
QLabel#HeroTitle {{ font-size: 30px; font-weight: 700; }}
QLabel#Dim {{ color: {text_dim}; }}
QLabel#Faint {{ color: {text_faint}; font-size: 11px; }}

/* ---------- Profils ---------- */
QFrame#ProfileCard {{
    background: {surface}; border: 1px solid {border}; border-radius: 12px;
}}
QFrame#ProfileCard[selected="true"] {{ border: 2px solid {accent}; background: {surface_hi}; }}
QFrame#ProfileCard:hover {{ border-color: {border_hi}; }}
QLabel#ProfileName {{ font-size: 15px; font-weight: 700; }}
QLabel#ProfileTag {{ color: {text_dim}; font-size: 11px; }}

/* ---------- Conseils ---------- */
QFrame#Advice {{ background: {surface}; border-radius: 10px; border: 1px solid {border}; }}
QFrame#Advice[level="attention"] {{ border-left: 3px solid {warn}; }}
QFrame#Advice[level="conseil"] {{ border-left: 3px solid {accent}; }}
QFrame#Advice[level="info"] {{ border-left: 3px solid {border_hi}; }}

/* ---------- Tableaux et listes ---------- */
QTableView, QTreeWidget, QListWidget {{
    background: {bg_alt}; border: 1px solid {border}; border-radius: 10px;
    gridline-color: {border}; outline: none;
}}
QHeaderView::section {{
    background: {surface}; border: none; border-bottom: 1px solid {border};
    padding: 7px; color: {text_faint}; font-size: 11px; font-weight: 600;
}}
QTableView::item {{ padding: 6px; border-bottom: 1px solid {bg}; }}
QTableView::item:selected {{ background: {surface_hi}; }}

/* ---------- Champs ---------- */
QComboBox, QSpinBox, QDoubleSpinBox, QLineEdit {{
    background: {surface}; border: 1px solid {border}; border-radius: 8px;
    padding: 7px 11px;
}}
QPlainTextEdit, QTextEdit {{
    background: {surface}; border: 1px solid {border}; border-radius: 8px;
    padding: 6px 8px; color: {text};
}}
QPlainTextEdit:focus, QTextEdit:focus, QLineEdit:focus {{ border-color: {accent}; }}
QComboBox:hover, QSpinBox:hover, QDoubleSpinBox:hover {{ border-color: {border_hi}; }}
QComboBox::drop-down {{ border: none; width: 22px; }}
QComboBox QAbstractItemView {{
    background: {surface}; border: 1px solid {border_hi};
    selection-background-color: {surface_hi}; outline: none;
}}
QCheckBox {{ spacing: 9px; }}
QSpinBox::up-button, QSpinBox::down-button,
QDoubleSpinBox::up-button, QDoubleSpinBox::down-button {{
    background: {surface_hi}; border: none; width: 14px;
}}

/* ---------- Divers ---------- */
QStackedWidget {{ background: transparent; }}
QScrollArea {{ border: none; background: transparent; }}
QScrollArea > QWidget {{ background: transparent; }}
QScrollArea > QWidget > QWidget {{ background: transparent; }}
QScrollBar:vertical {{ background: transparent; width: 9px; margin: 2px; }}
QScrollBar::handle:vertical {{ background: {border_hi}; border-radius: 4px; min-height: 34px; }}
QScrollBar::handle:vertical:hover {{ background: {accent_dim}; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; }}
QScrollBar:horizontal {{ background: transparent; height: 9px; }}
QScrollBar::handle:horizontal {{ background: {border_hi}; border-radius: 4px; }}
QProgressBar {{
    background: {surface}; border: none; border-radius: 3px; height: 6px;
    text-align: center; color: transparent;
}}
QProgressBar::chunk {{ background: {accent}; border-radius: 3px; }}
QToolTip {{
    background: {surface_hi}; color: {text}; border: 1px solid {border_hi};
    padding: 6px; border-radius: 6px;
}}
QToolButton#CardMore {{
    background: rgba(10, 13, 20, 200); color: {text};
    border: 1px solid rgba(255, 255, 255, 40); border-radius: 15px;
    font-size: 17px; font-weight: 700; padding: 0 0 2px 0;
}}
QToolButton#CardMore:hover {{
    background: {accent}; color: {bg}; border-color: {accent};
}}
QMenu {{
    background: {surface_hi}; color: {text};
    border: 1px solid {border_hi}; border-radius: 10px; padding: 6px;
}}
QMenu::item {{
    padding: 8px 18px 8px 12px; border-radius: 6px; background: transparent;
}}
QMenu::item:selected {{ background: {surface}; color: {accent}; }}
QMenu::item:disabled {{ color: {text_faint}; }}
QMenu::separator {{ height: 1px; background: {border}; margin: 5px 8px; }}
QMenu::icon {{ padding-left: 8px; }}
QSplitter::handle {{ background: {border}; }}
QTabWidget::pane {{ border: 1px solid {border}; border-radius: 10px; }}
QTabBar::tab {{
    background: transparent; padding: 9px 16px; color: {text_dim};
    border-bottom: 2px solid transparent;
}}
QTabBar::tab:selected {{ color: {text}; border-bottom: 2px solid {accent}; }}
"""
