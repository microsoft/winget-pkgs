"""Prix d'un jeu chez un revendeur de cles, releve par le service d'ORION.

ORION n'interroge jamais le revendeur depuis le PC du joueur : il demande au
service (`api.orion-launcher.com/prix`), qui fait le releve une fois par jeu
et le garde six heures. La demande ne contient que le numero Steam et le
titre du jeu, et le pays ; le service n'enregistre rien sur le demandeur.

Le service ne rend un prix que s'il est sur : la fiche du jeu lui-meme, en cle
Steam activable dans le pays du joueur (jamais un compte, un « Gift », un lot
mystere, une edition ou un DLC), chez un vendeur tres bien note (Kinguin) ou
chez un vendeur unique (Loaded, dont le service lit le catalogue fourni a ses
partenaires). Dans tous les autres cas il ne rend rien, et ORION ecrit « Prix
sur le site ».
"""
from __future__ import annotations

import time

from . import partage
from .core.logging_setup import get

log = get("prix.revendeurs")

ADRESSE = partage.SERVICE + "/prix"
#: duree de vie d'un releve garde sur le PC (le service garde le sien 6 h)
DUREE = 3 * 3600
#: seuls ces sites peuvent etre ouverts depuis une reponse du service
HOTES = {"kinguin": "https://www.kinguin.net/", "loaded": "https://www.loaded.com/"}
#: places de marche : la reputation du vendeur fait partie de la reponse
AVEC_VENDEUR = ("kinguin",)
#: Loaded ne donne pas le numero Steam du jeu : son prix public doit rester
#: proche du prix normal du jeu, sinon c'est un homonyme (vieille version,
#: « remake ») et rien n'est affiche
PUBLIC_MIN, PUBLIC_MAX = 0.6, 1.7


def _valider(site: str, brut) -> dict | None:
    """La reponse du service, verifiee : rien n'est affiche ni ouvert sur la
    foi d'une reponse mal formee."""
    if not isinstance(brut, dict):
        return None
    try:
        prix = float(brut.get("prix"))
    except (TypeError, ValueError):
        return None
    url = str(brut.get("url") or "")
    if not (0 < prix < 1000) or brut.get("devise") != "EUR":
        return None
    if not url.startswith(HOTES.get(site, "\0")):
        return None
    offre = {"prix": round(prix, 2), "devise": "EUR", "url": url,
             "nom": str(brut.get("nom") or "")[:120]}
    if brut.get("choisi") is True:
        offre["choisi"] = True               # fiche choisie a la main : pas forcement une cle Steam
    if site in AVEC_VENDEUR:
        try:
            note = float(brut.get("note"))
            ventes = int(brut.get("ventes"))
        except (TypeError, ValueError):
            return None
        if not (0 <= note <= 100) or ventes < 0:
            return None
        offre.update(note=note, ventes=ventes, vendeur=str(brut.get("vendeur") or "")[:60])
    else:
        try:
            public = float(brut.get("public"))
        except (TypeError, ValueError):
            return None                      # sans prix public, pas de controle possible
        if not (prix <= public < 1000):
            return None
        offre["public"] = round(public, 2)
    return offre


def meme_jeu(offre: dict, prix_normal: float) -> bool:
    """Faux quand le prix public d'un vendeur unique s'ecarte trop du prix
    normal du jeu : ce n'est sans doute pas le meme jeu."""
    public = offre.get("public")
    if public is None:
        return True                          # place de marche : numero Steam verifie par le service
    if not prix_normal or prix_normal <= 0:
        return False
    return PUBLIC_MIN <= public / prix_normal <= PUBLIC_MAX


def offres(appid, titre: str, duree: int | None = None) -> dict:
    """Les offres sures des revendeurs pour ce jeu : {"kinguin": offre ou
    None, "loaded": offre ou None}. Ne leve jamais. `duree` : age maximal
    du releve garde sur le PC (la sortie a la une le relit toutes les 10
    minutes ; le service, lui, garde ce jeu-la 10 minutes aussi)."""
    from .core import region
    vide = {site: None for site in HOTES}
    appid = str(appid or "").strip()
    if not appid.isdigit() or not (titre or "").strip() or region.devise() != "EUR":
        return vide
    from .core.base import Table
    from .core.recherche import titre_recherche
    pays = (region.pays() or "FR").upper()[:2]
    table = Table("prix_revendeurs", maximum=800)
    cle = f"prix|{appid}|{pays}"
    memo = None
    try:
        memo = table.get(cle)
    except Exception:
        pass

    def lire(brut, repondu: bool = False) -> dict:
        brut = brut if isinstance(brut, dict) else {}
        lues = {site: _valider(site, brut.get(site)) for site in HOTES}
        if repondu:
            # le service a repondu : « None » veut dire « aucune cle sure »,
            # pas « on ne sait pas » (voir la fiche : Loaded s'efface alors)
            lues["repondu"] = True
        return lues

    if isinstance(memo, dict) and time.time() - float(memo.get("lu_le") or 0) < (duree or DUREE):
        return lire(memo.get("offres"), True)
    try:
        from .core import reseau
        params = {"appid": appid, "titre": titre_recherche(titre)[:90], "pays": pays}
        if duree:
            params["une"] = "1"
        r = reseau.get(ADRESSE, timeout=12, params=params)
        if r.status_code != 200:
            raise RuntimeError(f"reponse {r.status_code}")
        lues = lire(r.json(), True)
        table.set(cle, {"lu_le": time.time(), "offres": {s: lues[s] for s in HOTES}})
        return lues
    except Exception as exc:
        log.debug("Prix des revendeurs indisponibles pour %s : %s", appid, exc)
        return lire(memo.get("offres")) if isinstance(memo, dict) else vide


#: noms affiches des revendeurs dont le service releve le prix
NOMS = {"kinguin": "Kinguin", "loaded": "Loaded"}
#: jeux par demande au service, et passes au plus pour une page de cartes
#: (le service ne releve que huit jeux nouveaux par demande)
LOT = 20
PASSES = 6


def libelle(cle: dict | None, sortie=None) -> str:
    """Ce que vend le revendeur, a afficher devant son prix. « Cle Steam
    verifiee » pour une offre trouvee par le service (cle Steam du jeu) ;
    pour une fiche choisie a la main, son type tel qu'ecrit dans la liste des
    sorties (10 octobre : la precommande de Modern Warfare 4 chez Kinguin est
    une cle Microsoft Store, l'affiche disait « Cle Steam verifiee »)."""
    if not isinstance(cle, dict) or not cle.get("choisi"):
        return "Cle Steam verifiee"
    base = str(cle.get("url") or "").split("?")[0].rstrip("/")
    try:
        from . import sorties
        candidates = ([sortie] if sortie is not None else []) + list(sorties.embarquee())
        for s in candidates:
            for r in getattr(s, "revendeurs", ()) or ():
                if str(r.get("url", "")).split("?")[0].rstrip("/") == base and r.get("quoi"):
                    return str(r["quoi"])
    except Exception:
        pass
    return "Cle PC (fiche choisie par ORION)"


def meilleure_cle(offres: dict, prix_officiel: float, prix_normal: float) -> dict | None:
    """La cle verifiee la moins chere parmi `offres` ({site: offre}), si elle
    est moins chere que la meilleure boutique sure et s'il s'agit bien du
    meme jeu. Rend l'offre avec son site (« site », « boutique »), ou None."""
    choix = None
    for site, offre in (offres or {}).items():
        if not isinstance(offre, dict) or site not in HOTES:
            continue
        if not (prix_officiel and offre["prix"] < prix_officiel) or not meme_jeu(offre, prix_normal):
            continue
        if choix is None or offre["prix"] < choix["prix"]:
            choix = {**offre, "site": site, "boutique": NOMS.get(site, site)}
    return choix


def lot(jeux) -> dict:
    """Les offres sures deja connues pour une page de jeux : {appid: {site:
    offre ou None}}. `jeux` : [(appid, titre)]. Ne leve jamais.

    Sert aux cartes de la Boutique. Le service rend ce qu'il sait deja (un
    releve complet fait a l'ouverture d'une fiche, Kinguin compris) et, pour
    les autres jeux, le seul prix de Loaded, lu dans le catalogue que Loaded
    fournit a ses partenaires. Kinguin n'est jamais interroge en masse. Un
    site absent d'une reponse n'a pas ete releve : rien n'est affiche."""
    from .core import region
    from .core.recherche import titre_recherche
    voulus = {}
    for appid, titre in jeux or []:
        appid, titre = str(appid or "").strip(), titre_recherche(titre or "")[:90]
        if appid.isdigit() and len(titre) >= 2:
            voulus.setdefault(appid, titre)
    if not voulus or region.devise() != "EUR":
        return {}
    from .core.base import Table
    pays = (region.pays() or "FR").upper()[:2]
    table = Table("prix_revendeurs", maximum=800)
    maintenant = time.time()

    def lire(brut) -> dict:
        brut = brut if isinstance(brut, dict) else {}
        return {site: _valider(site, brut.get(site)) for site in HOTES if site in brut}

    connus: dict[str, dict] = {}
    for appid in voulus:
        for cle in (f"prix|{appid}|{pays}", f"lot|{appid}|{pays}"):
            try:
                memo = table.get(cle)
            except Exception:
                memo = None
            if isinstance(memo, dict) and maintenant - float(memo.get("lu_le") or 0) < DUREE:
                connus[appid] = lire(memo.get("offres"))
                break
    manquants = [a for a in voulus if a not in connus]
    try:
        from .core import reseau
        for _passe in range(PASSES):
            if not manquants:
                break
            recus = 0
            for i in range(0, len(manquants), LOT):
                bloc = manquants[i:i + LOT]
                r = reseau.requete("POST", ADRESSE + "/lot", timeout=20, json={
                    "pays": pays, "jeux": [{"appid": a, "titre": voulus[a]} for a in bloc]})
                if r.status_code != 200:
                    raise RuntimeError(f"reponse {r.status_code}")
                prix = (r.json() or {}).get("prix")
                for appid, brut in (prix if isinstance(prix, dict) else {}).items():
                    if appid in bloc and isinstance(brut, dict):
                        connus[appid] = lire(brut)
                        table.set(f"lot|{appid}|{pays}", {"lu_le": maintenant,
                                                           "offres": connus[appid]})
                        recus += 1
            manquants = [a for a in manquants if a not in connus]
            if not recus:
                break                # rien de neuf : plafond du service ou Loaded muet
    except Exception as exc:
        log.debug("Prix des revendeurs par lot indisponibles : %s", exc)
    return connus


def kinguin(appid, titre: str) -> dict | None:
    """L'offre sure de Kinguin pour ce jeu, ou None. Ne leve jamais."""
    return offres(appid, titre).get("kinguin")
