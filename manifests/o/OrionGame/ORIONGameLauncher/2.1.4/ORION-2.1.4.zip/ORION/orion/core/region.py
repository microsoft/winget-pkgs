"""Pays, devise et langue des donnees (1.9.4).

Un seul reglage de pays (`market.country`) decide des prix demandes aux
boutiques, des jeux gratuits et de la devise affichee ; la langue de
l'interface decide de la langue des textes demandes a Steam. Au tout
premier lancement, les deux sont pris sur Windows : un joueur americain
voit l'anglais et des dollars sans rien regler.
"""
from __future__ import annotations

from .config import CONFIG

#: pays proposes dans les Reglages et leur devise
PAYS: dict[str, str] = {
    "FR": "EUR", "BE": "EUR", "LU": "EUR", "DE": "EUR", "ES": "EUR", "IT": "EUR",
    "CH": "CHF", "CA": "CAD", "US": "USD", "GB": "GBP",
}
SYMBOLES = {"EUR": "€", "USD": "$", "GBP": "£", "CHF": "CHF", "CAD": "$ CA"}
SYMBOLES_EN = {"EUR": "€", "USD": "$", "GBP": "£", "CHF": "CHF ", "CAD": "CA$"}


def pays() -> str:
    """Code du pays des prix (« FR », « US »...)."""
    code = str(CONFIG.get("market.country") or "FR").strip().upper()
    return code if len(code) == 2 and code.isalpha() else "FR"


def cc() -> str:
    return pays().lower()


def devise() -> str:
    return PAYS.get(pays(), "EUR")


def anglais() -> bool:
    return str(CONFIG.get("langue", "fr") or "fr") == "en"


def langue_steam() -> str:
    """Langue des textes demandes a Steam (genres, descriptions, succes)."""
    return "english" if anglais() else "french"


def locale_gog() -> str:
    return "en-US" if anglais() else "fr-FR"


def symbole(code: str | None = None) -> str:
    code = (code or devise()).upper()
    return (SYMBOLES_EN if anglais() else SYMBOLES).get(code, code).strip()


def prix(valeur: float, code: str | None = None, decimales: bool = True) -> str:
    """« 59,99 € » en francais, « $59.99 » en anglais, dans la devise du
    pays choisi (ou celle donnee par la boutique)."""
    code = (code or devise()).upper()
    nombre = f"{valeur:,.2f}" if decimales else f"{round(valeur):,}"
    if anglais():
        return f"{SYMBOLES_EN.get(code, code + ' ')}{nombre}"
    nombre = nombre.replace(",", " ").replace(".", ",")
    return f"{nombre} {SYMBOLES.get(code, code)}"


# ----------------------------------------------------------------------
def _locale_windows() -> str:
    """« fr-FR », « en-US »... d'apres Windows (vide si inconnu)."""
    try:
        import ctypes
        tampon = ctypes.create_unicode_buffer(85)
        if ctypes.windll.kernel32.GetUserDefaultLocaleName(tampon, 85):   # type: ignore[attr-defined]
            return tampon.value
    except Exception:
        pass
    try:
        import locale
        import os
        return (os.environ.get("LC_ALL") or os.environ.get("LANG")
                or (locale.getlocale()[0] or "")).split(".")[0].replace("_", "-")
    except Exception:
        return ""


def detecter(nom: str | None = None) -> tuple[str, str]:
    """(langue de l'interface, pays des prix) d'apres la region de Windows.
    Une region inconnue donne l'anglais et les Etats-Unis ; une region
    francophone hors liste donne le francais et la France."""
    nom = (_locale_windows() if nom is None else nom) or ""
    morceaux = nom.replace("_", "-").split("-")
    langue = "fr" if morceaux[0].lower() == "fr" else "en"
    territoire = morceaux[-1].upper() if len(morceaux) > 1 else ""
    if territoire not in PAYS:
        territoire = "FR" if langue == "fr" else "US"
    return langue, territoire


def premier_lancement() -> bool:
    """Au tout premier lancement, regle la langue et le pays sur Windows.
    Une installation existante n'est jamais modifiee. Vrai si regle."""
    if CONFIG.get("region_detectee"):
        return False
    regle = False
    if getattr(CONFIG, "nouvelle", False):
        langue, territoire = detecter()
        CONFIG.set("langue", langue, save=False)
        CONFIG.set("market.country", territoire, save=False)
        regle = True
    CONFIG.set("region_detectee", True)
    return regle
