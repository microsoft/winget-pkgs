"""Page « Sorties » : les plus grosses sorties a venir, avec compte a rebours (1.8.1).

Tout ce qui se voit ici est peint a la main (QPainter) : le ciel etoile du
fond (avec la constellation d'Orion, qui a donne son nom au launcher), la
grande affiche de la sortie la plus attendue et ses quatre compteurs, et
les cartes des autres sorties rangees par mois. Les secondes defilent
une fois par seconde, seulement quand la page est affichee.
"""
from __future__ import annotations

import time

import datetime as dt
import random

from PySide6.QtCore import QPointF, QRectF, QSize, Qt, QTimer, Signal
from PySide6.QtGui import (QBrush, QColor, QCursor, QFont, QFontMetrics,
                           QLinearGradient, QPainter, QPainterPath, QPen,
                           QPixmap, QRadialGradient)
from PySide6.QtWidgets import (QButtonGroup, QFrame, QHBoxLayout, QLabel,
                               QPushButton, QSizePolicy, QSpacerItem, QVBoxLayout,
                               QWidget)

from ... import sorties as S
from ...core.logging_setup import get
from ...i18n import t
from ..theme import PALETTE, accent
from ..widgets.flow_layout import FlowLayout
from ..widgets.layouts import clear_layout
from ..widgets.tampon import Tampon
from ..defilement import ZoneDefilante

log = get("ui.sorties_view")

POLICE = "Segoe UI Variable Display"
FILTRES = (("toutes", "Toutes"), ("pc", "PC"), ("ps5", "PS5"),
           ("xbox", "Xbox Series"), ("switch2", "Switch 2"))
MOIS_COURT = ("JANV.", "FEVR.", "MARS", "AVR.", "MAI", "JUIN", "JUIL.", "AOUT",
              "SEPT.", "OCT.", "NOV.", "DEC.")
MONTHS_SHORT = ("JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT",
                "NOV", "DEC")

#: constellation d'Orion (positions relatives dans un carre 1 x 1)
ORION_ETOILES = {
    "betelgeuse": (0.18, 0.12), "bellatrix": (0.72, 0.20),
    "alnitak": (0.36, 0.52), "alnilam": (0.47, 0.49), "mintaka": (0.58, 0.46),
    "saiph": (0.28, 0.90), "rigel": (0.80, 0.84), "meissa": (0.46, 0.0),
}
ORION_TRAITS = (("meissa", "betelgeuse"), ("meissa", "bellatrix"),
                ("betelgeuse", "alnitak"), ("bellatrix", "mintaka"),
                ("alnitak", "alnilam"), ("alnilam", "mintaka"),
                ("alnitak", "saiph"), ("mintaka", "rigel"))


_POLICES: dict[tuple, QFont] = {}


def police(taille: float, graisse: int = 400, espacement: float = 0.0) -> QFont:
    """Police de la page, gardee en memoire (la page se repeint chaque seconde).
    Une copie est rendue : l'appelant peut la modifier (italique...)."""
    cle = (int(taille), graisse, espacement)
    f = _POLICES.get(cle)
    if f is None:
        f = QFont(POLICE)
        f.setPixelSize(int(taille))
        f.setWeight(QFont.Weight(graisse))
        if espacement:
            f.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, espacement)
        try:                               # chiffres de largeur fixe (Qt 6.7+)
            f.setFeature(QFont.Tag("tnum"), 1)
        except Exception:
            pass
        _POLICES[cle] = f
    return QFont(f)


def couleur(hexa: str, alpha: int = 255) -> QColor:
    c = QColor(hexa)
    c.setAlpha(alpha)
    return c


def peindre_image(p: QPainter, rect: QRectF, pix: QPixmap) -> None:
    """Image recadree au centre pour couvrir `rect`."""
    if pix.isNull():
        return
    echelle = max(rect.width() / pix.width(), rect.height() / pix.height())
    w, h = pix.width() * echelle, pix.height() * echelle
    cible = QRectF(rect.center().x() - w / 2, rect.center().y() - h / 2, w, h)
    p.drawPixmap(cible, pix, QRectF(pix.rect()))


#: au-dela de ce rapport entre la forme du bandeau et celle de l'image,
#: recadrer couperait trop (titre et visages tranches) : on montre l'image entiere
TROP_ETROITE = 1.35


def image_entiere(rect: QRectF, pix: QPixmap) -> QRectF | None:
    """Ou poser l'image ENTIERE (a droite, sur toute la hauteur) quand elle
    est nettement moins allongee que `rect` ; None si un recadrage suffit."""
    if pix.isNull() or rect.height() <= 0 or pix.height() <= 0:
        return None
    forme_rect = rect.width() / rect.height()
    forme_image = pix.width() / pix.height()
    if forme_rect <= forme_image * TROP_ETROITE:
        return None
    largeur = rect.height() * forme_image
    return QRectF(rect.right() - largeur, rect.top(), largeur, rect.height())


def peindre_bandeau(p: QPainter, rect: QRectF, pix: QPixmap) -> None:
    """Bandeau tres large : l'image est montree entiere a droite, jamais
    tranchee ; derriere, la meme image floutee remplit le reste, et un fondu
    efface la couture."""
    cible = image_entiere(rect, pix)
    if cible is None:
        peindre_image(p, rect, pix)
        return
    # fond : l'image tres reduite puis etiree, donc floue, et assombrie
    flou = pix.scaledToWidth(48, Qt.TransformationMode.SmoothTransformation)
    peindre_image(p, rect, flou)
    p.fillRect(rect, QColor(6, 8, 14, 120))
    # l'image entiere, dont le bord gauche se fond dans le flou (pas de couture)
    taille = cible.size().toSize()
    if taille.isEmpty():
        return
    calque = QPixmap(taille)
    calque.fill(Qt.GlobalColor.transparent)
    q = QPainter(calque)
    q.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
    q.drawPixmap(QRectF(0, 0, taille.width(), taille.height()), pix, QRectF(pix.rect()))
    q.setCompositionMode(QPainter.CompositionMode.CompositionMode_DestinationIn)
    g = QLinearGradient(0, 0, taille.width() * 0.25, 0)
    g.setColorAt(0, QColor(0, 0, 0, 0))
    g.setColorAt(1, QColor(0, 0, 0, 255))
    q.fillRect(calque.rect(), g)
    q.end()
    p.drawPixmap(cible.topLeft(), calque)


def peindre_affiche(p: QPainter, rect: QRectF, s: S.Sortie, pix: QPixmap | None,
                    taille_titre: float, bandeau: bool = False) -> None:
    """Visuel du jeu, ou a defaut une affiche aux couleurs du jeu."""
    if pix is not None and not pix.isNull():
        (peindre_bandeau if bandeau else peindre_image)(p, rect, pix)
        return
    c1, c2 = S.couleurs_valides(s.couleurs)
    g = QLinearGradient(rect.topLeft(), rect.bottomRight())
    g.setColorAt(0, QColor(c1))
    g.setColorAt(1, QColor(c2))
    p.fillRect(rect, g)
    # halo et grain de lumiere
    halo = QRadialGradient(rect.topRight() + QPointF(-rect.width() * 0.2, rect.height() * 0.3),
                           rect.width() * 0.7)
    halo.setColorAt(0, QColor(255, 255, 255, 60))
    halo.setColorAt(1, QColor(255, 255, 255, 0))
    p.fillRect(rect, halo)
    # le titre en grandes lettres, comme sur une affiche
    p.save()
    p.setClipRect(rect)
    p.setPen(QColor(255, 255, 255, 38))
    p.setFont(police(taille_titre, 900, -1))
    p.drawText(rect.adjusted(rect.width() * 0.04, 0, 0, -rect.height() * 0.04),
               Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignBottom
               | Qt.TextFlag.TextWordWrap, s.titre.upper())
    p.restore()


# ----------------------------------------------------------------------
class CarteSortie(QWidget):
    """Carte d'une sortie : visuel, date, titre, plateformes, compte a rebours."""
    ouvrir = Signal(object)

    LARGEUR_MIN, H = 270, 318

    def __init__(self, s: S.Sortie, largeur: int = 300, parent=None) -> None:
        super().__init__(parent)
        self.s = s
        self.pix: QPixmap | None = None
        self.meta: dict = {}
        self.prix = ""                      # « Precommande : 69,99 € » (2.1.0)
        self._survol = False
        self._fond = Tampon()
        self.set_largeur(largeur)
        self.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.setToolTip(self._bulle())

    def set_largeur(self, largeur: int) -> None:
        self.L = max(self.LARGEUR_MIN, int(largeur))
        self.IMG = int(self.L * 0.47)
        self.setFixedSize(QSize(self.L, self.H + self.IMG - 150))

    def _bulle(self) -> str:
        lignes = [self.s.titre]
        if self.s.studio:
            lignes.append(self.s.studio)
        if getattr(self, "prix", ""):
            lignes.append(t(self.prix) + t(" (prix Steam, relu deux fois par jour)"))
        lignes.append(t("Cliquer : fiche Steam") if self.s.steam
                      else t("Cliquer : page officielle"))
        return "\n".join(lignes)

    def set_visuel(self, chemin: str) -> None:
        pix = QPixmap(chemin)
        if not pix.isNull():
            self.pix = pix
            self.update()

    def enterEvent(self, e) -> None:            # noqa: N802
        self._survol = True
        self.update()

    def leaveEvent(self, e) -> None:            # noqa: N802
        self._survol = False
        self.update()

    def mouseReleaseEvent(self, e) -> None:     # noqa: N802
        if e.button() == Qt.MouseButton.LeftButton:
            self.ouvrir.emit(self.s)

    def paintEvent(self, _e) -> None:           # noqa: N802
        p = QPainter(self)
        try:
            # tout ce qui ne bouge pas (visuel, titre, plateformes...) est
            # garde en image : chaque seconde, seul le compte a rebours est
            # redessine, et non les trente cartes de la page
            s = self.s
            delta = S.restant(s)
            sortie = delta is not None and delta.total_seconds() <= 0
            cle = (s.id, s.titre, s.studio, s.genre, self.pix.cacheKey() if self.pix else 0,
                   self.L, self.IMG, str(sorted(self.meta.items())), sortie,
                   str(s.jour), accent(), t("DISPONIBLE"), str(s.plateformes))
            self._fond.peindre(self, p, cle, self._peindre)
            self._peindre_vif(p, delta)
        except Exception:                      # donnee mal formee : carte vide, pas de plantage
            log.exception("Carte de sortie impossible a peindre : %s",
                          getattr(self.s, "id", "?"))
        finally:
            if p.isActive():
                p.end()

    def _peindre(self, p: QPainter) -> None:
        s = self.s
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        HT = self.height()
        r = QRectF(0.5, 0.5, self.L - 1, HT - 1)
        forme = QPainterPath()
        forme.addRoundedRect(r, 14, 14)
        p.setClipPath(forme)
        p.fillPath(forme, QColor(16, 21, 33, 232))

        img = QRectF(0, 0, self.L, self.IMG)
        peindre_affiche(p, img, s, self.pix, 34)
        voile = QLinearGradient(0, self.IMG * 0.45, 0, self.IMG)
        voile.setColorAt(0, QColor(16, 21, 33, 0))
        voile.setColorAt(1, QColor(16, 21, 33, 235))
        p.fillRect(img, voile)

        # pastille de date
        j = s.jour
        if j is not None:
            pastille = QRectF(12, 12, 58, 74)
            chemin = QPainterPath()
            chemin.addRoundedRect(pastille, 10, 10)
            p.fillPath(chemin, QColor(8, 11, 18, 200))
            p.setPen(QPen(QColor(255, 255, 255, 40), 1))
            p.drawPath(chemin)
            p.setPen(QColor(PALETTE["text"]))
            p.setFont(police(24, 800))
            p.drawText(pastille.adjusted(0, 4, 0, -22), Qt.AlignmentFlag.AlignCenter, str(j.day))
            p.setPen(QColor(accent()))
            p.setFont(police(10, 700, 1.2))
            p.drawText(pastille.adjusted(0, 36, 0, -20), Qt.AlignmentFlag.AlignCenter,
                       (MONTHS_SHORT if S.anglais() else MOIS_COURT)[j.month - 1])
            p.setPen(QColor(PALETTE["text_dim"]))
            p.setFont(police(10, 600))
            p.drawText(pastille.adjusted(0, 52, 0, -4), Qt.AlignmentFlag.AlignCenter,
                       str(j.year))
        delta = S.restant(s)
        if delta is not None and delta.total_seconds() <= 0:
            self._badge(p, t("DISPONIBLE"), PALETTE["ok"])

        x, largeur = 16, self.L - 32
        y = self.IMG + 8
        p.setPen(QColor(PALETTE["text"]))
        f = police(16, 700)
        p.setFont(f)
        fm = QFontMetrics(f)
        titre = s.titre
        lignes = self._couper(titre, fm, largeur, 2)
        for ligne in lignes:
            p.drawText(QRectF(x, y, largeur, fm.height()), Qt.AlignmentFlag.AlignLeft, ligne)
            y += fm.height()
        y += 2
        p.setPen(QColor(PALETTE["text_dim"]))
        f = police(12)
        p.setFont(f)
        fm = QFontMetrics(f)
        studio = s.studio or self.meta.get("studio", "")
        genre = t(s.genre) if s.genre else self.meta.get("genre", "")
        meta = " · ".join(b for b in (studio, genre) if b)
        p.drawText(QRectF(x, y, largeur, fm.height()), Qt.AlignmentFlag.AlignLeft,
                   fm.elidedText(meta, Qt.TextElideMode.ElideRight, int(largeur)))
        if self.prix:
            y += fm.height() + 2
            p.setPen(QColor(accent()))
            p.setFont(police(12, 700))
            p.drawText(QRectF(x, y, largeur, fm.height() + 2), Qt.AlignmentFlag.AlignLeft,
                       t(self.prix))

        # plateformes
        yp = HT - 70
        f = police(10.5, 600)
        p.setFont(f)
        fm = QFontMetrics(f)
        xp = x
        for nom in S.noms_plateformes(s) or [t("Plateformes a venir")]:
            w = fm.horizontalAdvance(nom) + 14
            puce = QRectF(xp, yp, w, 20)
            p.setPen(QPen(QColor(PALETTE["border_hi"]), 1))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRoundedRect(puce, 10, 10)
            p.setPen(QColor(PALETTE["text_dim"]))
            p.drawText(puce, Qt.AlignmentFlag.AlignCenter, nom)
            xp += w + 6

        # trait au-dessus du compte a rebours
        ligne = QRectF(x, HT - 40, largeur, 26)
        p.setPen(QPen(QColor(PALETTE["border"]), 1))
        p.drawLine(QPointF(x, ligne.top() - 4), QPointF(x + largeur, ligne.top() - 4))
        p.setClipping(False)

    def _peindre_vif(self, p: QPainter, delta) -> None:
        """Ce qui change : le compte a rebours (chaque seconde) et le contour
        (au survol)."""
        s = self.s
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        HT = self.height()
        r = QRectF(0.5, 0.5, self.L - 1, HT - 1)
        x, largeur = 16, self.L - 32
        ligne = QRectF(x, HT - 40, largeur, 26)
        if delta is None:
            p.setPen(QColor(PALETTE["text_dim"]))
            p.setFont(police(14, 600))
            p.drawText(ligne, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                       S.date_lisible(s))
        elif delta.total_seconds() <= 0:
            p.setPen(QColor(PALETTE["ok"]))
            p.setFont(police(14, 700))
            p.drawText(ligne, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                       S.texte_decompte(delta))
        else:
            p.setPen(QColor(accent()))
            p.setFont(police(16, 700))
            p.drawText(ligne, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                       S.texte_decompte(delta))

        p.setClipping(False)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(QColor(accent()) if self._survol else QColor(255, 255, 255, 28),
                      1.5 if self._survol else 1))
        p.drawRoundedRect(r, 14, 14)

    def _badge(self, p: QPainter, texte: str, teinte: str) -> None:
        f = police(10, 800, 1.2)
        fm = QFontMetrics(f)
        w = fm.horizontalAdvance(texte) + 18
        rect = QRectF(self.L - w - 12, 12, w, 22)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(couleur(teinte, 230))
        p.drawRoundedRect(rect, 11, 11)
        p.setPen(QColor("#06140E"))
        p.setFont(f)
        p.drawText(rect, Qt.AlignmentFlag.AlignCenter, texte)

    @staticmethod
    def _couper(texte: str, fm: QFontMetrics, largeur: float, maxi: int) -> list[str]:
        mots, lignes, courante = texte.split(), [], ""
        for m in mots:
            essai = f"{courante} {m}".strip()
            if fm.horizontalAdvance(essai) <= largeur or not courante:
                courante = essai
            else:
                lignes.append(courante)
                courante = m
        if courante:
            lignes.append(courante)
        if len(lignes) > maxi:
            lignes = lignes[:maxi]
            lignes[-1] = fm.elidedText(lignes[-1] + " …", Qt.TextElideMode.ElideRight,
                                       int(largeur))
        return lignes


# ----------------------------------------------------------------------
class Vedette(QWidget):
    """La grande affiche : la sortie la plus attendue et son compte a rebours."""
    ouvrir = Signal(object)
    suivre = Signal(object)
    acheter = Signal(str)                   # adresse d'une offre (precommande, cle)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.s: S.Sortie | None = None
        self.pix: QPixmap | None = None
        self.meta: dict = {}
        self._fond = Tampon()
        self._url_officiel = ""
        self._url_cle = ""
        self.setMinimumHeight(440)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        bas = QHBoxLayout()
        bas.setContentsMargins(36, 0, 36, 30)
        bas.setSpacing(10)
        self.b_ouvrir = QPushButton("Page officielle")
        self.b_ouvrir.setObjectName("Primary")
        self.b_ouvrir.clicked.connect(lambda: self.s and self.ouvrir.emit(self.s))
        bas.addWidget(self.b_ouvrir)
        self.b_suivre = QPushButton("Suivre dans mes Envies")
        self.b_suivre.setObjectName("Ghost")
        self.b_suivre.setToolTip("Ajoute le jeu a vos Envies : ORION vous previent "
                                 "des baisses de prix.")
        self.b_suivre.clicked.connect(lambda: self.s and self.suivre.emit(self.s))
        bas.addWidget(self.b_suivre)
        bas.addStretch(1)
        # precommandes (2.1.0) : le prix officiel d'abord, la cle verifiee a part
        prix = QVBoxLayout()
        prix.setContentsMargins(36, 0, 36, 10)
        prix.setSpacing(6)
        achats = QHBoxLayout()
        achats.setSpacing(10)
        self.b_precommander = QPushButton("")
        self.b_precommander.setObjectName("Primary")
        self.b_precommander.clicked.connect(
            lambda: self._url_officiel and self.acheter.emit(self._url_officiel))
        achats.addWidget(self.b_precommander)
        self.b_cle = QPushButton("")
        self.b_cle.setObjectName("Ghost")
        self.b_cle.clicked.connect(lambda: self._url_cle and self.acheter.emit(self._url_cle))
        achats.addWidget(self.b_cle)
        achats.addStretch(1)
        prix.addLayout(achats)
        self.detail_prix = QLabel("")
        self.detail_prix.setWordWrap(True)
        self.detail_prix.setStyleSheet("background: transparent; color: rgba(230,236,245,200);"
                                       " font-size: 12px;")
        prix.addWidget(self.detail_prix)
        self.fidelite = QLabel("")
        self.fidelite.setWordWrap(True)
        self.fidelite.setStyleSheet("background: transparent; color: #3DDC97; font-size: 12px;"
                                    " font-weight: 600;")
        prix.addWidget(self.fidelite)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        # la place de la partie peinte (titre, textes, compte a rebours) : les
        # boutons commencent dessous. 10 octobre : avec le bloc des prix (2.1.0),
        # « Precommander » et la cle couvraient le compte a rebours.
        self._place = QSpacerItem(0, 0, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)
        lay.addItem(self._place)
        lay.addStretch(1)
        lay.addLayout(prix)
        lay.addLayout(bas)
        self.set_offre(None)

    def set_offre(self, o) -> None:
        """Bloc prix de la sortie a la une (`precommandes.Offre`), ou None."""
        from ...affiliation import est_partenaire
        officiel = bool(o is not None and o.precommande)
        sortie = bool(self.s is not None and S.restant(self.s) is not None
                      and S.restant(self.s).total_seconds() <= 0)
        self._url_officiel = o.url if officiel else ""
        self.b_precommander.setText(
            (t("Acheter") if sortie else t("Precommander")) + "  ·  " + t(o.texte_officiel)
            if officiel else "")
        self.b_precommander.setVisible(officiel)
        cle = o.cle if officiel and o.cle else None
        self._url_cle = cle["url"] if cle else ""
        self.b_cle.setText(t(cle.get("libelle") or "Cle Steam verifiee") + "  ·  " + cle["boutique"]
                           + "  " + o.montant(cle["prix"]) if cle else "")
        self.b_cle.setToolTip(
            (t("Lien partenaire : le prix ne change pas pour vous. ") if est_partenaire(self._url_cle) else "")
            + (t("Revendeur de cles : fiche choisie a la main par ORION, cle du jeu lui-meme activable "
                 "en Europe, jamais un compte ni un « gift ». Ce n'est pas une boutique officielle.")
               if cle.get("choisi") else
               t("Revendeur de cles : cle Steam du jeu lui-meme, activable dans votre pays, "
                 "verifiee par ORION. Ce n'est pas une boutique officielle.")) if cle else "")
        self.b_cle.setVisible(bool(cle))
        if officiel:
            quand = time.strftime("%H:%M", time.localtime(o.lu_le))
            self.detail_prix.setText(
                t("Prix officiel releve sur Steam a {0}, relu toutes les 10 minutes.").replace("{0}", quand)
                + ("  " + t("Cle verifiee : revendeur, jamais une boutique officielle.") if cle else ""))
        else:
            self.detail_prix.setText("")
        self.detail_prix.setVisible(officiel)
        self.fidelite.setText(t(o.fidelite) if o is not None and o.fidelite else "")
        self.fidelite.setVisible(bool(o is not None and o.fidelite))
        self._ajuster()

    def hauteur_affiche(self) -> int:
        """Hauteur de la partie peinte par `_peindre` puis `_peindre_decompte`
        (memes mesures), marge comprise."""
        s = self.s
        if s is None:
            return 0
        largeur = min(self.width() * 0.62, 760)
        y = 30.0 + 38
        fm = QFontMetrics(police(46, 800, -0.8))
        y += len(CarteSortie._couper(s.titre, fm, largeur, 2)) * (fm.height() - 4)
        y += 8 + 26 + 28
        if s.mot:
            f = police(13, 500)
            f.setItalic(True)
            fm = QFontMetrics(f)
            y += len(CarteSortie._couper(t(s.mot), fm, largeur, 2)) * fm.height() + 6
        else:
            y += 10
        if S.decompte(S.restant(s)) is not None:
            y += 92
        return int(y + 18)

    def _ajuster(self) -> None:
        h = self.hauteur_affiche()
        if h != self._place.sizeHint().height():
            self._place.changeSize(0, h, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)
            self.layout().invalidate()
            self.updateGeometry()

    def resizeEvent(self, e) -> None:          # noqa: N802
        super().resizeEvent(e)
        self._ajuster()

    def definir(self, s: S.Sortie | None) -> None:
        if s is None or self.s is None or s.id != self.s.id:
            self.set_offre(None)
        self.s = s
        self.pix = None
        self.setVisible(s is not None)
        if s is not None:
            self.b_ouvrir.setText("Fiche Steam" if s.steam else "Page officielle")
            self.b_suivre.setVisible(bool(s.steam))
        self._ajuster()
        self.update()

    def set_visuel(self, chemin: str) -> None:
        pix = QPixmap(chemin)
        if not pix.isNull():
            self.pix = pix
            self.update()

    def paintEvent(self, _e) -> None:           # noqa: N802
        if self.s is None:
            return
        p = QPainter(self)
        try:
            # l'affiche (image, voiles, titre, textes) est gardee en image ;
            # chaque seconde, seules les quatre cases du compte a rebours
            # sont redessinees
            s = self.s
            cle = (s.id, s.titre, s.studio, s.genre, s.mot, s.vedette, str(s.jour),
                   self.pix.cacheKey() if self.pix else 0, str(sorted(self.meta.items())),
                   str(s.plateformes), str(s.couleurs), accent(),
                   t("LA PLUS ATTENDUE"))
            self._fond.peindre(self, p, cle, lambda q: self._peindre(q, s))
            self._peindre_decompte(p, s, self._fond.rendu)
        except Exception:                      # donnee mal formee : pas de plantage
            log.exception("Affiche de sortie impossible a peindre : %s",
                          getattr(self.s, "id", "?"))
        finally:
            if p.isActive():
                p.end()

    def _peindre(self, p: QPainter, s: S.Sortie) -> None:
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        r = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        forme = QPainterPath()
        forme.addRoundedRect(r, 20, 20)
        p.setClipPath(forme)
        peindre_affiche(p, r, s, self.pix, 120, bandeau=True)
        entiere = self.pix is not None and image_entiere(r, self.pix) is not None
        # voile : dense a gauche (texte), leger a droite (image). Quand
        # l'image est montree entiere a droite, elle reste a pleine lumiere.
        g = QLinearGradient(r.left(), 0, r.right(), 0)
        g.setColorAt(0, QColor(6, 8, 14, 238))
        g.setColorAt(0.45, QColor(6, 8, 14, 170))
        g.setColorAt(0.62 if entiere else 1, QColor(6, 8, 14, 0 if entiere else 40))
        if entiere:
            g.setColorAt(1, QColor(6, 8, 14, 0))
        p.fillRect(r, g)
        g = QLinearGradient(0, r.bottom() - 140, 0, r.bottom())
        g.setColorAt(0, QColor(6, 8, 14, 0))
        g.setColorAt(1, QColor(6, 8, 14, 170))
        p.fillRect(r, g)

        x = 36.0
        y = 30.0
        # etiquette
        etiquette = t("A LA UNE" if s.une else "LA PLUS ATTENDUE" if s.vedette
                      else "PROCHAINE GROSSE SORTIE")
        f = police(11, 800, 2.2)
        fm = QFontMetrics(f)
        w = fm.horizontalAdvance(etiquette) + 22
        p.setPen(Qt.PenStyle.NoPen)
        teinte = S.couleurs_valides(s.couleurs)[0]
        p.setBrush(couleur(teinte, 235))
        p.drawRoundedRect(QRectF(x, y, w, 24), 12, 12)
        p.setPen(QColor("#0A0D14") if QColor(teinte).lightness() > 120
                 else QColor("#FFFFFF"))
        p.setFont(f)
        p.drawText(QRectF(x, y, w, 24), Qt.AlignmentFlag.AlignCenter, etiquette)
        y += 38

        largeur = min(self.width() * 0.62, 760)
        f = police(46, 800, -0.8)
        p.setFont(f)
        fm = QFontMetrics(f)
        p.setPen(QColor("#FFFFFF"))
        for ligne in CarteSortie._couper(s.titre, fm, largeur, 2):
            p.drawText(QRectF(x, y, largeur, fm.height()), Qt.AlignmentFlag.AlignLeft, ligne)
            y += fm.height() - 4
        y += 8
        studio = s.studio or self.meta.get("studio", "")
        genre = t(s.genre) if s.genre else self.meta.get("genre", "")
        meta = "  ·  ".join(b for b in (studio, genre,
                                        " / ".join(S.noms_plateformes(s)))
                            if b)
        p.setFont(police(14, 500))
        p.setPen(QColor(230, 236, 245, 210))
        p.drawText(QRectF(x, y, largeur, 22), Qt.AlignmentFlag.AlignLeft, meta)
        y += 26
        p.setFont(police(15, 700))
        p.setPen(QColor(accent()))
        p.drawText(QRectF(x, y, largeur, 22), Qt.AlignmentFlag.AlignLeft,
                   (t("Sortie le") + " " + S.date_lisible(s)) if s.jour else S.date_lisible(s))
        y += 28
        if s.mot:
            f = police(13, 500)
            f.setItalic(True)
            p.setFont(f)
            fm = QFontMetrics(f)
            p.setPen(QColor(230, 236, 245, 200))
            for ligne in CarteSortie._couper(t(s.mot), fm, largeur, 2):
                p.drawText(QRectF(x, y, largeur, fm.height()), Qt.AlignmentFlag.AlignLeft, ligne)
                y += fm.height()
            y += 6
        else:
            y += 10

        return x, y

    def _peindre_decompte(self, p: QPainter, s: S.Sortie, place) -> None:
        if not place:
            return
        x, y = place
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        d = S.decompte(S.restant(s))
        if d is not None:
            for valeur, nom in zip(d, ("JOURS", "HEURES", "MINUTES", "SECONDES")):
                boite = QRectF(x, y, 104, 92)
                chemin = QPainterPath()
                chemin.addRoundedRect(boite, 14, 14)
                p.fillPath(chemin, QColor(255, 255, 255, 24))
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.setPen(QPen(QColor(255, 255, 255, 56), 1))
                p.drawPath(chemin)
                p.setPen(QColor("#FFFFFF"))
                p.setFont(police(44, 800))
                p.drawText(boite.adjusted(0, 6, 0, -26), Qt.AlignmentFlag.AlignCenter,
                           f"{valeur:02d}" if nom != "JOURS" else str(valeur))
                p.setPen(QColor(230, 236, 245, 160))
                p.setFont(police(10, 700, 2))
                p.drawText(boite.adjusted(0, 60, 0, -8), Qt.AlignmentFlag.AlignCenter, t(nom))
                x += 116


# ----------------------------------------------------------------------
class SortiesView(QWidget):
    ouvrir_lien = Signal(str)
    suivre = Signal(str, str)                 # identifiant Steam, titre
    actualiser_demande = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._liste: list[S.Sortie] = []
        self._maj = S.MAJ
        self._filtre = "toutes"
        self._cartes: list[CarteSortie] = []
        self._visuels: dict[str, dict] = {}
        self._montrees: list[S.Sortie] = []
        self._etoiles = self._semer(260)

        racine = QVBoxLayout(self)
        racine.setContentsMargins(0, 0, 0, 0)
        defil = ZoneDefilante()
        defil.setWidgetResizable(True)
        defil.setFrameShape(QFrame.Shape.NoFrame)
        defil.setStyleSheet("QScrollArea, QScrollArea > QWidget > QWidget "
                            "{ background: transparent; }")
        racine.addWidget(defil)
        contenu = QWidget()
        contenu.setObjectName("SortiesContenu")
        defil.setWidget(contenu)
        self.lay = QVBoxLayout(contenu)
        self.lay.setContentsMargins(40, 34, 40, 36)
        self.lay.setSpacing(18)

        tete = QVBoxLayout()
        tete.setSpacing(4)
        sur = QLabel("SORTIES A VENIR")
        sur.setStyleSheet(f"color: {accent()}; font-size: 12px; font-weight: 800; "
                          "letter-spacing: 3px; background: transparent;")
        tete.addWidget(sur)
        titre = QLabel("Les plus grosses sorties, toutes plateformes")
        titre.setStyleSheet("color: #FFFFFF; font-size: 32px; font-weight: 800; "
                            "background: transparent;")
        tete.addWidget(titre)
        self.sous_titre = QLabel("")
        self.sous_titre.setObjectName("Dim")
        self.sous_titre.setStyleSheet("background: transparent;")
        tete.addWidget(self.sous_titre)
        self.lay.addLayout(tete)

        self.vedette = Vedette()
        self.vedette.ouvrir.connect(self._ouvrir)
        self.vedette.suivre.connect(lambda s: self.suivre.emit(s.steam, s.titre))
        self.vedette.acheter.connect(self.ouvrir_lien.emit)
        self._prix_cartes: dict[str, str] = {}
        self.lay.addWidget(self.vedette)

        barre = QHBoxLayout()
        barre.setSpacing(8)
        self.groupe = QButtonGroup(self)
        self.puces: dict[str, QPushButton] = {}
        for cle, texte in FILTRES:
            b = QPushButton(texte)
            b.setObjectName("Chip")
            b.setCheckable(True)
            b.clicked.connect(lambda _=False, c=cle: self._filtrer(c))
            self.groupe.addButton(b)
            barre.addWidget(b)
            self.puces[cle] = b
        self.puces["toutes"].setChecked(True)
        barre.addStretch(1)
        self.compte = QLabel("")
        self.compte.setObjectName("Faint")
        barre.addWidget(self.compte)
        self.lay.addLayout(barre)

        self.sections = QVBoxLayout()
        self.sections.setSpacing(14)
        self.lay.addLayout(self.sections)

        pied = QLabel(
            "Dates officielles annoncees par les editeurs. Le compte a rebours vise minuit "
            "(heure de votre PC) le jour de la sortie ; l'heure de deblocage peut varier "
            "selon la plateforme et le pays. Un jeu sans date officielle n'a pas de compte "
            "a rebours. La liste est mise a jour en ligne par ORION quand une date change.")
        pied.setObjectName("Faint")
        pied.setWordWrap(True)
        pied.setStyleSheet("background: transparent;")
        self.lay.addWidget(pied)
        self.lay.addStretch(1)

        self._tic = QTimer(self)
        self._tic.setInterval(1000)
        self._tic.timeout.connect(self._seconde)

    # ------------------------------------------------------------------
    def definir(self, liste: list[S.Sortie], maj: str) -> None:
        self._liste = liste
        self._maj = maj
        try:
            quand = S.date_lisible(S.Sortie("maj", "maj", date=maj))
        except ValueError:
            quand = maj
        self.sous_titre.setText(f"PC, PlayStation, Xbox et Switch  ·  dates officielles  ·  "
                                f"liste mise a jour le {quand}")
        self._rendre()

    def set_visuels(self, visuels: dict[str, dict]) -> None:
        """{id de sortie: {'carte': chemin, 'fond': chemin}}."""
        self._visuels.update(visuels)
        for c in self._cartes:
            v = self._visuels.get(c.s.id) or {}
            c.meta = v
            if v.get("carte") and c.pix is None:
                c.set_visuel(v["carte"])
            c.update()
        s = self.vedette.s
        if s is not None:
            self.vedette.meta = self._visuels.get(s.id) or {}
            self.vedette.update()
        if s is not None and self.vedette.pix is None:
            v = self._visuels.get(s.id) or {}
            if v.get("fond") or v.get("carte"):
                self.vedette.set_visuel(v.get("fond") or v["carte"])

    def set_offre(self, o) -> None:
        """Bloc prix de la sortie a la une (voir `precommandes.offre_une`)."""
        if o is not None and (self.vedette.s is None or self.vedette.s.steam != o.appid):
            return                              # la une a change entre-temps
        self.vedette.set_offre(o)

    def set_prix_cartes(self, prix: dict[str, str]) -> None:
        """{id de sortie: « Precommande : 69,99 € »}."""
        self._prix_cartes = dict(prix or {})
        for c in self._cartes:
            c.prix = self._prix_cartes.get(c.s.id, "")
            c.setToolTip(c._bulle())
            c.update()

    def a_illustrer(self) -> list[S.Sortie]:
        return [s for s in self._montrees if (s.steam or s.image)
                and not {"carte", "fond"} <= set(self._visuels.get(s.id) or {})]

    # ------------------------------------------------------------------
    def _filtrer(self, cle: str) -> None:
        self._filtre = cle
        self.puces[cle].setChecked(True)
        self._rendre()

    def _rendre(self) -> None:
        maintenant = dt.datetime.now()
        datees, sans = S.a_venir(self._liste, maintenant)
        vedette = S.vedette(datees, maintenant)
        datees, sans = S.selection([s for s in datees if s is not vedette], sans)
        self._montrees = ([vedette] if vedette else []) + datees + sans
        self.vedette.definir(vedette)
        if vedette is not None:
            v = self._visuels.get(vedette.id) or {}
            self.vedette.meta = v
            if v.get("fond") or v.get("carte"):
                self.vedette.set_visuel(v.get("fond") or v["carte"])

        datees = S.filtrer([s for s in datees if s is not vedette], self._filtre)
        sans = S.filtrer(sans, self._filtre)
        clear_layout(self.sections)
        self._cartes = []
        groupes: dict[str, list[S.Sortie]] = {}
        if datees:
            groupes["Prochaines sorties"] = datees
        if sans:
            groupes["Annonces, date a venir"] = sans
        for titre, liste in groupes.items():
            self.sections.addWidget(self._section(titre, liste))
        if not groupes:
            vide = QLabel("Aucune sortie pour cette plateforme dans la liste pour l'instant.")
            vide.setObjectName("Dim")
            self.sections.addWidget(vide)
        n = len(datees) + len(sans) + (1 if vedette and (
            self._filtre == "toutes" or self._filtre in vedette.plateformes) else 0)
        self.compte.setText(f"{n} sortie" + ("s" if n > 1 else ""))

    def _section(self, titre: str, liste: list[S.Sortie]) -> QWidget:
        bloc = QWidget()
        bloc.setStyleSheet("background: transparent;")
        v = QVBoxLayout(bloc)
        v.setContentsMargins(0, 8, 0, 0)
        v.setSpacing(12)
        tete = QHBoxLayout()
        nom = QLabel(titre)
        nom.setStyleSheet("color: #FFFFFF; font-size: 19px; font-weight: 700; "
                          "background: transparent;")
        tete.addWidget(nom)
        trait = QFrame()
        trait.setFixedHeight(1)
        trait.setStyleSheet(f"background: {PALETTE['border']};")
        tete.addWidget(trait, 1, Qt.AlignmentFlag.AlignVCenter)
        nb = QLabel(str(len(liste)))
        nb.setObjectName("Faint")
        tete.addWidget(nb)
        v.addLayout(tete)
        grille = QWidget()
        grille.setStyleSheet("background: transparent;")
        flux = FlowLayout(grille, 0, 16)
        largeur = self._largeur_carte()
        for s in liste:
            c = CarteSortie(s, largeur)
            c.ouvrir.connect(self._ouvrir)
            c.meta = self._visuels.get(s.id) or {}
            c.prix = self._prix_cartes.get(s.id, "")
            if c.prix:
                c.setToolTip(c._bulle())
            chemin = c.meta.get("carte")
            if chemin:
                c.set_visuel(chemin)
            flux.addWidget(c)
            self._cartes.append(c)
        v.addWidget(grille)
        return bloc

    def _largeur_carte(self) -> int:
        """Largeur des cartes pour remplir les rangees sans vide a droite."""
        m = self.lay.contentsMargins()
        dispo = max(CarteSortie.LARGEUR_MIN, self.width() - m.left() - m.right() - 16)
        ecart = 16
        n = max(1, (dispo + ecart) // (CarteSortie.LARGEUR_MIN + ecart))
        return int((dispo - ecart * (n - 1)) / n)

    def resizeEvent(self, e) -> None:          # noqa: N802
        super().resizeEvent(e)
        largeur = self._largeur_carte()
        if self._cartes and self._cartes[0].L != max(CarteSortie.LARGEUR_MIN, largeur):
            for c in self._cartes:
                c.set_largeur(largeur)

    def _ouvrir(self, s: S.Sortie) -> None:
        if s.lien_boutique:
            self.ouvrir_lien.emit(s.lien_boutique)

    # -- une fois par seconde, seulement page affichee ------------------------
    def showEvent(self, e) -> None:            # noqa: N802
        super().showEvent(e)
        self._tic.start()
        self.actualiser_demande.emit()

    def hideEvent(self, e) -> None:            # noqa: N802
        super().hideEvent(e)
        self._tic.stop()

    def _seconde(self) -> None:
        s = self.vedette.s
        if s is not None and S.decompte(S.restant(s)) is None:
            self._rendre()                     # la vedette vient de sortir
            return
        self.vedette.update()
        for c in self._cartes:
            c.update()

    # -- le ciel ----------------------------------------------------------
    @staticmethod
    def _semer(n: int) -> list[tuple[float, float, float, int]]:
        hasard = random.Random(1987)
        return [(hasard.random(), hasard.random(), hasard.choice((0.6, 0.8, 1.0, 1.4)),
                 hasard.randint(40, 170)) for _ in range(n)]

    def paintEvent(self, _e) -> None:           # noqa: N802
        # le ciel (trois halos sur toute la page, etoiles, constellation) est
        # garde en image : il etait redessine sous chaque carte, chaque seconde
        p = QPainter(self)
        if getattr(self, "_ciel", None) is None:
            self._ciel = Tampon()
        self._ciel.peindre(self, p, (accent(),), self._peindre_ciel)
        p.end()

    def _peindre_ciel(self, p: QPainter) -> None:
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        fond = QLinearGradient(0, 0, 0, h)
        fond.setColorAt(0, QColor("#070A12"))
        fond.setColorAt(1, QColor("#0B0F1C"))
        p.fillRect(self.rect(), fond)
        for cx, cy, rayon, teinte, alpha in (
                (0.88, 0.10, 0.55, "#FF3E8A", 46), (0.08, 0.45, 0.50, accent(), 34),
                (0.60, 0.95, 0.60, "#7B5CFF", 40)):
            g = QRadialGradient(QPointF(w * cx, h * cy), max(w, h) * rayon)
            g.setColorAt(0, couleur(teinte, alpha))
            g.setColorAt(1, couleur(teinte, 0))
            p.fillRect(self.rect(), g)
        p.setPen(Qt.PenStyle.NoPen)
        for x, y, r, a in self._etoiles:
            p.setBrush(QColor(255, 255, 255, a))
            p.drawEllipse(QPointF(x * w, y * h), r, r)
        # la constellation d'Orion, en haut a droite
        cote = min(w, h) * 0.34
        ox, oy = w - cote - 60, 30
        pts = {k: QPointF(ox + vx * cote, oy + vy * cote) for k, (vx, vy) in ORION_ETOILES.items()}
        p.setPen(QPen(couleur(accent(), 46), 1))
        for a, b in ORION_TRAITS:
            p.drawLine(pts[a], pts[b])
        p.setPen(Qt.PenStyle.NoPen)
        for k, pt in pts.items():
            grand = k in ("betelgeuse", "rigel")
            halo = QRadialGradient(pt, 9 if grand else 6)
            teinte = "#FFB27A" if k == "betelgeuse" else "#BFE6FF"
            halo.setColorAt(0, couleur(teinte, 190))
            halo.setColorAt(1, couleur(teinte, 0))
            p.setBrush(QBrush(halo))
            p.drawEllipse(pt, 9 if grand else 6, 9 if grand else 6)
            p.setBrush(QColor(255, 255, 255, 230))
            p.drawEllipse(pt, 1.8 if grand else 1.3, 1.8 if grand else 1.3)
