"""Calculateur de puissance (1.8) : ce que ce PC peut faire tourner.

Rassemble les jeux a evaluer (installes, possedes, envies, Boutique),
recupere progressivement leurs configurations sur Steam (en tache de fond,
au rythme autorise par Steam), puis evalue chacun avec la meilleure source
disponible (voir `estimation`). Les prix viennent de la Boutique (offres
sures uniquement).
"""
from __future__ import annotations

from dataclasses import dataclass

from ..core.logging_setup import get
from ..core.models import normalize_title
from . import estimation, exigences, lecture
from .estimation import (COMMUNAUTE, ESTIME, INCONNU, MESURE, NOMS, SOURCES,
                         Evaluation, Machine, machine_depuis)

log = get("puissance")

from ..partage import LECTURE as MESURES_COMMUNAUTE


@dataclass
class Candidat:
    titre: str
    appid: str = ""
    uid: str = ""
    installe: bool = False
    possede: bool = False
    prix: float | None = None
    boutique: str = ""
    url: str = ""


def candidats(installes, possedes, envies, fiches) -> list[Candidat]:
    """Un candidat par jeu, fusionne par appid Steam puis par titre."""
    par_cle: dict[str, Candidat] = {}
    offres = {}
    for f in fiches or []:
        m = f.meilleure
        info = (m.prix, m.boutique, m.url) if m else (None, "", "")
        if f.steam_appid:
            offres[f"a:{f.steam_appid}"] = info
        offres[f"t:{normalize_title(f.titre)}"] = info

    titres_appid = {normalize_title(f.titre): str(f.steam_appid) for f in fiches or []
                    if f.steam_appid}

    def cle_de(appid, titre):
        return f"a:{appid}" if appid else f"t:{normalize_title(titre)}"

    def ajouter(titre, appid="", uid="", installe=False, possede=False):
        appid = str(appid or "") or titres_appid.get(normalize_title(titre), "")
        cle = cle_de(appid, titre)
        c = par_cle.get(cle)
        if c is None:
            c = Candidat(titre=titre, appid=appid, uid=uid)
            par_cle[cle] = c
        c.installe |= installe
        c.possede |= possede or installe
        c.uid = c.uid or uid
        info = offres.get(f"a:{appid}") or offres.get(f"t:{normalize_title(titre)}")
        if info and c.prix is None:
            c.prix, c.boutique, c.url = info

    for g in installes or []:
        appid = g.source_id if g.source == "steam" else g.extra.get("steam_appid", "")
        ajouter(g.title, appid, g.uid, installe=True)
    for g in possedes or []:
        appid = g.source_id if g.source == "steam" else g.extra.get("steam_appid", "")
        ajouter(g.title, appid, g.uid, possede=True)
    for e in envies or []:
        ajouter(getattr(e, "title", "") or getattr(e, "titre", ""), getattr(e, "appid", ""))
    for f in fiches or []:
        if f.steam_appid:
            ajouter(f.titre, f.steam_appid)
    return list(par_cle.values())


def a_lire(liste: list[Candidat]) -> list[str]:
    """appids dont la configuration n'est pas encore connue, jeux du joueur
    d'abord."""
    vus, sortie, a_relire = set(), [], []
    for c in sorted(liste, key=lambda c: (not c.installe, not c.possede)):
        if c.appid and c.appid not in vus:
            vus.add(c.appid)
            if exigences.en_cache(c.appid) is None:
                sortie.append(c.appid)
            elif exigences.a_relire(c.appid):
                # lue avant la regle 4, notes de l'editeur coupees : relue
                # apres les fiches inconnues (13 octobre 2026)
                a_relire.append(c.appid)
    return sortie + a_relire


def lire_configurations(appids: list[str], limite: int = 45, progress_cb=None) -> int:
    """Recupere les configurations manquantes (reseau, tache de fond)."""
    faits = 0
    for i, appid in enumerate(appids[:limite]):
        try:
            exigences.exigences(appid)
            faits += 1
        except Exception as exc:
            log.info("Configuration %s non lue : %s", appid, exc)
            if "pause" in str(exc).lower():
                break                     # Steam demande de ralentir : on reprendra
        if progress_cb:
            progress_cb("Configurations des jeux", int((i + 1) * 100 / min(len(appids), limite)))
    return faits


_MESURES: list[dict] = []   # dernieres mesures partagees lues


def mesures_en_memoire() -> list[dict]:
    """Les mesures partagees deja lues pendant cette session, sans reseau."""
    return _MESURES


_ECHEC_MESURES = 0.0      # dernier echec de lecture : on ne reessaie pas en boucle


def mesures_communaute() -> list[dict]:
    """Mesures partagees par les joueurs (voir orion/partage.py), relues au
    plus toutes les 6 heures ; apres un echec, pas de nouvel essai avant 30 min."""
    global _ECHEC_MESURES, _MESURES
    import time
    from ..core import reseau
    if time.time() - _ECHEC_MESURES < 1800:
        return []
    try:
        d = reseau.get_json(MESURES_COMMUNAUTE, garder=6 * 3600, timeout=15)
        _MESURES = list(d.get("mesures") or []) if isinstance(d, dict) else []
        return _MESURES
    except Exception:
        _ECHEC_MESURES = time.time()
        return []


def evaluer_tout(liste: list[Candidat], machine: Machine, perf=None,
                 communaute: list | None = None) -> list[tuple[Candidat, Evaluation]]:
    """Evalue chaque candidat. Les jeux mesures servent aussi a calibrer les
    estimations des autres (correction automatique pour CE PC)."""
    calibration = estimation.calibration_du_pc(getattr(perf, "runs", None) or [], machine)
    if calibration != 1.0:
        log.info("Estimations corrigees d'apres vos mesures : x%.2f", calibration)
    sortie = []
    for c in liste:
        runs = perf.by_profile(c.uid) if (perf is not None and c.uid) else {}
        exig = exigences.en_cache(c.appid) if c.appid else None
        ev = estimation.evaluer(c.titre, machine, exig, runs, communaute or [],
                                calibration, appid=c.appid, uid=c.uid)
        ev.installe = c.installe
        ev.calibration = calibration
        if ev.source == ESTIME and ev.niveau and (ev.niveau != "haute" or not ev.fluide):
            # ce qui le rendrait jouable un niveau au-dessus, sans rien acheter
            try:
                trouvees = lecture.pistes(c.titre, exig, machine, calibration, ev)
            except Exception:
                log.exception("Pistes non calculees pour %s", c.titre)
                trouvees = []
            if trouvees:
                ev.piste, ev.niveau_piste = trouvees[0].court, trouvees[0].niveau
        sortie.append((c, ev))
    return sortie


def par_niveau(resultats, niveau: str) -> list[tuple[Candidat, Evaluation]]:
    return sorted([(c, e) for c, e in resultats if e.niveau == niveau],
                  key=lambda r: (not r[0].installe, not r[0].possede,
                                 -(r[1].fps_niveau or (0, 0))[0]))


__all__ = ["Candidat", "Evaluation", "Machine", "machine_depuis", "candidats", "a_lire",
           "lire_configurations", "evaluer_tout", "par_niveau", "mesures_communaute",
           "NOMS", "SOURCES", "MESURE", "COMMUNAUTE", "ESTIME", "INCONNU"]
