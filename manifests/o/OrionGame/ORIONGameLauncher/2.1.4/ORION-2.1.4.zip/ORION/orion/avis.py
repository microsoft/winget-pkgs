"""Votre avis sur ORION (2.1.2).

Les proches qui essaient ORION disent « c'est bien » et rien d'autre : la
question est trop vague. Le lien discret « Donnez votre avis », sous l'encart
de version (bas gauche), ouvre une petite fenetre : trois questions precises
et une quatrieme a choix. Elle ne s'ouvre jamais d'elle-meme. Rien ne part
sans le bouton « Envoyer » : la reponse va au service d'ORION comme un
signalement (meme chemin, memes masques), sans rapport technique.
"""
from __future__ import annotations

from .core.logging_setup import get

log = get("avis")


CHOIX = ("Oui", "Peut-etre", "Non")

QUESTIONS = (
    ("utile", "Qu'est-ce qui vous a ete le plus utile ?"),
    ("gene", "Qu'est-ce qui vous a gene, ou paru bizarre ?"),
    ("manque", "Qu'est-ce qui manque pour que vous l'utilisiez tous les jours ?"),
)
QUESTION_CHOIX = "Utiliseriez-vous ORION a la place de votre launcher habituel ?"


def message(reponses: dict[str, str], choix: str = "") -> tuple[str, str]:
    """(titre, texte) du signalement : les reponses telles quelles, une
    question par paragraphe ; rien d'autre."""
    titre = "Avis" + (f" : {choix}" if choix in CHOIX else "")
    blocs = []
    for cle, question in QUESTIONS:
        texte = (reponses.get(cle) or "").strip()
        if texte:
            blocs.append(f"{question}\n{texte}")
    if choix in CHOIX:
        blocs.append(f"{QUESTION_CHOIX}\n{choix}")
    return titre, "\n\n".join(blocs)


def vide(reponses: dict[str, str], choix: str = "") -> bool:
    return not any((v or "").strip() for v in reponses.values()) and choix not in CHOIX


def envoyer(reponses: dict[str, str], choix: str = "") -> int:
    """Envoie l'avis au service ; leve une exception si l'envoi echoue."""
    from . import signalement
    titre, texte = message(reponses, choix)
    numero = signalement.envoyer(titre, texte)
    log.info("Avis envoye (n° %s)", numero)
    return numero
