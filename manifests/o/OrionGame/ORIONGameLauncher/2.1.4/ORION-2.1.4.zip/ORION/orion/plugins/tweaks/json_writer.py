"""Fichiers de configuration au format JSON (jeux recents)."""
from __future__ import annotations

import json
import os
import re
from pathlib import Path

from ...core.logging_setup import get
from ...core.models import TweakOp
from .base import TweakWriter

log = get("tweaks.json")


#: un segment de chemin : « nom » ou « nom[cle=valeur] » (element d'une liste
#: d'objets nommes, comme les options de REDengine)
_SEGMENT = re.compile(r"([^.\[\]]+)(?:\[([^=\]]+)=([^\]]*)\])?(?:\.|$)")


def _segments(path: str) -> list[tuple[str, str, str]]:
    """« a.b[name=X].value » -> [(a,'',''), (b,'name','X'), (value,'','')]."""
    sortie, i = [], 0
    while i < len(path):
        m = _SEGMENT.match(path, i)
        if not m or m.end() == i:
            return []
        sortie.append((m.group(1), m.group(2) or "", m.group(3) or ""))
        i = m.end()
    return sortie


def _descendre(data, segments, creer: bool = False):
    """L'objet qui porte la derniere cle, ou None. Un element de liste n'est
    jamais cree : si le jeu n'a pas cette option, ORION ne l'invente pas."""
    cur = data
    for nom, cle, valeur in segments:
        if not isinstance(cur, dict):
            return None
        if cle:
            liste = cur.get(nom)
            if not isinstance(liste, list):
                return None
            cur = next((e for e in liste if isinstance(e, dict)
                        and str(e.get(cle)) == valeur), None)
        elif creer:
            cur = cur.setdefault(nom, {})
        else:
            cur = cur.get(nom)
        if cur is None:
            return None
    return cur if isinstance(cur, dict) else None


def _dig(data: dict, path: str, value=None, write: bool = False):
    """Acces a une valeur imbriquee via "a.b.c" ou "a[name=X].value"."""
    seg = _segments(path)
    if not seg or seg[-1][1]:
        return None
    avec_liste = any(c for _n, c, _v in seg)
    parent = _descendre(data, seg[:-1], creer=write and not avec_liste)
    if parent is None:
        return None
    if write:
        parent[seg[-1][0]] = value
        return value
    return parent.get(seg[-1][0])


def _ecrire(data: dict, path: str, val) -> str:
    """Ecrit une valeur. Retourne "" si c'est fait, sinon la raison du refus.

    Une option de jeu decrit souvent elle-meme ce qu'elle accepte : une liste
    « values » (avec un « index » qui doit suivre la valeur), ou des bornes
    « min_value » / « max_value ». ORION s'y tient : il n'ecrit jamais une
    valeur hors de la liste que le jeu donne, garde la valeur dans ses bornes
    et dans son type. Pour une liste que le jeu dresse lui-meme d'apres le
    materiel (« is_dynamic »), il ecrit la valeur et laisse l'index au jeu."""
    seg = _segments(path)
    if not seg or seg[-1][1]:
        return "chemin illisible"
    avec_liste = any(c for _n, c, _v in seg)
    parent = _descendre(data, seg[:-1], creer=not avec_liste)
    if parent is None:
        return "option absente du fichier"
    cle = seg[-1][0]
    if not avec_liste:
        parent[cle] = val
        return ""
    if cle not in parent:
        return "option absente du fichier"
    if cle == "value":
        choix = parent.get("values")
        if isinstance(choix, list):
            trouve = next((c for c in choix if str(c).lower() == str(val).lower()), None)
            if trouve is None:
                return "valeur non proposee par le jeu"
            parent["value"] = trouve
            if "index" in parent:
                parent["index"] = choix.index(trouve)
            return ""
        ancien = parent.get("value")
        if parent.get("is_dynamic") and "index" in parent:
            # liste que le jeu dresse lui-meme (definitions de l'ecran, modes
            # de DLSS...) : elle n'est pas dans le fichier, l'index ne peut
            # donc pas etre recalcule ici. C'est la valeur qui fait foi : vu
            # dans Cyberpunk 2077, ou la liste des definitions avait grandi
            # entre deux parties, le jeu a garde « 3620x2036 » et a lui-meme
            # corrige l'index (18 devenu 19). ORION ecrit la valeur, du meme
            # type que l'ancienne, et laisse l'index au jeu.
            if type(val) is not type(ancien):
                return "valeur d'un autre type"
            parent["value"] = val
            return ""
        if isinstance(ancien, bool):
            if not isinstance(val, bool):
                return "valeur d'un autre type"
        elif isinstance(ancien, (int, float)):
            if isinstance(val, bool) or not isinstance(val, (int, float)):
                return "valeur d'un autre type"
            bas, haut = parent.get("min_value"), parent.get("max_value")
            if isinstance(bas, (int, float)):
                val = max(val, bas)
            if isinstance(haut, (int, float)):
                val = min(val, haut)
            val = float(val) if isinstance(ancien, float) else int(round(val))
        elif isinstance(ancien, str) and not isinstance(val, str):
            return "valeur d'un autre type"
    parent[cle] = val
    return ""


class JsonWriter(TweakWriter):
    id = "json"
    label = "Fichier JSON"

    def read(self, op: TweakOp) -> str | None:
        try:
            data = json.loads(Path(op.target).read_text("utf-8-sig", errors="ignore"))
        except Exception:
            return None
        val = _dig(data, op.key)
        return None if val is None else str(val)

    def write(self, ops: list[TweakOp]) -> tuple[int, str]:
        by_file: dict[str, list[TweakOp]] = {}
        for op in ops:
            by_file.setdefault(op.target, []).append(op)

        written = 0
        non_ecrits: list[str] = []
        for target, items in by_file.items():
            path = Path(target)
            if path.exists() and not os.access(path, os.W_OK):
                return written, (f"{path.name} est en lecture seule : ORION ne le "
                                 "force pas.")
            try:
                data = json.loads(path.read_text("utf-8-sig")) if path.exists() else {}
            except Exception:
                # l'ancienne version repartait d'un document vide : un fichier
                # que Python ne sait pas lire (commentaires, encodage) etait
                # remplace par les seules cles d'ORION, et le jeu perdait
                # toutes ses autres options
                log.warning("JSON illisible, non modifie : %s", path)
                return written, (f"{path.name} n'a pas pu etre lu : ORION ne le "
                                 "modifie pas.")
            if not isinstance(data, dict):
                return written, f"{path.name} n'a pas la forme attendue : non modifie."
            refuses: list[str] = []
            for op in items:
                raw = str(op.value)
                if raw.lower() in ("true", "false"):
                    val: object = raw.lower() == "true"
                elif raw.lstrip("-").replace(".", "", 1).isdigit():
                    val = float(raw) if "." in raw else int(raw)
                else:
                    val = raw
                refus = _ecrire(data, op.key, val)
                if refus:
                    refuses.append(f"{op.label or op.key} ({refus})")
            try:
                path.parent.mkdir(parents=True, exist_ok=True)
                provisoire = path.with_name(path.name + ".orion.tmp")
                provisoire.write_text(json.dumps(data, indent=2, ensure_ascii=False),
                                      "utf-8")
                os.replace(provisoire, path)
                written += len(items) - len(refuses)
                if refuses:
                    non_ecrits.extend(refuses)
                    log.warning("%s : %d reglage(s) non ecrit(s) : %s", path.name,
                                len(refuses), "; ".join(refuses[:6]))
            except Exception as exc:
                return written, f"Ecriture impossible dans {path.name} : {exc}"
        if non_ecrits:
            return written, (f"{len(non_ecrits)} reglage(s) non ecrit(s) : "
                             + "; ".join(non_ecrits[:4]))
        return written, "Reglages ecrits"
