"""Unreal : ecrire la ou le jeu lit vraiment (2.0.2).

Retour de l'auteur (9 octobre, Ready or Not et Aniimo) : ORION ecrivait
`[/Script/Engine.GameUserSettings]` et `[ScalabilityGroups]`, le jeu
restait en Epic. Cause : Unreal enregistre les reglages de l'utilisateur
sous le nom de la CLASSE reelle du jeu. Un jeu qui derive GameUserSettings
(Ready or Not : `[/Script/ReadyOrNot.ReadyOrNotGameUserSettings]`) y garde
definition, limite d'images, plein ecran... et souvent ses propres niveaux
(`ShadowQuality=3`, `TextureQuality=3`...) qu'il reapplique au demarrage,
par-dessus `sg.*`. La section Engine n'est alors qu'une coquille (une ou
deux cles), et `[ScalabilityGroups]` est ecrase a la premiere lecture.

Regle generique, valable pour n'importe quel jeu Unreal : chaque reglage
prevu pour `/Script/Engine.GameUserSettings` est AUSSI ecrit dans toute
section `[/Script/<Module>.<Classe>]` dont la classe finit par
`GameUserSettings` ; chaque `sg.XQuality` de `[ScalabilityGroups]` est
recopie dans ces memes sections sous la cle `XQuality` quand elle y existe
deja (on ne cree pas une cle que le jeu ne connait pas). Rien n'est
invente : la section Engine et les groupes de scalabilite restent ecrits,
pour les jeux qui les lisent.
"""
from __future__ import annotations

import re
from dataclasses import replace

from ..core.models import TweakOp

ENGINE = "/Script/Engine.GameUserSettings"
SCALABILITE = "ScalabilityGroups"
_SECTION = re.compile(r"^\s*\[(.+?)\]\s*$")
_CLE = re.compile(r"^\s*([^;#\s=][^=]*?)\s*=")
_CLASSE = re.compile(r"^/Script/[^.\s]+\.[^.\s]*GameUserSettings$", re.I)


def sections_du_jeu(texte: str) -> dict[str, set[str]]:
    """{section -> cles presentes} des sections GameUserSettings propres au
    jeu (classe derivee), hors section Engine."""
    out: dict[str, set[str]] = {}
    courante = None
    for ligne in (texte or "").splitlines():
        m = _SECTION.match(ligne)
        if m:
            nom = m.group(1).strip()
            courante = nom if _CLASSE.match(nom) and nom.lower() != ENGINE.lower() else None
            if courante is not None:
                out.setdefault(courante, set())
            continue
        if courante is not None:
            k = _CLE.match(ligne)
            if k:
                out[courante].add(k.group(1).strip())
    return out


def ops_miroir(ops: list[TweakOp], texte: str) -> list[TweakOp]:
    """Les operations a ajouter pour qu'un jeu Unreal a classe derivee lise
    les reglages : copie des cles Engine dans la section du jeu, et des
    `sg.XQuality` vers `XQuality` quand le jeu tient ses propres niveaux."""
    sections = sections_du_jeu(texte)
    if not sections:
        return []
    deja = {(o.target, o.section.lower(), o.key) for o in ops}
    out: list[TweakOp] = []
    for o in ops:
        for section, cles in sections.items():
            if o.section.lower() == ENGINE.lower():
                cle = o.key
            elif o.section.lower() == SCALABILITE.lower() and o.key.lower().startswith("sg."):
                cle = o.key[3:]
                if cle not in cles:
                    continue
            else:
                continue
            if (o.target, section.lower(), cle) in deja:
                continue
            deja.add((o.target, section.lower(), cle))
            out.append(replace(o, section=section, key=cle, current=None,
                               label=f"{o.label} (section du jeu)" if o.label else cle))
    return out
