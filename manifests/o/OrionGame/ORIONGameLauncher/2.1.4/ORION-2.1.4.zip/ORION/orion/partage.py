"""Mesures partagees : ce que les joueurs obtiennent vraiment, pour tous.

Apres une partie mesuree, et seulement si le joueur a dit oui, ORION envoie
UNE ligne anonyme au service communautaire : le jeu (identifiant Steam), le
modele de carte graphique et de processeur, la definition, le niveau de
reglages et les images par seconde. Aucun nom, aucun compte, aucun chemin de
fichier, aucune adresse. Le service regroupe ces lignes et republie un
fichier commun, que tous les ORION lisent (`puissance.mesures_communaute`) :
« d'apres 12 joueurs equipes comme vous ».

`poste` est un identifiant tire au hasard a la premiere utilisation : il ne
dit rien de la personne, il evite seulement qu'un meme PC compte pour dix.
"""
from __future__ import annotations

import uuid
from typing import Any

from .core.config import CONFIG
from .core.logging_setup import get
from .version import APP_VERSION

log = get("partage")

SERVICE = "https://api.orion-launcher.com"
ENVOI = SERVICE + "/mesure"
LECTURE = SERVICE + "/mesures.json"
NIVEAUX = ("basse", "moyenne", "haute", "ultra")
#: gain d'images/s de la super-resolution (memes valeurs que recommande.MODES)
GAINS = {"off": 1.0, "quality": 1.35, "balanced": 1.5, "performance": 1.7}


#: version du texte de la question. 1 : mesures seules (1.9.5). 2 : mesures
#: et compteur anonyme (`compteur`). 3 : le service situe l'envoi (pays et
#: region, 1.9.7). 4 : bilan de fluidite anonyme a la fermeture (2.0.1).
#: Quand le texte s'elargit, la question est reposee une fois : un oui donne
#: a l'ancien texte ne vaut pas pour le nouveau.
QUESTION = 4


def actif() -> bool:
    return bool(CONFIG.get("partage.actif", False))


def a_demander() -> bool:
    """La question (dans son texte actuel) n'a pas encore ete posee."""
    if not CONFIG.get("partage.demande", False):
        return True
    return int(CONFIG.get("partage.question", 1) or 1) < QUESTION


def repondre(oui: bool) -> None:
    CONFIG.set("partage.demande", True)
    CONFIG.set("partage.question", QUESTION)
    CONFIG.set("partage.actif", bool(oui))


def poste() -> str:
    p = str(CONFIG.get("partage.poste", "") or "")
    if len(p) != 32:
        p = uuid.uuid4().hex
        CONFIG.set("partage.poste", p)
    return p


def cle_jeu(game) -> str:
    """Identifiant commun d'un jeu entre joueurs : son numero Steam, sinon
    « t: » suivi de son titre simplifie (jeux Battle.net, Epic, hors boutique)."""
    if game is None:
        return ""
    from .core.liens import appid_steam
    from .core.models import normalize_title
    appid = str(appid_steam(game) or "")
    if appid.isdigit():
        return appid
    titre = "".join(c for c in normalize_title(game.title) if c.isascii() and c.isalnum())
    return f"t:{titre[:60]}" if len(titre) >= 2 else ""


def _cle_valide(cle: str) -> bool:
    cle = str(cle or "")
    return cle.isdigit() or (cle.startswith("t:") and 2 <= len(cle) - 2 <= 60
                             and cle[2:].isascii() and cle[2:].isalnum())


def ligne(appid: str, stats: dict, machine, pixels: int) -> dict[str, Any] | None:
    """La ligne anonyme a envoyer, ou None si la mesure n'est pas partageable
    (jeu sans identifiant, carte inconnue, niveau inconnu, mesure trop courte).
    `appid` : `cle_jeu(game)`."""
    from .puissance.estimation import PROFIL_PRESET
    try:
        moy = float(stats.get("fps_avg") or 0)
        bas = float(stats.get("fps_low_1") or 0)
        duree = float(stats.get("duration") or stats.get("seconds") or 0)
    except (TypeError, ValueError):
        return None
    niveau = stats.get("preset") or PROFIL_PRESET.get(str(stats.get("profile") or ""))
    if not _cle_valide(appid) or niveau not in NIVEAUX or not 5 <= moy <= 1000:
        return None
    if machine is None or not machine.gpu or not pixels:
        return None
    if duree and duree < 120:               # moins de deux minutes : pas fiable
        return None
    mode = str(stats.get("upscaler_mode") or "off")
    if mode not in GAINS:
        mode = "off"
    gain = GAINS[mode]
    return {
        "v": 1, "app": APP_VERSION, "poste": poste(), "appid": str(appid),
        "gpu": round(float(machine.gpu), 1), "gpu_nom": (machine.gpu_nom or "")[:60],
        "cpu": round(float(machine.cpu), 1) if machine.cpu else None,
        "cpu_nom": (getattr(machine, "cpu_nom", "") or "")[:60],
        "pixels": int(pixels), "preset": niveau, "mode": mode,
        # ramene a la definition native, comme le calcul local
        "fps": round(moy / gain, 1), "bas": round(bas / gain, 1) if bas else None,
    }


def envoyer(donnees: dict) -> bool:
    """Envoie une ligne. Ne leve jamais : le partage ne doit rien casser."""
    if not actif() or not donnees:
        return False
    from .core import reseau
    try:
        r = reseau.post(ENVOI, json=donnees, timeout=15)
        ok = 200 <= r.status_code < 300
        log.info("Mesure partagee (%s, %s) : %s", donnees.get("appid"),
                 donnees.get("preset"), "recue" if ok else f"refusee ({r.status_code})")
        return ok
    except Exception as exc:
        log.info("Mesure non partagee : %s", exc)
        return False


RECETTE = SERVICE + "/recette"


def envoyer_recette(recette: dict) -> bool:
    """Propose une recette apprise par l'exemple aux autres joueurs, sous le
    meme oui que les mesures (rien de personnel : des noms et des valeurs de
    reglages, des chemins ramenes a %LOCALAPPDATA%...). Le service la garde
    pour verification avant de la publier. Ne leve jamais."""
    if not actif() or not isinstance(recette, dict) or not recette.get("targets"):
        return False
    from .core import reseau
    corps = {"poste": poste(), "app": APP_VERSION,
             "recette": {k: v for k, v in recette.items() if k != "community"}}
    try:
        r = reseau.post(RECETTE, json=corps, timeout=15)
        ok = 200 <= r.status_code < 300
        log.info("Recette proposee (%s) : %s", recette.get("id"), "recue" if ok else f"refusee ({r.status_code})")
        return ok
    except Exception as exc:
        log.info("Recette non proposee : %s", exc)
        return False
