"""Valeur de la bibliotheque : prix du catalogue possede, a titre indicatif.

Le total additionne le prix **actuel hors promotion** de chaque jeu possede
(installe ou non), tel que les boutiques l'affichent aujourd'hui. Ce n'est
ni ce que le joueur a paye, ni une valeur de revente : une simple idee de ce
que coute le catalogue. Les jeux gratuits comptent pour 0.

Ou ORION trouve les prix, sans cle ni compte, dans cet ordre :

1. le releve de prix deja fait pour la fiche du jeu (cache « prix ») ;
2. le magasin Steam pour tout jeu dont l'identifiant Steam est connu :
   un appel groupe `appdetails` (filtre `price_overview`, 40 jeux par
   appel), garde 7 jours par jeu ;
3. les fiches de la Boutique (vitrine, recherches), reconnues par
   identifiant Steam ou par titre.

Un jeu sans prix trouve n'est pas compte : le texte dit combien de jeux ont
ete estimes sur combien. Tout le travail reseau se fait hors de l'interface
(`estimer` est appele dans une tache) ; `preparer` lit, dans le fil de
l'interface, ce qui est deja en memoire.
"""
from __future__ import annotations

from orion.core import region

import time
from dataclasses import asdict, dataclass, field

from .core.logging_setup import get

log = get("valeur")

DETAILS = "https://store.steampowered.com/api/appdetails"
LOT = 40                          # appids par appel groupe
GARDER = 7 * 24 * 3600            # prix Steam gardes une semaine


@dataclass
class Valeur:
    total: float = 0.0            # prix actuels hors promotion
    actuel: float = 0.0           # prix du moment (promotions comprises)
    estimes: int = 0              # jeux dont le prix est connu (gratuits compris)
    gratuits: int = 0
    jeux: int = 0                 # jeux possedes pris en compte
    devise: str = "EUR"
    le: float = 0.0
    partiel: bool = False         # Steam n'a pas repondu pour tous les jeux
    sources: dict = field(default_factory=dict)
    #: jeux comptes, du plus cher au moins cher (2.1.1, fenetre « Valeur estimee
    #: de ma bibliotheque ») : {titre, appid, normal, actuel, origine}
    liste: list = field(default_factory=list)

    @property
    def connue(self) -> bool:
        return self.jeux > 0 and self.estimes > 0

    @staticmethod
    def montant(valeur: float) -> str:
        """1234.5 -> « 1 235 » (espaces fines insecables evitees : simple espace)."""
        return f"{round(valeur):,}".replace(",", " ")

    def texte(self) -> str:
        if not self.connue:
            return ""
        return (f"Valeur de la bibliotheque : {self.montant(self.total)} {self.devise}"
                f"  ·  prix actuels hors promotion, {self.estimes} jeux sur {self.jeux} "
                "estimes")

    def detail(self) -> str:
        """Bulle d'aide : ce que le chiffre veut dire, et ses limites."""
        lignes = [
            "A titre indicatif : somme des prix affiches aujourd'hui par les "
            "boutiques, hors promotion. Ce n'est ni ce que vous avez paye, ni une "
            "valeur de revente.",
            f"{self.estimes} jeux estimes sur {self.jeux}"
            + (f", dont {self.gratuits} gratuits (comptes 0 {self.devise})"
               if self.gratuits else "") + ".",
        ]
        if self.actuel and abs(self.actuel - self.total) >= 1:
            lignes.append(f"Aux prix du moment (promotions comprises) : "
                          f"{self.montant(self.actuel)} {self.devise}.")
        manquants = self.jeux - self.estimes
        if manquants:
            lignes.append(f"{manquants} jeu(x) sans prix connu (hors Steam, retires de "
                          "la vente, ajoutes a la main...) ne sont pas comptes.")
        if self.partiel:
            lignes.append("Steam n'a pas repondu pour tous les jeux : l'estimation "
                          "sera completee plus tard.")
        if self.le:
            lignes.append("Calcule le " + time.strftime("%d/%m/%Y a %H:%M",
                                                        time.localtime(self.le)) + ".")
        return "\n".join(lignes)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Valeur":
        return cls(**{k: v for k, v in (d or {}).items() if k in cls.__dataclass_fields__})


# --------------------------------------------------------------------------
def _cle(game) -> str:
    from .core.liens import appid_steam
    from .core.recherche import sans_bruit
    appid = appid_steam(game)
    return f"steam:{appid}" if appid else "titre:" + (sans_bruit(game.title) or game.uid)


def _prix_du_releve(d: dict) -> tuple[float, float] | None:
    """(prix hors promotion, prix du moment) d'un releve de fiche, ou None."""
    if not isinstance(d, dict):
        return None
    if d.get("free"):
        return 0.0, 0.0
    courant = d.get("current") or {}
    prix = float(courant.get("price") or 0)
    cut = int(courant.get("cut") or 0)
    base = float(d.get("base_price") or 0)
    if not base and prix:
        base = round(prix / (1 - cut / 100), 2) if 0 < cut < 100 else prix
    if not base:
        return None
    return base, (prix or base)


def preparer(jeux, releves: dict | None = None, fiches=None) -> list[dict]:
    """Instantane des jeux a estimer, lu dans le fil de l'interface.

    `jeux` : jeux installes et possedes non installes (doublons fusionnes) ;
    `releves` : cache des fiches {uid: MarketInfo en dict} ;
    `fiches` : fiches de la Boutique. Rend une liste de dicts simples,
    utilisable sans risque depuis une tache."""
    from .core.liens import appid_steam
    from .core.recherche import sans_bruit
    releves = releves or {}
    index_appid: dict[str, tuple[float, float]] = {}
    index_titre: dict[str, tuple[float, float]] = {}
    for f in fiches or []:
        try:
            m = f.meilleure
            if m is None:
                continue
            normal = f.prix_normal or m.prix
            prix = (0.0, 0.0) if f.gratuit else (float(normal), float(m.prix))
            if not f.gratuit and not normal:
                continue
            if f.steam_appid:
                index_appid.setdefault(str(f.steam_appid), prix)
            t = sans_bruit(f.titre)
            if t:
                index_titre.setdefault(t, prix)
        except Exception:
            continue

    vus: set[str] = set()
    sortie: list[dict] = []
    for g in jeux or []:
        if g is None or getattr(g, "hidden", False):
            continue
        cle = _cle(g)
        if cle in vus:
            continue
        vus.add(cle)
        appid = appid_steam(g)
        prix = _prix_du_releve(releves.get(g.uid))
        origine = "releve" if prix else ""
        if prix is None and appid and appid in index_appid:
            prix, origine = index_appid[appid], "boutique"
        if prix is None and not appid:
            t = sans_bruit(g.title)
            if t in index_titre:
                prix, origine = index_titre[t], "boutique"
        from .steam_famille import HORS_COMPTE, PRETE
        extra = getattr(g, "extra", None) or {}
        sortie.append({"uid": g.uid, "titre": g.title, "appid": appid,
                       "prix": prix, "origine": origine,
                       # (2.1.2) famille Steam : certain, ou hors du compte (dit s'il est payant)
                       "famille": "oui" if extra.get(PRETE) else ("hors_compte" if extra.get(HORS_COMPTE) else "")})
    return sortie


def _prix_steam(appids: list[str], forcer: bool = False) -> tuple[dict, bool]:
    """{appid: (hors promo, actuel) | None} ; None = pas de prix (gratuit ou
    retire de la vente). Le booleen dit si Steam a manque des reponses."""
    from .core import reseau, steam_limite
    from .core.base import Table
    from .core.config import CONFIG
    table = Table("valeur_steam", maximum=8000)
    maintenant = time.time()
    out: dict = {}
    a_demander = []
    for a in appids:
        memo = table.get(a)
        if memo and not forcer and maintenant - float(memo.get("le", 0)) < GARDER:
            out[a] = tuple(memo["prix"]) if memo.get("prix") is not None else None
        else:
            a_demander.append(a)
    partiel = False
    pays = str(CONFIG.get("market.country") or "FR").lower()
    nouveaux = {}
    for i in range(0, len(a_demander), LOT):
        lot = a_demander[i:i + LOT]
        if steam_limite.en_pause():
            partiel = True
            break
        try:
            r = reseau.get(DETAILS, params={"appids": ",".join(lot), "cc": pays,
                                            "filters": "price_overview"},
                           headers=steam_limite.NAVIGATEUR, timeout=20)
            if r.status_code in (403, 429):
                steam_limite.signaler_refus()
                partiel = True
                break
            blocs = steam_limite.fiches_groupees(r.json(), lot)
        except Exception as exc:
            log.info("Prix Steam (valeur de la bibliotheque) : %s", exc)
            partiel = True
            continue
        for a in lot:
            bloc = blocs.get(a)
            if not isinstance(bloc, dict):
                continue                       # pas de reponse : redemande plus tard
            data = bloc.get("data") if bloc.get("success") else None
            po = data.get("price_overview") if isinstance(data, dict) else None
            if po and po.get("initial") is not None:
                if str(po.get("currency") or region.devise()) != region.devise():
                    prix = None                # autre devise : non additionnable
                else:
                    initial = (po.get("initial") or po.get("final") or 0) / 100
                    prix = (round(initial, 2), round((po.get("final") or 0) / 100, 2))
            elif bloc.get("success"):
                prix = (0.0, 0.0)              # en vente sans prix : gratuit
            else:
                prix = None                    # retire de la vente / inconnu
            out[a] = prix
            nouveaux[a] = {"le": maintenant, "prix": list(prix) if prix else None}
    if nouveaux:
        table.update(nouveaux)
    return out, partiel


def estimer(instantane: list[dict], reseau_autorise: bool = True,
            forcer: bool = False) -> Valeur:
    """Calcule la valeur a partir de l'instantane de `preparer` (en tache)."""
    v = Valeur(jeux=len(instantane), le=time.time(), devise=region.devise())
    manquants = [j["appid"] for j in instantane if j["prix"] is None and j["appid"]]
    steam: dict = {}
    if manquants and reseau_autorise:
        steam, v.partiel = _prix_steam(sorted(set(manquants)), forcer)
    for j in instantane:
        prix, origine = j["prix"], j["origine"]
        if prix is None and j["appid"] in steam and steam[j["appid"]] is not None:
            prix, origine = steam[j["appid"]], "steam"
        if prix is None:
            continue
        normal, actuel = float(prix[0]), float(prix[1])
        v.estimes += 1
        v.total += normal
        v.actuel += actuel
        if normal <= 0:
            v.gratuits += 1
        v.sources[origine] = v.sources.get(origine, 0) + 1
        entree = {"titre": j["titre"], "appid": j["appid"], "normal": round(normal, 2),
                  "actuel": round(actuel, 2), "origine": origine}
        if j.get("famille") == "oui" or (j.get("famille") == "hors_compte" and normal > 0):
            entree["famille"] = True
        v.liste.append(entree)
    v.liste.sort(key=lambda x: (-x["normal"], str(x["titre"]).lower()))
    v.total = round(v.total, 2)
    v.actuel = round(v.actuel, 2)
    return v


# -- derniere valeur calculee (affichee aussitot au demarrage) ------------------
def derniere() -> Valeur | None:
    from .core.base import Document
    try:
        d = Document("valeur_bibliotheque").lire(None)
        return Valeur.from_dict(d) if d else None
    except Exception:
        return None


def retenir(v: Valeur) -> None:
    from .core.base import Document
    try:
        Document("valeur_bibliotheque").ecrire(v.to_dict())
    except Exception:
        log.debug("Valeur de la bibliotheque non enregistree", exc_info=True)
