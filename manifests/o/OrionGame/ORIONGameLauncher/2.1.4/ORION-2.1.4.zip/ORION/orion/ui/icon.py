"""Icone de l'application.

Le fichier livre (`assets/orion.ico`) est utilise quand il est present :
c'est lui que Windows affiche dans la barre des taches, les raccourcis et
« Applications installees ». A defaut, l'icone est dessinee a la volee, ce
qui garantit que l'application a toujours une identite visuelle.
"""
from __future__ import annotations

from PySide6.QtCore import QRectF, Qt
from PySide6.QtGui import QColor, QPainter, QPen, QPixmap

from ..core.paths import ASSETS_DIR
from .theme import PALETTE, accent

ICON_FILE = ASSETS_DIR / "orion.ico"


def app_icon(size: int = 256) -> QPixmap:
    if ICON_FILE.exists():
        pix = QPixmap(str(ICON_FILE))
        if not pix.isNull():
            return pix
    return _draw_icon(size)


def _draw_icon(size: int = 256) -> QPixmap:
    pix = QPixmap(size, size)
    pix.fill(Qt.GlobalColor.transparent)
    p = QPainter(pix)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)

    p.setBrush(QColor(PALETTE["bg_alt"]))
    p.setPen(Qt.PenStyle.NoPen)
    p.drawRoundedRect(QRectF(0, 0, size, size), size * 0.22, size * 0.22)

    pen = QPen(QColor(accent()))
    pen.setWidthF(size * 0.055)
    p.setPen(pen)
    p.setBrush(Qt.BrushStyle.NoBrush)
    m = size * 0.24
    p.drawEllipse(QRectF(m, m, size - 2 * m, size - 2 * m))

    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QColor(accent()))
    r = size * 0.075
    p.drawEllipse(QRectF(size * 0.5 - r, size * 0.13 - r, r * 2, r * 2))
    p.end()
    return pix
