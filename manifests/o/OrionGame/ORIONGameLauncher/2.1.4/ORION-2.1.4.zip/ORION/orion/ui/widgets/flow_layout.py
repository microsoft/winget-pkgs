"""Disposition en flux : les tuiles se reorganisent selon la largeur.

Les tuiles masquees ne prennent aucune place : filtrer la bibliotheque
revient a masquer ou montrer des tuiles existantes, sans en reconstruire
aucune. Les calculs de hauteur sont gardes jusqu'a la prochaine
invalidation (Qt les redemande des centaines de fois pendant un
rafraichissement ; sans memoire, chaque appel reparcourait toutes les
tuiles).
"""
from __future__ import annotations

from PySide6.QtCore import QMargins, QPoint, QRect, QSize, Qt
from PySide6.QtWidgets import QLayout, QWidgetItem


class FlowLayout(QLayout):
    def __init__(self, parent=None, margin: int = 0, spacing: int = 16) -> None:
        super().__init__(parent)
        self._items: list[QWidgetItem] = []
        self._hauteurs: dict[int, int] = {}
        self._minimum: QSize | None = None
        self.setContentsMargins(QMargins(margin, margin, margin, margin))
        self.setSpacing(spacing)

    def invalidate(self) -> None:
        self._hauteurs.clear()
        self._minimum = None
        super().invalidate()

    def ordonner(self, widgets: list) -> None:
        """Remet les tuiles dans l'ordre donne ; les autres suivent, dans
        leur ordre actuel (elles sont normalement masquees)."""
        par_widget = {id(it.widget()): it for it in self._items if it.widget() is not None}
        devant, pris = [], set()
        for w in widgets:
            it = par_widget.get(id(w))
            if it is not None and id(w) not in pris:
                devant.append(it)
                pris.add(id(w))
        reste = [it for it in self._items
                 if it.widget() is None or id(it.widget()) not in pris]
        nouveau = devant + reste
        if [id(i) for i in nouveau] != [id(i) for i in self._items]:
            self._items = nouveau
        self.invalidate()

    def addItem(self, item) -> None:            # noqa: N802
        self._items.append(item)
        self.invalidate()

    def count(self) -> int:
        return len(self._items)

    def itemAt(self, index):                    # noqa: N802
        return self._items[index] if 0 <= index < len(self._items) else None

    def takeAt(self, index):                    # noqa: N802
        if not 0 <= index < len(self._items):
            return None
        self._hauteurs.clear()
        self._minimum = None
        return self._items.pop(index)

    def expandingDirections(self):              # noqa: N802
        return Qt.Orientation(0)

    def hasHeightForWidth(self) -> bool:        # noqa: N802
        return True

    def heightForWidth(self, width: int) -> int:    # noqa: N802
        if width not in self._hauteurs:
            self._hauteurs[width] = self._layout(QRect(0, 0, width, 0), test_only=True)
        return self._hauteurs[width]

    def setGeometry(self, rect: QRect) -> None:     # noqa: N802
        super().setGeometry(rect)
        self._layout(rect, test_only=False)

    def sizeHint(self) -> QSize:                # noqa: N802
        return self.minimumSize()

    def minimumSize(self) -> QSize:             # noqa: N802
        if self._minimum is None:
            size = QSize()
            for item in self._items:
                if not item.isEmpty():
                    size = size.expandedTo(item.minimumSize())
            m = self.contentsMargins()
            self._minimum = size + QSize(m.left() + m.right(), m.top() + m.bottom())
        return QSize(self._minimum)

    def clear(self) -> None:
        from .layouts import clear_layout
        clear_layout(self)

    # ------------------------------------------------------------------
    def _layout(self, rect: QRect, test_only: bool) -> int:
        m = self.contentsMargins()
        effective = rect.adjusted(m.left(), m.top(), -m.right(), -m.bottom())
        x, y, line_height = effective.x(), effective.y(), 0
        space = self.spacing()

        for item in self._items:
            if item.isEmpty():               # tuile masquee : aucune place
                continue
            hint = item.sizeHint()
            next_x = x + hint.width() + space
            if next_x - space > effective.right() and line_height > 0:
                x = effective.x()
                y = y + line_height + space
                next_x = x + hint.width() + space
                line_height = 0
            if not test_only:
                item.setGeometry(QRect(QPoint(x, y), hint))
            x = next_x
            line_height = max(line_height, hint.height())
        return y + line_height - rect.y() + m.bottom()
