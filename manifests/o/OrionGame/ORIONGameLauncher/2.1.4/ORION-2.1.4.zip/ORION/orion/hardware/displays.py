"""Ecrans : enumeration des modes et application d'un mode.

Utilise directement l'API Windows (user32) via ctypes : pas de dependance
supplementaire, et l'application d'un mode est immediate et reversible.
"""
from __future__ import annotations

import ctypes
import re
from ctypes import wintypes
from typing import Iterator

from ..core.logging_setup import get
from ..core.models import Display, DisplayMode
from ..core.paths import is_windows
from ..core.winutil import run_powershell

log = get("hardware.ecrans")

# --- constantes Windows ----------------------------------------------------
ENUM_CURRENT_SETTINGS = -1
CCHDEVICENAME = 32
CCHFORMNAME = 32

DM_BITSPERPEL = 0x00040000
DM_PELSWIDTH = 0x00080000
DM_PELSHEIGHT = 0x00100000
DM_DISPLAYFREQUENCY = 0x00400000

CDS_UPDATEREGISTRY = 0x00000001
CDS_TEST = 0x00000002

DISP_CHANGE_SUCCESSFUL = 0
DISPLAY_DEVICE_ATTACHED_TO_DESKTOP = 0x00000001
DISPLAY_DEVICE_PRIMARY_DEVICE = 0x00000004

CHANGE_ERRORS = {
    0: "Mode applique",
    -1: "Mode refuse par le pilote",
    -2: "Mode non pris en charge par cet ecran",
    -3: "Redemarrage necessaire",
    -4: "Echec du changement de mode",
    -5: "Parametre invalide",
}


class DISPLAY_DEVICEW(ctypes.Structure):
    _fields_ = [
        ("cb", wintypes.DWORD),
        ("DeviceName", wintypes.WCHAR * CCHDEVICENAME),
        ("DeviceString", wintypes.WCHAR * 128),
        ("StateFlags", wintypes.DWORD),
        ("DeviceID", wintypes.WCHAR * 128),
        ("DeviceKey", wintypes.WCHAR * 128),
    ]


class _POINTL(ctypes.Structure):
    _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]


class _DEVMODE_UNION1_STRUCT1(ctypes.Structure):
    _fields_ = [
        ("dmOrientation", ctypes.c_short), ("dmPaperSize", ctypes.c_short),
        ("dmPaperLength", ctypes.c_short), ("dmPaperWidth", ctypes.c_short),
        ("dmScale", ctypes.c_short), ("dmCopies", ctypes.c_short),
        ("dmDefaultSource", ctypes.c_short), ("dmPrintQuality", ctypes.c_short),
    ]


class _DEVMODE_UNION1_STRUCT2(ctypes.Structure):
    _fields_ = [
        ("dmPosition", _POINTL),
        ("dmDisplayOrientation", wintypes.DWORD),
        ("dmDisplayFixedOutput", wintypes.DWORD),
    ]


class _DEVMODE_UNION1(ctypes.Union):
    _fields_ = [("s1", _DEVMODE_UNION1_STRUCT1), ("s2", _DEVMODE_UNION1_STRUCT2)]


class DEVMODEW(ctypes.Structure):
    _anonymous_ = ("u1",)
    _fields_ = [
        ("dmDeviceName", wintypes.WCHAR * CCHDEVICENAME),
        ("dmSpecVersion", wintypes.WORD),
        ("dmDriverVersion", wintypes.WORD),
        ("dmSize", wintypes.WORD),
        ("dmDriverExtra", wintypes.WORD),
        ("dmFields", wintypes.DWORD),
        ("u1", _DEVMODE_UNION1),
        ("dmColor", ctypes.c_short),
        ("dmDuplex", ctypes.c_short),
        ("dmYResolution", ctypes.c_short),
        ("dmTTOption", ctypes.c_short),
        ("dmCollate", ctypes.c_short),
        ("dmFormName", wintypes.WCHAR * CCHFORMNAME),
        ("dmLogPixels", wintypes.WORD),
        ("dmBitsPerPel", wintypes.DWORD),
        ("dmPelsWidth", wintypes.DWORD),
        ("dmPelsHeight", wintypes.DWORD),
        ("dmDisplayFlags", wintypes.DWORD),
        ("dmDisplayFrequency", wintypes.DWORD),
        ("dmICMMethod", wintypes.DWORD),
        ("dmICMIntent", wintypes.DWORD),
        ("dmMediaType", wintypes.DWORD),
        ("dmDitherType", wintypes.DWORD),
        ("dmReserved1", wintypes.DWORD),
        ("dmReserved2", wintypes.DWORD),
        ("dmPanningWidth", wintypes.DWORD),
        ("dmPanningHeight", wintypes.DWORD),
    ]


def _user32():
    if not is_windows():
        return None
    return ctypes.windll.user32        # type: ignore[attr-defined]


# --------------------------------------------------------------------------
# Lecture
# --------------------------------------------------------------------------

def _friendly_names() -> dict[str, str]:
    """Noms commerciaux des ecrans (via WMI), indexes par identifiant PnP."""
    out: dict[str, str] = {}
    raw = run_powershell(
        "Get-CimInstance -Namespace root\\wmi -ClassName WmiMonitorID | "
        "ForEach-Object { $n = ($_.UserFriendlyName | Where-Object {$_ -gt 0} | "
        "ForEach-Object {[char]$_}) -join ''; \"$($_.InstanceName)|$n\" }",
        timeout=15)
    for line in raw.splitlines():
        if "|" not in line:
            continue
        inst, name = line.split("|", 1)
        m = re.search(r"DISPLAY\\([^\\]+)\\", inst)
        if m and name.strip():
            out.setdefault(m.group(1).upper(), name.strip())
    return out


def _preferred_modes() -> dict[str, tuple[int, int]]:
    """Definition native reelle de chaque dalle (mode prefere de l'EDID).

    Indispensable : avec DSR (NVIDIA) ou VSR (AMD), Windows expose des
    definitions superieures a la dalle. Sans ce garde-fou, ORION prendrait
    une super-resolution pour la definition native.
    """
    out: dict[str, tuple[int, int]] = {}
    raw = run_powershell(
        "Get-CimInstance -Namespace root\\wmi -ClassName "
        "WmiMonitorListedSupportedSourceModes -ErrorAction SilentlyContinue | "
        "ForEach-Object { $p = $_.MonitorSourceModes[$_.PreferredMonitorSourceModeIndex]; "
        "\"$($_.InstanceName)|$($p.HorizontalActivePixels)x$($p.VerticalActivePixels)\" }",
        timeout=20)
    for line in raw.splitlines():
        if "|" not in line:
            continue
        inst, res = line.split("|", 1)
        m = re.search(r"DISPLAY\\([^\\]+)\\", inst)
        r = re.match(r"\s*(\d+)x(\d+)", res.strip())
        if m and r:
            out.setdefault(m.group(1).upper(), (int(r.group(1)), int(r.group(2))))
    return out


def _iter_devices() -> Iterator[DISPLAY_DEVICEW]:
    u = _user32()
    if u is None:
        return
    i = 0
    while True:
        dd = DISPLAY_DEVICEW()
        dd.cb = ctypes.sizeof(DISPLAY_DEVICEW)
        if not u.EnumDisplayDevicesW(None, i, ctypes.byref(dd), 0):
            break
        i += 1
        if dd.StateFlags & DISPLAY_DEVICE_ATTACHED_TO_DESKTOP:
            yield dd


def _monitor_pnp(device_name: str) -> str:
    """Identifiant PnP de l'ecran branche sur cette sortie."""
    u = _user32()
    if u is None:
        return ""
    dd = DISPLAY_DEVICEW()
    dd.cb = ctypes.sizeof(DISPLAY_DEVICEW)
    if u.EnumDisplayDevicesW(device_name, 0, ctypes.byref(dd), 0):
        m = re.search(r"MONITOR\\([^\\]+)\\", dd.DeviceID)
        if m:
            return m.group(1).upper()
    return ""


def _modes(device_name: str) -> list[DisplayMode]:
    u = _user32()
    if u is None:
        return []
    seen: set[tuple[int, int, int]] = set()
    out: list[DisplayMode] = []
    i = 0
    while True:
        dm = DEVMODEW()
        dm.dmSize = ctypes.sizeof(DEVMODEW)
        if not u.EnumDisplaySettingsExW(device_name, i, ctypes.byref(dm), 0):
            break
        i += 1
        if dm.dmBitsPerPel < 32 or dm.dmDisplayFrequency <= 1:
            continue
        key = (dm.dmPelsWidth, dm.dmPelsHeight, dm.dmDisplayFrequency)
        if key in seen:
            continue
        seen.add(key)
        out.append(DisplayMode(dm.dmPelsWidth, dm.dmPelsHeight,
                               dm.dmDisplayFrequency, dm.dmBitsPerPel))
    out.sort(key=lambda m: (m.pixels, m.refresh), reverse=True)
    return out


def _current(device_name: str) -> DisplayMode | None:
    u = _user32()
    if u is None:
        return None
    dm = DEVMODEW()
    dm.dmSize = ctypes.sizeof(DEVMODEW)
    if not u.EnumDisplaySettingsExW(device_name, ENUM_CURRENT_SETTINGS,
                                    ctypes.byref(dm), 0):
        return None
    return DisplayMode(dm.dmPelsWidth, dm.dmPelsHeight,
                       dm.dmDisplayFrequency, dm.dmBitsPerPel)


def _position(device_name: str) -> tuple[int, int]:
    u = _user32()
    if u is None:
        return (0, 0)
    dm = DEVMODEW()
    dm.dmSize = ctypes.sizeof(DEVMODEW)
    if u.EnumDisplaySettingsExW(device_name, ENUM_CURRENT_SETTINGS,
                                ctypes.byref(dm), 0):
        return (dm.s2.dmPosition.x, dm.s2.dmPosition.y)
    return (0, 0)


def _native_mode(modes: list[DisplayMode], current: DisplayMode | None,
                 preferred: tuple[int, int] | None) -> DisplayMode | None:
    """Mode natif de la dalle, en ignorant les super-resolutions logicielles."""
    if preferred:
        exact = [m for m in modes
                 if (m.width, m.height) == preferred]
        if exact:
            return max(exact, key=lambda m: m.refresh)
        # la dalle annonce une definition absente de la liste : on prend
        # le plus grand mode qui ne la depasse pas.
        below = [m for m in modes
                 if m.width <= preferred[0] and m.height <= preferred[1]]
        if below:
            return max(below, key=lambda m: (m.pixels, m.refresh))
    if current:
        same = [m for m in modes
                if (m.width, m.height) == (current.width, current.height)]
        if same:
            return max(same, key=lambda m: m.refresh)
        return current
    return modes[0] if modes else None


def enumerate_displays() -> list[Display]:
    """Tous les ecrans actifs, avec leurs modes disponibles."""
    if not is_windows():
        return []
    names = _friendly_names()
    preferred = _preferred_modes()
    out: list[Display] = []
    for dd in _iter_devices():
        dev = dd.DeviceName
        modes = _modes(dev)
        cur = _current(dev)
        pnp = _monitor_pnp(dev)
        native = _native_mode(modes, cur, preferred.get(pnp))
        disp = Display(
            device=dev,
            name=names.get(pnp) or dd.DeviceString or dev.strip("\\.").replace("\\", ""),
            primary=bool(dd.StateFlags & DISPLAY_DEVICE_PRIMARY_DEVICE),
            current=cur,
            native=native,
            modes=modes,
            position=_position(dev),
        )
        if native:
            disp.max_refresh_at_native = disp.best_refresh(native.width, native.height)
        out.append(disp)
    out.sort(key=lambda d: (not d.primary, d.device))
    log.info("Ecrans detectes : %s", [(d.name, str(d.current)) for d in out])
    return out


# --------------------------------------------------------------------------
# Ecriture
# --------------------------------------------------------------------------

def apply_mode(device: str, mode: DisplayMode, permanent: bool = False) -> tuple[bool, str]:
    """Applique une resolution / frequence a un ecran.

    `permanent=False` : le mode est actif jusqu'au prochain redemarrage,
    ce qui permet de revenir en arriere sans rien casser.
    """
    u = _user32()
    if u is None:
        return False, "Fonction disponible uniquement sous Windows"

    dm = DEVMODEW()
    dm.dmSize = ctypes.sizeof(DEVMODEW)
    if not u.EnumDisplaySettingsExW(device, ENUM_CURRENT_SETTINGS, ctypes.byref(dm), 0):
        return False, "Ecran introuvable"

    dm.dmPelsWidth = mode.width
    dm.dmPelsHeight = mode.height
    dm.dmDisplayFrequency = mode.refresh
    dm.dmBitsPerPel = mode.bpp or 32
    dm.dmFields = DM_PELSWIDTH | DM_PELSHEIGHT | DM_DISPLAYFREQUENCY | DM_BITSPERPEL

    test = u.ChangeDisplaySettingsExW(device, ctypes.byref(dm), None, CDS_TEST, None)
    if test != DISP_CHANGE_SUCCESSFUL:
        return False, CHANGE_ERRORS.get(test, f"Code {test}")

    flags = CDS_UPDATEREGISTRY if permanent else 0
    res = u.ChangeDisplaySettingsExW(device, ctypes.byref(dm), None, flags, None)
    ok = res == DISP_CHANGE_SUCCESSFUL
    if ok:
        log.info("Ecran %s regle sur %s", device, mode)
    return ok, CHANGE_ERRORS.get(res, f"Code {res}")

