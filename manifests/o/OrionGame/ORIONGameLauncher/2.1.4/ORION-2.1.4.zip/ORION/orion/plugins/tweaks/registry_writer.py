"""Base de registre (Unity et jeux qui stockent leurs options la)."""
from __future__ import annotations

from ...core.logging_setup import get
from ...core.models import TweakOp
from ...core.winutil import (HKCU, HKLM, reg_type, reg_value, reg_write_binary,
                              reg_write_dword, reg_write_string)
from .base import TweakWriter

log = get("tweaks.registre")


#: winreg.REG_BINARY (constante Windows, sans importer winreg ailleurs que sous Windows)
REG_BINARY = 3


def texte_binaire(val: bytes) -> str:
    """b"TemporalAntialiasing\\0" -> "TemporalAntialiasing" (texte Unity) ;
    autre contenu binaire : sa forme hexadecimale."""
    brut = val.rstrip(b"\0")
    try:
        texte = brut.decode("utf-8")
    except UnicodeDecodeError:
        return val.hex()
    return texte if texte.isprintable() else val.hex()


def _split(target: str) -> tuple[str, str]:
    """"HKCU\\Software\\X" -> ("HKCU", "Software\\X")"""
    t = target.replace("/", "\\")
    for prefix, root in (("HKCU\\", HKCU), ("HKEY_CURRENT_USER\\", HKCU),
                         ("HKLM\\", HKLM), ("HKEY_LOCAL_MACHINE\\", HKLM)):
        if t.upper().startswith(prefix.upper()):
            return root, t[len(prefix):]
    return HKCU, t


class RegistryWriter(TweakWriter):
    id = "registry"
    label = "Base de registre"

    def read(self, op: TweakOp) -> str | None:
        root, path = _split(op.target)
        val = reg_value(root, path, op.key, None)
        if isinstance(val, (bytes, bytearray)):
            return texte_binaire(bytes(val))
        return None if val is None else str(val)

    def write(self, ops: list[TweakOp]) -> tuple[int, str]:
        written = 0
        for op in ops:
            root, path = _split(op.target)
            value = str(op.value)
            if reg_type(root, path, op.key) == REG_BINARY:
                # le jeu range ce texte en binaire (Unity) : on garde sa forme
                ok = reg_write_binary(root, path, op.key, value.encode("utf-8") + b"\0")
            elif value.lstrip("-").isdigit():
                ok = reg_write_dword(root, path, op.key, int(value))
            else:
                ok = reg_write_string(root, path, op.key, value)
            if ok:
                written += 1
            else:
                return written, f"Ecriture refusee : {op.target}\\{op.key}"
        return written, "Reglages ecrits dans le registre"

