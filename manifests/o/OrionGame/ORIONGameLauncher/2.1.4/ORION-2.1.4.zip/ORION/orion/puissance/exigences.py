"""Configurations minimale et recommandee des jeux (fiches Steam).

La fiche Steam de chaque jeu publie ses configurations en texte libre
(HTML). On en extrait, pour chacune : les cartes graphiques citees, les
processeurs, la memoire vive et la memoire video.

Quand plusieurs composants sont cites (« GTX 1060 / RX 580 », « Core
i7-12700 ou Ryzen 7 7800X3D »), l'editeur dit que l'un OU l'autre suffit :
c'est donc le MOINS puissant qui sert de reference (regle 2, 2.0). Jusqu'a
la 1.9.8 c'etait le plus puissant, « par prudence » : le calculateur
demandait alors plus que l'editeur lui-meme, et classait en « Basse » des
jeux que la machine fait tourner sans peine (Cyberpunk 2077 demandait un
Ryzen 7 7800X3D la ou un Core i7-12700 est annonce suffisant). La prudence
reste dans la fourchette d'images par seconde, pas dans la lecture de ce
que l'editeur a ecrit.

Les resultats sont gardes 30 jours (les configurations changent rarement).
"""
from __future__ import annotations

from orion.core import region

import html
import re
import time
from dataclasses import asdict, dataclass

from ..core.logging_setup import get
from .references import tous_les_cpu, tous_les_gpu

log = get("puissance.exigences")

GARDER = 30 * 24 * 3600
#: regle de lecture des composants cites (voir l'en-tete) ; une fiche gardee
#: sous une regle anterieure est relue depuis son texte, sans reseau.
#: 2 : le moins puissant des composants cites. 3 : tables de reference
#: completees (portables, puces integrees) : un composant qui n'etait pas
#: reconnu peut l'etre. 4 (13 octobre 2026) : l'objectif de l'editeur est lu
#: en entier (generation d'images, prereglage, definition de rendu), voir
#: `_objectif`. Une fiche gardee sous une regle anterieure dont le texte a ete
#: abrege avant ses notes est relue sur Steam (`perimee`). 5 (13 octobre
#: 2026, le soir) : une carte avec ray tracing materiel exigee est lue
#: (`_RAY_TRACING`), depuis le texte garde.
REGLE = 5
#: regle a partir de laquelle le texte garde va jusqu'aux notes de l'editeur
TEXTE_COMPLET = 4
#: longueur du texte garde de chaque configuration (600 jusqu'a la regle 3 :
#: les notes de l'editeur, en fin de fiche, etaient coupees)
TEXTE_GARDE = 2000
ANCIEN_TEXTE = 600


@dataclass
class Config:
    gpu: float | None = None           # indice de la carte demandee
    gpu_nom: str = ""
    cpu: float | None = None
    cpu_nom: str = ""
    ram_go: float | None = None
    vram_go: float | None = None
    cible_px: int | None = None        # definition visee si le jeu la precise
    cible_fps: int | None = None       # images/s visees si le jeu les precise
    texte: str = ""                    # extrait lisible (pour la fiche)
    #: l'objectif de l'editeur suppose la generation d'images (« 60 fps avec
    #: Frame Generation ») : la carte n'en calcule qu'environ la moitie
    generation_images: bool = False
    #: prereglage de l'objectif (« basse », « moyenne », « haute », « ultra »),
    #: s'il est ecrit ; sans precision : « haute » (recommandee) ou « basse »
    cible_niveau: str | None = None
    #: definition reellement calculee quand l'objectif passe par une mise a
    #: l'echelle (« 1080p upscale depuis 720p ») ; None : `cible_px`
    rendu_px: int | None = None
    #: le jeu exige une carte qui calcule le ray tracing (« GPU Hardware Ray
    #: Tracing Required ») : sans elle, il ne se lance pas
    ray_tracing: bool = False
    #: la fiche cite une mise a l'echelle (DLSS, FSR, XeSS, TSR, upscaling),
    #: ou que ce soit dans le texte : le jeu en propose une (15 octobre :
    #: sans cette lecture, ORION conseillait « Ultra + DLSS » a Rocket
    #: League, qui n'a pas de DLSS)
    mise_a_l_echelle: bool = False


@dataclass
class Exigences:
    appid: str
    titre: str = ""
    minimum: Config | None = None
    recommandee: Config | None = None
    lu_le: float = 0.0

    @property
    def exploitable(self) -> bool:
        return any(c is not None and c.gpu for c in (self.minimum, self.recommandee))

    @property
    def ray_tracing(self) -> bool:
        """Le jeu ne se lance que sur une carte avec ray tracing materiel."""
        return any(c is not None and getattr(c, "ray_tracing", False) for c in (self.minimum, self.recommandee))

    @property
    def mise_a_l_echelle(self) -> bool:
        """La fiche Steam cite DLSS, FSR, XeSS, TSR ou un « upscaling »."""
        return any(c is not None and getattr(c, "mise_a_l_echelle", False) for c in (self.minimum, self.recommandee))


def _texte(brut: str) -> str:
    t = re.sub(r"<br\s*/?>|</li>|</p>", "\n", brut or "", flags=re.I)
    t = re.sub(r"<[^>]+>", " ", t)
    return html.unescape(re.sub(r"[ \t]+", " ", t)).strip()


def _ligne(texte: str, *mots: str) -> str:
    for ligne in texte.splitlines():
        if ":" not in ligne:
            continue
        tete, reste = ligne.split(":", 1)
        if any(m in tete.lower() for m in mots) and len(tete) < 40:
            return reste
    return ""


def _go(texte: str) -> float | None:
    m = re.search(r"(\d+(?:[.,]\d+)?)\s*(go|gb|g\b)", texte, re.I)
    if m:
        return float(m.group(1).replace(",", "."))
    m = re.search(r"(\d{3,5})\s*(mo|mb)", texte, re.I)
    return round(int(m.group(1)) / 1024, 1) if m else None


#: generation d'images (DLSS Frame Generation, FSR 3, « génération d'images »)
_GENERATION = re.compile(r"frame[\s-]*gen\w*|g[ée]n[ée]ration\s+d.images|g[ée]n[ée]ration\s+de\s+(?:trames|frames)"
                         r"|multi[\s-]*frame|\bmfg\b", re.I)
#: mise a l'echelle de l'image (le jeu calcule moins de points qu'il n'en affiche)
_MISE_A_L_ECHELLE = re.compile(r"upscal\w*|mise\s+[àa]\s+l.[ée]chelle|\bdlss\b|\bfsr\b|\bxess\b|\btsr\b"
                               r"|super[\s-]*r[ée]solution|r[ée]solution\s+dynamique|dynamic\s+resolution", re.I)
_NATIVE = re.compile(r"(?:native|natif|natives?|depuis|from|internal|interne)\D{0,30}?(\d{3,4})\s*p\b", re.I)
#: mots d'un prereglage, du plus precis au plus court
_MOTS_NIVEAU = (r"tr[eè]s\s+bas|ultra[\s-]+bas|tr[eè]s\s+faibles?|plus\s+bas|bas|basse|faibles?|moyens?|moyenne"
                r"|standard|tr[eè]s\s+[ée]lev[ée]e?s?|[ée]lev[ée]e?s?|hauts?|haute|ultra|maximum|max|lowest|very\s+low|low"
                r"|medium|normal|very\s+high|highest|high|epic|extreme")
#: « paramètres graphiques sur "Moyen" », « Graphics Preset: LOW », « réglages élevés »
_PREREGLAGE = re.compile(
    r"(?:param[eè]tres?|r[ée]glages?|settings?|presets?|pr[ée]r[ée]glages?|qualit[ée]|graphismes?|graphiques?"
    r"|graphics|d[ée]tails?|quality|configuration)\b[^.\n]{0,30}?[\"«“”'\s:]*(" + _MOTS_NIVEAU + r")\b", re.I)
#: un prereglage ecrit avant le mot (« High Quality Settings », « Medium quality settings »)
_PREREGLAGE_AVANT = re.compile(
    r"\b(lowest|very\s+low|low|medium|very\s+high|high|ultra|epic|max|performance|standard)\s+"
    r"(?:quality\s+)?(?:settings?|presets?|quality|graphics|mode)\b", re.I)
NIVEAUX_ECRITS = {
    "basse": ("tres bas", "ultra bas", "tres faible", "plus bas", "bas", "basse", "faible", "lowest", "very low",
              "low"),
    "moyenne": ("moyen", "moyenne", "medium", "normal", "standard", "performance"),
    "haute": ("eleve", "haut", "haute", "high"),
    "ultra": ("tres eleve", "ultra", "maximum", "max", "very high", "highest", "epic", "extreme"),
}
#: definitions, dans l'ordre ou la phrase les cite
_DEFINITIONS = [(re.compile(r"3840\s*[x×]\s*2160|2160p|\b4k\b|\buhd\b"), 3840 * 2160),
                (re.compile(r"2560\s*[x×]\s*1440|1440p|\bqhd\b|\b2k\b"), 2560 * 1440),
                (re.compile(r"1920\s*[x×]\s*1080|1080p|full\s*hd"), 1920 * 1080),
                (re.compile(r"1280\s*[x×]\s*720|720p"), 1280 * 720)]
#: « 60 fps », « 30 ips », « Target FPS: 30 »
_IMAGES = re.compile(r"(\d{2,3})\s*(?:fps|i/s|ips|images par seconde)|\b(?:fps|i/s)\s*:?\s*(\d{2,3})\b", re.I)


def _sans_accent(t: str) -> str:
    import unicodedata
    t = unicodedata.normalize("NFD", t.lower())
    return re.sub(r"\s+", " ", "".join(ch for ch in t if not unicodedata.combining(ch))).strip()


def _niveau_ecrit(mot: str) -> str | None:
    m = re.sub(r"(eleve)e?s?$", r"\1", _sans_accent(mot))
    m = re.sub(r"^(moyen|haut|faible|tres faible)s$", r"\1", m)
    for niveau in ("ultra", "basse", "moyenne", "haute"):
        if m in NIVEAUX_ECRITS[niveau]:
            return niveau
    return None


def _nettoyer(t: str) -> str:
    """Le texte sans ce qui ressemble a une definition et n'en est pas une
    (« Intel UHD Graphics 630 », « Série Intel HD/UHD », « textures 4K »)."""
    bas = re.sub(r"\buhd\s*(graphics|\d{3})|\bhd\s*/\s*uhd\b|\bintel\s+(?:hd|uhd)\b", " ", t.lower())
    return re.sub(r"\b4k\s*(textures?|texture pack)|\btextures?\s*(en\s*)?4k\b", " ", bas)


def _objectif(texte: str, c: Config) -> None:
    """Ce que l'editeur promet avec cette configuration, lu dans la phrase qui
    donne l'objectif (images/s ou definition) : images/s, definition,
    prereglage, generation d'images, mise a l'echelle.

    13 octobre 2026 : Monster Hunter Wilds recommande « 1080p/60 fps (avec
    Frame Generation activé) avec les paramètres graphiques sur "Moyen" » ;
    ORION lisait « 60 fps » en reglages eleves sans generation d'images, et
    annoncait deux fois trop d'images par seconde. Une possibilite citee en
    plus (« Frame Generation can be used », « or 4k using DLSS ») ne change
    pas l'objectif : seule compte la phrase de l'objectif, et ce qui n'y est
    pas donne en alternative."""
    vise = re.compile(r"\d{2,3}\s*(?:fps|i/s|ips|images par seconde)|\b(?:720|1080|1440|2160)p\b|\b4k\b|"
                      r"full\s*hd|\d{3,4}\s*[x×]\s*\d{3,4}", re.I)
    composant = re.compile(r"\s*(graphi|vid|carte|gpu|processeur|processor|cpu|m[ée]moire|memory|ram|syst|os\b"
                           r"|espace|storage|stockage|directx|r[ée]seau|network)", re.I)
    # la ligne de l'objectif (le plus souvent « Notes supplémentaires »), en
    # entier : « 1080P. Graphics Quality Preset “Low”. 60FPS Target. »
    ligne = next((x for x in texte.splitlines() if vise.search(x) and not composant.match(x)), None)
    if not ligne:
        return
    propre = _nettoyer(ligne)
    # alternative (« … or High quality settings in 30 FPS », « (or 4k using DLSS) ») : retiree
    principal = re.split(r"\(\s*(?:or|ou)\b|\b(?:or|ou)\s+(?=\d|4k|high|medium|low|ultra|[ée]lev|moyen|bas)",
                         propre, maxsplit=1)[0]
    images = _IMAGES.search(principal)
    if images and 20 <= int(images.group(1) or images.group(2)) <= 240:
        c.cible_fps = int(images.group(1) or images.group(2))
    # la definition : avant une alternative entre parentheses (« FullHD (or 4k
    # using DLSS) »), meme apres un second objectif (« or High … in 30 FPS »)
    definitions = re.split(r"\(\s*(?:or|ou)\b", propre, maxsplit=1)[0]
    trouvees = [(m.start(), px) for motif, px in _DEFINITIONS for m in [motif.search(definitions)] if m]
    if trouvees:
        c.cible_px = min(trouvees)[1]
    niveaux = [m for m in (_PREREGLAGE.search(principal), _PREREGLAGE_AVANT.search(principal)) if m]
    if niveaux:
        c.cible_niveau = _niveau_ecrit(min(niveaux, key=lambda m: m.start()).group(1))
    phrases = [x for x in re.split(r"(?<=[.!;])\s+", principal) if x.strip()]
    if any(_dans_l_objectif(x, _GENERATION, vise) for x in phrases):
        c.generation_images = True
    if any(_dans_l_objectif(x, _MISE_A_L_ECHELLE, vise) for x in phrases):
        n = _NATIVE.search(principal)
        hauteur = int(n.group(1)) if n else 0
        if 480 <= hauteur <= 2160:
            c.rendu_px = round(hauteur * 16 / 9) * hauteur
        elif c.cible_px:
            # mode « Qualité » des mises a l'echelle : 2/3 de la definition
            # affichee sur chaque cote
            c.rendu_px = round(c.cible_px * 4 / 9)


#: une carte avec ray tracing materiel EXIGEE (« GPU Hardware Ray Tracing
#: Required », « hardware ray tracing-enabled graphics card », « Raytracing-
#: capable GPU », « carte compatible ray tracing obligatoire »). Pas une
#: carte seulement conseillee pour l'activer (« nécessaires pour bénéficier
#: du ray tracing », Resident Evil 4).
_RT = r"(?:ray[\s-]*tracing|raytracing|lancer\s+de\s+rayons|\bdxr\b)"
_RAY_TRACING = re.compile(
    r"(?:hardware|mat[ée]riel)[\s-]*(?:accelerated\s+)?" + _RT + r"[^.;\n]{0,25}?\b(?:required|requis|obligatoire|needed|n[ée]cessaire)"
    r"|" + _RT + r"[\s-]*(?:enabled|capable|compatible)[\s-]*(?:graphics\s+card|video\s+card|gpu|carte)"
    r"|(?:gpu|graphics\s+card|video\s+card|carte(?:\s+graphique)?)\s+(?:with|avec|prenant\s+en\s+charge\s+le|compatible(?:\s+avec\s+le)?)"
    r"\s+(?:hardware\s+|mat[ée]riel\s+)?" + _RT + r"(?!\s*(?:optional|optionnel|facultatif))"
    r"|" + _RT + r"(?:\s+(?:hardware|mat[ée]riel))?\s*(?:is\s+|est\s+)?(?:required|requis|obligatoire)"
    r"|(?:requires?|n[ée]cessite|exige)\s+(?:an?\s+|une\s+)?(?:\w+\s+){0,4}?" + _RT + r"[\s-]*(?:enabled|capable|compatible|gpu|graphics|card|carte)",
    re.I)
#: phrase ou le ray tracing n'est qu'une option
_RT_OPTION = re.compile(r"optional|optionnel|facultatif|pour\s+b[ée]n[ée]ficier|to\s+(?:use|enable|play\s+with)"
                        r"|for\s+ray|pour\s+(?:le|activer)|if\s+you\s+want|recommended\s+for", re.I)


def cite_mise_a_l_echelle(texte: str) -> bool:
    """Vrai si la fiche cite une mise a l'echelle de l'image, ou que ce soit."""
    return bool(_MISE_A_L_ECHELLE.search(texte or ""))


def exige_ray_tracing(texte: str) -> bool:
    """Le texte d'une configuration exige une carte avec ray tracing materiel
    (fonction pure, testee)."""
    for phrase in re.split(r"(?<=[.;!])\s+|\n", texte or ""):
        m = _RAY_TRACING.search(phrase)
        if m and not _RT_OPTION.search(phrase):
            return True
    return False


#: une technique seulement possible, pas utilisee pour l'objectif
_POSSIBLE = r"(?:can|could|peut|peuvent|pris en charge|prise en charge|supported|optional|optionnel|available|disponible)"


def _dans_l_objectif(phrase: str, motif: re.Pattern, vise: re.Pattern) -> bool:
    """La technique (generation d'images, mise a l'echelle) sert a l'objectif :
    citee dans la phrase de l'objectif ou dans une phrase qui dit l'avoir
    utilisee (« tested with TSR, DLSS »), pas seulement possible (« Frame
    Generation can be used », « Génération d'images prise en charge »)."""
    m = motif.search(phrase)
    if not m:
        return False
    if re.search(r"\b(?:sans|without|no)\b[^.]{0,20}(?:" + motif.pattern + ")", phrase, re.I):
        return False
    if re.search("(?:" + motif.pattern + r")[^.]{0,30}\b" + _POSSIBLE + r"\b", phrase, re.I):
        return False
    if vise.search(phrase):
        return True
    return not re.search(r"\b" + _POSSIBLE + r"\b|\bsupports?\b", phrase, re.I)


def perimee(memo: dict) -> bool:
    """Fiche gardee sous une regle anterieure, dont le texte a ete abrege
    avant les notes de l'editeur : la regle en vigueur ne peut pas la relire
    sans la fiche Steam complete."""
    if (memo.get("regle") or 0) >= min(REGLE, TEXTE_COMPLET):
        return False
    return any(len((memo.get(champ) or {}).get("texte") or "") >= ANCIEN_TEXTE
               for champ in ("minimum", "recommandee"))


def lire_config(brut: str) -> Config | None:
    """Une configuration Steam (HTML) -> Config (fonction pure, testee)."""
    texte = _texte(brut)
    if not texte:
        return None
    c = Config(texte=texte[:TEXTE_GARDE])
    graph = _ligne(texte, "graphi", "vid", "carte", "gpu") or texte
    gpus = tous_les_gpu(graph)
    if gpus:
        # l'une OU l'autre suffit : la moins puissante est la vraie demande
        cle, indice = min(gpus, key=lambda g: g[1])
        c.gpu, c.gpu_nom = indice, cle.upper()
    vram = re.search(r"(\d+)\s*(go|gb)\s*(de\s*)?(vram|v-ram|m[ée]moire vid|video)",
                     graph, re.I) or re.search(r"(\d+)\s*(go|gb)", graph, re.I)
    if vram:
        c.vram_go = float(vram.group(1))
    proc = _ligne(texte, "processeur", "processor", "cpu")
    cpus = tous_les_cpu(proc)
    if cpus:
        cle, indice = min(cpus, key=lambda x: x[1])
        c.cpu, c.cpu_nom = indice, cle.upper()
    # definition visee : les noms de cartes graphiques (« Intel UHD Graphics
    # 630 ») et les mentions de textures (« textures 4K ») ne comptent pas
    bas = _nettoyer(texte)
    if re.search(r"3840\s*[x×]\s*2160|2160p|\b4k\b|\buhd\b", bas):
        c.cible_px = 3840 * 2160
    elif re.search(r"2560\s*[x×]\s*1440|1440p|\bqhd\b|\b2k\b", bas):
        c.cible_px = 2560 * 1440
    elif re.search(r"1920\s*[x×]\s*1080|1080p|full\s*hd", bas):
        c.cible_px = 1920 * 1080
    elif re.search(r"1280\s*[x×]\s*720|720p", bas):
        c.cible_px = 1280 * 720
    ips = re.search(r"(\d{2,3})\s*(fps|i/s|ips|images par seconde)", bas)
    if ips and 20 <= int(ips.group(1)) <= 240:
        c.cible_fps = int(ips.group(1))
    _objectif(texte, c)
    c.ray_tracing = exige_ray_tracing(texte)
    c.mise_a_l_echelle = cite_mise_a_l_echelle(texte)
    mem = _ligne(texte, "mémoire", "memoire", "memory", "ram")
    if mem and not re.search(r"vid|vram", mem, re.I):
        c.ram_go = _go(mem)
    return c


def depuis_fiche_steam(appid: str, donnees: dict) -> Exigences:
    e = Exigences(appid=str(appid), titre=donnees.get("name", ""), lu_le=time.time())
    req = donnees.get("pc_requirements") or {}
    if isinstance(req, dict):
        e.minimum = lire_config(req.get("minimum", ""))
        e.recommandee = lire_config(req.get("recommended", ""))
    return e


def exigences(appid: str) -> Exigences | None:
    """Configurations d'un jeu Steam (cache 30 jours). None si inconnu."""
    from ..core.base import Table
    table = Table("exigences")
    memo = table.get(str(appid))
    if memo and time.time() - memo.get("lu_le", 0) < GARDER and not perimee(memo):
        return en_cache(appid)
    from ..core import reseau
    r = reseau.get("https://store.steampowered.com/api/appdetails",
                   params={"appids": appid, "l": region.langue_steam(), "cc": region.cc()}, timeout=15)
    r.raise_for_status()
    from ..core import steam_limite
    bloc = steam_limite.fiche(r.json(), appid) or {}      # passage commun
    if not bloc.get("success"):
        table.set(str(appid), dict(asdict(Exigences(appid=str(appid), lu_le=time.time())),
                                   regle=REGLE))
        return None
    e = depuis_fiche_steam(appid, bloc.get("data") or {})
    table.set(str(appid), dict(asdict(e), regle=REGLE))
    return e


def _depuis_dict(d: dict) -> Exigences:
    e = Exigences(appid=d.get("appid", ""), titre=d.get("titre", ""),
                  lu_le=d.get("lu_le", 0))
    connus = set(Config.__dataclass_fields__)
    for champ in ("minimum", "recommandee"):
        if d.get(champ):
            setattr(e, champ, Config(**{k: v for k, v in d[champ].items() if k in connus}))
    return e


def _relire(c: Config | None) -> None:
    """Applique la regle en vigueur a une configuration gardee, depuis son
    texte : quand plusieurs cartes ou processeurs y sont cites, le moins
    puissant devient la reference, et un composant qui n'etait pas reconnu
    est lu s'il l'est desormais. Une seule reference deja lue : rien ne
    change (le texte garde est abrege, on ne lui fait dire que cela)."""
    if c is None or not c.texte:
        return
    graph = _ligne(c.texte, "graphi", "vid", "carte", "gpu") or c.texte
    gpus = tous_les_gpu(graph)
    if len(gpus) > 1 or (gpus and not c.gpu):
        cle, indice = min(gpus, key=lambda g: g[1])
        c.gpu, c.gpu_nom = indice, cle.upper()
    cpus = tous_les_cpu(_ligne(c.texte, "processeur", "processor", "cpu"))
    if len(cpus) > 1 or (cpus and not c.cpu):
        cle, indice = min(cpus, key=lambda x: x[1])
        c.cpu, c.cpu_nom = indice, cle.upper()
    # regle 4 : l'objectif, si les notes sont dans le texte garde (sinon la
    # fiche est relue sur Steam, `perimee`)
    _objectif(c.texte, c)
    # regle 5 : la carte avec ray tracing materiel exigee
    c.ray_tracing = exige_ray_tracing(c.texte)
    c.mise_a_l_echelle = cite_mise_a_l_echelle(c.texte)


def en_cache(appid: str) -> Exigences | None:
    from ..core.base import Table
    table = Table("exigences")
    memo = table.get(str(appid))
    if not memo:
        return None
    e = _depuis_dict(memo)
    if memo.get("regle") != REGLE:
        # fiche lue avec l'ancienne regle : relue une fois, puis gardee. Une
        # fiche abregee avant ses notes garde son ancienne regle : elle sera
        # relue sur Steam (`perimee`, `a_relire`), et sert telle quelle d'ici la
        _relire(e.minimum)
        _relire(e.recommandee)
        if not perimee(memo):
            try:
                table.set(str(appid), dict(asdict(e), regle=REGLE))
            except Exception:
                log.exception("Fiche %s non remise a jour", appid)
    return e


def a_relire(appid: str) -> bool:
    """La fiche gardee doit etre relue sur Steam (voir `perimee`)."""
    from ..core.base import Table
    memo = Table("exigences").get(str(appid))
    return bool(memo) and perimee(memo)
