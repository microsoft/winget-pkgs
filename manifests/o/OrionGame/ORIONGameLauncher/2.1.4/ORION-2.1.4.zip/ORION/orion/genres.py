"""Types de jeux de la Boutique : FPS, MOBA, MMORPG, RTS...

Un type regroupe les jeux dont les genres ou les etiquettes Steam contiennent
l'un de ses mots (en francais comme en anglais, sans accents ni casse).
`GRAINE` fixe le tirage du tri « Decouverte » le temps d'une session.
"""
from __future__ import annotations

import functools
import random
import re
import unicodedata

#: (cle, libelle affiche, mots cherches dans les genres et etiquettes)
TYPES: tuple[tuple[str, str, tuple[str, ...]], ...] = (
    ("fps", "FPS", ("fps", "tir a la premiere personne", "first-person shooter", "shooter")),
    ("tps", "TPS", ("tps", "tir a la troisieme personne", "third-person shooter")),
    ("battle-royale", "Battle Royale", ("battle royale",)),
    ("moba", "MOBA", ("moba",)),
    ("mmorpg", "MMORPG", ("mmorpg",)),
    ("mmo", "MMO", ("mmo", "massivement multijoueur", "massively multiplayer")),
    ("rpg", "RPG", ("rpg", "jdr", "jeu de role", "role-playing")),
    ("action-rpg", "Action-RPG", ("action-rpg", "action rpg", "hack and slash", "souls-like")),
    ("rts", "RTS", ("rts", "str", "strategie en temps reel", "real-time strategy")),
    ("strategie", "Strategie", ("strategie", "strategy", "4x", "tour par tour", "turn-based",
                                "grande strategie", "grand strategy")),
    ("gestion", "Gestion", ("gestion", "management", "city builder", "construction de ville",
                            "construction de base", "base building", "tycoon")),
    ("simulation", "Simulation", ("simulation", "simulateur", "simulator")),
    ("survie", "Survie", ("survie", "survival", "crafting", "artisanat")),
    ("horreur", "Horreur", ("horreur", "horror", "epouvante")),
    ("monde-ouvert", "Monde ouvert", ("monde ouvert", "open world", "bac a sable", "sandbox")),
    ("aventure", "Aventure", ("aventure", "adventure")),
    ("action", "Action", ("action",)),
    ("plateforme", "Plateforme", ("plateforme", "plateformes", "platformer", "metroidvania")),
    ("roguelike", "Roguelike", ("roguelike", "rogue-like", "roguelite", "rogue-lite")),
    ("combat", "Combat", ("combat", "fighting", "beat 'em up", "baston")),
    ("course", "Course", ("course", "racing", "conduite", "driving")),
    ("sport", "Sport", ("sport", "sports", "football", "basket")),
    ("coop", "Coop", ("coop", "co-op", "cooperation", "cooperatif")),
    ("reflexion", "Reflexion", ("reflexion", "puzzle", "casse-tete", "enigmes")),
    ("narratif", "Narratif", ("narratif", "riche en histoire", "story rich", "choix multiples",
                              "visual novel", "roman visuel")),
    ("inde", "Inde", ("inde", "independant", "indie")),
)
LIBELLES = {cle: libelle for cle, libelle, _ in TYPES}
_MOTS = {cle: mots for cle, _, mots in TYPES}

#: une graine par lancement d'ORION : la selection change a chaque ouverture,
#: pas a chaque clic
GRAINE = random.randrange(1 << 30)


def _plat(texte: str) -> str:
    t = unicodedata.normalize("NFKD", texte or "")
    return "".join(c for c in t if not unicodedata.combining(c)).lower().strip()


def _contient(etiquette: str, mot: str) -> bool:
    """Mot entier (« str » ne doit pas reconnaitre « strategie »)."""
    return re.search(rf"(?<![a-z0-9]){re.escape(mot)}(?![a-z0-9])", etiquette) is not None


@functools.lru_cache(maxsize=8192)
def _types_etiquette(etiquette: str) -> frozenset:
    """Types reconnus dans UNE etiquette. Steam n'en a que quelques
    centaines : chacune n'est examinee qu'une fois. Examiner chaque etiquette
    de chaque jeu contre chaque mot prenait plus de deux secondes du fil
    d'affichage au demarrage (mesure du 7 octobre 2026)."""
    plat = _plat(etiquette)
    return frozenset(cle for cle, mots in _MOTS.items()
                     if any(_contient(plat, m) for m in mots))


@functools.lru_cache(maxsize=8192)
def _types(etiquettes: tuple) -> frozenset:
    out: set = set()
    for e in etiquettes:
        if e:
            out |= _types_etiquette(e)
    return frozenset(out)


def types_de(etiquettes) -> set[str]:
    """Types de jeu reconnus dans des etiquettes (calcul garde en memoire :
    la Boutique le demande pour chaque jeu a chaque affichage)."""
    return set(_types(tuple(str(e) for e in etiquettes or [] if e)))


def du_type(fiche, cle: str) -> bool:
    return cle in types_de(getattr(fiche, "etiquettes", []) or [])


def compter(fiches) -> dict[str, int]:
    """{type: nombre de jeux}, pour n'afficher que les types qui en ont."""
    total: dict[str, int] = {}
    for f in fiches:
        for cle in types_de(getattr(f, "etiquettes", []) or []):
            total[cle] = total.get(cle, 0) + 1
    return total

