@echo off
cd /d "%~dp0"
if exist "%~dp0.venv\Scripts\pythonw.exe" (
  start "" "%~dp0.venv\Scripts\pythonw.exe" "%~dp0run.py"
) else (
  echo Environnement introuvable. Lancez d'abord Installer.bat
  pause
)
