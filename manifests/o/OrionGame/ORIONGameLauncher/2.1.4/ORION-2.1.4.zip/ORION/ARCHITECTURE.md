# Architecture d'ORION

Document destiné aux évolutions futures : où se trouve chaque chose, et où
brancher du neuf sans toucher à l'existant.

---

## Principe général

Le noyau ne connaît aucune plateforme, aucun jeu et aucun format de fichier.
Il connaît quatre **contrats** (classes de base) et un **registre** qui va
chercher toutes les implémentations disponibles :

```
                       ┌──────────────────┐
                       │  core/registry   │   découverte automatique
                       └────────┬─────────┘
          ┌─────────────┬───────┴────────┬──────────────┐
          ▼             ▼                ▼              ▼
      Scanner     ArtworkProvider   TweakWriter     Recettes JSON
   (une source   (une source de    (un format de   (un jeu ou un
    de jeux)      jaquettes)        réglages)       moteur précis)
```

Le registre importe tous les modules de `orion/plugins/<famille>/`, **puis**
ceux de `%LOCALAPPDATA%\ORION\plugins\<famille>\`, collecte les sous-classes
concrètes, les instancie et écarte celles qui répondent `available() == False`.
Une classe est ignorée si elle déclare `abstract = True` **dans son propre
corps** ou si son attribut `id` est vide.

---

## Arborescence

```
ORION/
├─ run.py                     lanceur
├─ Installer.bat              environnement + raccourci
├─ ORION.bat                  démarrage normal
├─ ORION-console.bat          démarrage avec console (diagnostic)
└─ orion/
   ├─ version.py              nom et version
   ├─ app.py                  amorçage Qt
   ├─ library.py              service de bibliothèque (orchestre les scanners)
   ├─ artwork.py              service de visuels (orchestre les fournisseurs)
   │
   ├─ core/
   │  ├─ paths.py             TOUS les emplacements disque
   │  ├─ config.py            configuration JSON + valeurs par défaut
   │  ├─ logging_setup.py     journal tournant
   │  ├─ events.py            bus d'événements (publication/abonnement)
   │  ├─ registry.py          découverte des plugins
   │  ├─ models.py            Game, Display, HardwareInfo, TweakOp, plan…
   │  ├─ store.py             persistance bibliothèque + statistiques
   │  ├─ tasks.py             exécution en arrière-plan
   │  └─ winutil.py           registre Windows, VDF, PowerShell
   │
   ├─ plugins/
   │  ├─ scanners/            steam, epic, gog, ubisoft, ea, battlenet,
   │  │                       xbox, folders, registry_uninstall
   │  ├─ artwork/             steam_cdn, steamgriddb, exe_icon
   │  └─ tweaks/              ini, registry, cfg, json + recipes/*.json
   │
   ├─ hardware/
   │  ├─ probe.py             synthèse machine
   │  ├─ gpu.py               identification GPU + capacités
   │  └─ displays.py          énumération et application des modes d'écran
   │
   ├─ optimizer/
   │  ├─ choix.py             les deux cartes : « Votre écran » et « Mon choix »
   │  ├─ recommande.py        le plus beau niveau qui tient l'objectif d'images/s
   │  ├─ profiles.py          profil unique « recommande » → réglages chiffrés
   │  ├─ securite.py          jamais pendant une partie, jamais une clé inventée
   │  ├─ apprentissage.py     jeu inconnu : fichier appris, clés sûres seulement
   │  ├─ engine.py            recette + profil + matériel → plan applicable
   │  ├─ discovery.py         localisation des configs (projet Unreal, Unity…)
   │  ├─ backup.py            sauvegarde / restauration
   │  └─ advisor.py           règles de conseil
   │
   ├─ launch/launcher.py      lancement, suivi de session, restauration écran
   │
   └─ ui/
      ├─ theme.py             palette + feuille de style (source unique)
      ├─ icon.py              icône dessinée à la volée
      ├─ main_window.py       assemblage et orchestration
      ├─ views/               library, detail, hardware, advice, settings
      └─ widgets/             game_card, sidebar, profile_card, advice_card,
                              flow_layout
```

---

## Les six points d'extension

### 1. Ajouter une source de jeux

Fichier : `%LOCALAPPDATA%\ORION\plugins\scanners\mon_store.py`

```python
from orion.plugins.scanners.base import Scanner, detect_engine, pick_main_exe

class MonStoreScanner(Scanner):
    id = "monstore"          # obligatoire, unique
    label = "Mon Store"
    priority = 40            # ordre : plus grand = passe avant (arbitre les doublons)

    def available(self) -> bool:
        return Path(r"C:\MonStore").is_dir()

    def scan(self) -> list:
        jeux = []
        for dossier in Path(r"C:\MonStore\Games").iterdir():
            jeux.append(self._mk(
                title=dossier.name,
                source_id=dossier.name,
                install_dir=str(dossier),
                executable=pick_main_exe(dossier, dossier.name),
                engine=detect_engine(dossier),
            ))
        return jeux
```

`_mk()` remplit `source` automatiquement. `scan()` ne doit jamais lever
d'exception : une erreur est journalisée et la source est simplement ignorée.

### 2. Ajouter une source de jaquettes

Fichier : `%LOCALAPPDATA%\ORION\plugins\artwork\ma_source.py`

```python
from orion.plugins.artwork.base import ArtworkProvider, cache_path, download

class MaSourceProvider(ArtworkProvider):
    id = "ma_source"
    priority = 80            # essayé avant ceux de priorité inférieure

    def fetch(self, game, want: set) -> dict:
        if "cover" not in want:
            return {}
        dest = cache_path(game, "cover", "jpg")
        url = f"https://exemple.test/{game.title}.jpg"
        return {"cover": str(dest)} if download(url, dest) else {}
```

Le service interroge les fournisseurs par priorité décroissante jusqu'à ce que
chaque type de visuel (`cover`, `hero`, `logo`, `icon`) soit trouvé.

### 3. Apprendre à ORION à régler un jeu

Fichier : `%LOCALAPPDATA%\ORION\recipes\mon_jeu.json`

```json
{
  "id": "mon_jeu",
  "name": "Mon Jeu",
  "match": { "appid": ["1091500"] },
  "confidence": "exact",
  "derive": {
    "mode_ecran": { "from": "window_mode",
                    "map": { "fullscreen": "0", "borderless": "1" } }
  },
  "targets": [
    {
      "format": "json",
      "paths": ["%USERPROFILE%/Saved Games/MonJeu/settings.json"],
      "entries": [
        { "key": "video.width",  "value": "{resolution_w}", "label": "Largeur" },
        { "key": "video.mode",   "value": "{mode_ecran}",   "label": "Affichage" },
        { "key": "video.fpsCap", "value": "{fps_cap}",      "label": "Limite d'images" }
      ]
    }
  ],
  "advice": ["Fermer le jeu avant d'appliquer les réglages."]
}
```

**Sélection de la recette** (score le plus élevé) :

| `match` | Score | Signification |
|---|---|---|
| `appid` | 100 | identifiant Steam exact |
| `title` | 90 | titre exact (comparaison normalisée) |
| `title_contains` | 70 | le titre contient l'un des fragments |
| `engine` | 50 | moteur détecté (`unreal`, `unity`, `source`…) |
| `{}` (vide) | 1 | recette de repli |

**Variables disponibles dans `paths` et `value`** — réglages calculés :
`resolution_w`, `resolution_h`, `refresh`, `fps_cap`, `window_mode`, `vsync`,
`quality`, `q_textures`, `q_shadows`, `q_effects`, `q_postprocess`,
`q_view_distance`, `q_foliage`, `q_antialiasing`, `q_reflections`, `upscaler`,
`frame_gen`, `ray_tracing`, `reflex`, `hdr`, `fx_motion_blur`,
`fx_depth_of_field`, `fx_bloom`, `fx_film_grain`, `fx_chromatic`, `fx_vignette` ;
— et chemins : `install_dir`, `exe_dir`, `title`, `appid`, `documents`,
`saved_games`, `localappdata`, `appdata`, plus `ue_project` (Unreal) ou
`unity_company` / `unity_product` (Unity).

`derive` sert à traduire une valeur abstraite en valeur attendue par le jeu.
Les `paths` acceptent `%VARIABLES%` et les jokers `*`. Options d'une cible :
`all_matching` (traiter tous les chemins trouvés, pas seulement le premier) et
`create_if_missing` (créer le fichier s'il n'existe pas).

Une variable non résolue fait sauter la ligne concernée : une recette
incomplète dégrade proprement au lieu d'écrire n'importe quoi.

### 4. Ajouter une source de prix

Fichier : `%LOCALAPPDATA%\ORION\plugins\market\ma_boutique.py`

```python
from orion.plugins.market.base import MarketProvider, Offer

class MaBoutiqueProvider(MarketProvider):
    id = "ma_boutique"
    priority = 60

    def fetch(self, game, info) -> None:
        info.offers.append(Offer(shop="Ma Boutique", price=12.99,
                                 cut=50, url="https://…", drm="Steam"))
        info.offers.sort(key=lambda o: o.price)
        info.best = info.offers[0]
```

Le service fusionne ce que chaque fournisseur sait remplir dans la même
`MarketInfo` (note, prix courant, meilleure offre, plus bas historique).

### 5. Ajouter une source de jeux gratuits

Fichier : `%LOCALAPPDATA%\ORION\plugins\freebies\ma_source.py`

```python
from orion.plugins.freebies.base import (Freebie, FreebieSource, fetch_json,
                                         A_GARDER, DEFINITIF, TEMPORAIRE)

class MaSource(FreebieSource):
    id = "ma_source"
    label = "Ma source"
    priority = 55

    def fetch(self) -> list[Freebie]:
        # fetch_json lève SourceUnavailable si le service ne répond pas
        for offre in fetch_json("https://…/api", {"pays": "FR"}):
            ...
        return [Freebie(key="ma_source:42", title="Un Jeu",
                        shop="Ma Boutique", url="https://…",
                        kind=A_GARDER, ends_at=1790000000, worth=19.99)]
```

**Une source ne retourne jamais une liste vide pour masquer une panne.**
Une liste vide signifie « aucune offre en ce moment », et ORION retire alors
de la page les offres que cette source annonçait. Un service injoignable
doit lever `SourceUnavailable` — ce que `fetch_json` fait pour vous : la
source est signalée en erreur et ce qu'elle avait déjà trouvé reste
affiché. Une coupure réseau ne doit jamais vider la page.

La `kind` est la seule information réellement engageante :

| Valeur | Sens | Conséquence dans ORION |
|---|---|---|
| `DEFINITIF` | gratuit pour toujours | rien n'expire |
| `A_GARDER` | offre limitée, jeu acquis à vie | seule la fenêtre de récupération expire |
| `TEMPORAIRE` | jouable pendant l'offre seulement | à l'échéance, ORION propose la désinstallation puis la page d'achat |

Le service fusionne les doublons entre sources, complète chaque jeu depuis
la fiche Steam (solo, multijoueur, coopération, multiplateforme, note,
plateformes) et télécharge le visuel. Une source n'a donc que sa propre
API à connaître.

### 6. Ajouter un format de réglages

Fichier : `%LOCALAPPDATA%\ORION\plugins\tweaks\mon_format.py`

```python
from orion.plugins.tweaks.base import TweakWriter

class MonFormatWriter(TweakWriter):
    id = "mon_format"        # à utiliser dans "format" des recettes

    def read(self, op):      # valeur actuelle, ou None
        ...

    def write(self, ops):    # -> (nombre écrit, message)
        ...
```

---

## Ajouter un fournisseur d'IA

Dans `orion/ai/client.py`, ajouter une entrée à `PROVIDERS` (libellé, modèle
par défaut, page où obtenir la clé, tutoriel) et une méthode
`_ask_<id>(prompt, model, max_tokens)` qui renvoie `(succès, texte)`.
L'interface des Réglages se met à jour toute seule.

Les usages de l'IA sont dans `orion/ai/tasks.py` : chacun est une fonction
autonome qui construit son contexte et renvoie du texte. En ajouter un ne
demande qu'un bouton de plus dans la fiche.

## Les graphismes d'un jeu

Depuis la 2.1.0, il n'y a plus qu'un profil, `recommande`
(`orion/optimizer/profiles.py`, `ORDER`) ; les anciens (Esport, Détente,
Photoréaliste) sont dans `ANCIENS`, pour relire leurs mesures. Le choix du
joueur passe par les deux cartes de `choix.py` (« Votre écran », « Mon
choix »), et `compute_settings()` reste le seul endroit où une intention
devient des valeurs chiffrées — c'est là qu'on affine l'optimisation.

## Ajouter une règle de conseil

Dans `orion/optimizer/advisor.py`, décorer une fonction avec `@system_rule`
(machine) ou `@game_rule` (jeu) et renvoyer une liste d'`Advice`. Elle est
prise en compte immédiatement.

## Ajouter une page

Créer la vue dans `orion/ui/views/`, l'ajouter à `PAGES` dans
`orion/ui/widgets/sidebar.py` et au `QStackedWidget` de `main_window.py`,
dans le même ordre que la constante `PAGES` de ce module.

---

## Bus d'événements

`orion/core/events.py` publie : `scan.started`, `scan.source_done`,
`scan.finished`, `art.updated`, `game.launched`, `game.exited`,
`display.changed`, `tweaks.applied`, `ui.notify`.

```python
from orion.core.events import BUS, GAME_EXITED
BUS.on(GAME_EXITED, lambda uid, seconds, **_: print(uid, seconds))
```

C'est le point d'accroche naturel pour une future intégration : overlay,
présence Discord, statistiques, synchronisation de sauvegardes, appel à une
API d'IA pour des conseils personnalisés.

---

## Règles de conception à respecter

1. **Aucune écriture sans sauvegarde ni confirmation.** `OptimizationPlan`
   expose toujours la valeur actuelle avant la valeur visée.
2. **Aucun chemin en dur hors de `core/paths.py`.**
3. **Un plugin ne doit jamais faire tomber l'application** : `available()` et
   `scan()` / `fetch()` échouent en silence, l'erreur part au journal.
4. **Le réseau est facultatif** : sans connexion, la détection, l'analyse
   matérielle, l'optimisation et le lancement fonctionnent toujours.
5. **Le thème ne se définit qu'une fois**, dans `ui/theme.py`.

---

## Journaux et données

| Quoi | Où |
|---|---|
| Configuration | `%LOCALAPPDATA%\ORION\config.json` |
| Bibliothèque | `%LOCALAPPDATA%\ORION\library.json` |
| Sessions de jeu | `%LOCALAPPDATA%\ORION\stats.json` |
| Cache de jaquettes | `%LOCALAPPDATA%\ORION\cache\art\` |
| Sauvegardes | `%LOCALAPPDATA%\ORION\backups\<jeu>\<date>\` |
| Journal | `%LOCALAPPDATA%\ORION\logs\orion.log` |
| Extensions | `%LOCALAPPDATA%\ORION\plugins\{scanners,artwork,market,tweaks,freebies}\` |
| Recettes | `%LOCALAPPDATA%\ORION\recipes\` |
| Jeux gratuits suivis | `%LOCALAPPDATA%\ORION\gratuits.json` |

La variable d'environnement `ORION_DATA_DIR` déplace l'ensemble ailleurs
(utile pour tester sans toucher aux données réelles).
