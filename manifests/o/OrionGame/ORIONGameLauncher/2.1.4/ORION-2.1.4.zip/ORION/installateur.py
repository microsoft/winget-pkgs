"""Point d'entree de l'executable d'installation d'ORION.

L'application compilee voyage a l'interieur de cet executable : PyInstaller
la depose dans un dossier temporaire au lancement, et la fenetre ci-dessous
la recopie a l'emplacement choisi par l'utilisateur.
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from orion.deploiement.interface import main   # noqa: E402

if __name__ == "__main__":
    raise SystemExit(main())
