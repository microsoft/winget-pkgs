@echo off
chcp 65001 >nul
title ORION - paquet Microsoft Store
cd /d "%~dp0"
echo.
echo   ===========================================
echo    ORION - paquet pour le Microsoft Store
echo   ===========================================
echo.
if not exist "dist\ORION\ORION.exe" (
  echo   Compilez d'abord ORION ^(COMPILER-SEUL.bat^), puis relancez ce fichier.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" outils\msix\construire.py
echo.
pause
