"""Diagnostic des sources de detection.

Lance chaque scanner isolement et ecrit un rapport lisible a cote de ce
fichier. Utile quand une plateforme installee ne remonte aucun jeu.

    .venv\\Scripts\\python.exe outils_diagnostic.py
"""
from __future__ import annotations

import sys
import time
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from orion.core import registry                      # noqa: E402
from orion.core.winutil import HKCU, HKLM, reg_subkeys, reg_value  # noqa: E402
from orion.plugins.scanners._filters import is_game  # noqa: E402
from orion.plugins.scanners.base import Scanner      # noqa: E402

OUT = Path(__file__).resolve().parent / "_diagnostic_orion.txt"
lines: list[str] = []


def w(text: str = "") -> None:
    lines.append(text)
    print(text)


w("DIAGNOSTIC ORION - " + time.strftime("%d/%m/%Y %H:%M"))
w("=" * 70)

w("\n--- CLES DE REGISTRE BRUTES ---")
checks = [
    ("GOG (64)", HKLM, r"SOFTWARE\GOG.com\Games"),
    ("GOG (32)", HKLM, r"SOFTWARE\WOW6432Node\GOG.com\Games"),
    ("Ubisoft", HKLM, r"SOFTWARE\WOW6432Node\Ubisoft\Launcher\Installs"),
    ("EA Games", HKLM, r"SOFTWARE\WOW6432Node\EA Games"),
    ("Origin Games", HKLM, r"SOFTWARE\WOW6432Node\Origin Games"),
    ("Steam (HKCU)", HKCU, r"Software\Valve\Steam"),
]
for label, root, path in checks:
    subs = reg_subkeys(root, path)
    w(f"{label:16s} {len(subs):3d} sous-cle(s)  {subs[:8]}")

w("\n  Detail GOG :")
for base in (r"SOFTWARE\GOG.com\Games", r"SOFTWARE\WOW6432Node\GOG.com\Games"):
    for sub in reg_subkeys(HKLM, base):
        name = reg_value(HKLM, f"{base}\\{sub}", "gameName")
        path = reg_value(HKLM, f"{base}\\{sub}", "path")
        exists = Path(str(path)).is_dir() if path else False
        w(f"    {sub:12s} {str(name)[:36]:36s} dossier present={exists}  {path}")

w("\n  Detail Ubisoft :")
base = r"SOFTWARE\WOW6432Node\Ubisoft\Launcher\Installs"
for sub in reg_subkeys(HKLM, base):
    path = reg_value(HKLM, f"{base}\\{sub}", "InstallDir")
    exists = Path(str(path).replace("/", "\\")).is_dir() if path else False
    w(f"    {sub:12s} dossier present={exists}  {path}")

w("\n  Detail Battle.net (liste des programmes) :")
for base in (r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
             r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"):
    for sub in reg_subkeys(HKLM, base):
        if sub.lower().startswith(("battle.net", "blizzard", "world of warcraft")):
            name = reg_value(HKLM, f"{base}\\{sub}", "DisplayName")
            loc = reg_value(HKLM, f"{base}\\{sub}", "InstallLocation")
            w(f"    {sub[:30]:30s} {str(name)[:30]:30s} {loc}")

w("\n--- SCANNERS ---")
scanners = registry.discover(Scanner, "orion.plugins.scanners", "scanners")
for sc in scanners:
    try:
        dispo = sc.available()
    except Exception:
        w(f"\n[{sc.id}] available() a leve une exception :")
        w(traceback.format_exc())
        continue
    if not dispo:
        w(f"\n[{sc.id:10s}] {sc.label} : INACTIF (plateforme non detectee)")
        continue
    t0 = time.time()
    try:
        games = sc.scan() or []
    except Exception:
        w(f"\n[{sc.id:10s}] {sc.label} : ERREUR")
        w(traceback.format_exc())
        continue
    kept = [g for g in games if is_game(g.title)]
    w(f"\n[{sc.id:10s}] {sc.label} : {len(games)} trouve(s), "
      f"{len(kept)} retenu(s) en {time.time() - t0:.1f}s")
    for g in games[:40]:
        flag = "   " if is_game(g.title) else "[x]"
        w(f"    {flag} {g.title[:44]:44s} {g.install_dir[:60]}")
    if len(games) > 40:
        w(f"    ... et {len(games) - 40} autres")

w("\n--- MOTEURS DETECTES ---")
from orion.core.store import LibraryStore          # noqa: E402
from orion.plugins.scanners.base import detect_engine  # noqa: E402

store = LibraryStore()
for g in sorted(store.all(True), key=lambda x: x.title.lower()):
    moteur = detect_engine(Path(g.install_dir)) if g.install_dir else ""
    w(f"  {g.title[:38]:38s} moteur={moteur or '-':10s} {g.install_dir}")
    if not moteur and g.install_dir:
        try:
            entries = sorted(p.name + ("/" if p.is_dir() else "")
                             for p in Path(g.install_dir).iterdir())
            w(f"      contenu : {entries[:18]}")
            for sub in Path(g.install_dir).iterdir():
                if sub.is_dir():
                    try:
                        w(f"      {sub.name}/ : "
                          f"{sorted(x.name for x in sub.iterdir())[:12]}")
                    except Exception:
                        pass
        except Exception as exc:
            w(f"      (illisible : {exc})")

# --------------------------------------------------------------------------
# Jeux gratuits : chaque source est interrogee isolement, pour voir laquelle
# repond et ce qu'elle annonce reellement.
# --------------------------------------------------------------------------
w("")
w("=" * 70)
w("SOURCES DE JEUX GRATUITS")
w("=" * 70)

try:
    from orion.plugins.freebies.base import FreebieSource

    sources = registry.discover(FreebieSource, "orion.plugins.freebies",
                                "freebies")
    if not sources:
        w("  aucune source chargee")
    for source in sources:
        start = time.time()
        try:
            found = source.fetch() or []
        except Exception:
            w(f"  {source.label:34s} ECHEC")
            w("      " + traceback.format_exc().strip().splitlines()[-1])
            continue
        w(f"  {source.label:34s} {len(found):3d} offre(s)   "
          f"({time.time() - start:.1f} s)")
        for fb in found[:12]:
            w(f"      {fb.title[:34]:34s} {fb.kind_label[:22]:22s} "
              f"{fb.shop[:18]:18s} {fb.deadline_label}")
        if len(found) > 12:
            w(f"      ... et {len(found) - 12} autre(s)")
except Exception:
    w("  diagnostic des jeux gratuits impossible")
    w(traceback.format_exc())

OUT.write_text("\n".join(lines), "utf-8")
print(f"\nRapport ecrit dans {OUT}")
