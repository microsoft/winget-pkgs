@echo off
title ORION - mode diagnostic
cd /d "%~dp0"
if exist "%~dp0.venv\Scripts\python.exe" (
  "%~dp0.venv\Scripts\python.exe" "%~dp0run.py"
) else (
  echo Environnement introuvable. Lancez d'abord Installer.bat
)
pause
