"""Meilleurs reglages par carte graphique, pour les pages de jeux (12 octobre 2026).

Les recherches qui amenent deja des visiteurs (Search Console : « parametres
monster hunter wilds », « parametres mh wilds ») demandent QUOI regler, pas
seulement quelle carte acheter. ORION le sait : c'est son profil
« Recommande ». Ce module le fait tourner sans PC, carte par carte et
definition par definition, avec exactement le code de l'application
(`orion.optimizer.recommande.recommander`) :

* le niveau de details le plus beau qui tient 60 images par seconde ;
* la super-resolution en mode Qualite (ou plus) quand elle permet de monter
  d'un niveau : DLSS sur une GeForce RTX, XeSS sur une Intel Arc, FSR sur les
  autres cartes ;
* sinon le plus haut palier tenable (50, 40 ou 30 i/s), ou « trop juste ».

Ce n'est jamais une mesure : la base est l'estimation prudente de la page
(configuration de l'editeur). Les pages le disent.

Pour les jeux dont ORION connait le menu (recette exacte dont les valeurs
sont des mots du jeu : Cyberpunk 2077, Elden Ring), `menu_du_jeu` rend aussi
chaque option telle qu'ORION l'ecrit, niveau par niveau.
"""
from __future__ import annotations

import html as _html
import json
import re
from dataclasses import dataclass, replace
from functools import lru_cache
from pathlib import Path

from orion.core.models import Display, DisplayMode, GPUInfo, HardwareInfo
from orion.hardware.gpu import classify
from orion.optimizer import recommande
from orion.optimizer.engine import _apply_derive, _fmt
from orion.optimizer.profiles import PROFILES, compute_settings

RACINE = Path(__file__).resolve().parent.parent.parent

#: cartes de la section : les plus repandues, de l'entree au haut de gamme
#: (cles de gen_jeux.CARTES)
CARTES_CONSEIL = ("rtx 5070", "rtx 4070", "rx 7800 xt", "rtx 4060 ti", "rtx 3070", "arc b580",
                  "rtx 4060", "rx 7600", "rtx 3060", "rx 6600", "gtx 1660 super")
#: objectif : 60 images par seconde, l'ecran le plus courant
CIBLE = 60


@dataclass(frozen=True)
class Conseil:
    niveau: str            # basse | moyenne | haute (jamais ultra sans mesure)
    mode: str              # off | quality | balanced | performance
    famille: str           # dlss | fsr | xess | ""
    fps: tuple[int, int] | None
    palier: int            # images par seconde tenues (60, ou un palier plus bas)
    atteint: bool          # 60 i/s tenues
    #: le jeu ne se lance pas sur cette carte (ray tracing materiel exige)
    bloque: bool = False

    @property
    def trop_juste(self) -> bool:
        return self.palier < 30 or self.fps is None


def materiel(nom_carte: str, vram_go: float, largeur: int, hauteur: int) -> tuple[HardwareInfo, Display]:
    """Un PC fictif : cette carte, 64 Go de memoire et un processeur qui ne
    bride pas (comme le tableau d'estimation de la page), un ecran 60 Hz."""
    fabricant, gamme, capacites = classify(nom_carte)
    gpu = GPUInfo(name=nom_carte, vendor=fabricant, vram_mb=int(vram_go * 1024), tier=gamme,
                  features=list(capacites))
    mode = DisplayMode(largeur, hauteur, CIBLE)
    ecran = Display(device="site", primary=True, current=mode, native=mode,
                    max_refresh_at_native=CIBLE, modes=[mode])
    return HardwareInfo(ram_gb=64, gpus=[gpu], displays=[ecran]), ecran


def conseiller(exig, nom_carte: str, vram_go: float, largeur: int, hauteur: int) -> Conseil | None:
    """Ce que le profil « Recommande » choisirait ; None si le jeu n'est pas estimable."""
    from orion.puissance.estimation import Machine, blocage
    if blocage(exig, Machine(gpu_nom=nom_carte)):
        return Conseil("basse", "off", "", None, 0, False, bloque=True)
    hw, ecran = materiel(nom_carte, vram_go, largeur, hauteur)
    r = recommande.recommander(None, hw, ecran, capacites=["upscaler"], runs={}, exig=exig,
                               communaute=[], refresh=CIBLE, cible=CIBLE, sr=None)
    if r.source != "estime":
        return None
    return Conseil(r.niveau, r.mode if r.famille else "off", r.famille if r.mode != "off" else "",
                   tuple(r.fps) if r.fps else None, int(r.palier or 0), bool(r.atteint))


# --------------------------------------------------------------------------
# Le menu du jeu, option par option (recettes exactes seulement)
# --------------------------------------------------------------------------

#: options qui ne dependent pas du niveau ou ne se lisent pas dans un menu
HORS_TABLEAU = re.compile(r"definition|largeur|hauteur|frequence|mode d'affichage|plein ecran|"
                          r"sans bordure|synchro|limite|dlss|fsr|xess|super-resolution|"
                          r"niveau \(|personnalise|ray|reconstruction|generation", re.I)
#: une valeur lisible dans le menu du jeu : des mots, pas un code de fichier
MOT = re.compile(r"[A-Za-z][A-Za-z ]+")


@lru_cache(maxsize=None)
def _recettes() -> tuple[dict, ...]:
    dossier = RACINE / "orion" / "plugins" / "tweaks" / "recipes"
    return tuple(json.loads(p.read_text(encoding="utf-8")) for p in sorted(dossier.glob("*.json")))


def _simple(t: str) -> str:
    return re.sub(r"[^a-z0-9]", "", t.lower())


def recette_exacte(appid: str, titre: str) -> dict | None:
    """La recette ecrite pour CE jeu (pas celle d'un moteur)."""
    for r in _recettes():
        if r.get("confidence") != "exact":
            continue
        m = r.get("match") or {}
        if appid and str(appid) in {str(a) for a in m.get("appid", [])}:
            return r
        if _simple(titre) in {_simple(t) for t in m.get("title", [])}:
            return r
    return None


def _reglages(niveau: int) -> dict:
    """Les reglages abstraits d'ORION pour un niveau, sur une carte qui ne
    force rien (gamme haute, 8 Go de memoire video), en 1080p."""
    hw, ecran = materiel("GeForce RTX 4070", 8, 1920, 1080)
    profil = replace(PROFILES["recommande"], id="site", quality=niveau)
    return compute_settings(profil, hw, ecran, None, [])


def menu_du_jeu(appid: str, titre: str) -> list[tuple[str, list[str]]]:
    """[(option, [valeur en Bas, Moyens, Eleves])] telles qu'ORION les ecrit
    dans le jeu ; vide si ORION n'a pas de recette exacte aux valeurs lisibles."""
    r = recette_exacte(appid, titre)
    if r is None:
        return []
    par_niveau = []
    for q in (0, 1, 2):
        s = _reglages(q)
        ctx = dict(s)
        ctx.update(_apply_derive(r.get("derive") or {}, s))
        par_niveau.append(ctx)
    lignes: list[tuple[str, list[str]]] = []
    vus: set[str] = set()
    for cible in r.get("targets") or []:
        for entree in cible.get("entries") or []:
            libelle = str(entree.get("label") or "")
            gabarit = str(entree.get("value") or "")
            if not libelle or libelle in vus or HORS_TABLEAU.search(libelle) or "{" not in gabarit:
                continue
            valeurs = [_fmt(gabarit, ctx) for ctx in par_niveau]
            if any("{" in v or not MOT.fullmatch(v) for v in valeurs):
                continue
            vus.add(libelle)
            lignes.append((libelle, valeurs))
    # un tableau de deux lignes n'apprend rien : on ne le montre pas
    return lignes if len(lignes) >= 4 else []


@lru_cache(maxsize=None)
def _langue(code: str) -> dict:
    d = json.loads((RACINE / "orion" / "langues" / f"{code}.json").read_text(encoding="utf-8"))
    return d.get("exact", {})


def libelle(texte: str, code: str = "fr") -> str:
    """Le libelle tel que l'application l'affiche (accents en francais)."""
    return _langue(code).get(texte, texte)


# --------------------------------------------------------------------------
# Rendu dans les pages (francais et anglais)
# --------------------------------------------------------------------------

NIVEAUX_TXT = {"fr": {"haute": "Élevés", "moyenne": "Moyens", "basse": "Bas"},
               "en": {"haute": "High", "moyenne": "Medium", "basse": "Low"}}
MODES_TXT = {"fr": {"quality": "Qualité", "balanced": "Équilibré", "performance": "Performance"},
             "en": {"quality": "Quality", "balanced": "Balanced", "performance": "Performance"}}
FAMILLES_TXT = {"dlss": "DLSS", "fsr": "FSR", "xess": "XeSS"}
#: valeurs du fichier du jeu, dites comme dans un menu
VALEURS_TXT = {"fr": {"Low": "Bas", "Medium": "Moyen", "High": "Élevé", "Ultra": "Ultra", "Max": "Maximum",
                      "Off": "Désactivé", "On": "Activé", "Psycho": "Psycho"},
               "en": {"Max": "Maximum"}}
CLASSES = {"haute": "ok", "moyenne": "mi", "basse": "bas"}


def _e(t) -> str:
    return _html.escape(str(t), quote=True)


#: au-dela, l'application affiche « plus de 300 » (recommande.PLAFOND_FPS) :
#: une estimation ne dit rien de serieux sur 1 500 images par seconde
PLAFOND = recommande.PLAFOND_FPS


def fourchette(bas: int, haut: int, langue: str, forme: str = "court") -> str:
    """La fourchette d'images par seconde comme dans l'application.

    court : « 72–99 i/s », « plus de 300 i/s », « plus de 240 i/s » ;
    long  : « entre 72 et 99 images par seconde », « plus de 300 images par seconde »."""
    bas, haut = int(bas), int(haut)
    if langue == "fr":
        plus, unite = "plus de", ("i/s" if forme == "court" else "images par seconde")
    else:
        plus, unite = "over", ("fps" if forme == "court" else "frames per second")
    if bas >= PLAFOND:
        return f"{plus} {PLAFOND} {unite}"
    if haut >= PLAFOND:
        return f"{plus} {bas} {unite}"
    if bas >= haut:                      # jeu bloque a sa limite (Elden Ring : 60)
        return f"{haut} {unite}"
    if forme == "court":
        return f"{bas}–{haut} {unite}"
    return (f"entre {bas} et {haut} {unite}" if langue == "fr" else f"between {bas} and {haut} {unite}")


def reglage_txt(k: Conseil, langue: str) -> str:
    """« Élevés + DLSS Qualité »."""
    t = NIVEAUX_TXT[langue][k.niveau]
    if k.famille and k.mode != "off":
        t += f" + {FAMILLES_TXT[k.famille]} {MODES_TXT[langue][k.mode]}"
    return t


def _cellule(k: Conseil | None, langue: str) -> str:
    if k is not None and k.bloque:
        return ('<td class="non"><b>Ne se lance pas</b><span class="mono">ray tracing exigé</span></td>'
                if langue == "fr" else
                '<td class="non"><b>Won\'t launch</b><span class="mono">needs ray tracing</span></td>')
    if k is None or k.trop_juste or k.niveau not in CLASSES:
        return ('<td class="non"><b>Trop juste</b><span class="mono">moins de 30 i/s</span></td>' if langue == "fr"
                else '<td class="non"><b>Too weak</b><span class="mono">under 30 fps</span></td>')
    if not k.atteint:
        sous = (f"limité à {k.palier} i/s" if langue == "fr" else f"capped at {k.palier} fps")
        return f'<td class="juste"><b>{_e(reglage_txt(k, langue))}</b><span class="mono">{sous}</span></td>'
    return (f'<td class="{CLASSES[k.niveau]}"><b>{_e(reglage_txt(k, langue))}</b>'
            f'<span class="mono">{fourchette(*k.fps, langue)}</span></td>')


def conseils_du_jeu(exig, cartes: list[tuple[str, str, float]], definitions) -> dict:
    """{(cle de carte, definition): Conseil | None} pour les cartes de la section."""
    par_cle = {c: (n, v) for c, n, v in cartes}
    sortie = {}
    for cle in CARTES_CONSEIL:
        nom, vram = par_cle[cle]
        for _, d, _px in definitions:
            largeur, hauteur = (int(x) for x in d.split("x"))
            sortie[(cle, d)] = conseiller(exig, nom, vram, largeur, hauteur)
    return sortie


def faq(nom: str, conseils: dict, definitions, langue: str) -> tuple[str, str] | None:
    k = conseils.get(("rtx 4060", definitions[0][1]))
    if langue == "fr":
        q = f"Quels paramètres graphiques pour {nom} avec une RTX 4060 ?"
        if k is None or k.trop_juste:
            r = (f"Une GeForce RTX 4060 est trop juste pour {nom} en 1080p d'après notre estimation "
                 f"prudente : moins de 30 images par seconde, même avec les réglages au plus bas.")
        elif not k.atteint:
            r = (f"En 1080p, le profil « Recommandé » d'ORION choisirait les réglages "
                 f"{_minuscule(reglage_txt(k, 'fr'))}, avec une limite à {k.palier} images par seconde "
                 f"pour garder un rythme régulier.")
        else:
            r = (f"Pour 60 images par seconde en 1080p, le profil « Recommandé » d'ORION choisirait les "
                 f"réglages {_minuscule(reglage_txt(k, 'fr'))} : {fourchette(*k.fps, 'fr', 'long')} "
                 f"d'après notre estimation prudente.")
        return q, r
    q = f"What are the best graphics settings for {nom} on an RTX 4060?"
    if k is None or k.trop_juste:
        r = (f"A GeForce RTX 4060 is too weak for {nom} at 1080p according to our conservative estimate: "
             f"under 30 frames per second, even on the lowest settings.")
    elif not k.atteint:
        r = (f"At 1080p, ORION's “Recommended” profile would pick {reglage_txt(k, 'en')} settings, capped "
             f"at {k.palier} frames per second for steady pacing.")
    else:
        r = (f"For 60 frames per second at 1080p, ORION's “Recommended” profile would pick "
             f"{reglage_txt(k, 'en')} settings: {fourchette(*k.fps, 'en', 'long')} "
             f"according to our conservative estimate.")
    return q, r


def _de(nom: str) -> str:
    """« d'Elden Ring », « de Cyberpunk 2077 » (meme regle que gen_jeux.de)."""
    import unicodedata
    return ("d'" if unicodedata.normalize("NFD", nom[:1]).lower()[:1] in "aeiou" else "de ") + nom


def _minuscule(t: str) -> str:
    """« Élevés + DLSS Qualité » -> « élevés avec DLSS en mode Qualité »."""
    if " + " not in t:
        return t.lower()
    niveau, sr = t.split(" + ", 1)
    famille, mode = sr.split(" ", 1)
    return f"{niveau.lower()} avec {famille} en mode {mode}"


def section(nom: str, appid: str, conseils: dict, cartes, definitions, langue: str) -> str:
    """La section « Meilleurs réglages » d'une page de jeu."""
    par_cle = {c: n for c, n, _v in cartes}
    defs = [(lib, d) for lib, d, _px in definitions]
    lignes = []
    for cle in CARTES_CONSEIL:
        tds = "".join(_cellule(conseils.get((cle, d)), langue) for _lib, d in defs)
        lignes.append(f'<tr><th scope="row">{_e(par_cle[cle])}</th>{tds}</tr>')
    tetes = "".join(f'<th scope="col">{_e(lib)}</th>' for lib, _d in defs)
    menu = menu_du_jeu(appid, nom)
    if langue == "fr":
        tete = f"""  <section class="bloc" id="reglages">
    <p class="eyebrow">Meilleurs réglages</p>
    <h2>Meilleurs paramètres graphiques {_e(_de(nom))} selon votre carte</h2>
    <p>Le réglage que choisirait le profil « Recommandé » d'ORION pour jouer à 60 images par seconde :
      le niveau de détails le plus beau qui reste fluide, avec la super-résolution quand elle permet de
      monter d'un cran (DLSS sur les GeForce RTX, XeSS sur les Intel Arc, FSR sur les autres cartes).
      Si {_e(nom)} ne propose pas cette option, retenez le niveau du tableau précédent.</p>"""
        col = "Carte graphique"
        apres = """    <p>À ces niveaux, ORION garde les textures en élevé dès 8 Go de mémoire vidéo (elles prennent de
      la mémoire, presque pas d'images), cale la limite d'images sur l'objectif pour un rythme régulier,
      coupe le flou de mouvement et le grain de l'image, et laisse la synchronisation verticale
      désactivée. C'est une estimation prudente, pas une mesure : dans ORION, la première partie
      mesurée corrige le réglage.</p>"""
        menu_tete = (f"    <h3>Option par option dans {_e(nom)}</h3>\n"
                     "    <p>Ce qu'ORION écrit dans les réglages du jeu pour chaque niveau (textures : avec 8 Go de "
                     "mémoire vidéo ou plus).</p>")
        menu_cols = ("Option", "Bas", "Moyens", "Élevés")
    else:
        tete = f"""  <section class="bloc" id="settings">
    <p class="eyebrow">Best settings</p>
    <h2>Best graphics settings for {_e(nom)} by graphics card</h2>
    <p>The setting ORION's “Recommended” profile would pick to play at 60 frames per second: the
      best-looking detail level that stays smooth, with upscaling when it lets you go one step up (DLSS
      on GeForce RTX, XeSS on Intel Arc, FSR on other cards). If {_e(nom)} doesn't offer it, use the
      level from the previous table.</p>"""
        col = "Graphics card"
        apres = """    <p>At these levels, ORION keeps textures on high from 8 GB of video memory (they cost memory,
      hardly any frames), sets the frame cap on the target for steady pacing, turns off motion blur and
      film grain, and leaves vertical sync off. This is a conservative estimate, not a measurement: in
      ORION, the first measured session corrects the setting.</p>"""
        menu_tete = (f"    <h3>Option by option in {_e(nom)}</h3>\n"
                     "    <p>What ORION writes into the game's settings for each level (textures: with 8 GB of "
                     "video memory or more).</p>")
        menu_cols = ("Option", "Low", "Medium", "High")
    menu_html = ""
    if menu:
        lignes_menu = "".join(
            f'<tr><th scope="row">{_e(libelle(lib, langue))}</th>'
            + "".join(f"<td>{_e(VALEURS_TXT[langue].get(v, v))}</td>" for v in vals) + "</tr>"
            for lib, vals in menu)
        cols = "".join(f'<th scope="col">{_e(c)}</th>' for c in menu_cols)
        menu_html = f"""
{menu_tete}
    <div class="defile">
      <table class="perf menu">
        <thead><tr>{cols}</tr></thead>
        <tbody>
{lignes_menu}
        </tbody>
      </table>
    </div>"""
    return f"""{tete}
    <div class="defile">
      <table class="perf">
        <thead><tr><th scope="col">{col}</th>{tetes}</tr></thead>
        <tbody>
{chr(10).join(lignes)}
        </tbody>
      </table>
    </div>
{apres}{menu_html}
  </section>

"""
