"""Page d'accueil du site d'ORION (refonte 2.0).

Assemble `index.html` : l'en-tete et les contenus de fond repris de la page
en ligne (donnees structurees, historique des versions, questions, tableau
technique), le style (`style.css`) et le corps (`corps.html`) de ce dossier,
et le journal de la version lu dans `CHANGELOG.md`. Refait aussi les mentions
legales et la page introuvable avec le meme style, et copie les polices :
le site les sert lui-meme, il n'appelle aucun service de polices.

    python construire.py <site d'origine> <site de sortie> <CHANGELOG.md>

Les captures sont attendues dans `<site de sortie>/img/2-0/` (voir
`outils/captures_site.py`). A la publication, dans l'ordre :

    python accueil/construire.py site-en-ligne site-neuf ../../CHANGELOG.md
    python gen_sorties.py site-neuf
    python gen_jeux.py site-neuf jeux-steam.json gamesplanet-fr.json fiches-jeux.json
    python essai_accueil.py site-neuf ; python essai_sorties.py site-neuf x.png

Les pages de jeux et le calendrier reprennent la feuille de style de
l'accueil : ils doivent etre regeneres apres lui.
"""
import html, re, shutil, sys
from pathlib import Path

ICI = Path(__file__).parent
origine, sortie, journal = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
ancien = (origine / "index.html").read_text(encoding="utf-8")


def section(ident: str) -> str:
    a = ancien.find(f'id="{ident}"')
    a = ancien.rfind("<section", 0, a)
    return ancien[a:ancien.find("</section>", a)]


# -- en-tete : tout ce qui precede les polices, sans le fond du jour ----------
tete = ancien[:ancien.find('<link rel="preconnect"')]
tete = re.sub(r"<script>/\* Fond du jour.*?</script>\n", "", tete, flags=re.S)
assert "Fond du jour" not in tete and "fonts.g" not in tete
tete = tete.replace('<meta name="theme-color" content="#070B10">',
                    '<meta name="theme-color" content="#0C1122">')
titre = "ORION Game Launcher — le launcher de jeux PC qui lit votre machine"
desc = ("ORION, launcher de jeux PC gratuit pour Windows : toute votre bibliothèque Steam, Epic, "
        "GOG, Ubisoft, EA et Battle.net réunie, ce que votre PC peut faire jeu par jeu, les bons "
        "réglages écrits à votre place et le meilleur prix sur des sites sûrs.")
tete = re.sub(r"<title>.*?</title>", f"<title>{titre}</title>", tete)
tete = re.sub(r'(<meta name="description" content=")[^"]*', lambda m: m.group(1) + desc, tete)
tete = re.sub(r'(<meta property="og:title" content=")[^"]*',
              lambda m: m.group(1) + "ORION — votre PC peut plus que vous ne croyez", tete)
for vieux, neuf in (("img/bibliotheque.jpg", "img/2-0/bibliotheque.jpg"),
                    ("img/fiche-jeu.jpg", "img/2-0/ma-machine.jpg"),
                    ("img/boutique.jpg", "img/2-0/boutique.jpg")):
    tete = tete.replace("https://orion-launcher.com/" + vieux, "https://orion-launcher.com/" + neuf)
tete = tete.replace('"Analyse de la configuration et goulots d\'étranglement"',
                    '"Ce que votre PC peut faire, jeu par jeu, et ce qui le freine"')
tete += '<link rel="preload" href="/polices/bricolage.woff2" as="font" type="font/woff2" crossorigin>\n'
tete += '<link rel="preload" href="/polices/figtree.woff2" as="font" type="font/woff2" crossorigin>\n'

version = re.search(r'"softwareVersion": "([^"]+)"', ancien).group(1)
taille = re.search(r'"fileSize": "([^"]+)"', ancien).group(1)
empreinte = re.search(r'<p class="hash">([0-9a-f]{64})</p>', ancien).group(1)

# -- contenus repris tels quels ------------------------------------------------
j = section("journal")
historique = "\n".join("      " + d for d in re.findall(r"<details>.*?</details>", j, re.S))
tout = "\n".join(f"          <dt>{t.strip()}</dt><dd>{' '.join(p.split())}</dd>"
                 for t, p in re.findall(r"<h3>(.*?)</h3>\s*<p>(.*?)</p>", j, re.S))
faq = section("faq")
questions = re.findall(r"<details[^>]*>.*?</details>", faq, re.S)
questions = [re.sub(r"<details open>", "<details>", " ".join(q.split())) for q in questions]
# ORION n'est plus presente comme une version d'essai
finale = next((i for i, q in enumerate(questions) if "Est-ce une version finale" in q), None)
if finale is not None:
    questions[finale] = (
        "<details><summary>ORION évolue-t-il encore ?</summary> <p>Oui. Les fonctions présentées "
        "ici marchent, et des mises à jour sortent régulièrement : la section Nouveautés montre "
        "ce qui vient d'arriver, et ORION se met à jour tout seul.</p></details>")
assert not any("version d'essai" in q for q in questions)
faq_html = "\n".join("      " + q for q in questions)
table = re.search(r"<table>.*?</table>", section("technique"), re.S).group(0)
table = table.replace("IsThereAnyDeal <i>(clé gratuite, facultative)</i>",
                      "IsThereAnyDeal <i>(par le service d'ORION, sans clé)</i>")

# -- le journal de la version, depuis CHANGELOG.md -----------------------------
texte = journal.read_text(encoding="utf-8")
bloc = texte[texte.find(f"## {version}"):]
bloc = bloc[:bloc.find("\n## ", 5)]
lignes = []
for ligne in bloc.splitlines():
    if not ligne.startswith("- "):
        continue
    corps = html.escape(ligne[2:].strip(), quote=False)
    if " : " in corps[:28]:
        rubrique, reste = corps.split(" : ", 1)
        corps = f"<b>{rubrique}.</b> {reste[0].upper()}{reste[1:]}"
    lignes.append(f"          <li>{corps}</li>")
assert len(lignes) > 20 and historique and tout and len(questions) >= 10

corps = (ICI / "corps.html").read_text(encoding="utf-8")
from PIL import Image
fiche = Image.open(sortie / "img" / "2-0" / "boutique-fiche.jpg").size
for cle, valeur in {"VERSION_COURTE": ".".join(version.split(".")[:2]), "VERSION": version,
                    "TAILLE": taille, "EMPREINTE": empreinte, "TABLE_TECH": table,
                    "JOURNAL": "\n".join(lignes), "TOUT": tout, "HISTORIQUE": historique,
                    "FAQ": faq_html, "FICHE_L": str(fiche[0]), "FICHE_H": str(fiche[1])}.items():
    corps = corps.replace("{{" + cle + "}}", valeur)
assert "{{" not in corps, re.findall(r"\{\{\w+\}\}", corps)


def typographie(page: str) -> str:
    """Apostrophes courbes et espaces insecables du francais, dans le texte
    seulement (ni les balises, ni les scripts, ni le code)."""
    def texte(m):
        t = m.group(1).replace("'", "\u2019")
        t = t.replace("« ", "«\u00a0").replace(" »", "\u00a0»")
        t = re.sub(r" ([:])", "\u00a0\\1", t)
        t = re.sub(r" ([;!?])", "\u202f\\1", t)
        return ">" + t + "<"
    morceaux = re.split(r"(<script.*?</script>|<style.*?</style>|<code>.*?</code>)", page, flags=re.S)
    return "".join(m if m.startswith(("<script", "<style", "<code")) else
                   re.sub(r">([^<]+)<", texte, m) for m in morceaux)


style = (ICI / "style.css").read_text(encoding="utf-8")
page = tete + "<style>\n" + style + "</style>\n</head>\n" + typographie(corps)
sortie.mkdir(parents=True, exist_ok=True)
(sortie / "index.html").write_text(page, encoding="utf-8")

# -- polices, mentions legales, page introuvable -------------------------------
(sortie / "polices").mkdir(exist_ok=True)
for police in (ICI / "polices").glob("*.woff2"):
    shutil.copy2(police, sortie / "polices" / police.name)
annexes = (ICI / "annexes.css").read_text(encoding="utf-8")
POLICES_TIERS = re.compile(r'(<link rel="preconnect" href="https://fonts\.g[^>]*>\n)*'
                           r'<link rel="stylesheet" href="https://fonts\.googleapis\.com/[^"]*">\n')
for nom in ("mentions-legales.html", "404.html"):
    t = (origine / nom).read_text(encoding="utf-8")
    t = POLICES_TIERS.sub("", t)
    t = re.sub(r"<style>.*?</style>", lambda m: "<style>\n" + annexes + "</style>", t, count=1, flags=re.S)
    t = t.replace('content="#070B10"', 'content="#0C1122"')
    if nom.startswith("mentions"):
        t = t.replace("<h2>Logiciel en version d'essai</h2>", "<h2>Logiciel fourni en l'état</h2>")
        t = t.replace("gratuitement, en l'état, pendant sa phase d'essai.", "gratuitement, en l'état.")
    phrase = ("<p>Les polices de caractères et les images sont servies par le site lui-même : "
              "la page n'appelle aucun service de polices tiers.</p>")
    if nom.startswith("mentions") and phrase not in t:
        repere = "sans identifier les visiteurs.</p>"
        assert repere in t
        t = t.replace(repere, repere + "\n" + phrase, 1)
        import datetime
        mois = ("janvier février mars avril mai juin juillet août septembre octobre "
                "novembre décembre").split()
        auj = datetime.date.today()
        t = re.sub(r"Dernière mise à jour : [^<.]*\.",
                   f"Dernière mise à jour : {auj.day} {mois[auj.month - 1]} {auj.year}.", t, count=1)
    # 2.0.1 : le bilan de fluidite anonyme, decrit a la suite du pays et de la region
    FLUIDITE = ("<p>Bilan de fluidité (à partir d'ORION 2.0.1). À la fermeture, si vous avez dit oui\n"
                "  au partage, ORION envoie un bilan anonyme de la session : combien de fois l'affichage\n"
                "  s'est figé plus de 0,2 s, le nom de la fonction d'ORION en cause (par exemple\n"
                "  « boutique_view._rendre »), le temps de démarrage et le nombre d'erreurs écrites dans\n"
                "  son journal. Jamais le jeu, jamais un chemin de fichier, jamais un texte libre. Le\n"
                "  service additionne ces bilans par jour et par version, sans identifiant : il ne sait\n"
                "  pas de quel PC vient un accrochage. La question posée dans ORION l'annonce ; elle est\n"
                "  reposée une fois à ceux qui avaient répondu avant ce changement.</p>")
    if nom.startswith("mentions") and "Bilan de fluidité (à partir" not in t:
        repere = "reposée une fois à ceux qui avaient répondu avant ce changement.</p>"
        assert repere in t
        t = t.replace(repere, repere + "\n" + FLUIDITE, 1)
    # 2.1.0 : les niveaux appris par l'exemple, proposes sous le meme oui
    RECETTES = ("<p>Niveaux appris (à partir d'ORION 2.1.0). Quand vous apprenez à ORION les niveaux\n"
                "  d'un jeu (vous choisissez quelques niveaux dans son menu), et si vous avez dit oui au\n"
                "  partage, ORION propose la recette obtenue aux autres joueurs : des noms et des valeurs\n"
                "  de réglages du jeu, des chemins ramenés à %LOCALAPPDATA% ou %APPDATA%. Jamais un nom de\n"
                "  compte, un identifiant ou une date : ORION ne retient que des réglages qui changent avec\n"
                "  le niveau. Le service les garde pour vérification avant de les publier.</p>")
    if nom.startswith("mentions") and "Niveaux appris (à partir" not in t and "Bilan de fluidité (à partir" in t:
        t = t.replace(FLUIDITE, FLUIDITE + "\n" + RECETTES, 1)
    assert "fonts.g" not in t
    (sortie / nom).write_text(t, encoding="utf-8")
print("index.html", len(page), "octets ;", len(lignes), "points au journal ;", len(questions), "questions")
