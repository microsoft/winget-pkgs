import sys, json, functools, http.server, threading
from playwright.sync_api import sync_playwright
site = sys.argv[1]
class H(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_GET(self):
        if self.path.split("?")[0] == "/sorties": self.path = "/sorties.html"
        return super().do_GET()
srv = http.server.ThreadingHTTPServer(("127.0.0.1", 8797), functools.partial(H, directory=site))
threading.Thread(target=srv.serve_forever, daemon=True).start()
with sync_playwright() as p:
    nav = p.chromium.launch(); page = nav.new_page(viewport={"width": 1280, "height": 900})
    err = []; page.on("pageerror", lambda e: err.append(str(e)))
    page.goto("http://127.0.0.1:8797/sorties"); page.wait_for_selector(".mois")
    tout = page.locator(".sortie:visible").count(); mois = page.locator(".mois:visible").count()
    print("titre", len(page.title()), page.title())
    d = page.get_attribute('meta[name=description]', 'content'); print("description", len(d), d)
    for b in page.locator(".puce").all():
        b.click(); pl = b.get_attribute("data-p")
        n = page.locator(".sortie:visible").count()
        attendu = page.locator(".sortie").evaluate_all("(l, p) => l.filter(c => !p || c.dataset.p.split(' ').includes(p)).length", pl)
        vides = page.locator(".mois:visible").evaluate_all("l => l.filter(m => !m.querySelector('.sortie:not([hidden])')).length")
        print(repr(pl), n, attendu, "mois visibles", page.locator(".mois:visible").count(), "liens", page.locator(".sauts a:visible").count())
        assert n == attendu and vides == 0 and b.get_attribute("aria-pressed") == "true"
    page.locator(".puce").first.click()
    assert page.locator(".sortie:visible").count() == tout and page.locator(".mois:visible").count() == mois
    ld = [json.loads(x) for x in page.locator('script[type="application/ld+json"]').all_inner_texts()]
    print([x["@type"] for x in ld], len(ld[0]["itemListElement"]))
    page.locator(".filtres").scroll_into_view_if_needed(); page.mouse.wheel(0, -120)
    page.screenshot(path=sys.argv[2]); assert not err, err
    page.set_viewport_size({"width": 390, "height": 800}); page.wait_for_timeout(200)
    assert page.evaluate("document.documentElement.scrollWidth <= innerWidth"), "deborde sur telephone"
    nav.close()
print("sorties ok")
