"""Pages « pilotes par modele » (2.0.2) : /pilotes, /pilotes/dell/<modele>,
/pilotes/hp/<modele>.

« Mettre a jour les pilotes d'un Dell XPS 15 9530 » est une recherche
frequente ; la bonne reponse est le catalogue du constructeur pour ce modele,
celui qu'ORION lit. Chaque page porte ce qui est verifiable dans les index
publics des constructeurs (identifiants du modele, nom de son catalogue,
date de sa derniere mise a jour chez Dell, versions de Windows pour
lesquelles HP publie encore), la marche a suivre, et ce qu'ORION en fait.
Cinquante bonnes pages, pas mille vides.

Usage : python gen_pilotes.py <dossier du site> <platformList.xml> <CatalogIndexPC.xml>
"""
from __future__ import annotations

import datetime as dt
import re
import sys
import xml.etree.ElementTree as ET
from html import escape as e
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gen_jeux import SITE, date_fr, gabarit, slug  # noqa: E402

#: modeles Dell retenus (prefixes de noms, tels que l'index Dell les ecrit)
DELL = ("Alienware m16", "Alienware m18", "Alienware x14", "Alienware x15", "Alienware x16", "Alienware x17",
        "Alienware m15 R6", "Alienware m15 R7", "Alienware m17 R5", "Alienware Aurora R15", "Alienware Aurora R16",
        "Dell G15 5530", "Dell G15 5520", "Dell G16 7630", "Dell G16 7620", "G15 5515", "G15 5511",
        "XPS 15 9530", "XPS 15 9520", "XPS 17 9730", "XPS 17 9720", "XPS 13 9340", "XPS 8960", "XPS 8950",
        "Inspiron 15 3530", "Inspiron 15 3520", "Inspiron 16 5630", "Inspiron 16 7630", "Inspiron 14 5440",
        "Latitude 7440", "Latitude 5540")
#: plateformes HP retenues (HP Image Assistant ne couvre que les machines professionnelles)
HP = ("HP EliteDesk 800 G4", "HP EliteDesk 800 G5", "HP EliteDesk 800 G6", "HP EliteDesk 880 G4",
      "HP EliteBook 840 14 inch G9", "HP EliteBook 840 14 inch G10", "HP EliteBook 840 14 inch G11",
      "HP ProBook 450 G8", "HP ProBook 450 15.6 inch G9", "HP ProBook 450 15.6 inch G10",
      "HP ZBook Fury 16 G9", "HP ZBook Fury 16 G10", "HP ZBook Fury 16 G11",
      "HP ZBook Power 15.6 inch G9", "HP ZBook Power 15.6 inch G10", "HP ZBook Power 16 inch G11",
      "HP ZBook Studio 16 inch G9", "HP ZBook Studio 16 inch G10", "HP Z2 Tower G9", "HP Elite Tower 800 G9")

PAGE_DELL = "https://www.dell.com/support/home/fr-fr?app=drivers"
PAGE_HP = "https://support.hp.com/fr-fr/drivers"


def lire_dell(chemin) -> list[dict]:
    root = ET.parse(chemin).getroot()
    ns = "{openmanage/cm/dm}"
    par_nom: dict[str, dict] = {}
    for g in root.iter(ns + "GroupManifest"):
        mi = g.find(ns + "ManifestInformation")
        if mi is None:
            continue
        for m in g.iter(ns + "Model"):
            nom = (m.findtext(ns + "Display") or "").strip()
            if not any(nom == p or nom.startswith(p + " ") or nom.startswith(p + ",") for p in DELL):
                continue
            d = par_nom.setdefault(nom, {"nom": nom, "ids": [], "catalogues": set(), "maj": ""})
            d["ids"].append(m.get("systemID"))
            d["catalogues"].add(Path(mi.get("path") or "").stem)
            d["maj"] = max(d["maj"], mi.get("version") or "")
    out = []
    for d in par_nom.values():
        d["ids"] = sorted(set(d["ids"]))
        d["catalogues"] = sorted(d["catalogues"])
        d["constructeur"] = "Dell"
        d["slug"] = slug(d["nom"].replace("Dell ", ""))
        out.append(d)
    return sorted(out, key=lambda d: d["nom"])


def lire_hp(chemin) -> list[dict]:
    root = ET.parse(chemin).getroot()
    par_nom: dict[str, dict] = {}
    for pl in root.iter("Platform"):
        nom = (pl.findtext("ProductName") or "").strip()
        if not any(nom.startswith(p) for p in HP):
            continue
        d = par_nom.setdefault(nom, {"nom": nom, "ids": [], "w11": set(), "w10": set(), "maj": ""})
        d["ids"].append((pl.findtext("SystemID") or "").upper())
        for o in pl.iter("OS"):
            (d["w11"] if o.findtext("IsWindows11") == "true" else d["w10"]).add(o.findtext("OSReleaseIdFilename") or "")
        d["maj"] = max(d["maj"], pl.get("DateLastModified") or "")
    out = []
    for d in par_nom.values():
        d["ids"] = sorted(set(d["ids"]))
        d["w11"], d["w10"] = sorted(d["w11"]), sorted(d["w10"])
        d["constructeur"] = "HP"
        d["slug"] = slug(d["nom"].replace("HP ", "").replace(" PC", "").replace(" inch", ""))
        out.append(d)
    return sorted(out, key=lambda d: d["nom"])


def _date_dell(v: str) -> str:
    m = re.match(r"(\d{4})\.(\d{2})\.(\d{2})", v or "")
    return date_fr(dt.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))) if m else ""


def _date_hp(v: str) -> str:
    m = re.match(r"(\d{4})(\d{2})(\d{2})", v or "")
    return date_fr(dt.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))) if m else ""


COMMUN = """
<h2>Les quatre pilotes qui comptent pour jouer</h2>
<p><b>La carte graphique</b> d'abord : c'est elle qui traduit les images du jeu, et chaque version apporte des
optimisations pour les sorties récentes. Sur un portable, le pilote du constructeur et celui de NVIDIA ou AMD
coexistent ; le plus récent des deux l'emporte, sauf consigne contraire du constructeur.
<b>Le réseau</b> ensuite (latence, pertes de paquets, déconnexions en ligne dépendent aussi de lui),
<b>l'audio</b> (son positionnel, craquements) et <b>le chipset</b> (gestion d'énergie, stabilité PCIe et USB,
donc les images par seconde minimales).</p>

<h2>La méthode en trois étapes</h2>
<ol>
  <li><b>Le catalogue du constructeur pour ce modèle</b> : les versions qu'il contient ont été validées pour cette
  machine précise, avec ses particularités (alimentation, écran, touches). C'est la source de Dell Command Update,
  HP Image Assistant et Lenovo System Update, et c'est celle qu'ORION lit.</li>
  <li><b>Windows Update, mises à jour facultatives</b> : les fabricants de puces y publient leurs pilotes génériques.
  Paramètres → Windows Update → Options avancées → Mises à jour facultatives.</li>
  <li><b>NVIDIA ou AMD pour la carte graphique dédiée</b>, quand le constructeur n'a rien de plus récent : le pilote
  « Game Ready » ou « Adrenalin » de la série de la carte.</li>
</ol>

<h2>Ce que fait ORION</h2>
<p>ORION lit l'inventaire de votre PC puce par puce (identifiants matériels, pas noms traduits), reconnaît le
modèle, télécharge le catalogue du constructeur une fois tous les trois jours et compare : « réseau 12.19.2.45
installée, 12.19.2.62 publiée le 18 juillet 2024 pour ce modèle », avec la page officielle et le fichier. Pour une
GeForce, il connaît la dernière version de la série ; pour le reste, il regarde Windows Update. Il ne dit
« version disponible » que quand une source le prouve, et n'installe jamais rien lui-même : vous gardez la main.
Gratuit, sans compte, rien n'est envoyé sans votre accord.</p>
<p><a class="btn" href="/#installer">Télécharger ORION</a></p>
"""


def ajuste_texte(variantes, limite):
    """La premiere formulation qui tient dans `limite` caracteres, sinon la plus courte."""
    variantes = [v for v in variantes if v]
    return next((v for v in variantes if len(v) <= limite), min(variantes, key=len))


def page_modele(d: dict, style: str, auj: dt.date) -> str:
    c = d["constructeur"]
    chemin = f"/pilotes/{c.lower()}/{d['slug']}"
    titre = f"Mettre à jour les pilotes d'un {c} {d['nom'].replace('Dell ', '').replace('HP ', '')}"
    if c == "Dell":
        ids = ", ".join(d["ids"])
        faits = (f"<li><b>Identifiant du modèle chez Dell</b> (System ID, celui que Windows donne comme numéro "
                 f"de produit) : {e(ids)}.</li>"
                 f"<li><b>Catalogue Dell du modèle</b> : {', '.join(e(x) for x in d['catalogues'])}, "
                 f"mis à jour le {e(_date_dell(d['maj']))} dans l'index public de Dell.</li>"
                 f"<li><b>Page officielle</b> : <a href=\"{PAGE_DELL}\" rel=\"noopener\">support Dell, pilotes et "
                 f"téléchargements</a> — entrez le numéro de série (Service Tag) ou le nom du modèle.</li>")
        desc = (f"Pilotes {d['nom']} : où les prendre (catalogue Dell du modèle, mis à jour le {_date_dell(d['maj'])}), "
                "lesquels comptent pour jouer, et comment ORION compare vos versions à celles validées par Dell.")
    else:
        w11 = ", ".join(d["w11"]) or "aucune"
        w10 = d["w10"][-1] if d["w10"] else ""
        faits = (f"<li><b>Plateforme HP</b> (le modèle de la carte mère, tel que Windows le lit) : {e(', '.join(d['ids']))}.</li>"
                 f"<li><b>HP publie un fichier de référence pour</b> Windows 11 {e(w11)}"
                 f"{' et Windows 10 ' + e(w10) if w10 else ''} (liste HP du {e(_date_hp(d['maj']))}). "
                 "Sur une version de Windows plus récente, les pilotes de la dernière version publiée s'appliquent.</li>"
                 f"<li><b>Page officielle</b> : <a href=\"{PAGE_HP}\" rel=\"noopener\">support HP, pilotes</a> — "
                 "avec le numéro de produit (étiquette sous la machine, ou dans ORION, page Ma machine).</li>")
        desc = (f"Pilotes {d['nom']} : où les prendre (fichier de référence HP de la plateforme, Windows 11 {w11}), "
                "lesquels comptent pour jouer, et comment ORION compare vos versions à celles validées par HP.")
    corps = f"""
<section>
  <p class="fil"><a href="/pilotes">Pilotes par modèle</a> · {e(c)}</p>
  <h1>{e(titre)}</h1>
  <p class="chapo">Sur un PC de marque, le bon pilote réseau, audio, chipset ou graphique est celui que le constructeur
  a validé pour ce modèle, pas la version générique du fabricant de la puce. Voici où il se trouve, et comment
  savoir en une minute lesquels sont en retard.</p>
  <h2>En bref</h2>
  <ul>{faits}</ul>
  {COMMUN}
  <p><small>Les identifiants et dates de cette page viennent des index publics {e(c)} (lus le {e(date_fr(auj))}).
  Les marques citées appartiennent à leurs propriétaires ; ORION n'est pas affilié à {e(c)}.</small></p>
</section>
"""
    ld = [{"@context": "https://schema.org", "@type": "TechArticle", "headline": titre, "inLanguage": "fr",
           "about": {"@type": "Product", "name": d["nom"], "brand": c},
           "dateModified": auj.isoformat(), "publisher": {"@type": "Organization", "name": "ORION Game Launcher"}}]
    # 11 octobre : titres de 69 a 96 caracteres et descriptions de 187 a 256 sur
    # les modeles HP et Alienware ; Google les coupait. Le H1 garde la phrase entiere.
    court = d["nom"].replace("Dell ", "").replace("HP ", "")
    court = re.sub(r"\s+(Notebook|Desktop|Mobile Workstation|Workstation Desktop|Workstation) PC$|\s+PC$", "", court)
    court = court.replace(" inch ", " ")
    onglet = ajuste_texte([f"{titre} — ORION", f"Pilotes {c} {court} : où les mettre à jour",
                           f"Pilotes {c} {court} : mise à jour", f"Pilotes {court}"], 60)
    desc = ajuste_texte([desc,
                         f"Pilotes {court} : où prendre ceux validés par {c} pour ce modèle, lesquels comptent pour "
                         f"jouer, et comment ORION repère ceux qui sont en retard.",
                         f"Pilotes {court} : où prendre ceux validés par {c}, et lesquels comptent pour jouer.",
                         f"Pilotes {court} validés par {c} : où les prendre, et lesquels comptent pour jouer."], 155)
    return gabarit(style, onglet, desc, chemin, ld, corps)


def page_index(dell: list[dict], hp: list[dict], style: str, auj: dt.date) -> str:
    def liste(l, c):
        return "\n".join(f'<li><a href="/pilotes/{c}/{e(d["slug"])}">{e(d["nom"])}</a></li>' for d in l)
    corps = f"""
<section>
  <h1>Mettre à jour les pilotes de son PC, modèle par modèle</h1>
  <p class="chapo">Pour un PC Dell, Lenovo ou HP, le bon pilote est celui du catalogue du constructeur pour ce
  modèle : ORION le lit et compare. Les pages ci-dessous disent où chaque catalogue se trouve et ce qu'il contient.</p>
  <h2>Dell et Alienware</h2>
  <ul class="liste-courte">{liste(dell, "dell")}</ul>
  <h2>HP</h2>
  <ul class="liste-courte">{liste(hp, "hp")}</ul>
  {COMMUN}
</section>
"""
    ld = [{"@context": "https://schema.org", "@type": "CollectionPage", "name": "Pilotes par modèle",
           "inLanguage": "fr", "dateModified": auj.isoformat()}]
    return gabarit(style, "Pilotes par modèle : Dell, Alienware, HP — ORION",
                   "Où prendre les pilotes validés pour votre modèle de PC, lesquels comptent pour jouer, et comment "
                   "ORION compare vos versions à celles du constructeur.", "/pilotes", ld, corps)


def main(dossier, plateformes_hp, index_dell) -> int:
    dossier = Path(dossier)
    accueil = (dossier / "index.html").read_text(encoding="utf-8")
    style = re.search(r"<style>(.*?)</style>", accueil, re.S).group(1)
    auj = dt.date.today()
    dell, hp = lire_dell(index_dell), lire_hp(plateformes_hp)
    cible = dossier / "pilotes"
    for sous in ("dell", "hp"):
        (cible / sous).mkdir(parents=True, exist_ok=True)
        for ancien in (cible / sous).glob("*.html"):
            ancien.unlink()
    for d in dell + hp:
        (cible / d["constructeur"].lower() / f"{d['slug']}.html").write_text(page_modele(d, style, auj), encoding="utf-8")
    (dossier / "pilotes.html").write_text(page_index(dell, hp, style, auj), encoding="utf-8")
    plan = dossier / "sitemap.xml"
    x = plan.read_text(encoding="utf-8")
    x = re.sub(r"  <url>\n    <loc>" + re.escape(SITE) + r"/pilotes[^<]*</loc>.*?</url>\n", "", x, flags=re.S)
    bloc = "".join(f"  <url>\n    <loc>{SITE}{c}</loc>\n    <lastmod>{auj.isoformat()}</lastmod>\n"
                   f"    <changefreq>monthly</changefreq>\n    <priority>{p}</priority>\n  </url>\n"
                   for c, p in [("/pilotes", "0.8")]
                   + [(f"/pilotes/{d['constructeur'].lower()}/{d['slug']}", "0.6") for d in dell + hp])
    x = x.replace("  <url>\n    <loc>" + SITE + "/mentions-legales",
                  bloc + "  <url>\n    <loc>" + SITE + "/mentions-legales")
    plan.write_text(x, encoding="utf-8")
    print(f"{len(dell)} pages Dell, {len(hp)} pages HP, index /pilotes")
    return len(dell) + len(hp)


if __name__ == "__main__":
    main(*sys.argv[1:4])
