"""Genere les visuels d'ORION : les fonds du jour et les bannieres de saison.

Usage : python generer.py fonds <dossier> [nombre] [premier]
        python generer.py saisons <dossier> [premiere annee] [nombre d'annees]

Tout est calcule (aucune image prise ailleurs, aucun droit a verifier) :
du bruit lisse pour les nebuleuses et les aurores, des etoiles, les traits
de constellation qui font la marque d'ORION. Chaque image vient d'un numero
(`graine`) : la meme commande redonne exactement les memes images, et un
numero de plus en donne une nouvelle.

Deux regles de lisibilite, verifiees par le script lui-meme :

* un fond reste sombre (luminance moyenne et zones claires bornees) : le
  texte pose dessus garde le meme contraste, quel que soit le jour ;
* une banniere de saison s'eteint a gauche, la ou sont le titre de la page
  et ses compteurs.
"""
from __future__ import annotations

import colorsys
import math
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter
from scipy.ndimage import gaussian_filter, zoom

NUIT = np.array([7, 10, 17], dtype=np.float32) / 255          # fond d'ORION
#: teintes des fonds (degres) : du cyan de la marque au violet, un peu d'ambre
TEINTES = [188, 200, 212, 226, 244, 262, 280, 304, 328, 168, 152, 196, 216]
#: bornes de lisibilite d'un fond (0..255)
LUMINANCE = (17.0, 29.0)
CLAIR_MAX = 120.0             # aucune zone (floue) plus claire que cela
FONDS = (1920, 1080)
BANNIERE = (2560, 128)


def teinte(deg: float, sat: float = 0.75, val: float = 1.0) -> np.ndarray:
    return np.array(colorsys.hsv_to_rgb((deg % 360) / 360, sat, val), dtype=np.float32)


def bruit(rng, h: int, w: int, grain: float, octaves: int = 4, etire=(1.0, 1.0)) -> np.ndarray:
    """Bruit lisse 0..1 : des aleas flous de plus en plus fins, additionnes.
    Calcule en petit puis agrandi (le resultat est flou de toute facon)."""
    ph, pw = max(8, h // 6), max(8, w // 6)
    total, poids = np.zeros((ph, pw), np.float32), 0.0
    for o in range(octaves):
        s = grain / 6 / (2 ** o)
        champ = gaussian_filter(rng.standard_normal((ph, pw)).astype(np.float32),
                                (max(0.6, s * etire[0]), max(0.6, s * etire[1])), mode="wrap")
        champ /= (champ.std() + 1e-6)
        a = 0.55 ** o
        total += a * champ
        poids += a
    total /= poids
    total = zoom(total, (h / ph, w / pw), order=3)[:h, :w]
    lo, hi = np.percentile(total, 2), np.percentile(total, 98)
    return np.clip((total - lo) / (hi - lo + 1e-6), 0, 1)


def grille(h: int, w: int):
    y, x = np.mgrid[0:h, 0:w].astype(np.float32)
    return x / w, y / h


def halo(h: int, w: int, cx: float, cy: float, rayon: float, puissance: float = 2.0) -> np.ndarray:
    x, y = grille(h, w)
    d = np.sqrt(((x - cx) * w / h) ** 2 + (y - cy) ** 2) / rayon
    return np.exp(-d ** puissance)


def etoiles(rng, h: int, w: int, nombre: int, grosses: int = 14, zone=None) -> np.ndarray:
    """Calque d'etoiles (RVB additif). `zone` : densite 0..1 par pixel."""
    champ = np.zeros((h, w, 3), np.float32)
    ys, xs = rng.integers(0, h, nombre * 3), rng.integers(0, w, nombre * 3)
    if zone is not None:
        garde = rng.random(nombre * 3) < zone[ys, xs]
        ys, xs = ys[garde][:nombre], xs[garde][:nombre]
    else:
        ys, xs = ys[:nombre], xs[:nombre]
    eclat = rng.random(len(ys)) ** 3.2 * 0.9 + 0.08
    froid = rng.random(len(ys))[:, None]
    couleur = (1 - froid) * np.array([1.0, 0.93, 0.84], np.float32) + \
        froid * np.array([0.80, 0.90, 1.0], np.float32)
    champ[ys, xs] = couleur * eclat[:, None]
    champ = gaussian_filter(champ, (0.55, 0.55, 0)) * 2.4
    # quelques etoiles plus proches, avec leur lueur
    lueur = np.zeros((h, w, 3), np.float32)
    for _ in range(grosses):
        y, x = int(rng.integers(8, h - 8)), int(rng.integers(8, w - 8))
        if zone is not None and rng.random() > zone[y, x] + 0.25:
            continue
        c = teinte(rng.choice([195, 210, 40, 0]), 0.25 if rng.random() < 0.8 else 0.5)
        lueur[y, x] = c * (0.6 + rng.random() * 0.9)
    champ += gaussian_filter(lueur, (1.1, 1.1, 0)) * 26 + gaussian_filter(lueur, (5, 5, 0)) * 120
    return champ


def constellation(rng, h: int, w: int, points: int, couleur, cadre=(0.1, 0.1, 0.9, 0.9),
                  force: float = 0.5) -> np.ndarray:
    """Etoiles reliees par des traits fins : le motif d'ORION. Rend un calque
    RVB additif (dessine deux fois plus grand puis reduit : traits nets)."""
    k = 2
    img = Image.new("L", (w * k, h * k), 0)
    d = ImageDraw.Draw(img)
    x0, y0, x1, y1 = cadre
    pts = [(rng.uniform(x0, x1) * w * k, rng.uniform(y0, y1) * h * k) for _ in range(points)]
    # chaine du plus proche voisin : une figure lisible, sans toile d'araignee
    reste, chemin = pts[1:], [pts[0]]
    while reste:
        px, py = chemin[-1]
        j = min(range(len(reste)), key=lambda i: (reste[i][0] - px) ** 2 + (reste[i][1] - py) ** 2)
        chemin.append(reste.pop(j))
    for a, b in zip(chemin, chemin[1:]):
        if rng.random() < 0.86:
            d.line([a, b], fill=int(255 * 0.42), width=k)
    if len(chemin) > 4 and rng.random() < 0.7:      # une branche, comme un vrai asterisme
        d.line([chemin[1], chemin[len(chemin) // 2]], fill=int(255 * 0.3), width=k)
    for (x, y) in chemin:
        r = rng.uniform(1.6, 3.4) * k
        d.ellipse([x - r, y - r, x + r, y + r], fill=255)
    trait = np.asarray(img.resize((w, h), Image.LANCZOS), np.float32) / 255
    lueur = gaussian_filter(trait, 3.0) * 1.6
    return (trait + lueur)[:, :, None] * np.asarray(couleur, np.float32)[None, None, :] * force


def finir(rvb: np.ndarray, rng, bornes=LUMINANCE) -> Image.Image:
    """Vignette, grain leger, puis mise aux bornes de lisibilite."""
    h, w, _ = rvb.shape
    x, y = grille(h, w)
    vignette = 1 - 0.55 * np.clip(((x - 0.5) ** 2 + (y - 0.5) ** 2) * 2.2, 0, 1)
    rvb = rvb * vignette[:, :, None]
    rvb = np.clip(rvb, 0, None)
    rvb = rvb / (1 + rvb * 0.55)                            # compression douce des hautes lumieres
    rvb = NUIT[None, None, :] * 0.85 + rvb

    def mesure(a):
        # memes poids que le controle final (`luminance`, niveaux de gris de PIL)
        lum = (a * np.array([0.299, 0.587, 0.114], np.float32)).sum(axis=2) * 255
        return float(lum.mean()), float(gaussian_filter(lum, 28).max())
    for _ in range(12):
        moyenne, clair = mesure(np.clip(rvb, 0, 1))
        if moyenne > bornes[1] or clair > CLAIR_MAX:
            rvb = NUIT[None, None, :] * 0.85 + (rvb - NUIT * 0.85) * 0.88
        elif moyenne < bornes[0]:
            rvb = NUIT[None, None, :] * 0.85 + (rvb - NUIT * 0.85) * 1.12
        else:
            break
    rvb += rng.normal(0, 0.004, rvb.shape).astype(np.float32)   # grain : pas de bandes dans les degrades
    return Image.fromarray((np.clip(rvb, 0, 1) * 255 + 0.5).astype(np.uint8), "RGB")


# ---------------------------------------------------------------------------
# Fonds du jour
# ---------------------------------------------------------------------------
STYLES = ("nebuleuse", "voie", "aurore", "constellation", "planete", "anneaux", "poussiere",
          "nebuleuse", "constellation", "voie")


def fond(graine: int, taille=FONDS) -> Image.Image:
    rng = np.random.default_rng(1000 + graine)
    w, h = taille
    style = STYLES[graine % len(STYLES)]
    t1 = TEINTES[(graine * 5 + graine // len(STYLES)) % len(TEINTES)]
    t2 = (t1 + rng.choice([-46, -28, 28, 46, 64])) % 360
    c1, c2 = teinte(t1, 0.78), teinte(t2, 0.7)
    x, y = grille(h, w)
    rvb = np.zeros((h, w, 3), np.float32)
    densite = None

    if style == "nebuleuse":
        n1 = bruit(rng, h, w, 520, 5) ** 2.3
        n2 = bruit(rng, h, w, 340, 4) ** 2.6
        voile = bruit(rng, h, w, 900, 2)
        cx, cy = rng.uniform(0.45, 0.85), rng.uniform(0.25, 0.7)
        centre = halo(h, w, cx, cy, rng.uniform(0.45, 0.7), 1.6)
        rvb += c1 * (n1 * centre * 0.95)[:, :, None] + c2 * (n2 * (0.35 + 0.65 * voile) * 0.5)[:, :, None]
        rvb *= (1 - 0.75 * bruit(rng, h, w, 260, 3) ** 3)[:, :, None]          # nuages sombres
        densite = 0.35 + 0.65 * n1
    elif style == "voie":
        angle = rng.uniform(-0.55, -0.2) if rng.random() < 0.5 else rng.uniform(0.2, 0.55)
        d = (y - 0.5) * math.cos(angle) - (x - 0.5) * math.sin(angle) * w / h + rng.uniform(-0.08, 0.08)
        bande = np.exp(-(d / rng.uniform(0.13, 0.2)) ** 2)
        grain = bruit(rng, h, w, 240, 5)
        poussiere = bruit(rng, h, w, 150, 4) ** 1.6
        rvb += c1 * (bande * (0.25 + 0.75 * grain) * 0.75)[:, :, None]
        rvb += c2 * (bande ** 3 * grain * 0.5)[:, :, None]
        rvb *= (1 - 0.8 * bande * poussiere)[:, :, None] * 1.0
        densite = 0.2 + 0.8 * bande
    elif style == "aurore":
        vert, haut = teinte(rng.choice([150, 162, 176, 190]), 0.8), teinte(rng.choice([268, 286, 310]), 0.7)
        for i in range(3):
            onde = 0.34 + 0.1 * i + 0.07 * np.sin(x * rng.uniform(4, 9) + rng.uniform(0, 6)) \
                + 0.05 * np.sin(x * rng.uniform(11, 19) + rng.uniform(0, 6))
            rideau = np.clip((y - onde + 0.3) / 0.3, 0, 1) * np.exp(-np.clip(y - onde, 0, None) / 0.05)
            fibres = 0.45 + 0.55 * bruit(rng, h, w, 60, 3, etire=(9.0, 0.35))
            rvb += vert * (rideau * fibres * 0.5)[:, :, None]
            rvb += haut * (np.clip((onde - y) / 0.3, 0, 1) * rideau * fibres * 0.45)[:, :, None]
        rvb = gaussian_filter(rvb, (5, 2, 0))
        rvb *= np.clip((0.86 - y) / 0.16, 0, 1)[:, :, None]                     # horizon sombre
        densite = np.clip(0.9 - y * 0.9, 0.05, 1)
    elif style == "constellation":
        n1 = bruit(rng, h, w, 700, 3) ** 2.2
        rvb += c1 * (n1 * halo(h, w, rng.uniform(0.55, 0.9), rng.uniform(0.2, 0.8), 0.75, 1.5) * 0.5)[:, :, None]
        for _ in range(int(rng.integers(2, 4))):
            cx, cy = rng.uniform(0.3, 0.8), rng.uniform(0.2, 0.7)
            rvb += constellation(rng, h, w, int(rng.integers(5, 9)), teinte(t1, 0.35),
                                 (cx - 0.16, cy - 0.18, cx + 0.2, cy + 0.2), 0.42)
        densite = 0.45 + 0.4 * n1
    elif style == "planete":
        cx, cy, r = rng.uniform(0.78, 1.05), rng.uniform(0.95, 1.5), rng.uniform(0.55, 0.9)
        d = np.sqrt(((x - cx) * w / h) ** 2 + (y - cy) ** 2)
        dehors = np.clip((d - r) / 0.012, 0, 1)
        atmosphere = np.exp(-np.clip(d - r, 0, None) / 0.035) * dehors
        jour = np.clip(1.25 - x - (y - 0.4) * 0.6, 0, 1)                         # eclairee par la gauche
        rvb += c1 * (atmosphere * (0.25 + 0.75 * jour) * 1.1)[:, :, None]
        rvb += c2 * (bruit(rng, h, w, 600, 3) ** 2.5 * 0.3)[:, :, None]
        surface = np.clip((r - d) / 0.25, 0, 1) * (1 - dehors)
        rvb += c1 * (np.exp(-(r - d) / 0.02) * (1 - dehors) * jour * 0.35)[:, :, None]
        rvb *= (1 - 0.35 * surface)[:, :, None]
        densite = dehors * 0.8
    elif style == "anneaux":
        cx, cy = rng.uniform(0.6, 0.85), rng.uniform(0.35, 0.65)
        rvb += c1 * (halo(h, w, cx, cy, 0.42, 1.3) * 0.55)[:, :, None]
        rvb += c2 * (bruit(rng, h, w, 500, 3) ** 2.4 * 0.3)[:, :, None]
        k = 2
        img = Image.new("L", (w * k, h * k), 0)
        d = ImageDraw.Draw(img)
        incl, aplat = rng.uniform(-28, 28), rng.uniform(0.22, 0.42)
        for i in range(int(rng.integers(4, 7))):
            a = (0.16 + 0.085 * i + rng.uniform(-0.01, 0.01)) * h * k
            calque = Image.new("L", (w * k, h * k), 0)
            ImageDraw.Draw(calque).ellipse(
                [cx * w * k - a, cy * h * k - a * aplat, cx * w * k + a, cy * h * k + a * aplat],
                outline=int(255 * rng.uniform(0.2, 0.5)), width=k)
            calque = calque.rotate(incl, center=(cx * w * k, cy * h * k), resample=Image.BICUBIC)
            img = Image.fromarray(np.maximum(np.asarray(img), np.asarray(calque)))
        del d
        traits = np.asarray(img.resize((w, h), Image.LANCZOS), np.float32) / 255
        rvb += (traits + gaussian_filter(traits, 2.5))[:, :, None] * teinte(t1, 0.4)[None, None, :] * 0.5
        densite = np.full((h, w), 0.55, np.float32)
    else:                                                       # poussiere : lumieres floues
        rvb += c1 * (bruit(rng, h, w, 800, 2) ** 2 * 0.4)[:, :, None]
        disques = np.zeros((h, w, 3), np.float32)
        for _ in range(int(rng.integers(26, 44))):
            px, py = rng.uniform(0.3, 1.0), rng.uniform(0.0, 1.0)
            r = rng.uniform(0.012, 0.05)
            d = np.sqrt(((x - px) * w / h) ** 2 + (y - py) ** 2)
            disque = np.clip((r - d) / 0.004, 0, 1) * (0.55 + 0.45 * np.clip(d / r, 0, 1) ** 3)
            disques += (c1 if rng.random() < 0.6 else c2) * (disque * rng.uniform(0.05, 0.2))[:, :, None]
        rvb += gaussian_filter(disques, (1.5, 1.5, 0))
        densite = np.full((h, w), 0.3, np.float32)

    nombre = int(rng.integers(900, 2100) * (w * h) / (1920 * 1080))
    rvb += etoiles(rng, h, w, nombre, int(rng.integers(8, 18)), densite) * 0.8
    if style in ("nebuleuse", "voie", "planete") and rng.random() < 0.7:
        cx, cy = rng.uniform(0.35, 0.8), rng.uniform(0.2, 0.65)
        rvb += constellation(rng, h, w, int(rng.integers(5, 8)), teinte(t1, 0.3),
                             (cx - 0.14, cy - 0.16, cx + 0.16, cy + 0.16), 0.3)
    return finir(rvb, rng)


# ---------------------------------------------------------------------------
# Bannieres de saison
# ---------------------------------------------------------------------------
SAISONS = ("printemps", "ete", "automne", "hiver")
K = 3          # les motifs sont dessines trois fois plus grands, puis reduits


def _feuille(d, x, y, taille, angle, couleur):
    """Feuille : deux arcs qui se rejoignent en pointe, et sa nervure."""
    pts = []
    for i in range(0, 21):
        t = i / 20
        larg = math.sin(t * math.pi) ** 0.8 * 0.34
        pts.append((t - 0.5, larg))
    contour = pts + [(px, -py) for px, py in reversed(pts)]
    ca, sa = math.cos(angle), math.sin(angle)
    d.polygon([(x + (px * ca - py * sa) * taille, y + (px * sa + py * ca) * taille)
               for px, py in contour], fill=couleur)
    d.line([(x - 0.5 * ca * taille, y - 0.5 * sa * taille), (x + 0.62 * ca * taille, y + 0.62 * sa * taille)],
           fill=couleur[:3] + (min(255, couleur[3] + 40),), width=max(1, int(taille * 0.035)))


def _flocon(d, x, y, r, angle, couleur, epais):
    for i in range(6):
        a = angle + i * math.pi / 3
        ex, ey = x + r * math.cos(a), y + r * math.sin(a)
        d.line([(x, y), (ex, ey)], fill=couleur, width=epais)
        for f in (0.45, 0.72):
            bx, by = x + r * f * math.cos(a), y + r * f * math.sin(a)
            for s in (-1, 1):
                b = a + s * math.pi / 3.2
                d.line([(bx, by), (bx + r * 0.26 * math.cos(b), by + r * 0.26 * math.sin(b))],
                       fill=couleur, width=epais)


def _petale(d, x, y, taille, angle, couleur):
    pts = []
    for i in range(0, 25):
        t = i / 24 * 2 * math.pi
        rr = (1 - math.sin(t)) * 0.5                       # goutte
        pts.append((rr * math.cos(t) * 0.62, rr * math.sin(t) + 0.5))
    ca, sa = math.cos(angle), math.sin(angle)
    d.polygon([(x + (px * ca - py * sa) * taille, y + (px * sa + py * ca) * taille) for px, py in pts],
              fill=couleur)


def _fleur(d, x, y, taille, angle, couleur, coeur):
    for i in range(5):
        _petale(d, x, y, taille, angle + i * 2 * math.pi / 5, couleur)
    r = taille * 0.16
    d.ellipse([x - r, y - r, x + r, y + r], fill=coeur)


def _semis(rng, w, h, nombre, marge=0.0):
    """Positions plus denses a droite (le titre de la page est a gauche)."""
    for _ in range(nombre):
        yield (1 - rng.random() ** 1.7 * (1 - marge)) * w, rng.uniform(-0.1, 1.1) * h


def banniere(saison: str, annee: int, taille=BANNIERE) -> Image.Image:
    rng = np.random.default_rng(annee * 10 + SAISONS.index(saison))
    w, h = taille
    x, y = grille(h, w)
    variante = (annee + SAISONS.index(saison)) % 3
    reglages = {
        "printemps": dict(t1=[142, 128, 156][variante], t2=[330, 344, 318][variante]),
        "ete":       dict(t1=[30, 24, 36][variante], t2=[190, 200, 182][variante]),
        "automne":   dict(t1=[26, 18, 34][variante], t2=[350, 8, 42][variante]),
        "hiver":     dict(t1=[200, 212, 192][variante], t2=[230, 250, 216][variante]),
    }[saison]
    c1, c2 = teinte(reglages["t1"], 0.8), teinte(reglages["t2"], 0.7)
    rvb = np.zeros((h, w, 3), np.float32)
    voile = bruit(rng, h, w, 420, 3, etire=(0.5, 3.0))
    pente = np.clip((x - 0.18) / 0.82, 0, 1) ** 1.25                       # la lumiere vient de la droite
    # une teinte de saison par-dessus le bleu nuit d'ORION, jamais un aplat
    rvb += teinte(222, 0.6)[None, None, :] * (pente * 0.07)[:, :, None]
    rvb += c1 * (pente ** 1.6 * (0.25 + 0.75 * voile) * 0.2)[:, :, None]
    rvb += c2 * (halo(h, w, rng.uniform(0.62, 0.95), rng.uniform(-0.2, 0.3), 2.2, 1.4) * 0.2)[:, :, None]

    net = Image.new("RGBA", (w * K, h * K), (0, 0, 0, 0))
    flou = Image.new("RGBA", (w * K, h * K), (0, 0, 0, 0))
    dn, df = ImageDraw.Draw(net), ImageDraw.Draw(flou)
    W, H = w * K, h * K

    def rgba(deg, sat, val, alpha):
        r, g, b = teinte(deg, sat, val)
        return (int(r * 255), int(g * 255), int(b * 255), int(alpha * 255))

    if saison == "automne":
        tons = [(30, 0.82, 1.0), (20, 0.85, 0.95), (12, 0.8, 0.85), (44, 0.8, 1.0), (4, 0.75, 0.78)]
        for px, py in _semis(rng, W, H, 30):
            t = tons[int(rng.integers(len(tons)))]
            _feuille(df, px, py, rng.uniform(26, 60) * K, rng.uniform(0, 6.28), rgba(*t, rng.uniform(0.2, 0.42)))
        for px, py in _semis(rng, W, H, 64):
            t = tons[int(rng.integers(len(tons)))]
            _feuille(dn, px, py, rng.uniform(11, 27) * K, rng.uniform(0, 6.28), rgba(*t, rng.uniform(0.5, 0.92)))
    elif saison == "hiver":
        for px, py in _semis(rng, W, H, 46):
            r = rng.uniform(6, 16) * K
            df.ellipse([px - r, py - r, px + r, py + r], fill=rgba(200, 0.25, 1.0, rng.uniform(0.1, 0.3)))
        for px, py in _semis(rng, W, H, 56):
            _flocon(dn, px, py, rng.uniform(5, 15) * K, rng.uniform(0, 1.05),
                    rgba(rng.choice([195, 205, 215]), rng.uniform(0.1, 0.35), 1.0, rng.uniform(0.45, 0.95)),
                    max(1, int(K * rng.uniform(0.9, 1.5))))
        for px, py in _semis(rng, W, H, 240):                              # neige fine
            r = rng.uniform(0.6, 1.8) * K
            dn.ellipse([px - r, py - r, px + r, py + r], fill=rgba(205, 0.12, 1.0, rng.uniform(0.3, 0.85)))
        # crete de montagnes, tres discrete, en bas a droite
        crete, alt = [], 0.72
        for i in range(0, 61):
            alt = min(0.95, max(0.42, alt + rng.uniform(-0.09, 0.09)))
            # la crete sort de terre en douceur a gauche
            crete.append(((0.42 + 0.6 * i / 60) * W, (alt + (1.02 - alt) * max(0.0, 1 - i / 9) ** 2) * H))
        dn.polygon(crete + [(W * 1.02, H), (0.42 * W, H)], fill=rgba(212, 0.45, 0.5, 0.22))
    elif saison == "printemps":
        roses = [(335, 0.4, 1.0), (345, 0.3, 1.0), (322, 0.45, 0.98), (20, 0.15, 1.0)]
        for px, py in _semis(rng, W, H, 26):
            t = roses[int(rng.integers(len(roses)))]
            _petale(df, px, py, rng.uniform(24, 52) * K, rng.uniform(0, 6.28), rgba(*t, rng.uniform(0.16, 0.34)))
        for px, py in _semis(rng, W, H, 70):
            t = roses[int(rng.integers(len(roses)))]
            _petale(dn, px, py, rng.uniform(8, 19) * K, rng.uniform(0, 6.28), rgba(*t, rng.uniform(0.5, 0.9)))
        for px, py in _semis(rng, W, H, 14, marge=0.25):
            t = roses[int(rng.integers(len(roses) - 1))]
            _fleur(dn, px, py, rng.uniform(12, 20) * K, rng.uniform(0, 6.28),
                   rgba(*t, rng.uniform(0.7, 0.95)), rgba(48, 0.7, 1.0, 0.95))
        for px, py in _semis(rng, W, H, 34):                               # jeunes feuilles
            _feuille(dn, px, py, rng.uniform(9, 18) * K, rng.uniform(0, 6.28),
                     rgba(rng.choice([120, 135, 150]), 0.55, 0.85, rng.uniform(0.35, 0.7)))
    else:                                                                   # ete
        sx, sy = rng.uniform(0.86, 0.97), rng.uniform(-0.25, 0.35)
        soleil = halo(h, w, sx, sy, 1.5, 1.1)
        rvb += teinte(36, 0.8)[None, None, :] * (soleil ** 1.6 * 0.55)[:, :, None]
        angle = np.arctan2((y - sy), (x - sx) * w / h)
        rayons = (0.5 + 0.5 * np.cos(angle * 26 + rng.uniform(0, 6))) ** 6
        rvb += teinte(42, 0.6)[None, None, :] * (rayons * halo(h, w, sx, sy, 3.2, 1.0) * 0.12)[:, :, None]
        for px, py in _semis(rng, W, H, 46):                               # lumieres du soir
            r = rng.uniform(5, 15) * K
            df.ellipse([px - r, py - r, px + r, py + r],
                       fill=rgba(rng.choice([40, 48, 186]), 0.6, 1.0, rng.uniform(0.1, 0.28)))
        for px, py in _semis(rng, W, H, 110):                              # lucioles
            r = rng.uniform(0.8, 2.3) * K
            dn.ellipse([px - r, py - r, px + r, py + r], fill=rgba(52, 0.5, 1.0, rng.uniform(0.5, 0.95)))
        for i in range(3):                                                 # la mer, en bas
            base = (0.74 + 0.09 * i) * H
            phase, ampl, pas = rng.uniform(0, 6), rng.uniform(3, 6) * K, rng.uniform(70, 120) * K
            pts = [(px, base + ampl * math.sin(px / pas + phase)) for px in range(int(0.25 * W), W + 30, 30)]
            dn.line(pts, fill=rgba(186, 0.6, 1.0, 0.28 - 0.06 * i), width=K * 2)

    flou = flou.filter(ImageFilter.GaussianBlur(4 * K))
    for calque, force in ((flou, 1.0), (net, 1.0)):
        petit = np.asarray(calque.resize((w, h), Image.LANCZOS), np.float32) / 255
        alpha = petit[:, :, 3:4] * force
        rvb = rvb * (1 - alpha * 0.85) + petit[:, :, :3] * alpha
        if calque is net:
            rvb += gaussian_filter(petit[:, :, :3] * alpha, (2.5, 2.5, 0)) * 0.35      # leger eclat
    if saison in ("hiver", "ete"):
        zone = np.clip(pente * (0.9 - y * 0.5), 0, 1)
        rvb += etoiles(rng, h, w, 260, 5, zone) * (0.7 if saison == "hiver" else 0.4)
    rvb += constellation(rng, h, w, 6, teinte(reglages["t1"], 0.25),
                         (rng.uniform(0.5, 0.62), 0.12, rng.uniform(0.78, 0.9), 0.88), 0.26)

    # le titre de la page et ses compteurs sont a gauche : la banniere s'y eteint
    rvb *= np.clip((x - 0.04) / 0.34, 0, 1)[:, :, None] ** 1.3
    rvb = np.clip(rvb, 0, None)
    rvb = rvb / (1 + rvb * 0.45)
    rvb = NUIT[None, None, :] * 0.85 + rvb
    rvb += rng.normal(0, 0.004, rvb.shape).astype(np.float32)
    return Image.fromarray((np.clip(rvb, 0, 1) * 255 + 0.5).astype(np.uint8), "RGB")


# ---------------------------------------------------------------------------
def luminance(img: Image.Image) -> tuple[float, float]:
    lum = np.asarray(img.convert("L"), np.float32)
    return float(lum.mean()), float(gaussian_filter(lum, 28).max())


def main(argv: list[str]) -> int:
    if len(argv) < 3 or argv[1] not in ("fonds", "saisons"):
        print(__doc__)
        return 2
    dossier = Path(argv[2])
    dossier.mkdir(parents=True, exist_ok=True)
    if argv[1] == "fonds":
        nombre = int(argv[3]) if len(argv) > 3 else 50
        premier = int(argv[4]) if len(argv) > 4 else 1
        for n in range(premier, premier + nombre):
            img = fond(n)
            moyenne, clair = luminance(img)
            assert LUMINANCE[0] - 1.5 <= moyenne <= LUMINANCE[1] + 1.5 and clair <= CLAIR_MAX + 6, \
                f"fond {n} hors des bornes de lisibilite ({moyenne:.1f}, {clair:.1f})"
            img.save(dossier / f"{n:03d}.jpg", quality=84, optimize=True, progressive=True)
            print(f"{n:03d} {STYLES[n % len(STYLES)]:14s} luminance {moyenne:5.1f}  zone la plus claire {clair:5.1f}")
    else:
        debut = int(argv[3]) if len(argv) > 3 else 2026
        annees = int(argv[4]) if len(argv) > 4 else 5
        for annee in range(debut, debut + annees):
            for saison in SAISONS:
                img = banniere(saison, annee)
                gauche = float(np.asarray(img.convert("L"), np.float32)[:, : img.width // 8].mean())
                assert gauche < 16, f"{saison} {annee} : trop clair a gauche ({gauche:.1f})"
                img.save(dossier / f"{saison}-{annee}.jpg", quality=88, optimize=True, progressive=True)
                print(f"{saison}-{annee}  gauche {gauche:4.1f}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
