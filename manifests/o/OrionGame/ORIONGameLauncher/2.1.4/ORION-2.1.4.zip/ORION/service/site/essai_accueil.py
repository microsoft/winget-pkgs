"""Essai de la page d'accueil du site dans un vrai navigateur (Chromium).

Usage : python essai_accueil.py <dossier du site>

Rien ne doit manquer ni deborder : polices et images servies par le site,
aucune demande a un tiers, ancres valides, loupe et fenetre de soutien."""
import functools, http.server, os, sys, threading
from playwright.sync_api import sync_playwright

SITE = sys.argv[1]


class H(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass

    def send_head(self):
        p = self.translate_path(self.path)
        if (not os.path.exists(p) or os.path.isdir(p)) and os.path.exists(p.rstrip("/") + ".html"):
            self.path += ".html"
        return super().send_head()


srv = http.server.ThreadingHTTPServer(("127.0.0.1", 8771), functools.partial(H, directory=SITE))
threading.Thread(target=srv.serve_forever, daemon=True).start()
BASE = "http://127.0.0.1:8771"
with sync_playwright() as p:
    nav = p.chromium.launch()
    for largeur in (1440, 820, 390):
        page = nav.new_page(viewport={"width": largeur, "height": 900})
        erreurs, dehors, rates = [], [], []
        page.on("pageerror", lambda e: erreurs.append(str(e)))
        page.on("console", lambda m: erreurs.append(m.text) if m.type == "error" else None)
        page.on("request", lambda r: dehors.append(r.url) if not r.url.startswith(BASE) else None)
        page.on("response", lambda r: rates.append((r.status, r.url)) if r.status >= 400 else None)
        page.goto(BASE + "/")
        page.wait_for_timeout(1500)
        # tout faire defiler : les images paresseuses se chargent
        hauteur = page.evaluate("document.documentElement.scrollHeight")
        for y in range(0, hauteur, 700):
            page.evaluate(f"window.scrollTo(0,{y})"); page.wait_for_timeout(60)
        page.wait_for_timeout(600)
        assert not erreurs, erreurs
        assert not dehors, ("demande a un tiers", dehors[:3])
        assert not rates, rates[:3]
        assert page.evaluate("document.documentElement.scrollWidth <= innerWidth"), f"deborde a {largeur}"
        cassees = page.evaluate("[...document.images].filter(i => !i.closest('dialog') && (!i.complete || !i.naturalWidth)).map(i => i.src)")
        assert not cassees, cassees
        ancres = page.evaluate("""[...document.querySelectorAll('a[href^="#"]')].map(a => a.getAttribute('href'))
            .filter(h => h.length > 1 && !document.getElementById(h.slice(1)))""")
        assert not ancres, ancres
        polices = page.evaluate("['800 40px Bricolage','400 17px Figtree','600 24px Caveat'].map(f => document.fonts.check(f))")
        assert all(polices), polices
        assert page.evaluate("getComputedStyle(document.querySelector('h1')).fontFamily").startswith('Bricolage')
        notes = page.locator(".note:visible").count()
        assert (notes > 0) == (largeur > 860), (largeur, notes)
        if largeur == 1440:
            # les notes restent dans leur capture
            dehors_notes = page.evaluate("""[...document.querySelectorAll('.note')].filter(n => {
                const a = n.querySelector("span").getBoundingClientRect(), b = n.closest(".cadre").getBoundingClientRect();
                return a.left < b.left - 4 || a.right > b.right + 4 || a.top < b.top - 4 || a.bottom > b.bottom + 4;}).length""")
            assert dehors_notes == 0, dehors_notes
            page.locator("button.zoom").first.scroll_into_view_if_needed()
            page.locator("button.zoom").first.click()
            assert page.locator("#loupe img").is_visible()
            page.keyboard.press("Escape")
            assert page.locator("#loupe").count() == 0
            page.locator('a[href*="paypal.me"]').first.scroll_into_view_if_needed()
            page.locator('a[href*="paypal.me"]').first.click()
            assert page.locator("dialog.soutien").evaluate("d => d.open")
            page.locator("dialog.soutien [data-fermer]").first.click()
            questions = page.locator("#faq details").count()
            assert questions >= 10, questions
        print(largeur, "ok :", hauteur, "px de haut,", notes, "notes visibles")
        page.close()
    # les autres pages n'appellent personne non plus
    for chemin in ("/sorties", "/jeux", "/mentions-legales", "/404"):
        page = nav.new_page(viewport={"width": 1280, "height": 800}); dehors = []
        page.on("request", lambda r: dehors.append(r.url) if not r.url.startswith(BASE) else None)
        page.goto(BASE + chemin); page.wait_for_timeout(500)
        assert not dehors, (chemin, dehors[:3])
        assert page.evaluate("getComputedStyle(document.querySelector('h1')).fontFamily").startswith('Bricolage'), chemin
        page.close()
    nav.close()
print("accueil ok")
