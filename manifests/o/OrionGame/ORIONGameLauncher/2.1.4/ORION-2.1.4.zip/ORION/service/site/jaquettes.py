"""Visuels des jeux pour les pages /jeux et /en/games (12 octobre 2026,
demande de l'auteur : « dans toutes les pages de cette categorie, il manque
les photos »).

Chaque jeu a sa page ; son visuel est celui de sa fiche Steam (« header »,
460 x 215, le visuel officiel de l'editeur). Il est servi par le site
lui-meme (`/img/jeux/<appid>.jpg`), jamais charge depuis Steam par le
visiteur : aucune adresse IP de visiteur ne part chez un tiers, comme
l'annoncent les mentions legales.

Deux etapes :

1. `python jaquettes.py liste <liste.txt> <jeux-steam.json> <fiches-jeux.json> [<jeux-en.json>]`
   ecrit, pour chaque jeu qui a une page, « appid;adresse;adresse de secours ».
   Le telechargement se fait sur le PC de l'auteur (`JAQUETTES-SITE.bat`,
   dossier `Claude creation\\site-jaquettes`) : un seul passage par jeu, les
   visuels deja la ne sont pas redemandes.
2. `python jaquettes.py preparer <images telechargees> <base du site>/img/jeux`
   recompresse chaque visuel (JPEG progressif, 460 x 215).

Les generateurs (`gen_jeux.py`, `gen_jeux_en.py`) ne posent une image que si
le fichier existe dans le site : un jeu sans visuel garde sa carte sans image.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ICI = Path(__file__).resolve().parent
#: taille du visuel « header » de Steam
LARGEUR, HAUTEUR = 460, 215
DOSSIER = "img/jeux"
SECOURS = "https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/{}/header.jpg"


def adresse(appid) -> str:
    """Adresse du visuel dans le site."""
    return f"/{DOSSIER}/{appid}.jpg"


def disponibles(site: Path) -> set[str]:
    """Appids dont le visuel est dans le site."""
    d = Path(site) / DOSSIER
    return {f.stem for f in d.glob("*.jpg") if f.stem.isdigit()} if d.is_dir() else set()


def balise(appid, classe: str = "", chargement: str = "lazy") -> str:
    """<img> du visuel. Texte de remplacement vide : le nom du jeu est ecrit
    juste a cote (il serait lu deux fois)."""
    attr_classe = f' class="{classe}"' if classe else ""
    prio = ' fetchpriority="high"' if chargement == "eager" else ""
    return (f'<img{attr_classe} src="{adresse(appid)}" alt="" width="{LARGEUR}" height="{HAUTEUR}" '
            f'loading="{chargement}" decoding="async"{prio}>')


def appids_publies(jeux_steam: Path, fiches: Path, jeux_en: Path | None = None) -> dict[str, str]:
    """{appid: adresse Steam du visuel} des jeux qui ont une page."""
    sys.path.insert(0, str(ICI))
    sys.path.insert(0, str(ICI.parent.parent))
    import gen_jeux
    donnees = json.loads(Path(jeux_steam).read_text(encoding="utf-8"))
    nouvelles = json.loads(Path(fiches).read_text(encoding="utf-8")).get("jeux") or {}
    jeux, _ = gen_jeux.choisir(donnees, nouvelles, None)
    vus = {j["appid"]: j.get("img") or "" for j in jeux}
    if jeux_en:
        import gen_jeux_en
        for j in gen_jeux_en.choisir(json.loads(Path(jeux_en).read_text(encoding="utf-8"))):
            vus.setdefault(j["appid"], j.get("img") or "")
    return vus


def liste(sortie: Path, jeux_steam: Path, fiches: Path, jeux_en: Path | None = None) -> int:
    lignes = []
    for appid, img in sorted(appids_publies(jeux_steam, fiches, jeux_en).items(), key=lambda x: int(x[0])):
        img = img.split(";")[0].strip()
        lignes.append(f"{appid};{img or SECOURS.format(appid)};{SECOURS.format(appid)}")
    Path(sortie).write_bytes(("\r\n".join(lignes) + "\r\n").encode("ascii"))
    return len(lignes)


def preparer(source: Path, dest: Path) -> tuple[int, list[str]]:
    """Recompresse les visuels telecharges. Rend (nombre, illisibles)."""
    from PIL import Image
    dest = Path(dest)
    dest.mkdir(parents=True, exist_ok=True)
    faits, illisibles = 0, []
    for f in sorted(Path(source).glob("*.jpg")):
        if not f.stem.isdigit():
            continue
        try:
            with Image.open(f) as im:
                im = im.convert("RGB")
                if im.size != (LARGEUR, HAUTEUR):
                    # meme cadrage que Steam : remplit 460 x 215, coupe ce qui depasse
                    echelle = max(LARGEUR / im.width, HAUTEUR / im.height)
                    im = im.resize((round(im.width * echelle), round(im.height * echelle)),
                                   Image.Resampling.LANCZOS)
                    g, h = (im.width - LARGEUR) // 2, (im.height - HAUTEUR) // 2
                    im = im.crop((g, h, g + LARGEUR, h + HAUTEUR))
                im.save(dest / f.name, "JPEG", quality=80, optimize=True, progressive=True)
                faits += 1
        except Exception:                    # fichier tronque, page d'erreur...
            illisibles.append(f.stem)
    return faits, illisibles


if __name__ == "__main__":
    if sys.argv[1:2] == ["liste"]:
        n = liste(*[Path(a) for a in sys.argv[2:6]])
        print(f"{n} jeux dans la liste")
    elif sys.argv[1:2] == ["preparer"]:
        n, rates = preparer(Path(sys.argv[2]), Path(sys.argv[3]))
        print(f"{n} visuels prepares" + (f", {len(rates)} illisibles : {', '.join(rates[:20])}" if rates else ""))
    else:
        print(__doc__)
