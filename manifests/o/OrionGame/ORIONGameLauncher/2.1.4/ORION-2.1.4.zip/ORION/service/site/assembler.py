"""Assemble le site a deployer : la base en ligne (accueil, sorties, mentions
legales, images, polices, scripts) + les pages de jeux generees + le compteur
de clics, puis un zip pret pour DEPLOYER-SITE.bat.

Usage :
  python assembler.py <base en ligne> <dossier de sortie> <jeux-steam.json>
                      <gamesplanet-fr.json> <fiches-fusion.json> [platformList.xml CatalogIndexPC.xml] [--max N]

`--max N` limite le nombre de pages de jeux (les plus possedees d'abord) :
le depot par le tableau de bord Cloudflare accepte 1 000 fichiers au plus ;
Wrangler n'a pas cette limite.
"""
from __future__ import annotations

import json
import re
import os
import shutil
import sys
import zipfile
from pathlib import Path

ICI = Path(__file__).resolve().parent


#: 11 octobre (audit) : le titre de l'accueil faisait 98 signes et sa
#: description 339 ; Google coupe vers 60 et 155. La promesse reste dans le
#: titre affiche de la page et dans le partage (og:title).
TITRE_ACCUEIL = "ORION Game Launcher : launcher de jeux PC gratuit"
DESC_ACCUEIL = ("Launcher de jeux PC gratuit : Steam, Epic, GOG, Xbox, Ubisoft, EA et Battle.net réunis, "
                "les bons réglages pour votre PC, les pilotes et le meilleur prix.")
#: pages d'entree du referencement, au pied de chaque page francaise. Un seul
#: endroit (13 octobre) : l'accueil les perdait depuis le site 217 (le test
#: cherchait « /gratuits » dans toute la page, et la section Bons plans de
#: l'accueil en contient un), et les pages neuves n'etaient liees de nulle part
ENTREES = [("/gratuits", "Jeux gratuits"), ("/gta-6-pc", "GTA 6 PC"), ("/black-friday", "Black Friday"),
           ("/soldes-steam", "Soldes Steam"), ("/augmenter-fps", "Augmenter ses FPS"),
           ("/jeux/peu-gourmands", "Jeux peu gourmands"), ("/config-pc-gamer-2026", "Config PC gamer 2026"),
           ("/mon-pc-peut-il-faire-tourner", "Mon PC peut-il faire tourner ?")]
TIKTOK = "https://www.tiktok.com/@oriongamelauncher"
#: profils publics d'ORION (donnees structurees de l'accueil, pied de page)
PROFILS = ["https://github.com/Sikher-kisa/orion-game-launcher", TIKTOK]   # + la fiche du Microsoft Store
NAVS_PIED = ('<nav aria-label="Liens du pied de page">', '<nav aria-label="Footer links">')


def completer_pieds(sortie: Path) -> int:
    """Pied de page de chaque page : les pages d'entree (francais) et le
    compte TikTok (les deux langues), chacun une seule fois. Rend le nombre
    de pages changees."""
    n = 0
    for page in sortie.rglob("*.html"):
        s = page.read_text(encoding="utf-8")
        debut = max(s.rfind(x) for x in NAVS_PIED)
        if debut < 0 or s.rfind("<footer") > debut or s.rfind("<footer") < 0:
            continue
        fin = s.index("</nav>", debut)
        nav = s[debut:fin]
        if NAVS_PIED[0] in nav:
            ancre = re.search(r'<a href="/sorties"[^>]*>[^<]*</a>', nav)
            pos = ancre.end() if ancre else len(nav)
            for href, nom in ENTREES:
                deja = re.search(r'<a href="' + re.escape(href) + r'"[^>]*>[^<]*</a>', nav)
                if deja:
                    pos = deja.end()
                    continue
                lien = f'\n      <a href="{href}">{nom}</a>'
                nav = nav[:pos] + lien + nav[pos:]
                pos += len(lien)
        if TIKTOK not in nav:
            nav = nav.rstrip() + f'\n      <a href="{TIKTOK}" rel="me noopener">TikTok</a>\n    '
        if nav != s[debut:fin]:
            page.write_text(s[:debut] + nav + s[fin:], encoding="utf-8")
            n += 1
    return n


def profils_publics(sortie: Path) -> None:
    """« sameAs » des donnees structurees de l'application (accueils FR et EN) :
    le depot GitHub et le compte TikTok d'ORION."""
    for nom in ("index.html", "en/index.html"):
        p = sortie / nom
        if not p.is_file():
            continue
        s = p.read_text(encoding="utf-8")

        def ajouter(m):
            try:
                d = json.loads(m.group(1))
            except ValueError:
                return m.group(0)
            if not isinstance(d, dict) or d.get("@type") != "SoftwareApplication":
                return m.group(0)
            from gen_alternatives import STORE
            d["sameAs"] = [STORE] + PROFILS
            return '<script type="application/ld+json">\n' + json.dumps(d, ensure_ascii=False, indent=1) + "\n</script>"
        p.write_text(re.sub(r'<script type="application/ld\+json">(.*?)</script>', ajouter, s, flags=re.S),
                     encoding="utf-8")


def referencer_accueil(sortie: Path) -> None:
    """Titre et description de l'accueil a la bonne longueur (les liens du pied
    de page : `completer_pieds`)."""
    p = sortie / "index.html"
    s = p.read_text(encoding="utf-8")
    s = re.sub(r"<title>.*?</title>", f"<title>{TITRE_ACCUEIL}</title>", s, count=1, flags=re.S)
    s = re.sub(r'<meta name="description" content="[^"]*">', f'<meta name="description" content="{DESC_ACCUEIL}">',
               s, count=1)
    p.write_text(s, encoding="utf-8")


#: pages ecrites a la main (base du site) : titre d'onglet et description
#: tenus dans les limites de Google (60 et 155 caracteres), 11 octobre
STATIQUES = {
    "ce-qu-orion-envoie.html": ("Ce qu'ORION envoie, et ce qu'il n'envoie pas",
                                "Ce que l'application ORION envoie, à qui et quand, et ce qui ne quitte jamais votre "
                                "PC. Pas de compte, pas de publicité, rien sans votre accord."),
    "comparatif.html": ("ORION, Playnite ou GOG Galaxy : comparatif honnête", None),
    "mentions-legales.html": (None, "Mentions légales d'orion-launcher.com et d'ORION Game Launcher : éditeur, "
                                    "hébergement, données personnelles, liens partenaires et marques."),
}
NOMS_FIL = {"fr": "Accueil", "en": "Home"}


def completer_statiques(sortie: Path) -> int:
    """Pages de la base du site : onglet et description dans les limites,
    balises Open Graph et donnees structurees quand elles manquent, images
    avec leurs dimensions (lues dans le fichier). Rien n'est invente : le
    titre et la description de la page servent aux deux."""
    import html as h
    import re
    try:
        from PIL import Image
    except ImportError:                       # dimensions laissees telles quelles
        Image = None
    tailles: dict[str, str] = {}

    def dimensions(m):
        balise, src = m.group(0), m.group(1)
        if "width=" in balise or not src.startswith("/img/"):
            return balise
        if src not in tailles:
            f = sortie / src.lstrip("/").split("?")[0]
            tailles[src] = ""
            if src == "/img/logo.png":
                tailles[src] = ' width="30" height="30"'
            elif Image is not None and f.is_file():
                with Image.open(f) as im:
                    tailles[src] = f' width="{im.width}" height="{im.height}"'
        return balise[:-1].rstrip("/").rstrip() + tailles[src] + ">"

    changees = 0
    for page in sortie.rglob("*.html"):
        if page.name.startswith("google"):
            continue
        texte = page.read_text(encoding="utf-8")
        neuf = re.sub(r'<img\b[^>]*\bsrc="([^"]+)"[^>]*>', dimensions, texte)
        rel = page.relative_to(sortie).as_posix()
        titre, desc = STATIQUES.get(rel, (None, None))
        if titre:
            neuf = re.sub(r"<title>.*?</title>", f"<title>{h.escape(titre, quote=False)}</title>", neuf, count=1, flags=re.S)
        if desc:
            if '<meta name="description"' in neuf:
                neuf = re.sub(r'<meta name="description" content="[^"]*">',
                              f'<meta name="description" content="{h.escape(desc)}">', neuf, count=1)
            else:
                neuf = re.sub(r"(</title>)", r'\1' + f'\n<meta name="description" content="{h.escape(desc)}">', neuf, count=1)
        canon = re.search(r'<link rel="canonical" href="([^"]+)">', neuf)
        langue = (re.search(r'<html lang="([a-z]+)"', neuf) or [None, "fr"])[1]
        t = re.search(r"<title>(.*?)</title>", neuf, re.S)
        d = re.search(r'<meta name="description" content="([^"]*)">', neuf)
        if canon and t and d and "og:title" not in neuf:
            og = (f'\n<meta property="og:type" content="website">'
                  f'\n<meta property="og:site_name" content="ORION Game Launcher">'
                  f'\n<meta property="og:locale" content="{"en_US" if langue == "en" else "fr_FR"}">'
                  f'\n<meta property="og:url" content="{canon[1]}">'
                  f'\n<meta property="og:title" content="{h.escape(h.unescape(t[1].strip()))}">'
                  f'\n<meta property="og:description" content="{d[1]}">'
                  f'\n<meta property="og:image" content="https://orion-launcher.com/img/og.jpg">'
                  f'\n<meta name="twitter:card" content="summary_large_image">')
            neuf = neuf.replace(canon[0], canon[0] + og, 1)
        if canon and t and "application/ld+json" not in neuf:
            accueil = "https://orion-launcher.com/en/" if langue == "en" else "https://orion-launcher.com/"
            nom = h.unescape(t[1].strip())
            ld = [{"@context": "https://schema.org", "@type": "WebPage", "name": nom, "url": canon[1],
                   "inLanguage": langue, "description": h.unescape(d[1]) if d else "",
                   "isPartOf": {"@type": "WebSite", "name": "ORION Game Launcher", "url": "https://orion-launcher.com/"}}]
            if canon[1] != accueil:
                ld.append({"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [
                    {"@type": "ListItem", "position": 1, "name": NOMS_FIL[langue if langue in NOMS_FIL else "fr"],
                     "item": accueil},
                    {"@type": "ListItem", "position": 2, "name": nom, "item": canon[1]}]})
            bloc = "".join('\n<script type="application/ld+json">' + json.dumps(x, ensure_ascii=False) + "</script>"
                           for x in ld)
            neuf = neuf.replace("</head>", bloc.lstrip("\n") + "\n</head>", 1)
        if neuf != texte:
            page.write_text(neuf, encoding="utf-8")
            changees += 1
    return changees


#: une adresse de courriel dans une page
COURRIEL = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}")
ECARTE, FIN_ECARTE = "<!--email_off-->", "<!--/email_off-->"
#: ce que Cloudflare prend pour une adresse est plus large qu'une adresse :
#: « Intel Core i5-2500K@3.3GHz » (fiche Steam de Days Gone) etait masque
#: et recreait le lien /cdn-cgi/l/email-protection (audit du 12 octobre). Toute
#: page dont le texte contient un « @ » entre deux caracteres est protegee.
#: une arobase entre deux caracteres de texte ; pas « /@ » : l'adresse d'un
#: profil (tiktok.com/@orion...) n'est pas un courriel (13 octobre : le lien
#: TikTok du pied de page marquait toutes les pages)
AROBASE = re.compile(r"[^\s<>\"'=/]@[^\s<>\"']")


def proteger_courriels(sortie: Path) -> int:
    """Cloudflare « masque » toute adresse de courriel d'une page : il la
    remplace par un lien vers /cdn-cgi/l/email-protection et un script qui la
    remet. Google suit ce lien, tombe sur une page introuvable et le signale
    (Search Console, 12 octobre : « Introuvable (404) ») ; sans JavaScript, le
    visiteur lit « [email protected] » au lieu de l'adresse. L'adresse de
    contact est publique : on demande a Cloudflare de la laisser telle quelle
    (balises email_off autour du corps de la page). Rend le nombre de pages."""
    n = 0
    for page in sortie.rglob("*.html"):
        s = page.read_text(encoding="utf-8")
        if ECARTE in s or not AROBASE.search(s):
            continue
        debut = re.search(r"<body\b[^>]*>", s, re.I)
        fin = s.lower().rfind("</body>")
        if debut is None or fin < debut.end():
            raise RuntimeError(f"{page.relative_to(sortie)} : adresse de courriel sans <body> ni </body>")
        s = s[:debut.end()] + ECARTE + s[debut.end():fin] + FIN_ECARTE + s[fin:]
        page.write_text(s, encoding="utf-8")
        n += 1
    return n


def ecrire_codes_promo(sortie: Path) -> int:
    """codes.json (lu par l'application) et la meme liste inscrite dans
    comparatif.js (15 octobre) : une seule source, orion/codes_promo.py."""
    sys.path.insert(0, str(ICI.parent.parent))
    from orion import codes_promo
    contenu = codes_promo.pour_le_site()
    (sortie / "codes.json").write_text(json.dumps(contenu, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    script = sortie / "comparatif.js"
    texte = script.read_text(encoding="utf-8")
    if "/*CODES*/[]" not in texte:
        raise SystemExit("comparatif.js : repere /*CODES*/ absent")
    script.write_text(texte.replace("/*CODES*/[]", json.dumps(contenu["codes"], ensure_ascii=False), 1), encoding="utf-8")
    return len(contenu["codes"])


def versionner_scripts(sortie: Path) -> int:
    """Chaque script du site appele en /nom.js?v=<empreinte>, une seule fois par page.

    10 octobre : Cloudflare sert les scripts avec « max-age=14400 » ; un
    visiteur deja venu gardait l'ancien comparatif.js quatre heures apres une
    mise en ligne (« ca ne change toujours pas »). L'empreinte change avec le
    contenu, le navigateur recharge donc le script neuf des la mise en ligne.
    La page Modern Warfare 4 appelait aussi clic.js deux fois (chaque clic
    compte double) : les doublons sont retires."""
    import hashlib
    import re
    empreintes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()[:10] for p in sortie.glob("*.js")}
    motif = re.compile(r'<script src="/([\w.-]+\.js)(?:\?v=\w+)?"([^>]*)></script>(\n?)')
    changees = 0
    for page in sortie.rglob("*.html"):
        texte = page.read_text(encoding="utf-8")
        vus: set[str] = set()

        def remplacer(m):
            nom, reste, fin = m.group(1), m.group(2), m.group(3)
            if nom in vus:
                return ""
            vus.add(nom)
            if nom not in empreintes:
                return m.group(0)
            return f'<script src="/{nom}?v={empreintes[nom]}"{reste}></script>{fin}'

        neuf = motif.sub(remplacer, texte)
        if neuf != texte:
            page.write_text(neuf, encoding="utf-8")
            changees += 1
    return changees


def versionner_fichiers(sortie: Path) -> int:
    """Images et polices appelees en /img/x.jpg?v=<empreinte> (12 octobre).

    Le site les sert avec « max-age=604800 » (_headers) : Cloudflare les garde
    sept jours sous la meme adresse. La capture « fiche-jeu-reglages.jpg »,
    refaite le 11 octobre, etait encore servie dans sa version d'avant 3,6
    jours plus tard (audit du site en ligne). Comme pour les scripts,
    l'empreinte change avec le contenu : une image refaite a une adresse
    neuve, aucune ancienne copie ne peut etre servie a sa place."""
    import hashlib
    import re
    empreintes = {}
    for dossier in ("img", "polices"):
        for f in (sortie / dossier).rglob("*"):
            if f.is_file():
                empreintes["/" + f.relative_to(sortie).as_posix()] = hashlib.sha256(f.read_bytes()).hexdigest()[:10]
    motif = re.compile(r"(https://orion-launcher\.com)?(/(?:img|polices)/[A-Za-z0-9._/-]+)(?![A-Za-z0-9._/-]|\?v=)")

    def remplacer(m):
        v = empreintes.get(m.group(2))
        return m.group(0) + f"?v={v}" if v else m.group(0)
    changees = 0
    for page in sortie.rglob("*.html"):
        texte = page.read_text(encoding="utf-8")
        neuf = motif.sub(remplacer, texte)
        if neuf != texte:
            page.write_text(neuf, encoding="utf-8")
            changees += 1
    return changees


def main(base, sortie, source, prix, fiches, maximum: int | None = None,
         plateformes_hp: str = "", index_dell: str = "", jeux_en: str = "", releve_en: str = "") -> int:
    base, sortie = Path(base), Path(sortie)
    if sortie.exists():
        shutil.rmtree(sortie)
    shutil.copytree(base, sortie, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".DS_Store"))
    shutil.copy(ICI / "clic.js", sortie / "clic.js")
    shutil.copy(ICI / "comparatif.js", sortie / "comparatif.js")
    # sorties.json : la liste de l'application elle-meme (orion/sorties.py),
    # jamais une copie faite a la main (10 octobre : les fiches Instant Gaming
    # ajoutees a l'application manquaient au site).
    sys.path.insert(0, str(ICI.parent.parent))
    from orion import sorties as liste_sorties
    (sortie / "sorties.json").write_text(json.dumps(
        {"format": liste_sorties.FORMAT, "maj": liste_sorties.MAJ, "sorties": liste_sorties.EMBARQUEE},
        ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    ecrire_codes_promo(sortie)
    if maximum:
        os.environ["ORION_PAGES_MAX"] = str(maximum)
    sys.path.insert(0, str(ICI))
    import importlib
    gen = importlib.import_module("gen_jeux")
    gen.main(sortie, source, prix, fiches)
    if plateformes_hp and index_dell:
        importlib.import_module("gen_pilotes").main(sortie, plateformes_hp, index_dell)
    importlib.import_module("gen_journal").main(sortie, ICI.parent.parent / "CHANGELOG.md")
    importlib.import_module("gen_en").main(sortie)
    if jeux_en:
        # pages de jeux en anglais (11 octobre) : donnees anglaises de COLLECTER-JEUX
        importlib.import_module("gen_jeux_en").main(sortie, jeux_en, releve_en)
    importlib.import_module("gen_une").main(sortie)
    importlib.import_module("gen_sorties").main(sortie)
    # pages d'entree du referencement (11 octobre) : une par sortie, GTA 6 PC,
    # Black Friday, jeux gratuits
    importlib.import_module("gen_evenements").main(sortie)
    importlib.import_module("gen_guides").main(sortie)
    # pages « alternative à… » et llms.txt (11 octobre) : recherches de gens prets a installer
    importlib.import_module("gen_alternatives").main(sortie)
    # flux RSS (11 octobre) : sorties, nouveautes ; jeux gratuits servis par le service
    importlib.import_module("gen_rss").main(sortie, ICI.parent.parent / "CHANGELOG.md")
    # « Bons plans » dans le menu et le pied de page des pages francaises (13 octobre)
    referencer_accueil(sortie)
    print(f"pied de page complete sur {completer_pieds(sortie)} pages")
    profils_publics(sortie)
    # apres les pieds de page : « Bons plans » se place devant « Jeux gratuits »
    if (sortie / "bons-plans.html").exists():
        print(f"bons plans : lien ajoute a {importlib.import_module('gen_bons_plans').relier(sortie)} pages")
    # barre de recherche dans l'en-tete de chaque page, page des resultats (14 octobre)
    importlib.import_module("gen_recherche").main(sortie)
    completer_statiques(sortie)
    versionner_scripts(sortie)
    versionner_fichiers(sortie)
    print(f"{proteger_courriels(sortie)} pages avec une adresse de courriel laissee en clair (Cloudflare)")
    fichiers = [p for p in sortie.rglob("*") if p.is_file()]
    print(f"{len(fichiers)} fichiers dans {sortie}"
          + (" : au-dela des 1 000 du tableau de bord Cloudflare, Wrangler obligatoire" if len(fichiers) > 1000 else ""))
    zip_ = sortie.with_suffix(".zip")
    with zipfile.ZipFile(zip_, "w", zipfile.ZIP_DEFLATED) as z:
        for p in fichiers:
            z.write(p, p.relative_to(sortie))
    print(f"archive : {zip_} ({zip_.stat().st_size // 1024} Ko)")
    return len(fichiers)


if __name__ == "__main__":
    def option(nom):
        """Valeur de --nom, retiree des arguments positionnels."""
        if nom not in sys.argv:
            return ""
        valeur = sys.argv[sys.argv.index(nom) + 1]
        sys.argv[sys.argv.index(nom):sys.argv.index(nom) + 2] = []
        return valeur
    maximum = option("--max")
    jeux_en, releve_en = option("--en"), option("--en-releve")
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    main(*args[:5], maximum=int(maximum) if maximum else None,
         plateformes_hp=args[5] if len(args) > 5 else "", index_dell=args[6] if len(args) > 6 else "",
         jeux_en=jeux_en, releve_en=releve_en)
