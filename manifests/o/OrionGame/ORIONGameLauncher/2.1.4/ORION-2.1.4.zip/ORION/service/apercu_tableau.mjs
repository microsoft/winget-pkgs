// Apercu du tableau de suivi sur ce PC, avec des chiffres inventes : rien ne
// sort, rien n'est lu chez les joueurs. Sert aussi a l'essai dans un vrai
// navigateur (service/essai_tableau.py).
//   node --experimental-sqlite apercu_tableau.mjs [port]
// puis ouvrir http://127.0.0.1:8799/tableau et saisir la cle affichee.
import http from "node:http";
import { DatabaseSync } from "node:sqlite";
import worker, { jourLocal, compterLectureRss } from "./worker.js";

export const CLE = "apercu-" + "a1b2c3d4e5".repeat(3);
const base = new DatabaseSync(":memory:");
const DB = {
  prepare(sql) {
    let args = [];
    const p = {
      bind(...a) { args = a.map((x) => (x === undefined ? null : x)); return p; },
      async run() { const r = base.prepare(sql).run(...args); return { meta: { last_row_id: Number(r.lastInsertRowid) } }; },
      async first() { return base.prepare(sql).get(...args) ?? null; },
      async all() { return { results: base.prepare(sql).all(...args) }; },
    };
    return p;
  },
};
const env = { DB, CLE_TABLEAU: CLE };
const poster = async (chemin, corps, cf) => {
  const texte = JSON.stringify(corps);
  const r = new Request("http://apercu" + chemin, { method: "POST", body: texte,
    headers: { "content-type": "application/json", "content-length": String(texte.length) } });
  if (cf) Object.defineProperty(r, "cf", { value: cf });
  return worker.fetch(r, env);
};

// -- des chiffres plausibles : quelques PC sur trois semaines
let graine = 7;
const hasard = () => (graine = (graine * 16807) % 2147483647) / 2147483647;
const pc = (i) => i.toString(16).padStart(32, "0");
const BOUTIQUES = ["instant-gaming", "gamesplanet", "kinguin", "steam", "loaded", "gog"];
const ORIGINES = ["boutique", "fiche", "envies", "bibliotheque", "gratuits"];
const PAGES = ["library", "boutique", "detail", "free", "wishlist", "hardware", "settings", "sorties"];
const REGIONS = [["FR", "Île-de-France"], ["FR", "Bretagne"], ["FR", "Occitanie"], ["BE", "Wallonie"], ["CA", "Quebec"]];
// l'horloge du service est reculee le temps de fabriquer le passe
const VraieDate = Date;
let faux = null;
globalThis.Date = class extends VraieDate {
  constructor(...a) { if (a.length) super(...a); else super(faux ?? VraieDate.now()); }
  static now() { return faux ?? VraieDate.now(); }
};
for (let recul = 20; recul >= 0; recul--) {
  const actifs = 3 + Math.round((20 - recul) * 0.6 + hasard() * 3);
  for (let i = 1; i <= actifs; i++) {
    if (recul && hasard() < 0.35) continue;         // tout le monde ne revient pas chaque jour
    faux = VraieDate.now() - recul * 86400000 - Math.floor(hasard() * (recul ? 80000000 : 20000000));
    const evenements = [{ nom: "ouverture", n: 1 }];
    for (let k = 0; k < 3; k++) evenements.push({ nom: "page", detail: PAGES[Math.floor(hasard() * PAGES.length)], n: 1 + Math.floor(hasard() * 4) });
    if (hasard() < 0.55) evenements.push({ nom: "clic", detail: BOUTIQUES[Math.floor(hasard() * hasard() * BOUTIQUES.length)],
      origine: ORIGINES[Math.floor(hasard() * hasard() * ORIGINES.length)], n: 1 + Math.floor(hasard() * 2) });
    const [country, region] = REGIONS[i % REGIONS.length];
    await poster("/compteur", { v: 2, app: i % 4 ? "2.0.0" : "1.9.8", canal: i % 3 ? "installateur" : "store",
      poste: pc(i), evenements }, { country, region });
  }
}
faux = null;
globalThis.Date = VraieDate;
// telechargements : vingt jours de releves, sans celui d'aujourd'hui (la page
// lit alors le total du jour directement sur GitHub)
base.exec("CREATE TABLE IF NOT EXISTS telechargements (jour TEXT NOT NULL, version TEXT NOT NULL, n INTEGER NOT NULL, publie TEXT, PRIMARY KEY (jour, version))");
base.exec("CREATE TABLE IF NOT EXISTS etat (cle TEXT PRIMARY KEY, valeur TEXT NOT NULL)");
for (let recul = 20; recul >= 1; recul--) {
  const jour = jourLocal(Date.now() - recul * 86400000);     // le jour de Paris, comme le service (sinon faux entre 22 h et minuit UTC)
  base.prepare("INSERT INTO telechargements (jour, version, n, publie) VALUES (?,?,?,?)")
    .run(jour, "v1.9.8", 226 - 5 * recul, "2026-10-05T08:00:00Z");
}
base.prepare("INSERT INTO etat (cle, valeur) VALUES ('releve_reussi', ?)").run(String(Math.floor(Date.now() / 1000) - 1500));
// fluidite (2.0.1) : des bilans de session, une cause qui domine
for (let i = 0; i < 9; i++) {
  await poster("/compteur", { v: 3, app: i % 3 ? "2.0.1" : "2.0.0", canal: "installateur", poste: pc(30 + i), evenements: [],
    sante: { arrets: 1 + (i % 4), duree_ms: 300 + 250 * (i % 4), demarrage_ms: 1500 + 200 * i, erreurs: i % 5 ? 0 : 1, causes: [
      { pile: "boutique_view._rendre:2046 < main_window._boutique_actualisee:1590", n: 1 + (i % 3), ms: 260 + 90 * (i % 3) },
      { pile: "free_view.__init__:111", n: 1, ms: 690 }] } });
}
// sante du service : un echec et quelques refus, aujourd'hui
base.exec("CREATE TABLE IF NOT EXISTS sante (jour TEXT NOT NULL, route TEXT NOT NULL, code INTEGER NOT NULL, n INTEGER NOT NULL DEFAULT 0, PRIMARY KEY (jour, route, code))");
const jourApercu = new Intl.DateTimeFormat("en-CA", { timeZone: "Europe/Paris", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
base.prepare("INSERT INTO sante (jour, route, code, n) VALUES (?, '/prix', 503, 1), (?, '/compteur', 400, 4), (?, '/esprit', 503, 2)").run(jourApercu, jourApercu, jourApercu);
base.prepare("INSERT INTO etat (cle, valeur) VALUES ('coherence', ?)").run(JSON.stringify({ quand: Math.floor(Date.now() / 1000) - 900,
  github: { version: "2.0.0", sha: "486dc3f787f08166d7f91fb5d1f0b850de55a0c2d4c8ba63a691d8dea30ab6bb" },
  site: { version: "2.0.0", sha: "486dc3f787f08166d7f91fb5d1f0b850de55a0c2d4c8ba63a691d8dea30ab6bb" }, ok: true }));
// flux RSS des jeux gratuits (11 octobre, soir) : quelques lecteurs inventes
for (let k = 0; k < 40; k++) await compterLectureRss(DB, "MonitoRSS [Feed Fetcher]", jourApercu);
for (let k = 0; k < 6; k++) await compterLectureRss(DB, "Feedly/1.0 (+http://www.feedly.com/fetcher.html; " + (3 + k) + " subscribers; )", jourApercu);
await compterLectureRss(DB, "Mozilla/5.0 Chrome/130", jourApercu);
await poster("/signalement", { v: 1, poste: pc(2), app: "2.0.0", titre: "La fiche d'un jeu reste vide",
  description: "J'ouvre Cyberpunk 2077 depuis la bibliotheque, la page reste noire quelques secondes.",
  erreur: "", rapport: "ORION 2.0.0\nWindows 11\n(rapport d'exemple)" });
await poster("/signalement", { v: 1, poste: pc(5), app: "1.9.8", titre: "<img src=x onerror=\"document.title='PIEGE'\">",
  description: "<script>document.title='PIEGE'</script> texte libre : affiche tel quel",
  erreur: "Traceback (most recent call last):\n  File \"orion/ui/x.py\", line 12\nValueError: exemple", rapport: "" });

export function demarrer(port) {
  return new Promise((pret) => {
    const serveur = http.createServer(async (q, r) => {
      const morceaux = [];
      for await (const m of q) morceaux.push(m);
      const corps = Buffer.concat(morceaux);
      const requete = new Request("http://127.0.0.1:" + port + q.url, { method: q.method,
        headers: Object.fromEntries(Object.entries(q.headers).filter(([, v]) => typeof v === "string")),
        body: q.method === "GET" || q.method === "HEAD" ? undefined : corps });
      const reponse = await worker.fetch(requete, env);
      r.writeHead(reponse.status, Object.fromEntries(reponse.headers));
      r.end(Buffer.from(await reponse.arrayBuffer()));
    });
    serveur.listen(port, "127.0.0.1", () => pret(serveur));
  });
}

if (import.meta.url === "file://" + process.argv[1]) {
  const port = Number(process.argv[2]) || 8799;
  await demarrer(port);
  console.log("Tableau d'essai : http://127.0.0.1:" + port + "/tableau");
  console.log("Cle d'essai     : " + CLE);
}
