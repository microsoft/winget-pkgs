/* Recherche du site ORION : la barre de l'en-tete, comme sur les sites de vente de jeux
   (demande de l'auteur, 14 octobre 2026 : Instant Gaming, Kinguin, DLCompare).
   - des la premiere lettre, une liste sous la barre : jeux (visuel, nom, genre,
     prix et remise quand ils sont connus), pages du site (bons plans, cartes...),
     puis « Voir tous les resultats » ;
   - champ vide : jeux vus recemment (sur cet appareil) ou tendances ;
   - fautes de frappe, accents et sigles acceptes (gta, bg3, cod bo3, rdr2) ;
   - page /recherche (/en/search) : tous les resultats, filtres et tri.
   L'index (/recherche.json, /en/search.json) n'est charge qu'au premier usage :
   aucune page ne fait de requete de plus tant qu'on ne cherche pas. */
(function () {
  "use strict";
  var EN = (document.documentElement.lang || "fr").slice(0, 2) === "en";
  var T = EN ? {
    jeux: "Games", pages: "Pages", vus: "Recently viewed", tendances: "Trending",
    tout: "See all results", rien: "No game matches. Check the spelling, or try fewer words.",
    des: "from", chez: "at", gratuit: "Free", config: "PC requirements", resultats: "results for", resultat: "result for",
    aucun: "No result for", filtres: { tous: "All", promo: "On sale", petit: "Under €10", gratuit: "Free" },
    tri: { pertinence: "Relevance", prix: "Lowest price", remise: "Biggest discount" },
    page: "/en/search", index: "/en/search.json", jeu: "/en/games/"
  } : {
    jeux: "Jeux", pages: "Pages", vus: "Vus récemment", tendances: "Tendances",
    tout: "Voir tous les résultats", rien: "Aucun jeu ne correspond. Vérifiez l'orthographe, ou essayez moins de mots.",
    des: "dès", chez: "chez", gratuit: "Gratuit", config: "Configuration requise", resultats: "résultats pour", resultat: "résultat pour",
    aucun: "Aucun résultat pour", filtres: { tous: "Tous", promo: "En promo", petit: "Moins de 10 €", gratuit: "Gratuits" },
    tri: { pertinence: "Pertinence", prix: "Prix croissant", remise: "Plus grosse remise" },
    page: "/recherche", index: "/recherche.json", jeu: "/jeux/"
  };
  var VERSION = "__VERSION__";
  var MAX_LISTE = 6, MAX_PAGES = 3, CLE_VUS = "orion.vus";

  // ------------------------------------------------------------------ texte
  var ROMAINS = { ii: 2, iii: 3, iv: 4, vi: 6, vii: 7, viii: 8, ix: 9, xi: 11, xii: 12, xiii: 13, xiv: 14, xv: 15, xvi: 16 };
  var SIGLES = {
    cod: "call of duty", bo: "black ops", mw: "modern warfare", r6: "rainbow six", cs: "counter strike",
    lol: "league of legends", wow: "world of warcraft", rdr: "red dead redemption", gow: "god of war",
    ac: "assassins creed", tlou: "the last of us", ff: "final fantasy", nfs: "need for speed",
    l4d: "left 4 dead", bf: "battlefield", pubg: "pubg battlegrounds", dbd: "dead by daylight",
    gta: "grand theft auto", bg: "baldurs gate", mh: "monster hunter", re: "resident evil",
    dmc: "devil may cry", mgs: "metal gear solid", hl: "half life", tes: "the elder scrolls",
    ets: "euro truck simulator", fh: "forza horizon", bl: "borderlands", aoe: "age of empires"
  };
  function plier(s) {
    return (s || "").replace(/[™®©]/g, "").replace(/[œŒ]/g, "oe").replace(/[æÆ]/g, "ae")
      .normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/['’`´]/g, "")
      .replace(/&/g, " and ").replace(/[^a-z0-9]+/g, " ").trim();
  }
  function mots(s) {
    var m = plier(s).split(" ").filter(Boolean);
    return m.map(function (x, i) { return ROMAINS[x] ? String(ROMAINS[x]) : (x === "v" && i > 0 ? "5" : x); });
  }
  /* « bo3 » -> « black ops 3 », « cod » -> « call of duty », « gta5 » -> « grand theft auto 5 » */
  function developper(liste) {
    var out = [];
    liste.forEach(function (m) {
      var p = /^([a-z]+)(\d+)$/.exec(m);
      if (SIGLES[m]) { out = out.concat(SIGLES[m].split(" ")); }
      else if (p && SIGLES[p[1]]) { out = out.concat(SIGLES[p[1]].split(" "), [p[2]]); }
      else { out.push(m); }
    });
    return out;
  }
  function initiales(liste) {
    return liste.map(function (m) { return /^\d+$/.test(m) ? m : m[0]; }).join("");
  }
  function distance(a, b, max) {            // Damerau-Levenshtein, coupe au-dela de max
    if (Math.abs(a.length - b.length) > max) return max + 1;
    var d = [], i, j;
    for (i = 0; i <= a.length; i++) { d[i] = [i]; }
    for (j = 0; j <= b.length; j++) { d[0][j] = j; }
    for (i = 1; i <= a.length; i++) {
      var mini = max + 1;
      for (j = 1; j <= b.length; j++) {
        var c = a[i - 1] === b[j - 1] ? 0 : 1;
        d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + c);
        if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) d[i][j] = Math.min(d[i][j], d[i - 2][j - 2] + 1);
        if (d[i][j] < mini) mini = d[i][j];
      }
      if (mini > max) return max + 1;
    }
    return d[a.length][b.length];
  }
  function preparer(nom) {
    var m = mots(nom);
    return { m: m, c: m.join(""), i: initiales(m) };
  }
  /* note de 0 a 100 ; en dessous de 55, ce n'est pas le jeu */
  function noter(q, cible, sansSigle) {
    if (!q.c) return 0;
    if (cible.c === q.c) return 100;
    // un sigle connu (« cod », « gta5 », « bo3 ») passe avant les titres qui commencent par ces lettres
    if (!sansSigle) {
      var dev0 = developper(q.m);
      if (dev0.join("") !== q.m.join("")) {
        var r0 = noter({ m: dev0, c: dev0.join(""), i: initiales(dev0) }, cible, true);
        if (r0 >= 80) return 97;
      }
    }
    if (cible.c.indexOf(q.c) === 0) return 92 - Math.min(12, (cible.c.length - q.c.length) / 3);
    var tous = q.m.every(function (x) { return cible.m.some(function (y) { return y.indexOf(x) === 0; }); });
    if (tous) return 84 - Math.min(10, cible.m.length - q.m.length);
    if (q.c.length >= 2 && /[a-z]/.test(q.c) && (cible.i === q.c || (q.c.length >= 3 && cible.i.indexOf(q.c) === 0))) return 80;
    var dev = sansSigle ? q.m : developper(q.m);
    if (dev.join("") !== q.m.join("")) {
      var r = noter({ m: dev, c: dev.join(""), i: initiales(dev) }, cible, true);
      if (r >= 55) return Math.max(r - 4, 56);
    }
    if (q.c.length >= 4 && cible.c.indexOf(q.c) > 0) return 70;
    var fautes = 0;
    var ok = q.m.every(function (x) {
      if (cible.m.some(function (y) { return y.indexOf(x) === 0; })) return true;
      if (x.length < 4) return false;
      var max = x.length >= 7 ? 2 : 1;
      var meilleur = Math.min.apply(null, cible.m.map(function (y) {
        return Math.min(distance(x, y, max), distance(x, y.slice(0, x.length), max));
      }));
      fautes += meilleur;
      return meilleur <= max;
    });
    return ok ? 66 - fautes * 4 : 0;
  }

  // ------------------------------------------------------------------ index
  var index = null, attente = null;
  function charger() {
    if (index) return Promise.resolve(index);
    if (attente) return attente;
    attente = fetch(T.index + "?v=" + VERSION).then(function (r) { return r.json(); }).then(function (d) {
      index = {
        jeux: (d.j || []).map(function (x, rang) {
          return { nom: x[0], slug: x[1], img: x[2], genre: x[3], dev: x[4], prix: x[5], remise: x[6] || 0,
                   gratuit: !!x[8], rang: rang, p: preparer(x[0]) };
        }),
        pages: (d.p || []).map(function (x) { return { nom: x[0], url: x[1], p: preparer(x[0] + " " + (x[2] || "")), titre: preparer(x[0]) }; })
      };
      return index;
    }).catch(function () { attente = null; return null; });
    return attente;
  }
  function chercher(texte) {
    var q = preparer(texte);
    var jeux = [], pages = [];
    index.pages.forEach(function (pg) {
      var n = Math.max(noter(q, pg.titre), noter(q, pg.p) - 6);
      if (n >= 60) pages.push({ pg: pg, n: n });
    });
    pages.sort(function (a, b) { return b.n - a.n; });
    pages = pages.map(function (x) { return x.pg; });
    index.jeux.forEach(function (j) {
      var n = noter(q, j.p);
      if (n >= 55) jeux.push({ j: j, n: n });
    });
    jeux.sort(function (a, b) { return (b.n - a.n) || (a.j.rang - b.j.rang); });
    // des titres trouves tels quels : les lectures a une faute pres ne viennent pas les noyer
    if (jeux.length && jeux[0].n >= 80) jeux = jeux.filter(function (x) { return x.n >= 70; });
    // rien avec tous les mots (« cod bo3 » quand le site n'a pas Black Ops III) : avec un mot de moins
    if (!jeux.length && q.m.length > 1) {
      var court = chercher(texte.trim().split(/\s+/).slice(0, -1).join(" "));
      return { jeux: court.jeux, pages: pages.length ? pages : court.pages, approche: true };
    }
    return { jeux: jeux.map(function (x) { return x.j; }), pages: pages };
  }

  // ------------------------------------------------------------------ vus recemment (cet appareil)
  function lireVus() {
    try { return JSON.parse(localStorage.getItem(CLE_VUS) || "[]"); } catch (e) { return []; }
  }
  function noterVu() {
    var m = location.pathname.match(EN ? /^\/en\/games\/([a-z0-9-]+?)(?:\.html)?$/ : /^\/jeux\/([a-z0-9-]+?)(?:\.html)?$/);
    if (!m) return;
    var h1 = document.querySelector("main h1");
    try {
      var vus = lireVus().filter(function (s) { return s !== m[1]; });
      vus.unshift(m[1]);
      localStorage.setItem(CLE_VUS, JSON.stringify(vus.slice(0, 8)));
    } catch (e) { /* stockage refuse : rien a garder */ }
    return h1;
  }

  // ------------------------------------------------------------------ dessin
  function el(tag, cls, html) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (html !== undefined) e.innerHTML = html;
    return e;
  }
  function echap(s) {
    return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; });
  }
  function euros(v) {
    return EN ? "€" + v.toFixed(2) : v.toFixed(2).replace(".", ",") + " €";
  }
  function teinte(nom) {
    var h = 0;
    for (var i = 0; i < nom.length; i++) h = (h * 31 + nom.charCodeAt(i)) % 360;
    return h;
  }
  function vignette(j, cls) {
    if (j.img) return '<img class="' + cls + '" src="/img/jeux/' + j.img + '.jpg" alt="" loading="lazy" decoding="async">';
    var h = teinte(j.nom);
    return '<span class="' + cls + '" style="background:linear-gradient(135deg,hsl(' + h + ',45%,38%),hsl(' + ((h + 50) % 360) + ',55%,14%))"></span>';
  }
  function prixHtml(j) {
    if (j.gratuit) return '<span class="ch-prix ch-gratuit">' + T.gratuit + "</span>";
    if (j.prix === null || j.prix === undefined) return "";
    return (j.remise ? '<span class="ch-remise">-' + j.remise + " %</span>" : "") +
           '<span class="ch-prix">' + euros(j.prix) + "</span>";
  }
  function ligneJeu(j, id) {
    var a = el("a", "ch-ligne");
    a.href = T.jeu + j.slug;
    a.id = id;
    a.setAttribute("role", "option");
    a.innerHTML = vignette(j, "ch-img") + '<span class="ch-txt"><b>' + echap(j.nom) + "</b><small>" +
      echap([j.genre, j.prix !== null && j.prix !== undefined && !j.gratuit ? T.des + " " + euros(j.prix) + " " + T.chez + " Gamesplanet" : T.config]
        .filter(Boolean).join(" · ")) + '</small></span><span class="ch-droite">' + prixHtml(j) + "</span>";
    return a;
  }

  // ------------------------------------------------------------------ la barre
  function brancher(form) {
    var champ = form.querySelector("input");
    var liste = el("div", "ch-liste");
    liste.id = "ch-liste-" + Math.random().toString(36).slice(2, 7);
    liste.setAttribute("role", "listbox");
    liste.hidden = true;
    form.appendChild(liste);
    champ.setAttribute("role", "combobox");
    champ.setAttribute("aria-controls", liste.id);
    champ.setAttribute("aria-expanded", "false");
    champ.setAttribute("aria-autocomplete", "list");
    var actif = -1, minuterie = 0;

    function options() { return liste.querySelectorAll("[role=option]"); }
    function fermer() { liste.hidden = true; champ.setAttribute("aria-expanded", "false"); actif = -1; }
    function ouvrir() { liste.hidden = false; champ.setAttribute("aria-expanded", "true"); }
    function surligner(i) {
      var o = options();
      if (!o.length) return;
      actif = (i + o.length) % o.length;
      for (var k = 0; k < o.length; k++) o[k].classList.toggle("ch-actif", k === actif);
      champ.setAttribute("aria-activedescendant", o[actif].id);
      o[actif].scrollIntoView({ block: "nearest" });
    }
    function titre(texte) { liste.appendChild(el("p", "ch-titre", texte)); }

    function remplir() {
      var texte = champ.value.trim();
      charger().then(function (ix) {
        if (!ix || document.activeElement !== champ) return;
        liste.innerHTML = "";
        actif = -1;
        var n = 0;
        if (!texte) {
          var parSlug = {};
          ix.jeux.forEach(function (j) { parSlug[j.slug] = j; });
          var vus = lireVus().map(function (s) { return parSlug[s]; }).filter(Boolean);
          var tuiles = vus.length >= 2 ? vus : ix.jeux.filter(function (j) { return j.remise >= 30; }).slice(0, MAX_LISTE);
          if (!tuiles.length) tuiles = ix.jeux.slice(0, MAX_LISTE);
          titre(vus.length >= 2 ? T.vus : T.tendances);
          var rang = el("div", "ch-tuiles");
          tuiles.slice(0, MAX_LISTE).forEach(function (j) {
            var a = el("a", "ch-tuile");
            a.href = T.jeu + j.slug;
            a.id = liste.id + "-" + (n++);
            a.setAttribute("role", "option");
            a.innerHTML = vignette(j, "ch-timg") + (j.remise ? '<span class="ch-remise">-' + j.remise + " %</span>" : "") +
                          "<b>" + echap(j.nom) + "</b>";
            rang.appendChild(a);
          });
          liste.appendChild(rang);
          ouvrir();
          return;
        }
        var r = chercher(texte);
        if (r.jeux.length) {
          titre(T.jeux);
          r.jeux.slice(0, MAX_LISTE).forEach(function (j) { liste.appendChild(ligneJeu(j, liste.id + "-" + (n++))); });
        } else {
          liste.appendChild(el("p", "ch-rien", T.rien));
        }
        if (r.pages.length) {
          titre(T.pages);
          var puces = el("div", "ch-puces");
          r.pages.slice(0, MAX_PAGES).forEach(function (pg) {
            var a = el("a", "ch-puce", echap(pg.nom));
            a.href = pg.url;
            a.id = liste.id + "-" + (n++);
            a.setAttribute("role", "option");
            puces.appendChild(a);
          });
          liste.appendChild(puces);
        }
        var tout = el("a", "ch-tout", echap(T.tout) + (r.jeux.length > MAX_LISTE ? " (" + r.jeux.length + ")" : "") + " &rarr;");
        tout.href = T.page + "?q=" + encodeURIComponent(texte);
        tout.id = liste.id + "-" + (n++);
        tout.setAttribute("role", "option");
        liste.appendChild(tout);
        ouvrir();
      });
    }
    champ.addEventListener("focus", remplir);
    champ.addEventListener("input", function () { clearTimeout(minuterie); minuterie = setTimeout(remplir, 90); });
    champ.addEventListener("keydown", function (e) {
      if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        if (liste.hidden) remplir();
        surligner(actif + (e.key === "ArrowDown" ? 1 : -1));
        e.preventDefault();
      } else if (e.key === "Escape") {
        fermer();
      } else if (e.key === "Enter" && actif >= 0) {
        var o = options()[actif];
        if (o) { e.preventDefault(); location.href = o.href; }
      }
    });
    document.addEventListener("click", function (e) { if (!form.contains(e.target)) fermer(); });
    form.addEventListener("submit", function (e) {
      if (!champ.value.trim()) { e.preventDefault(); champ.focus(); }
    });
  }

  // ------------------------------------------------------------------ la page des resultats
  function pageResultats(zone) {
    var params = new URLSearchParams(location.search);
    var texte = (params.get("q") || "").trim();
    var champs = document.querySelectorAll("form.cherche input");
    for (var i = 0; i < champs.length; i++) champs[i].value = texte;
    var filtre = "tous", tri = "pertinence";
    var barre = el("div", "ch-filtres");
    Object.keys(T.filtres).forEach(function (k) {
      var b = el("button", "ch-filtre" + (k === filtre ? " ch-on" : ""), T.filtres[k]);
      b.type = "button";
      b.onclick = function () { filtre = k; dessiner(); };
      barre.appendChild(b);
    });
    var choix = el("select", "ch-tri");
    choix.setAttribute("aria-label", "Tri");
    Object.keys(T.tri).forEach(function (k) { var o = el("option", "", T.tri[k]); o.value = k; choix.appendChild(o); });
    choix.onchange = function () { tri = choix.value; dessiner(); };
    barre.appendChild(choix);
    var entete = zone.querySelector("h1") || zone.appendChild(el("h1", "ch-h1"));
    var bruit = zone.querySelector("noscript");
    if (bruit) bruit.remove();
    var pages = el("div", "ch-puces ch-pages");
    var grille = el("div", "ch-resultats");
    zone.appendChild(barre);
    zone.appendChild(pages);
    zone.appendChild(grille);
    var trouves = null;
    function dessiner() {
      var bs = barre.querySelectorAll(".ch-filtre");
      Object.keys(T.filtres).forEach(function (k, i) { bs[i].classList.toggle("ch-on", k === filtre); });
      var l = trouves.jeux.filter(function (j) {
        if (filtre === "promo") return j.remise > 0;
        if (filtre === "petit") return j.prix !== null && j.prix !== undefined && j.prix < 10;
        if (filtre === "gratuit") return j.gratuit;
        return true;
      });
      if (tri === "prix") l = l.slice().sort(function (a, b) { return (a.prix === null ? 1e9 : a.prix) - (b.prix === null ? 1e9 : b.prix); });
      if (tri === "remise") l = l.slice().sort(function (a, b) { return b.remise - a.remise; });
      entete.textContent = l.length + " " + (l.length > 1 ? T.resultats : T.resultat) + " « " + texte + " »";
      grille.innerHTML = "";
      if (!l.length) grille.appendChild(el("p", "ch-rien", T.rien));
      l.slice(0, 120).forEach(function (j, i) { grille.appendChild(ligneJeu(j, "r-" + i)); });
    }
    if (!texte) { entete.textContent = T.aucun + " « »"; return; }
    charger().then(function (ix) {
      if (!ix) return;
      trouves = chercher(texte);
      pages.innerHTML = "";
      trouves.pages.slice(0, 6).forEach(function (pg) { var a = el("a", "ch-puce", echap(pg.nom)); a.href = pg.url; pages.appendChild(a); });
      dessiner();
    });
  }

  function demarrer() {
    noterVu();
    var forms = document.querySelectorAll("form.cherche");
    for (var i = 0; i < forms.length; i++) brancher(forms[i]);
    var zone = document.getElementById("resultats-recherche");
    if (zone) pageResultats(zone);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", demarrer);
  else demarrer();
})();
