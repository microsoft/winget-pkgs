package com.orionlauncher.suivi;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;

/**
 * La veille : toutes les trente minutes environ (Android choisit le moment,
 * et attend que le telephone soit en ligne), relit le tableau de suivi et
 * previent s'il y a du nouveau. Survit au redemarrage du telephone.
 * Le travail lui-meme est dans {@link Controle}.
 */
public class Veille extends JobService {
    private static final int NUMERO = 1;
    private static final long PERIODE_MS = 30L * 60L * 1000L;
    private Thread fil;

    static void programmer(Context ctx) {
        JobScheduler planificateur = (JobScheduler) ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (planificateur == null || planificateur.getPendingJob(NUMERO) != null) {
            return;   // deja en place : on ne decale pas son rythme
        }
        JobInfo tache = new JobInfo.Builder(NUMERO, new ComponentName(ctx, Veille.class))
                .setPeriodic(PERIODE_MS)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPersisted(true)
                .build();
        planificateur.schedule(tache);
    }

    static void arreter(Context ctx) {
        JobScheduler planificateur = (JobScheduler) ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (planificateur != null) {
            planificateur.cancel(NUMERO);
        }
    }

    @Override
    public boolean onStartJob(final JobParameters parametres) {
        fil = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Controle.executer(getApplicationContext());
                } catch (RuntimeException e) {
                    // la veille ne doit jamais faire tomber l'application
                } finally {
                    jobFinished(parametres, false);
                }
            }
        }, "veille");
        fil.start();
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters parametres) {
        if (fil != null) {
            fil.interrupt();
        }
        return true;   // a reprendre a la prochaine periode
    }
}
