"""Genere la page publique /sorties du site a partir de sorties.json.

Usage : python gen_sorties.py <dossier du site>
Le contenu est ecrit dans le HTML (lisible par les moteurs de recherche) ;
le script de la page ne fait qu'animer les comptes a rebours.
"""
import datetime as dt
import html
import json
import re
import sys
from pathlib import Path

SITE = "https://orion-launcher.com"

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))


def fr(texte):
    """Le texte de la liste en francais correct, avec les tables de l'application
    elle-meme (orion/langues/fr.json) : 10 octobre, « Precommandes ouvertes » et
    « Acces anticipe : date non annoncee » s'affichaient sans accents sur le
    site, faute d'etre dans la petite table ACCENTS."""
    texte = str(texte or "")
    if not texte:
        return ""
    try:
        from orion import i18n
        if not getattr(fr, "_pret", False):
            fr._pret = i18n.charger("fr")
        if fr._pret:
            return i18n.traduire(texte)
    except Exception:
        pass
    return ACCENTS.get(texte, texte)


def quoi_fr(texte):
    """« Clé Steam PC (Europe) » -> « clé Steam PC (Europe) », a placer apres un nom."""
    t = fr(texte) or "clé PC"
    return t[:1].lower() + t[1:]
EXE = "https://github.com/Sikher-kisa/orion-game-launcher/releases/latest/download/Installateur-ORION.exe"
MOIS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août",
        "septembre", "octobre", "novembre", "décembre"]
PLATEFORMES = {"pc": "PC", "ps5": "PS5", "xbox": "Xbox Series", "switch2": "Switch 2"}
ACCENTS = {"Cle PC Europe (precommande)": "clé PC Europe, précommande",
           "Cle Steam PC (Europe)": "clé Steam PC, Europe",
           "Cle Microsoft Store (PC et Xbox)": "clé Microsoft Store, PC et Xbox",
           "Code PS5 (Europe)": "code PS5, Europe", "Code Xbox Series (Europe)": "code Xbox Series, Europe",
           "Combat aerien": "Combat aérien", "Tir a la troisieme personne": "Tir à la troisième personne",
           "Strategie en temps reel": "Stratégie en temps réel", "Jeu de role": "Jeu de rôle",
           "Date non annoncee": "Date non annoncée"}


def e(t):
    return html.escape(str(t or ""), quote=True)


#: en tete de la page (10 octobre, demande de l'auteur : « des images de jeux,
#: COD, GTA et Zelda en tete »), dans cet ordre
EN_TETE = ("cod-mw4", "gta-6", "zelda-ocarina-of-time")


#: visuels officiels, servis par le site lui-meme (img/sorties/<id>.jpg) : la
#: page n'appelle jamais un tiers (Steam, Rockstar, Nintendo verraient
#: l'adresse des visiteurs). Copies depuis le cache d'ORION, qui les telecharge
#: deja pour l'application.
IMAGES: dict[str, str] = {}


def visuel(s):
    return IMAGES.get(s.get("id", ""), "")


def img(s, classe, chargement="lazy"):
    u = visuel(s)
    if not u:
        return ""
    return (f'<img class="{classe}" src="{e(u)}" alt="{e(s["titre"])}" loading="{chargement}" '
            f'decoding="async" onerror="this.remove()">')


#: identifiants partenaires des revendeurs (les memes que dans l'application,
#: orion/affiliation.py et gen_une.py)
NOMS_REVENDEURS = {"instant-gaming": "Instant Gaming", "kinguin": "Kinguin", "loaded": "Loaded"}


HOTES_REVENDEURS = {"instant-gaming": "https://www.instant-gaming.com/",
                    "kinguin": "https://www.kinguin.net/", "loaded": "https://www.loaded.com/"}


def fiches(s):
    """Attribut du comparateur : les fiches de revendeurs choisies a la main
    (sorties.json, « revendeurs »), en JSON. Toujours present sur la page
    Sorties, meme vide : sans fiche choisie, aucun lien de recherche n'est
    propose (une recherche Instant Gaming tombait sur un homonyme ou sur la
    page d'accueil du site pour un jeu pas encore sorti)."""
    liste = [{"site": r["site"], "url": r["url"], "quoi": quoi_fr(r.get("quoi"))}
             for r in s.get("revendeurs") or []
             if r.get("site") in HOTES_REVENDEURS and str(r.get("url", "")).startswith(HOTES_REVENDEURS[r["site"]])]
    return f' data-revendeurs="{e(json.dumps(liste, ensure_ascii=False))}"'


def boutiques(s):
    """Le bloc « Prix et boutiques » d'une fiche : boutiques officielles d'abord
    (prix IsThereAnyDeal pour un jeu PC, sinon le site officiel du jeu), puis
    les revendeurs. Rien quand il n'y a rien a acheter."""
    pc = bool(s.get("steam")) and "pc" in s.get("plateformes", [])
    if not pc and not s.get("revendeurs"):
        return ""
    b = s.get("boutique") if isinstance(s.get("boutique"), dict) else {}
    if str(b.get("url", "")).startswith("https://") and b.get("nom"):
        officiels = [{"nom": str(b["nom"]), "url": b["url"]}]          # la boutique de l'editeur
    else:
        officiels = [] if pc else ([{"nom": "Site officiel du jeu", "url": s["lien"]}] if s.get("lien") else [])
    appid = f' data-appid="{e(s["steam"])}"' if pc else ""
    return (f'<div class="cmp-carte" data-comparatif{appid} data-titre="{e(s["titre"])}" '
            f'data-officiels="{e(json.dumps(officiels, ensure_ascii=False))}"{fiches(s)}></div>')


def partenaire(site, url):
    from urllib.parse import quote
    if site == "instant-gaming":
        return url + ("&" if "?" in url else "?") + "igr=Sikher"
    if site == "kinguin":
        return url + ("&" if "?" in url else "?") + "r=w0405u433koc0"
    if site == "loaded":
        return "https://go.loaded.com/xJDad5?u=" + quote(url, safe="")
    return url


def chemin_fiche(s):
    """Page d'une sortie (11 octobre, referencement) : la page dediee quand
    elle existe (Modern Warfare 4), sinon /sorties/<titre> (gen_evenements)."""
    page = str(s.get("page") or "")
    if page.startswith("/"):
        return page
    from gen_jeux import slug
    return f"/sorties/{slug(s['titre'])}"


def date_fr(d):
    return f"{d.day}{'er' if d.day == 1 else ''} {MOIS[d.month - 1]} {d.year}"


def main(dossier):
    dossier = Path(dossier)
    donnees = json.loads((dossier / "sorties.json").read_text(encoding="utf-8"))
    IMAGES.clear()
    for f in sorted((dossier / "img" / "sorties").glob("*")):
        if f.suffix.lower() in (".jpg", ".jpeg", ".webp", ".png") and f.stat().st_size > 1000:
            IMAGES.setdefault(f.stem, f"/img/sorties/{f.name}")
    auj = dt.date.today()
    dates, sans = [], []
    for s in donnees["sorties"]:
        if s.get("date"):
            d = dt.date.fromisoformat(s["date"])
            if (auj - d).days <= 3:
                dates.append((d, s))
        else:
            sans.append(s)
    dates.sort(key=lambda x: x[0])
    avenir = [x for x in dates if x[0] >= auj]
    vedette = max(avenir, key=lambda x: x[1].get("attente", 0)) if avenir else None
    # « a la une » (2.1.0) : comme dans l'application, choisie par l'auteur,
    # jusqu'a trois jours apres sa sortie
    unes = [x for x in dates if x[1].get("une")]
    if unes:
        vedette = min(unes, key=lambda x: x[0])

    def plats(s):
        return " · ".join(PLATEFORMES.get(p, p) for p in s.get("plateformes", [])) or "Plateformes à confirmer"

    def carte(d, s):
        c1, c2 = (s.get("couleurs") or ["#38E1FF", "#0E141C"])[:2]
        genre = fr(s.get("genre", ""))
        lien = f'<a href="{e(s["lien"])}" rel="noopener nofollow">Site officiel</a>' if s.get("lien") else ""
        source = f'<a href="{e(s["source"])}" rel="noopener nofollow">Source de la date</a>' if s.get("source") else ""
        if d is not None:
            quand = (f'<p class="quand"><time datetime="{d.isoformat()}">{date_fr(d)}</time>'
                     f' <span class="decompte mono" data-date="{d.isoformat()}">'
                     f'{"Sorti" if d < auj else "Dans " + str((d - auj).days) + " jours"}</span></p>')
        else:
            quand = (f'<p class="quand">{e(fr(s.get("fenetre", "")))}'
                     f' <span class="decompte mono">Pas encore de date</span></p>')
        # sans visuel : un aplat aux couleurs du jeu, pour que toutes les fiches
        # aient la meme allure (10 octobre : Stranger Than Heaven sans image)
        visuel = img(s, "vignette") or (f'<div class="vignette sans-image" aria-hidden="true">'
                                        f'<span>{e(s["titre"])}</span></div>')
        return (f'<article class="sortie" id="{e(s["id"])}" data-p="{e(" ".join(s.get("plateformes", [])))}" '
                f'style="--c1:{e(c1)};--c2:{e(c2)}">'
                f'<div class="bande"></div>{visuel}'
                f'<div class="infos"><h3><a href="{e(chemin_fiche(s))}">{e(s["titre"])}</a></h3>{quand}'
                f'<p class="meta">{e(plats(s))}</p>'
                f'<p class="meta">{e(s.get("studio", ""))}{" · " + e(genre) if genre else ""}</p>'
                f'<p class="liens">{lien}{" · " if lien and source else ""}{source}</p></div>'
                f'{boutiques(s)}</article>')

    # un intertitre par mois : « sorties jeux video novembre 2026 » est une recherche a part
    par_mois: dict[tuple[int, int], list] = {}
    for d, s in dates:
        par_mois.setdefault((d.year, d.month), []).append((d, s))
    cartes = "\n".join(
        f'<section class="mois" id="{a}-{m:02d}"><h2>{MOIS[m - 1].capitalize()} {a} '
        f'<small>{len(lot)} jeu{"x" if len(lot) > 1 else ""}</small></h2>\n<div class="grille-sorties">\n'
        + "\n".join(carte(d, s) for d, s in lot) + "\n</div></section>"
        for (a, m), lot in par_mois.items())
    sauts = "".join(f'<a href="#{a}-{m:02d}">{MOIS[m - 1].capitalize()} {a}</a>' for a, m in par_mois)
    presentes = [p for p in PLATEFORMES if any(p in s.get("plateformes", []) for _, s in dates)]
    puces = ('<button type="button" class="puce actif" data-p="" aria-pressed="true">Toutes</button>'
             + "".join(f'<button type="button" class="puce" data-p="{p}" aria-pressed="false">{PLATEFORMES[p]}</button>'
                       for p in presentes))
    cartes_sans = "\n".join(carte(None, s) for s in sans)

    tous = {s["id"]: (d, s) for d, s in dates} | {s["id"]: (None, s) for s in sans}
    tuiles = []
    for ident in EN_TETE:
        if ident not in tous or (vedette and vedette[1].get("id") == ident):
            continue            # deja en grand juste au-dessus
        d, s = tous[ident]
        if d is not None and d < auj - dt.timedelta(days=3):
            continue
        cible = chemin_fiche(s)
        quand = (f'<time datetime="{d.isoformat()}">{date_fr(d)}</time>' if d is not None
                 else e(fr(s.get("fenetre", ""))))
        compte = (f'<span class="decompte mono" data-date="{d.isoformat()}">'
                  f'{"Sorti" if d < auj else "Dans " + str((d - auj).days) + " jours"}</span>' if d is not None else "")
        c1, c2 = (s.get("couleurs") or ["#38E1FF", "#0E141C"])[:2]
        tuiles.append(f'<a class="tuile" href="{e(cible)}" style="--c1:{e(c1)};--c2:{e(c2)}">'
                      f'{img(s, "fond-tuile", "eager")}<span class="voile"></span>'
                      f'<span class="texte"><b>{e(s["titre"])}</b><span>{quand} · {e(plats(s))}</span>{compte}</span></a>')
    trio = (f'<div class="trio" aria-label="A ne pas manquer">{"".join(tuiles)}</div>' if tuiles else "")

    hero = ""
    if vedette:
        d, s = vedette
        hero = (f'<div class="vedette" style="--c1:{e(s["couleurs"][0])};--c2:{e(s["couleurs"][1])}">'
                f'{img(s, "fond-vedette", "eager")}'
                f'<p class="eyebrow">{"À la une" if s.get("une") else "La sortie la plus attendue"}</p>'
                f'<h2>{e(s["titre"])}</h2>'
                f'<p class="quand">Sortie le <time datetime="{d.isoformat()}">{date_fr(d)}</time> · {e(plats(s))}</p>'
                + (f'<p class="mot">{e(fr(s["mot"]))}</p>' if s.get("mot") else "") +
                f'<p class="gros mono" data-date="{d.isoformat()}" data-detail="1">Dans {(d - auj).days} jours</p>'
                + (f'<p><a class="btn" href="{e(s["page"])}">Précommande PC et prix du moment</a></p>'
                   if str(s.get("page") or "").startswith("/") else "") +
                f'</div>') + trio

    # FAQ : une question par jeu tres attendu, reponse tiree des memes donnees
    faq = []
    for d, s in sorted(avenir, key=lambda x: -x[1].get("attente", 0))[:6]:
        faq.append((f"Quand sort {s['titre']} ?",
                    f"{s['titre']} sort le {date_fr(d)} sur {plats(s).replace(' · ', ', ')}."))
    faq_html = "\n".join(f"<details><summary>{e(q)}</summary><p>{e(r)}</p></details>" for q, r in faq)

    ld = [
        {"@context": "https://schema.org", "@type": "ItemList",
         "name": "Calendrier des sorties de jeux vidéo",
         "itemListElement": [
             {"@type": "ListItem", "position": i + 1,
              "item": {"@type": "VideoGame", "name": s["titre"], "datePublished": d.isoformat(),
                       "gamePlatform": [PLATEFORMES.get(p, p) for p in s.get("plateformes", [])],
                       "author": {"@type": "Organization", "name": s.get("studio", "")},
                       "url": f"{SITE}/sorties#{s['id']}"}}
             for i, (d, s) in enumerate(avenir)]},
        {"@context": "https://schema.org", "@type": "FAQPage",
         "mainEntity": [{"@type": "Question", "name": q,
                         "acceptedAnswer": {"@type": "Answer", "text": r}} for q, r in faq]},
        {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [
            {"@type": "ListItem", "position": 1, "name": "ORION", "item": SITE + "/"},
            {"@type": "ListItem", "position": 2, "name": "Sorties", "item": SITE + "/sorties"}]},
    ]
    ld_html = "\n".join('<script type="application/ld+json">' + json.dumps(x, ensure_ascii=False) + "</script>"
                        for x in ld)

    noms = [s["titre"] for _, s in sorted(avenir, key=lambda x: -x[1].get("attente", 0))[:3]]
    annees = sorted({d.year for d, _ in avenir})
    plage = "-".join(str(a) for a in (annees[0], annees[-1])) if len(annees) > 1 else str(annees[0])
    titre = f"Calendrier des sorties jeux vidéo {plage} : toutes les dates"
    # 155 caracteres au plus : au-dela, le moteur de recherche coupe la phrase
    desc = (f"Calendrier des sorties jeux vidéo {plage} sur PC, PS5, Xbox et Switch 2 : les dates mois par "
            f"mois, avec compte à rebours et source.")
    for nom in noms:
        if len(desc) + len(nom) + 2 <= 155:
            desc += (" " if desc.endswith(".") else ", ") + nom
    desc = desc.rstrip(".") + "."

    # la feuille de style du site est reprise telle quelle depuis la page d'accueil
    accueil = (dossier / "index.html").read_text(encoding="utf-8")
    style = re.search(r"<style>(.*?)</style>", accueil, re.S).group(1)

    page = f"""<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<script>if(/\.pages\.dev$/.test(location.hostname)){{location.replace("https://orion-launcher.com"+location.pathname+location.hash);}}</script>
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>{e(titre)}</title>
<meta name="description" content="{e(desc)}">
<meta name="robots" content="index, follow, max-image-preview:large">
<link rel="canonical" href="{SITE}/sorties">
<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="icon" type="image/png" href="/img/logo.png">
<meta name="theme-color" content="#0C1122">
<meta property="og:type" content="website">
<meta property="og:site_name" content="ORION Game Launcher">
<meta property="og:locale" content="fr_FR">
<meta property="og:url" content="{SITE}/sorties">
<meta property="og:title" content="{e(titre)}">
<meta property="og:description" content="{e(desc)}">
<meta property="og:image" content="{SITE}/img/og.jpg">
<meta name="twitter:card" content="summary_large_image">
{ld_html}
<link rel="preload" href="/polices/bricolage.woff2" as="font" type="font/woff2" crossorigin>
<style>{style}
  /* ---------- page Sorties ---------- */
  .tete{{padding-block:54px 26px;}}
  .tete h1{{font-size:clamp(32px,5.4vw,58px);line-height:1.02;font-weight:800;margin-top:10px;}}
  .tete .lede{{color:var(--dim);max-width:65ch;margin-top:14px;font-size:18px;}}
  .vedette{{
    margin-top:30px;padding:30px 26px;border-radius:var(--radius);
    border:1px solid var(--line-hi);
    background:linear-gradient(120deg,color-mix(in srgb,var(--c1) 26%,var(--panel)),var(--panel) 62%);
  }}
  .vedette{{position:relative;overflow:hidden;}}
  .vedette > *{{position:relative;}}
  .vedette .fond-vedette{{position:absolute;inset:0 0 0 auto;width:min(58%,560px);height:100%;object-fit:cover;
    -webkit-mask-image:linear-gradient(90deg,transparent,#000 45%);mask-image:linear-gradient(90deg,transparent,#000 45%);opacity:.85;}}
  .trio{{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-top:16px;}}
  .tuile{{position:relative;display:block;aspect-ratio:16/9;border-radius:var(--radius);overflow:hidden;
    border:1px solid var(--line-hi);background:linear-gradient(135deg,var(--c1),var(--c2));color:var(--ink);text-decoration:none;}}
  .tuile .fond-tuile{{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;transition:transform .4s;}}
  .tuile:hover .fond-tuile{{transform:scale(1.04);}}
  .tuile .voile{{position:absolute;inset:0;background:linear-gradient(transparent 35%,rgba(6,9,16,.92));}}
  .tuile .texte{{position:absolute;left:14px;right:14px;bottom:12px;display:flex;flex-direction:column;gap:2px;}}
  .tuile b{{font-size:18px;line-height:1.2;}}
  .tuile .texte span{{font-size:13.5px;color:#D6DCE8;}}
  .tuile .decompte{{color:var(--accent);}}
  @media (max-width:720px){{.trio{{grid-template-columns:1fr;}}}}
  .trio{{grid-template-columns:repeat(auto-fit,minmax(260px,1fr));}}
  .vedette h2{{font-size:clamp(26px,4.4vw,42px);margin-top:8px;}}
  .vedette .quand{{color:var(--dim);margin-top:6px;}}
  .vedette .mot{{color:var(--ink);font-style:italic;margin-top:10px;max-width:60ch;}}
  .vedette .gros{{font-size:clamp(22px,4.6vw,40px);color:var(--ink);margin-top:16px;font-variant-numeric:tabular-nums;}}
  .grille-sorties{{display:grid;grid-template-columns:minmax(0,1fr);gap:12px;margin-top:22px;}}
  .sortie{{display:grid;grid-template-columns:6px 230px minmax(0,1fr);grid-template-rows:auto auto;
    background:var(--panel);border:1px solid var(--line);border-radius:var(--radius);overflow:hidden;}}
  .sortie .bande{{grid-column:1;grid-row:1/span 2;background:linear-gradient(var(--c1),var(--c2));}}
  .sortie .vignette{{grid-column:2;grid-row:1/span 2;align-self:start;display:block;width:calc(100% - 14px);
    max-width:none;height:auto;aspect-ratio:460/215;margin:14px 0 14px 14px;border-radius:10px;object-fit:cover;}}
  .sortie .sans-image{{display:flex;align-items:flex-end;padding:12px 14px;color:#fff;font-weight:700;
    font-size:15px;line-height:1.25;background:linear-gradient(135deg,var(--c1),var(--c2));}}
  .sortie .infos{{grid-column:3;grid-row:1;padding:14px 18px 6px;display:flex;flex-direction:column;gap:3px;min-width:0;}}
  .sortie h3{{font-size:18px;line-height:1.25;}}
  .sortie h3 a{{color:inherit;text-decoration:none;}}
  .sortie h3 a:hover{{text-decoration:underline;}}
  .sortie .quand{{color:var(--ink);font-weight:600;}}
  .sortie .decompte{{color:var(--accent);font-weight:500;font-size:14px;margin-left:8px;font-variant-numeric:tabular-nums;}}
  .sortie .meta{{color:var(--dim);font-size:14.5px;}}
  .sortie .liens{{font-size:13.5px;padding-top:2px;}}
  .sortie .cmp-carte{{grid-column:3;grid-row:2;padding:0 18px 14px;min-width:0;}}
  @media (max-width:640px){{
    .sortie{{grid-template-columns:6px minmax(0,1fr);grid-template-rows:auto auto auto;}}
    .sortie .bande{{grid-row:1/span 3;}}
    .sortie .vignette{{grid-column:2;grid-row:1;width:calc(100% - 28px);margin:14px 14px 0;}}
    .sortie .infos{{grid-column:2;grid-row:2;}}
    .sortie .cmp-carte{{grid-column:2;grid-row:3;}}
  }}
  .mention{{color:var(--dim);font-size:13.5px;margin-top:14px;max-width:80ch;}}
  .filtres,.sauts{{display:flex;flex-wrap:wrap;gap:8px;margin-top:18px;}}
  .puce{{font:inherit;color:var(--dim);background:var(--panel);border:1px solid var(--line);
    border-radius:999px;padding:7px 15px;cursor:pointer;}}
  .puce.actif{{color:var(--ink);border-color:var(--accent);}}
  .sauts a{{font-size:14.5px;color:var(--dim);}}
  .sauts a::after{{content:"·";margin-left:8px;color:var(--line-hi);}}
  .sauts a:last-child::after{{content:"";}}
  .mois{{margin-top:34px;scroll-margin-top:84px;}}
  .mois h2{{font-size:clamp(20px,3vw,26px);}}
  .mois h2 small{{font-size:15px;font-weight:400;color:var(--dim);margin-left:8px;}}
  .mois .grille-sorties{{margin-top:14px;}}
  .vide{{color:var(--dim);margin-top:22px;}}
  [hidden]{{display:none!important;}}
  .bloc{{padding-block:34px;border-top:1px solid var(--line);margin-top:40px;}}
  .bloc h2{{font-size:clamp(22px,3.2vw,30px);}}
  .bloc > p{{color:var(--dim);max-width:65ch;margin-top:10px;}}
  .appel{{display:flex;flex-wrap:wrap;gap:14px;align-items:center;margin-top:18px;}}
  details{{border-bottom:1px solid var(--line);padding-block:12px;max-width:70ch;}}
  summary{{cursor:pointer;font-weight:600;}}
  details p{{color:var(--dim);margin-top:8px;}}
</style>
</head>
<body>

<header class="nav">
  <div class="wrap nav-in">
    <a class="brand" href="/"><img src="/img/logo.png" alt="" width="30" height="30"><b>ORION</b></a>
    <nav>
      <a href="/">Le launcher</a>
      <a href="/jeux">Configs des jeux</a>
      <a href="/sorties" aria-current="page">Sorties</a>
      <a href="/#faq">FAQ</a>
    </nav>
    <span class="sp"></span>
    <a class="btn" href="/#installer">Télécharger</a>
  </div>
</header>

<main class="wrap">
  <div class="tete">
    <p class="eyebrow">Calendrier · PC, PS5, Xbox, Switch 2</p>
    <h1>Sorties jeux vidéo <span style="white-space:nowrap">{plage}</span> : le calendrier</h1>
    <p class="lede">Les dates de sortie des jeux les plus attendus, mois par mois, avec le compte
      à rebours de chacun. La liste se renouvelle d'elle-même : un jeu sorti laisse sa place au suivant.
      Mise à jour le {date_fr(auj)}.</p>
    {hero}
  </div>

  <section>
    <p class="eyebrow">Dates confirmées</p>
    <div class="filtres" role="group" aria-label="Filtrer par plateforme">{puces}</div>
    <nav class="sauts" aria-label="Aller à un mois">{sauts}</nav>
    <p class="mention">« Prix et boutiques » montre d'abord les boutiques officielles et les vendeurs
      agréés, puis les revendeurs de clés. Les liens Instant Gaming, Kinguin et Loaded sont des liens
      partenaires : ils financent ORION sans changer votre prix.</p>
    <p class="vide" id="aucun" hidden>Aucune sortie datée sur cette plateforme pour l'instant.</p>
{cartes}
  </section>

  <section class="bloc">
    <p class="eyebrow">Sans date précise</p>
    <h2>Annoncés, pas encore datés</h2>
    <div class="grille-sorties">
{cartes_sans}
    </div>
  </section>

  <section class="bloc">
    <p class="eyebrow">Dans l'application</p>
    <h2>Ce calendrier, à côté de vos jeux</h2>
    <p>ORION est un launcher gratuit pour Windows. Il réunit vos jeux Steam, Epic, GOG, Xbox,
      Ubisoft, EA et Battle.net, choisit les réglages graphiques adaptés à votre PC, et affiche
      cette page Sorties avec les jeux Steam les plus suivis en plus. Sans compte, sans publicité.</p>
    <div class="appel">
      <a class="btn" href="{EXE}">Télécharger ORION pour Windows</a>
      <a class="btn ghost" href="/">Découvrir le launcher</a>
    </div>
  </section>

  <section class="bloc">
    <p class="eyebrow">Questions fréquentes</p>
    <h2>Les dates en une phrase</h2>
{faq_html}
    <details><summary>D'où viennent ces dates ?</summary><p>Chaque date vient d'une annonce de
      l'éditeur ou d'un article de presse spécialisée, en lien sous chaque jeu. Une date peut
      être repoussée : la liste est alors corrigée.</p></details>
  </section>
</main>

<footer>
  <div class="wrap foot">
    <span class="sign">ORION lit votre PC et vous dit quoi jouer, avec quels réglages, à quel prix.</span>
    <span class="sp"></span>
    <nav aria-label="Liens du pied de page">
      <a href="/">Accueil</a>
      <a href="/versions">Journal des versions</a>
      <a href="/comparatif">Comparatif</a>
      <a href="/presse">Presse</a>
      <a href="/ce-qu-orion-envoie">Ce qu'ORION envoie</a>
      <a href="/mentions-legales">Mentions légales</a>
    </nav>
  </div>
</footer>

<script>
(function(){{
  function maj(){{
    var maintenant = new Date();
    document.querySelectorAll("[data-date]").forEach(function(el){{
      var p = el.getAttribute("data-date").split("-");
      var cible = new Date(+p[0], +p[1]-1, +p[2]);
      var ms = cible - maintenant;
      if (ms <= 0) {{ el.textContent = ms > -864e5 ? "Sort aujourd'hui" : "Sorti"; return; }}
      var j = Math.floor(ms/864e5), h = Math.floor(ms%864e5/36e5),
          m = Math.floor(ms%36e5/6e4), s = Math.floor(ms%6e4/1e3);
      if (el.getAttribute("data-detail")) {{
        el.textContent = j + " j " + ("0"+h).slice(-2) + " h " + ("0"+m).slice(-2) + " min " + ("0"+s).slice(-2) + " s";
      }} else {{
        el.textContent = j > 0 ? "Dans " + j + " jour" + (j > 1 ? "s" : "") + " " + h + " h" : "Dans " + h + " h " + m + " min";
      }}
    }});
  }}
  maj(); setInterval(maj, 1000);

  // filtre par plateforme : les jeux et les mois sans rien a montrer sont masques
  var puces = document.querySelectorAll(".puce");
  function filtrer(p){{
    var restants = 0;
    document.querySelectorAll(".sortie").forEach(function(c){{
      var garde = !p || (" " + (c.getAttribute("data-p") || "") + " ").indexOf(" " + p + " ") >= 0;
      c.hidden = !garde;
    }});
    document.querySelectorAll(".mois").forEach(function(m){{
      var n = m.querySelectorAll(".sortie:not([hidden])").length;
      m.hidden = !n; restants += n;
      var lien = document.querySelector('.sauts a[href="#' + m.id + '"]');
      if (lien) lien.hidden = !n;
    }});
    document.getElementById("aucun").hidden = restants > 0;
    puces.forEach(function(b){{
      var actif = b.getAttribute("data-p") === p;
      b.classList.toggle("actif", actif); b.setAttribute("aria-pressed", actif ? "true" : "false");
    }});
  }}
  puces.forEach(function(b){{ b.addEventListener("click", function(){{ filtrer(b.getAttribute("data-p")); }}); }});
}})();
</script>
<script src="/glisse.js" defer></script>
<script src="/clic.js" defer></script>
<script src="/comparatif.js" defer></script>
</body>
</html>
"""
    (dossier / "sorties.html").write_text(page, encoding="utf-8")

    plan = dossier / "sitemap.xml"
    x = plan.read_text(encoding="utf-8")
    if "/sorties<" not in x:
        x = x.replace("  <url>\n    <loc>" + SITE + "/mentions-legales",
                      f"  <url>\n    <loc>{SITE}/sorties</loc>\n    <lastmod>{auj.isoformat()}</lastmod>\n"
                      "    <changefreq>weekly</changefreq>\n    <priority>0.9</priority>\n  </url>\n"
                      "  <url>\n    <loc>" + SITE + "/mentions-legales")
    x = re.sub(r"<lastmod>[^<]+</lastmod>", f"<lastmod>{auj.isoformat()}</lastmod>", x)
    plan.write_text(x, encoding="utf-8")
    print("sorties.html", len(page), "octets ;", len(dates), "dates,", len(sans), "sans date")


if __name__ == "__main__":
    main(sys.argv[1])
