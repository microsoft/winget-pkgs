"""English pages (2.0.2) : /en/ (landing) and /en/what-orion-sends.

The English landing keeps the French home page's head (styles, icons) and
its classes, with a shorter body written for an English-speaking player.
Version, size and SHA-256 are read from the French home page, so one
publication script updates both. hreflang links go both ways.

Usage : python gen_en.py <dossier du site>
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

SITE = "https://orion-launcher.com"


def _tete(index_fr: str, titre: str, desc: str, chemin: str, fr: str) -> str:
    tete = index_fr[:index_fr.index("<body")]
    tete = tete.replace('<html lang="fr">', '<html lang="en">')
    tete = re.sub(r"<title>.*?</title>", f"<title>{titre}</title>", tete, count=1, flags=re.S)
    tete = re.sub(r'<meta name="description" content="[^"]*">', f'<meta name="description" content="{desc}">', tete, count=1)
    tete = re.sub(r'<link rel="canonical" href="[^"]*">',
                  f'<link rel="canonical" href="{SITE}{chemin}">\n'
                  f'<link rel="alternate" hreflang="fr" href="{SITE}{fr}">\n'
                  f'<link rel="alternate" hreflang="en" href="{SITE}{chemin}">\n'
                  f'<link rel="alternate" hreflang="x-default" href="{SITE}{fr}">', tete, count=1)
    tete = re.sub(r'<meta property="og:locale" content="[^"]*">', '<meta property="og:locale" content="en_US">', tete)
    tete = re.sub(r'<meta property="og:url" content="[^"]*">', f'<meta property="og:url" content="{SITE}{chemin}">', tete)
    tete = re.sub(r'<meta property="og:title" content="[^"]*">', f'<meta property="og:title" content="{titre}">', tete)
    tete = re.sub(r'<meta property="og:description" content="[^"]*">', f'<meta property="og:description" content="{desc}">', tete)
    tete = re.sub(r'<script type="application/ld\+json">.*?</script>\n?', "", tete, flags=re.S)
    return tete


def _faits(index_fr: str) -> dict:
    v = re.search(r"Version (\d+\.\d+(?:\.\d+)?), Windows 10 et 11 en 64 bits, (\d+) Mo", index_fr)
    h = re.search(r'<p class="hash">([0-9a-f]{64})</p>', index_fr)
    return {"version": v.group(1) if v else "", "taille": v.group(2) if v else "",
            "hash": h.group(1) if h else ""}


def page_accueil(index_fr: str) -> str:
    f = _faits(index_fr)
    # 11 octobre (audit) : 98 et 240 signes, coupes par les moteurs
    tete = _tete(index_fr, "ORION Game Launcher: free PC game launcher for Windows",
                 "Free PC game launcher: Steam, Epic, GOG, Xbox, Ubisoft, EA and Battle.net in one library, the right "
                 "settings for your PC, drivers and the best price.", "/en/", "/")
    corps = f"""<body>
<header class="nav">
  <div class="wrap nav-in">
    <a class="brand" href="#haut"><img src="/img/logo.png" alt="" width="30" height="30"><b>ORION</b></a>
    <nav aria-label="Page sections">
      <a href="#what">What it does</a>
      <a href="#drivers">Drivers</a>
      <a href="#faq">Questions</a>
      <a href="/" lang="fr">Français</a>
    </nav>
    <span class="sp"></span>
    <a class="btn" href="#installer">Download</a>
  </div>
</header>

<main id="haut">
  <div class="hero">
    <div class="wrap">
      <h1>Your PC can do more than you think.</h1>
      <p class="lede">ORION reads your PC and tells you what to play, with which settings, at what price.
        All your games in one place, what your machine can run game by game, outdated drivers,
        and the real best price.</p>
      <div class="cta">
        <a class="btn" href="https://github.com/Sikher-kisa/orion-game-launcher/releases/latest/download/Installateur-ORION.exe">Download for Windows</a>
        <a class="btn ghost" href="https://apps.microsoft.com/detail/9P91GMXV7FPW" rel="noopener">Microsoft Store</a>
      </div>
      <p class="sous-cta">Free, no account, no ads. Version {f['version']} for Windows 10 and 11. Interface in English and French.</p>
      <figure class="capture">
        <div class="cadre"><img src="/img/2-0/bibliotheque.jpg" width="1600" height="976" alt="ORION's library: the last game played as a banner, then the covers of every game on the PC, from every store."></div>
        <figcaption>The library, on the author's own machine. Every screenshot on this page comes from a real install.</figcaption>
      </figure>
    </div>
  </div>

  <section class="wrap partie" id="what" aria-labelledby="t-what">
    <h2 id="t-what">Seven stores, and nobody to tell you what your machine can do.</h2>
    <div class="prose">
      <p>A PC gamer today has Steam, Epic, GOG, Ubisoft Connect, the EA app, Battle.net, the Microsoft Store, and a few
        games dropped in a folder by hand. Nobody knows what is installed anymore, or where. And with every new game,
        the same ritual: open the options, guess what each slider costs, look for a guide, test, start over. Meanwhile
        the 180&nbsp;Hz display runs at 60 and the graphics card uses half of what it can do.</p>
      <p>ORION does not replace Steam or Epic. It sits on top of them, reads your machine, and does the thinking.</p>
    </div>
    <div class="prose" style="margin-top:18px">
      <p><b>One library.</b> Steam, Epic Games, GOG, Xbox, Ubisoft, EA, Battle.net and Ankama games found on your drives,
        plus the ones you own but haven't installed. One click to play; the owning launcher starts if the game needs it.</p>
      <p><b>What your PC can run, game by game.</b> For each game, the highest settings level that stays smooth on your
        hardware and the expected frame rate, estimated from the publisher's requirements, corrected by real measurements
        shared by players with a similar graphics card, and by your own measurements once you play.</p>
      <p><b>Settings written for you.</b> ORION writes each game's graphics settings for your card and your display,
        after a backup you can restore in one click. When a game won't let anyone touch its settings, it shows you what
        to pick in its menus, line by line, in plain words.</p>
      <p><b>Real prices, done properly.</b> Thirty-plus approved stores compared (IsThereAnyDeal data), the free games of the
        moment, a wishlist that warns you when a game drops. Official stores come first; three long-proven key resellers
        (Instant Gaming, Kinguin, Loaded) are shown apart, with a visible rule (Steam key, Global region or your own country's, never "gift" or "account" keys).</p>
      <p><b>The big upcoming releases</b>, on PC and consoles, with their countdowns.</p>
      <p><b>Your PC, in one minute.</b> Right after the first install: how many of your games run at High quality, how many
        drivers need an update, what your library is worth, and whether wishlisted games dropped in price. An image to
        share ("My PC runs 38 of my 52 games at High quality") is one click away.</p>
    </div>
    <figure class="capture" style="margin-top:22px">
      <div class="cadre"><img src="/img/2-0/ma-machine.jpg" width="1600" height="976" alt="The My machine page: for each game, the settings level that stays smooth and the expected frame rate." loading="lazy"></div>
      <figcaption>My machine: what the PC runs, game by game, before you buy.</figcaption>
    </figure>
  </section>

  <section class="wrap partie" id="drivers" aria-labelledby="t-drivers">
    <h2 id="t-drivers">The right drivers, by hardware ID.</h2>
    <div class="prose">
      <p>ORION identifies every chip by its hardware ID, not by its translated name. It checks what Windows Update
        offers as optional drivers, knows the latest NVIDIA version for your card series, and, on a Dell, Lenovo or HP PC,
        reads the manufacturer's driver catalog for your exact model — the same source Dell Command Update, Lenovo System
        Update and HP Image Assistant use. The advice names the version you have, the version published for your model,
        its date, and the official page.</p>
      <p>ORION only says "newer version available" when a source proves it, and it never installs a driver itself: you
        keep control.</p>
    </div>
  </section>

  <section class="wrap partie" id="garanties" aria-labelledby="t-garanties">
    <h2 id="t-garanties">What ORION does not do.</h2>
    <div class="prose">
      <p>No account to create. No ads. Nothing sent without your consent: a single question, asked once, lets you share
        anonymous performance measurements and an anonymous usage counter — and if you say no, ORION works exactly the
        same. Your games, your files, your name: none of it leaves your PC. The page
        <a href="/en/what-orion-sends">What ORION sends</a> lists everything.</p>
      <p>No cheats, no "boosters", no registry tricks. ORION changes a game's settings only when you ask, after a backup.
        It never touches your other launchers' libraries.</p>
    </div>
  </section>

  <section class="wrap partie" id="financement" aria-labelledby="t-argent">
    <h2 id="t-argent">Where the money comes from.</h2>
    <div class="prose">
      <p>ORION is free. It is funded by donations and by partner links to some stores: if you buy after clicking one, the
        store may pay the author a commission. The price you pay is the same, and these links never change the order of
        the offers. No paid placement, ever.</p>
    </div>
  </section>

  <section class="wrap partie" id="installer" aria-labelledby="t-installer">
    <h2 id="t-installer">Install ORION.</h2>
    <div class="dl">
      <div class="row">
        <a class="btn" href="https://github.com/Sikher-kisa/orion-game-launcher/releases/latest/download/Installateur-ORION.exe">Download Installateur-ORION.exe</a>
        <a class="btn ghost" href="https://apps.microsoft.com/detail/9P91GMXV7FPW" rel="noopener">From the Microsoft Store</a>
      </div>
      <p class="meta">Version {f['version']}, Windows 10 and 11, 64-bit, {f['taille']} MB. The file is hosted on GitHub, with
        <a href="https://github.com/Sikher-kisa/orion-game-launcher/releases" rel="noopener">every version</a>.
        Coming soon to winget: the package is awaiting Microsoft's review.</p>
      <p class="warn"><b>On first launch, Windows may show "Windows protected your PC".</b> The installer is not
        code-signed yet (a certificate costs real money every year, which a free project does not commit to at the start).
        Click "More info", then "Run anyway". To avoid the warning, install from the
        <a href="https://apps.microsoft.com/detail/9P91GMXV7FPW" rel="noopener">Microsoft Store</a>.</p>
      <p class="meta">SHA-256 fingerprint, to check the file has not been altered:</p>
      <p class="hash">{f['hash']}</p>
    </div>
    <ol class="steps">
      <li>Download <b>Installateur-ORION.exe</b>.</li>
      <li>Double-click it: a window asks for the folder and offers a desktop shortcut. No administrator rights needed.</li>
      <li>ORION starts, reads the machine and finds your games. Allow about fifteen seconds the first time.</li>
    </ol>
    <div class="prose" style="margin-top:22px">
      <p>The program installs into <code>%LOCALAPPDATA%\\Programs\\ORION</code>, its data into
        <code>%LOCALAPPDATA%\\ORION</code>. Nothing anywhere else. Uninstall from Windows' "Installed apps"; it offers to
        keep or remove your library. ORION then updates itself: it offers each new version, verifies its fingerprint,
        and restarts. Library, settings and backups are kept.</p>
    </div>
  </section>

  <section class="wrap partie" id="faq" aria-labelledby="t-faq">
    <h2 id="t-faq">Questions.</h2>
    <div class="prose">
      <details><summary>Does it work with my games?</summary><p>If they come from Steam, Epic Games, GOG, Xbox, Ubisoft,
        EA, Battle.net or Ankama, or sit in a folder you add, yes. Settings are written for the engines and games ORION
        knows (Unreal, Unity, Source, Cyberpunk 2077 and many others); for the rest, it tells you what to pick in the
        game's own menus.</p></details>
      <details><summary>Will it break my games?</summary><p>Every change is made after a backup of the game's own
        settings file, and one button restores it. ORION never modifies a game's program files.</p></details>
      <details><summary>Does it install drivers?</summary><p>No. It tells you which driver is outdated, which version is
        published for your hardware, and gives the official page. You decide.</p></details>
      <details><summary>Is it really free?</summary><p>Yes, with no locked features. Donations and partner links fund it;
        prices never change for you, and no store pays for its place.</p></details>
      <details><summary>What does it send?</summary><p>Nothing identifying, and nothing at all without your consent.
        See <a href="/en/what-orion-sends">What ORION sends</a>.</p></details>
      <details><summary>Is the French site the same?</summary><p>The French site has more: 1,500+ game pages with "can
        it run on my PC", release calendar, driver pages by PC model, version journal. The app itself is fully in English
        (Settings &gt; Language).</p></details>
    </div>
  </section>
</main>

<footer>
  <div class="wrap foot">
    <span class="sign">ORION reads your PC and tells you what to play, with which settings, at what price.</span>
    <span class="sp"></span>
    <nav aria-label="Footer links">
      <a href="https://github.com/Sikher-kisa/orion-game-launcher/releases" rel="noopener">Releases</a>
      <a href="https://github.com/Sikher-kisa/orion-game-launcher/issues" rel="noopener">Report a problem</a>
      <a href="https://paypal.me/FoxSikh" rel="nofollow noopener">Donate</a>
      <a href="/en/what-orion-sends">What ORION sends</a>
      <a href="/mentions-legales" lang="fr">Mentions légales (legal notice, French)</a>
      <a href="/" lang="fr">Site en français</a>
    </nav>
  </div>
</footer>
</body>
</html>
"""
    return tete + corps


def page_envois(index_fr: str, envoie_fr: str) -> str:
    tete = envoie_fr[:envoie_fr.index("<body>")]
    tete = tete.replace('<html lang="fr">', '<html lang="en">')
    tete = re.sub(r"<title>.*?</title>", "<title>What ORION sends, and what it does not — ORION Game Launcher</title>", tete, count=1, flags=re.S)
    tete = re.sub(r'<meta name="description" content="[^"]*">',
                  '<meta name="description" content="In plain words: what the ORION app sends over the Internet, to whom, when, and what never leaves your PC. No account, no ads, nothing without your consent.">', tete, count=1)
    tete = re.sub(r'<link rel="canonical" href="[^"]*">',
                  f'<link rel="canonical" href="{SITE}/en/what-orion-sends">\n<link rel="alternate" hreflang="fr" href="{SITE}/ce-qu-orion-envoie">\n'
                  f'<link rel="alternate" hreflang="en" href="{SITE}/en/what-orion-sends">\n<link rel="alternate" hreflang="x-default" href="{SITE}/ce-qu-orion-envoie">', tete, count=1)
    corps = """<body>
<div class="wrap">
<a class="brand" href="/en/"><img src="/img/logo.png" alt="" width="30" height="30">ORION</a>
<h1>What ORION sends, and what it does not</h1>
<p>Last updated 9 October 2026, for ORION 2.1.0. The <a href="/mentions-legales" lang="fr">legal notice (French)</a>
  says the same thing in legal terms; this page says it in plain words.</p>

<div class="box"><p><b>In one sentence:</b> ORION works on your PC. No account, no ads, no data sent unless you said yes to a
  question asked once. What you play, where your files are, who you are: none of it leaves your machine.</p></div>

<h2>What never leaves</h2>
<ul>
  <li>Your name, your e-mail address, an account: ORION has none.</li>
  <li>Your game list, your saves, your screenshots, your playtime.</li>
  <li>Your file paths and your Windows user name. Problem reports strip them before sending.</li>
  <li>Your platform passwords and tokens: sign-in happens on the platform's official page, the token stays encrypted on your PC.</li>
  <li>Your IP address: ORION's service does not record it.</li>
</ul>

<h2>What ORION fetches from the Internet (like a browser)</h2>
<p>To show covers, prices, news, free games, system requirements and trailers, ORION queries Steam, GOG, Epic, Xbox,
  IsThereAnyDeal, Gamesplanet, GitHub, NVIDIA and, on a Dell, Lenovo or HP PC, those manufacturers' public servers. As with
  any website you visit, these services see the IP address making the request, and nothing else about you. What each
  request contains:</p>
<div class="tableau">
  <div class="ligne"><b>Game pages, covers, prices</b><span>The game's number or title, and the country chosen in Settings. Never an identifier.</span></div>
  <div class="ligne"><b>Latest NVIDIA driver version</b><span>Nothing: ORION reads a list published by its service (the version per card series). Your card is not sent.</span></div>
  <div class="ligne"><b>Your model's driver catalog (Dell, Lenovo, HP)</b><span>The requested file carries the model's identifier (for example "0BEB" or "83E0"), not your PC's. The manufacturer sees a public file request, like a download.</span></div>
  <div class="ligne"><b>Windows Update, optional drivers</b><span>Windows itself queries Microsoft, as it already does; ORION only reads the answer on your PC.</span></div>
  <div class="ligne"><b>Prices at Kinguin and Loaded</b><span>Requested from ORION's service with the game's number, title and country. The service keeps the price, not the request.</span></div>
</div>

<h2>What ORION sends to its own service, only if you said yes</h2>
<p>A question, asked once, asks whether you accept to share anonymously. If you say no, nothing below is sent and
  ORION works exactly the same. If you say yes:</p>
<div class="tableau">
  <div class="ligne"><b>Performance measurements</b><span>The game, graphics card, processor, resolution, settings level and frame rate. They tell other players what a similar machine gets.</span></div>
  <div class="ligne"><b>Usage counter</b><span>That ORION was opened (version, Store or installer), the names of the pages used, the name of the store opened from an offer. Never the game, never the link.</span></div>
  <div class="ligne"><b>Smoothness report</b><span>On exit: how many times the display froze, which ORION function was involved, startup time. Never the game, never a path.</span></div>
  <div class="ligne"><b>A random identifier</b><span>Used only to count each PC once a day. It contains nothing about your machine and the service hashes it before storing.</span></div>
  <div class="ligne"><b>Country and region</b><span>Derived by the host from the IP address, which is neither read nor kept. Never the city.</span></div>
</div>
<p>You can change your mind at any time in Settings, and ask for your measurements to be deleted by e-mail.</p>

<h2>What you send yourself, when you decide to</h2>
<div class="tableau">
  <div class="ligne"><b>A problem report</b><span>The text you write, ORION's version and where it comes from (Microsoft Store or installer), your hardware (processor, graphics card, memory, display), the last lines of the log and, after an abrupt stop, how the previous session ended with the technical crash trace, all cleaned of paths and user name. You see everything before sending.</span></div>
  <div class="ligne"><b>Your feedback (from ORION 2.1.2)</b><span>Your answers to the three “Give your feedback” questions (link under the version, bottom left), ORION's version and the same random identifier; no technical report. Nothing is sent without the Send button.</span></div>
  <div class="ligne"><b>A Microsoft Store rating</b><span>The button opens the Store's rating page; ORION sends nothing.</span></div>
  <div class="ligne"><b>The image to share</b><span>Made on your PC, saved where you want. It contains the summary's numbers, your processor and graphics card, nothing else.</span></div>
</div>

<h2>On this website</h2>
<p>No cookie, no ads, no form. A cookie-less audience measurement may be done by the host. When you click a partner
  store link from a game page, the site counts the store's name and the page type, without any identifier: it does not
  know who clicked, nor on which game. The free games RSS feed counts its reads by type of reader (Feedly,
  MonitoRSS…), with no address and no identifier.</p>

<h2>How to check</h2>
<p>The settings recipes are public, and every ORION release on GitHub carries its SHA-256 fingerprint, which the
  installer verifies. The <code>orion.log</code> file in ORION's data folder records every call to the service.
  Questions: oriongamelauncher@gmail.com.</p>
<footer><a href="/en/">Back to the English page</a> · <a href="/ce-qu-orion-envoie" lang="fr">Version française</a></footer>
</div>
</body>
</html>
"""
    return tete + corps


def main(dossier) -> None:
    dossier = Path(dossier)
    index_fr = (dossier / "index.html").read_text(encoding="utf-8")
    envoie_fr = (dossier / "ce-qu-orion-envoie.html").read_text(encoding="utf-8")
    en = dossier / "en"
    en.mkdir(exist_ok=True)
    (en / "index.html").write_text(page_accueil(index_fr), encoding="utf-8")
    (en / "what-orion-sends.html").write_text(page_envois(index_fr, envoie_fr), encoding="utf-8")
    # hreflang sur les pages francaises correspondantes
    for nom, fr, en_ in (("index.html", "/", "/en/"), ("ce-qu-orion-envoie.html", "/ce-qu-orion-envoie", "/en/what-orion-sends")):
        p = dossier / nom
        s = p.read_text(encoding="utf-8")
        if 'rel="alternate" hreflang="en"' not in s:
            s = re.sub(r'(<link rel="canonical" href="[^"]*">)',
                       lambda m: m.group(1) + f'\n<link rel="alternate" hreflang="fr" href="{SITE}{fr}">'
                                              f'\n<link rel="alternate" hreflang="en" href="{SITE}{en_}">'
                                              f'\n<link rel="alternate" hreflang="x-default" href="{SITE}{fr}">', s, count=1)
            p.write_text(s, encoding="utf-8")
    plan = dossier / "sitemap.xml"
    x = plan.read_text(encoding="utf-8")
    x = re.sub(r"  <url>\n    <loc>" + re.escape(SITE) + r"/en/[^<]*</loc>.*?</url>\n", "", x, flags=re.S)
    bloc = "".join(f"  <url>\n    <loc>{SITE}{c}</loc>\n    <lastmod>2026-10-08</lastmod>\n"
                   f"    <changefreq>monthly</changefreq>\n    <priority>{p}</priority>\n  </url>\n"
                   for c, p in (("/en/", "0.9"), ("/en/what-orion-sends", "0.5")))
    x = x.replace("  <url>\n    <loc>" + SITE + "/mentions-legales", bloc + "  <url>\n    <loc>" + SITE + "/mentions-legales")
    plan.write_text(x, encoding="utf-8")
    print("pages anglaises : /en/, /en/what-orion-sends ; hreflang poses")


if __name__ == "__main__":
    main(sys.argv[1])
