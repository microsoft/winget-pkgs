"""Flux RSS du site (11 octobre 2026).

- /rss/sorties.xml : les fiches de sortie du site (/sorties/<jeu>), une par jeu
  attendu, avec sa date ou sa fenetre de sortie ;
- /rss/versions.xml : les nouveautes d'ORION, une par version (CHANGELOG.md) ;
- le flux des jeux gratuits est servi par le service, a jour toute seule :
  https://api.orion-launcher.com/gratuits.rss (worker.js, rssGratuits).

Chaque page concernee annonce ses flux (<link rel="alternate">), pour les
lecteurs de flux et les robots Discord. Aucun suivi : un flux est un fichier.

Usage : python gen_rss.py <dossier du site> <CHANGELOG.md>
"""
from __future__ import annotations

import datetime as dt
import email.utils
import html
import re
import sys
from pathlib import Path

ICI = Path(__file__).resolve().parent
sys.path.insert(0, str(ICI))
sys.path.insert(0, str(ICI.parent.parent))

SITE = "https://orion-launcher.com"
GRATUITS = "https://api.orion-launcher.com/gratuits.rss"
FLUX = {
    "sorties": ("Sorties de jeux PC — ORION", f"{SITE}/rss/sorties.xml"),
    "versions": ("Nouveautés d'ORION", f"{SITE}/rss/versions.xml"),
    "gratuits": ("Jeux PC gratuits — ORION", GRATUITS),
}
#: pages qui annoncent leurs flux (chemin du fichier -> flux)
ANNONCES = {
    "index.html": ("gratuits", "sorties", "versions"),
    "gratuits.html": ("gratuits",),
    "sorties.html": ("sorties",),
    "versions.html": ("versions",),
}


def x(t) -> str:
    return html.escape(str(t or ""), quote=True)


def date_rfc(d: dt.date) -> str:
    return email.utils.format_datetime(dt.datetime(d.year, d.month, d.day, 8, 0, tzinfo=dt.timezone.utc))


def canal(titre: str, lien: str, soi: str, description: str, articles: list[str], auj: dt.date) -> str:
    return ('<?xml version="1.0" encoding="UTF-8"?>\n'
            '<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">\n<channel>\n'
            f"<title>{x(titre)}</title>\n<link>{x(lien)}</link>\n"
            f'<atom:link href="{x(soi)}" rel="self" type="application/rss+xml"/>\n'
            f"<description>{x(description)}</description>\n<language>fr</language>\n"
            f"<lastBuildDate>{date_rfc(auj)}</lastBuildDate>\n" + "".join(articles) + "</channel>\n</rss>\n")


def article(titre: str, lien: str, description: str, quand: dt.date, guid: str = "") -> str:
    return (f"<item><title>{x(titre)}</title><link>{x(lien)}</link>"
            f'<guid isPermaLink="{"false" if guid else "true"}">{x(guid or lien)}</guid>'
            f"<description>{x(description)}</description><pubDate>{date_rfc(quand)}</pubDate></item>\n")


def _meta(page: str, nom: str) -> str:
    if nom == "title":
        m = re.search(r"<title>(.*?)</title>", page, re.S)
    else:
        m = re.search(r'<meta name="description" content="([^"]*)">', page)
    return html.unescape(m.group(1).strip()) if m else ""


def flux_sorties(dossier: Path, auj: dt.date) -> int:
    from orion import sorties as liste
    from gen_sorties import chemin_fiche
    maj = dt.date.fromisoformat(liste.MAJ) if re.match(r"\d{4}-\d{2}-\d{2}$", str(liste.MAJ)) else auj
    articles = []
    for s in sorted(liste.EMBARQUEE, key=lambda s: (s.get("date") or "9999", s.get("titre", ""))):
        chemin = chemin_fiche(s)
        f = dossier / (chemin.lstrip("/") + ".html")
        if not f.is_file():
            continue
        page = f.read_text(encoding="utf-8")
        articles.append(article(_meta(page, "title"), SITE + chemin, _meta(page, "description"), maj))
    (dossier / "rss").mkdir(exist_ok=True)
    titre, soi = FLUX["sorties"]
    (dossier / "rss" / "sorties.xml").write_text(canal(
        titre, f"{SITE}/sorties", soi, "Les grosses sorties de jeux attendues sur PC : date officielle, plateformes, "
        "configuration et prix, chacune avec sa source.", articles, auj), encoding="utf-8")
    return len(articles)


def flux_versions(dossier: Path, changelog: Path, auj: dt.date) -> int:
    from gen_journal import lire
    articles = []
    for v in lire(changelog.read_text(encoding="utf-8"))[:30]:
        quand = dt.date.fromisoformat(v["iso"])
        articles.append(article(f"ORION {v['version']} : {v['titre']}", f"{SITE}/versions/{v['version']}",
                                f"Nouveautés d'ORION {v['version']} ({v['date']}) : {v['titre']}.", quand))
    (dossier / "rss").mkdir(exist_ok=True)
    titre, soi = FLUX["versions"]
    (dossier / "rss" / "versions.xml").write_text(canal(
        titre, f"{SITE}/versions", soi, "Chaque nouvelle version du launcher ORION, ce qui change pour vous.",
        articles, auj), encoding="utf-8")
    return len(articles)


def annoncer(dossier: Path) -> int:
    n = 0
    for nom, flux in ANNONCES.items():
        p = dossier / nom
        if not p.is_file():
            continue
        s = p.read_text(encoding="utf-8")
        liens = "".join(f'\n<link rel="alternate" type="application/rss+xml" title="{x(FLUX[f][0])}" href="{FLUX[f][1]}">'
                        for f in flux if FLUX[f][1] not in s.split("</head>")[0])
        m = re.search(r'<link rel="canonical" href="[^"]*">', s)
        if liens and m:
            s = s.replace(m.group(0), m.group(0) + liens, 1)
            # lien visible sur les pages de liste (l'accueil et /gratuits l'ont deja dans le texte)
            if nom in ("sorties.html", "versions.html") and "/rss/" not in s.split("</head>", 1)[1]:
                f = flux[0]
                lien = (f'<p class="petit rss">S\'abonner : <a href="{FLUX[f][1]}" type="application/rss+xml">'
                        f'flux RSS</a>, pour un lecteur de flux ou un serveur Discord.</p>\n')
                fin = "</main>" if "</main>" in s else "<footer"
                s = s.replace(fin, lien + fin, 1)
            p.write_text(s, encoding="utf-8")
            n += 1
    return n


def main(dossier, changelog) -> None:
    dossier, auj = Path(dossier), dt.date.today()
    a = flux_sorties(dossier, auj)
    b = flux_versions(dossier, Path(changelog), auj)
    c = annoncer(dossier)
    print(f"flux RSS : sorties ({a} articles), versions ({b}), jeux gratuits (service) ; annonces sur {c} pages")


if __name__ == "__main__":
    main(*sys.argv[1:3])
