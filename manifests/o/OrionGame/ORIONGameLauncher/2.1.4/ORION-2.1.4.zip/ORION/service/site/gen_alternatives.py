"""Pages « alternative à… » et llms.txt (11 octobre 2026).

Ces pages répondent aux recherches de quelqu'un qui est prêt à installer un
launcher : « alternative à GOG Galaxy », « Playnite en français », « un
launcher pour tous mes jeux », et leurs équivalents anglais. Chaque page dit
honnêtement ce que l'autre logiciel fait mieux (mêmes faits que /comparatif,
relevés sur les sites officiels le 8 octobre 2026), ce qu'ORION fait en plus,
et comment passer à ORION sans rien perdre.

    python gen_alternatives.py <dossier du site>

Écrit aussi /llms.txt : le résumé d'ORION et ses pages principales, au format
proposé sur llmstxt.org, pour les assistants qui lisent le web (ChatGPT,
Copilot, Perplexity…).
"""
from __future__ import annotations

import datetime as dt
import json
import re
import sys
from pathlib import Path

ICI = Path(__file__).resolve().parent
sys.path.insert(0, str(ICI))
import gen_jeux as fr                                               # noqa: E402
import gen_jeux_en as en                                            # noqa: E402
from gen_jeux import SITE, e                                        # noqa: E402

STORE = "https://apps.microsoft.com/detail/9P91GMXV7FPW"
RELEVE = "8 octobre 2026"
RELEVE_EN = "8 October 2026"

LAUNCHERS = "Steam, Epic Games, GOG, Xbox et Microsoft Store, Ubisoft Connect, EA app, Battle.net et Ankama"
LAUNCHERS_EN = "Steam, Epic Games, GOG, Xbox and the Microsoft Store, Ubisoft Connect, the EA app, Battle.net and Ankama"

ORION_EN_PLUS = [
    ("Ce que votre PC fait tourner, jeu par jeu",
     "le niveau de réglages qui reste fluide et les images par seconde attendues, avant d'acheter, puis corrigées par vos vraies parties."),
    ("Les réglages écrits pour vous",
     "deux cartes, « Votre écran » (le plus beau réglage qui tient la fréquence de votre écran) et « Mon choix » ; sauvegarde avant, retour à l'état d'origine en un clic, jamais pendant une partie."),
    ("Les vrais prix",
     "plus de trente boutiques agréées comparées (données IsThereAnyDeal), les officielles d'abord, la liste d'envies avec alerte, les jeux gratuits du moment."),
    ("Les pilotes en retard",
     "par identifiant matériel : Windows Update, la dernière version NVIDIA de votre série, le catalogue de votre modèle Dell, Lenovo ou HP. ORION dit où prendre la bonne version, il n'installe rien."),
    ("Sans compte",
     "rien à créer, rien n'est envoyé sans votre accord, pas de publicité. En français et en anglais."),
]
ORION_EN_PLUS_EN = [
    ("What your PC can run, game by game",
     "the settings level that stays smooth and the frame rate to expect, before you buy, then corrected by your real sessions."),
    ("Settings written for you",
     "two cards, \"Your screen\" (the best-looking setting that holds your display's refresh rate) and \"My choice\"; backup first, one-click return to the original state, never during a session."),
    ("Real prices",
     "over thirty approved stores compared (IsThereAnyDeal data), official stores first, a wishlist with price alerts, the free games of the moment."),
    ("Outdated drivers",
     "by hardware ID: Windows Update, the latest NVIDIA version for your card series, your Dell, Lenovo or HP model's catalog. ORION tells you where to get the right version; it never installs anything."),
    ("No account",
     "nothing to create, nothing sent without your consent, no ads. In English and French."),
]

#: ce que chaque concurrent fait mieux (mêmes faits que /comparatif)
MIEUX = {
    "gog-galaxy": [
        "Le plus social : succès, temps de jeu et amis de toutes les plateformes réunis, discussion entre plateformes.",
        "Sauvegardes dans le nuage et mises à jour automatiques pour les jeux GOG ; disponible aussi sur Mac.",
        "La boutique GOG intégrée, et des intégrations communautaires open source pour les autres plateformes.",
    ],
    "playnite": [
        "La bibliothèque la plus large, émulateurs compris, avec des centaines d'extensions et de thèmes.",
        "Open source (licence MIT), extensible en .NET et PowerShell.",
        "Un mode plein écran complet pensé pour la manette et le canapé ; dix ans d'existence, traduit dans une trentaine de langues.",
    ],
}
MIEUX_EN = {
    "gog-galaxy": [
        "The most social: achievements, playtime and friends from every platform in one place, cross-platform chat.",
        "Cloud saves and automatic updates for GOG games; also available on Mac.",
        "The built-in GOG store, and open-source community integrations for the other platforms.",
    ],
    "playnite": [
        "The widest library, emulators included, with hundreds of extensions and themes.",
        "Open source (MIT licence), extensible in .NET and PowerShell.",
        "A complete full-screen mode built for controllers and the couch; ten years old, translated into about thirty languages.",
    ],
}
#: lignes du tableau (ORION, l'autre)
TABLE = {
    "gog-galaxy": [
        ("Bibliothèque unifiée", "Steam, Epic, GOG, Xbox, Ubisoft, EA, Battle.net, Ankama", "Par intégrations officielles et communautaires"),
        ("Ce que le PC fait tourner", "Oui, jeu par jeu", "Non"),
        ("Réglages graphiques écrits pour vous", "Oui, sauvegarde et retour en arrière", "Non"),
        ("Pilotes en retard", "Oui, par identifiant matériel", "Non"),
        ("Comparateur de prix", "30+ boutiques, officielles d'abord", "Boutique GOG"),
        ("Amis, discussion", "Non", "Oui, entre plateformes"),
        ("Compte obligatoire", "Non", "Compte GOG"),
        ("Systèmes", "Windows 10 et 11", "Windows, Mac"),
    ],
    "playnite": [
        ("Bibliothèque unifiée", "Steam, Epic, GOG, Xbox, Ubisoft, EA, Battle.net, Ankama", "La plus large, extensions comprises"),
        ("Émulateurs", "Non", "Oui, très complet"),
        ("Ce que le PC fait tourner", "Oui, jeu par jeu", "Non"),
        ("Réglages graphiques écrits pour vous", "Oui, sauvegarde et retour en arrière", "Non"),
        ("Pilotes en retard", "Oui, par identifiant matériel", "Non"),
        ("Comparateur de prix", "30+ boutiques, officielles d'abord", "Par extensions"),
        ("Manette, plein écran", "Oui, simple (affichage salon)", "Oui, très complet"),
        ("Open source", "Recettes publiques, code fermé", "Oui (MIT)"),
    ],
}
TABLE_EN = {
    "gog-galaxy": [
        ("Unified library", "Steam, Epic, GOG, Xbox, Ubisoft, EA, Battle.net, Ankama", "Official and community integrations"),
        ("What your PC can run", "Yes, game by game", "No"),
        ("Graphics settings written for you", "Yes, with backup and undo", "No"),
        ("Outdated drivers", "Yes, by hardware ID", "No"),
        ("Price comparison", "30+ stores, official first", "GOG store"),
        ("Friends, chat", "No", "Yes, cross-platform"),
        ("Account required", "No", "GOG account"),
        ("Systems", "Windows 10 and 11", "Windows, Mac"),
    ],
    "playnite": [
        ("Unified library", "Steam, Epic, GOG, Xbox, Ubisoft, EA, Battle.net, Ankama", "The widest, with extensions"),
        ("Emulators", "No", "Yes, very complete"),
        ("What your PC can run", "Yes, game by game", "No"),
        ("Graphics settings written for you", "Yes, with backup and undo", "No"),
        ("Outdated drivers", "Yes, by hardware ID", "No"),
        ("Price comparison", "30+ stores, official first", "Through extensions"),
        ("Controller, full screen", "Yes, simple (couch mode)", "Yes, very complete"),
        ("Open source", "Public recipes, closed code", "Yes (MIT)"),
    ],
}

PAGES = [
    {
        "id": "gog-galaxy", "fr": "/alternative-gog-galaxy", "en": "/en/gog-galaxy-alternative",
        "nom": "GOG Galaxy",
        "titre": "Alternative à GOG Galaxy : ORION, gratuit, sans compte",
        "titre_en": "GOG Galaxy alternative: ORION, free, no account",
        "desc": "GOG Galaxy réunit vos jeux et vos amis. ORION réunit vos jeux et lit votre PC : réglages écrits pour vous, pilotes, vrais prix. Gratuit, sans compte.",
        "desc_en": "GOG Galaxy brings your games and friends together. ORION brings your games together and reads your PC: settings, drivers, real prices. Free.",
        "h1": "Une alternative à GOG Galaxy qui lit votre PC",
        "h1_en": "A GOG Galaxy alternative that reads your PC",
        "lede": ("Comme GOG Galaxy, ORION réunit vos jeux de toutes les boutiques dans une seule bibliothèque. "
                 "La différence : ORION regarde votre carte graphique, votre processeur et votre écran, vous dit ce "
                 "que votre PC fait tourner, écrit les réglages à votre place et compare les prix. Il ne fait pas "
                 "de réseau social, et ne demande aucun compte."),
        "lede_en": ("Like GOG Galaxy, ORION brings the games from every store into a single library. The difference: "
                    "ORION looks at your graphics card, processor and display, tells you what your PC can run, writes "
                    "the settings for you and compares prices. It has no social features, and needs no account."),
        "pour_qui": ("Vous jouez surtout avec des amis répartis sur plusieurs plateformes, ou sur Mac : gardez GOG Galaxy. "
                     "Vous voulez savoir ce que votre PC fait tourner, le régler sans y passer la soirée et acheter au bon "
                     "prix : essayez ORION. Les deux peuvent cohabiter : ORION ne touche pas à la bibliothèque de GOG Galaxy."),
        "pour_qui_en": ("You mostly play with friends spread across platforms, or on a Mac: keep GOG Galaxy. You want to know "
                        "what your PC can run, tune it without spending the evening on it and buy at the right price: try "
                        "ORION. Both can live side by side: ORION never touches GOG Galaxy's library."),
        "faq": [
            ("ORION remplace-t-il GOG Galaxy ?",
             "Pour la bibliothèque, oui : ORION lit les jeux de Steam, Epic, GOG, Xbox, Ubisoft, EA, Battle.net et Ankama. Pour les amis, la discussion et les sauvegardes GOG dans le nuage, non : gardez GOG Galaxy si vous vous en servez."),
            ("Faut-il un compte ?",
             "Non. ORION fonctionne sans compte. Vous pouvez connecter Steam, GOG ou Xbox pour voir aussi les jeux possédés mais pas installés ; ORION ne voit jamais votre mot de passe."),
            ("ORION est-il gratuit ?",
             "Oui, sans publicité. Il vit de dons et de liens partenaires vers certaines boutiques, qui ne changent ni le prix ni l'ordre des offres."),
        ],
        "faq_en": [
            ("Does ORION replace GOG Galaxy?",
             "For the library, yes: ORION reads the games from Steam, Epic, GOG, Xbox, Ubisoft, EA, Battle.net and Ankama. For friends, chat and GOG cloud saves, no: keep GOG Galaxy if you use them."),
            ("Do I need an account?",
             "No. ORION works without an account. You can connect Steam, GOG or Xbox to also see games you own but haven't installed; ORION never sees your password."),
            ("Is ORION free?",
             "Yes, with no ads. It is funded by donations and partner links to some stores, which change neither the price nor the order of offers."),
        ],
    },
    {
        "id": "playnite", "fr": "/alternative-playnite", "en": "/en/playnite-alternative",
        "nom": "Playnite",
        "titre": "Alternative à Playnite : ORION, simple et en français",
        "titre_en": "Playnite alternative: ORION, simpler, reads your PC",
        "desc": "Playnite range une grosse collection. ORION la range aussi, sans réglage, et lit votre PC : ce qu'il fait tourner, les réglages, les vrais prix. Gratuit.",
        "desc_en": "Playnite organizes a big collection. ORION does too, with no setup, and reads your PC: what it can run, settings written for you, real prices. Free.",
        "h1": "Une alternative à Playnite, prête dès l'installation",
        "h1_en": "A Playnite alternative that works out of the box",
        "lede": ("Playnite est le plus complet pour ranger une grande collection, émulateurs compris, à condition de "
                 "prendre le temps de le configurer. ORION vise autre chose : à l'installation, il trouve vos jeux de "
                 "toutes les boutiques, lit votre matériel et vous dit quoi jouer, avec quels réglages, à quel prix. "
                 "Sans extension à installer ni compte à créer."),
        "lede_en": ("Playnite is the most complete way to organize a big collection, emulators included, if you take the "
                    "time to set it up. ORION aims at something else: right after install it finds your games from every "
                    "store, reads your hardware and tells you what to play, with which settings, at what price. No "
                    "extension to install, no account to create."),
        "pour_qui": ("Vous avez une grosse collection, des émulateurs, et vous aimez tout personnaliser : gardez Playnite. "
                     "Vous voulez que le PC soit réglé pour vous et savoir où acheter au bon prix, sans configuration : "
                     "essayez ORION. Les deux peuvent tourner côte à côte."),
        "pour_qui_en": ("You have a big collection, emulators, and you like to customize everything: keep Playnite. You want "
                        "your PC tuned for you and the best place to buy, with no setup: try ORION. Both can run side by side."),
        "faq": [
            ("ORION gère-t-il les émulateurs ?",
             "Non. Si vous jouez beaucoup sur émulateur, Playnite reste le meilleur choix ; ORION peut tourner à côté sans rien toucher."),
            ("Peut-on jouer à la manette ?",
             "Oui : ORION se pilote à la manette (XInput) et a un affichage salon en plein écran, plus simple que celui de Playnite."),
            ("ORION est-il open source ?",
             "Ses recettes de réglages sont publiques ; le code de l'application est fermé. Playnite, lui, est entièrement open source (licence MIT)."),
        ],
        "faq_en": [
            ("Does ORION handle emulators?",
             "No. If you play a lot on emulators, Playnite remains the best choice; ORION can run next to it without touching anything."),
            ("Can I use a controller?",
             "Yes: ORION can be driven with a controller (XInput) and has a full-screen couch mode, simpler than Playnite's."),
            ("Is ORION open source?",
             "Its settings recipes are public; the app's code is closed. Playnite is fully open source (MIT licence)."),
        ],
    },
    {
        "id": "tous", "fr": "/launcher-tous-les-jeux", "en": "/en/one-launcher-all-games",
        "nom": "",
        "titre": "Un seul launcher pour tous vos jeux PC (Steam, Epic, GOG…)",
        "titre_en": "One launcher for all your PC games (Steam, Epic, GOG…)",
        "desc": "Réunir Steam, Epic, GOG, Xbox, Ubisoft, EA et Battle.net dans une seule bibliothèque, gratuitement et sans compte : ORION, et ce qu'il ajoute.",
        "desc_en": "Bring Steam, Epic, GOG, Xbox, Ubisoft, EA and Battle.net into a single library, free and without an account: ORION, and what it adds.",
        "h1": "Tous vos jeux PC dans un seul launcher",
        "h1_en": "All your PC games in one launcher",
        "lede": ("Sept boutiques, sept launchers, et plus aucune idée de ce qui est installé où. ORION les lit tous et "
                 "range vos jeux dans une seule bibliothèque, même ceux que vous possédez sans les avoir installés. "
                 "Un clic lance le jeu par son launcher d'origine : rien n'est remplacé, rien n'est déplacé."),
        "lede_en": ("Seven stores, seven launchers, and no idea anymore what is installed where. ORION reads them all and "
                    "puts your games in a single library, including the ones you own but haven't installed. One click "
                    "starts the game through its own launcher: nothing is replaced, nothing is moved."),
        "pour_qui": ("D'autres logiciels réunissent aussi vos jeux : Playnite, très personnalisable, et GOG Galaxy, le plus "
                     "social. Le comparatif honnête dit ce que chacun fait mieux. ORION est le seul des trois qui lit votre "
                     "matériel pour régler les jeux et vous dire ce que votre PC fait tourner."),
        "pour_qui_en": ("Other apps bring your games together too: Playnite, very customizable, and GOG Galaxy, the most social. "
                        "ORION is the only one of the three that reads your hardware to tune your games and tell you what "
                        "your PC can run."),
        "faq": [
            ("Quels launchers ORION lit-il ?",
             LAUNCHERS + ", plus vos dossiers de jeux et les programmes installés. L'analyse se fait sur votre PC, sans rien envoyer."),
            ("Mes jeux non installés apparaissent-ils ?",
             "Oui, si vous connectez votre compte Steam, GOG ou Xbox : ORION liste alors aussi les jeux possédés, et la valeur de votre bibliothèque."),
            ("Faut-il désinstaller mes autres launchers ?",
             "Non, surtout pas : ORION s'en sert pour lancer les jeux, les mettre à jour et les désinstaller. Il ne les remplace pas."),
        ],
        "faq_en": [
            ("Which launchers does ORION read?",
             LAUNCHERS_EN + ", plus your game folders and installed programs. The scan runs on your PC and sends nothing."),
            ("Do games I haven't installed show up?",
             "Yes, if you connect your Steam, GOG or Xbox account: ORION then also lists the games you own, and what your library is worth."),
            ("Should I uninstall my other launchers?",
             "No: ORION uses them to start, update and uninstall your games. It doesn't replace them."),
        ],
    },
]


def _faq_ld(faq):
    return {"@context": "https://schema.org", "@type": "FAQPage",
            "mainEntity": [{"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": r}} for q, r in faq]}


def _fil(nom, chemin, accueil="/", nom_accueil="Accueil"):
    return {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [
        {"@type": "ListItem", "position": 1, "name": nom_accueil, "item": SITE + accueil},
        {"@type": "ListItem", "position": 2, "name": nom, "item": SITE + chemin}]}


def _corps(p, lang):
    anglais = lang == "en"
    k = (lambda c: p[c + "_en"]) if anglais else (lambda c: p[c])
    plus = ORION_EN_PLUS_EN if anglais else ORION_EN_PLUS
    accueil = "/en/" if anglais else "/"
    installer = "/en/#installer" if anglais else "/#installer"
    morceaux = [f'<section class="tete"><p class="fil"><a href="{accueil}">{"Home" if anglais else "Accueil"}</a> › '
                f'{e(k("h1"))}</p><h1>{e(k("h1"))}</h1><p class="lede">{e(k("lede"))}</p>'
                f'<div class="appel"><a class="btn" href="{installer}">{"Download ORION, free" if anglais else "Télécharger ORION, gratuit"}</a>'
                f'<a href="{STORE}" rel="noopener">{"Microsoft Store" if anglais else "Sur le Microsoft Store"}</a></div></section>']
    if p["id"] in MIEUX:
        nom = p["nom"]
        mieux = (MIEUX_EN if anglais else MIEUX)[p["id"]]
        morceaux.append(f'<section class="bloc"><h2>{"What " + nom + " does better" if anglais else "Ce que " + nom + " fait mieux"}</h2>'
                        f'<p>{("Honestly, from its official site, checked on " + RELEVE_EN + ".") if anglais else ("Honnêtement, d’après son site officiel, relevé le " + RELEVE + ".")}</p>'
                        "<ul>" + "".join(f"<li>{e(x)}</li>" for x in mieux) + "</ul></section>")
    titre_plus = "What ORION adds" if anglais else "Ce qu’ORION fait en plus"
    morceaux.append(f'<section class="bloc"><h2>{titre_plus}</h2><div class="configs">'
                    + "".join(f"<article><h3>{e(t)}</h3><p>{e(d)}</p></article>" for t, d in plus) + "</div></section>")
    if p["id"] in TABLE:
        lignes = (TABLE_EN if anglais else TABLE)[p["id"]]
        tete = f'<tr><th></th><th>ORION</th><th>{e(p["nom"])}</th></tr>'
        morceaux.append(f'<section class="bloc"><h2>{"Side by side" if anglais else "Côte à côte"}</h2><div class="defile"><table class="perf">'
                        f"<thead>{tete}</thead><tbody>"
                        + "".join(f"<tr><th>{e(a)}</th><td>{e(b)}</td><td>{e(c)}</td></tr>" for a, b, c in lignes)
                        + "</tbody></table></div></section>")
    etapes = ([("Install ORION", "from the Microsoft Store or the installer on this site; no administrator rights."),
               ("Let it scan", "it finds the games of every launcher on your drives, then reads your hardware."),
               ("Play", "pick a card in a game's page, then Play: settings are written after a backup.")] if anglais else
              [("Installez ORION", "depuis le Microsoft Store ou l’installateur de ce site ; aucun droit administrateur."),
               ("Laissez-le analyser", "il trouve les jeux de tous les launchers sur vos disques, puis lit votre matériel."),
               ("Jouez", "choisissez une carte dans la fiche d’un jeu, puis Jouer : les réglages s’écrivent après sauvegarde.")])
    morceaux.append(f'<section class="bloc"><h2>{"Switch without losing anything" if anglais else "Passer à ORION sans rien perdre"}</h2>'
                    f'<p>{e(k("pour_qui"))}</p><div class="resume">'
                    + "".join(f"<div><span>{i}. {e(t)}</span><b>{e(d)}</b></div>" for i, (t, d) in enumerate(etapes, 1))
                    + "</div></section>")
    morceaux.append(f'<section class="bloc"><h2>{"Questions" if anglais else "Questions"}</h2>'
                    + "".join(f"<h3>{e(q)}</h3><p>{e(r)}</p>" for q, r in k("faq")) + "</section>")
    autres = [x for x in PAGES if x["id"] != p["id"]]
    liens = "".join(f'<a href="{x["en"] if anglais else x["fr"]}">{e(x["h1_en"] if anglais else x["h1"])}</a>' for x in autres)
    if not anglais:
        liens += '<a href="/comparatif">Le comparatif ORION, Playnite, GOG Galaxy</a>'
    morceaux.append(f'<section class="bloc"><h2>{"See also" if anglais else "Voir aussi"}</h2><div class="autres">{liens}</div></section>')
    return "\n".join(morceaux)


def _alternance(page: str, chemin_fr: str, chemin_en: str) -> str:
    """hreflang fr/en/x-default juste après le lien canonique."""
    m = re.search(r'<link rel="canonical" href="[^"]*">', page)
    liens = (f'\n<link rel="alternate" hreflang="fr" href="{SITE}{chemin_fr}">'
             f'\n<link rel="alternate" hreflang="en" href="{SITE}{chemin_en}">'
             f'\n<link rel="alternate" hreflang="x-default" href="{SITE}{chemin_en}">')
    return page.replace(m.group(0), m.group(0) + liens, 1) if m and "hreflang" not in page.split("</head>")[0] else page


def llms(dossier: Path) -> None:
    texte = f"""# ORION Game Launcher

> ORION reads your PC and tells you what to play, with which settings, at what price. Free Windows 10/11 game launcher, no account, no ads, nothing sent without consent. Made in France, interface in French and English.

ORION brings the games from {LAUNCHERS_EN} into one library, including games you own but haven't installed. For each game it estimates the settings level and frame rate your hardware can hold, writes the graphics settings into the game's own files after a backup (two cards: "Your screen" and "My choice"), compares prices across 30+ approved stores with IsThereAnyDeal data (official stores first, three key resellers shown apart), lists outdated drivers by hardware ID and shows the free games of the moment. Available from the Microsoft Store and as a direct installer.

## Main pages
- [Home (English)]({SITE}/en/): what ORION does, download, FAQ
- [Accueil (français)]({SITE}/): présentation, téléchargement, questions
- [ORION, Playnite or GOG Galaxy]({SITE}/comparatif): honest comparison (French)
- [GOG Galaxy alternative]({SITE}/en/gog-galaxy-alternative): what GOG Galaxy does better, what ORION adds
- [Playnite alternative]({SITE}/en/playnite-alternative): what Playnite does better, what ORION adds
- [One launcher for all your PC games]({SITE}/en/one-launcher-all-games)
- [Game requirements and per-GPU estimates]({SITE}/en/games): 900+ games
- [Configs des jeux]({SITE}/jeux): 1 100+ fiches en français, avec estimation par carte graphique
- [Bons plans jeux PC]({SITE}/bons-plans): PC game deals on very popular games, official keys, prices checked every 20 minutes (French)
- [Jeux peu gourmands]({SITE}/jeux/peu-gourmands), [jeux pour PC portable]({SITE}/jeux/pc-portable), [jeux sans carte graphique]({SITE}/jeux/sans-carte-graphique): games estimated on modest, laptop and integrated GPUs (French)
- [Soldes Steam]({SITE}/soldes-steam): next Steam sale dates, from Valve's published calendar (French)
- [Augmenter ses FPS]({SITE}/augmenter-fps): settings that raise FPS, and what does not help (French)
- [Config PC gamer 2026]({SITE}/config-pc-gamer-2026): a 1440p gaming PC build with dated French prices, assembly steps and measured FPS (French)
- [Mon PC peut-il faire tourner ce jeu ?]({SITE}/mon-pc-peut-il-faire-tourner): "can I run it" hub, search 1 100+ games or pick one of 21 graphics cards (French)
- [Prix de la RAM]({SITE}/prix-ram) and [prix des cartes graphiques]({SITE}/prix-cartes-graphiques): dated French price checks, sources, what each GPU allows at 1440p (French)
- [Free PC games this week]({SITE}/gratuits) and RSS: https://api.orion-launcher.com/gratuits.rss
- [Release notes]({SITE}/versions)
- [What ORION sends]({SITE}/en/what-orion-sends): privacy, in plain words

## Facts
- Price: free. Platform: Windows 10 and 11, 64-bit. No account required.
- Microsoft Store: {STORE}
- Contact: oriongamelauncher@gmail.com
- TikTok: https://www.tiktok.com/@oriongamelauncher
"""
    (dossier / "llms.txt").write_text(texte, encoding="utf-8")


def main(dossier) -> int:
    dossier = Path(dossier)
    accueil = (dossier / "index.html").read_text(encoding="utf-8")
    style = re.search(r"<style>(.*?)</style>", accueil, re.S).group(1)
    n = 0
    for p in PAGES:
        for lang in ("fr", "en"):
            chemin = p[lang]
            titre = p["titre_en" if lang == "en" else "titre"]
            desc = p["desc_en" if lang == "en" else "desc"]
            faq = p["faq_en" if lang == "en" else "faq"]
            ld = [{"@context": "https://schema.org", "@type": "WebPage", "name": titre, "description": desc,
                   "url": SITE + chemin, "inLanguage": lang,
                   "about": {"@type": "SoftwareApplication", "name": "ORION Game Launcher",
                             "operatingSystem": "Windows 10, Windows 11", "applicationCategory": "GameApplication",
                             "offers": {"@type": "Offer", "price": "0", "priceCurrency": "EUR"}}},
                  _faq_ld(faq),
                  _fil(p["h1_en"] if lang == "en" else p["h1"], chemin,
                       "/en/" if lang == "en" else "/", "Home" if lang == "en" else "Accueil")]
            corps = _corps(p, lang)
            if lang == "en":
                page = en.gabarit(style, titre, desc, chemin, ld, corps, fr_chemin=p["fr"], rubrique="")
            else:
                page = _alternance(fr.gabarit(style, titre, desc, chemin, ld, corps, rubrique=""), p["fr"], p["en"])
            f = dossier / (chemin.lstrip("/") + ".html")
            f.parent.mkdir(parents=True, exist_ok=True)
            f.write_text(page, encoding="utf-8")
            n += 1
    llms(dossier)
    # plan du site
    plan = dossier / "sitemap.xml"
    x = plan.read_text(encoding="utf-8")
    auj = dt.date.today().isoformat()
    bloc = "".join(f"  <url>\n    <loc>{SITE}{p[l]}</loc>\n    <lastmod>{auj}</lastmod>\n"
                   f"    <changefreq>monthly</changefreq>\n    <priority>0.8</priority>\n  </url>\n"
                   for p in PAGES for l in ("fr", "en") if f"<loc>{SITE}{p[l]}</loc>" not in x)
    plan.write_text(x.replace("</urlset>", bloc + "</urlset>"), encoding="utf-8")
    # le comparatif renvoie vers les pages « alternative à… »
    # (11 octobre : la vraie page n'a pas de </main>, seulement un <footer> ; le lien
    # n'était donc jamais posé, sans erreur. On vise le pied de page, et on échoue fort
    # si aucun point d'ancrage n'existe.)
    comp = dossier / "comparatif.html"
    if comp.is_file():
        s = comp.read_text(encoding="utf-8")
        if "/alternative-gog-galaxy" not in s:
            ligne = ('<p><small>Voir aussi : <a href="/alternative-gog-galaxy">alternative à GOG Galaxy</a> · '
                     '<a href="/alternative-playnite">alternative à Playnite</a> · '
                     '<a href="/launcher-tous-les-jeux">un seul launcher pour tous vos jeux</a></small></p>\n')
            ancre = next((a for a in ("<footer", "</main>", "</body>") if a in s), None)
            if ancre is None:
                raise RuntimeError("comparatif.html : ni <footer>, ni </main>, ni </body> pour poser « Voir aussi »")
            s = s.replace(ancre, ligne + ancre, 1)
            comp.write_text(s, encoding="utf-8")
    print(f"pages « alternative à… » : {n} (français et anglais), llms.txt")
    return n


if __name__ == "__main__":
    main(sys.argv[1])
