#!/bin/sh
# Fabrique ORION-Suivi.apk sans Android Studio.
#   sh construire.sh <dossier des outils> <magasin de cles> <fichier du mot de passe> [sortie.apk]
# Outils attendus dans le dossier (tous recuperables par GitHub et PyPI) :
#   android.jar   bibliotheque Android 34 (depot Sable/android-platforms)
#   aapt2         paquet PyPI « aapt2 » (aapt2/bin/Linux/aapt2)
#   dx.jar        dx-30.0.2.jar de dex-tools 2.4 (pxb1988/dex2jar)
#   signer.jar    uber-apk-signer 1.3.0 (patrickfav/uber-apk-signer)
# Le magasin de cles n'est jamais range avec les sources : sans lui, une
# nouvelle version ne peut pas remplacer l'ancienne sur le telephone.
set -e
ICI=$(cd "$(dirname "$0")" && pwd)
OUTILS=$1; MAGASIN=$2; PASSE=$3; SORTIE=${4:-ORION-Suivi.apk}
T=$(mktemp -d)
"$OUTILS/aapt2" compile --dir "$ICI/res" -o "$T/res.zip"
mkdir "$T/gen"
"$OUTILS/aapt2" link -o "$T/brut.apk" -I "$OUTILS/android.jar" --manifest "$ICI/AndroidManifest.xml" \
  --java "$T/gen" "$T/res.zip"
mkdir "$T/classes"
javac -source 8 -target 8 -Xlint:-options -bootclasspath "$OUTILS/android.jar" -d "$T/classes" \
  "$ICI"/src/com/orionlauncher/suivi/*.java "$T"/gen/com/orionlauncher/suivi/R.java
java -cp "$OUTILS/dx.jar" com.android.dx.command.Main --dex --min-sdk-version=24 --output="$T/classes.dex" "$T/classes"
(cd "$T" && zip -q -j brut.apk classes.dex)
java -jar "$OUTILS/signer.jar" --apks "$T/brut.apk" --out "$T/signe" --allowResign \
  --ks "$MAGASIN" --ksAlias suivi --ksPass "$(cat "$PASSE")" --ksKeyPass "$(cat "$PASSE")" > "$T/signature.log"
cp "$T"/signe/*.apk "$SORTIE"
rm -rf "$T"
echo "$SORTIE"
