"""English game pages (11 October 2026): /en/games, /en/games/<game>,
/en/games/genre/<genre> and /en/games/gpu/<card>.

Usage : python gen_jeux_en.py <site folder> <jeux-steam-1000-en.json> [<YYYY-MM-DD collected>]

The data is the English pass of COLLECTER-JEUX (Steam store pages read with
l=english): name, developer, genres, release date, minimum and recommended
requirements. The estimate per graphics card is the same engine as the French
pages and the app (orion.puissance.estimation), so both languages always give
the same numbers for the same game.

No price and no partner link on these pages: the French price feed is a
French shop in euros. The official Steam page is the only shop link.

A game present in both languages gets hreflang links both ways (fr, en,
x-default = en): the French page is found from the Steam link it cites.
"""
from __future__ import annotations

import datetime as dt
import json
import re
import sys
from pathlib import Path

ICI = Path(__file__).resolve().parent
sys.path.insert(0, str(ICI))
import gen_jeux as fr                                               # noqa: E402
from gen_jeux import (CARTES, CSS, DEFS, EXE, GPU, SITE, Exigences, ajuste, e,   # noqa: E402
                      evaluer, h1_texte, lire_config, propre, repere, slug)
import reglages                                                     # noqa: E402

TITRE_MAX, DESC_MAX = fr.TITRE_MAX, fr.DESC_MAX
NIVEAU = {"haute": "High", "moyenne": "Medium", "basse": "Low"}
MOIS = ["January", "February", "March", "April", "May", "June", "July", "August",
        "September", "October", "November", "December"]
STORE = "https://apps.microsoft.com/detail/9P91GMXV7FPW"

CHAMPS = [(("os",), "OS"), (("processor", "cpu"), "Processor"), (("memory", "ram"), "Memory"),
          (("graphics", "video card", "video"), "Graphics"), (("directx",), "DirectX"),
          (("storage", "hard drive", "hard disk space"), "Storage"),
          (("additional notes",), "Publisher's note")]

#: Steam genres that are not game genres (software that slipped through)
PAS_UN_GENRE = {"utilities", "animation & modeling", "design & illustration", "video production",
                "photo editing", "software training", "audio production", "game development",
                "web publishing", "accounting", "education", "free to play", "early access"}


def date_en(d: dt.date) -> str:
    return f"{MOIS[d.month - 1]} {d.day}, {d.year}"


def sortie_en(brut: str) -> str:
    """« 9 Dec, 2020 » (Steam, English) -> « December 9, 2020 »; other forms kept."""
    for fmt in ("%d %b, %Y", "%b %d, %Y", "%d %B, %Y", "%B %d, %Y"):
        try:
            return date_en(dt.datetime.strptime(brut.strip(), fmt).date())
        except ValueError:
            continue
    return brut.strip()


def champs(texte):
    """« Label: value » lines of the Steam page, in a fixed order."""
    vus = {}
    for ligne in texte.replace("﻿", "").splitlines():
        if ":" not in ligne:
            continue
        tete, reste = ligne.split(":", 1)
        tete = re.sub(r"[™®*]", "", tete).strip().lower()
        reste = re.sub(r"[™®]", "", reste).strip()
        if not reste or tete in ("minimum", "recommended"):
            continue
        for cles, nom in CHAMPS:
            if any(tete == c or tete.startswith(c + " ") for c in cles) and nom not in vus:
                if nom == "Graphics" and tete.startswith("video") and "card" not in tete and tete != "video":
                    continue
                reste = re.sub(r"\s+available space\b", "", reste)
                if nom == "Publisher's note":
                    reste = re.split(r"(?<=[.!])\s", reste)[0]
                    if len(reste) > 180:
                        continue
                vus[nom] = fr.net(reste)
                break
    return [(nom, vus[nom]) for _, nom in CHAMPS if nom in vus]


#: game that requires hardware ray tracing, on a card that lacks it (13 October 2026)
CELLULE_RT = '<td class="non"><b>Won\'t launch</b><span class="mono">needs ray tracing</span></td>'
CARTES_RT = "GeForce RTX, Radeon RX 6000 or newer, Intel Arc"


def cellule(ev):
    if getattr(ev, "bloque", ""):
        return CELLULE_RT
    if ev.niveau in NIVEAU:
        bas, haut = ev.fps[ev.niveau]
        classe = {"haute": "ok", "moyenne": "mi", "basse": "bas"}[ev.niveau]
        if ev.niveau == "basse" and bas < 55:
            classe = "juste"
        return f'<td class="{classe}"><b>{NIVEAU[ev.niveau]}</b><span class="mono">{reglages.fourchette(bas, haut, "en")}</span></td>'
    return '<td class="non"><b>Too weak</b><span class="mono">under 30 fps</span></td>'


def gabarit(style, titre, desc, chemin, ld, corps, fr_chemin=None, rubrique="games", image=""):
    ld_html = "\n".join('<script type="application/ld+json">' + json.dumps(x, ensure_ascii=False)
                        + "</script>" for x in ld)
    alt = ""
    if fr_chemin:
        alt = (f'\n<link rel="alternate" hreflang="en" href="{SITE}{chemin}">'
               f'\n<link rel="alternate" hreflang="fr" href="{SITE}{fr_chemin}">'
               f'\n<link rel="alternate" hreflang="x-default" href="{SITE}{chemin}">')
    francais = fr_chemin or "/"
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<script>if(/\\.pages\\.dev$/.test(location.hostname)){{location.replace("https://orion-launcher.com"+location.pathname+location.hash);}}</script>
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>{e(titre)}</title>
<meta name="description" content="{e(desc)}">
<meta name="robots" content="index, follow, max-image-preview:large">
<link rel="canonical" href="{SITE}{chemin}">{alt}
<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="icon" type="image/png" href="/img/logo.png">
<meta name="theme-color" content="#0C1122">
<meta property="og:type" content="article">
<meta property="og:site_name" content="ORION Game Launcher">
<meta property="og:locale" content="en_US">
<meta property="og:url" content="{SITE}{chemin}">
<meta property="og:title" content="{e(titre)}">
<meta property="og:description" content="{e(desc)}">
<meta property="og:image" content="{image or SITE + '/img/og.jpg'}">
<meta name="twitter:card" content="summary_large_image">
{ld_html}
<link rel="preload" href="/polices/bricolage.woff2" as="font" type="font/woff2" crossorigin>
<style>{style}
{CSS}</style>
</head>
<body>

<header class="nav">
  <div class="wrap nav-in">
    <a class="brand" href="/en/"><img src="/img/logo.png" alt="" width="30" height="30"><b>ORION</b></a>
    <nav>
      <a href="/en/">The launcher</a>
      <a href="/en/games"{' aria-current="page"' if rubrique == "games" else ""}>Game requirements</a>
      <a href="/en/#faq">Questions</a>
      <a href="{francais}" lang="fr">Français</a>
    </nav>
    <span class="sp"></span>
    <a class="btn" href="/en/#installer">Download</a>
  </div>
</header>

<main class="wrap">
{corps}
</main>

<footer>
  <div class="wrap foot">
    <span class="sign">ORION reads your PC and tells you what to play, with which settings.</span>
    <span class="sp"></span>
    <nav aria-label="Footer links">
      <a href="/en/">Home</a>
      <a href="/en/games">Game requirements</a>
      <a href="/en/one-launcher-all-games">All your games, one launcher</a>
      <a href="/en/what-orion-sends">What ORION sends</a>
      <a href="https://github.com/Sikher-kisa/orion-game-launcher/releases" rel="noopener">Releases</a>
      <a href="/mentions-legales" lang="fr">Mentions légales (legal notice, French)</a>
      <a href="{francais}" lang="fr">Site en français</a>
    </nav>
  </div>
</footer>
<script src="/glisse.js" defer></script>
<script src="/clic.js" defer></script>
</body>
</html>
"""


def appel():
    return f"""  <section class="bloc">
    <p class="eyebrow">On your PC</p>
    <h2>The same estimate with your own hardware, and the settings applied for you</h2>
    <p>ORION is a free game launcher for Windows. It reads your graphics card, processor and
      screen, estimates every game in your library, then measures the real frame rate while you
      play and sets the game up with its "Recommended" profile. No account, no ads.</p>
    <div class="appel">
      <a class="btn" href="{EXE}">Download ORION for Windows</a>
      <a class="btn ghost" href="{STORE}" rel="noopener">Microsoft Store</a>
      <a class="btn ghost" href="/en/">About the launcher</a>
    </div>
  </section>
"""


def page_jeu(j, style, tous, releve, avec_page, fr_de):
    exig, nom, s = j["exig"], j["nom"], j["slug"]
    rec, mini = exig.recommandee, exig.minimum
    estimable = j["estimable"]
    lignes = []
    c1080 = cmin = ev3060 = ev4060 = None
    if estimable:
        for cle, carte, vram in CARTES:
            tds = "".join(cellule(evaluer(exig, cle, vram, px, d)) for _, d, px in DEFS)
            lignes.append(f'<tr><th scope="row"><a href="/en/games/gpu/{slug(carte)}">{e(carte)}</a> '
                          f'<span class="mono" style="color:var(--dim);'
                          f'font-weight:400;font-size:13px">{vram} GB</span></th>{tds}</tr>')
        c1080, _ = fr.premiere(exig, DEFS[0][2], DEFS[0][1], ("haute",))
        cmin, _ = fr.premiere(exig, DEFS[0][2], DEFS[0][1], ("haute", "moyenne", "basse"))
        ev3060 = evaluer(exig, "rtx 3060", 12, DEFS[0][2], DEFS[0][1])
        ev4060 = evaluer(exig, "rtx 4060", 8, DEFS[0][2], DEFS[0][1])
    ram = (rec and rec.ram_go) or (mini and mini.ram_go)

    def phrase(carte, ev):
        if getattr(ev, "bloque", ""):
            return (f"A {carte} can't run {nom}: the game requires a graphics card with hardware ray tracing "
                    f"({CARTES_RT}).")
        if ev.niveau in NIVEAU:
            bas, haut = ev.fps[ev.niveau]
            return (f"By our estimate, a {carte} runs {nom} at 1080p on {NIVEAU[ev.niveau].lower()} "
                    f"settings, {reglages.fourchette(bas, haut, 'en', 'long')}.")
        return (f"By our estimate, a {carte} is too weak for {nom} at 1080p: under 30 frames per "
                f"second, even on the lowest settings.")

    grec, gmin = dict(j["rec"]).get("Graphics"), dict(j["min"]).get("Graphics")
    r1 = f"The publisher recommends: {fr.sans_point(grec)}. " if grec else ""
    if not estimable:
        r1 += f"Minimum: {fr.sans_point(gmin)}. " if gmin and gmin != grec else ""
        r1 += ("The official page does not name a specific graphics card for both minimum and "
               "recommended specs, so we give no frame-rate estimate for this game. ORION does the "
               "maths on your own PC.")
    elif c1080:
        r1 += f"By our conservative estimate, high settings hold 60 frames per second at 1080p with a {c1080}"
        r1 += (f", and a {cmin} gets there with lower settings." if cmin and cmin != c1080 else ".")
    else:
        r1 += ("By our conservative estimate, no card on our list holds 60 frames per second at 1080p "
               "on high settings.")
    faq = [(f"Which graphics card do I need for {nom} at 1080p?", r1)]
    if estimable:
        faq += [(f"Can I run {nom} on an RTX 3060?", phrase("GeForce RTX 3060", ev3060)),
                (f"Can I run {nom} on an RTX 4060?", phrase("GeForce RTX 4060", ev4060))]
    if ram:
        faq.append((f"How much RAM does {nom} need?",
                    f"The publisher recommends {ram:g} GB of RAM"
                    + (f" (minimum: {mini.ram_go:g} GB)." if mini and mini.ram_go and rec and rec.ram_go
                       and mini.ram_go != rec.ram_go else ".")))
    disque = dict(j["rec"]).get("Storage") or dict(j["min"]).get("Storage")
    if disque:
        faq.append((f"How much storage does {nom} take?",
                    f"The official page asks for {disque} of storage."))
    # best settings by card (12 October): ORION's "Recommended" profile
    conseils = reglages.conseils_du_jeu(exig, CARTES, DEFS[:2]) if estimable else {}
    question = reglages.faq(nom, conseils, DEFS, "en") if conseils else None
    if question:
        faq.insert(1, question)
    faq_html = "\n".join(f"<details><summary>{e(q)}</summary><p>{e(r)}</p></details>" for q, r in faq)

    def bloc(titre, items):
        if not items:
            return ""
        dl = "".join(f"<div><dt>{e(k)}</dt><dd>{e(v)}</dd></div>" for k, v in items)
        return f"<article><h3>{titre}</h3><dl>{dl}</dl></article>"

    resume = []
    if grec:
        resume.append(("Publisher's recommended card", grec))
    if gmin:
        resume.append(("Minimum card", gmin))
    if ram:
        resume.append(("Recommended RAM", f"{ram:g} GB"))
    if c1080:
        resume.append(("Our conservative estimate", f"60 fps at 1080p, high settings, with a {c1080}"))
    resume_html = "".join(f"<div><span>{e(k)}</span><b>{e(v)}</b></div>" for k, v in resume)

    base = "recommended" if rec and rec.gpu else "minimum"
    i = tous.index(j)
    autres = [x for x in tous if x["slug"] != s]
    miens = set(j["genres"])

    def proximite(k):
        x = autres[k]
        return (-len(miens & set(x["genres"])), (k - i) % max(len(autres), 1))
    voisins = [autres[k] for k in sorted(range(len(autres)), key=proximite)[:8]]
    autres_html = "".join(f'<a href="/en/games/{x["slug"]}">{e(x["nom"])}</a>' for x in voisins)
    genres_html = " · ".join(f'<a href="/en/games/genre/{slug(g)}">{e(g)} games</a>' for g in j["genres"][:4]
                             if g in avec_page)

    if estimable:
        estim_html = f"""  <section class="bloc">
    <p class="eyebrow">Estimate per graphics card</p>
    <h2>Which settings to aim for with your card</h2>
    <p>For each card: the highest settings level that stays smooth, and the expected frame-rate
      range. This is a conservative estimate worked out from the publisher's {base} specs, not a
      measurement: your processor, drivers and game updates move it.</p>
    <div class="defile">
      <table class="perf">
        <thead><tr><th scope="col">Graphics card</th><th scope="col">1080p</th>
          <th scope="col">1440p</th><th scope="col">4K</th></tr></thead>
        <tbody>
{chr(10).join(lignes)}
        </tbody>
      </table>
    </div>
    <p>Without DLSS, FSR or frame generation: turning them on raises the frame rate noticeably
      when the game offers them.</p>
  </section>

"""
        if conseils:
            estim_html += reglages.section(nom, j["appid"], conseils, CARTES, DEFS[:2], "en")
        # « best settings » et « FPS » (13 octobre), comme les pages francaises
        titre = ajuste([f"{nom} system requirements, best settings & FPS",
                        f"{nom} requirements, best settings & FPS",
                        f"{nom} system requirements and PC settings",
                        f"{nom} system requirements", f"{nom} PC requirements", f"{nom} specs"], TITRE_MAX)
        desc = ajuste([f"Minimum and recommended specs for {nom}, best settings and estimated FPS on "
                       f"{fr.NB_CARTES} graphics cards (RTX 4060, RX 7600…) from 1080p to 4K.",
                       f"Minimum and recommended specs for {nom}, best settings and estimated FPS on "
                       f"{fr.NB_CARTES} graphics cards, from 1080p to 4K.",
                       f"{nom} specs, best settings and FPS on {fr.NB_CARTES} graphics cards, from 1080p to 4K."],
                      DESC_MAX)
        methode_html = """    <details><summary>How are these estimates worked out?</summary><p>The publisher's
      recommended specs are the reference point (about 60 frames per second at 1080p on high
      settings, unless the publisher says otherwise). Each card's power is compared with the
      recommended card (the average when the publisher names several), then adjusted to the screen
      resolution. A low margin is kept, and less video memory than recommended drops one level.</p></details>
"""
    else:
        estim_html = """  <section class="bloc">
    <p class="eyebrow">Estimate per graphics card</p>
    <h2>No frame-rate estimate for this game</h2>
    <p>The official page does not name a specific graphics card for both the minimum and the
      recommended specs. Rather than an invented number, we give none. ORION does the maths on your
      own PC, with your card, processor and screen, then measures the real frame rate while you play.</p>
  </section>

"""
        titre = ajuste([f"{nom} system requirements (PC)", f"{nom} PC requirements", f"{nom} specs"], TITRE_MAX)
        detail = ((f": {ram:g} GB of RAM" if ram else "") + (f", {grec or gmin}" if (grec or gmin) else ""))
        desc = ajuste([f"Minimum and recommended PC specs for {nom}, from the official store page{detail}.",
                       f"Minimum and recommended PC specs for {nom}{detail}.",
                       f"Minimum and recommended PC specs for {nom}, from the official store page."], DESC_MAX)
        methode_html = ""

    achat_html = ""
    if not j["gratuit"]:
        achat_html = f"""  <section class="bloc">
    <p class="eyebrow">Where to buy</p>
    <h2>Buy {e(nom)}</h2>
    <p>The official page first. In ORION, the Store tab compares prices across shops, with the
      official stores listed before key resellers.</p>
    <div class="autres">
      <a href="https://store.steampowered.com/app/{e(j["appid"])}/" rel="noopener nofollow">Steam (official store)</a>
    </div>
  </section>

"""
    genres = ", ".join(j["genres"]) or "game"
    titre_html = f"""<h1>Can you run {e(nom)}? PC requirements and settings</h1>
    <p class="lede">{e(nom)}, by {e(j["dev"])} ({e(genres)}), came out on Steam on {e(j["date"])}.
      Here are the official specs, and what they mean on the most common graphics cards.</p>"""
    image = fr.visuel(j["appid"], "visuel", "eager")
    if image:
        titre_html = f"""<div class="tete-jeu">
      <div>
    {titre_html}
      </div>
      {image}
    </div>"""
    corps = f"""  <div class="tete">
    <p class="fil"><a href="/en/">ORION</a> › <a href="/en/games">Game requirements</a> › {e(nom)}</p>
    {titre_html}
    <div class="resume">{resume_html}</div>
  </div>

{estim_html}  <section class="bloc">
    <p class="eyebrow">Official specs</p>
    <h2>Minimum and recommended requirements</h2>
    <div class="configs">
      {bloc("Minimum", j["min"])}
      {bloc("Recommended", j["rec"])}
    </div>
    <p>Source: <a href="https://store.steampowered.com/app/{e(j["appid"])}/" rel="noopener nofollow">the
      game's Steam page</a>, read on {date_en(releve)}.</p>
  </section>

{achat_html}{appel()}
  <section class="bloc">
    <p class="eyebrow">Questions</p>
    <h2>{e(nom)} at a glance</h2>
{faq_html}
{methode_html}  </section>

  <section class="bloc">
    <p class="eyebrow">Other games</p>
    <h2>Check another game's requirements</h2>
    <div class="autres">{autres_html}<a href="/en/games">All games</a></div>
{f"    <p>By genre: {genres_html}</p>{chr(10)}" if genres_html else ""}  </section>"""
    jeu_ld = {"@context": "https://schema.org", "@type": "VideoGame", "name": nom, "inLanguage": "en",
              "url": f"{SITE}/en/games/{s}", "gamePlatform": "PC", "operatingSystem": "Windows",
              "applicationCategory": "Game", "genre": j["genres"],
              "author": {"@type": "Organization", "name": j["dev"]}}
    if str(j["appid"]) in fr.VISUELS:
        jeu_ld["image"] = fr.image_og(j["appid"])   # the site's own image, not Steam's address
    elif j["img"]:
        jeu_ld["image"] = j["img"]
    ld = [jeu_ld,
          {"@context": "https://schema.org", "@type": "FAQPage",
           "mainEntity": [{"@type": "Question", "name": q,
                           "acceptedAnswer": {"@type": "Answer", "text": r}} for q, r in faq]},
          {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [
              {"@type": "ListItem", "position": 1, "name": "ORION", "item": SITE + "/en/"},
              {"@type": "ListItem", "position": 2, "name": "Game requirements", "item": SITE + "/en/games"},
              {"@type": "ListItem", "position": 3, "name": nom, "item": f"{SITE}/en/games/{s}"}]}]
    return gabarit(style, titre, desc, f"/en/games/{s}", ld, corps, fr_de.get(j["appid"]),
                   image=fr.image_og(j["appid"]))


def carte_jeu(j, sous=None):
    if sous is None:
        sous = ("Recommended card: " + " or ".join(j["cites"][:2])) if j["cites"] else \
            "Official specs" + (" and estimates" if j["estimable"] else "")
    img = fr.visuel(j["appid"])
    classe = ' class="avec-visuel"' if img else ""
    return f'<a href="/en/games/{j["slug"]}"{classe}>{img}<b>{e(j["nom"])}</b><span>{e(sous)}</span></a>'


def page_liste(jeux, style, releve, chemin, titre, desc, eyebrow, h1, lede, cartes, fil=None, avant=""):
    fil_html = (f'    <p class="fil"><a href="/en/">ORION</a> › <a href="/en/games">Game requirements</a> › {e(fil)}</p>\n'
                if fil else "")
    corps = f"""  <div class="tete">
{fil_html}    <p class="eyebrow">{e(eyebrow)}</p>
    <h1>{h1}</h1>
    <p class="lede">{lede}
      Specs read on {date_en(releve)}.</p>
  </div>
{avant}  <section>
    <div class="filtre" id="filtre" hidden>
      <input type="search" id="filtre-jeux" placeholder="Search for a game…" aria-label="Search for a game in the list" autocomplete="off">
      <span id="filtre-compte"></span>
    </div>
    <div class="liste-jeux" id="liste-jeux">
{chr(10).join(cartes)}
    </div>
  </section>
{appel()}"""
    corps += """
  <script>
  (function () {
    var liens = document.querySelectorAll("#liste-jeux a"), boite = document.getElementById("filtre");
    var champ = document.getElementById("filtre-jeux"), compte = document.getElementById("filtre-compte");
    if (!boite || liens.length < 40) { return; }
    boite.hidden = false;
    function plat(t) { return t.normalize("NFD").replace(/[\\u0300-\\u036f]/g, "").toLowerCase(); }
    var noms = Array.prototype.map.call(liens, function (a) { return plat(a.querySelector("b").textContent); });
    function filtrer() {
      var q = plat(champ.value.trim()), n = 0;
      Array.prototype.forEach.call(liens, function (a, i) {
        var vu = !q || noms[i].indexOf(q) !== -1;
        a.hidden = !vu;
        if (vu) { n += 1; }
      });
      compte.textContent = q ? n + (n === 1 ? " game found" : " games found") : liens.length + " games";
    }
    champ.addEventListener("input", filtrer);
    filtrer();
  }());
  </script>"""
    miettes = [{"@type": "ListItem", "position": 1, "name": "ORION", "item": SITE + "/en/"},
               {"@type": "ListItem", "position": 2, "name": "Game requirements", "item": SITE + "/en/games"}]
    if fil:
        miettes.append({"@type": "ListItem", "position": 3, "name": fil, "item": SITE + chemin})
    ld = [{"@context": "https://schema.org", "@type": "ItemList", "name": h1_texte(h1),
           "itemListElement": [{"@type": "ListItem", "position": i + 1, "name": j["nom"],
                                "url": f"{SITE}/en/games/{j['slug']}"} for i, j in enumerate(jeux)]},
          {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": miettes}]
    alt = "/jeux" if chemin == "/en/games" else None
    return gabarit(style, titre, desc, chemin, ld, corps, alt)


def genres_de(jeux):
    par = {}
    for j in jeux:
        for g in j["genres"]:
            par.setdefault(g, []).append(j)
    return dict(sorted(((g, l) for g, l in par.items() if len(l) >= 5), key=lambda gl: (-len(gl[1]), gl[0])))


def choisir(donnees):
    jeux, pris = [], set()
    for rang, (appid, x) in enumerate(donnees.items()):
        if x.get("err") or not x.get("n") or not (x.get("min") or "").strip():
            continue
        nom = propre(x["n"])
        exig = Exigences(appid=appid, titre=nom)
        exig.minimum, exig.recommandee = lire_config(x.get("min", "")), lire_config(x.get("rec", ""))
        cites = repere(x.get("rec", ""), exig.recommandee)
        repere(x.get("min", ""), exig.minimum)
        if fr.est_un_logiciel(x.get("g") or []):
            fr.RETIRES_EN.append(slug(nom))
            continue                      # software (Wallpaper Engine), not a game
        genres = [g for g in (x.get("g") or []) if g.lower() not in PAS_UN_GENRE]
        if not genres and any(g.lower() in PAS_UN_GENRE - {"free to play", "early access"} for g in x.get("g") or []):
            continue                      # software, not a game
        j = {"appid": appid, "nom": nom, "slug": slug(nom), "exig": exig, "cites": cites, "genres": genres,
             "estimable": bool(exig.recommandee and exig.recommandee.gpu and exig.minimum and exig.minimum.gpu),
             "img": x.get("img") or "", "dev": x.get("dev") or "its studio", "date": sortie_en(x.get("d") or ""),
             "gratuit": bool(x.get("free")), "rang": rang,
             "min": champs(x.get("min", "")), "rec": champs(x.get("rec", ""))}
        if not j["slug"] or not j["date"] or not j["min"]:
            continue
        if j["slug"] in pris:
            continue          # same name twice (a second Steam entry): the better-known one keeps the page
        pris.add(j["slug"])
        jeux.append(j)
    return jeux


def pages_fr(dossier: Path) -> dict:
    """{appid: /jeux/<slug>} of the French game pages, from the Steam link each one cites."""
    fr_de = {}
    for p in sorted((dossier / "jeux").glob("*.html")):
        m = re.search(r"store\.steampowered\.com/app/(\d+)/", p.read_text(encoding="utf-8"))
        if m:
            fr_de.setdefault(m.group(1), f"/jeux/{p.stem}")
    return fr_de


def relier_fr(dossier: Path, fr_de: dict, en_de: dict) -> int:
    """hreflang on the French pages that have an English twin (same set both ways)."""
    n = 0
    for appid, chemin_fr in fr_de.items():
        if appid not in en_de:
            continue
        p = dossier / (chemin_fr.lstrip("/") + ".html")
        s = p.read_text(encoding="utf-8")
        if 'hreflang="en"' in s:
            continue
        lien = (f'<link rel="canonical" href="{SITE}{chemin_fr}">'
                f'\n<link rel="alternate" hreflang="fr" href="{SITE}{chemin_fr}">'
                f'\n<link rel="alternate" hreflang="en" href="{SITE}{en_de[appid]}">'
                f'\n<link rel="alternate" hreflang="x-default" href="{SITE}{en_de[appid]}">')
        s2 = s.replace(f'<link rel="canonical" href="{SITE}{chemin_fr}">', lien, 1)
        s2 = s2.replace('<a href="/mentions-legales">Mentions légales</a>',
                        f'<a href="{en_de[appid]}" lang="en">English</a>\n      '
                        '<a href="/mentions-legales">Mentions légales</a>', 1)
        if s2 != s:
            p.write_text(s2, encoding="utf-8")
            n += 1
    return n


def relier_accueil_en(dossier: Path) -> None:
    """The English landing links to the game pages (nav and footer)."""
    p = dossier / "en" / "index.html"
    s = p.read_text(encoding="utf-8")
    if 'href="/en/games"' in s:
        return
    s = s.replace('<a href="#faq">Questions</a>', '<a href="/en/games">Game requirements</a>\n      '
                  '<a href="#faq">Questions</a>', 1)
    s = s.replace('<a href="/en/what-orion-sends">What ORION sends</a>\n      <a href="/mentions-legales"',
                  '<a href="/en/games">Game requirements</a>\n      '
                  '<a href="/en/what-orion-sends">What ORION sends</a>\n      <a href="/mentions-legales"', 1)
    p.write_text(s, encoding="utf-8")


def main(dossier, source, releve="") -> int:
    dossier = Path(dossier)
    donnees = json.loads(Path(source).read_text(encoding="utf-8"))
    releve = dt.date.fromisoformat(releve) if releve else \
        dt.date.fromtimestamp(Path(source).stat().st_mtime)
    accueil = (dossier / "index.html").read_text(encoding="utf-8")
    style = re.search(r"<style>(.*?)</style>", accueil, re.S).group(1)

    import jaquettes
    fr.VISUELS.update(jaquettes.disponibles(dossier))     # deja lus par les pages francaises
    jeux = choisir(donnees)
    fr.rediriger(dossier, [f"/en/games/{r}" for r in fr.RETIRES_EN], "/en/games")
    jeux.sort(key=lambda j: j["nom"].lower())
    assert len({j["slug"] for j in jeux}) == len(jeux)
    fr_de = pages_fr(dossier)
    en_de = {j["appid"]: f"/en/games/{j['slug']}" for j in jeux}
    genres = genres_de(jeux)

    cible = dossier / "en" / "games"
    for sous in (cible, cible / "genre", cible / "gpu"):
        sous.mkdir(parents=True, exist_ok=True)
        for ancien in sous.glob("*.html"):
            ancien.unlink()
    for j in jeux:
        (cible / f"{j['slug']}.html").write_text(page_jeu(j, style, jeux, releve, set(genres), fr_de),
                                                 encoding="utf-8")
    # index de la barre de recherche (14 octobre), the best-known games first
    import gen_recherche
    gen_recherche.ecrire_index(dossier / "en" / "search.json", jeux, fr.VISUELS, rang=lambda j: j.get("rang", 0))
    for g, l in genres.items():
        noms = ", ".join(x["nom"] for x in l[:3])
        (cible / "genre" / f"{slug(g)}.html").write_text(page_liste(
            l, style, releve, f"/en/games/genre/{slug(g)}",
            ajuste([f"{g} PC games: system requirements ({len(l)} games)", f"{g} PC games: system requirements",
                    f"{g} games: PC requirements"], TITRE_MAX),
            ajuste([f"Minimum and recommended specs for {len(l)} {g} PC games ({noms}…), with the settings "
                    f"to expect per graphics card.",
                    f"Minimum and recommended specs for {len(l)} {g} PC games, with the settings to expect "
                    f"per graphics card."], DESC_MAX),
            f"{g} games · {len(l)} games", f"Which PC do you need for {e(g)} games?",
            f"The {e(g)} games in our catalogue, with their official specs and, when the store page "
            f"allows it, the settings to expect on {fr.NB_CARTES} graphics cards.",
            [carte_jeu(x) for x in l], fil=f"{g} games"), encoding="utf-8")
    for cle, nom, vram in CARTES:
        lignes, tient, juste, bloques = [], 0, 0, 0
        est = [j for j in jeux if j["estimable"]]
        for j in est:
            ev1, ev2 = (evaluer(j["exig"], cle, vram, px, d) for _, d, px in DEFS[:2])
            if ev1.bloque:
                sous, bloques = "won't launch: hardware ray tracing required", bloques + 1
            elif ev1.niveau in NIVEAU:
                bas, haut = ev1.fps[ev1.niveau]
                sous = f"1080p: {NIVEAU[ev1.niveau].lower()}, {reglages.fourchette(bas, haut, 'en')}"
                if ev2.niveau in NIVEAU:
                    b2, h2 = ev2.fps[ev2.niveau]
                    sous += f" · 1440p: {NIVEAU[ev2.niveau].lower()}, {reglages.fourchette(b2, h2, 'en')}"
                else:
                    sous += " · 1440p: too weak"
                tient += 1
            else:
                sous, juste = "1080p: too weak, under 30 fps even on low", juste + 1
            lignes.append(carte_jeu(j, sous))
        chemin = f"/en/games/gpu/{slug(nom)}"
        bilan = f"{tient} games run, {juste} are too heavy" + (f", {bloques} won't launch" if bloques else "")
        (cible / "gpu" / f"{slug(nom)}.html").write_text(page_liste(
            est, style, releve, chemin,
            ajuste([f"Which games run on a {nom}? ({len(est)} games)", f"Games that run on a {nom}",
                    f"{nom}: which games?"], TITRE_MAX),
            ajuste([f"{nom} ({vram} GB): settings and frame rates to expect in {len(est)} PC games at 1080p "
                    f"and 1440p. {bilan}.",
                    f"{nom} ({vram} GB): settings and fps to expect in {len(est)} PC games. {bilan}.",
                    f"{nom} ({vram} GB): settings and frame rates to expect in {len(est)} PC games at 1080p "
                    f"and 1440p."], DESC_MAX),
            f"{nom} · {len(est)} games", f"What can a {e(nom)} run?",
            f"For each game, the highest settings that stay smooth on a {e(nom)} ({vram} GB of video "
            f"memory), and the expected frame rate at 1080p then 1440p. Conservative estimate from the "
            f"publisher's recommended specs, without DLSS or FSR; {bilan}"
            + (" (they require hardware ray tracing)." if bloques else "."),
            lignes, fil=nom), encoding="utf-8")
    liens_g = "".join(f'<a href="/en/games/genre/{slug(g)}">{e(g)} <span>{len(l)} games</span></a>'
                      for g, l in genres.items())
    liens_c = "".join(f'<a href="/en/games/gpu/{slug(nom)}">{e(nom)} <span>{vram} GB</span></a>'
                      for _, nom, vram in CARTES)
    avant = f"""  <section class="bloc">
    <p class="eyebrow">By genre</p>
    <h2>Requirements by game genre</h2>
    <div class="liste-jeux liste-courte">{liens_g}</div>
  </section>
  <section class="bloc">
    <p class="eyebrow">By graphics card</p>
    <h2>Which games run on your card?</h2>
    <p>For each common card: the settings and frame rates to expect, game by game.</p>
    <div class="liste-jeux liste-courte">{liens_c}</div>
  </section>
"""
    n_est = sum(1 for j in jeux if j["estimable"])
    (dossier / "en" / "games.html").write_text(page_liste(
        jeux, style, releve, "/en/games",
        "PC game system requirements: which graphics card?",
        ajuste([f"System requirements and recommended settings for {len(jeux)} PC games (Counter-Strike 2, "
                f"Cyberpunk 2077, Elden Ring…), estimated per graphics card from 1080p to 4K.",
                f"System requirements and best settings for {len(jeux)} PC games (Counter-Strike 2, "
                f"Cyberpunk 2077, Elden Ring…), estimated per graphics card from 1080p to 4K."], DESC_MAX),
        f"Game requirements · {len(jeux)} games", "Can your PC run it?",
        f"For each game: the official specs and, for {n_est} of them, the settings level to expect from "
        f"{fr.NB_CARTES} common graphics cards at 1080p, 1440p and 4K. The numbers are conservative estimates, "
        f"worked out with the estimate engine of the ORION launcher.",
        [carte_jeu(j) for j in jeux], avant=avant), encoding="utf-8")
    # the French index points back to the English one
    p = dossier / "jeux.html"
    s = p.read_text(encoding="utf-8")
    if 'hreflang="en"' not in s:
        s = s.replace(f'<link rel="canonical" href="{SITE}/jeux">',
                      f'<link rel="canonical" href="{SITE}/jeux">'
                      f'\n<link rel="alternate" hreflang="fr" href="{SITE}/jeux">'
                      f'\n<link rel="alternate" hreflang="en" href="{SITE}/en/games">'
                      f'\n<link rel="alternate" hreflang="x-default" href="{SITE}/en/games">', 1)
        p.write_text(s, encoding="utf-8")
    jumeaux = relier_fr(dossier, fr_de, en_de)
    relier_accueil_en(dossier)

    plan = dossier / "sitemap.xml"
    x = plan.read_text(encoding="utf-8")
    x = re.sub(r"  <url>\n    <loc>" + re.escape(SITE) + r"/en/games[^<]*</loc>.*?</url>\n", "", x, flags=re.S)
    auj = dt.date.today().isoformat()
    bloc = "".join(f"  <url>\n    <loc>{SITE}{c}</loc>\n    <lastmod>{auj}</lastmod>\n"
                   f"    <changefreq>monthly</changefreq>\n    <priority>{p}</priority>\n  </url>\n"
                   for c, p in [("/en/games", "0.9")]
                   + [(f"/en/games/genre/{slug(g)}", "0.8") for g in genres]
                   + [(f"/en/games/gpu/{slug(nom)}", "0.8") for _, nom, _ in CARTES]
                   + [(f"/en/games/{j['slug']}", "0.7") for j in jeux])
    x = x.replace("</urlset>", bloc + "</urlset>")
    plan.write_text(x, encoding="utf-8")
    sans = sum(1 for j in jeux if not j["estimable"])
    print(f"{len(jeux)} English game pages ({sans} without estimate), {len(genres)} genre pages, "
          f"{len(CARTES)} card pages ; {jumeaux} French pages linked to their English twin")
    return len(jeux)


if __name__ == "__main__":
    main(*sys.argv[1:4])
