/* Comparateur de prix du site (10 octobre, demande de l'auteur : « en tete le
   moins cher des liens officiels, puis une comparaison sur Kinguin, Instant
   Gaming et autres, sur tous les jeux »).

   Lu chez le visiteur, aupres du service d'ORION (et de lui seul) :
   - boutiques officielles : relais IsThereAnyDeal (donnees creditees, liens
     des boutiques laisses tels quels) ; la moins chere en tete ;
   - revendeurs de cles, a part et apres : Kinguin et Loaded avec leur prix
     verifie (cle Steam du jeu, en euros), Instant Gaming en recherche filtree.
     Jamais presentes comme « le meilleur prix ».
   Aucune donnee du visiteur n'est envoyee : seulement le jeu demande.

   Un bloc : <div data-comparatif data-appid="1086940" data-titre="..." data-auto="1">.
   Sans data-auto, un bouton « Prix et boutiques » charge le bloc au clic.
   Page Sorties (10 octobre) : data-revendeurs = les fiches choisies a la main
   (JSON, plusieurs par revendeur possibles), data-officiels = liens officiels
   d'un jeu sans prix IsThereAnyDeal (console) ; data-une="1" : prix releve
   toutes les 10 minutes (la sortie a la une).
   Codes promo (15 octobre) : CODES est ecrit par assembler.py depuis
   orion/codes_promo.py (le meme que l'application) ; un code s'affiche sous
   le lien de son revendeur entre ses dates, et disparait seul apres. */
(function () {
  "use strict";
  var API = "https://api.orion-launcher.com";
  var IG = "https://www.instant-gaming.com/fr/rechercher/?query=";
  var IG_FILTRES = "&platform%5B%5D=1&type%5B%5D=Steam&type%5B%5D=Rockstar&type%5B%5D=Ubisoft+Connect" +
    "&type%5B%5D=Microsoft+Store&type%5B%5D=Instant+Gaming&type%5B%5D=GOG.com&type%5B%5D=Epic+Games" +
    "&type%5B%5D=EA+App&type%5B%5D=Battle.net&product_types%5B%5D=game&product_types%5B%5D=preorder&os%5B%5D=1";
  // Liens partenaires via le service (16 octobre) : /aller/<site>?u=...&p=<page>
  // y ajoute l'identifiant partenaire et compte le clic ; interdit aux robots
  // (les adresses partenaires en clair etaient suivies par Googlebot).
  var ALLER = "https://api.orion-launcher.com/aller/";
  function pageSite() {
    var p = location.pathname;
    if (p.indexOf("/jeux/") === 0) return "jeu";
    if (p.indexOf("/sorties") === 0) return "sorties";
    if (p.indexOf("/bons-plans") === 0 || p.indexOf("/black-friday") === 0) return "bons-plans";
    if (p.indexOf("/gratuits") === 0) return "gratuits";
    if (p.indexOf("/recherche") === 0) return "recherche";
    if (p.indexOf("/en/") === 0 || p === "/en") return "en";
    if (p === "/" || p === "/index.html") return "accueil";
    return "autre";
  }
  function aller(site, u) { return ALLER + site + "?u=" + encodeURIComponent(u) + "&p=" + pageSite(); }
  var PARTENAIRE = {
    loaded: function (u) { return aller("loaded", u); },
    kinguin: function (u) { return aller("kinguin", u); },
    "instant-gaming": function (u) { return aller("instant-gaming", u); }
  };
  var NOMS = { loaded: "Loaded", kinguin: "Kinguin", "instant-gaming": "Instant Gaming" };
  var CODES = /*CODES*/[];
  var MOIS = ["janvier", "f\u00e9vrier", "mars", "avril", "mai", "juin", "juillet", "ao\u00fbt", "septembre", "octobre",
    "novembre", "d\u00e9cembre"];
  var HOTES = { loaded: "https://www.loaded.com/", kinguin: "https://www.kinguin.net/" };
  var MAX_OFFICIELS = 6;
  // Vitrines d'une meme enseigne pour d'autres pays (identifiants
  // IsThereAnyDeal) : [enseigne, devise, pays]. Les memes que VITRINES dans
  // orion/itad.py (un test le verifie). Le site est en France : on garde les
  // vitrines en euros, une seule par enseigne (la francaise si elle est la).
  // Le 10 octobre, GamesPlanet US (vendu en dollars) passait en tete.
  var VITRINES = { 28: ["gamesplanet", "EUR", "FR"], 27: ["gamesplanet", "EUR", "DE"],
    26: ["gamesplanet", "GBP", "GB"], 29: ["gamesplanet", "USD", "US"], 64: ["wingamestore", "USD", "US"] };

  function duPays(deals) {
    var gardees = [], enseignes = {};
    deals.forEach(function (d) {
      var v = VITRINES[d.shop.id];
      if (!v) { gardees.push(d); return; }
      if (v[1] !== "EUR") { return; }
      (enseignes[v[0]] = enseignes[v[0]] || []).push(d);
    });
    Object.keys(enseignes).forEach(function (k) {
      var l = enseignes[k], fr = l.filter(function (d) { return VITRINES[d.shop.id][2] === "FR"; });
      gardees.push(fr.length ? fr[0] : l.sort(function (a, b) { return montant(a.price) - montant(b.price); })[0]);
    });
    return deals.filter(function (d) { return gardees.indexOf(d) >= 0; });
  }

  // « clé Steam », « clé Microsoft Store »... quand la boutique vend la clé
  // d'une autre plate-forme : l'acheteur sait ce qu'il recoit.
  // 11 octobre : GOG s'affichait « (clé Drm Free) » ; un jeu sans DRM n'est
  // pas une clé d'une autre plate-forme, il se dit « sans DRM »
  function cle(d) {
    var drm = ((d.drm || [])[0] || {}).name || "";
    if (/drm\s*free/i.test(drm)) { return " (sans DRM)"; }
    return drm && drm !== d.shop.name ? " (clé " + drm + ")" : "";
  }

  function euros(v) { return Number(v).toFixed(2).replace(".", ",") + " €"; }
  function noeud(tag, classe, texte) {
    var n = document.createElement(tag);
    if (classe) { n.className = classe; }
    if (texte !== undefined) { n.textContent = texte; }
    return n;
  }
  function lien(url, texte, rel) {
    var a = noeud("a", "", texte);
    a.href = url; a.rel = rel || "noopener nofollow";
    return a;
  }
  function montant(b) { return b && b.amount > 0 ? Number(b.amount) : 0; }

  function style() {
    if (document.getElementById("style-comparatif")) { return; }
    var s = noeud("style");
    s.id = "style-comparatif";
    s.textContent =
      ".cmp{margin-top:14px;display:grid;gap:10px}" +
      ".cmp-tete{display:flex;flex-wrap:wrap;align-items:center;gap:10px 18px;background:var(--panel,#121a2b);" +
      "border:1px solid var(--line-hi,#2b3a55);border-radius:14px;padding:14px 16px}" +
      ".cmp-tete b.cmp-prix{font-size:28px;color:#57D98A;font-variant-numeric:tabular-nums;line-height:1}" +
      ".cmp-tete .cmp-ou{flex:1 1 200px;color:var(--dim,#aab4c8);font-size:14.5px}" +
      ".cmp-liste{display:grid;gap:4px;font-size:14.5px}" +
      ".cmp-ligne{display:flex;justify-content:space-between;gap:12px;border-bottom:1px solid var(--line,#1f2a40);padding:5px 0}" +
      ".cmp-ligne span:last-child{font-variant-numeric:tabular-nums;white-space:nowrap}" +
      ".cmp h3{font-size:15px;margin-top:6px}.cmp small{color:var(--dim,#aab4c8)}" +
      ".cmp-bouton{font:inherit;font-size:13.5px;color:var(--ink,#e7ecf5);background:var(--panel,#121a2b);" +
      "border:1px solid var(--accent,#38E1FF);border-radius:999px;padding:5px 12px;cursor:pointer;margin-top:6px}" +
      ".cmp-remise{background:#57D98A;color:#07130C;border-radius:6px;padding:1px 6px;font-weight:700;font-size:12.5px;margin-left:6px;white-space:nowrap}" +
      ".cmp-code{font-size:13px;color:#57D98A;padding:2px 0 6px 14px}.cmp-code b{font-family:ui-monospace,Consolas,monospace;" +
      "background:rgba(87,217,138,.14);border:1px dashed rgba(87,217,138,.6);border-radius:6px;padding:0 6px}";
    document.head.appendChild(s);
  }

  function officiels(bloc, deals) {
    deals = (deals || []).filter(function (d) {
      return d && d.shop && montant(d.price) && (d.price.currency || "EUR") === "EUR" && /^https:\/\//.test(d.url || "");
    });
    deals = duPays(deals).sort(function (a, b) { return montant(a.price) - montant(b.price); });
    if (!deals.length) { return 0; }
    var meilleur = deals[0];
    var tete = noeud("div", "cmp-tete");
    tete.appendChild(noeud("b", "cmp-prix", euros(montant(meilleur.price))));
    var ou = noeud("span", "cmp-ou");
    ou.appendChild(document.createTextNode(officielle(meilleur.shop.name)
      ? "Le moins cher en boutique officielle : " : "Le moins cher chez un vendeur agréé : "));
    ou.appendChild(noeud("b", "", meilleur.shop.name));
    if (cle(meilleur)) { ou.appendChild(document.createTextNode(cle(meilleur))); }
    if (meilleur.cut > 0) { ou.appendChild(noeud("span", "cmp-remise", "-" + meilleur.cut + " %")); }
    tete.appendChild(ou);
    var bouton = lien(meilleur.url, "Voir l'offre");
    bouton.className = "btn";
    tete.appendChild(bouton);
    bloc.appendChild(tete);
    if (deals.length > 1) {
      var liste = noeud("div", "cmp-liste");
      deals.slice(1, MAX_OFFICIELS).forEach(function (d) {
        var l = noeud("div", "cmp-ligne");
        var g = noeud("span");
        g.appendChild(lien(d.url, d.shop.name));
        if (cle(d)) { g.appendChild(document.createTextNode(cle(d))); }
        l.appendChild(g);
        l.appendChild(noeud("span", "", euros(montant(d.price)) + (d.cut > 0 ? "  (-" + d.cut + " %)" : "")));
        liste.appendChild(l);
      });
      bloc.appendChild(liste);
    }
    return montant(meilleur.price);
  }

  // boutiques de l'editeur ou de la plate-forme ; les autres boutiques suivies
  // par IsThereAnyDeal sont des vendeurs agrees (10 octobre : PlayerLand etait
  // presente comme « boutique officielle »)
  var OFFICIELLES = ["Steam", "Epic Game Store", "Epic Games Store", "GOG", "GOG.com", "Microsoft Store",
    "Blizzard", "Battle.net", "Ubisoft Store", "Ubisoft Connect", "EA Store", "EA app", "PlayStation Store",
    "Nintendo eShop", "Rockstar Store", "Square Enix Store", "Bethesda.net"];
  function officielle(nom) { return OFFICIELLES.indexOf(nom) >= 0; }

  function sure(site, o, reference) {
    if (!o || o.devise !== "EUR" || !(o.prix > 0)) { return false; }
    if (String(o.url || "").indexOf(HOTES[site]) !== 0) { return false; }
    if (site === "loaded" && reference) { return o.public >= reference * 0.6 && o.public <= reference * 1.7; }
    return true;
  }

  function fichesChoisies(source) {
    if (!source.hasAttribute("data-revendeurs")) { return null; }
    try {
      return (JSON.parse(source.getAttribute("data-revendeurs") || "[]") || []).filter(function (r) {
        return r && /^https:\/\/www\.(instant-gaming\.com|kinguin\.net|loaded\.com)\//.test(r.url || "");
      });
    } catch (e) { return []; }
  }

  function ligne(liste, url, texte, droite) {
    var l = noeud("div", "cmp-ligne"), g = noeud("span");
    g.appendChild(lien(url, texte, "sponsored noopener nofollow"));
    l.appendChild(g);
    l.appendChild(noeud("span", "", droite));
    liste.appendChild(l);
  }

  // codes promo valables aujourd'hui pour un revendeur (dates incluses,
  // heure du visiteur) ; CODES vient de codes.json, ecrit avec le site
  function codesActifs(site) {
    var j = new Date(), jour = j.getFullYear() + "-" + ("0" + (j.getMonth() + 1)).slice(-2) + "-" + ("0" + j.getDate()).slice(-2);
    return CODES.filter(function (c) {
      return c && c.site === site && /^[A-Za-z0-9-]{1,20}$/.test(c.code || "") && c.remise &&
        /^\d{4}-\d{2}-\d{2}$/.test(c.debut || "") && /^\d{4}-\d{2}-\d{2}$/.test(c.fin || "") && c.debut <= jour && jour <= c.fin;
    });
  }

  function ligneCode(liste, site) {
    codesActifs(site).forEach(function (c) {
      var fin = c.fin.split("-"), l = noeud("div", "cmp-code"), b = noeud("b", "", c.code);
      var details = [c.quoi, c.limites].filter(Boolean).join(" ; ");
      l.appendChild(document.createTextNode("Code "));
      l.appendChild(b);
      l.appendChild(document.createTextNode(" : " + c.remise + " chez " + (NOMS[site] || site) + " jusqu'au " +
        (fin[2] === "01" ? "1er" : String(+fin[2])) + " " + MOIS[+fin[1] - 1] + (details ? " (" + details + ")." : ".")));
      liste.appendChild(l);
    });
  }

  function revendeurs(bloc, p, reference, titre, source) {
    var liste = noeud("div", "cmp-liste");
    var choisies = fichesChoisies(source);           // null : page de jeu (sans fiche choisie)
    ["kinguin", "loaded"].forEach(function (site) {
      var miennes = (choisies || []).filter(function (r) { return r.site === site; });
      if (sure(site, p && p[site], reference)) {
        var libelle = p[site].choisi ? ((miennes[0] && miennes[0].quoi) || source.getAttribute("data-" + site + "-quoi") || "clé PC")
          : "clé Steam vérifiée";
        ligne(liste, PARTENAIRE[site](p[site].url), NOMS[site] + " · " + libelle, euros(p[site].prix));
        ligneCode(liste, site);
        return;
      }
      var avant = liste.childNodes.length;
      miennes.forEach(function (r) { ligne(liste, PARTENAIRE[site](r.url), NOMS[site] + " · " + r.quoi, "voir le prix"); });
      var fiche = choisies ? "" : source.getAttribute("data-" + site) || "";
      if (String(fiche).indexOf(HOTES[site]) === 0) {
        ligne(liste, PARTENAIRE[site](fiche), NOMS[site] + " · " + (source.getAttribute("data-" + site + "-quoi") || "clé PC"), "voir le prix");
      }
      if (liste.childNodes.length > avant) { ligneCode(liste, site); }
    });
    // Instant Gaming : les fiches choisies a la main ; sur une page de jeu sans
    // fiche, la recherche filtree (data-ig="non" : aucun lien)
    var ig = (choisies || []).filter(function (r) { return r.site === "instant-gaming"; });
    ig.forEach(function (r) {
      ligne(liste, PARTENAIRE["instant-gaming"](r.url), "Instant Gaming · " + r.quoi, "voir le prix");
    });
    var fiche = source.getAttribute("data-ig") || "";
    if (!choisies && fiche !== "non") {
      var adresse = PARTENAIRE["instant-gaming"](/^https:\/\/www\.instant-gaming\.com\//.test(fiche)
        ? fiche : IG + encodeURIComponent(titre).replace(/%20/g, "+") + IG_FILTRES);
      var quoiIg = /^https:\/\/www\.instant-gaming\.com\//.test(fiche) ? source.getAttribute("data-ig-quoi") : "";
      ligne(liste, adresse, "Instant Gaming" + (quoiIg ? " · " + quoiIg : ""), "voir le prix");
    }
    if (ig.length || (!choisies && fiche !== "non")) { ligneCode(liste, "instant-gaming"); }
    if (!liste.childNodes.length) { return; }
    bloc.appendChild(noeud("h3", "", "Revendeurs de clés"));
    bloc.appendChild(liste);
    bloc.appendChild(noeud("small", "", "Revendeurs, pas des boutiques officielles : la clé du jeu lui-même " +
      "(Steam, Microsoft Store…), région Global ou Europe, jamais d'offre « Gift » ni « Account ». Liens " +
      "partenaires : ils financent ORION sans changer votre prix."));
  }

  // jeu sans prix IsThereAnyDeal (console, ou pas encore en vente) : le lien
  // officiel d'abord, toujours avant les revendeurs
  function officielsFixes(bloc, source, appid) {
    var liens = [];
    try { liens = JSON.parse(source.getAttribute("data-officiels") || "[]") || []; } catch (e) { liens = []; }
    if (!liens.length && appid) { liens = [{ nom: "Steam", url: "https://store.steampowered.com/app/" + appid + "/" }]; }
    liens = liens.filter(function (o) { return o && /^https:\/\//.test(o.url || ""); });
    if (!liens.length) { return; }
    bloc.appendChild(noeud("h3", "", "Boutique officielle"));
    var liste = noeud("div", "cmp-liste");
    liens.forEach(function (o) {
      var l = noeud("div", "cmp-ligne"), g = noeud("span");
      g.appendChild(lien(o.url, o.nom));
      l.appendChild(g);
      l.appendChild(noeud("span", "", "voir le prix"));
      liste.appendChild(l);
    });
    bloc.appendChild(liste);
  }

  function charger(bloc) {
    if (bloc.getAttribute("data-charge")) { return; }
    bloc.setAttribute("data-charge", "1");
    var appid = bloc.getAttribute("data-appid") || "", titre = bloc.getAttribute("data-titre") || "";
    if (appid && !/^\d{1,10}$/.test(appid)) { return; }
    style();
    var cadre = noeud("div", "cmp");
    bloc.appendChild(cadre);
    var lu = function (r) { if (!r.ok) { throw new Error("prix"); } return r.json(); };
    var prixOfficiels = !appid || !window.fetch ? Promise.resolve([]) :
      fetch(API + "/itad/games/lookup/v1?appid=" + appid).then(lu).then(function (l) {
        if (!l || !l.found || !l.game || !l.game.id) { return []; }
        return fetch(API + "/itad/games/prices/v3?capacity=30&country=FR&nondeals=true", {
          method: "POST", headers: { "content-type": "text/plain" }, body: JSON.stringify([l.game.id])
        }).then(lu).then(function (d) { return (d && d[0] && d[0].deals) || []; });
      }).catch(function () { return []; });
    var prixRevendeurs = !appid || !window.fetch ? Promise.resolve(null) :
      fetch(API + "/prix?pays=FR" + (bloc.getAttribute("data-une") === "1" ? "&une=1" : "") + "&appid=" + appid +
            "&titre=" + encodeURIComponent(titre)).then(lu).catch(function () { return null; });
    Promise.all([prixOfficiels, prixRevendeurs]).then(function (r) {
      var reference = officiels(cadre, r[0]);
      if (!reference) { officielsFixes(cadre, bloc, appid); }
      revendeurs(cadre, r[1], reference, titre, bloc);
      if (reference) {
        var credit = noeud("small", "");
        credit.appendChild(document.createTextNode("Prix des boutiques officielles et des vendeurs agréés : données "));
        credit.appendChild(lien("https://isthereanydeal.com/", "IsThereAnyDeal"));
        credit.appendChild(document.createTextNode(", relevées à l'instant. Le prix affiché par la boutique fait foi."));
        cadre.appendChild(credit);
      }
    });
  }

  style();
  Array.prototype.forEach.call(document.querySelectorAll("[data-comparatif]"), function (bloc) {
    if (bloc.getAttribute("data-auto") === "1") { charger(bloc); return; }
    var b = noeud("button", "cmp-bouton", "Prix et boutiques");
    b.type = "button";
    b.addEventListener("click", function () { b.remove(); charger(bloc); });
    bloc.appendChild(b);
  });
})();
