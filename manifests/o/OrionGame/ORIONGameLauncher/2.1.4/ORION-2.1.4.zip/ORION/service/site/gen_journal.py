"""Journal public des versions (2.0.2) : /versions et /versions/<x.y.z>, depuis
CHANGELOG.md, dans la ligne editoriale (titre-promesse, « L'essentiel » en
gras, « Dans le detail » par rubrique). Les versions sans date (« en
preparation ») ne sont pas publiees.

Usage : python gen_journal.py <dossier du site> <CHANGELOG.md>
"""
from __future__ import annotations

import datetime as dt
import re
import sys
from html import escape as e
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gen_jeux import SITE, gabarit  # noqa: E402

MOIS = {m: i for i, m in enumerate(("janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août",
                                    "septembre", "octobre", "novembre", "décembre"), 1)}


def lire(changelog: str) -> list[dict]:
    """[{version, titre, date (texte), iso, nature, lignes}] ; une version
    n'est retenue que si sa ligne de date se lit (jour mois annee)."""
    out = []
    blocs = re.split(r"^## ", changelog, flags=re.M)[1:]
    for b in blocs:
        tete, _, corps = b.partition("\n")
        m = re.match(r"(\d+\.\d+(?:\.\d+)?)\s*[—-]\s*(.+)", tete.strip())
        if not m:
            continue
        version, titre = m.group(1), m.group(2).strip()
        lignes = corps.strip("\n").split("\n")
        date, nature, iso = "", "", ""
        if lignes:
            md = re.match(r"(\d{1,2})(?:er)?\s+([a-zéû]+)\s+(\d{4})(?:\s*·\s*(.+))?", lignes[0].strip())
            if md and md.group(2) in MOIS:
                date = f"{md.group(1)} {md.group(2)} {md.group(3)}"
                iso = f"{md.group(3)}-{MOIS[md.group(2)]:02d}-{int(md.group(1)):02d}"
                nature = (md.group(4) or "").strip()
                lignes = lignes[1:]
        if not iso:
            continue                      # en preparation, ou ancienne forme sans date
        out.append({"version": version, "titre": titre, "date": date, "iso": iso, "nature": nature,
                    "lignes": lignes})
    return out


def _gras(t: str) -> str:
    t = e(t)
    t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
    t = re.sub(r"`([^`]+)`", r"<code>\1</code>", t)
    return t


def html_corps(lignes: list[str]) -> str:
    """Le markdown restreint du CHANGELOG -> HTML : sections en gras seules
    (« **L'essentiel** ») -> h2, lignes seules courtes -> h3 (rubrique),
    « - » -> puces, le reste -> paragraphes."""
    out, puces = [], []

    def vider():
        nonlocal puces
        if puces:
            out.append("<ul>" + "".join(f"<li>{_gras(p)}</li>" for p in puces) + "</ul>")
            puces = []
    for l in lignes:
        s = l.strip()
        if not s:
            vider()
            continue
        if s.startswith("- "):
            puces.append(s[2:].strip())
            continue
        vider()
        m = re.fullmatch(r"\*\*(.+?)\*\*", s)
        if m:
            out.append(f"<h2>{e(m.group(1))}</h2>")
        elif len(s) < 40 and not s.endswith((".", ":")):
            out.append(f"<h3>{e(s)}</h3>")
        else:
            out.append(f"<p>{_gras(s)}</p>")
    vider()
    return "\n".join(out)


def page_version(v: dict, versions: list[dict], style: str) -> str:
    chemin = f"/versions/{v['version']}"
    i = versions.index(v)
    prec = versions[i + 1] if i + 1 < len(versions) else None
    suiv = versions[i - 1] if i > 0 else None
    nav = " · ".join(x for x in (
        f'<a href="/versions/{e(suiv["version"])}">{e(suiv["version"])} →</a>' if suiv else "",
        f'<a href="/versions/{e(prec["version"])}">← {e(prec["version"])}</a>' if prec else "") if x)
    corps = f"""
<section class="journal">
  <p class="fil"><a href="/versions">Journal des versions</a></p>
  <h1>ORION {e(v['version'])} — {e(v['titre'])}</h1>
  <p class="chapo">{e(v['date'])}{' · ' + e(v['nature']) if v['nature'] else ''}</p>
  {html_corps(v['lignes'])}
  <p><a class="btn" href="/#installer">Télécharger ORION {e(v['version'])}</a></p>
  <p class="fil">{nav}</p>
</section>
"""
    ld = [{"@context": "https://schema.org", "@type": "SoftwareApplication", "name": "ORION Game Launcher",
           "softwareVersion": v["version"], "datePublished": v["iso"], "operatingSystem": "Windows 10, Windows 11",
           "applicationCategory": "UtilitiesApplication", "offers": {"@type": "Offer", "price": "0", "priceCurrency": "EUR"},
           "releaseNotes": f"{SITE}{chemin}"}]
    # onglet tenu en 60 caracteres (11 octobre : 1.7, 1.9.0, 2.0.2 a 75-76)
    onglet = next((t for t in (f"ORION {v['version']} — {v['titre']}", f"ORION {v['version']} : {v['titre']}")
                   if len(t) <= 60), f"ORION {v['version']} : nouveautés de la version")
    return gabarit(style, onglet,
                   f"Nouveautés d'ORION {v['version']} ({v['date']}) : {v['titre']}.", chemin, ld, corps)


def page_index(versions: list[dict], style: str) -> str:
    lignes = "\n".join(
        f'<li><a href="/versions/{e(v["version"])}"><b>{e(v["version"])}</b> — {e(v["titre"])}</a>'
        f'<span>{e(v["date"])}{" · " + e(v["nature"]) if v["nature"] else ""}</span></li>' for v in versions)
    corps = f"""
<section class="journal">
  <h1>Journal des versions</h1>
  <p class="chapo">Ce qui change à chaque version, écrit pour le joueur : la promesse d'abord, l'essentiel en
  quelques points, le détail par rubrique. Les mêmes notes accompagnent chaque version sur GitHub et sur le
  Microsoft Store.</p>
  <ul class="versions">{lignes}</ul>
</section>
"""
    ld = [{"@context": "https://schema.org", "@type": "CollectionPage", "name": "Journal des versions d'ORION",
           "inLanguage": "fr"}]
    return gabarit(style, "Journal des versions — ORION Game Launcher",
                   "Toutes les versions d'ORION et ce qu'elles changent, dans l'ordre, écrites pour le joueur.",
                   "/versions", ld, corps)


CSS = """
  .journal h2{margin-top:30px;}
  .journal h3{font-size:17px;letter-spacing:.04em;text-transform:uppercase;color:var(--dim);margin:22px 0 6px;}
  .journal ul{padding-left:22px;} .journal li{margin:10px 0;}
  .versions{list-style:none;padding:0;} .versions li{padding:12px 0;border-bottom:1px solid var(--line);}
  .versions li a{text-decoration:none;color:var(--ink);} .versions li span{display:block;color:var(--dim);font-size:14px;}
"""


def main(dossier, changelog) -> int:
    dossier = Path(dossier)
    accueil = (dossier / "index.html").read_text(encoding="utf-8")
    style = re.search(r"<style>(.*?)</style>", accueil, re.S).group(1) + CSS
    versions = lire(Path(changelog).read_text(encoding="utf-8"))
    cible = dossier / "versions"
    cible.mkdir(exist_ok=True)
    for ancien in cible.glob("*.html"):
        ancien.unlink()
    for v in versions:
        (cible / f"{v['version']}.html").write_text(page_version(v, versions, style), encoding="utf-8")
    (dossier / "versions.html").write_text(page_index(versions, style), encoding="utf-8")
    plan = dossier / "sitemap.xml"
    x = plan.read_text(encoding="utf-8")
    x = re.sub(r"  <url>\n    <loc>" + re.escape(SITE) + r"/versions[^<]*</loc>.*?</url>\n", "", x, flags=re.S)
    auj = dt.date.today().isoformat()
    bloc = "".join(f"  <url>\n    <loc>{SITE}{c}</loc>\n    <lastmod>{d}</lastmod>\n"
                   f"    <changefreq>monthly</changefreq>\n    <priority>{p}</priority>\n  </url>\n"
                   for c, d, p in [("/versions", auj, "0.7")] + [(f"/versions/{v['version']}", v["iso"], "0.5") for v in versions])
    x = x.replace("  <url>\n    <loc>" + SITE + "/mentions-legales",
                  bloc + "  <url>\n    <loc>" + SITE + "/mentions-legales")
    plan.write_text(x, encoding="utf-8")
    print(f"{len(versions)} pages de version, index /versions")
    return len(versions)


if __name__ == "__main__":
    main(*sys.argv[1:3])
