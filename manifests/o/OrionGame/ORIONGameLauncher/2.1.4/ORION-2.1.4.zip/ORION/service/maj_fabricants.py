"""Rafraichit `orion/hardware/fabricants_ids.json` depuis les bases publiques
d'identifiants PCI et USB (projet pci.ids / usb.ids, licence BSD 3 clauses).

    python3 service/maj_fabricants.py

Seuls les fabricants sont gardes (identifiant de quatre chiffres hexa ->
nom court) : c'est ce qui permet a ORION de dire qui a fabrique une carte
(sous-systeme PCI) ou une puce, pour n'importe quel composant, sans liste
entretenue a la main. Les noms sont raccourcis (« ASUSTeK Computer Inc. »
-> « ASUSTeK Computer », et les grands noms vers leur nom d'usage).
"""
from __future__ import annotations

import json
import re
import sys
import urllib.request
from pathlib import Path

SOURCES = {
    "pci": "https://raw.githubusercontent.com/pciutils/pciids/master/pci.ids",
    "usb": "https://raw.githubusercontent.com/usbids/usbids/master/usb.ids",
}
CIBLE = Path(__file__).resolve().parent.parent / "orion" / "hardware" / "fabricants_ids.json"

#: nom d'usage des fabricants qu'on voit chez les joueurs (le nom legal de
#: la base est trop long pour un conseil)
NOMS_D_USAGE = {
    "pci": {
        "1002": "AMD", "1022": "AMD", "10de": "NVIDIA", "8086": "Intel", "10ec": "Realtek",
        "1043": "ASUS", "1462": "MSI", "1458": "Gigabyte", "1849": "ASRock", "3842": "EVGA",
        "103c": "HP", "1028": "Dell", "17aa": "Lenovo", "1025": "Acer", "144d": "Samsung",
        "7470": "TP-Link", "1102": "Creative", "11ab": "Marvell", "1b4b": "Marvell",
        "1d6a": "Marvell (Aquantia)", "14e4": "Broadcom", "168c": "Qualcomm", "17cb": "Qualcomm",
        "14c3": "MediaTek", "1a56": "Killer (Intel)", "15b7": "Western Digital", "1987": "Phison",
        "1c5c": "SK hynix", "1e0f": "Kioxia", "c0a9": "Micron (Crucial)", "196e": "PNY",
        "19da": "Zotac", "1da2": "Sapphire", "1682": "XFX", "148c": "PowerColor",
        "10b0": "Gainward", "1569": "Palit", "1b1c": "Corsair", "1d05": "Tongfang",
        "1179": "Toshiba", "104d": "Sony", "152d": "Quanta", "1297": "Shuttle", "1734": "Fujitsu",
        "1025": "Acer", "1b0a": "Pegatron", "19e5": "Huawei", "1e49": "Xiaomi", "1d87": "Rockchip",
    },
    "usb": {
        "8087": "Intel", "0955": "NVIDIA", "0bda": "Realtek", "0b05": "ASUS", "1462": "MSI",
        "0414": "Gigabyte", "2357": "TP-Link", "046d": "Logitech", "1532": "Razer",
        "1038": "SteelSeries", "1b1c": "Corsair", "0781": "SanDisk", "0cf3": "Qualcomm",
        "0a12": "Cambridge Silicon Radio", "13d3": "IMC Networks (Azurewave)", "0489": "Foxconn",
        "04ca": "Lite-On", "8086": "Intel", "045e": "Microsoft", "054c": "Sony", "057e": "Nintendo",
        "0e8d": "MediaTek", "2109": "VIA Labs", "05ac": "Apple", "041e": "Creative", "1058": "Western Digital",
        "04e8": "Samsung", "03f0": "HP", "413c": "Dell", "17ef": "Lenovo", "3434": "Keychron",
    },
}

_SUFFIXES = re.compile(
    r"\s*(,|\.)?\s*\b(inc|incorporated|corp|corporation|co|company|ltd|limited|llc|gmbh|ag|sa|"
    r"s\.a|bv|b\.v|plc|kg|technologies|technology|electronics|international|group|holdings?|"
    r"industries|industrial|systems|semiconductors?|microelectronics|usa|america|europe|asia)"
    r"\b\.?\s*$", re.I)


def court(nom: str) -> str:
    """Un nom court lisible : suffixes legaux et crochets retires."""
    n = re.sub(r"\s*\[.*?\]\s*", " ", nom).strip()
    n = re.sub(r"\s*\(.*?\)\s*$", "", n).strip()
    for _ in range(4):
        m = _SUFFIXES.sub("", n).strip(" ,.")
        if m == n or not m:
            break
        n = m
    return n or nom.strip()


def lire(texte: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for ligne in texte.splitlines():
        m = re.match(r"^([0-9a-f]{4})\s+(.+?)\s*$", ligne)
        if m:
            out[m.group(1)] = m.group(2)
    return out


def main() -> int:
    resultat = {"source": "pci.ids / usb.ids (https://pci-ids.ucw.cz, http://www.linux-usb.org/usb.ids), "
                          "licence BSD 3 clauses", "versions": {}, "pci": {}, "usb": {}}
    for bus, url in SOURCES.items():
        with urllib.request.urlopen(url, timeout=60) as r:
            texte = r.read().decode("utf-8", errors="replace")
        m = re.search(r"Version:\s*(\S+)", texte)
        resultat["versions"][bus] = m.group(1) if m else ""
        bruts = lire(texte)
        resultat[bus] = {k.upper(): NOMS_D_USAGE[bus].get(k, court(v)) for k, v in sorted(bruts.items())}
        print(f"{bus} : {len(bruts)} fabricants, version {resultat['versions'][bus]}")
    CIBLE.write_text(json.dumps(resultat, ensure_ascii=False, separators=(",", ":")) + "\n", encoding="utf-8")
    print("ecrit :", CIBLE, CIBLE.stat().st_size, "octets")
    return 0


if __name__ == "__main__":
    sys.exit(main())
