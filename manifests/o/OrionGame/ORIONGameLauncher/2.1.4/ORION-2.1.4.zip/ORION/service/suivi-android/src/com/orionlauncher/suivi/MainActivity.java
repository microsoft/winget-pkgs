package com.orionlauncher.suivi;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * ORION Suivi : une fenetre sur le tableau de suivi du service d'ORION.
 *
 * Toute la logique d'affichage est dans la page servie par le service : cette
 * application ne contient ni cle ni chiffre. La cle saisie par l'auteur reste
 * dans le stockage prive de l'application (jamais sauvegardee ailleurs :
 * allowBackup est coupe). Seul l'hote du service s'ouvre ici ; tout autre lien
 * part dans le navigateur du telephone.
 *
 * Depuis la 1.1, la page confie la cle a l'application (objet « Suivi ») pour
 * que la veille ({@link Veille}) relise le tableau en arriere-plan et previenne.
 */
public class MainActivity extends Activity {
    static final String HOTE = "api.orion-launcher.com";
    static final String ADRESSE = "https://" + HOTE + "/tableau";
    static final String CANAL_ALERTES = "alertes";
    static final String CANAL_RESUME = "resume";
    private static final int DEMANDE_NOTIFICATIONS = 1;
    private WebView vue;

    @Override
    protected void onCreate(Bundle etat) {
        super.onCreate(etat);
        canaux();
        vue = new WebView(this);
        vue.setBackgroundColor(0xFF0A0E1A);
        WebSettings reglages = vue.getSettings();
        reglages.setJavaScriptEnabled(true);
        reglages.setDomStorageEnabled(true);
        reglages.setAllowFileAccess(false);
        reglages.setAllowContentAccess(false);
        reglages.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        reglages.setSupportMultipleWindows(false);
        reglages.setGeolocationEnabled(false);
        vue.setWebViewClient(new Client());
        // seule la page du service tourne dans cette vue : elle seule voit cet objet
        vue.addJavascriptInterface(new Pont(), "Suivi");
        setContentView(vue);
        vue.loadUrl(ADRESSE);
        if (!Memoire.cle(this).isEmpty()) {
            Veille.programmer(this);
        }
        demanderNotifications();
    }

    @Override
    protected void onResume() {
        super.onResume();
        vue.onResume();
    }

    @Override
    protected void onPause() {
        vue.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        vue.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (vue.canGoBack()) {
            vue.goBack();
        } else {
            super.onBackPressed();
        }
    }

    /** Les deux canaux de notification : alertes (sonores) et resume du matin (discret). */
    private void canaux() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            return;
        }
        NotificationManager gestion = getSystemService(NotificationManager.class);
        if (gestion == null) {
            return;
        }
        NotificationChannel alertes = new NotificationChannel(CANAL_ALERTES, getString(R.string.canal_alertes),
                NotificationManager.IMPORTANCE_HIGH);
        alertes.setDescription(getString(R.string.canal_alertes_detail));
        gestion.createNotificationChannel(alertes);
        NotificationChannel resume = new NotificationChannel(CANAL_RESUME, getString(R.string.canal_resume),
                NotificationManager.IMPORTANCE_DEFAULT);
        resume.setDescription(getString(R.string.canal_resume_detail));
        gestion.createNotificationChannel(resume);
    }

    /** Android 13 et plus demandent l'accord avant la premiere notification. */
    private void demanderNotifications() {
        if (Build.VERSION.SDK_INT < 33) {
            return;
        }
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[] { Manifest.permission.POST_NOTIFICATIONS }, DEMANDE_NOTIFICATIONS);
        }
    }

    /** Page d'attente quand le service ne repond pas : rien ne vient d'ailleurs. */
    private void attente(String message) {
        String page = "<!doctype html><html lang='fr'><head><meta charset='utf-8'>"
                + "<meta name='viewport' content='width=device-width,initial-scale=1'>"
                + "<style>body{background:#0a0e1a;color:#e8edf7;font:16px/1.5 sans-serif;padding:32px 22px}"
                + "h1{font-size:18px;letter-spacing:.06em}p{color:#93a1bd}"
                + "a{display:block;margin-top:24px;padding:14px;border-radius:10px;background:#6ea8ff;"
                + "color:#06101f;text-align:center;text-decoration:none;font-weight:bold}</style></head>"
                + "<body><h1>ORION · SUIVI</h1><p>" + message + "</p>"
                + "<a href='" + ADRESSE + "'>R&eacute;essayer</a></body></html>";
        vue.loadDataWithBaseURL(null, page, "text/html", "utf-8", null);
    }

    /**
     * Ce que la page peut dire a l'application : la cle (pour la veille) et
     * son oubli. Rien ne va dans l'autre sens.
     */
    private final class Pont {
        @JavascriptInterface
        public void cle(String cle) {
            if (cle == null) {
                return;
            }
            String propre = cle.trim();
            if (propre.length() < 24 || propre.length() > 200) {
                return;
            }
            if (!propre.equals(Memoire.cle(MainActivity.this))) {
                Memoire.garderCle(MainActivity.this, propre);
            }
            Veille.programmer(MainActivity.this);
        }

        @JavascriptInterface
        public void oublier() {
            Memoire.oublier(MainActivity.this);
            Veille.arreter(MainActivity.this);
        }
    }

    private final class Client extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest requete) {
            Uri adresse = requete.getUrl();
            if ("https".equals(adresse.getScheme()) && HOTE.equals(adresse.getHost())) {
                return false;
            }
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, adresse));
            } catch (RuntimeException e) {
                // aucune application pour ce lien : on reste ou l'on est
            }
            return true;
        }

        @Override
        public void onReceivedError(WebView v, WebResourceRequest requete, WebResourceError erreur) {
            if (requete.isForMainFrame()) {
                attente("Le service d'ORION est injoignable. V&eacute;rifiez la connexion du t&eacute;l&eacute;phone.");
            }
        }

        @Override
        public void onReceivedHttpError(WebView v, WebResourceRequest requete, WebResourceResponse reponse) {
            if (requete.isForMainFrame()) {
                attente("Le tableau de suivi n'est pas encore en service (r&eacute;ponse "
                        + reponse.getStatusCode() + "). Il s'ouvrira ici d&egrave;s que le service sera mis &agrave; jour.");
            }
        }
    }
}
