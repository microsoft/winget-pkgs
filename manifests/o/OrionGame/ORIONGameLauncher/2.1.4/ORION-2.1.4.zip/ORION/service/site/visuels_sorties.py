"""Copie les visuels officiels des sorties dans le site (img/sorties/<id>.jpg).

Les visuels viennent du cache d'ORION (%LOCALAPPDATA%\\ORION\\cache\\sorties),
que l'application remplit deja depuis Steam et les sites des editeurs : le
site les sert lui-meme, la page n'appelle jamais un tiers.

Usage : python visuels_sorties.py <cache sorties> <dossier du site>
"""
import json
import re
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gen_sorties import EN_TETE  # noqa: E402


def nom_cache(s: dict) -> str:
    """Meme nom que `orion.sorties._nom` : l'identifiant Steam, sinon l'id."""
    return str(s.get("steam") or "") or re.sub(r"[^A-Za-z0-9_-]", "_", s["id"])[:80] or "sortie"


def main(cache: str, site: str) -> int:
    cache_d, site_d = Path(cache), Path(site)
    donnees = json.loads((site_d / "sorties.json").read_text(encoding="utf-8"))
    dest = site_d / "img" / "sorties"
    dest.mkdir(parents=True, exist_ok=True)
    n = 0
    for s in donnees["sorties"]:
        base = nom_cache(s)
        # grand visuel pour les jeux en tete et la vedette, vignette ailleurs
        # (une page legere)
        grand = s["id"] in EN_TETE or s.get("une") or s.get("vedette")
        for genre in (("fond", "carte") if grand else ("carte", "fond")):
            f = cache_d / f"{base}-{genre}.jpg"
            if f.exists() and f.stat().st_size > 1000:
                shutil.copyfile(f, dest / f"{s['id']}.jpg")
                n += 1
                break
    print(f"{n} visuel(s) copie(s) dans {dest}")
    return n


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
