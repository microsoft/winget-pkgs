import json, sys, time, threading, http.server, functools, os
from playwright.sync_api import sync_playwright
"""Essai des pages de jeux dans un vrai navigateur (Chromium, Playwright).

Usage : python essai_pages.py <dossier du site genere> <gamesplanet-fr.json>

Le releve de prix est simule : frais, sans remise, en panne, arrete, jeu
retire. La page doit toujours afficher un prix vrai avec sa date, ou rien."""
SITE, RELEVE = sys.argv[1], sys.argv[2]
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "gamesplanet"))
import releve_gamesplanet as R
doc = json.load(open(RELEVE, encoding="utf-8"))

class H(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
    def send_head(self):
        # comme Cloudflare Pages : /jeux/x sert jeux/x.html
        p = self.translate_path(self.path)
        if (not os.path.exists(p) or os.path.isdir(p)) and os.path.exists(p.rstrip("/") + ".html"):
            self.path += ".html"
        return super().send_head()
srv = http.server.ThreadingHTTPServer(("127.0.0.1", 8765), functools.partial(H, directory=SITE))
threading.Thread(target=srv.serve_forever, daemon=True).start()

def essai(page, mode, releve=None, slug_page=None):
    d = json.loads(json.dumps(doc))
    d["releve"] = int(time.time()) - 300 if releve is None else releve
    if mode == "hausse":
        for p in d["jeux"]["1245620"]:
            if p[3].endswith("--4266-1"): p[1], p[2] = 41.99, 59.99
    if mode == "plein":
        for p in d["jeux"]["1245620"]:
            if p[3].endswith("--4266-1"): p[1], p[2] = 59.99, 59.99
    if mode == "retire":
        d["jeux"].pop("1245620")
    frag = R.fragments(d)
    def route(r):
        if mode == "panne":
            return r.abort()
        cle = r.request.url.rsplit("/", 1)[1][:2]
        r.fulfill(status=200, content_type="application/json", body=json.dumps(frag[cle]),
                  headers={"access-control-allow-origin": "*"})
    page.unroute("**/raw.githubusercontent.com/**")
    page.route("**/raw.githubusercontent.com/**", route)
    page.route("**/fonts.googleapis.com/**", lambda r: r.abort())
    page.route("**/fonts.gstatic.com/**", lambda r: r.abort())
    page.goto("http://127.0.0.1:8765/jeux/elden-ring")
    if slug_page is not None:        # page generee il y a longtemps
        page.evaluate("v => document.getElementById('prix-gp').setAttribute('data-releve', v)", str(slug_page))
        page.evaluate("() => { var s=document.createElement('script'); s.src='/prix.js?x='+Date.now(); document.body.appendChild(s); }")
    page.wait_for_timeout(700)
    return page.evaluate("""() => ({final:[...document.querySelectorAll('.pg-final')].map(e=>e.textContent),
        normal:document.querySelector('.pg-normal').textContent, normalCache:document.querySelector('.pg-normal').hidden,
        remise:document.querySelector('.pg-remise').textContent, remiseCachee:document.querySelector('.pg-remise').hidden,
        date:document.querySelector('.pg-date').textContent, inconnu:document.documentElement.classList.contains('prix-inconnu'),
        chiffres:getComputedStyle(document.querySelector('.pg-chiffres')).display, secours:getComputedStyle(document.querySelector('.pg-secours')).display})""")

with sync_playwright() as pw:
    b = pw.chromium.launch()
    page = b.new_page(viewport={"width": 1180, "height": 900})
    erreurs = []
    page.on("pageerror", lambda e: erreurs.append(str(e)))
    for nom, kw in (("releve frais, prix change", dict(mode="hausse")), ("plus de remise", dict(mode="plein")),
                    ("releve en panne, page recente", dict(mode="panne")),
                    ("releve en panne, page de 3 jours", dict(mode="panne", slug_page=int(time.time()) - 3 * 86400)),
                    ("releve arrete depuis 10 h, page recente", dict(mode="hausse", releve=int(time.time()) - 10 * 3600)),
                    ("jeu retire du catalogue", dict(mode="retire"))):
        print(nom, "->", json.dumps(essai(page, **kw), ensure_ascii=False))
    essai(page, "hausse")
    page.locator("#prix-gp").scroll_into_view_if_needed()
    page.evaluate("window.scrollBy(0, -260)")
    page.wait_for_timeout(300)
    page.screenshot(path="page-prix.png")
    page.goto("http://127.0.0.1:8765/jeux")
    page.wait_for_timeout(300)
    print("index:", page.evaluate("() => ({filtreCache: document.getElementById('filtre').hidden, n: document.querySelectorAll('#liste-jeux a').length, compte: document.getElementById('filtre-compte').textContent})"))
    page.fill("#filtre-jeux", "elden")
    print("filtre elden:", page.evaluate("() => ({visibles:[...document.querySelectorAll('#liste-jeux a')].filter(a=>!a.hidden).map(a=>a.querySelector('b').textContent), compte: document.getElementById('filtre-compte').textContent})"))
    print("erreurs JS:", erreurs)
    b.close()
