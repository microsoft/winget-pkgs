package com.orionlauncher.suivi;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Un passage de la veille : lire le tableau (avec la cle de l'auteur) et les
 * chiffres publics de GitHub, comparer a ce qui a deja ete signale, prevenir.
 * Tout ce qui est lu vient du service d'ORION ou de GitHub ; rien n'en sort.
 */
final class Controle {
    private static final String SERVICE = "https://" + MainActivity.HOTE;
    private static final String DEPOT = "https://api.github.com/repos/Sikher-kisa/orion-game-launcher";
    private static final String AGENT = "ORION-Suivi/1.1 (+https://orion-launcher.com)";
    private static final int DELAI_MS = 15000;
    private static final long HEURE_MS = 3600000L;
    // numeros des notifications : une par sujet, la suivante remplace la precedente
    private static final int N_SIGNALEMENT = 10, N_SERVICE = 11, N_COHERENCE = 12, N_GITHUB = 13,
            N_RELAIS = 14, N_SILENCE = 15, N_RESUME = 20;

    private Controle() {
    }

    static void executer(Context ctx) {
        String cle = Memoire.cle(ctx);
        if (cle.isEmpty()) {
            return;
        }
        JSONObject d;
        try {
            d = new JSONObject(lire(SERVICE + "/tableau/donnees?jours=1", "Bearer " + cle));
        } catch (Exception e) {
            return;   // hors ligne, cle refusee ou service en panne : on reessaiera dans trente minutes
        }
        signalements(ctx, d);
        service(ctx, d);
        silence(ctx, d);
        github(ctx);
        resume(ctx, d);
    }

    // -- sujets -----------------------------------------------------------------
    private static void signalements(Context ctx, JSONObject d) {
        JSONObject s = d.optJSONObject("signalements");
        if (s == null) {
            return;
        }
        long total = s.optLong("total", 0), connu = Memoire.nombre(ctx, "signalements_total", -1);
        if (connu >= 0 && total > connu) {
            JSONArray liste = s.optJSONArray("liste");
            JSONObject dernier = liste != null && liste.length() > 0 ? liste.optJSONObject(0) : null;
            String titre = dernier == null ? "" : "n° " + dernier.optLong("id") + " · " + dernier.optString("titre");
            long nouveaux = total - connu;
            prevenir(ctx, MainActivity.CANAL_ALERTES, N_SIGNALEMENT,
                    nouveaux > 1 ? nouveaux + " nouveaux signalements" : "Nouveau signalement", titre);
        }
        Memoire.garder(ctx, "signalements_total", total);
    }

    private static void service(Context ctx, JSONObject d) {
        JSONObject s = d.optJSONObject("service");
        if (s == null) {
            return;
        }
        String jour = d.optString("aujourdhui", "");
        JSONObject a = s.optJSONObject("aujourdhui");
        long pannes = a == null ? 0 : a.optLong("pannes", 0);
        if (pannes > Memoire.nombre(ctx, "pannes_" + jour, 0)) {
            prevenir(ctx, MainActivity.CANAL_ALERTES, N_SERVICE, "Service d'ORION : " + pannes + (pannes > 1 ? " réponses en échec" : " réponse en échec"),
                    "Aujourd'hui. Le détail par route est dans la section Service du tableau.");
            Memoire.garder(ctx, "pannes_" + jour, pannes);
        }
        JSONObject c = s.optJSONObject("coherence");
        if (c != null && c.has("ok") && !c.optBoolean("ok", true)) {
            long quand = c.optLong("quand", 0);
            if (quand > Memoire.nombre(ctx, "coherence_quand", 0)) {
                JSONObject site = c.optJSONObject("site"), gh = c.optJSONObject("github");
                prevenir(ctx, MainActivity.CANAL_ALERTES, N_COHERENCE, "Le site et GitHub ne concordent pas",
                        "Site : " + (site == null ? "?" : site.optString("version", "?")) + " · GitHub : "
                                + (gh == null ? "?" : gh.optString("version", "?")) + ". Un visiteur peut vérifier son fichier contre une empreinte périmée.");
                Memoire.garder(ctx, "coherence_quand", quand);
            }
        }
    }

    /** Plus rien ne rentre alors que des PC etaient la hier : le service est peut-etre muet. */
    private static void silence(Context ctx, JSONObject d) {
        JSONObject pc = d.optJSONObject("pc");
        JSONArray fil = d.optJSONArray("fil");
        if (pc == null || fil == null || fil.length() == 0 || pc.optLong("hier", 0) < 3) {
            return;
        }
        long dernier = fil.optJSONObject(0) == null ? 0 : fil.optJSONObject(0).optLong("quand", 0) * 1000L;
        long maintenant = System.currentTimeMillis();
        if (dernier > 0 && maintenant - dernier > 6 * HEURE_MS && maintenant - Memoire.nombre(ctx, "silence_alerte", 0) > 12 * HEURE_MS) {
            prevenir(ctx, MainActivity.CANAL_ALERTES, N_SILENCE, "Aucun envoi reçu depuis " + ((maintenant - dernier) / HEURE_MS) + " h",
                    pc.optLong("hier", 0) + " PC étaient là hier. Le service ou le compteur a peut-être un problème.");
            Memoire.garder(ctx, "silence_alerte", maintenant);
        }
    }

    /** Chiffres publics de GitHub : une tache planifiee en echec, le relais des prix en retard. */
    private static void github(Context ctx) {
        try {
            JSONObject runs = new JSONObject(lire(DEPOT + "/actions/runs?per_page=12", null));
            JSONArray liste = runs.optJSONArray("workflow_runs");
            String echec = "", id = "";
            java.util.HashSet<String> vus = new java.util.HashSet<String>();
            for (int i = 0; liste != null && i < liste.length(); i++) {
                JSONObject x = liste.optJSONObject(i);
                if (x == null || !vus.add(x.optString("name"))) {
                    continue;   // seule la derniere execution de chaque tache compte
                }
                String conclusion = x.optString("conclusion", "");
                if ("completed".equals(x.optString("status")) && !conclusion.isEmpty() && !"success".equals(conclusion)
                        && !"skipped".equals(conclusion) && !"cancelled".equals(conclusion)) {
                    echec = echec.isEmpty() ? x.optString("name") : echec + ", " + x.optString("name");
                    id = id + x.optLong("id") + ";";
                }
            }
            if (!echec.isEmpty() && !id.equals(Memoire.texte(ctx, "github_echec"))) {
                prevenir(ctx, MainActivity.CANAL_ALERTES, N_GITHUB, "Tâche GitHub en échec", echec);
            }
            Memoire.garder(ctx, "github_echec", id);
        } catch (Exception e) {
            // GitHub injoignable ou limite atteinte : rien a dire
        }
        try {
            JSONObject b = new JSONObject(lire(DEPOT + "/branches/donnees", null));
            String date = b.getJSONObject("commit").getJSONObject("commit").getJSONObject("committer").optString("date", "");
            long depose = lireDate(date), maintenant = System.currentTimeMillis();
            if (depose > 0 && maintenant - depose > 90 * 60000L && maintenant - Memoire.nombre(ctx, "relais_alerte", 0) > 6 * HEURE_MS) {
                prevenir(ctx, MainActivity.CANAL_ALERTES, N_RELAIS, "Relais des prix Gamesplanet en retard",
                        "Dernier relevé il y a " + Math.round((maintenant - depose) / (double) HEURE_MS) + " h (attendu toutes les vingt minutes).");
                Memoire.garder(ctx, "relais_alerte", maintenant);
            }
        } catch (Exception e) {
            // idem
        }
    }

    /** Chaque matin a partir de 8 h : la veille en trois chiffres. */
    private static void resume(Context ctx, JSONObject d) {
        Calendar c = Calendar.getInstance();
        if (c.get(Calendar.HOUR_OF_DAY) < 8) {
            return;
        }
        String jour = d.optString("aujourdhui", "");
        if (jour.isEmpty() || jour.equals(Memoire.texte(ctx, "resume_jour"))) {
            return;
        }
        JSONObject pc = d.optJSONObject("pc");
        long hier = pc == null ? 0 : pc.optLong("hier", 0), aujourdhui = pc == null ? 0 : pc.optLong("aujourdhui", 0);
        long clics = 0, ouvertures = 0;
        JSONArray h = d.optJSONArray("hier");
        for (int i = 0; h != null && i < h.length(); i++) {
            JSONObject l = h.optJSONObject(i);
            if (l == null) {
                continue;
            }
            if ("clic".equals(l.optString("nom"))) {
                clics += l.optLong("n", 0);
            } else if ("ouverture".equals(l.optString("nom"))) {
                ouvertures += l.optLong("n", 0);
            }
        }
        // telechargements de la veille : difference entre les deux derniers totaux releves avant aujourd'hui
        long dl = -1;
        JSONObject t = d.optJSONObject("telechargements");
        JSONArray par = t == null ? null : t.optJSONArray("parJour");
        if (par != null) {
            long avant = -1, veille = -1;
            for (int i = 0; i < par.length(); i++) {
                JSONObject x = par.optJSONObject(i);
                if (x == null || x.optString("jour").compareTo(jour) >= 0) {
                    continue;
                }
                avant = veille;
                veille = x.optLong("n", -1);
            }
            if (avant >= 0 && veille >= 0) {
                dl = Math.max(0, veille - avant);
            }
        }
        StringBuilder texte = new StringBuilder();
        texte.append("Hier : ").append(hier).append(hier > 1 ? " PC actifs" : " PC actif");
        texte.append(" · ").append(ouvertures).append(" ouvertures · ").append(clics).append(" clics boutiques");
        if (dl >= 0) {
            texte.append(" · +").append(dl).append(" téléchargements");
        }
        texte.append(". Aujourd'hui déjà : ").append(aujourdhui).append(" PC.");
        prevenir(ctx, MainActivity.CANAL_RESUME, N_RESUME, "ORION, ce matin", texte.toString());
        Memoire.garder(ctx, "resume_jour", jour);
    }

    // -- outils -----------------------------------------------------------------
    private static String lire(String adresse, String autorisation) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(adresse).openConnection();
        c.setConnectTimeout(DELAI_MS);
        c.setReadTimeout(DELAI_MS);
        c.setRequestProperty("User-Agent", AGENT);
        c.setRequestProperty("Accept", "application/json");
        if (autorisation != null) {
            c.setRequestProperty("Authorization", autorisation);
        }
        try {
            if (c.getResponseCode() != 200) {
                throw new Exception("reponse " + c.getResponseCode());
            }
            InputStream in = c.getInputStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] tampon = new byte[8192];
            int n;
            long total = 0;
            while ((n = in.read(tampon)) > 0) {
                total += n;
                if (total > 4000000) {
                    throw new Exception("reponse trop longue");
                }
                out.write(tampon, 0, n);
            }
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        } finally {
            c.disconnect();
        }
    }

    private static long lireDate(String iso) {
        try {
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
            f.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date d = f.parse(iso);
            return d == null ? 0 : d.getTime();
        } catch (Exception e) {
            return 0;
        }
    }

    private static void prevenir(Context ctx, String canal, int numero, String titre, String texte) {
        if (Build.VERSION.SDK_INT >= 33
                && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return;   // l'auteur n'a pas encore dit oui aux notifications
        }
        NotificationManager gestion = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (gestion == null) {
            return;
        }
        Intent ouvrir = new Intent(ctx, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent au_clic = PendingIntent.getActivity(ctx, numero, ouvrir,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(ctx, canal) : new Notification.Builder(ctx);
        b.setSmallIcon(R.drawable.ic_notif)
                .setColor(0xFF6EA8FF)
                .setContentTitle(titre)
                .setContentText(texte)
                .setStyle(new Notification.BigTextStyle().bigText(texte))
                .setContentIntent(au_clic)
                .setAutoCancel(true)
                .setWhen(System.currentTimeMillis())
                .setShowWhen(true);
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            b.setPriority(MainActivity.CANAL_ALERTES.equals(canal) ? Notification.PRIORITY_HIGH : Notification.PRIORITY_DEFAULT);
        }
        gestion.notify(numero, b.build());
    }
}
