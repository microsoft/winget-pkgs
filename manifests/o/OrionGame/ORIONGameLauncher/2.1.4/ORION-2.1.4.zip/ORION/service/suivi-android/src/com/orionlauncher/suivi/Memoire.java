package com.orionlauncher.suivi;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Le stockage prive de l'application : la cle du tableau et ce que la veille
 * a deja signale (pour ne pas prevenir deux fois). Jamais sauvegarde ailleurs
 * (allowBackup est coupe dans le manifeste).
 */
final class Memoire {
    private static final String FICHIER = "suivi";
    static final String CLE = "cle";

    private Memoire() {
    }

    private static SharedPreferences ouvrir(Context ctx) {
        return ctx.getSharedPreferences(FICHIER, Context.MODE_PRIVATE);
    }

    static String cle(Context ctx) {
        return ouvrir(ctx).getString(CLE, "");
    }

    static void garderCle(Context ctx, String cle) {
        ouvrir(ctx).edit().putString(CLE, cle).apply();
    }

    /** La cle part, et avec elle tout ce que la veille retenait. */
    static void oublier(Context ctx) {
        ouvrir(ctx).edit().clear().apply();
    }

    static long nombre(Context ctx, String nom, long defaut) {
        return ouvrir(ctx).getLong(nom, defaut);
    }

    static void garder(Context ctx, String nom, long valeur) {
        ouvrir(ctx).edit().putLong(nom, valeur).apply();
    }

    static String texte(Context ctx, String nom) {
        return ouvrir(ctx).getString(nom, "");
    }

    static void garder(Context ctx, String nom, String valeur) {
        ouvrir(ctx).edit().putString(nom, valeur).apply();
    }
}
