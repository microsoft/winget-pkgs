"""Pages guides du site (13 octobre 2026, « des mots clés à mettre en avant
qui ne sont pas déjà présents ») :

* `/soldes-steam` : « soldes Steam », « prochaines soldes Steam ». Les dates
  viennent de `soldes_steam.py` (calendrier publie par Valve), jamais devinees.
* `/augmenter-fps` : « augmenter ses FPS », « gagner des FPS ». Des reglages
  qui marchent, et ce qui ne sert a rien ; aucun chiffre de gain invente.
* `/config-pc-gamer-2026` (17/10) : « config pc gamer 2026 », « monter son pc ». La
  page du tuto video : liste avec prix dates et sources, montage, FPS mesures
  par TechSpot. Prix a relever de nouveau avant chaque mise a jour (CONFIG_RELEVE).

Usage : python gen_guides.py <dossier du site>   (apres gen_evenements.py)
"""
from __future__ import annotations

import datetime as dt
import re
import sys
from html import escape
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import soldes_steam as ST                                                   # noqa: E402
from gen_evenements import CSS, ajouter_plan, black_friday, date_fr, faq_html, faq_ld  # noqa: E402
from gen_jeux import DESC_MAX, EXE, NB_CARTES, SITE, TITRE_MAX, ajuste, gabarit  # noqa: E402


def e(t) -> str:
    return escape(str(t or ""), quote=True)


CSS_GUIDES = """
.ev table.cal{width:100%;border-collapse:collapse;margin:14px 0}
.ev table.cal th,.ev table.cal td{text-align:left;padding:9px 8px;border-bottom:1px solid rgba(255,255,255,.08)}
.ev table.cal th{color:var(--dim,#AAB4C8);font-weight:600}
.ev table.cal tr.fini td{color:var(--dim,#AAB4C8)}
.ev table.cal tr.vise td{font-weight:600}
.ev ol.etapes{padding-left:1.2em}
.ev ol.etapes li{margin:0 0 18px}
.ev ol.etapes b{display:block;font-size:18px;margin-bottom:4px}
.ev .appel{display:flex;gap:10px;flex-wrap:wrap;margin:18px 0}
.ev .defile{overflow-x:auto;-webkit-overflow-scrolling:touch;max-width:100%}
.ev .defile table.cal{min-width:520px}
.ev .prix{white-space:nowrap}
.ev ul.liens{display:flex;flex-wrap:wrap;gap:8px;list-style:none;padding:0;margin:12px 0 18px}
.ev ul.liens a{display:inline-block;padding:8px 14px;border-radius:999px;border:1px solid rgba(255,255,255,.14);text-decoration:none}
.ev form.cherche.grand{margin:16px 0 8px;max-width:520px}
"""

#: compte a rebours des soldes : avant, pendant, apres (la page peut rester
#: en ligne apres la fin des soldes : elle ne doit pas mentir)
SOLDES_JS = """<script>
(function () {
  "use strict";
  var d = document.getElementById("decompte-soldes");
  if (!d) { return; }
  var debut = Date.parse(d.getAttribute("data-debut")), fin = Date.parse(d.getAttribute("data-fin"));
  function bloc(v, t) { return "<div><b>" + v + "</b><span>" + t + "</span></div>"; }
  function tic() {
    var now = Date.now(), cible = now < debut ? debut : fin;
    if (now >= fin) { d.hidden = true; return; }
    var s = Math.floor((cible - now) / 1000);
    var j = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60);
    d.innerHTML = (now < debut ? "" : bloc("En cours", "FIN DANS")) + bloc(j, "JOURS") + bloc(h, "HEURES")
      + bloc(m, "MINUTES");
    setTimeout(tic, 30000);
  }
  tic();
}());
</script>"""


def fil(nom: str, chemin: str) -> dict:
    return {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [
        {"@type": "ListItem", "position": 1, "name": "ORION", "item": SITE + "/"},
        {"@type": "ListItem", "position": 2, "name": nom, "item": SITE + chemin}]}


# --------------------------------------------------------------------------
# Soldes Steam
# --------------------------------------------------------------------------

def page_soldes(auj: dt.date, style: str) -> str:
    chemin = "/soldes-steam"
    p = ST.prochaine(auj)
    if p is None:                     # calendrier a relire : la page le dit
        raise RuntimeError("soldes_steam.py : plus aucune solde a venir, relire le calendrier de Valve")
    nom, debut, fin = p
    en_cours = debut <= auj
    h_debut, h_fin = ST.heure_paris(debut), ST.heure_paris(fin)
    lignes = []
    for n, d1, d2 in ST.SOLDES:
        classe = ' class="fini"' if d2 < auj else (' class="vise"' if (n, d1, d2) == p else "")
        etat = "terminées" if d2 < auj else ("en cours" if d1 <= auj else f"dès {ST.heure_paris(d1)} h")
        lignes.append(f"<tr{classe}><td>{e(n)}</td><td>{e(date_fr(d1))}</td><td>{e(date_fr(d2))}</td>"
                      f"<td>{e(etat)}</td></tr>")
    for n in ST.PAS_ANNONCEES:
        lignes.append(f'<tr><td>{e(n)}</td><td colspan="3">date pas encore annoncée par Valve</td></tr>')
    fini = ' class="fini"'
    fests = "".join(f"<tr{fini if d2 < auj else ''}><td>{e(n)}</td><td>{e(date_fr(d1))}</td>"
                    f"<td>{e(date_fr(d2))}</td></tr>" for n, d1, d2 in ST.FESTIVALS)
    heures = sorted({ST.heure_paris(d) for _, d1, d2 in ST.SOLDES if d2 >= auj for d in (d1, d2)})
    if len(heures) > 1:
        autres = [f"{ST.minuscule(n)} : {ST.heure_paris(d1)} h" for n, d1, d2 in ST.SOLDES
                  if d2 >= auj and ST.heure_paris(d1) != h_debut]
        heure_txt = (f"À 10 h, heure du Pacifique, soit {h_debut} h à Paris pour les {ST.minuscule(nom)}. "
                     f"L'heure de Paris change quand l'Amérique et l'Europe ne passent pas à l'heure d'été le même "
                     f"jour ({', '.join(autres)}). Les soldes finissent à la même heure qu'elles commencent.")
    else:
        heure_txt = (f"À 10 h, heure du Pacifique, soit {h_debut} h à Paris. Elles finissent à la même heure, "
                     f"le dernier jour.")
    bf = black_friday(auj.year if auj <= black_friday(auj.year) else auj.year + 1)
    steam_bf = ST.au_black_friday(bf)
    automne = f"Soldes d'automne {bf.year}"
    if steam_bf:
        bf_txt = (f"Oui : les {ST.minuscule(steam_bf[0])} ont lieu {ST.periode(steam_bf[1], steam_bf[2])}, "
                  f"la semaine du Black Friday ({date_fr(bf)}).")
    elif automne in ST.PAS_ANNONCEES:
        bf_txt = (f"Valve n'a pas encore annoncé la date de ses soldes d'automne {bf.year}. Les boutiques "
                  f"officielles comme Gamesplanet font leurs promotions pour le Black Friday ({date_fr(bf)}).")
    else:
        a = ST.nommee(automne)
        bf_txt = (f"Non : en {bf.year}, Valve a placé ses soldes d'automne "
                  + (f"{ST.periode(a[1], a[2])}" if a else "à une autre période")
                  + f". Le Black Friday ({date_fr(bf)}) n'a pas de soldes Steam ; les boutiques officielles comme "
                    f"Gamesplanet font en revanche leurs promotions.")
    questions = [
        ("Quand sont les prochaines soldes Steam ?",
         (f"Les {ST.minuscule(nom)} sont en cours jusqu'au {date_fr(fin)} à {h_fin} h (heure de Paris)."
          if en_cours else
          f"Les {ST.minuscule(nom)}, {ST.periode(debut, fin)}, à partir de {h_debut} h (heure de Paris).")
         + " Dates publiées par Valve."),
        ("À quelle heure commencent les soldes Steam ?", heure_txt),
        (f"Y a-t-il des soldes Steam pour le Black Friday {bf.year} ?", bf_txt),
        ("Peut-on se faire rembourser un jeu acheté pendant les soldes ?",
         "Oui, comme tout achat sur Steam : le remboursement se demande dans les 14 jours qui suivent l'achat, "
         "avec moins de 2 heures de jeu."),
        ("Quelle différence entre les soldes et les festivals Steam ?",
         "Les soldes saisonnières touchent presque tout le catalogue. Les festivals (Next Fest, Scream Fest…) "
         "mettent en avant des démos ou un genre, avec des promotions sur une partie des jeux seulement."),
        ("Steam est-il le moins cher pendant ses soldes ?",
         "Souvent, mais pas toujours : les boutiques officielles qui vendent des clés Steam (Gamesplanet, "
         "Fanatical…) baissent aussi leurs prix. ORION compare les boutiques officielles d'abord."),
    ]
    statut = (f"Les <b>{e(ST.minuscule(nom))}</b> sont en cours, jusqu'au {e(date_fr(fin))} à {h_fin} h (heure "
              f"de Paris)." if en_cours else
              f"Les prochaines soldes Steam sont les <b>{e(ST.minuscule(nom))}</b> : "
              f"{e(ST.periode(debut, fin))}, à partir de {h_debut} h (heure de Paris).")
    corps = f"""
<section class="ev">
  <p class="fil"><a href="/">ORION</a> › Soldes Steam</p>
  <h1>Soldes Steam : les dates des prochaines soldes</h1>
  <p class="chapo">{statut} Toutes les dates viennent du calendrier que Valve publie pour les éditeurs.</p>
  <div class="decompte" id="decompte-soldes" data-debut="{ST.instant(debut).isoformat()}"
    data-fin="{ST.instant(fin).isoformat()}" aria-live="off"></div>
  <h2>Calendrier des soldes Steam</h2>
  <div class="defile"><table class="cal">
    <thead><tr><th scope="col">Soldes</th><th scope="col">Début</th><th scope="col">Fin</th><th scope="col">État</th></tr></thead>
    <tbody>
    {chr(10).join(lignes)}
    </tbody>
  </table></div>
  <p class="petit">Début et fin à 10 h, heure du Pacifique. Source :
    <a href="{ST.SOURCE}" rel="noopener nofollow">calendrier des événements Steam</a>, relu le
    {e(date_fr(ST.RELU))}. En 2026, Valve a avancé ses soldes d'automne au mois d'octobre.</p>
  <h2>Les festivals Steam</h2>
  <p>Entre deux soldes, Steam organise des festivals : des démos à essayer gratuitement (Next Fest) ou un genre
    à l'honneur, avec des promotions sur une partie des jeux.</p>
  <div class="defile"><table class="cal">
    <thead><tr><th scope="col">Festival</th><th scope="col">Début</th><th scope="col">Fin</th></tr></thead>
    <tbody>{fests}</tbody>
  </table></div>
  <h2>Payer moins cher pendant les soldes</h2>
  <p><b>Remplissez votre liste de souhaits avant.</b> Steam prévient par courriel quand un jeu de la liste est
    en promotion. <b>Comparez au plus bas historique.</b> Un « -50 % » au-dessus du plus bas prix jamais relevé
    n'est pas une affaire ; ORION l'affiche à côté de chaque prix (données IsThereAnyDeal). <b>Vérifiez que le
    jeu tourne.</b> Chaque jeu a sa <a href="/jeux">page de configuration requise</a>, avec les paramètres et
    les FPS estimés pour {NB_CARTES} cartes graphiques.</p>
  <h2>En attendant les soldes</h2>
  <p>Gamesplanet, distributeur officiel des éditeurs, a des jeux très joués en promotion toute l'année :
    <a href="/bons-plans">les bons plans du moment</a>, et <a href="/gratuits">les jeux gratuits de la
    semaine</a>. Le <a href="/black-friday">Black Friday</a> est aussi l'occasion de promotions chez les
    boutiques officielles.</p>
  <div class="appel"><a class="btn" href="/bons-plans">Voir les bons plans</a>
    <a class="btn ghost" href="{EXE}">Télécharger ORION, gratuit</a></div>
  <h2>Questions fréquentes</h2>
  <div class="faq">{faq_html(questions)}</div>
</section>
{SOLDES_JS}
"""
    titre = ajuste([f"Soldes Steam {ST.minuscule(nom).replace('soldes ', '', 1)} : dates et prochaines soldes",
                    f"Soldes Steam {ST.minuscule(nom).replace('soldes ', '', 1)} : dates",
                    "Soldes Steam : dates des prochaines soldes"], TITRE_MAX)
    quand = (f"en cours jusqu'au {date_fr(fin)}" if en_cours else f"{ST.periode(debut, fin)}, dès {h_debut} h")
    desc = ajuste([f"Prochaines soldes Steam : {ST.minuscule(nom)} {quand}. Calendrier publié par Valve, "
                   f"festivals et conseils pour payer moins cher.",
                   f"Prochaines soldes Steam : {ST.minuscule(nom)} {quand}. Calendrier publié par Valve."],
                  DESC_MAX)
    ld = [fil("Soldes Steam", chemin), faq_ld(questions)]
    return gabarit(style, titre, desc, chemin, ld, corps, rubrique="guides")


# --------------------------------------------------------------------------
# Augmenter ses FPS
# --------------------------------------------------------------------------

#: (titre, texte HTML) : des reglages verifiables, sans gain chiffre invente
ETAPES_FPS = [
    ("Brancher l'écran sur la carte graphique",
     "Sur un PC de bureau, le câble de l'écran va dans la carte graphique (les prises alignées plus bas, à "
     "l'arrière), pas dans celles de la carte mère : sinon le jeu tourne sur la puce du processeur, bien moins "
     "puissante. C'est l'erreur la plus fréquente sur un PC neuf."),
    ("Mettre à jour le pilote graphique",
     "Les pilotes NVIDIA, AMD et Intel apportent régulièrement des corrections pour les jeux récents. "
     "Téléchargez-le sur le site du fabricant de la carte ; pour un PC portable, le constructeur propose "
     "souvent le sien : <a href=\"/pilotes\">les pilotes par modèle de PC</a>."),
    ("Activer DLSS, FSR ou XeSS",
     "Le jeu calcule l'image dans une définition plus basse, puis l'agrandit : c'est le moyen le plus efficace "
     "de gagner des images. Commencez par le mode « Qualité ». La génération d'images (DLSS Frame Generation, "
     "FSR 3) affiche presque deux fois plus d'images, mais ajoute un peu de latence : réservez-la aux jeux solo "
     "qui tournent déjà autour de 60 images par seconde."),
    ("Baisser d'abord les réglages qui coûtent cher",
     "Les ombres, le ray tracing et l'éclairage global, les effets volumétriques (nuages, brouillard), les "
     "réflexions et l'occlusion ambiante sont les plus gourmands. La qualité des textures coûte peu d'images "
     "tant que la mémoire de la carte suffit, et le filtrage anisotrope presque rien : gardez-les."),
    ("Préférer « Élevé » à « Ultra »",
     "Le préréglage le plus haut coûte souvent beaucoup d'images pour une différence à peine visible en jeu. "
     "Le profil « Recommandé » d'ORION choisit, jeu par jeu, le niveau le plus beau qui reste fluide sur votre "
     "PC : <a href=\"/jeux\">les paramètres conseillés de chaque jeu</a>."),
    ("Activer le mode Jeu et la planification du GPU",
     "Dans Windows 11 : Paramètres › Jeux › Mode Jeu, puis Paramètres › Système › Écran › Graphiques › "
     "« Planification du processeur graphique à accélération matérielle ». Le gain est faible, mais la "
     "génération d'images DLSS en a besoin."),
    ("Sur un portable : secteur, performances et bonne carte",
     "Branchez-le : sur batterie, un portable joue nettement moins vite. Choisissez le mode d'alimentation "
     "« Performances optimales » (Paramètres › Système › Alimentation), et attribuez le jeu à la carte "
     "graphique dédiée (Paramètres › Système › Écran › Graphiques › Hautes performances). Voir les "
     "<a href=\"/jeux/pc-portable\">jeux qui tournent sur un PC portable</a>."),
    ("Activer le profil XMP ou EXPO de la mémoire",
     "Sans lui, beaucoup de barrettes tournent à leur vitesse de base, plus lente que celle annoncée sur la "
     "boîte. Le réglage se fait dans le BIOS : à faire seulement si vous êtes à l'aise. Deux barrettes valent "
     "mieux qu'une seule (double canal), surtout pour les "
     "<a href=\"/jeux/sans-carte-graphique\">jeux sans carte graphique</a>."),
    ("Fermer ce qui tourne en arrière-plan",
     "Un navigateur qui lit une vidéo, un enregistrement d'écran permanent ou un téléchargement occupent le "
     "processeur et la mémoire. Fermez-les avant de lancer un jeu exigeant."),
    ("Surveiller la température",
     "Un PC qui chauffe baisse sa fréquence, et les images chutent au bout de quelques minutes de jeu. "
     "Dépoussiérez les filtres et les ventilateurs, et laissez l'air circuler autour du boîtier ou sous le "
     "portable."),
]


def page_fps(auj: dt.date, style: str) -> str:
    chemin = "/augmenter-fps"
    etapes = "\n".join(f"    <li><b>{e(t)}</b>{x}</li>" for t, x in ETAPES_FPS)
    questions = [
        ("Combien de FPS faut-il pour bien jouer ?",
         "30 images par seconde : jouable. 60 : fluide, la cible de la plupart des jeux. 120 et plus : utile dans "
         "les jeux compétitifs, avec un écran à 144 Hz ou plus."),
        ("Le DLSS ou le FSR baissent-ils la qualité d'image ?",
         "En mode « Qualité », très peu en 1440p et en 4K ; en 1080p, l'image peut être un peu plus douce. Les "
         "modes « Performance » gagnent davantage d'images, mais la différence se voit plus."),
        ("Pourquoi mes FPS chutent-ils d'un coup ?",
         "Le plus souvent : le PC chauffe et baisse sa fréquence, la mémoire de la carte graphique est pleine "
         "(textures trop hautes), ou une tâche de fond démarre (mise à jour, analyse antivirus)."),
        ("Un écran 144 Hz donne-t-il plus de FPS ?",
         "Non : il affiche plus d'images si le PC les calcule. Vérifiez qu'il est bien réglé à 144 Hz dans "
         "Windows (Paramètres › Système › Écran › Affichage avancé)."),
        ("Les logiciels « booster » ou nettoyeurs de registre font-ils gagner des FPS ?",
         "Non. Ils ne donnent pas d'images mesurables, et certains installent des logiciels publicitaires. "
         "Désactiver des services de Windows au hasard n'aide pas non plus, et peut casser des fonctions."),
    ]
    corps = f"""
<section class="ev">
  <p class="fil"><a href="/">ORION</a> › Augmenter ses FPS</p>
  <h1>Augmenter ses FPS sur PC : 10 réglages qui marchent vraiment</h1>
  <p class="chapo">Gagner des images par seconde sans rien acheter : dans l'ordre, de ce qui rapporte le plus à
    ce qui sert dans certains cas. Aucun chiffre miracle : le gain dépend du jeu et du PC, mesurez avant et
    après.</p>
  <ol class="etapes">
{etapes}
  </ol>
  <h2>Ce qui ne sert à rien</h2>
  <p>Les « game boosters », nettoyeurs de registre et optimiseurs en un clic ne donnent pas d'images
    mesurables. Désactiver des services de Windows au hasard non plus. Le reste dépend du matériel : voir
    les <a href="/jeux/peu-gourmands">jeux peu gourmands</a> qui tournent sur une petite config.</p>
  <h2>Mesurer avant et après</h2>
  <p>ORION, launcher gratuit pour Windows, mesure les images par seconde réelles pendant que vous jouez, et
    règle chaque jeu pour votre carte graphique et votre écran avec son profil « Recommandé ». Sans compte,
    sans publicité.</p>
  <div class="appel"><a class="btn" href="{EXE}">Télécharger ORION pour Windows</a>
    <a class="btn ghost" href="/jeux">Paramètres et FPS de chaque jeu</a></div>
  <h2>Questions fréquentes</h2>
  <div class="faq">{faq_html(questions)}</div>
  <p class="petit">Mis à jour le {e(date_fr(auj))}.</p>
</section>
"""
    titre = ajuste(["Augmenter ses FPS sur PC : 10 réglages qui marchent", "Augmenter ses FPS sur PC"], TITRE_MAX)
    desc = ajuste(["Gagner des FPS sans rien acheter : pilote, DLSS et FSR, réglages qui coûtent le plus, mode "
                   "Jeu, portable sur secteur… et ce qui ne sert à rien.",
                   "Gagner des FPS sans rien acheter : pilote, DLSS et FSR, réglages gourmands, mode Jeu."],
                  DESC_MAX)
    article = {"@context": "https://schema.org", "@type": "Article",
               "headline": "Augmenter ses FPS sur PC : 10 réglages qui marchent vraiment",
               "inLanguage": "fr", "url": SITE + chemin, "datePublished": "2026-10-13",
               "dateModified": auj.isoformat(), "image": SITE + "/img/og.jpg",
               "author": {"@type": "Organization", "name": "ORION Game Launcher", "url": SITE + "/"},
               "publisher": {"@type": "Organization", "name": "ORION Game Launcher", "url": SITE + "/"}}
    ld = [article, fil("Augmenter ses FPS", chemin), faq_ld(questions)]
    return gabarit(style, titre, desc, chemin, ld, corps, rubrique="guides")


# --------------------------------------------------------------------------
# Config PC gamer 2026 (17 octobre 2026, page du tuto video)
# --------------------------------------------------------------------------

#: releve des prix : a refaire avant chaque mise a jour de la page (jamais devine)
CONFIG_RELEVE = dt.date(2026, 10, 17)
#: (composant, choix, prix en euros, pourquoi, source)
CONFIG = [
    ("Processeur", "AMD Ryzen 7 7800X3D", 273.90,
     "un des meilleurs processeurs en jeu ; 48 € de moins que le 20 septembre", "Cowcotland, relevé du 11/10/2026"),
    ("Carte mère", "B650 (socket AM5), par exemple ASRock B650 Pro RS", 169.99,
     "le chipset le plus simple qui accepte ce processeur et la DDR5", "comparateur-gamer, 17/10/2026"),
    ("Mémoire", "32 Go de DDR5-6000 (2 × 16 Go)", 489.90,
     "deux barrettes pour le double canal ; 32 Go, la norme chez 42 % des joueurs Steam", "Cowcotland, 12/10/2026"),
    ("Carte graphique", "AMD Radeon RX 9070 XT 16 Go", 849.90,
     "vise 144 images par seconde en 1440p ; une RTX 5070 (794,90 €) suffit pour 60", "Cowcotland, relevé du 2 au 9/10/2026"),
    ("SSD", "NVMe 1 To", 154.11, "les jeux récents demandent un SSD (135 Go pour Fable)", "PC Radar, 15/10/2026"),
    ("Alimentation", "750 W, certifiée 80+ Gold", 82.80, "assez de marge pour la carte graphique", "PC Radar, 12/10/2026"),
    ("Ventirad", "ventirad tour, pâte thermique fournie", 32.77, "silencieux et suffisant pour ce processeur",
     "PC Radar, 12/10/2026"),
    ("Boîtier", "boîtier ATX bien ventilé", 82.01, "de l'air frais devant, de l'air chaud qui sort derrière",
     "PC Radar, 12/10/2026"),
]
#: images par seconde moyennes de la RX 9070 XT et de la RTX 5070 en 1440p (TechSpot, 07/09/2026, Ryzen 7 9800X3D)
CONFIG_IPS = [("Crimson Desert", "Cinématique", "86", "75"), ("Final Fantasy XVI", "Ultra", "103", "66"),
              ("Helldivers 2", "Ultra", "124", "104"), ("God of War Ragnarök", "Élevé", "143", "112"),
              ("Forza Horizon 5", "Ultra", "plus de 200", "—")]
SOURCE_IPS = "https://www.techspot.com/review/3168-geforce-rtx-5070-vs-radeon-rx-9070-xt/"
#: le montage, dans l'ordre (verifiable, sans risque)
CONFIG_MONTAGE = [
    ("Le processeur", "Repérez le petit triangle doré dans un coin du processeur et le même sur le socket. Posez-le "
     "à plat, sans forcer ni appuyer, puis refermez le levier : le cache en plastique saute tout seul."),
    ("La mémoire", "Deux barrettes dans les emplacements 2 et 4 (A2 et B2 sur la notice). Ouvrez les clips, "
     "alignez l'encoche, appuyez des deux côtés jusqu'au clic."),
    ("Le SSD", "Dans le port M.2 du haut, le plus proche du processeur, sous son dissipateur : une seule vis."),
    ("Le ventirad", "La pâte thermique est souvent déjà posée sous le ventirad. Sinon, un petit point au centre "
     "du processeur suffit. Serrez les vis en croix, un peu à chaque fois."),
    ("La carte mère dans le boîtier", "Vissez-la sur les entretoises du boîtier, après avoir posé la plaque "
     "arrière si elle n'est pas intégrée."),
    ("L'alimentation", "Le gros câble de 24 broches de la carte mère, et le câble 8 broches du processeur, en haut "
     "à gauche de la carte."),
    ("La carte graphique", "Dans le premier port PCIe, le plus long et le plus proche du processeur, puis ses câbles "
     "d'alimentation. Vissez-la au boîtier."),
    ("Les câbles du boîtier", "Bouton Power, Reset et voyants : le vrai boss de fin. Suivez le schéma de la notice "
     "de la carte mère, broche par broche."),
    ("Le premier démarrage", "Une à deux minutes d'écran noir au premier démarrage, c'est normal : la carte mère "
     "teste la mémoire. Dans le BIOS, activez le profil EXPO pour que la mémoire tourne à 6000, puis installez "
     "Windows et le pilote de la carte graphique."),
]


#: le tuto video publie le 17/10/2026 (TikTok et YouTube Shorts d'ORION)
TUTO_TIKTOK = "https://www.tiktok.com/@oriongamelauncher/video/7697623415649438978"
TUTO_YOUTUBE = "https://www.youtube.com/shorts/4DNq5aqtXE0"


def page_config(auj: dt.date, style: str) -> str:
    chemin = "/config-pc-gamer-2026"
    total = sum(p for _c, _x, p, _w, _s in CONFIG)
    prix = lambda v: f"{v:,.2f}".replace(",", " ").replace(".", ",") + " €"
    lignes = "\n".join(f"      <tr><td>{e(c)}</td><td><b>{e(x)}</b><br><span class=\"petit\">{e(w)}</span></td>"
                       f"<td class=\"prix\">{prix(p)}</td><td class=\"petit\">{e(s)}</td></tr>" for c, x, p, w, s in CONFIG)
    ips = "\n".join(f"      <tr><td>{e(j)}</td><td>{e(r)}</td><td><b>{e(a)}</b></td><td>{e(b)}</td></tr>"
                    for j, r, a, b in CONFIG_IPS)
    etapes = "\n".join(f"    <li><b>{e(t)}</b>{e(x)}</li>" for t, x in CONFIG_MONTAGE)
    releve = date_fr(CONFIG_RELEVE)
    questions = [
        ("Quelle config PC gamer acheter en 2026 ?",
         f"Pour jouer en 1440p : un Ryzen 7 7800X3D, une carte mère B650, 32 Go de DDR5-6000, une RX 9070 XT, un SSD "
         f"NVMe d'1 To et une alimentation 750 W 80+ Gold. Environ {prix(round(total))[:-5]} € aux prix relevés en "
         f"France le {releve}."),
        ("Combien coûte un PC gamer en 2026 ?",
         f"Environ {prix(round(total))[:-5]} € pour la config de cette page, visée sur le 1440p et 144 images par "
         "seconde. Avec une RTX 5070 au lieu de la RX 9070 XT, 55 € de moins, pour 60 images par seconde dans la "
         "plupart des gros jeux."),
        ("Pourquoi la mémoire vive coûte-t-elle si cher en 2026 ?",
         "Les centres de données de l'intelligence artificielle achètent la mémoire en masse. En octobre 2026, 32 Go "
         "de DDR5-6000 coûtent plus cher que le processeur conseillé ici. Si votre PC a déjà 32 Go et un processeur "
         "récent, changer seulement la carte graphique revient bien moins cher."),
        ("RTX 5070 ou RX 9070 XT ?",
         "Pour 60 images par seconde en 1440p, la RTX 5070 suffit dans la plupart des gros jeux. Pour viser 144, la RX "
         "9070 XT, 55 € de plus, est en moyenne 24 % plus rapide en 1440p selon TechSpot, avec l'upscaling dans les "
         "jeux les plus lourds."),
        ("L'écran reste noir au premier démarrage : est-ce normal ?",
         "Oui, une à deux minutes sur les cartes mères AM5 : elles testent la mémoire au premier démarrage. Ne coupez "
         "pas le courant. Si rien ne s'affiche après cinq minutes, vérifiez les câbles 24 et 8 broches et que l'écran "
         "est branché sur la carte graphique."),
        ("Faut-il activer EXPO ?",
         "Oui : sans lui, la DDR5-6000 tourne à sa vitesse de base, plus lente. Le réglage est dans le BIOS, en une "
         "option."),
    ]
    corps = f"""
<section class="ev">
  <p class="fil"><a href="/">ORION</a> › Config PC gamer 2026</p>
  <h1>Config PC gamer 2026 : quoi acheter, comment le monter, ce que ça donne</h1>
  <p class="chapo">Une config pour jouer en 1440p : au moins 60 images par seconde dans les gros jeux, 144 dans
    beaucoup d'autres. Prix relevés en France entre le 10 et le {e(releve)} ; ils bougent chaque semaine.</p>
  <p class="petit">Le tuto en vidéo (1 min 51) : <a href="{TUTO_TIKTOK}" rel="noopener">sur TikTok</a> ·
    <a href="{TUTO_YOUTUBE}" rel="noopener">sur YouTube</a>.</p>
  <h2>La liste : environ {prix(round(total))[:-5]} €</h2>
  <div class="defile"><table class="cal">
    <thead><tr><th scope="col">Composant</th><th scope="col">Choix</th><th scope="col">Prix</th>
      <th scope="col">Source</th></tr></thead>
    <tbody>
{lignes}
      <tr class="vise"><td>Total</td><td></td><td class="prix">{prix(total)}</td><td></td></tr>
    </tbody>
  </table></div>
  <p><b>Le piège de 2026, c'est la mémoire.</b> 32 Go de DDR5 coûtent plus cher que le processeur (voir <a href="/prix-ram">le prix de la RAM</a>). Si votre PC a
    déjà 32 Go et un processeur récent, changez seulement la carte graphique : ORION vous dit, jeu par jeu, ce
    que votre machine tient aujourd'hui et ce qu'une nouvelle carte changerait.</p>
  <h2>60 ou 144 images par seconde ?</h2>
  <p>Pour 60 images par seconde en 1440p, une RTX 5070 (794,90 €) suffit dans la plupart des gros jeux. Pour viser
    144, sur un écran 144 Hz, la RX 9070 XT ne coûte que 55 € de plus. Dans les jeux les plus lourds, activez
    l'upscaling (FSR ou DLSS) : voir <a href="/augmenter-fps">augmenter ses FPS</a>. Toutes les cartes et leurs prix :
    <a href="/prix-cartes-graphiques">prix des cartes graphiques</a>.</p>
  <h2>Le montage en 9 étapes</h2>
  <ol class="etapes">
{etapes}
  </ol>
  <p>Pas de marteau, pas de perceuse : rien ne se force dans un PC. Si une pièce résiste, elle est à l'envers.</p>
  <h2>Ce que ça donne en 1440p</h2>
  <div class="defile"><table class="cal">
    <thead><tr><th scope="col">Jeu</th><th scope="col">Réglages</th><th scope="col">RX 9070 XT</th>
      <th scope="col">RTX 5070</th></tr></thead>
    <tbody>
{ips}
    </tbody>
  </table></div>
  <p class="petit">Images par seconde moyennes, tests <a href="{SOURCE_IPS}" rel="noopener nofollow">TechSpot</a>
    du 7 septembre 2026, avec un Ryzen 7 9800X3D : avec le 7800X3D, comptez quelques images de moins.</p>
  <h2>Et votre PC à vous ?</h2>
  <p>ORION, launcher gratuit pour Windows, lit votre processeur, votre carte graphique, votre mémoire et la
    fréquence de votre écran, puis règle chaque jeu pour la tenir. Sans compte, sans publicité. Chaque jeu a aussi
    sa <a href="/jeux">fiche de configuration requise</a>, avec les FPS estimés pour {NB_CARTES} cartes
    graphiques.</p>
  <div class="appel"><a class="btn" href="{EXE}">Télécharger ORION, gratuit</a>
    <a class="btn ghost" href="/jeux">Configs de tous les jeux</a></div>
  <h2>Questions fréquentes</h2>
  <div class="faq">{faq_html(questions)}</div>
  <p class="petit">Mis à jour le {e(date_fr(auj))}. Aucun lien de cette page n'est un lien partenaire.</p>
</section>
"""
    titre = ajuste(["Config PC gamer 2026 : la liste, le montage et les FPS", "Config PC gamer 2026"], TITRE_MAX)
    desc = ajuste([f"Config PC gamer 2026 à environ {prix(round(total))[:-5]} € : Ryzen 7 7800X3D, 32 Go DDR5, "
                   f"RX 9070 XT. Prix du {releve}, montage en 9 étapes, FPS en 1440p.",
                   f"Config PC gamer 2026 : Ryzen 7 7800X3D, 32 Go DDR5, RX 9070 XT, montage et FPS en 1440p."],
                  DESC_MAX)
    article = {"@context": "https://schema.org", "@type": "Article",
               "headline": "Config PC gamer 2026 : quoi acheter, comment le monter, ce que ça donne",
               "inLanguage": "fr", "url": SITE + chemin, "datePublished": "2026-10-17",
               "dateModified": auj.isoformat(), "image": SITE + "/img/og.jpg",
               "author": {"@type": "Organization", "name": "ORION Game Launcher", "url": SITE + "/"},
               "publisher": {"@type": "Organization", "name": "ORION Game Launcher", "url": SITE + "/"}}
    howto = {"@context": "https://schema.org", "@type": "HowTo", "name": "Monter son PC gamer",
             "inLanguage": "fr", "totalTime": "PT2H",
             "estimatedCost": {"@type": "MonetaryAmount", "currency": "EUR", "value": f"{total:.2f}"},
             "supply": [{"@type": "HowToSupply", "name": x} for _c, x, _p, _w, _s in CONFIG],
             "tool": [{"@type": "HowToTool", "name": "Tournevis cruciforme"}],
             "step": [{"@type": "HowToStep", "position": k, "name": t, "text": x}
                      for k, (t, x) in enumerate(CONFIG_MONTAGE, 1)]}
    ld = [article, howto, fil("Config PC gamer 2026", chemin), faq_ld(questions)]
    return gabarit(style, titre, desc, chemin, ld, corps, rubrique="guides")


# --------------------------------------------------------------------------
# Prix de la RAM et des cartes graphiques (17 octobre 2026) : pages « actu des
# prix », a remettre a jour chaque semaine avec le releve de Cowcotland
# --------------------------------------------------------------------------

PRIX_RELEVE = dt.date(2026, 10, 12)
#: (kit, prix le plus bas, detail, source)
PRIX_RAM = [
    ("32 Go DDR5-6000 CL36 (2 × 16 Go)", "dès 489,90 €", "kit de référence à 546,90 €, +117 € en une semaine",
     "Cowcotland, 12/10/2026"),
    ("32 Go DDR4-3200 (2 × 16 Go)", "239,90 €", "kit de référence, sans changement sur la semaine", "Cowcotland, 12/10/2026"),
    ("32 Go DDR5-6000 aux États-Unis", "449,97 $", "400 $ en août 2026", "Tom's Hardware, 14/10/2026"),
]
#: (carte, memoire, prix, note) : releve Cowcotland du 2 au 9 octobre 2026, publie le 10/10
PRIX_GPU = [
    ("GeForce RTX 5060", "8 Go", "473,90 €", "1080p ; 8 Go ferment déjà certains modes ray tracing"),
    ("Radeon RX 9060 XT", "16 Go", "574,90 €", "16 Go de mémoire vidéo pour moins de 600 €"),
    ("GeForce RTX 5060 Ti", "16 Go", "774,90 €", ""),
    ("GeForce RTX 5070", "12 Go", "794,90 €", "60 i/s en 1440p dans la plupart des gros jeux"),
    ("Radeon RX 9070 XT", "16 Go", "849,90 €", "vise 144 i/s en 1440p, 24 % plus rapide que la RTX 5070 (TechSpot)"),
    ("GeForce RTX 5070 Ti", "16 Go", "1 109,90 €", "−190 € sur la semaine ; du niveau de la RX 9070 XT (indice ORION)"),
    ("GeForce RTX 5090", "32 Go", "5 999,90 €", ""),
]


def _tableau(entetes, lignes) -> str:
    th = "".join(f'<th scope="col">{e(x)}</th>' for x in entetes)
    tr = "\n".join("      <tr>" + "".join(f"<td>{c}</td>" for c in l) + "</tr>" for l in lignes)
    return (f'<div class="defile"><table class="cal">\n    <thead><tr>{th}</tr></thead>\n    <tbody>\n{tr}\n'
            f'    </tbody>\n  </table></div>')


def _article(titre, chemin, publie, auj):
    return {"@context": "https://schema.org", "@type": "Article", "headline": titre, "inLanguage": "fr",
            "url": SITE + chemin, "datePublished": publie, "dateModified": auj.isoformat(), "image": SITE + "/img/og.jpg",
            "author": {"@type": "Organization", "name": "ORION Game Launcher", "url": SITE + "/"},
            "publisher": {"@type": "Organization", "name": "ORION Game Launcher", "url": SITE + "/"}}


def page_prix_ram(auj: dt.date, style: str) -> str:
    chemin = "/prix-ram"
    h1 = "Prix de la RAM en octobre 2026 : DDR5 et DDR4 en France"
    tab = _tableau(["Kit", "Prix", "Détail", "Source"],
                   [(f"<b>{e(k)}</b>", f'<span class="prix">{e(p)}</span>', e(d), f'<span class="petit">{e(s)}</span>')
                    for k, p, d, s in PRIX_RAM])
    questions = [
        ("Pourquoi la RAM est-elle si chère en 2026 ?",
         "Les centres de données de l'intelligence artificielle achètent la mémoire en masse, et les fabricants "
         "leur réservent leur production. TrendForce attend encore 10 à 15 % de hausse des prix contractuels de la "
         "DRAM au quatrième trimestre 2026."),
        ("Quand les prix de la RAM vont-ils baisser ?",
         "Personne ne le sait avec certitude. La banque Barclays voit la pénurie durer encore environ deux ans "
         "(TechNews, 13 octobre 2026). Les prix bougent aussi d'une semaine à l'autre : comparez avant d'acheter."),
        ("16 ou 32 Go pour jouer en 2026 ?",
         "32 Go est devenu la norme (42 % des joueurs Steam en septembre 2026). Si vos 16 Go fonctionnent, gardez-les "
         "et fermez les onglets inutiles avant de jouer : certains modes ray tracing récents demandent 32 Go."),
        ("DDR4 ou DDR5 ?",
         "Ce n'est pas un choix : c'est la carte mère qui décide. Les processeurs AM5 et les Intel Core Ultra demandent "
         "de la DDR5. ORION affiche la mémoire et la carte mère de votre PC dans sa page « Ma machine »."),
        ("Une barrette ou deux ?",
         "Deux, de même modèle : la mémoire fonctionne alors en double canal, nettement plus rapide en jeu, surtout "
         "sans carte graphique."),
    ]
    corps = f"""
<section class="ev">
  <p class="fil"><a href="/">ORION</a> › Prix de la RAM</p>
  <h1>{e(h1)}</h1>
  <p class="chapo">La mémoire vive n'a jamais coûté aussi cher : en octobre 2026, 32 Go de DDR5 coûtent plus cher qu'un
    bon processeur de jeu. Les prix relevés, leur source et leur date.</p>
  <h2>Les prix relevés</h2>
  {tab}
  <p class="petit">Prix les plus bas relevés en France par Cowcotland le {e(date_fr(PRIX_RELEVE))} ; prix américain
    relevé par Tom's Hardware. Ils changent chaque semaine.</p>
  <h2>Pourquoi si cher ?</h2>
  <p>Les centres de données de l'intelligence artificielle achètent la mémoire en masse. La DDR4 n'y échappe pas :
    +24 % en trois mois selon Barclays, parfois plus chère que la DDR5. Même Valve a annoncé sa Steam Machine bien
    plus chère que prévu, à cause de la mémoire.</p>
  <h2>Que faire ?</h2>
  <ol class="etapes">
    <li><b>Vos 16 Go marchent ? Gardez-les</b>Fermez le navigateur et ses onglets avant de jouer : c'est gratuit.</li>
    <li><b>Si vous achetez : un kit de deux barrettes</b>Deux barrettes identiques pour le double canal, jamais une
      seule.</li>
    <li><b>Vérifiez ce que votre carte mère accepte</b>DDR4 ou DDR5, et la vitesse maximale : la notice de la carte
      mère le dit, ORION aussi.</li>
  </ol>
  <p>Avant d'acheter de la mémoire ou une carte graphique, regardez ce que votre PC tient déjà : ORION, launcher
    gratuit pour Windows, estime pour chaque jeu le niveau de détails et les images par seconde de votre machine.
    Voir aussi <a href="/prix-cartes-graphiques">le prix des cartes graphiques</a> et
    <a href="/config-pc-gamer-2026">la config PC gamer 2026</a>.</p>
  <div class="appel"><a class="btn" href="{EXE}">Télécharger ORION, gratuit</a>
    <a class="btn ghost" href="/config-pc-gamer-2026">Config PC gamer 2026</a></div>
  <h2>Questions fréquentes</h2>
  <div class="faq">{faq_html(questions)}</div>
  <p class="petit">Mis à jour le {e(date_fr(auj))}. Sources : Cowcotland (12/10/2026), Tom's Hardware (14/10/2026),
    TrendForce (30/09/2026), Barclays cité par TechNews (13/10/2026). Aucun lien de cette page n'est un lien
    partenaire.</p>
</section>
"""
    titre = ajuste(["Prix de la RAM en octobre 2026 : DDR5 et DDR4 en France", "Prix de la RAM DDR5 et DDR4"], TITRE_MAX)
    desc = ajuste(["Prix de la RAM en France : 32 Go de DDR5-6000 dès 489,90 €, DDR4 à 239,90 € (relevé du 12/10). "
                   "Pourquoi si cher, et que faire.",
                   "Prix de la RAM en France : 32 Go de DDR5 dès 489,90 €, DDR4 à 239,90 €. Pourquoi, et que faire."],
                  DESC_MAX)
    ld = [_article(h1, chemin, "2026-10-17", auj), fil("Prix de la RAM", chemin), faq_ld(questions)]
    return gabarit(style, titre, desc, chemin, ld, corps, rubrique="guides")


def page_prix_gpu(auj: dt.date, style: str) -> str:
    chemin = "/prix-cartes-graphiques"
    h1 = "Prix des cartes graphiques en octobre 2026 en France"
    tab = _tableau(["Carte", "Mémoire", "Prix", "Pour quoi faire"],
                   [(f"<b>{e(c)}</b>", e(m), f'<span class="prix">{e(p)}</span>', f'<span class="petit">{e(n)}</span>')
                    for c, m, p, n in PRIX_GPU])
    questions = [
        ("Quelle carte graphique pour jouer en 1440p en 2026 ?",
         "Pour 60 images par seconde dans la plupart des gros jeux : une RTX 5070 (794,90 €). Pour viser 144 sur un "
         "écran 144 Hz : une RX 9070 XT (849,90 €) ou une RTX 5070 Ti, avec l'upscaling dans les jeux les plus lourds."),
        ("Pourquoi les cartes graphiques sont-elles si chères ?",
         "La pénurie de mémoire touche aussi la mémoire vidéo : les puces partent vers les centres de données de "
         "l'intelligence artificielle."),
        ("8 Go de mémoire vidéo suffisent-ils en 2026 ?",
         "Pour du 1080p, souvent. Mais des modes récents en demandent plus : le ray tracing de Modern Warfare 4 exige "
         "16 Go. Pour garder une carte plusieurs années, visez 12 ou 16 Go."),
        ("Ma carte actuelle suffit-elle ?",
         "Chaque jeu a sa fiche de configuration requise sur ce site, avec les FPS estimés par carte graphique. ORION "
         "fait le calcul pour votre PC exact, avec la fréquence de votre écran."),
    ]
    corps = f"""
<section class="ev">
  <p class="fil"><a href="/">ORION</a> › Prix des cartes graphiques</p>
  <h1>{e(h1)}</h1>
  <p class="chapo">Les prix les plus bas relevés en France, carte par carte, et ce que chaque carte permet en jeu :
    60 images par seconde, ou 144 sur un écran rapide.</p>
  <h2>Les prix relevés</h2>
  {tab}
  <p class="petit">Relevé des prix en France par Cowcotland du 2 au 9 octobre 2026 (publié le 10/10). Images par
    seconde : tests TechSpot en 1440p du 7 septembre 2026. Les prix changent chaque semaine.</p>
  <h2>60 ou 144 images par seconde ?</h2>
  <p>En 1440p, la RTX 5070 tient 60 images par seconde dans la plupart des gros jeux (75 dans Crimson Desert, 66
    dans Final Fantasy XVI). La RX 9070 XT, 55 € de plus, monte à 143 dans God of War Ragnarök et dépasse 200 dans
    Forza Horizon 5. Voir la <a href="/config-pc-gamer-2026">config PC gamer 2026</a> complète et
    <a href="/augmenter-fps">comment gagner des FPS</a> sans rien acheter.</p>
  <p>Avant de changer de carte, regardez ce que la vôtre tient : chaque jeu a sa
    <a href="/jeux">fiche de configuration requise</a>, et ORION fait le calcul pour votre PC exact.</p>
  <div class="appel"><a class="btn" href="{EXE}">Télécharger ORION, gratuit</a>
    <a class="btn ghost" href="/jeux">Configs de tous les jeux</a></div>
  <h2>Questions fréquentes</h2>
  <div class="faq">{faq_html(questions)}</div>
  <p class="petit">Mis à jour le {e(date_fr(auj))}. Aucun lien de cette page n'est un lien partenaire. Voir aussi
    <a href="/prix-ram">le prix de la RAM</a>.</p>
</section>
"""
    titre = ajuste(["Prix des cartes graphiques en octobre 2026 en France", "Prix des cartes graphiques 2026"], TITRE_MAX)
    desc = ajuste(["Prix des cartes graphiques en France : RTX 5060 à 473,90 €, RTX 5070 à 794,90 €, RX 9070 XT à "
                   "849,90 €… et ce que chacune permet en 1440p.",
                   "Prix des cartes graphiques en France : RTX 5070 à 794,90 €, RX 9070 XT à 849,90 €."], DESC_MAX)
    ld = [_article(h1, chemin, "2026-10-17", auj), fil("Prix des cartes graphiques", chemin), faq_ld(questions)]
    return gabarit(style, titre, desc, chemin, ld, corps, rubrique="guides")


# --------------------------------------------------------------------------
# « Mon PC peut-il faire tourner… ? » (17 octobre 2026, vague 2 du
# referencement) : la porte d'entree des recherches « peut-il faire tourner »,
# « can I run it ». Rien de neuf a estimer : la page mene aux 1 122 fiches
# (config de l'editeur + FPS estimes) et aux pages par carte graphique.
# --------------------------------------------------------------------------

#: gros jeux du moment mis en avant (seuls ceux qui ont une fiche sont gardes)
PEUT_IL_JEUX = ["battlefield-6", "borderlands-4", "monster-hunter-wilds", "cyberpunk-2077", "black-myth-wukong",
                "clair-obscur-expedition-33", "arc-raiders", "kingdom-come-deliverance-ii", "hollow-knight-silksong",
                "elden-ring-nightreign", "marvel-rivals", "call-of-duty-warzone"]
PEUT_IL_TYPES = [("/jeux/sans-carte-graphique", "Sans carte graphique"), ("/jeux/pc-portable", "PC portable"),
                 ("/jeux/peu-gourmands", "Petite config")]
# classe « cherche grand » : recherche.js l'equipe comme celle de l'en-tete, et gen_recherche ajoute quand meme la barre d'en-tete
CHERCHE = ('<form class="cherche grand" action="/recherche" role="search"><input type="search" name="q" '
           'placeholder="Nom du jeu" aria-label="Nom du jeu" autocomplete="off" enterkeyhint="search" '
           'spellcheck="false"><button type="submit" aria-label="Chercher"><svg viewBox="0 0 24 24" width="18" '
           'height="18" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5" fill="none" stroke="currentColor" '
           'stroke-width="2.2"/><path d="M15.5 15.5 21 21" stroke="currentColor" stroke-width="2.2" '
           'stroke-linecap="round"/></svg></button></form>')


def page_peut_il(dossier: Path, auj: dt.date, style: str) -> str:
    import json
    chemin = "/mon-pc-peut-il-faire-tourner"
    jeux = {x[1]: x[0] for x in json.loads((dossier / "recherche.json").read_text(encoding="utf-8"))["j"]}
    nb = f"{len(jeux):,}".replace(",", "\u202f")  # « 1 122 », espace fine insecable
    gros = [(c, jeux[c]) for c in PEUT_IL_JEUX if c in jeux and (dossier / "jeux" / f"{c}.html").exists()]
    cartes = []
    for f in sorted((dossier / "jeux" / "carte").glob("*.html")):
        m = re.search(r"<p class=\"fil\">.*?› ([^<]+)</p>", f.read_text(encoding="utf-8"))
        if m:
            cartes.append((f"/jeux/carte/{f.stem}", m.group(1).strip()))
    marque = lambda n: 0 if "GeForce" in n else (1 if "Radeon" in n else 2)
    cartes.sort(key=lambda c: (marque(c[1]), c[1]))
    puces = lambda L: "\n".join(f'    <li><a href="{h}">{e(n)}</a></li>' for h, n in L)
    questions = [
        ("Comment savoir si mon PC peut faire tourner un jeu ?",
         "Comparez votre processeur, votre mémoire vive et votre carte graphique (et sa mémoire vidéo) à la "
         "configuration minimale donnée par l'éditeur. Chaque fiche ORION la reprend, avec les images par seconde "
         f"estimées pour {NB_CARTES} cartes graphiques. ORION, gratuit, fait la comparaison sur votre PC et règle le jeu."),
        ("Comment connaître ma carte graphique ?",
         "Sous Windows 10 et 11 : Ctrl + Maj + Échap ouvre le Gestionnaire des tâches ; onglet Performances, "
         "ligne GPU : le nom de la carte est en haut à droite. Le processeur et la mémoire vive sont dans le même onglet."),
        ("Configuration minimale ou recommandée ?",
         "La minimale permet de lancer le jeu, en général en réglages bas. La recommandée vise des réglages plus "
         "élevés. L'éditeur précise souvent, sur la page du jeu, la définition et les images par seconde visées."),
        ("Mon PC n'a pas de carte graphique : je peux jouer ?",
         "Oui, à beaucoup de jeux : les puces graphiques intégrées récentes font tourner les jeux légers. La page "
         "« jeux sans carte graphique » les liste avec les réglages estimés."),
        ("Quoi changer en premier pour faire tourner un jeu ?",
         "Le plus souvent la carte graphique. En 2026, la mémoire vive coûte cher : si vous avez déjà 16 Go, "
         "changez d'abord la carte, puis passez à 32 Go si le jeu les demande."),
    ]
    corps = f"""
<section class="ev">
  <p class="fil"><a href="/">ORION</a> › Mon PC peut-il faire tourner… ?</p>
  <h1>Mon PC peut-il faire tourner ce jeu ?</h1>
  <p class="chapo">Tapez le nom du jeu : sa fiche donne la configuration minimale et recommandée de l'éditeur, et
    les images par seconde estimées pour {NB_CARTES} cartes graphiques, en 1080p et en 1440p. {nb} jeux PC.</p>
  {CHERCHE}
  <h2>Les gros jeux du moment</h2>
  <ul class="liens">
{puces([(f"/jeux/{c}", n) for c, n in gros] + [("/gta-6-pc", "GTA 6 sur PC"), ("/call-of-duty-modern-warfare-4", "Call of Duty: Modern Warfare 4")])}
  </ul>
  <h2>Par carte graphique</h2>
  <p>Tous les jeux qu'une carte fait tourner, avec les réglages et les images par seconde attendus.</p>
  <ul class="liens">
{puces(cartes)}
  </ul>
  <h2>Par type de PC</h2>
  <ul class="liens">
{puces(PEUT_IL_TYPES)}
  </ul>
  <h2>Connaître sa configuration en 30 secondes</h2>
  <ol class="etapes">
    <li><b>Ouvrez le Gestionnaire des tâches</b>Ctrl + Maj + Échap, puis l'onglet Performances.</li>
    <li><b>Lisez le nom de la carte graphique</b>Ligne GPU, en haut à droite. La mémoire vidéo dédiée est écrite en dessous.</li>
    <li><b>Lisez le processeur et la mémoire vive</b>Lignes Processeur et Mémoire du même onglet.</li>
  </ol>
  <p>Ou laissez ORION le faire : le launcher gratuit lit votre processeur, votre carte graphique, votre mémoire et la
    fréquence de votre écran, puis règle chaque jeu pour la tenir. Sans compte, sans publicité.</p>
  <div class="appel"><a class="btn" href="{EXE}">Télécharger ORION, gratuit</a>
    <a class="btn ghost" href="/config-pc-gamer-2026">Monter un PC en 2026</a></div>
  <h2>Questions fréquentes</h2>
  <div class="faq">{faq_html(questions)}</div>
  <p class="petit">Mis à jour le {e(date_fr(auj))}. Configurations reprises des pages officielles des jeux.</p>
</section>
"""
    titre = ajuste(["Mon PC peut-il faire tourner ce jeu ? Configs et FPS", "Mon PC peut-il faire tourner ce jeu ?"],
                   TITRE_MAX)
    desc = ajuste([f"Mon PC peut-il faire tourner ce jeu ? Config minimale et recommandée de {nb} jeux PC, et FPS "
                   f"estimés pour {NB_CARTES} cartes graphiques, en 1080p et 1440p.",
                   f"Config minimale, recommandée et FPS estimés de {nb} jeux PC."], DESC_MAX)
    page = {"@context": "https://schema.org", "@type": "WebPage", "name": "Mon PC peut-il faire tourner ce jeu ?",
            "inLanguage": "fr", "url": SITE + chemin, "dateModified": auj.isoformat(),
            "potentialAction": {"@type": "SearchAction", "target": SITE + "/recherche?q={search_term_string}",
                                "query-input": "required name=search_term_string"}}
    ld = [page, fil("Mon PC peut-il faire tourner… ?", chemin), faq_ld(questions)]
    return gabarit(style, titre, desc, chemin, ld, corps, rubrique="guides")


def main(dossier) -> list[str]:
    dossier = Path(dossier)
    accueil = (dossier / "index.html").read_text(encoding="utf-8")
    style = re.search(r"<style>(.*?)</style>", accueil, re.S).group(1) + CSS + CSS_GUIDES
    auj = dt.date.today()
    (dossier / "soldes-steam.html").write_text(page_soldes(auj, style), encoding="utf-8")
    (dossier / "augmenter-fps.html").write_text(page_fps(auj, style), encoding="utf-8")
    (dossier / "config-pc-gamer-2026.html").write_text(page_config(auj, style), encoding="utf-8")
    (dossier / "prix-ram.html").write_text(page_prix_ram(auj, style), encoding="utf-8")
    (dossier / "prix-cartes-graphiques.html").write_text(page_prix_gpu(auj, style), encoding="utf-8")
    (dossier / "mon-pc-peut-il-faire-tourner.html").write_text(page_peut_il(dossier, auj, style), encoding="utf-8")
    faits = [("/soldes-steam", "weekly", "0.8"), ("/augmenter-fps", "monthly", "0.8"),
             ("/config-pc-gamer-2026", "weekly", "0.9"), ("/prix-ram", "weekly", "0.8"),
             ("/prix-cartes-graphiques", "weekly", "0.8"), ("/mon-pc-peut-il-faire-tourner", "weekly", "0.9")]
    ajouter_plan(dossier, faits)
    print(f"guides : {', '.join(c for c, _f, _p in faits)}")
    return [c for c, _f, _p in faits]


if __name__ == "__main__":
    main(sys.argv[1])
