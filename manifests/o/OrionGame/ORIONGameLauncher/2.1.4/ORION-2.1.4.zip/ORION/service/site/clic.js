/* Clic sur un lien partenaire ou sur « Telecharger ORION » depuis le site :
   compte anonyme, dans le meme tableau que les clics d'ORION. Part : le nom
   court de la boutique et la famille de page. Jamais le jeu, jamais
   l'adresse, aucun identifiant, aucun cookie.
   16 octobre : les liens partenaires passent par api.orion-launcher.com/aller/,
   qui compte lui-meme le clic ; ici ne restent que les autres liens
   sponsorises et le bouton Telecharger. Le clic du milieu et « ouvrir dans un
   nouvel onglet » (auxclick) comptent aussi. */
(function () {
  var BOUTIQUES = { "steampowered.com": "steam", "gog.com": "gog", "epicgames.com": "epic",
    "gamesplanet.com": "gamesplanet", "instant-gaming.com": "instant-gaming", "kinguin.net": "kinguin",
    "loaded.com": "loaded", "xbox.com": "xbox", "ubisoft.com": "ubisoft", "ea.com": "ea",
    "battle.net": "battlenet", "humblebundle.com": "humble", "fanatical.com": "fanatical",
    "greenmangaming.com": "gmg", "microsoft.com": "microsoft" };
  var SERVICE = "https://api.orion-launcher.com";
  function hote(a) {
    try { return new URL(a.href, location.href).hostname.toLowerCase(); } catch (e) { return ""; }
  }
  function boutique(a) {
    var h = hote(a);
    if (!h) return "";
    for (var d in BOUTIQUES) { if (h === d || h.slice(-d.length - 1) === "." + d) return BOUTIQUES[d]; }
    return "autre";
  }
  function page() {
    var p = location.pathname;
    if (p.indexOf("/jeux/") === 0) return "jeu";
    if (p.indexOf("/sorties") === 0) return "sorties";
    if (p.indexOf("/bons-plans") === 0 || p.indexOf("/black-friday") === 0) return "bons-plans";
    if (p.indexOf("/gratuits") === 0) return "gratuits";
    if (p.indexOf("/recherche") === 0) return "recherche";
    if (p.indexOf("/en/") === 0 || p === "/en") return "en";
    if (p === "/" || p === "/index.html") return "accueil";
    return "autre";
  }
  function envoyer(corps) {
    if (!navigator.sendBeacon) return;
    try { navigator.sendBeacon(SERVICE + "/clic-site", JSON.stringify(corps)); } catch (e) { /* rien */ }
  }
  function telecharger(a) {
    return /Installateur-ORION\.exe$/i.test(a.href || "") || /^#?installer$/.test((a.getAttribute("href") || "").replace(/^\//, ""));
  }
  function compter(ev) {
    if (ev.type === "auxclick" && ev.button !== 1) return;              // clic du milieu seulement
    var a = ev.target && ev.target.closest ? ev.target.closest("a[href]") : null;
    if (!a) return;
    if (telecharger(a)) { envoyer({ telecharger: true, page: page() }); return; }
    if (!a.matches("a[rel~='sponsored']")) return;
    var h = hote(a);
    if (h === SERVICE.slice(8)) return;                                   // /aller/ : compte par le service
    var b = boutique(a);
    if (b) envoyer({ boutique: b, page: page() });
  }
  document.addEventListener("click", compter, true);
  document.addEventListener("auxclick", compter, true);
})();
