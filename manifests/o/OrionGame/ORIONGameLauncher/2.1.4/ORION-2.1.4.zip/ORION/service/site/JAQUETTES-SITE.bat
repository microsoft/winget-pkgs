@echo off
setlocal EnableDelayedExpansion
title ORION - visuels des jeux pour le site
cd /d "%~dp0site-jaquettes"
if not exist "liste.txt" (
  echo.
  echo   liste.txt introuvable dans le dossier site-jaquettes.
  pause
  exit /b 1
)
if not exist "images" mkdir "images"
set /a NEUFS=0
set /a DEJA=0
set /a ECHECS=0
echo.
echo   ===========================================
echo    ORION - visuels des jeux pour le site
echo   ===========================================
echo.
echo   Telecharge le visuel officiel de chaque jeu (fiche Steam), une seule
echo   fois par jeu, dans site-jaquettes\images. Rien n'est installe.
echo   Patientez quelques minutes...
echo.
for /f "usebackq tokens=1,2,3 delims=;" %%a in ("liste.txt") do (
  if exist "images\%%a.jpg" (
    set /a DEJA+=1
  ) else (
    curl.exe -s -f -L --max-time 30 -o "images\%%a.tmp" "%%b" && ren "images\%%a.tmp" "%%a.jpg"
    if not exist "images\%%a.jpg" (
      curl.exe -s -f -L --max-time 30 -o "images\%%a.tmp" "%%c" && ren "images\%%a.tmp" "%%a.jpg"
    )
    if exist "images\%%a.jpg" (
      set /a NEUFS+=1
      set /a RESTE=NEUFS %% 100
      if !RESTE!==0 echo   !NEUFS! visuels telecharges...
    ) else (
      set /a ECHECS+=1
      echo %%a>> "echecs.txt"
    )
  )
)
echo.
echo   Nouveaux : !NEUFS!   deja la : !DEJA!   echecs : !ECHECS!
echo.
echo   Termine. Dites a Claude : "visuels telecharges".
echo.
pause
