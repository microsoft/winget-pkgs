"""Page du site consacree a la sortie « a la une » (2.1.0) :
/call-of-duty-modern-warfare-4.

Demande de l'auteur (9 octobre) : mettre en avant la sortie de Modern
Warfare 4 et la vente des precommandes, avec le meilleur prix du moment.

* Prix officiel : Steam, releve a la generation (date affichee). Steam ne
  laisse pas un site lire ses prix depuis le navigateur.
* Revendeurs : dans le comparateur seulement, apres les boutiques officielles
  et les vendeurs agrees (`api.orion-launcher.com/prix?une=1`, releve garde
  10 minutes), chacun avec le type de cle qu'il vend. 10 octobre : l'encart
  « Cle Steam verifiee » melait un revendeur au prix officiel et annoncait
  une cle Steam la ou Kinguin vend une cle Microsoft Store ; il est retire.
* Configuration PC : pas encore publiee par l'editeur (« TBD » sur Steam) :
  la page le dit, rien n'est invente.

Usage : python gen_une.py <dossier du site>
"""
from __future__ import annotations

import datetime as dt
import re
import sys
from html import escape as e
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gen_jeux import SITE, gabarit  # noqa: E402

CHEMIN = "/call-of-duty-modern-warfare-4"
UNE = {
    "titre": "Call of Duty: Modern Warfare 4",
    "appid": "4435490",
    "sortie": "2026-10-23",
    "sortie_texte": "23 octobre 2026",
    "steam_texte": "22 octobre au soir sur Steam",
    "studio": "Infinity Ward",
    "editions": [("Standard", 69.99), ("Coffre d'armes", 99.99)],
    "releve": "9 octobre 2026",
    "fidelite": ("Remise de fidélité Steam : -10 % sur l'édition Coffre d'armes en précommande, "
                 "jusqu'au 23 octobre, si vous possédez et avez joué à Modern Warfare II, "
                 "Modern Warfare III, Black Ops 6 ou Black Ops 7 sur le même compte Steam. "
                 "Remise appliquée par Steam au paiement."),
    "sources": [("Fiche Steam", "https://store.steampowered.com/app/4435490/"),
                ("Annonce Xbox", "https://www.xbox.com/en-US/games/call-of-duty-modern-warfare-4")],
}

CSS = """
.une{max-width:860px;margin:0 auto;padding:40px 20px 70px}
.une h1{font-size:clamp(28px,4.4vw,44px);line-height:1.1;margin:.2em 0 .3em}
.une .chapo{color:var(--dim,#AAB4C8);font-size:17px}
.decompte{display:flex;gap:10px;margin:22px 0 26px;flex-wrap:wrap}
.decompte div{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.14);border-radius:14px;
  padding:12px 16px;min-width:78px;text-align:center}
.decompte b{display:block;font-size:34px;line-height:1}
.decompte span{font-size:11px;letter-spacing:.14em;color:var(--dim,#AAB4C8)}
.prix-une{border:1px solid rgba(255,255,255,.14);border-radius:18px;padding:20px 22px;margin:18px 0}
.prix-une h2{margin:0 0 10px;font-size:20px}
.prix-une table{width:100%;border-collapse:collapse;margin:6px 0 14px}
.prix-une td{padding:7px 0;border-bottom:1px solid rgba(255,255,255,.08)}
.prix-une td.p{text-align:right;font-weight:700}
.une h2{margin-top:38px}
.une .prix-une h2{margin-top:0}
.petit{font-size:13px;color:var(--dim,#AAB4C8)}
.fid{color:#3DDC97;font-weight:600}
"""


def euros(v: float) -> str:
    return f"{v:.2f}".replace(".", ",") + " €"


def page(u: dict = UNE) -> str:
    lignes = "".join(f'<tr><td>Édition {e(n)}</td><td class="p">{euros(p)}</td></tr>'
                     for n, p in u["editions"])
    sources = " · ".join(f'<a href="{e(url)}" rel="noopener">{e(n)}</a>' for n, url in u["sources"])
    steam = f"https://store.steampowered.com/app/{u['appid']}/"
    corps = f"""
<section class="une">
  <p class="fil"><a href="/sorties">Sorties</a></p>
  <h1>{e(u["titre"])} sur PC&nbsp;: précommande, prix et date de sortie</h1>
  <p class="chapo">Sortie le {e(u['sortie_texte'])} ({e(u['steam_texte'])}) · {e(u['studio'])} ·
    pas dans le Game Pass au lancement.</p>
  <div class="decompte" id="decompte" data-sortie="{e(u['sortie'])}T00:00:00" aria-live="polite"></div>

  <div class="prix-une" id="prix-une" data-appid="{e(u['appid'])}" data-titre="{e(u['titre'])}"
       data-officiel="{u['editions'][0][1]}">
    <h2>Précommander sur PC</h2>
    <table>{lignes}</table>
    <p><a class="btn" href="{e(steam)}" rel="noopener">Précommander sur Steam</a></p>
    <p class="petit">Prix officiels relevés sur Steam le {e(u['releve'])}. Boutique officielle.</p>
    <p class="fid">{e(u['fidelite'])}</p>
  </div>

  <h2>Comparer les prix sur PC</h2>
  <div data-comparatif data-auto="1" data-une="1" data-appid="{e(u['appid'])}" data-titre="{e(u['titre'])}"{u.get('fiches', '')}></div>

  <h2>Votre PC le fera-t-il tourner ?</h2>
  <p>La configuration PC n'est pas encore publiée par l'éditeur (Steam indique « TBD »). ORION la lira
    dès sa publication et vous dira, pour <b>votre</b> PC, le niveau de graphismes attendu et les images par
    seconde, avec le réglage prêt pour le jour de la sortie. Gratuit, sans compte.</p>
  <p><a class="btn" href="/#installer">Télécharger ORION</a></p>
  <p class="petit">Sources : {sources}. Dates et prix peuvent changer : la page est mise à jour à chaque
    version du site.</p>
</section>
<script src="/clic.js" defer></script>
<script src="/comparatif.js" defer></script>
<script>
(function () {{
  "use strict";
  var d = document.getElementById("decompte");
  var fin = new Date(d.getAttribute("data-sortie")).getTime();
  function tic() {{
    var s = Math.floor((fin - Date.now()) / 1000);
    if (s <= 0) {{ d.innerHTML = "<div><b>Disponible</b><span>MAINTENANT</span></div>"; return; }}
    var j = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60), x = s % 60;
    d.innerHTML = [[j, "JOURS"], [h, "HEURES"], [m, "MINUTES"], [x, "SECONDES"]].map(function (v) {{
      return "<div><b>" + v[0] + "</b><span>" + v[1] + "</span></div>"; }}).join("");
    setTimeout(tic, 1000);
  }}
  tic();
}})();
</script>
"""
    ld = [{"@context": "https://schema.org", "@type": "VideoGame", "name": u["titre"],
           "gamePlatform": "PC", "author": {"@type": "Organization", "name": u["studio"]},
           "datePublished": u["sortie"],
           "offers": [{"@type": "Offer", "name": f"Édition {n}", "price": f"{p:.2f}", "priceCurrency": "EUR",
                       "seller": {"@type": "Organization", "name": "Steam"},
                       "availability": "https://schema.org/PreOrder", "url": steam}
                      for n, p in u["editions"]]}]
    ld.append({"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [
        {"@type": "ListItem", "position": 1, "name": "ORION", "item": SITE + "/"},
        {"@type": "ListItem", "position": 2, "name": "Sorties", "item": SITE + "/sorties"},
        {"@type": "ListItem", "position": 3, "name": u["titre"], "item": SITE + CHEMIN}]})
    # 60 signes au plus pour le titre, 155 pour la description : au-dela, le
    # moteur de recherche coupe (10 octobre : 71 et 168)
    titre = f"{u['titre'].replace('Call of Duty: ', 'CoD ')} PC : précommande, prix, date de sortie"
    desc = (f"{u['titre']} sort le {u['sortie_texte']} sur PC. Prix de précommande Steam, prix comparés "
            f"et compte à rebours.")
    return gabarit(_STYLE[0], titre, desc, CHEMIN, ld, corps, rubrique="sorties")


_STYLE = [""]


def main(dossier) -> str:
    dossier = Path(dossier)
    accueil = (dossier / "index.html").read_text(encoding="utf-8")
    _STYLE[0] = re.search(r"<style>(.*?)</style>", accueil, re.S).group(1) + CSS
    u = dict(UNE)
    try:
        import json
        from gen_sorties import fiches
        for x in json.loads((dossier / "sorties.json").read_text(encoding="utf-8"))["sorties"]:
            if str(x.get("steam") or "") == UNE["appid"]:
                u["fiches"] = fiches(x)
    except (OSError, ValueError, KeyError):
        pass
    (dossier / f"{CHEMIN.strip('/')}.html").write_text(page(u), encoding="utf-8")
    plan = dossier / "sitemap.xml"
    x = plan.read_text(encoding="utf-8")
    if f"<loc>{SITE}{CHEMIN}</loc>" not in x:
        bloc = (f"  <url>\n    <loc>{SITE}{CHEMIN}</loc>\n    <lastmod>{dt.date.today().isoformat()}</lastmod>\n"
                f"    <changefreq>daily</changefreq>\n    <priority>0.9</priority>\n  </url>\n")
        x = x.replace("</urlset>", bloc + "</urlset>")
        plan.write_text(x, encoding="utf-8")
    print(f"page a la une : {CHEMIN}")
    return CHEMIN


if __name__ == "__main__":
    main(sys.argv[1])
