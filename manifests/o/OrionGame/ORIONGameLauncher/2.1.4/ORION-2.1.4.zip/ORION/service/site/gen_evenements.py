"""Pages d'entree du referencement (11 octobre 2026, « mettre le paquet pour
le referencement du site ») :

* `/sorties/<jeu>` : une page par grosse sortie (« <jeu> date de sortie »,
  « <jeu> PC », « <jeu> prix »), tiree de la liste de l'application
  (`orion/sorties.py`, par `sorties.json`) : date officielle et sa source,
  plateformes, prix et boutiques, questions frequentes. Rien n'est invente :
  un champ absent de la liste n'apparait pas.
* `/gta-6-pc` : « GTA 6 PC », la recherche de l'annee. Ce qui est officiel,
  et ce que l'histoire de Rockstar permet de dire, sans date inventee.
* `/black-friday` : « Black Friday jeux PC 2026 ». Comment reconnaitre une
  vraie baisse ; le comparateur sur les jeux les plus suivis.
* `/gratuits` : « jeux PC gratuits cette semaine », lus sur le service
  (`api.orion-launcher.com/gratuits`), avec les sources si le service ne
  repond pas.

Usage : python gen_evenements.py <dossier du site>   (apres gen_sorties.py)
"""
from __future__ import annotations

import datetime as dt
import json
import re
import sys
from html import escape
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gen_jeux import DESC_MAX, SITE, TITRE_MAX, ajuste, de, gabarit, slug  # noqa: E402
from gen_sorties import MOIS, PLATEFORMES, boutiques, chemin_fiche, fr  # noqa: E402


def e(t) -> str:
    return escape(str(t or ""), quote=True)


SERVICE = "https://api.orion-launcher.com"

CSS = """
.ev{max-width:880px;margin:0 auto;padding:40px 20px 70px}
.ev h1{font-size:clamp(28px,4.4vw,44px);line-height:1.1;margin:.2em 0 .3em}
.ev h2{margin-top:38px}
.ev .chapo{color:var(--dim,#AAB4C8);font-size:17px}
.ev .fil{font-size:13px;color:var(--dim,#AAB4C8)}
.ev .fil a{color:inherit}
.decompte{display:flex;gap:10px;margin:22px 0 26px;flex-wrap:wrap}
.decompte div{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.14);border-radius:14px;
  padding:12px 16px;min-width:78px;text-align:center}
.decompte b{display:block;font-size:34px;line-height:1}
.decompte span{font-size:11px;letter-spacing:.14em;color:var(--dim,#AAB4C8)}
.fiche-tab{width:100%;border-collapse:collapse;margin:14px 0}
.fiche-tab th{text-align:left;font-weight:600;color:var(--dim,#AAB4C8);width:34%;padding:8px 0;
  border-bottom:1px solid rgba(255,255,255,.08)}
.fiche-tab td{padding:8px 0;border-bottom:1px solid rgba(255,255,255,.08)}
.faq details{border-bottom:1px solid rgba(255,255,255,.08);padding:10px 0}
.faq summary{cursor:pointer;font-weight:600}
.autres{display:flex;flex-wrap:wrap;gap:8px 14px;margin:12px 0}
.petit{font-size:13px;color:var(--dim,#AAB4C8)}
.liste-gratuits{display:grid;gap:12px;margin:16px 0}
.gratuit{border:1px solid rgba(255,255,255,.14);border-radius:14px;padding:14px 16px}
.gratuit b{display:block;font-size:17px}
.gratuit span{color:var(--dim,#AAB4C8);font-size:14px}
.gratuit.vise{border-color:#FF9F43;box-shadow:0 0 0 2px rgba(255,159,67,.35)}
"""

DECOMPTE_JS = """<script>
(function () {
  "use strict";
  var d = document.getElementById("decompte");
  if (!d) { return; }
  var fin = new Date(d.getAttribute("data-sortie")).getTime();
  function tic() {
    var s = Math.floor((fin - Date.now()) / 1000);
    if (s <= 0) { d.innerHTML = "<div><b>Disponible</b><span>MAINTENANT</span></div>"; return; }
    var j = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60), x = s % 60;
    d.innerHTML = [[j, "JOURS"], [h, "HEURES"], [m, "MINUTES"], [x, "SECONDES"]].map(function (v) {
      return "<div><b>" + v[0] + "</b><span>" + v[1] + "</span></div>"; }).join("");
    setTimeout(tic, 1000);
  }
  tic();
})();
</script>"""


def date_fr(d: dt.date) -> str:
    return f"{d.day}{'er' if d.day == 1 else ''} {MOIS[d.month - 1]} {d.year}"


def plats(s: dict) -> list[str]:
    return [PLATEFORMES.get(p, p) for p in (s.get("plateformes") or [])]


def fil_ariane(nom: str, chemin: str) -> dict:
    return {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [
        {"@type": "ListItem", "position": 1, "name": "ORION", "item": SITE + "/"},
        {"@type": "ListItem", "position": 2, "name": "Sorties", "item": SITE + "/sorties"},
        {"@type": "ListItem", "position": 3, "name": nom, "item": SITE + chemin}]}


def faq_ld(questions: list[tuple[str, str]]) -> dict:
    return {"@context": "https://schema.org", "@type": "FAQPage", "mainEntity": [
        {"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": r}}
        for q, r in questions]}


def faq_html(questions: list[tuple[str, str]]) -> str:
    return "".join(f"<details><summary>{e(q)}</summary><p>{e(r)}</p></details>" for q, r in questions)


# --------------------------------------------------------------------------
# Une page par sortie
# --------------------------------------------------------------------------

def page_sortie(s: dict, autres: list[dict], auj: dt.date, style: str) -> str:
    nom = s["titre"]
    chemin = chemin_fiche(s)
    d = dt.date.fromisoformat(s["date"]) if s.get("date") else None
    p = plats(s)
    sur_pc = "pc" in (s.get("plateformes") or [])
    fenetre = fr(s.get("fenetre", "")) if not d else ""
    if d:
        chapo = (f"{'Sortie' if d >= auj else 'Sorti'} le {date_fr(d)}"
                 + (f" sur {', '.join(p)}" if p else "") + (f" · {s['studio']}" if s.get("studio") else ""))
    else:
        chapo = ("Date pas encore annoncée par l'éditeur" + (f" ({fenetre})" if fenetre else "")
                 + (f" · {', '.join(p)}" if p else "") + (f" · {s['studio']}" if s.get("studio") else ""))
    lignes = [("Date de sortie", date_fr(d) if d else ("Non annoncée" + (f" ({fenetre})" if fenetre else ""))),
              ("Plateformes", ", ".join(p) if p else "À confirmer par l'éditeur"),
              ("Studio", s.get("studio", "")), ("Genre", fr(s.get("genre", "")))]
    tableau = "".join(f"<tr><th>{e(k)}</th><td>{e(v)}</td></tr>" for k, v in lignes if v)
    questions = [(f"Quand sort {nom} ?",
                  (f"{nom} sort le {date_fr(d)}" + (f" sur {', '.join(p)}." if p else ".")) if d and d >= auj
                  else (f"{nom} est sorti le {date_fr(d)}." if d else
                        f"L'éditeur n'a pas encore annoncé de date" + (f" (période annoncée : {fenetre})." if fenetre else "."))),
                 (f"{nom} sort-il sur PC ?",
                  (f"Oui, {nom} est annoncé sur PC." if sur_pc else
                   f"Aucune version PC {de(nom)} n'est annoncée pour l'instant" + (f" : le jeu est prévu sur {', '.join(p)}." if p else "."))),
                 ]
    if sur_pc:
        questions.append((f"Mon PC fera-t-il tourner {nom} ?",
                          f"ORION, gratuit, lit votre processeur, votre carte graphique et votre écran, puis vous dit "
                          f"le niveau de graphismes et les images par seconde à attendre dès que la configuration "
                          f"{de(nom)} est publiée."))
    # sur sa propre page, le comparateur se charge seul (sur /sorties, au clic)
    prix = boutiques(s).replace("data-comparatif", 'data-comparatif data-auto="1"', 1)
    bloc_prix = (f"<h2>Prix et boutiques</h2>\n{prix}\n<p class=\"petit\">Boutiques officielles d'abord, puis, à part, "
                 f"les revendeurs de clés agréés. Prix des boutiques : données IsThereAnyDeal.</p>") if prix else ""
    if sur_pc:
        bloc_pc = (f"<h2>Votre PC le fera-t-il tourner ?</h2><p>ORION lit votre PC et, dès que l'éditeur publie la "
                   f"configuration {e(de(nom))}, vous dit le niveau de graphismes et les images par seconde attendus, "
                   f"avec le réglage prêt pour le jour de la sortie. Gratuit, sans compte.</p>"
                   f"<p><a class=\"btn\" href=\"/#installer\">Télécharger ORION</a></p>")
    elif s.get("id") == "gta-6":
        bloc_pc = ("<h2>Et sur PC ?</h2><p>Aucune version PC n'est annoncée. Ce que l'on sait, et ce que "
                   "l'histoire de Rockstar permet d'attendre : <a href=\"/gta-6-pc\">GTA 6 sur PC</a>.</p>")
    else:
        bloc_pc = ""
    sources = [(n, u) for n, u in (("Site officiel", s.get("lien")), ("Source de la date", s.get("source")))
               if str(u or "").startswith("https://")]
    sources_html = " · ".join(f'<a href="{e(u)}" rel="noopener">{e(n)}</a>' for n, u in sources)
    autres_html = "".join(f'<a href="{e(chemin_fiche(x))}">{e(x["titre"])}</a>' for x in autres)
    decompte = (f'<div class="decompte" id="decompte" data-sortie="{d.isoformat()}T00:00:00" aria-live="polite"></div>'
                if d and d >= auj else "")
    corps = f"""
<section class="ev">
  <p class="fil"><a href="/">ORION</a> › <a href="/sorties">Sorties</a> › {e(nom)}</p>
  <h1>{e(nom)} : date de sortie, plateformes et prix</h1>
  <p class="chapo">{e(chapo)}.</p>
  {decompte}
  <table class="fiche-tab">{tableau}</table>
  {bloc_prix}
  {bloc_pc}
  <h2>Questions fréquentes</h2>
  <div class="faq">{faq_html(questions)}</div>
  <h2>Les autres sorties à venir</h2>
  <div class="autres">{autres_html}<a href="/sorties">Tout le calendrier</a></div>
  <p class="petit">{"Sources : " + sources_html + ". " if sources_html else ""}Date annoncée par l'éditeur ;
    la page est mise à jour avec la liste des sorties d'ORION.</p>
</section>
<script src="/clic.js" defer></script>
<script src="/comparatif.js" defer></script>
{DECOMPTE_JS if decompte else ""}
"""
    jeu = {"@context": "https://schema.org", "@type": "VideoGame", "name": nom, "url": SITE + chemin,
           "gamePlatform": p or None, "genre": fr(s.get("genre", "")) or None}
    if s.get("studio"):
        jeu["author"] = {"@type": "Organization", "name": s["studio"]}
    if d:
        jeu["datePublished"] = d.isoformat()
    jeu = {k: v for k, v in jeu.items() if v}
    ld = [jeu, fil_ariane(nom, chemin), faq_ld(questions)]
    court = re.sub(r"^Call of Duty: ", "CoD ", nom)
    titre = ajuste([f"{nom} : date de sortie, plateformes et prix",
                    f"{nom} : date de sortie et prix", f"{court} : date de sortie et prix",
                    f"{court} : date de sortie", court], TITRE_MAX)
    if d:
        quand_desc = f"sort le {date_fr(d)}" if d >= auj else f"est sorti le {date_fr(d)}"
    else:
        quand_desc = "n'a pas encore de date" + (f" ({fenetre})" if fenetre else "")
    desc = ajuste([f"{nom} {quand_desc}" + (f" sur {', '.join(p)}" if p else "")
                   + ". Prix, boutiques, compte à rebours et réponses aux questions fréquentes.",
                   f"{nom} {quand_desc}" + (f" sur {', '.join(p)}" if p else "") + ". Prix et compte à rebours.",
                   f"{nom} {quand_desc}. Prix et compte à rebours."], DESC_MAX)
    return gabarit(style, titre, desc, chemin, ld, corps, rubrique="sorties")


# --------------------------------------------------------------------------
# GTA 6 PC
# --------------------------------------------------------------------------

def page_gta(s: dict | None, auj: dt.date, style: str) -> str:
    chemin = "/gta-6-pc"
    d = dt.date.fromisoformat(s["date"]) if s and s.get("date") else None
    p = ", ".join(plats(s)) if s else "PS5, Xbox Series"
    officiel = (s or {}).get("lien") or "https://www.rockstargames.com/VI"
    source = (s or {}).get("source", "")
    date_txt = date_fr(d) if d else "date à confirmer"
    questions = [
        ("GTA 6 sort-il sur PC ?",
         f"Pas pour l'instant : au {date_fr(auj)}, Rockstar n'a annoncé GTA VI que sur {p}. Aucune version PC "
         f"n'est officielle, ni datée."),
        ("Quand sort GTA 6 ?", f"Sur consoles le {date_txt} ({p}), selon Rockstar Games."),
        ("Quand GTA 6 pourrait-il arriver sur PC ?",
         "Rockstar n'a rien annoncé. Pour mémoire, GTA V est sorti sur consoles le 17 septembre 2013 et sur PC "
         "le 14 avril 2015, environ dix-neuf mois plus tard ; Red Dead Redemption 2, le 26 octobre 2018 sur "
         "consoles et le 5 novembre 2019 sur PC, environ un an plus tard. Ce sont des précédents, pas une date."),
        ("Quelle configuration faudra-t-il pour GTA 6 sur PC ?",
         "Aucune configuration n'est publiée, puisqu'aucune version PC n'est annoncée. Méfiez-vous des "
         "« configurations requises » qui circulent : elles sont inventées. ORION lira la configuration "
         "officielle le jour de sa publication et vous dira ce que votre PC en fera."),
    ]
    decompte = (f'<div class="decompte" id="decompte" data-sortie="{d.isoformat()}T00:00:00" aria-live="polite"></div>'
                if d and d >= auj else "")
    sources = [("Site officiel de Rockstar", officiel)] + ([("Source de la date", source)] if source.startswith("https://") else [])
    sources_html = " · ".join(f'<a href="{e(u)}" rel="noopener">{e(n)}</a>' for n, u in sources)
    fiche = f'<a href="{e(chemin_fiche(s))}">la fiche de la sortie</a>' if s else '<a href="/sorties">les sorties</a>'
    corps = f"""
<section class="ev">
  <p class="fil"><a href="/">ORION</a> › <a href="/sorties">Sorties</a> › GTA 6 sur PC</p>
  <h1>GTA 6 sur PC : ce qui est officiel, et ce qu'on peut attendre</h1>
  <p class="chapo">GTA VI sort le {e(date_txt)} sur {e(p)}. Au {e(date_fr(auj))}, aucune version PC n'est annoncée.</p>
  {decompte}
  <h2>Ce qui est officiel</h2>
  <table class="fiche-tab">
    <tr><th>Sortie sur consoles</th><td>{e(date_txt)} ({e(p)})</td></tr>
    <tr><th>Version PC</th><td>Pas annoncée</td></tr>
    <tr><th>Configuration PC</th><td>Pas publiée</td></tr>
  </table>
  <h2>Ce que dit l'histoire de Rockstar</h2>
  <p>Rockstar sort ses grands jeux d'abord sur consoles. <b>GTA V</b> : consoles le 17 septembre 2013, PC le
    14 avril 2015. <b>Red Dead Redemption 2</b> : consoles le 26 octobre 2018, PC le 5 novembre 2019. Entre un
    et deux ans d'écart, donc. Ce sont des précédents, pas une promesse : la date de GTA VI sur PC ne sera
    connue que lorsque Rockstar l'annoncera.</p>
  <h2>En attendant, sur PC</h2>
  <p>Les jeux en monde ouvert les plus proches tournent déjà sur PC : leur configuration et ce que votre carte
    graphique en fait sont dans <a href="/jeux">les configurations des jeux</a>, et le jour où GTA VI sera
    annoncé sur PC, ORION lira sa configuration officielle et vous dira ce que <b>votre</b> PC en fera.</p>
  <p><a class="btn" href="/#installer">Télécharger ORION, gratuit</a></p>
  <h2>Questions fréquentes</h2>
  <div class="faq">{faq_html(questions)}</div>
  <p class="petit">Sources : {sources_html}. Voir aussi {fiche} et <a href="/sorties">tout le calendrier</a>.
    Page mise à jour dès qu'une annonce officielle change la donne.</p>
</section>
{DECOMPTE_JS if decompte else ""}
"""
    ld = [{"@context": "https://schema.org", "@type": "Article", "headline": "GTA 6 sur PC : ce qui est officiel",
           "datePublished": "2026-10-11", "dateModified": auj.isoformat(),
           "author": {"@type": "Organization", "name": "ORION Game Launcher"},
           "mainEntityOfPage": SITE + chemin},
          fil_ariane("GTA 6 sur PC", chemin), faq_ld(questions)]
    return gabarit(style, "GTA 6 PC : date, version PC et configuration",
                   ajuste([f"GTA 6 sur PC : aucune version annoncée au {date_fr(auj)}. Date consoles, précédents "
                           f"de Rockstar et configuration : ce qui est officiel.",
                           "GTA 6 sur PC : ce qui est officiel, les précédents de Rockstar et la configuration."],
                          DESC_MAX),
                   chemin, ld, corps, rubrique="sorties")


# --------------------------------------------------------------------------
# Black Friday
# --------------------------------------------------------------------------

def black_friday(annee: int) -> dt.date:
    """Le lendemain du quatrieme jeudi de novembre."""
    d = dt.date(annee, 11, 1)
    jeudis = [d + dt.timedelta(days=i) for i in range(30) if (d + dt.timedelta(days=i)).weekday() == 3]
    return jeudis[3] + dt.timedelta(days=1)


def page_black_friday(jeux: list[dict], auj: dt.date, style: str) -> str:
    chemin = "/black-friday"
    annee = auj.year if auj <= black_friday(auj.year) + dt.timedelta(days=4) else auj.year + 1
    bf = black_friday(annee)
    cartes = "".join(
        f'<h3><a href="/jeux/{e(j["slug"])}">{e(j["nom"])}</a></h3>'
        f'<div data-comparatif data-appid="{e(j["appid"])}" data-titre="{e(j["nom"])}"></div>'
        for j in jeux[:8])
    # Steam (13 octobre) : « chaque annee a la meme periode » etait faux en
    # 2026 (soldes d'automne avancees au 1er octobre) ; le calendrier le dit
    import soldes_steam
    steam = soldes_steam.au_black_friday(bf)
    automne = f"Soldes d'automne {annee}"
    if steam:
        mot_steam = f"et Steam tient ses {soldes_steam.minuscule(steam[0])} {soldes_steam.periode(steam[1], steam[2])}."
    elif automne in soldes_steam.PAS_ANNONCEES:
        mot_steam = f"et Steam n'a pas encore annoncé la date de ses soldes d'automne {annee}."
    else:
        avant, suite = soldes_steam.nommee(automne), soldes_steam.prochaine(bf)
        mot_steam = ("mais Steam n'a pas de soldes cette semaine-là"
                     + (f" : ses soldes d'automne ont eu lieu {soldes_steam.periode(avant[1], avant[2])}"
                        if avant else "")
                     + (f", les suivantes commencent le {date_fr(suite[1])}." if suite else "."))
    questions = [
        (f"Quand a lieu le Black Friday {annee} ?",
         f"Le vendredi {date_fr(bf)}. Beaucoup de boutiques commencent leurs promotions quelques jours avant, "
         + mot_steam),
        ("Comment savoir si une promotion est vraiment intéressante ?",
         "Comparez au plus bas prix jamais relevé pour ce jeu : ORION l'affiche à côté de chaque prix (données "
         "IsThereAnyDeal). Un « -60 % » au-dessus de ce plus bas n'est pas une affaire."),
        ("Les clés moins chères des revendeurs sont-elles sûres ?",
         "Prenez une clé du jeu lui-même, pour PC, région Global ou Europe, jamais un « Gift » ni un « Account ». "
         "ORION montre toujours les boutiques officielles en premier."),
    ]
    corps = f"""
<section class="ev">
  <p class="fil"><a href="/">ORION</a> › Black Friday {annee}</p>
  <h1>Black Friday {annee} jeux PC : les vrais prix</h1>
  <p class="chapo">Le Black Friday {annee} tombe le {e(date_fr(bf))}. Ici, pas de compte à rebours ni de
    « dernière chance » : le prix du jour dans les boutiques officielles, comparé au plus bas jamais relevé.</p>
  <h2>Avant d'acheter : trois réflexes</h2>
  <p><b>1. Le plus bas historique.</b> Une remise ne vaut que comparée au plus bas prix jamais vu pour ce jeu.
    <b>2. Les boutiques officielles d'abord.</b> Steam, GOG, Epic, et les revendeurs agréés (Gamesplanet,
    Fanatical, Humble…) vendent des clés fournies par les éditeurs. <b>3. Une clé du jeu lui-même.</b> Pas
    d'édition « Gift » ni de compte partagé chez les revendeurs de clés.</p>
  <h2>Les prix du jour sur les jeux les plus suivis</h2>
  <p class="petit">Prix relus à l'ouverture de la page. Données IsThereAnyDeal.</p>
  {cartes}
  <p>Pour suivre vos propres envies et être prévenu d'une vraie baisse : <a href="/#installer">ORION</a>,
    gratuit, alerte quand le prix passe sous votre seuil. Les dates des soldes de Steam :
    <a href="/soldes-steam">prochaines soldes Steam</a> ; les promos du jour : <a href="/bons-plans">bons plans</a>.</p>
  <h2>Questions fréquentes</h2>
  <div class="faq">{faq_html(questions)}</div>
</section>
<script src="/clic.js" defer></script>
<script src="/comparatif.js" defer></script>
"""
    ld = [{"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [
              {"@type": "ListItem", "position": 1, "name": "ORION", "item": SITE + "/"},
              {"@type": "ListItem", "position": 2, "name": f"Black Friday {annee}", "item": SITE + chemin}]},
          faq_ld(questions)]
    return gabarit(style, f"Black Friday {annee} jeux PC : les vrais prix",
                   f"Black Friday {annee} le {date_fr(bf)} : prix des jeux PC dans les boutiques officielles, "
                   f"comparés au plus bas jamais relevé. Sans fausse urgence.", chemin, ld, corps, rubrique="jeux")


# --------------------------------------------------------------------------
# Jeux gratuits
# --------------------------------------------------------------------------

GRATUITS_JS = """<script>
(function () {
  "use strict";
  var bloc = document.getElementById("gratuits");
  if (!bloc || !window.fetch) { return; }
  function t(x) { var d = document.createElement("div"); d.textContent = x == null ? "" : String(x); return d.innerHTML; }
  // meme ancre que le flux RSS du service (ancreGratuit, worker.js)
  function ancre(x) {
    return String(x || "").normalize("NFD").replace(/[\\u0300-\\u036f]/g, "").toLowerCase()
      .replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80);
  }
  function fin(iso) {
    if (!iso) { return ""; }
    var d = new Date(iso); if (isNaN(d)) { return ""; }
    return "jusqu'au " + d.toLocaleDateString("fr-FR", {day: "numeric", month: "long"});
  }
  fetch("%SERVICE%/gratuits", {cache: "no-store"}).then(function (r) { return r.ok ? r.json() : null; })
    .then(function (j) {
      var l = (j && j.jeux) || [];
      if (!l.length) { return; }
      bloc.innerHTML = l.map(function (g) {
        var lien = /^https:\\/\\//.test(g.url || "") ? g.url : "";
        return '<div class="gratuit" id="' + t(ancre(g.titre)) + '"><b>' + (lien ? '<a href="' + t(lien) + '" rel="noopener nofollow" data-boutique="' +
          t(g.boutique) + '">' + t(g.titre) + '</a>' : t(g.titre)) + '</b><span>' + t(g.boutique) +
          (g.fin ? " · " + t(fin(g.fin)) : "") + (g.valeur ? " · valeur " + t(g.valeur) : "") + '</span></div>';
      }).join("");
      var m = document.getElementById("gratuits-maj");
      if (m && j.releve) { m.textContent = "Liste relevée le " + new Date(j.releve * 1000).toLocaleString("fr-FR") + "."; }
      var vise = location.hash ? document.getElementById(decodeURIComponent(location.hash.slice(1))) : null;
      if (vise) { vise.classList.add("vise"); vise.scrollIntoView({block: "center"}); }
    }).catch(function () {});
})();
</script>"""


def page_gratuits(auj: dt.date, style: str) -> str:
    chemin = "/gratuits"
    questions = [
        ("Ces jeux sont-ils vraiment gratuits ?",
         "Oui : ce sont des offres des boutiques elles-mêmes (Epic Games Store, Steam, GOG…). Un jeu récupéré "
         "pendant l'offre reste à vous, sauf mention contraire (week-end gratuit, essai)."),
        ("Combien de temps dure une offre ?",
         "Souvent une semaine chez Epic (renouvelée chaque jeudi), quelques jours ailleurs. La date de fin est "
         "indiquée à côté de chaque jeu quand la boutique la donne."),
        ("Comment ne plus en rater ?",
         "ORION, gratuit, surveille ces offres et prévient dès qu'un jeu devient gratuit, en distinguant ce qui "
         "se garde à vie de ce qui s'arrête."),
    ]
    corps = f"""
<section class="ev">
  <p class="fil"><a href="/">ORION</a> › Jeux PC gratuits</p>
  <h1>Jeux PC gratuits cette semaine</h1>
  <p class="chapo">Les jeux offerts en ce moment sur Epic Games Store, Steam, GOG et les autres boutiques
    officielles, à récupérer et à garder.</p>
  <div class="liste-gratuits" id="gratuits">
    <p>La liste se charge… Sinon, les offres du moment sont sur
      <a href="https://store.epicgames.com/fr/free-games" rel="noopener nofollow">Epic Games Store</a>,
      <a href="https://store.steampowered.com/search/?maxprice=free&amp;specials=1" rel="noopener nofollow">Steam</a>
      et <a href="https://www.gog.com/fr/partner/free_games" rel="noopener nofollow">GOG</a>.</p>
  </div>
  <p class="petit" id="gratuits-maj"></p>
  <p>Pour être prévenu de chaque nouveau jeu gratuit : <a href="/#installer">ORION</a>, gratuit, sans compte.
    Ou le <a href="https://api.orion-launcher.com/gratuits.rss" type="application/rss+xml">flux RSS des jeux gratuits</a>,
    pour votre lecteur de flux ou votre serveur Discord (MonitoRSS et les autres robots de flux).</p>
  <h2>Questions fréquentes</h2>
  <div class="faq">{faq_html(questions)}</div>
</section>
<script src="/clic.js" defer></script>
{GRATUITS_JS.replace("%SERVICE%", SERVICE)}
"""
    ld = [{"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [
              {"@type": "ListItem", "position": 1, "name": "ORION", "item": SITE + "/"},
              {"@type": "ListItem", "position": 2, "name": "Jeux PC gratuits", "item": SITE + chemin}]},
          faq_ld(questions)]
    return gabarit(style, "Jeux PC gratuits cette semaine : Epic, Steam, GOG",
                   "Les jeux PC offerts en ce moment sur Epic Games Store, Steam et GOG, avec leur date de fin. "
                   "À récupérer et à garder, liste à jour.", chemin, ld, corps, rubrique="jeux")


# --------------------------------------------------------------------------

def ajouter_plan(dossier: Path, chemins: list[tuple[str, str, str]]) -> None:
    plan = dossier / "sitemap.xml"
    x = plan.read_text(encoding="utf-8")
    auj = dt.date.today().isoformat()
    bloc = "".join(f"  <url>\n    <loc>{SITE}{c}</loc>\n    <lastmod>{auj}</lastmod>\n"
                   f"    <changefreq>{f}</changefreq>\n    <priority>{p}</priority>\n  </url>\n"
                   for c, f, p in chemins if f"<loc>{SITE}{c}</loc>" not in x)
    plan.write_text(x.replace("</urlset>", bloc + "</urlset>"), encoding="utf-8")


def main(dossier) -> list[str]:
    dossier = Path(dossier)
    accueil = (dossier / "index.html").read_text(encoding="utf-8")
    style = re.search(r"<style>(.*?)</style>", accueil, re.S).group(1) + CSS
    auj = dt.date.today()
    sorties = json.loads((dossier / "sorties.json").read_text(encoding="utf-8"))["sorties"]
    a_venir = sorted((s for s in sorties if not s.get("date") or dt.date.fromisoformat(s["date"]) >= auj - dt.timedelta(days=30)),
                     key=lambda s: (s.get("date") or "9999", -int(s.get("attente") or 0)))
    faits = []
    (dossier / "sorties").mkdir(exist_ok=True)
    for s in a_venir:
        chemin = chemin_fiche(s)
        if not chemin.startswith("/sorties/"):
            continue                      # page dediee (Modern Warfare 4) : gen_une
        autres = [x for x in a_venir if x is not s][:8]
        (dossier / (chemin.strip("/") + ".html")).write_text(page_sortie(s, autres, auj, style), encoding="utf-8")
        faits.append((chemin, "weekly", "0.8"))
    gta = next((s for s in sorties if s.get("id") == "gta-6"), None)
    (dossier / "gta-6-pc.html").write_text(page_gta(gta, auj, style), encoding="utf-8")
    faits.append(("/gta-6-pc", "weekly", "0.9"))
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
    jeux = []
    # les jeux les plus suivis du catalogue ; l'identifiant Steam est relu sur
    # leur page de configuration (jamais recopie a la main)
    for nom in ("Cyberpunk 2077", "Baldur's Gate 3", "Elden Ring", "Red Dead Redemption 2", "Hogwarts Legacy",
                "Monster Hunter Wilds", "Battlefield 6", "Grand Theft Auto V Enhanced", "Grand Theft Auto V"):
        f = dossier / "jeux" / f"{slug(nom)}.html"
        m = re.search(r'data-appid="(\d+)"', f.read_text(encoding="utf-8")) if f.exists() else None
        if m and len(jeux) < 8:
            jeux.append({"nom": nom, "appid": m.group(1), "slug": slug(nom)})
    (dossier / "black-friday.html").write_text(page_black_friday(jeux, auj, style), encoding="utf-8")
    faits.append(("/black-friday", "daily", "0.8"))
    (dossier / "gratuits.html").write_text(page_gratuits(auj, style), encoding="utf-8")
    faits.append(("/gratuits", "daily", "0.9"))
    ajouter_plan(dossier, faits)
    print(f"pages d'entree : {len(faits)} ({', '.join(c for c, _f, _p in faits[-3:])}, "
          f"{len(faits) - 3} sorties)")
    return [c for c, _f, _p in faits]


if __name__ == "__main__":
    main(sys.argv[1])
