"""Essai du tableau de suivi dans un vrai navigateur, a la taille d'un telephone.

    python essai_tableau.py [dossier des captures]

Lance le service d'apercu (chiffres inventes), ouvre la page, verifie la cle
refusee, la cle juste, les tuiles, le fil horodate, les tris, et qu'un
signalement piege s'affiche comme du texte. GitHub est remplace par des
reponses d'essai : rien ne sort de la machine.
"""
import json
import os
import re
import subprocess
import sys
import time

from playwright.sync_api import sync_playwright

ICI = os.path.dirname(os.path.abspath(__file__))
PORT = 8798
CLE = "apercu-" + "a1b2c3d4e5" * 3
GITHUB = {
    "": {"stargazers_count": 12, "open_issues_count": 3},
    "/releases?per_page=100": [
        {"tag_name": "v2.0.0", "published_at": "2026-10-06T10:00:00Z",
         "assets": [{"name": "ORION-Setup.exe", "download_count": 41}, {"name": "x.txt", "download_count": 9}]},
        {"tag_name": "v1.9.8", "published_at": "2026-10-05T08:00:00Z",
         "assets": [{"name": "ORION-Setup.exe", "download_count": 230}]}],
    "/branches/donnees": {"commit": {"commit": {"committer": {"date": time.strftime(
        "%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - 3 * 3600))}}}},
    "/actions/runs?per_page=12": {"workflow_runs": [
        {"name": "Prix Gamesplanet", "status": "completed", "conclusion": "failure",
         "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - 1500))},
        {"name": "Prix Gamesplanet", "status": "completed", "conclusion": "success",
         "created_at": "2026-10-06T09:00:00Z"}]},
}


def main(captures: str = "") -> int:
    service = subprocess.Popen(["node", "--experimental-sqlite", "apercu_tableau.mjs", str(PORT)],
                               cwd=ICI, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
    try:
        assert "Tableau d'essai" in service.stdout.readline()
        with sync_playwright() as p:
            nav = p.chromium.launch()
            page = nav.new_page(viewport={"width": 412, "height": 915}, device_scale_factor=2,
                                locale="fr-FR", timezone_id="Europe/Paris")
            erreurs: list[str] = []
            page.on("pageerror", lambda e: erreurs.append(str(e)))
            page.on("console", lambda m: erreurs.append(m.text) if m.type == "error" else None)
            base = "https://api.github.com/repos/Sikher-kisa/orion-game-launcher"
            page.route("https://api.github.com/**", lambda r: r.fulfill(
                status=200, content_type="application/json",
                headers={"access-control-allow-origin": "*"},
                body=json.dumps(GITHUB[r.request.url[len(base):]])))
            page.goto(f"http://127.0.0.1:{PORT}/tableau")
            # sans cle : l'entree, aucun chiffre
            page.wait_for_selector("#entree:not([hidden])")
            assert page.is_hidden("#tableau")
            # tirage d'une cle : quarante caracteres, differents a chaque fois
            page.click("#tirer")
            a = page.input_value("#neuve")
            page.click("#tirer")
            assert re.fullmatch(r"[A-Za-z2-9]{40}", a) and a != page.input_value("#neuve")
            # cle fausse : refusee, et oubliee
            page.fill("#cle", "mauvaise-cle-" + "z" * 20)
            page.click("#entrer")
            page.wait_for_selector("#refus:not([hidden])")
            assert "refus" in page.inner_text("#refus").lower()
            assert page.evaluate("localStorage.getItem('orion.suivi.cle')") is None
            erreurs.clear()                                   # le 401 attendu
            if captures:
                page.screenshot(path=os.path.join(captures, "tableau-entree.png"))
            # cle juste
            page.fill("#cle", CLE)
            page.click("#entrer")
            page.wait_for_selector("#tableau:not([hidden])")
            page.wait_for_selector("#github .ligne")
            tuiles = page.locator("#tuiles .tuile b").all_inner_texts()
            # 16 octobre : neuf tuiles, les clics du site a part de ceux d'ORION
            assert len(tuiles) == 9 and int(tuiles[0]) > 5 and int(tuiles[8]) == 2, tuiles
            # telechargements : total lu sur GitHub (41 + 230), ecarts tires des releves du service
            assert tuiles[6] == "271" and tuiles[7] == "+80", tuiles
            sous = page.locator("#tuiles .tuile em").all_inner_texts()
            assert sous[6] == "aujourd'hui : +50" and sous[7].startswith("depuis le ") and sous[7].endswith("+145"), sous
            titres = page.locator("#tuiles .tuile i").all_inner_texts()
            assert titres[3].startswith("Clics boutiques depuis ORION") and titres[5].startswith("Clics boutiques depuis le site"), titres
            assert "Télécharger" in sous[5], sous
            assert page.locator("#dl-jours div").count() == 14
            jours = [d.get_attribute("title") for d in page.locator("#dl-jours div").all()]
            assert jours[-1].endswith(" : 50") and jours[-2].endswith(" : 5"), jours
            versions = page.inner_text("#dl-versions")
            assert "ORION 2.0.0" in versions and "41" in versions and "230" in versions
            assert "271 en tout" in page.inner_text("#dl-total")
            assert "7 jours" in page.inner_text("#periodes .actif")
            # clics tries du plus au moins
            n = [int(x.replace("\u202f", "")) for x in page.locator("#clics .ligne .n").all_inner_texts()]
            assert n and n == sorted(n, reverse=True), n
            page.click("#tri button:has-text('Par boutique')")
            noms = page.locator("#clics .ligne .nom").all_inner_texts()
            assert len(noms) == len(set(noms)) and "Instant Gaming" in " ".join(noms), noms
            # fil : heures locales, filtre « Clics »
            # (juste apres minuit, heure du telephone, le dernier evenement date d'« hier »)
            assert page.locator("#fil .jour").first.inner_text().lower().startswith(("aujourd", "hier"))
            page.click("#filtres button:has-text('Clics')")
            lignes = page.locator("#fil .ligne .nom").all_inner_texts()
            assert lignes and all(l.startswith("Clic · ") for l in lignes), lignes[:3]
            assert re.fullmatch(r"\d\d:\d\d", page.locator("#fil .ligne .h").first.inner_text())
            assert page.locator("#heures div").count() == 48
            assert page.locator("#jours div").count() == 14
            # signalement piege : du texte, aucun element cree, titre intact
            assert page.locator("#bugs img, #bugs script").count() == 0
            assert "<img src=x" in page.inner_text("#bugs")
            # flux RSS : lectures par lecteur, abonnes annonces (le plus grand du jour, pas la somme)
            flux = page.inner_text("#flux")
            assert "MonitoRSS (robot Discord)" in flux and "40 lectures" in flux, flux
            assert "Feedly" in flux and "8 abonnés annoncés" in flux and "6 lectures" in flux, flux
            assert "47 lectures, 8 abonnés annoncés" in page.inner_text("#flux-total"), page.inner_text("#flux-total")
            assert page.title() == "ORION · Suivi"
            # alertes : signalements, relais vieux de trois heures, tache en echec
            alertes = page.inner_text("#alertes")
            assert "2 signalements" in alertes and "Relais" in alertes and "Prix Gamesplanet" in alertes, alertes
            assert "Workers AI" in alertes, alertes
            assert "12" in page.inner_text("#github")           # etoiles
            assert "3 réponses du service en échec" in alertes, alertes
            # service : echec compte, site et GitHub concordent, liaisons absentes dites
            sante = page.inner_text("#service")
            assert "3 en échec aujourd'hui" in page.inner_text("#service-etat")
            assert "concordent" in sante and "Prix d'un jeu · 503" in sante and "liaison AI absente" in sante, sante
            assert "base de données" in sante.lower()
            # fluidite : neuf sessions, la cause dominante en tete, par version
            fluidite = page.inner_text("#fluidite")
            assert "9 sessions" in page.inner_text("#fluidite-total")
            assert "boutique_view._rendre:2046" in fluidite and "free_view.__init__:111" in fluidite, fluidite
            assert fluidite.index("boutique_view") < fluidite.index("free_view")
            assert "ORION 2.0.1" in fluidite and "ORION 2.0.0" in fluidite
            assert "Démarrage" in fluidite and " s" in fluidite
            if captures:
                page.click("#filtres button:has-text('Tout')")
                page.click("#tri button:has-text('Les plus')")
                page.mouse.wheel(0, -20000)
                page.wait_for_timeout(300)
                page.screenshot(path=os.path.join(captures, "tableau-haut.png"))
                page.screenshot(path=os.path.join(captures, "tableau-entier.png"), full_page=True)
                page.locator("#flux").locator("xpath=..").screenshot(path=os.path.join(captures, "tableau-flux.png"))
            # lecture d'un signalement en entier
            page.locator("#bugs button").last.click()
            page.wait_for_selector("#feuille pre")
            assert "rapport d'exemple" in page.inner_text("#feuille")
            assert "heure de Paris" in page.inner_text("#feuille") and "à lire" in page.inner_text("#feuille")
            # marquer traite, avec une note : la seule ecriture du tableau
            page.fill("#feuille textarea", "Corrigé en 2.0.1")
            page.click("#feuille button:has-text('Marquer traité')")
            page.wait_for_selector("#feuille button:has-text('Rouvrir')")
            assert "Marqué traité" in page.inner_text("#feuille")
            page.click("#fermer")
            page.wait_for_selector("#tuiles .tuile:has-text('Signalements à lire') b:has-text('1')")
            assert "Note : Corrigé en 2.0.1" in page.inner_text("#bugs")
            assert "1 signalement à lire" in page.inner_text("#alertes")
            # periode : aujourd'hui
            page.click("#periodes button:has-text(\"Aujourd'hui\")")
            page.wait_for_selector("#periodes .actif:has-text(\"Aujourd'hui\")")
            assert "aujourd'hui" in page.locator("#tuiles .tuile i").nth(2).inner_text()
            # la cle est gardee sur l'appareil, et s'oublie sur demande
            page.reload()
            page.wait_for_selector("#tableau:not([hidden])")
            page.click("#oublier")
            page.wait_for_selector("#entree:not([hidden])")
            assert page.evaluate("localStorage.getItem('orion.suivi.cle')") is None
            assert not erreurs, erreurs
            nav.close()
    finally:
        service.terminate()
    print("tableau ok")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else ""))
