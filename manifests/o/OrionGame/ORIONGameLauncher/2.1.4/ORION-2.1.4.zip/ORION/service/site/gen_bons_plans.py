"""Pages « Bons plans » du site (13 octobre 2026, demande de l'auteur : une
zone bonnes affaires, sur les jeux tres recherches seulement, prix de base
barre et remise affichee, avec des sous-onglets).

Ce que la page montre, et d'ou ca vient :

* **les jeux** : ceux du catalogue du site (une page de configuration
  chacun), parmi les plus joues sur Steam (nombre d'avis). Jamais un jeu
  inconnu juste parce qu'il est brade ;
* **la promotion** : le releve de Gamesplanet (distributeur officiel,
  partenaire d'ORION ; releve toutes les vingt minutes sur la branche
  « donnees » du depot). Le prix barre et la remise sont ceux que
  Gamesplanet annonce lui-meme : jamais une remise calculee par ORION contre
  un autre prix ;
* **« Prix et boutiques »** sur chaque carte (`comparatif.js`, au clic,
  jamais pour toute la page d'un coup) : les boutiques officielles, Steam
  compris, la moins chere en tete (donnees IsThereAnyDeal), puis a part les
  revendeurs de cles (Kinguin, Loaded, Instant Gaming).

Classement : popularite du jeu et taille de la remise, jamais la commission.
Les liens vers Gamesplanet sont des liens partenaires (`rel="sponsored"`),
et la page le dit (article L111-7 du code de la consommation : un site qui
classe des offres dit comment, et s'il est remunere).

`bons-plans.js` relit le releve du jour chez le visiteur : un prix qui a
change est mis a jour, une promotion terminee disparait, et « l'affaire du
jour » change chaque jour parmi les meilleures. La liste elle-meme est
refaite a chaque mise en ligne du site.
"""
from __future__ import annotations

import datetime as dt
import math
import re
import unicodedata
from pathlib import Path

import gen_jeux as fr
from orion.affiliation import lien_site
from gen_jeux import SITE, ajuste, e, euros

#: en dessous, ce n'est pas un bon plan (Gamesplanet vend presque tout a -10 %)
REMISE_MIN = 30
#: « tres recherche » : au moins ce nombre d'avis sur Steam
AVIS_MIN = 1000
POPULAIRE = 5000
#: affaire du siecle : au moins -75 % sur un jeu populaire
SIECLE = 75
PETIT_PRIX = 10.0
#: cartes par page (au-dela, la page s'allonge sans rien apporter)
MAX_CARTES = 60
#: l'affaire du jour tourne parmi les meilleures
ROTATION = 8
#: extensions d'un meme jeu sur la page DLC
PAR_JEU = 3

ONGLETS = [
    ("/bons-plans", "Tous les bons plans"),
    ("/bons-plans/affaires-du-siecle", "Affaires du siècle"),
    ("/bons-plans/moins-de-10-euros", "Moins de 10 €"),
    ("/bons-plans/jeux-independants", "Jeux indés"),
    ("/bons-plans/dlc", "DLC et extensions"),
    ("/gratuits", "Jeux gratuits"),
]

#: une extension se reconnait a son nom ; jamais une bande-son ni un artbook
MOTS_DLC = re.compile(r"\b(season pass|expansion pass|expansion|extension|dlc|pass saisonnier|"
                      r"deluxe kit|pack|add-on)\b", re.I)
PAS_UN_DLC = re.compile(r"soundtrack|\bost\b|art ?book|wallpaper|bundle|collection|complete|"
                        r"edition|upgrade", re.I)
#: une suite (« Dead Rising 4 ») n'est pas une extension de « Dead Rising »
SUITE = re.compile(r"^(?:\d+|i{1,3}|iv|v|vi{0,3})\b", re.I)

CSS = """
  /* ---------- Bons plans (13 octobre) ---------- */
  .bp-onglets{display:flex;gap:8px;overflow-x:auto;padding:4px 0 10px;margin-top:22px;scrollbar-width:none;}
  .bp-onglets::-webkit-scrollbar{display:none;}
  .bp-onglets a{flex:0 0 auto;border:1px solid var(--line);border-radius:999px;padding:8px 15px;font-size:14.5px;color:var(--ink);text-decoration:none;background:var(--panel);}
  .bp-onglets a[aria-current]{background:var(--accent);border-color:var(--accent);color:#0B0F1A;font-weight:700;}
  .bp-confiance{display:flex;flex-wrap:wrap;gap:8px 22px;margin-top:16px;color:var(--dim);font-size:14px;}
  .bp-confiance span::before{content:"✓ ";color:#57D98A;font-weight:700;}
  .bp-une{display:grid;grid-template-columns:minmax(0,1.25fr) minmax(0,1fr);gap:0;margin-top:26px;background:var(--panel);border:1px solid var(--line-hi);border-radius:calc(var(--radius) + 4px);overflow:hidden;}
  .bp-une .bp-visuel img{display:block;width:100%;height:100%;object-fit:cover;aspect-ratio:460/215;}
  .bp-une .bp-corps{padding:24px 26px;display:grid;align-content:center;gap:10px;}
  .bp-une .bp-etiquette{font-size:13px;letter-spacing:.08em;text-transform:uppercase;color:var(--accent);font-weight:700;}
  .bp-une h2{font-size:clamp(24px,3.2vw,34px);line-height:1.1;}
  .bp-une .bp-final{font-size:44px;}
  .bp-grille{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:16px;margin-top:20px;}
  .bp-carte{position:relative;display:flex;flex-direction:column;background:var(--panel);border:1px solid var(--line);border-radius:var(--radius);overflow:hidden;transition:border-color .15s,transform .15s;}
  .bp-carte:hover{border-color:var(--line-hi);transform:translateY(-2px);}
  .bp-carte[hidden]{display:none;}
  .bp-visuel{position:relative;display:block;background:var(--line);}
  .bp-carte .bp-visuel img{display:block;width:100%;height:auto;aspect-ratio:460/215;object-fit:cover;}
  .bp-badge{position:absolute;top:10px;left:10px;background:#57D98A;color:#07130C;font-weight:800;font-size:16px;border-radius:8px;padding:4px 9px;font-variant-numeric:tabular-nums;box-shadow:0 2px 10px rgba(0,0,0,.35);}
  .bp-badge.fort{background:#FF9F43;}
  .bp-carte .bp-corps{display:flex;flex-direction:column;gap:6px;padding:14px 16px 16px;flex:1;}
  .bp-carte h3{font-size:16.5px;line-height:1.3;}
  .bp-carte h3 a,.bp-une h2 a{color:inherit;text-decoration:none;}
  .bp-avis{color:var(--dim);font-size:13.5px;}
  .bp-avis b{color:#57D98A;font-weight:700;}
  .bp-prix{display:flex;align-items:baseline;flex-wrap:wrap;gap:4px 10px;margin-top:auto;padding-top:6px;}
  .bp-normal{color:var(--dim);font-size:15px;text-decoration:line-through;font-variant-numeric:tabular-nums;}
  .bp-final{font-size:26px;font-weight:800;color:#57D98A;font-variant-numeric:tabular-nums;line-height:1;}
  .bp-eco{font-size:13.5px;color:var(--ink);}
  .bp-ou{font-size:13px;color:var(--dim);}
  .bp-requis{font-size:13px;color:var(--dim);}
  .bp-actions{display:flex;flex-wrap:wrap;align-items:center;gap:8px 14px;margin-top:8px;}
  .bp-actions .btn{padding:9px 16px;font-size:14.5px;}
  .bp-actions a.bp-config{font-size:14px;}
  .bp-carte [data-comparatif]{font-size:14px;}
  .bp-carte .cmp-tete{padding:12px 14px;}
  .bp-carte .cmp-tete b.cmp-prix{font-size:22px;}
  .bp-suite{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:12px;margin-top:18px;}
  .bp-suite a{display:block;background:var(--panel);border:1px solid var(--line);border-radius:var(--radius);padding:16px;color:inherit;text-decoration:none;}
  .bp-suite a b{display:block;font-size:17px;}
  .bp-suite a span{display:block;color:var(--dim);font-size:14px;margin-top:4px;}
  .bp-vide{color:var(--dim);margin-top:18px;}
  @media (max-width:760px){.bp-une{grid-template-columns:1fr;}.bp-une .bp-final{font-size:36px;}.bp-une .bp-corps{padding:18px;}}
"""


def plat(t: str) -> str:
    t = unicodedata.normalize("NFKD", t or "").encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", " ", t).strip()


def milliers(n: int) -> str:
    return f"{n:,}".replace(",", " ")


def score(remise: float, avis: int, positifs: int) -> float:
    """Popularite d'abord (on ne met en avant que des jeux tres recherches),
    puis la remise ; un jeu mal note descend."""
    note = (positifs or 80) / 100
    return math.log10(max(avis, 10)) * (0.35 + remise / 100) * (0.5 + note / 2)


def offres_du_jeu(jeux: list[dict]) -> list[dict]:
    """Les jeux du catalogue en promotion chez Gamesplanet."""
    vus = []
    for j in jeux:
        gp = j.get("gp")
        if not gp or j.get("gratuit") or j.get("avis", 0) < AVIS_MIN:
            continue
        if gp["remise"] < REMISE_MIN or not gp["normal"] or gp["prix"] >= gp["normal"]:
            continue
        vus.append({"appid": j["appid"], "nom": j["nom"], "page": f"/jeux/{j['slug']}",
                    "visuel": j["appid"], "avis": j["avis"], "positifs": j.get("positifs", 0),
                    "genres": j["genres"], "cites": j.get("cites") or [], "prix": gp["prix"],
                    "normal": gp["normal"], "remise": gp["remise"], "url": gp["url"],
                    "fiche": gp["slug"], "cle": gp["cle"], "base": None,
                    "score": score(gp["remise"], j["avis"], j.get("positifs", 0))})
    return sorted(vus, key=lambda o: -o["score"])


def extensions(jeux: list[dict], G) -> list[dict]:
    """Extensions en promotion des jeux tres joues : un produit Gamesplanet
    qui n'est pas un jeu du catalogue, dont le nom commence par celui d'un
    jeu populaire et qui se nomme comme une extension (« Season Pass »,
    « Expansion »...), ou, pour les plus grands jeux, « Jeu : Sous-titre »
    (Iceborne, Sunbreak). Jamais une suite, une bande-son ou une edition."""
    if G is None:
        return []
    from orion.affiliation import affilier
    nos = {j["appid"] for j in jeux}
    bases = sorted((j for j in jeux if j.get("avis", 0) >= POPULAIRE and not j.get("gratuit")),
                   key=lambda j: -len(plat(j["nom"])))
    vus, pris = [], set()
    for appid in G._memo["jeux"]:
        if appid in nos:
            continue
        for p in G._produits(appid, "FR"):
            if not (p["prix"] < p["normal"]):
                continue
            remise = int(round(100 - p["prix"] * 100 / p["normal"]))
            if remise < REMISE_MIN or PAS_UN_DLC.search(p["nom"]):
                continue
            nom = plat(p["nom"])
            for b in bases:
                bn = plat(b["nom"])
                if len(bn) < 4 or not nom.startswith(bn + " "):
                    continue
                reste = nom[len(bn):].strip()
                if SUITE.match(reste):
                    break                       # une suite, pas une extension
                sous_titre = re.match(rf"^{re.escape(b['nom'])}\s*[:\-–]\s*\S", p["nom"], re.I)
                if not (MOTS_DLC.search(p["nom"]) or (sous_titre and b["avis"] >= 50000)):
                    break
                if p["url"] in pris:
                    break
                pris.add(p["url"])
                vus.append({"appid": appid, "nom": p["nom"], "page": f"/jeux/{b['slug']}",
                            "visuel": b["appid"], "avis": b["avis"], "positifs": b.get("positifs", 0),
                            "genres": b["genres"], "cites": [], "prix": p["prix"], "normal": p["normal"],
                            "remise": remise, "url": affilier(p["url"]),
                            "fiche": p["url"].rsplit("/", 1)[1],
                            "cle": "Clé " + {"steam": "Steam"}.get(p["type"], p["type"].capitalize() or "PC"),
                            "base": b["nom"], "score": score(remise, b["avis"], b.get("positifs", 0))})
                break
    # pas une page de packs d'un seul jeu : trois extensions au plus par jeu
    gardes, par_jeu = [], {}
    for o in sorted(vus, key=lambda o: -o["score"]):
        par_jeu[o["base"]] = par_jeu.get(o["base"], 0) + 1
        if par_jeu[o["base"]] <= PAR_JEU:
            gardes.append(o)
    return gardes


def _bloc_prix(o: dict, classe_final: str = "bp-final") -> str:
    eco = o["normal"] - o["prix"]
    return f"""<p class="bp-prix"><s class="bp-normal">{euros(o["normal"])}</s><b class="{classe_final}">{euros(o["prix"])}</b></p>
        <p class="bp-eco">Vous économisez <b>{euros(eco)}</b></p>"""


def _avis(o: dict) -> str:
    if o["positifs"] >= 1 and o["avis"]:
        return (f'<p class="bp-avis"><b>{o["positifs"]} %</b> d\'avis positifs · '
                f'{milliers(o["avis"])} avis Steam</p>')
    return f'<p class="bp-avis">{milliers(o["avis"])} avis Steam</p>' if o["avis"] else ""


def _donnees(o: dict) -> str:
    """Ce que bons-plans.js relit chez le visiteur."""
    return (f'data-appid="{e(o["appid"])}" data-fiche="{e(o["fiche"])}" '
            f'data-score="{o["score"]:.4f}"')


def carte(o: dict, comparer: bool = True) -> str:
    img = fr.visuel(o["visuel"])
    fort = " fort" if o["remise"] >= SIECLE else ""
    comparateur = (f'<div data-comparatif data-appid="{e(o["appid"])}" data-titre="{e(o["nom"])}"></div>'
                   if comparer else "")
    requis = (f'<p class="bp-requis">Nécessite le jeu de base : <a href="{o["page"]}">{e(o["base"])}</a></p>'
              if o["base"] else "")
    config = "" if o["base"] else f'<a class="bp-config" href="{o["page"]}">Config requise</a>'
    if not o["base"] and o["cites"]:
        requis = f'<p class="bp-requis">Carte conseillée : {e(" ou ".join(o["cites"][:2]))}</p>'
    return f"""      <article class="bp-carte" {_donnees(o)}>
        <a class="bp-visuel" href="{e(lien_site(o["url"], "bons-plans"))}" rel="sponsored noopener" target="_blank" tabindex="-1" aria-hidden="true">{img}<span class="bp-badge{fort}">-{o["remise"]} %</span></a>
        <div class="bp-corps">
        <h3><a href="{e(lien_site(o["url"], "bons-plans"))}" rel="sponsored noopener" target="_blank">{e(o["nom"])}</a></h3>
        {_avis(o)}
        {requis}
        {_bloc_prix(o)}
        <p class="bp-ou">{e(o["cle"])} officielle · Gamesplanet</p>
        <div class="bp-actions"><a class="btn" href="{e(lien_site(o["url"], "bons-plans"))}" rel="sponsored noopener" target="_blank">Voir l'offre</a>{config}</div>
        {comparateur}
        </div>
      </article>"""


def une(o: dict) -> str:
    """L'affaire du jour : la meme offre, en grand."""
    img = fr.visuel(o["visuel"], "", "eager")
    return f"""  <section class="bp-une" id="bp-une" {_donnees(o)}>
    <a class="bp-visuel" href="{e(lien_site(o["url"], "bons-plans"))}" rel="sponsored noopener" target="_blank" tabindex="-1" aria-hidden="true">{img}<span class="bp-badge{" fort" if o["remise"] >= SIECLE else ""}">-{o["remise"]} %</span></a>
    <div class="bp-corps">
      <span class="bp-etiquette">L'affaire du jour</span>
      <h2><a href="{e(lien_site(o["url"], "bons-plans"))}" rel="sponsored noopener" target="_blank">{e(o["nom"])}</a></h2>
      {_avis(o)}
      {_bloc_prix(o)}
      <p class="bp-ou">{e(o["cle"])} officielle · Gamesplanet</p>
      <div class="bp-actions"><a class="btn" href="{e(lien_site(o["url"], "bons-plans"))}" rel="sponsored noopener" target="_blank">Voir l'offre chez Gamesplanet</a><a class="bp-config" href="{o["page"]}">Config requise</a></div>
    </div>
  </section>
"""


def onglets(courant: str) -> str:
    actif = ' aria-current="page"'
    liens = "".join(f'<a href="{c}"{actif if c == courant else ""}>{e(n)}</a>' for c, n in ONGLETS)
    return f'  <nav class="bp-onglets" aria-label="Rubriques des bons plans">{liens}</nav>\n'


def de_mois(d: dt.date) -> str:
    """« d'octobre 2026 », « de mars 2026 »."""
    m = fr.MOIS[d.month - 1]
    return ("d'" if m[0] in "aeiouéâ" else "de ") + f"{m} {d.year}"


def exemples(offres: list[dict], n: int = 2) -> str:
    """« Resident Evil 4 à 9,24 € (-77 %), Metro Exodus à 6,99 € (-77 %) »."""
    return ", ".join(f"{o['nom']} à {euros(o['prix'])} (-{o['remise']} %)" for o in offres[:n])


FAQ = [
    ("Ces promotions sont-elles fiables ?",
     "Oui. Les offres viennent de Gamesplanet, distributeur officiel des éditeurs : la clé est une clé "
     "officielle (Steam le plus souvent), le prix barré est celui que Gamesplanet affiche lui-même, et les "
     "prix sont relevés toutes les vingt minutes. Une promotion terminée disparaît de la page."),
    ("Steam est-il parfois moins cher ?",
     "Oui, surtout pendant ses soldes. Le bouton « Prix et boutiques » de chaque jeu compare Steam et les "
     "autres boutiques officielles, la moins chère en tête, avec les données IsThereAnyDeal."),
    ("Les revendeurs de clés sont-ils sûrs ?",
     "Kinguin, Loaded et Instant Gaming sont présentés à part, après les boutiques officielles. Prenez une "
     "clé Steam, région Global ou Europe, et jamais une offre « Gift » ni « Account »."),
    ("Le jeu tournera-t-il sur mon PC ?",
     f"Chaque jeu a sa page de configuration requise, avec les réglages à attendre de {fr.NB_CARTES} cartes "
     "graphiques en 1080p, 1440p et 4K. Le launcher gratuit ORION fait le calcul avec votre propre machine."),
    ("Quand trouve-t-on les plus grosses promos ?",
     "Pendant les soldes saisonnières de Steam et des boutiques (printemps, été, automne, hiver) et les "
     "promotions des éditeurs. Cette page suit les prix toute l'année, sans attendre les soldes."),
]


def faq_html(questions) -> str:
    return "".join(f"<details><summary>{e(q)}</summary><p>{e(r)}</p></details>" for q, r in questions)


def page(style, chemin, titre, desc, eyebrow, h1, lede, offres, releve, avant="", apres="",
         fil=None, vide="Aucune promotion de ce type en ce moment : revenez demain.", faq=None):
    from zoneinfo import ZoneInfo
    quand = dt.datetime.fromtimestamp(releve, ZoneInfo("Europe/Paris"))
    heure = f"{date_fr(quand.date())} à {quand.hour} h {quand.minute:02d}"
    fil_html = (f'<a href="/">ORION</a> › <a href="/bons-plans">Bons plans</a> › {e(fil)}' if fil
                else '<a href="/">ORION</a> › Bons plans')
    bloc_faq = (f"""  <section class="bloc">
    <p class="eyebrow">Questions fréquentes</p>
    <h2>Bons plans jeux PC : vos questions</h2>
    <div class="faq">{faq_html(faq)}</div>
  </section>
""" if faq else "")
    cartes = "\n".join(carte(o) for o in offres[:MAX_CARTES])
    grille = (f'  <div class="bp-grille" id="bp-liste">\n{cartes}\n  </div>' if offres
              else f'  <p class="bp-vide">{e(vide)}</p>')
    corps = f"""  <div class="tete">
    <p class="fil">{fil_html}</p>
    <p class="eyebrow">{e(eyebrow)}</p>
    <h1>{h1}</h1>
    <p class="lede">{lede}</p>
    <div class="bp-confiance"><span>Clés officielles</span><span>Prix vérifiés toutes les 20 minutes</span><span>Jeux parmi les plus joués sur Steam</span></div>
{onglets(chemin)}  </div>
{avant}  <section>
    <p class="bp-ou" id="bp-releve" data-releve="{releve}">Prix relevés chez Gamesplanet le {heure}.</p>
{grille}
  </section>
{apres}{bloc_faq}  <section class="bloc">
    <p class="eyebrow">Comment cette page est faite</p>
    <h2>Des jeux très joués, des remises annoncées par la boutique</h2>
    <p>Ne figurent ici que des jeux parmi les plus joués sur Steam (au moins
      {milliers(AVIS_MIN)} avis), remisés d'au moins {REMISE_MIN} % chez Gamesplanet, distributeur
      officiel des éditeurs. Le prix barré et la remise sont ceux que Gamesplanet affiche lui-même.
      Classement : la popularité du jeu, puis la taille de la remise et les avis des joueurs ;
      jamais la commission.</p>
    <p>« Prix et boutiques » compare, sur chaque jeu, les boutiques officielles (Steam compris,
      la moins chère en tête, données IsThereAnyDeal), puis à part les revendeurs de clés
      (Kinguin, Loaded, Instant Gaming) : prenez une clé Steam, région Global ou Europe, jamais
      d'offre « Gift » ni « Account ».</p>
    <p><small>Gamesplanet, Instant Gaming, Kinguin et Loaded sont des liens partenaires : un achat par
      ces liens rapporte une commission à ORION, sans changer le prix que vous payez. Le prix
      affiché par la boutique fait foi.</small></p>
  </section>
  <section class="bloc">
    <p class="eyebrow">ORION, le launcher</p>
    <h2>Les promos de votre liste d'envies, sur votre PC</h2>
    <p>ORION est un launcher gratuit pour Windows : il regroupe vos jeux de toutes les plateformes,
      surveille le prix des jeux de votre liste d'envies et vous prévient d'une baisse, et vous dit
      si le jeu tournera sur votre PC avant de l'acheter. Sans compte, sans publicité.</p>
    <div class="appel">
      <a class="btn" href="{fr.EXE}">Télécharger ORION pour Windows</a>
      <a class="btn ghost" href="/">Découvrir le launcher</a>
    </div>
  </section>
  <script src="/bons-plans.js" defer></script>"""
    miettes = [{"@type": "ListItem", "position": 1, "name": "ORION", "item": SITE + "/"},
               {"@type": "ListItem", "position": 2, "name": "Bons plans", "item": SITE + "/bons-plans"}]
    if fil:
        miettes.append({"@type": "ListItem", "position": 3, "name": fil, "item": SITE + chemin})
    ld = [{"@context": "https://schema.org", "@type": "ItemList", "name": fr.h1_texte(h1),
           "itemListElement": [{"@type": "ListItem", "position": i + 1, "name": o["nom"],
                                "url": SITE + o["page"]} for i, o in enumerate(offres[:MAX_CARTES])]},
          {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": miettes}]
    if faq:
        ld.append({"@context": "https://schema.org", "@type": "FAQPage", "mainEntity": [
            {"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": r}} for q, r in faq]})
    image = fr.image_og(offres[0]["visuel"]) if offres else ""
    return fr.gabarit(style + CSS, titre, desc, chemin, ld, corps, rubrique="bons-plans", image=image)


def date_fr(d) -> str:
    return fr.date_fr(d)


def suite(offres_par_page: dict) -> str:
    """Les autres rubriques, avec leur nombre d'offres."""
    liens = []
    for chemin, nom, phrase in (
            ("/bons-plans/affaires-du-siecle", "Affaires du siècle", "-75 % et plus sur des jeux très joués"),
            ("/bons-plans/moins-de-10-euros", "Moins de 10 €", "des jeux connus pour le prix d'un sandwich"),
            ("/bons-plans/jeux-independants", "Jeux indés", "les pépites indépendantes en promo"),
            ("/bons-plans/dlc", "DLC et extensions", "les extensions des grands jeux, remisées"),
            ("/gratuits", "Jeux gratuits", "à garder pour toujours, cette semaine")):
        n = offres_par_page.get(chemin)
        compte = f" · {n} offre{'s' if n > 1 else ''}" if n else ""
        liens.append(f'<a href="{chemin}"><b>{e(nom)}</b><span>{e(phrase)}{compte}</span></a>')
    return f"""  <section class="bloc">
    <p class="eyebrow">Toutes les rubriques</p>
    <h2>Encore plus de bons plans</h2>
    <div class="bp-suite">{"".join(liens)}</div>
  </section>
"""


BONS_PLANS_JS = r"""/* Bons plans : relit le releve Gamesplanet du jour chez le visiteur. Un prix
   qui a change est mis a jour, une promotion terminee (ou sous -30 %) est
   retiree, et l'affaire du jour change chaque jour parmi les meilleures.
   Aucune donnee du visiteur n'est envoyee. */
(function () {
  "use strict";
  if (!window.fetch) { return; }
  var REMISE_MIN = 30, ROTATION = 8, PERIME = 8 * 3600;
  var cartes = Array.prototype.slice.call(document.querySelectorAll(".bp-carte[data-appid]"));
  var une = document.getElementById("bp-une");
  if (!cartes.length && !une) { return; }
  function euros(v) { return v.toFixed(2).replace(".", ",") + " €"; }
  function ilYA(s) {
    var m = Math.max(0, Math.round(s / 60));
    return m < 2 ? "à l'instant" : m < 90 ? "il y a " + m + " minutes" : "il y a " + Math.round(m / 60) + " heures";
  }
  function produit(d, el) {
    var l = (d.jeux || {})[el.getAttribute("data-appid")] || [], fiche = el.getAttribute("data-fiche"), i;
    for (i = 0; i < l.length; i += 1) { if (l[i][3] === fiche) { return l[i]; } }
    return null;
  }
  function poser(el, p) {
    var prix = Number(p[1]), normal = Number(p[2]);
    var remise = normal > prix ? Math.round(100 - prix * 100 / normal) : 0;
    if (!(prix > 0 && normal < 1000) || remise < REMISE_MIN) { return false; }
    var q = function (s) { return Array.prototype.slice.call(el.querySelectorAll(s)); };
    q(".bp-final").forEach(function (x) { x.textContent = euros(prix); });
    q(".bp-normal").forEach(function (x) { x.textContent = euros(normal); });
    q(".bp-eco b").forEach(function (x) { x.textContent = euros(normal - prix); });
    q(".bp-badge").forEach(function (x) { x.textContent = "-" + remise + " %"; x.classList.toggle("fort", remise >= 75); });
    return true;
  }
  function jour() { return Math.floor((Date.now() / 1000 + 7200) / 86400); }
  fetch("https://raw.githubusercontent.com/Sikher-kisa/orion-game-launcher/donnees/gamesplanet-fr.json")
    .then(function (r) { if (!r.ok) { throw new Error("releve"); } return r.json(); })
    .then(function (d) {
      var age = Date.now() / 1000 - Number(d.releve);
      if (!(age > -3600 && age < PERIME)) { return; }
      var restent = [];
      cartes.forEach(function (c) {
        var p = produit(d, c);
        if (p && poser(c, p)) { restent.push(c); } else { c.hidden = true; }
      });
      var r = document.getElementById("bp-releve");
      if (r) { r.textContent = "Prix relevés chez Gamesplanet " + ilYA(age) + "."; }
      if (!une) { return; }
      // l'affaire du jour : une des meilleures, differente chaque jour
      restent.sort(function (a, b) { return Number(b.getAttribute("data-score")) - Number(a.getAttribute("data-score")); });
      var choix = restent.slice(0, ROTATION);
      if (!choix.length) { var p0 = produit(d, une); if (!p0 || !poser(une, p0)) { une.hidden = true; } return; }
      var c = choix[jour() % choix.length];
      var img = c.querySelector(".bp-visuel img"), cible = une.querySelector(".bp-visuel img");
      if (img && cible) { cible.src = img.src; }
      ["a.bp-visuel", "h2 a", ".bp-actions a.btn"].forEach(function (s, i) {
        var src = c.querySelector(["a.bp-visuel", "h3 a", ".bp-actions a.btn"][i]), dst = une.querySelector(s);
        if (src && dst) { dst.href = src.href; }
      });
      une.querySelector("h2 a").textContent = c.querySelector("h3 a").textContent;
      var cfg = c.querySelector("a.bp-config"), ucfg = une.querySelector("a.bp-config");
      if (cfg && ucfg) { ucfg.href = cfg.getAttribute("href"); }
      var avis = c.querySelector(".bp-avis"), uavis = une.querySelector(".bp-avis");
      if (avis && uavis) { uavis.innerHTML = avis.innerHTML; }
      une.querySelector(".bp-ou").textContent = c.querySelector(".bp-ou").textContent;
      ["data-appid", "data-fiche", "data-score"].forEach(function (a) { une.setAttribute(a, c.getAttribute(a)); });
      poser(une, produit(d, c));
      c.hidden = true;                      // pas deux fois la meme offre a l'ecran
    })
    .catch(function () { /* le releve ne repond pas : la page garde ses prix et leur date */ });
}());
"""


def main(dossier, G, jeux, style=None) -> dict:
    """Ecrit /bons-plans et ses rubriques. Rend {chemin: nombre d'offres}."""
    dossier = Path(dossier)
    if style is None:
        accueil = (dossier / "index.html").read_text(encoding="utf-8")
        style = re.search(r"<style>(.*?)</style>", accueil, re.S).group(1)
    releve = int(G._memo["releve"]) if G is not None else 0
    tous = offres_du_jeu(jeux)
    dlc = extensions(jeux, G)
    populaires = [o for o in tous if o["avis"] >= POPULAIRE]
    siecle = [o for o in populaires if o["remise"] >= SIECLE]
    petits = sorted([o for o in tous if o["prix"] < PETIT_PRIX], key=lambda o: (-o["avis"]))
    indes = [o for o in tous if any(g.lower() in ("indépendant", "indie") for g in o["genres"])]
    comptes = {"/bons-plans": len(tous), "/bons-plans/affaires-du-siecle": len(siecle),
               "/bons-plans/moins-de-10-euros": len(petits), "/bons-plans/jeux-independants": len(indes),
               "/bons-plans/dlc": len(dlc)}
    (dossier / "bons-plans").mkdir(exist_ok=True)
    (dossier / "bons-plans.js").write_text(BONS_PLANS_JS, encoding="utf-8")

    tete, reste = (populaires or tous)[:1], [o for o in tous if o not in (populaires or tous)[:1]]
    meilleure = tete[0] if tete else None
    gros = sorted({o["remise"] for o in tous}, reverse=True)[:1]
    mois = de_mois(dt.date.today())
    jusqu = f" : jusqu'à -{gros[0]} %" if gros else ""
    (dossier / "bons-plans.html").write_text(page(
        style, "/bons-plans",
        ajuste([f"Bons plans jeux PC {mois}{jusqu}", f"Promos jeux PC {mois}{jusqu}",
                f"Bons plans jeux PC {mois}", "Bons plans jeux PC : promos du moment"], fr.TITRE_MAX),
        ajuste([f"{exemples(tous)}… {len(tous)} jeux PC très joués en promo, clés officielles, prix vérifiés "
                f"toutes les 20 minutes.",
                f"{exemples(tous, 1)}… {len(tous)} jeux PC très joués en promo, clés officielles, prix vérifiés "
                f"toutes les 20 minutes.",
                f"{len(tous)} jeux PC très joués en promo{jusqu} : clés officielles, prix vérifiés toutes les "
                f"20 minutes."], fr.DESC_MAX),
        f"Bons plans · {len(tous)} jeux en promo",
        "Bons plans jeux PC : les grosses promos sur les jeux que tout le monde joue",
        "Les meilleures promos jeux PC du moment, sans jeux inconnus bradés : seulement des jeux parmi "
        f"les plus joués sur Steam, remisés d'au moins {REMISE_MIN} %, en clé Steam officielle, avec le prix "
        "habituel barré. Jeux pas chers, affaires du siècle, DLC : un clic sur « Prix et boutiques » compare "
        "Steam, les autres boutiques officielles et les revendeurs de clés.",
        reste, releve, avant=une(meilleure) if meilleure else "", apres=suite(comptes), faq=FAQ),
        encoding="utf-8")

    rubriques = [
        ("affaires-du-siecle", "Affaires du siècle", siecle,
         ajuste([f"Affaires du siècle {mois} : jeux PC à -75 %", "Affaires du siècle : jeux PC à -75 % et plus",
                 "Jeux PC à -75 % et plus"], fr.TITRE_MAX),
         ajuste([f"{exemples(siecle)}… {len(siecle)} jeux PC très joués à -75 % et plus, clés officielles.",
                 f"{len(siecle)} jeux PC très joués à -75 % et plus en ce moment : prix barré, remise de la "
                 f"boutique, clés Steam officielles vérifiées toutes les 20 minutes.",
                 f"{len(siecle)} jeux PC très joués à -75 % et plus, clés officielles."], fr.DESC_MAX),
         "Les affaires du siècle : -75 % et plus sur des jeux très joués",
         f"Les plus grosses remises du moment, et seulement sur des jeux joués par des dizaines de milliers "
         f"de joueurs (au moins {milliers(POPULAIRE)} avis Steam)."),
        ("moins-de-10-euros", "Moins de 10 €", petits,
         ajuste([f"Jeux PC à moins de 10 € {mois}", "Jeux PC à moins de 10 € : les bons plans du moment",
                 "Jeux PC à moins de 10 €"], fr.TITRE_MAX),
         ajuste([f"{exemples(petits)}… {len(petits)} jeux PC connus à moins de 10 €, clés officielles.",
                 f"{len(petits)} jeux PC connus à moins de 10 € en ce moment, en promo d'au moins {REMISE_MIN} % : "
                 f"clés Steam officielles, prix vérifiés toutes les 20 minutes.",
                 f"{len(petits)} jeux PC à moins de 10 €, clés officielles."], fr.DESC_MAX),
         "Jeux PC à moins de 10 € : des jeux connus, pas des fonds de catalogue",
         "Des jeux très joués, remisés sous la barre des 10 €, les plus connus d'abord."),
        ("jeux-independants", "Jeux indés", indes,
         ajuste([f"Jeux indés PC en promo {mois}", "Jeux indés PC en promo : les bons plans du moment",
                 "Jeux indés PC en promo"], fr.TITRE_MAX),
         ajuste([f"{exemples(indes)}… {len(indes)} jeux indés PC en promo, clés officielles.",
                 f"{len(indes)} jeux indépendants PC très appréciés en promo d'au moins {REMISE_MIN} % : clés "
                 f"Steam officielles, prix vérifiés toutes les 20 minutes.",
                 f"{len(indes)} jeux indés PC en promo, clés officielles."], fr.DESC_MAX),
         "Jeux indés en promo : les pépites du moment",
         "Les jeux indépendants les plus joués et les mieux notés, en promotion."),
        ("dlc", "DLC et extensions", dlc,
         ajuste([f"DLC et extensions PC en promo {mois}", "DLC et extensions PC en promo : les bons plans",
                 "DLC PC en promo"], fr.TITRE_MAX),
         ajuste([f"{exemples(dlc)}… {len(dlc)} DLC et extensions PC en promo, clés officielles.",
                 f"{len(dlc)} DLC, season pass et extensions de jeux PC très joués en promo : clés Steam "
                 f"officielles, prix vérifiés toutes les 20 minutes.",
                 f"{len(dlc)} DLC et extensions PC en promo, clés officielles."], fr.DESC_MAX),
         "DLC et extensions en promo",
         "Les extensions et season pass des jeux les plus joués, remisés. Le jeu de base est "
         "nécessaire : il est indiqué sur chaque carte."),
    ]
    for nom_fichier, nom, offres, titre, desc, h1, lede in rubriques:
        (dossier / "bons-plans" / f"{nom_fichier}.html").write_text(page(
            style, f"/bons-plans/{nom_fichier}", titre, desc, f"Bons plans · {nom}", e(h1), lede,
            offres, releve, apres=suite(comptes), fil=nom), encoding="utf-8")
    # l'accueil est relu par gen_en (accueil anglais) : la section y est posee
    # apres tous les generateurs, par relier()
    A_LA_UNE[:] = populaires or tous
    RELEVE[:] = [releve] if releve else []
    if (dossier / "sitemap.xml").exists():
        plan(dossier, ["/bons-plans"] + [f"/bons-plans/{r[0]}" for r in rubriques], dt.date.today())
    print(f"bons plans : {len(tous)} jeux en promo (dont {len(siecle)} a -{SIECLE} % et plus), "
          f"{len(petits)} a moins de {PETIT_PRIX:g} euros, {len(indes)} indes, {len(dlc)} DLC")
    return comptes


def accueil(dossier: Path, offres: list[dict], n: int = 4) -> bool:
    """Les bons plans du moment sur l'accueil : la page la plus forte du site
    renvoie vers eux (et Google suit ce lien en premier)."""
    p = Path(dossier) / "index.html"
    if not p.exists() or not offres:
        return False
    s = p.read_text(encoding="utf-8")
    ancre = '<section class="wrap partie" id="garanties"'
    if 'id="bons-plans"' in s or ancre not in s:
        return False
    cartes = "\n".join(carte(o, comparer=False) for o in offres[:n])
    from zoneinfo import ZoneInfo
    quand = dt.datetime.fromtimestamp(RELEVE[0], ZoneInfo("Europe/Paris")) if RELEVE else None
    date = (f" Prix relevés le {date_fr(quand.date())} à {quand.hour} h {quand.minute:02d}, à jour sur la page "
            f"des bons plans.") if quand else ""
    section = f"""<section class="wrap partie" id="bons-plans" aria-labelledby="t-bons-plans">
    <h2 id="t-bons-plans">Les bons plans du moment.</h2>
    <p>Des jeux parmi les plus joués sur Steam, remisés d'au moins {REMISE_MIN} %, en clé officielle et prix
      vérifiés toutes les vingt minutes. <a href="/bons-plans">Tous les bons plans</a> ·
      <a href="/bons-plans/affaires-du-siecle">Affaires du siècle</a> · <a href="/bons-plans/moins-de-10-euros">Moins
      de 10 €</a> · <a href="/gratuits">Jeux gratuits</a>.{date}</p>
    <div class="bp-grille">
{cartes}
    </div>
  </section>

  """
    s = s.replace(ancre, section + ancre, 1)
    # l'accueil n'appelle aucun service tiers (essai_accueil.py) : pas de
    # relecture des prix ici, la date du releve est ecrite et la page des
    # bons plans, elle, suit les prix en direct
    s = s.replace("</head>", f"<style>{CSS}</style>\n</head>", 1)
    p.write_text(s, encoding="utf-8")
    return True


def onglets_gratuits(dossier: Path) -> bool:
    """La page Jeux gratuits fait partie des bons plans : memes onglets."""
    p = Path(dossier) / "gratuits.html"
    if not p.exists():
        return False
    s = p.read_text(encoding="utf-8")
    if "bp-onglets" in s:
        return False
    m = re.search(r'(<p class="chapo">.*?</p>)', s, re.S)
    if not m:
        return False
    s = s[:m.end()] + "\n" + onglets("/gratuits") + s[m.end():]
    s = s.replace("</head>", f"<style>{CSS}</style>\n</head>", 1)
    p.write_text(s, encoding="utf-8")
    return True


#: les meilleures offres, pour l'accueil (remplies par main)
A_LA_UNE: list[dict] = []
RELEVE: list[int] = []

#: lien « Bons plans » dans le menu et le pied de page de toutes les pages francaises
LIEN_MENU = '<a href="/bons-plans"{courant}>Bons plans</a>\n      '


def relier(dossier: Path) -> int:
    """Ajoute « Bons plans » au menu du haut (avant « Sorties ») et au pied de
    page (avant « Jeux gratuits ») des pages francaises. Rend le nombre de pages."""
    n = 0
    onglets_gratuits(Path(dossier))
    accueil(Path(dossier), A_LA_UNE)
    for f in Path(dossier).rglob("*.html"):
        rel = f.relative_to(dossier).as_posix()
        if rel.startswith("en/"):
            continue
        t = f.read_text(encoding="utf-8")
        if 'href="/bons-plans"' in t.split("<main", 1)[0]:
            continue
        m = re.search(r'<header class="nav">.*?</header>', t, re.S)
        if not m or 'href="/sorties"' not in m.group(0):
            continue
        courant = ' aria-current="page"' if rel.startswith("bons-plans") else ""
        nav = m.group(0).replace('<a href="/sorties"', LIEN_MENU.format(courant=courant) + '<a href="/sorties"', 1)
        if courant:
            nav = re.sub(r'(<a href="/jeux") aria-current="page"', r"\1", nav)
        t = t[:m.start()] + nav + t[m.end():]
        pied = t.rfind("<footer")
        if pied > 0 and 'href="/bons-plans"' not in t[pied:]:
            t = t[:pied] + t[pied:].replace('<a href="/gratuits">', '<a href="/bons-plans">Bons plans</a>\n      '
                                            '<a href="/gratuits">', 1)
        f.write_text(t, encoding="utf-8")
        n += 1
    return n


def plan(dossier: Path, chemins: list[str], auj: dt.date) -> None:
    """Ajoute les pages au plan du site (avant les mentions legales)."""
    p = Path(dossier) / "sitemap.xml"
    x = p.read_text(encoding="utf-8")
    x = re.sub(r"  <url>\n    <loc>" + re.escape(SITE) + r"/bons-plans[^<]*</loc>.*?</url>\n", "", x, flags=re.S)
    bloc = "".join(f"  <url>\n    <loc>{SITE}{c}</loc>\n    <lastmod>{auj.isoformat()}</lastmod>\n"
                   f"    <changefreq>daily</changefreq>\n    <priority>{'0.9' if c == '/bons-plans' else '0.8'}</priority>\n  </url>\n"
                   for c in chemins)
    x = x.replace("  <url>\n    <loc>" + SITE + "/mentions-legales", bloc + "  <url>\n    <loc>" + SITE + "/mentions-legales")
    p.write_text(x, encoding="utf-8")
