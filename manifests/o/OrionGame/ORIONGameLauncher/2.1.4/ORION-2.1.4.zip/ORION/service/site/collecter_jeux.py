"""Collecte les fiches Steam des jeux les plus joues, pour les pages /jeux du site.

Usage : python collecter_jeux.py <sortie.json> [nombre de jeux] [french|english]

Produit le meme format que `jeux-steam.json` (appid -> {n, d, g, dev, s, min,
rec, img, free}), que `gen_jeux.py` transforme en pages. Reprend la ou il
s'est arrete : relancer le script complete le fichier au lieu de repartir
de zero. Respecte la limite de Steam (environ 200 appels par 5 minutes) :
compter 30 a 40 minutes pour 1 000 jeux.

Sources : la liste des jeux les plus possedes (SteamSpy, une requete par
page de 1 000), puis la fiche publique de chaque jeu (store.steampowered.com).
Seuls les jeux (pas les logiciels, DLC ni bandes originales) sont gardes.
"""
import html
import json
import re
import sys
import time
import unicodedata
import urllib.request
from pathlib import Path

LISTE = "https://steamspy.com/api.php?request=all&page={page}"
FICHE = ("https://store.steampowered.com/api/appdetails?appids={appid}"
         "&cc=fr&l={langue}&filters=basic,developers,genres,release_date,pc_requirements")
PAUSE = 1.6                 # secondes entre deux fiches : sous la limite de Steam
ENTETES = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) ORION-site/1.0",
           "Accept-Language": "fr-FR,fr;q=0.9"}


def lire(url: str, essais: int = 4):
    for n in range(essais):
        try:
            req = urllib.request.Request(url, headers=ENTETES)
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read().decode("utf-8", "replace"))
        except Exception as exc:            # 429 (trop vite), coupure : on attend et on reprend
            attente = 30 * (n + 1)
            print(f"  attente {attente} s ({exc})")
            time.sleep(attente)
    return None


def texte(h: str) -> str:
    """Le HTML de la configuration requise, en lignes « Cle : valeur »."""
    h = re.sub(r"<br\s*/?>", "\n", h or "", flags=re.I)
    h = re.sub(r"</li>", "\n", h, flags=re.I)
    h = re.sub(r"<[^>]+>", "", h)
    h = html.unescape(h)
    return "\n".join(l.strip() for l in h.splitlines() if l.strip())


def sans_accents(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c))


def appids_populaires(nombre: int) -> list[int]:
    ids: list[int] = []
    page = 0
    while len(ids) < nombre * 2 and page < 5:      # marge : la moitie seront ecartes
        d = lire(LISTE.format(page=page)) or {}
        if not d:
            break
        ids.extend(int(k) for k in d)
        page += 1
        time.sleep(2)
    return ids


def fiche(appid: int, langue: str) -> dict | None:
    d = lire(FICHE.format(appid=appid, langue=langue))
    bloc = (d or {}).get(str(appid)) or {}
    if not bloc.get("success"):
        return None
    x = bloc.get("data") or {}
    if x.get("type") != "game":
        return None
    cfg = x.get("pc_requirements") or {}
    if isinstance(cfg, list):               # Steam rend [] quand il n'y a rien
        cfg = {}
    mini = texte(cfg.get("minimum", ""))
    if not mini:
        return None                         # sans configuration, pas de page utile
    date = (x.get("release_date") or {}).get("date", "")
    return {
        "n": x.get("name", "").strip(),
        "d": sans_accents(date),
        "g": [g.get("description", "") for g in x.get("genres") or [] if g.get("description")],
        "dev": ", ".join(x.get("developers") or [])[:80],
        "s": html.unescape(re.sub(r"<[^>]+>", "", x.get("short_description", ""))).strip(),
        "min": mini,
        "rec": texte(cfg.get("recommended", "")),
        "img": x.get("header_image", ""),
        "free": bool(x.get("is_free")),
    }


def main(sortie: str, nombre: int = 1000, langue: str = "french") -> None:
    chemin = Path(sortie)
    jeux = json.loads(chemin.read_text(encoding="utf-8")) if chemin.exists() else {}
    vus = set(jeux)
    ecartes_chemin = chemin.with_suffix(".ecartes.txt")
    ecartes = set(ecartes_chemin.read_text().split()) if ecartes_chemin.exists() else set()
    print(f"{len(jeux)} jeux deja collectes, {len(ecartes)} ecartes connus")

    candidats = [a for a in appids_populaires(nombre) if str(a) not in vus and str(a) not in ecartes]
    print(f"{len(candidats)} jeux a lire")
    depuis = time.time()
    for i, appid in enumerate(candidats, 1):
        if len(jeux) >= nombre:
            break
        f = fiche(appid, langue)
        if f and f["n"]:
            jeux[str(appid)] = f
        else:
            ecartes.add(str(appid))
        if i % 25 == 0:
            chemin.write_text(json.dumps(jeux, ensure_ascii=False, indent=0), encoding="utf-8")
            ecartes_chemin.write_text("\n".join(sorted(ecartes)))
            restant = (len(candidats) - i) * PAUSE / 60
            print(f"  {len(jeux)} jeux ({i}/{len(candidats)} lus, {time.time() - depuis:.0f} s, "
                  f"encore ~{restant:.0f} min)")
        time.sleep(PAUSE)
    chemin.write_text(json.dumps(jeux, ensure_ascii=False, indent=0), encoding="utf-8")
    ecartes_chemin.write_text("\n".join(sorted(ecartes)))
    print(f"Termine : {len(jeux)} jeux dans {chemin}")


if __name__ == "__main__":
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        sys.exit(1)
    main(args[0], int(args[1]) if len(args) > 1 else 1000, args[2] if len(args) > 2 else "french")
