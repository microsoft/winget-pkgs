"""Calendrier des soldes Steam (13 octobre 2026), pour la page /soldes-steam
et la page Black Friday.

Source : la page des evenements a venir que Valve publie pour les
developpeurs, relue le 13 octobre 2026
(https://partner.steamgames.com/doc/marketing/upcoming_events). Les soldes
d'automne 2026, deja passees, n'y figurent plus : elles ont eu lieu du 1er au
8 octobre (Valve les a avancees cette annee). Une date que Valve n'a pas
publiee n'est jamais devinee : elle reste « pas encore annoncee ».

Les soldes commencent et finissent a 10 h, heure du Pacifique. L'heure de
Paris est calculee pour chaque date : l'Amerique et l'Europe ne changent pas
d'heure le meme jour (soldes de printemps 2027 : 18 h a Paris, pas 19 h).

A relire a chaque trimestre : `RELU` dit quand.
"""
from __future__ import annotations

import datetime as dt
from zoneinfo import ZoneInfo

SOURCE = "https://partner.steamgames.com/doc/marketing/upcoming_events"
RELU = dt.date(2026, 10, 13)
PACIFIQUE, PARIS = ZoneInfo("America/Los_Angeles"), ZoneInfo("Europe/Paris")

#: (nom, debut, fin) : du jour de debut au jour de fin, 10 h heure du Pacifique
SOLDES = [
    ("Soldes d'automne 2026", dt.date(2026, 10, 1), dt.date(2026, 10, 8)),
    ("Soldes d'hiver 2026", dt.date(2026, 12, 17), dt.date(2027, 1, 4)),
    ("Soldes de printemps 2027", dt.date(2027, 3, 18), dt.date(2027, 3, 25)),
    ("Soldes d'été 2027", dt.date(2027, 6, 24), dt.date(2027, 7, 8)),
]
#: soldes dont Valve n'a pas encore donne la date
PAS_ANNONCEES = ["Soldes d'automne 2027"]

#: festivals : demos ou un genre a l'honneur, promotions sur une partie des jeux
FESTIVALS = [
    ("Steam Next Fest d'octobre (démos)", dt.date(2026, 10, 19), dt.date(2026, 10, 26)),
    ("Steam Scream Fest (jeux d'horreur, Halloween)", dt.date(2026, 10, 26), dt.date(2026, 11, 2)),
    ("Steam Next Fest de février (démos)", dt.date(2027, 2, 22), dt.date(2027, 3, 1)),
    ("Steam Next Fest de juin (démos)", dt.date(2027, 6, 14), dt.date(2027, 6, 21)),
]


def instant(jour: dt.date) -> dt.datetime:
    """Debut (ou fin) d'une solde : 10 h, heure du Pacifique, ce jour-la."""
    return dt.datetime(jour.year, jour.month, jour.day, 10, 0, tzinfo=PACIFIQUE)


def heure_paris(jour: dt.date) -> int:
    return instant(jour).astimezone(PARIS).hour


def prochaine(auj: dt.date):
    """La solde en cours ou la prochaine : (nom, debut, fin), ou None."""
    return next((s for s in SOLDES if s[2] >= auj), None)


def au_black_friday(bf: dt.date):
    """La solde Steam qui couvre la semaine du Black Friday, ou None."""
    return next((s for s in SOLDES if s[1] <= bf + dt.timedelta(days=4) and s[2] >= bf - dt.timedelta(days=7)),
                None)


def nommee(nom: str):
    """La solde de ce nom, ou None."""
    return next((s for s in SOLDES if s[0] == nom), None)


MOIS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre",
        "novembre", "décembre"]


def jour_fr(d: dt.date, annee: bool = True) -> str:
    return f"{d.day}{'er' if d.day == 1 else ''} {MOIS[d.month - 1]}" + (f" {d.year}" if annee else "")


def periode(debut: dt.date, fin: dt.date) -> str:
    """« du 1er au 8 octobre 2026 », « du 17 décembre 2026 au 4 janvier 2027 »."""
    if (debut.year, debut.month) == (fin.year, fin.month):
        return f"du {debut.day}{'er' if debut.day == 1 else ''} au {jour_fr(fin)}"
    if debut.year == fin.year:
        return f"du {jour_fr(debut, False)} au {jour_fr(fin)}"
    return f"du {jour_fr(debut)} au {jour_fr(fin)}"


def minuscule(nom: str) -> str:
    return nom[:1].lower() + nom[1:]
