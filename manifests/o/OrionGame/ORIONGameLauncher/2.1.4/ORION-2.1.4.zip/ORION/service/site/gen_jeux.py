"""Genere les pages publiques /jeux et /jeux/<jeu> du site.

Usage : python gen_jeux.py <dossier du site> <jeux-steam.json>
                           [<gamesplanet-fr.json> [<fiches-jeux.json>]]

`gamesplanet-fr.json` : le releve des prix de Gamesplanet (branche « donnees »
du depot public). Chaque page recoit le prix releve a sa generation ; le
script `/prix.js` le remplace, chez le visiteur, par celui du dernier releve.
`fiches-jeux.json` : les fiches relevees par la tache « Fiches des jeux du
site » (branche « donnees-jeux »), pour les pages des jeux les plus connus.

Chaque page donne la configuration officielle d'un jeu (fiche Steam) et ce
que le moteur d'ORION en deduit pour les cartes graphiques courantes, en
1080p, 1440p et 4K. Le calcul est exactement celui de l'application
(orion.puissance.estimation) : une estimation prudente, jamais une mesure,
et la page le dit.
"""
import datetime as dt
import html
import json
import re
import sys
import time
import unicodedata
from pathlib import Path

sys.path.insert(0, "/home/claude/ORION")
from orion.puissance.estimation import Machine, estimer            # noqa: E402
from orion.puissance.exigences import Exigences, lire_config       # noqa: E402
from orion.puissance.references import GPU, tous_les_gpu           # noqa: E402
import reglages                                                     # noqa: E402

SITE = "https://orion-launcher.com"
EXE = "https://github.com/Sikher-kisa/orion-game-launcher/releases/latest/download/Installateur-ORION.exe"
MOIS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août",
        "septembre", "octobre", "novembre", "décembre"]

# cartes affichees (cle de la table d'ORION, nom, memoire video en Go)
CARTES = [
    ("rtx 5080", "GeForce RTX 5080", 16), ("rx 9070 xt", "Radeon RX 9070 XT", 16),
    ("rtx 5070", "GeForce RTX 5070", 12), ("rtx 4070 super", "GeForce RTX 4070 Super", 12),
    ("rx 7800 xt", "Radeon RX 7800 XT", 16), ("rtx 4070", "GeForce RTX 4070", 12),
    ("rtx 3080", "GeForce RTX 3080", 10), ("rx 9060 xt", "Radeon RX 9060 XT", 16),
    ("rtx 4060 ti", "GeForce RTX 4060 Ti", 8),
    ("rtx 3070", "GeForce RTX 3070", 8), ("rx 6700 xt", "Radeon RX 6700 XT", 12),
    ("rtx 5060", "GeForce RTX 5060", 8), ("arc b580", "Intel Arc B580", 12),
    ("rtx 4060", "GeForce RTX 4060", 8), ("rx 7600", "Radeon RX 7600", 8),
    ("rtx 3060", "GeForce RTX 3060", 12), ("rx 6600", "Radeon RX 6600", 8),
    ("rtx 2060", "GeForce RTX 2060", 6), ("gtx 1660 super", "GeForce GTX 1660 Super", 6),
    ("rx 580", "Radeon RX 580", 8), ("gtx 1060", "GeForce GTX 1060", 6),
]
DEFS = [("1080p", "1920x1080", 1920 * 1080), ("1440p", "2560x1440", 2560 * 1440),
        ("4K", "3840x2160", 3840 * 2160)]
NIVEAU = {"haute": "Élevés", "moyenne": "Moyens", "basse": "Bas"}
#: nombre de cartes du tableau, tel qu'il est ecrit dans les textes (13 octobre :
#: la RX 9060 XT fait passer de 20 a 21 ; « vingt » etait ecrit en dur)
NB_CARTES = len(CARTES)

NOMS = {  # noms d'affichage quand celui de Steam est en capitales ou trop long
    "ELDEN RING": "Elden Ring", "ELDEN RING NIGHTREIGN": "Elden Ring Nightreign",
    "FINAL FANTASY VII REBIRTH": "Final Fantasy VII Rebirth",
    "PUBG: BATTLEGROUNDS": "PUBG: Battlegrounds", "HELLDIVERS 2": "Helldivers 2",
    "Ghost of Tsushima DIRECTOR'S CUT": "Ghost of Tsushima",
    "Grand Theft Auto V Version améliorée": "Grand Theft Auto V",
    "Sid Meier's Civilization VII": "Civilization VII",
    "Marvel's Spider-Man Remastered": "Marvel's Spider-Man",
    "Hogwarts Legacy : L'Héritage de Poudlard": "Hogwarts Legacy",
    "The Witcher 3: Wild Hunt — Remastered": "The Witcher 3: Wild Hunt",
    "Horizon Forbidden West Complete Edition": "Horizon Forbidden West",
}
#: pages publiees au plus. L'envoi par le tableau de bord de Cloudflare est
#: limite a 1 000 fichiers (images comprises) : au-dela, le site part par
#: Wrangler (`wrangler pages deploy`, jusqu'a 20 000 fichiers).
#: une page de jeu en promo renvoie aux bons plans (13 octobre)
VERS_BONS_PLANS = ' Les autres jeux très joués en promo : <a href="/bons-plans">les bons plans du moment</a>.'

#: appids dont le visuel est dans le site (`jaquettes.py`), lus par `main`
VISUELS: set[str] = set()


def visuel(appid, classe="", chargement="lazy") -> str:
    """Visuel du jeu, ou « » s'il n'est pas dans le site."""
    import jaquettes
    return jaquettes.balise(appid, classe, chargement) if str(appid) in VISUELS else ""


def image_og(appid) -> str:
    """Image de partage : le visuel du jeu s'il est la, sinon celle du site."""
    import jaquettes
    return SITE + (jaquettes.adresse(appid) if str(appid) in VISUELS else "/img/og.jpg")


PAGES_MAX = int(__import__("os").environ.get("ORION_PAGES_MAX") or 2500)   # assembler.py --max


def euros(v):
    return f"{v:.2f}".replace(".", ",") + "\u00a0€"


def charger_prix(chemin):
    """Branche le releve Gamesplanet sur le moteur de l'application : meme
    regle que dans ORION pour reconnaitre le bon produit (jamais une edition
    prise pour le jeu), vue depuis la France."""
    from orion import prix_gamesplanet as G
    from orion.core import region
    d = json.loads(Path(chemin).read_text(encoding="utf-8"))
    G._memo["releve"], G._memo["jeux"] = float(d["releve"]), d["jeux"]
    region.devise, region.pays = (lambda: "EUR"), (lambda: "FR")
    assert G.valable(), "releve Gamesplanet trop ancien : le retelecharger"
    return G


def offre_gp(G, appid, *noms):
    """{prix, normal, remise, slug, url, cle} du jeu chez Gamesplanet, ou None."""
    if G is None:
        return None
    from orion.affiliation import affilier
    for nom in noms:
        o = G.offre(appid, nom)
        if o is not None:
            return {"prix": o.prix, "normal": o.prix_normal, "remise": o.remise,
                    "slug": o.url.rsplit("/", 1)[1], "url": affilier(o.url),
                    "cle": o.drm.replace("Cle", "Clé"), "releve": int(G._memo["releve"])}
    return None


CHAMPS = [("système d'exploitation", "Système"), ("processeur", "Processeur"),
          ("mémoire vive", "Mémoire vive"), ("graphiques", "Carte graphique"),
          ("directx", "DirectX"), ("espace disque", "Espace disque"),
          ("notes supplémentaires", "Notes de l'éditeur")]


def e(t):
    return html.escape(str(t or ""), quote=True)


def propre(nom):
    n = re.sub(r"[™®]", "", nom).replace("’", "'").replace("\xa0", " ")
    n = re.sub(r"\s+", " ", n).strip()
    return NOMS.get(n, n)


def slug(nom):
    t = unicodedata.normalize("NFKD", nom).encode("ascii", "ignore").decode().lower()
    t = re.sub(r"['.,]", "", t)
    return re.sub(r"[^a-z0-9]+", "-", t).strip("-")


def date_fr(d):
    return f"{d.day}{'er' if d.day == 1 else ''} {MOIS[d.month - 1]} {d.year}"


def joli(cle):
    mots = {"rtx": "RTX", "gtx": "GTX", "rx": "RX", "gt": "GT", "arc": "Arc", "ti": "Ti",
            "super": "Super", "xt": "XT", "xtx": "XTX", "gre": "GRE", "hd": "HD", "r9": "R9",
            "vega": "Vega", "radeon": "Radeon", "6gb": "6 Go", "3gb": "3 Go"}
    return " ".join(mots.get(m, m.upper() if m[:1] in "ab" and m[1:].isdigit() else m)
                    for m in cle.split())


def repere(brut, config):
    """Plusieurs cartes citees (« RX 6800 XT, RTX 2080 ») : leur moyenne sert
    de repere, pour ne pas caler l'estimation sur la plus puissante."""
    ligne = next((l.split(":", 1)[1] for l in brut.splitlines()
                  if l.lower().startswith("graphi") and ":" in l), brut)
    cites = tous_les_gpu(ligne)
    if config is not None and cites:
        config.gpu = round(sum(i for _, i in cites) / len(cites), 1)
    return [joli(c) for c, _ in cites]


def champs(texte, coupe=True):
    """Lignes « Libelle : valeur » de la fiche Steam, dans un ordre fixe.
    `coupe` : texte de la premiere collecte, tronque a 700 caracteres."""
    vus = {}
    lignes = texte.replace("\ufeff", "").splitlines()
    if coupe and len(texte) >= 700 and lignes:  # derniere ligne coupee a la collecte
        lignes = lignes[:-1]
    for ligne in lignes:
        if ":" not in ligne:
            continue
        tete, reste = ligne.split(":", 1)
        tete, reste = tete.strip().lower(), reste.strip()
        if tete.startswith("système d'exploitation et processeur"):
            continue
        for cle, nom in CHAMPS:
            if tete.startswith(cle) and reste and nom not in vus:
                reste = re.sub(r"[™®]", "", reste)
                reste = re.sub(r"\bde mémoire\b|\bd'espace disque disponible\b", "", reste).strip()
                reste = re.sub(r"(\d)\s*GB\b", r"\1 Go", reste)
                if nom in ("Processeur", "Carte graphique"):
                    reste = re.sub(r"\s+or\s+", " ou ", reste)
                if nom == "Notes de l'éditeur":
                    reste = re.split(r"(?<=[.!])\s", reste)[0]
                    if len(reste) > 180:
                        continue
                vus[nom] = net(reste)
    return [(nom, vus[nom]) for _, nom in CHAMPS if nom in vus]


def net(t: str) -> str:
    """Le texte d'une fiche Steam, sans ses fautes de frappe visibles (audit du
    12 octobre) : « Windows 7 , Windows 8 », « RTX 2060 Super(VRAM 8 Go) »,
    « might not work.. »."""
    t = re.sub(r"\s+([,.])(?=\s|$)", r"\1", t)
    t = re.sub(r"(?<=[A-Za-z0-9])\((?=[A-Za-z0-9])", " (", t)
    t = re.sub(r"(?<!\.)\.\.(?!\.)", ".", t)
    return re.sub(r"\s{2,}", " ", t).strip()


#: genres Steam d'un logiciel (francais et anglais) ...
LOGICIELS = {"utilitaires", "utilities", "conception et illustration", "design & illustration",
             "animation et modélisation", "animation & modeling", "édition photo", "photo editing",
             "montage vidéo", "video production", "production audio", "audio production", "formation",
             "software training", "développement de jeux", "game development", "publication web",
             "web publishing", "comptabilité", "accounting", "logiciels"}
#: ... et ceux d'un vrai jeu, qui l'emportent (un jeu de simulation range parfois
#: aussi « Utilitaires »)
FORTS = {"action", "aventure", "adventure", "rpg", "stratégie", "strategy", "simulation",
         "course automobile", "racing", "sport", "sports", "massivement multijoueur", "massively multiplayer"}


def est_un_logiciel(genres) -> bool:
    """Wallpaper Engine (« Occasionnel, Indépendant, Utilitaires… ») avait sa
    page de jeu, et depuis le 12 octobre ses « meilleurs réglages »."""
    g = {str(x).lower() for x in (genres or [])}
    return bool(g & LOGICIELS) and not (g & FORTS)


def rediriger(dossier: Path, chemins: list[str], vers: str) -> None:
    """Une page retiree renvoie vers la liste (Cloudflare Pages, `_redirects`)
    plutot que vers une page introuvable que Google signalerait."""
    if not chemins:
        return
    f = Path(dossier) / "_redirects"
    deja = f.read_text(encoding="utf-8").splitlines() if f.is_file() else []
    neuves = [f"{c} {vers} 301" for c in chemins if f"{c} {vers} 301" not in deja]
    if neuves:
        f.write_text("\n".join(deja + neuves) + "\n", encoding="utf-8")


def seul(nom: str) -> list[str]:
    """Le nom seul comme titre de page francaise, seulement s'il tient. Les
    pages anglaises gardent toujours un mot en plus (« specs ») : sinon la
    page francaise et l'anglaise d'un jeu au long nom portaient le meme titre
    (audit du 12 octobre : 5 doublons). Un titre un peu long mais distinct
    vaut mieux qu'un doublon."""
    return [nom] if len(nom) <= TITRE_MAX else []


def sans_point(t: str) -> str:
    """Pour finir une phrase par « . » sans en mettre deux."""
    return (t or "").rstrip(" .")


def evaluer(exig, cle, vram, pixels, definition):
    m = Machine(gpu=GPU[cle], gpu_nom=cle, vram_go=vram, ram_go=64, pixels=pixels,
                definition=definition)
    return estimer(exig.titre, exig, m)


#: jeu qui exige le ray tracing materiel, sur une carte qui ne le calcule pas (13 octobre 2026)
CELLULE_RT = '<td class="non"><b>Ne se lance pas</b><span class="mono">ray tracing exigé</span></td>'
CARTES_RT = "GeForce RTX, Radeon RX 6000 ou plus récente, Intel Arc"


def cellule(ev):
    if getattr(ev, "bloque", ""):
        return CELLULE_RT
    if ev.niveau in NIVEAU:
        bas, haut = ev.fps[ev.niveau]
        classe = {"haute": "ok", "moyenne": "mi", "basse": "bas"}[ev.niveau]
        if ev.niveau == "basse" and bas < 55:
            classe = "juste"
        return (f'<td class="{classe}"><b>{NIVEAU[ev.niveau]}</b>'
                f'<span class="mono">{reglages.fourchette(bas, haut, "fr")}</span></td>')
    return '<td class="non"><b>Trop juste</b><span class="mono">moins de 30 i/s</span></td>'


def premiere(exig, pixels, definition, niveaux):
    """Carte la moins puissante de la liste qui atteint l'un des niveaux."""
    for cle, nom, vram in sorted(CARTES, key=lambda c: GPU[c[0]]):
        ev = evaluer(exig, cle, vram, pixels, definition)
        if ev.niveau in niveaux and ev.fps[ev.niveau][0] >= 55:
            return nom, ev
    return None, None


CSS = """
  /* ---------- pages Jeux ---------- */
  .liste-courte a{padding:12px 14px;}
  .liste-courte a span{display:block;color:var(--dim);font-size:13px;margin-top:2px;}
  .tete{padding-block:54px 22px;}
  .tete h1{font-size:clamp(32px,5.4vw,58px);line-height:1.02;font-weight:800;margin-top:10px;text-wrap:balance;}
  .tete .lede{color:var(--dim);max-width:68ch;margin-top:14px;font-size:18px;}
  .fil{font-size:14px;color:var(--dim);}
  .resume{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;margin-top:26px;}
  .resume div{background:var(--panel);border:1px solid var(--line);border-radius:var(--radius);padding:16px;}
  .resume span{display:block;color:var(--dim);font-size:14.5px;}
  .resume b{display:block;margin-top:6px;font-size:16.5px;line-height:1.35;overflow-wrap:anywhere;}
  .bloc{padding-block:34px 0;border-top:1px solid var(--line);margin-top:40px;}
  .bloc h2{font-size:clamp(22px,3.2vw,30px);text-wrap:balance;}
  .bloc > p{color:var(--dim);max-width:68ch;margin-top:10px;}
  .bloc > h3{margin-top:30px;font-size:clamp(19px,2.6vw,23px);}
  table.perf.menu td{font-size:15px;}
  .defile{overflow-x:auto;margin-top:20px;border:1px solid var(--line);border-radius:var(--radius);}
  table.perf{border-collapse:collapse;width:100%;min-width:560px;background:var(--panel);}
  table.perf th,table.perf td{padding:11px 14px;text-align:left;border-bottom:1px solid var(--line);}
  table.perf thead th{font-size:14.5px;color:var(--dim);font-weight:400;}
  table.perf tbody th{font-weight:700;font-size:15.5px;color:var(--ink);font-family:inherit;}
  table.perf tr:last-child th,table.perf tr:last-child td{border-bottom:0;}
  table.perf td b{display:block;}
  table.perf td span{display:block;font-size:13px;color:var(--dim);font-variant-numeric:tabular-nums;}
  table.perf td.ok b{color:#57D98A;} table.perf td.mi b{color:var(--accent);}
  table.perf td.bas b{color:#E8C25A;} table.perf td.juste b{color:#E8A05A;}
  table.perf td.non b{color:#E87070;}
  .configs{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px;margin-top:20px;}
  .configs article{background:var(--panel);border:1px solid var(--line);border-radius:var(--radius);padding:18px;}
  .configs h3{font-size:18px;}
  .configs dl{margin-top:10px;display:grid;gap:9px;}
  .configs dt{color:var(--dim);font-size:13.5px;}
  .configs dd{margin:2px 0 0;overflow-wrap:anywhere;}
  .appel{display:flex;flex-wrap:wrap;gap:14px;align-items:center;margin-top:18px;}
  .autres{display:flex;flex-wrap:wrap;gap:10px;margin-top:16px;}
  .autres a{border:1px solid var(--line);border-radius:999px;padding:7px 14px;font-size:14.5px;}
  .liste-jeux{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:14px;margin-top:22px;}
  .liste-jeux a{display:block;background:var(--panel);border:1px solid var(--line);border-radius:var(--radius);padding:16px;color:inherit;text-decoration:none;}
  .liste-jeux a:hover{border-color:var(--line-hi);}
  .liste-jeux b{display:block;font-size:17px;line-height:1.3;}
  .liste-jeux span{display:block;color:var(--dim);font-size:14px;margin-top:6px;}
  .liste-jeux a[hidden]{display:none;}
  /* visuels des jeux (12 octobre) : servis par le site, jamais par Steam */
  .liste-jeux a.avec-visuel{padding:0;overflow:hidden;}
  .liste-jeux a.avec-visuel img{display:block;width:100%;height:auto;aspect-ratio:460/215;object-fit:cover;background:var(--line);}
  .liste-jeux a.avec-visuel b{margin:12px 16px 0;}
  .liste-jeux a.avec-visuel span{margin:6px 16px 14px;}
  .tete-jeu{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,400px);gap:22px 36px;align-items:center;}
  .tete-jeu .visuel{display:block;width:100%;height:auto;aspect-ratio:460/215;object-fit:cover;border-radius:var(--radius);border:1px solid var(--line);background:var(--panel);}
  @media (max-width:860px){.tete-jeu{grid-template-columns:1fr;}.tete-jeu .visuel{order:-1;max-width:460px;margin-top:14px;}}
  .filtre{margin-top:26px;display:flex;flex-wrap:wrap;gap:12px;align-items:center;}
  .filtre input{flex:1 1 280px;max-width:460px;background:var(--panel);border:1px solid var(--line);border-radius:999px;padding:12px 18px;color:var(--ink);font:inherit;}
  .filtre input:focus{outline:2px solid var(--accent);outline-offset:2px;}
  .filtre span{color:var(--dim);font-size:14.5px;}
  /* prix releve chez le distributeur partenaire */
  .prix-gp{display:flex;flex-wrap:wrap;align-items:center;gap:16px 26px;margin-top:20px;background:var(--panel);border:1px solid var(--line-hi);border-radius:var(--radius);padding:20px 22px;}
  .prix-gp .pg-chiffres{display:flex;align-items:baseline;gap:12px;}
  .prix-gp .pg-final{font-size:34px;font-weight:700;color:#57D98A;font-variant-numeric:tabular-nums;line-height:1;}
  .prix-gp .pg-normal{color:var(--dim);font-size:17px;font-variant-numeric:tabular-nums;}
  .prix-gp .pg-remise{background:#57D98A;color:#07130C;font-weight:700;border-radius:8px;padding:3px 9px;font-size:15px;align-self:center;}
  .prix-gp .pg-texte{flex:1 1 240px;display:grid;gap:3px;}
  .prix-gp .pg-texte span{color:var(--dim);font-size:14.5px;}
  .pg-secours{display:none;}
  .prix-inconnu .pg-chiffres,.prix-inconnu .pg-date,.prix-inconnu .pg-resume{display:none;}
  .prix-inconnu .pg-secours{display:inline;}
"""


#: longueurs que Google affiche sans couper (11 octobre, audit : 631 titres
#: de pages de jeux et 777 descriptions depassaient)
TITRE_MAX, DESC_MAX = 60, 155


def ajuste(variantes, limite):
    """La premiere formulation qui tient dans `limite` caracteres, sinon la plus courte."""
    variantes = [v for v in variantes if v]
    return next((v for v in variantes if len(v) <= limite), min(variantes, key=len))


def gabarit(style, titre, desc, chemin, ld, corps, rubrique="jeux", image=""):
    ld_html = "\n".join('<script type="application/ld+json">' + json.dumps(x, ensure_ascii=False)
                        + "</script>" for x in ld)
    return f"""<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<script>if(/\\.pages\\.dev$/.test(location.hostname)){{location.replace("https://orion-launcher.com"+location.pathname+location.hash);}}</script>
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>{e(titre)}</title>
<meta name="description" content="{e(desc)}">
<meta name="robots" content="index, follow, max-image-preview:large">
<link rel="canonical" href="{SITE}{chemin}">
<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="icon" type="image/png" href="/img/logo.png">
<meta name="theme-color" content="#0C1122">
<meta property="og:type" content="article">
<meta property="og:site_name" content="ORION Game Launcher">
<meta property="og:locale" content="fr_FR">
<meta property="og:url" content="{SITE}{chemin}">
<meta property="og:title" content="{e(titre)}">
<meta property="og:description" content="{e(desc)}">
<meta property="og:image" content="{image or SITE + '/img/og.jpg'}">
<meta name="twitter:card" content="summary_large_image">
{ld_html}
<link rel="preload" href="/polices/bricolage.woff2" as="font" type="font/woff2" crossorigin>
<style>{style}
{CSS}</style>
</head>
<body>

<header class="nav">
  <div class="wrap nav-in">
    <a class="brand" href="/"><img src="/img/logo.png" alt="" width="30" height="30"><b>ORION</b></a>
    <nav>
      <a href="/">Le launcher</a>
      <a href="/jeux"{' aria-current="page"' if rubrique == "jeux" else ""}>Configs des jeux</a>
      <a href="/sorties"{' aria-current="page"' if rubrique == "sorties" else ""}>Sorties</a>
      <a href="/#faq">FAQ</a>
    </nav>
    <span class="sp"></span>
    <a class="btn" href="/#installer">Télécharger</a>
  </div>
</header>

<main class="wrap">
{corps}
</main>

<footer>
  <div class="wrap foot">
    <span class="sign">ORION lit votre PC et vous dit quoi jouer, avec quels réglages, à quel prix.</span>
    <span class="sp"></span>
    <nav aria-label="Liens du pied de page">
      <a href="/">Accueil</a>
      <a href="/jeux">Configs des jeux</a>
      <a href="/sorties">Sorties</a>
      <a href="/gratuits">Jeux gratuits</a>
      <a href="/gta-6-pc">GTA 6 PC</a>
      <a href="/black-friday">Black Friday</a>
      <a href="/soldes-steam">Soldes Steam</a>
      <a href="/augmenter-fps">Augmenter ses FPS</a>
      <a href="/jeux/peu-gourmands">Jeux peu gourmands</a>
      <a href="/config-pc-gamer-2026">Config PC gamer 2026</a>
      <a href="/mon-pc-peut-il-faire-tourner">Mon PC peut-il faire tourner ?</a>
      <a href="/pilotes">Pilotes par modèle</a>
      <a href="/versions">Journal des versions</a>
      <a href="/comparatif">Comparatif</a>
      <a href="/launcher-tous-les-jeux">Tous vos jeux, un launcher</a>
      <a href="/presse">Presse</a>
      <a href="/ce-qu-orion-envoie">Ce qu'ORION envoie</a>
      <a href="/mentions-legales">Mentions légales</a>
      <a href="https://www.tiktok.com/@oriongamelauncher" rel="me noopener">TikTok</a>
    </nav>
  </div>
</footer>
<script src="/glisse.js" defer></script>
<script src="/clic.js" defer></script>
<script src="/prix.js" defer></script>
<script src="/comparatif.js" defer></script>
</body>
</html>
"""


def liens_achat(nom):
    """Gamesplanet (officiel), puis les revendeurs de clés retenus par ORION,
    avec les mêmes adresses et identifiants partenaires que l'application."""
    from orion import marche_gris
    # pas de lien Gamesplanet pour un jeu qu'il ne vend pas (catalogue connu)
    officiel = [x for x in marche_gris.liens_officiels(nom) if x[0].id == "gamesplanet"] \
        if marche_gris.lien_gamesplanet(nom) else []
    return officiel + marche_gris.liens_revendeurs(nom)


NIVEAUX_FR = {"basse": "bas", "moyenne": "moyens", "haute": "élevés", "ultra": "ultra"}


def objectif_editeur(j) -> str:
    """Ce que l'objectif de l'editeur suppose, et la limite du jeu (13 octobre
    2026 : Monster Hunter Wilds, Elden Ring), en une ou deux phrases."""
    from orion.puissance.plafonds import limite
    exig, nom = j["exig"], j["nom"]
    ref, base = (exig.recommandee, "recommandée") if exig.recommandee and exig.recommandee.gpu else \
        (exig.minimum, "minimale")
    phrases = []
    if ref is not None:
        defaut = "haute" if base == "recommandée" else "basse"
        morceaux = []
        if ref.cible_niveau and ref.cible_niveau != defaut:
            morceaux.append(f"des réglages {NIVEAUX_FR[ref.cible_niveau]}")
        if ref.generation_images:
            morceaux.append("la génération d'images")
        if ref.rendu_px:
            morceaux.append("une mise à l'échelle de l'image (DLSS, FSR)")
        if morceaux:
            texte = (f"L'éditeur annonce sa configuration {base} pour "
                     + ", ".join(morceaux[:-1]) + (" et " if len(morceaux) > 1 else "") + morceaux[-1]
                     + " : l'estimation en tient compte")
            texte += (", la carte ne calculant qu'environ six des dix images affichées." if ref.generation_images
                      else ".")
            phrases.append(texte)
    if exig.ray_tracing:
        phrases.append(f"{nom} exige une carte graphique avec ray tracing matériel ({CARTES_RT}) : il ne se "
                       f"lance pas sur une GeForce GTX, une Radeon RX 5000 ou plus ancienne, ni sur une puce "
                       f"Intel HD, UHD ou Iris.")
    maxi = limite(j["appid"])
    if maxi:
        phrases.append(f"{nom} est limité à {maxi} images par seconde par le jeu lui-même : au-delà, une carte "
                       f"plus puissante n'apporte rien.")
    return " ".join(phrases)


def de(nom: str) -> str:
    """« d'Elden Ring », « de Cyberpunk 2077 » (13 octobre : « de Elden Ring »
    dans 1 100 descriptions)."""
    return ("d'" if unicodedata.normalize("NFD", nom[:1]).lower()[:1] in "aeiou" else "de ") + nom


def mon_pc(j, mini, rec) -> tuple[str, str]:
    """« Mon PC peut-il faire tourner X ? » (13 octobre) : la configuration
    minimale de l'editeur, telle qu'elle est ecrite sur la fiche, puis la
    recommandee. Rien d'estime ici : c'est la reponse de l'editeur."""
    nom = j["nom"]
    m, r = dict(j["min"]), dict(j["rec"])
    pieces = []
    if m.get("Processeur"):
        pieces.append("processeur : " + re.sub(r"^(processeur|cpu)\s*:?\s*", "", sans_point(m["Processeur"]), flags=re.I))
    if mini and mini.ram_go:
        pieces.append(f"mémoire vive : {mini.ram_go:g} Go")
    if m.get("Carte graphique"):
        pieces.append("carte graphique : " + re.sub(r"^(carte graphique|graphiques?|gpu)\s*:?\s*", "",
                                                     sans_point(m["Carte graphique"]), flags=re.I))
    if pieces:
        texte = f"Oui, s'il atteint au moins la configuration minimale de l'éditeur ({' ; '.join(pieces)})."
    else:
        texte = "La fiche officielle donne la configuration minimale ci-dessous."
    if r.get("Carte graphique") and r.get("Carte graphique") != m.get("Carte graphique"):
        texte += f" Configuration recommandée pour les réglages élevés : {sans_point(r['Carte graphique'])}."
    if j["exig"].ray_tracing:
        texte += f" Attention : la carte graphique doit calculer le ray tracing ({CARTES_RT})."
    texte += (" ORION, gratuit, fait la vérification sur votre propre PC et règle le jeu pour lui.")
    return f"Mon PC peut-il faire tourner {nom} ?", texte


def page_jeu(j, style, tous, auj, avec_page=None):
    exig, nom, s = j["exig"], j["nom"], j["slug"]
    rec, mini = exig.recommandee, exig.minimum
    estimable = j.get("estimable", True)
    lignes = []
    c1080 = cmin = ev3060 = ev4060 = None
    if estimable:
        for cle, carte, vram in CARTES:
            tds = "".join(cellule(evaluer(exig, cle, vram, px, d)) for _, d, px in DEFS)
            lignes.append(f'<tr><th scope="row"><a href="/jeux/carte/{slug(carte)}">{e(carte)}</a> '
                          f'<span class="mono" style="color:var(--dim);'
                          f'font-weight:400;font-size:13px">{vram} Go</span></th>{tds}</tr>')
        c1080, _ = premiere(exig, DEFS[0][2], DEFS[0][1], ("haute",))
        cmin, _ = premiere(exig, DEFS[0][2], DEFS[0][1], ("haute", "moyenne", "basse"))
        ev3060 = evaluer(exig, "rtx 3060", 12, DEFS[0][2], DEFS[0][1])
        ev4060 = evaluer(exig, "rtx 4060", 8, DEFS[0][2], DEFS[0][1])
    ram = (rec and rec.ram_go) or (mini and mini.ram_go)

    def phrase(carte, ev, definition):
        if getattr(ev, "bloque", ""):
            return (f"Une {carte} ne fait pas tourner {nom} : le jeu exige une carte graphique avec ray tracing "
                    f"matériel ({CARTES_RT}).")
        if ev.niveau in NIVEAU:
            bas, haut = ev.fps[ev.niveau]
            return (f"D'après notre estimation, une {carte} fait tourner {nom} en {definition} avec les "
                    f"réglages {NIVEAU[ev.niveau].lower()}, {reglages.fourchette(bas, haut, 'fr', 'long')}.")
        return (f"D'après notre estimation, une {carte} est trop juste pour {nom} en {definition} : "
                f"moins de 30 images par seconde, même avec les réglages au plus bas.")

    grec0 = dict(j["rec"]).get("Carte graphique")
    gmin0 = dict(j["min"]).get("Carte graphique")
    r1 = (f"L'éditeur recommande : {sans_point(grec0)}. " if grec0 else "")
    if not estimable:
        r1 += (f"Configuration minimale : {sans_point(gmin0)}. " if gmin0 and gmin0 != grec0 else "")
        r1 += ("La fiche officielle ne cite pas de carte précise des deux côtés : nous ne donnons "
               "pas d'estimation chiffrée pour ce jeu. ORION fait le calcul sur votre propre machine.")
    elif c1080:
        r1 += (f"D'après notre estimation prudente, les réglages élevés tiennent 60 images par seconde "
               f"en 1080p avec une {c1080}")
        r1 += (f", et il faut une {cmin} pour y arriver en baissant les réglages." if cmin and cmin != c1080
               else ".")
    else:
        r1 += ("D'après notre estimation prudente, aucune carte de notre liste ne tient 60 images par "
               "seconde en 1080p avec les réglages élevés.")
    faq = [mon_pc(j, mini, rec), (f"Quelle carte graphique pour jouer à {nom} en 1080p ?", r1)]
    if estimable:
        faq += [(f"Peut-on jouer à {nom} avec une RTX 3060 ?", phrase("GeForce RTX 3060", ev3060, "1080p")),
                (f"Combien de FPS sur {nom} avec une RTX 4060 ?", phrase("GeForce RTX 4060", ev4060, "1080p"))]
    if ram:
        faq.append((f"Combien de mémoire vive faut-il pour {nom} ?",
                    f"L'éditeur recommande {ram:g} Go de mémoire vive"
                    + (f" (minimum : {mini.ram_go:g} Go)." if mini and mini.ram_go and rec and rec.ram_go
                       and mini.ram_go != rec.ram_go else ".")))
    disque = dict(j["rec"]).get("Espace disque") or dict(j["min"]).get("Espace disque")
    if disque:
        faq.append((f"Quelle place {nom} prend-il sur le disque ?",
                    f"La fiche officielle demande {disque} d'espace disque."))
    if j.get("gp") and not j.get("gratuit"):
        faq.append((f"Où acheter {nom} au meilleur prix ?",
                    f"Gamesplanet, distributeur officiel, vend la clé {de(nom)} : son prix est relevé "
                    f"toutes les vingt minutes sur cette page. Les revendeurs de clés sont souvent moins "
                    f"chers ; prenez alors une clé Steam, région Global ou Europe, jamais d'offre "
                    f"« Gift » ni « Account »."))
    # meilleurs reglages selon la carte (12 octobre) : le profil « Recommande »
    conseils = reglages.conseils_du_jeu(exig, CARTES, DEFS[:2]) if estimable else {}
    question = reglages.faq(nom, conseils, DEFS, "fr") if conseils else None
    if question:
        faq.insert(2, question)
    faq_html = "\n".join(f"<details><summary>{e(q)}</summary><p>{e(r)}</p></details>" for q, r in faq)

    def bloc(titre, items):
        if not items:
            return ""
        dl = "".join(f"<div><dt>{e(k)}</dt><dd>{e(v)}</dd></div>" for k, v in items)
        return f"<article><h3>{titre}</h3><dl>{dl}</dl></article>"

    grec, gmin = dict(j["rec"]).get("Carte graphique"), dict(j["min"]).get("Carte graphique")
    resume = []
    if grec:
        resume.append(("Carte recommandée par l'éditeur", grec))
    if gmin:
        resume.append(("Carte minimale", gmin))
    if ram:
        resume.append(("Mémoire vive recommandée", f"{ram:g} Go"))
    if c1080:
        resume.append(("Notre estimation prudente", f"60 i/s en 1080p, réglages élevés, avec une {c1080}"))
    resume_html = "".join(f"<div><span>{e(k)}</span><b>{e(v)}</b></div>" for k, v in resume)
    if j.get("gp") and not j.get("gratuit"):
        resume_html += ('<div class="pg-resume"><span>Prix relevé chez Gamesplanet</span>'
                        f'<b class="pg-final">{euros(j["gp"]["prix"])}</b></div>')

    base = "recommandée" if rec and rec.gpu else "minimale"
    i = tous.index(j)
    autres = [x for x in tous if x["slug"] != s]
    miens = set(j["genres"])

    def proximite(k):
        x = autres[k]
        return (-len(miens & set(x["genres"])), (k - i) % max(len(autres), 1))
    voisins = [autres[k] for k in sorted(range(len(autres)), key=proximite)[:8]]
    achat_html = ""          # jeu gratuit : rien a acheter
    from orion.affiliation import lien_site
    achats_html = "\n".join(
        f'      <a href="{e(lien_site(url, "jeu"))}" rel="sponsored noopener">{e(site.nom)}'
        f'{" (boutique officielle)" if site.id == "gamesplanet" else " (clé Steam)"}</a>'
        for site, url in liens_achat(nom)
        if not (j.get("gp") and site.id == "gamesplanet"))
    gp = j.get("gp")
    prix_html = ""
    if gp:
        quand = time.localtime(gp["releve"])
        date = f"{date_fr(dt.date(quand.tm_year, quand.tm_mon, quand.tm_mday))} à {quand.tm_hour} h {quand.tm_min:02d}"
        remise = f'<span class="pg-remise">-{gp["remise"]} %</span>' if gp["remise"] else \
            '<span class="pg-remise" hidden></span>'
        normal = f'<s class="pg-normal">{euros(gp["normal"])}</s>' if gp["remise"] else \
            '<s class="pg-normal" hidden></s>'
        prix_html = f"""    <div class="prix-gp" id="prix-gp" data-appid="{e(j["appid"])}" data-slug="{e(gp["slug"])}" data-releve="{gp["releve"]}">
      <div class="pg-chiffres">{remise}{normal}<b class="pg-final">{euros(gp["prix"])}</b></div>
      <div class="pg-texte"><b>Chez Gamesplanet, distributeur officiel</b>
        <span>{e(gp["cle"])} officielle · <span class="pg-date">prix relevé le {date}</span><span class="pg-secours">prix à voir chez Gamesplanet</span></span></div>
      <a class="btn" href="{e(lien_site(gp["url"], "jeu"))}" rel="sponsored noopener">Voir l'offre</a>
    </div>
    <p><small>Ce prix est relevé automatiquement toutes les vingt minutes dans le catalogue que
      Gamesplanet fournit à ses partenaires. Le prix affiché chez Gamesplanet au moment de
      l'achat fait foi.{VERS_BONS_PLANS if gp["remise"] >= 30 else ""}</small></p>
"""
    if not j.get("gratuit"):
        achat_html = f"""  <section class="bloc">
    <p class="eyebrow">Où l'acheter</p>
    <h2>{("Prix " + e(de(nom)) + " : où l'acheter au meilleur prix") if gp else ("Acheter " + e(nom) + " au meilleur prix")}</h2>
    <p>La boutique officielle d'abord. Les revendeurs de clés sont souvent moins chers :
      prenez une clé Steam, région Global ou Europe, jamais d'offre « Gift » ni « Account ».</p>
{prix_html}    <div data-comparatif data-auto="1" data-appid="{e(j["appid"])}" data-titre="{e(nom)}"></div>
    <div class="autres">
      <a href="https://store.steampowered.com/app/{e(j["appid"])}/" rel="noopener nofollow">Steam (boutique officielle)</a>
{achats_html}
    </div>
    <p><small>Gamesplanet, Instant Gaming, Kinguin et Loaded sont des liens partenaires : ils
      financent ORION sans changer le prix que vous payez.</small></p>
  </section>

"""
    autres_html = "".join(f'<a href="/jeux/{x["slug"]}">{e(x["nom"])}</a>' for x in voisins)
    # seulement les genres qui ont leur page (11 octobre : « free-to-play »,
    # moins de cinq jeux, menait a une page absente)
    genres_html = " · ".join(f'<a href="/jeux/genre/{slug(g)}">jeux {e(g)}</a>' for g in j["genres"][:4]
                             if avec_page is None or g in avec_page)

    avec_prix = bool(j.get("gp")) and not j.get("gratuit")
    if estimable:
        estim_html = f"""  <section class="bloc">
    <p class="eyebrow">Estimation par carte graphique</p>
    <h2>Paramètres et FPS estimés pour votre carte graphique</h2>
    <p>Pour chaque carte : le niveau de réglages le plus élevé qui reste fluide, et la fourchette
      d'images par seconde attendue. C'est une estimation prudente calculée depuis la configuration
      {base} de l'éditeur, pas une mesure : le processeur, les pilotes et les mises à jour du jeu
      la font varier.</p>
    <div class="defile">
      <table class="perf">
        <thead><tr><th scope="col">Carte graphique</th><th scope="col">1080p</th>
          <th scope="col">1440p</th><th scope="col">4K</th></tr></thead>
        <tbody>
{chr(10).join(lignes)}
        </tbody>
      </table>
    </div>
    <p>Sans DLSS, FSR ni génération d'images : les activer augmente nettement le nombre d'images
      quand le jeu les propose.{(" " + e(objectif_editeur(j))) if objectif_editeur(j) else ""}</p>
  </section>

"""
        if conseils:
            estim_html += reglages.section(nom, j["appid"], conseils, CARTES, DEFS[:2], "fr")
        # « paramètres » et « FPS » (13 octobre) : ce que cherchent les joueurs
        # (« paramètres monster hunter wilds », Search Console) ; le prix reste
        # dans la description
        titre = ajuste([f"{nom} : configuration requise, paramètres et FPS",
                        f"{nom} : config requise, paramètres et FPS",
                        f"{nom} : config PC, paramètres et FPS",
                        f"{nom} : configuration requise PC", f"{nom} : config requise PC",
                        f"{nom} config PC", f"{nom} config"] + seul(nom), TITRE_MAX)
        desc = ajuste([f"Configuration minimale et recommandée {de(nom)}, meilleurs paramètres et FPS estimés sur "
                       f"{NB_CARTES} cartes graphiques (RTX 4060, RX 7600…), de 1080p à 4K."
                       + (" Prix du jour." if avec_prix else ""),
                       f"Configuration minimale et recommandée {de(nom)}, meilleurs paramètres et FPS estimés sur "
                       f"{NB_CARTES} cartes graphiques (RTX 4060, RX 7600…), de 1080p à 4K.",
                       f"Configuration requise {de(nom)}, meilleurs paramètres et FPS estimés sur {NB_CARTES} "
                       f"cartes graphiques, de 1080p à 4K.",
                       f"Config requise {de(nom)}, paramètres et FPS sur {NB_CARTES} cartes graphiques, de 1080p à 4K."],
                      DESC_MAX)
        methode_html = """    <details><summary>Comment ces estimations sont-elles calculées ?</summary><p>La configuration
      recommandée par l'éditeur sert de repère (environ 60 images par seconde en 1080p, réglages
      élevés, sauf indication contraire de l'éditeur). La puissance de chaque carte est comparée à
      celle de la carte recommandée (la moyenne, quand l'éditeur en cite plusieurs), puis ajustée à
      la définition de l'écran. Une marge basse est
      retenue, et une mémoire vidéo inférieure à la recommandation fait descendre d'un niveau.</p></details>
"""
    else:
        estim_html = """  <section class="bloc">
    <p class="eyebrow">Estimation par carte graphique</p>
    <h2>Pas d'estimation chiffrée pour ce jeu</h2>
    <p>La fiche officielle ne cite pas de carte graphique précise des deux côtés (minimale et
      recommandée). Plutôt qu'un chiffre inventé, nous n'en donnons aucun. ORION fait le calcul sur
      votre propre machine, avec votre carte, votre processeur et votre écran, puis mesure les images
      par seconde réelles pendant que vous jouez.</p>
  </section>

"""
        titre = ajuste([f"{nom} : configuration requise et prix PC" if avec_prix else "",
                        f"{nom} : configuration requise PC", f"{nom} : config requise PC",
                        f"{nom} config PC", f"{nom} config"] + seul(nom), TITRE_MAX)
        detail = ((f" : {ram:g} Go de mémoire vive" if ram else "")
                  + (f", carte {grec0 or gmin0}" if (grec0 or gmin0) else ""))
        desc = ajuste([f"Configuration minimale et recommandée {de(nom)} sur PC, relevée sur la fiche officielle"
                       f"{detail}." + (" Prix du jour." if avec_prix else ""),
                       f"Configuration minimale et recommandée {de(nom)} sur PC, relevée sur la fiche officielle"
                       f"{detail}.",
                       f"Configuration minimale et recommandée {de(nom)} sur PC{detail}.",
                       f"Configuration minimale et recommandée {de(nom)} sur PC, fiche officielle."], DESC_MAX)
        methode_html = ""
    # en promo (13 octobre) : le prix d'abord dans la description, celle que
    # Google affiche sous le titre (« Resident Evil 4 promo », « prix »)
    if gp and avec_prix and gp["remise"] >= 30:
        promo = f"En promo à {euros(gp['prix'])} (-{gp['remise']} %) chez Gamesplanet. "
        desc = ajuste([promo + desc,
                       promo + f"Config requise {de(nom)}, paramètres et FPS sur {NB_CARTES} cartes graphiques."
                       if estimable else "",
                       promo + (f"Config requise {de(nom)}, paramètres et FPS." if estimable
                                else f"Config requise {de(nom)} sur PC."),
                       promo + f"Config requise {de(nom)}.", desc], DESC_MAX)
    genres = ", ".join(j["genres"])
    titre_html = f"""<h1>{e(nom)} : configuration requise{", paramètres et FPS" if estimable else ""} sur PC</h1>
    <p class="lede">{e(nom)}, développé par {e(j["dev"])} (genre : {e(genres)}), est sorti sur Steam le {e(j["date"])}.
      Voici la configuration officielle, et ce qu'elle donne sur les cartes graphiques les plus répandues.</p>"""
    image = visuel(j["appid"], "visuel", "eager")
    if image:
        titre_html = f"""<div class="tete-jeu">
      <div>
    {titre_html}
      </div>
      {image}
    </div>"""
    corps = f"""  <div class="tete">
    <p class="fil"><a href="/">ORION</a> › <a href="/jeux">Configs des jeux</a> › {e(nom)}</p>
    {titre_html}
    <div class="resume">{resume_html}</div>
  </div>

{estim_html}
  <section class="bloc">
    <p class="eyebrow">Fiche officielle</p>
    <h2>Configuration minimale et recommandée</h2>
    <div class="configs">
      {bloc("Minimale", j["min"])}
      {bloc("Recommandée", j["rec"])}
    </div>
    <p>Source : <a href="https://store.steampowered.com/app/{e(j["appid"])}/" rel="noopener nofollow">fiche
      Steam du jeu</a>, relevée le {date_fr(auj)}.</p>
  </section>

{achat_html}  <section class="bloc">
    <p class="eyebrow">Sur votre PC</p>
    <h2>Le calcul pour votre machine, et les réglages appliqués</h2>
    <p>ORION est un launcher gratuit pour Windows. Il fait ce calcul avec votre carte, votre
      processeur et votre écran, mesure les images par seconde réelles pendant que vous jouez, et
      règle le jeu pour vous avec son profil « Recommandé ». Sans compte, sans publicité.</p>
    <div class="appel">
      <a class="btn" href="{EXE}">Télécharger ORION pour Windows</a>
      <a class="btn ghost" href="/">Découvrir le launcher</a>
    </div>
  </section>

  <section class="bloc">
    <p class="eyebrow">Questions fréquentes</p>
    <h2>{e(nom)} en bref</h2>
{faq_html}
{methode_html}  </section>

  <section class="bloc">
    <p class="eyebrow">Autres jeux</p>
    <h2>Voir la configuration d'un autre jeu</h2>
    <div class="autres">{autres_html}<a href="/jeux">Tous les jeux</a></div>
{f"    <p>Par genre : {genres_html}</p>{chr(10)}" if genres_html else ""}  </section>"""
    jeu_ld = {"@context": "https://schema.org", "@type": "VideoGame", "name": nom,
              "url": f"{SITE}/jeux/{s}", "gamePlatform": "PC", "operatingSystem": "Windows",
              "applicationCategory": "Game", "genre": j["genres"],
              "author": {"@type": "Organization", "name": j["dev"]}}
    if str(j["appid"]) in VISUELS:
        jeu_ld["image"] = image_og(j["appid"])      # le visuel du site, pas l'adresse de Steam
    elif j.get("img"):
        jeu_ld["image"] = j["img"]
    if avec_prix:
        jeu_ld["offers"] = {"@type": "Offer", "price": f'{j["gp"]["prix"]:.2f}', "priceCurrency": "EUR",
                            "url": j["gp"]["url"], "availability": "https://schema.org/InStock",
                            "seller": {"@type": "Organization", "name": "Gamesplanet"}}
    ld = [
        jeu_ld,
        {"@context": "https://schema.org", "@type": "FAQPage",
         "mainEntity": [{"@type": "Question", "name": q,
                         "acceptedAnswer": {"@type": "Answer", "text": r}} for q, r in faq]},
        {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [
            {"@type": "ListItem", "position": 1, "name": "ORION", "item": SITE + "/"},
            {"@type": "ListItem", "position": 2, "name": "Configs des jeux", "item": SITE + "/jeux"},
            {"@type": "ListItem", "position": 3, "name": nom, "item": f"{SITE}/jeux/{s}"}]},
    ]
    return gabarit(style, titre, desc, f"/jeux/{s}", ld, corps, image=image_og(j["appid"]))


#: etiquettes Steam qui ne sont pas des genres de jeu (logiciels passes entre les mailles)
PAS_UN_GENRE = {"jeu", "utilitaires", "conception et illustration", "production audio", "éducation",
                "montage vidéo", "formation", "développement de jeux", "publication web", "comptabilité",
                "animation et modélisation", "édition photo", "logiciels", "software training"}


def genres_de(jeux):
    """{genre: [jeux]} pour les genres qui ont au moins cinq jeux, les plus
    fournis d'abord."""
    par = {}
    for j in jeux:
        for g in j["genres"]:
            if g and g.lower() not in PAS_UN_GENRE:
                par.setdefault(g, []).append(j)
    return dict(sorted(((g, l) for g, l in par.items() if len(l) >= 5),
                       key=lambda gl: (-len(gl[1]), gl[0])))


def carte_jeu(j, sous=None):
    if sous is None:
        sous = ("Carte recommandée : " + " ou ".join(j["cites"][:2])) if j["cites"] else \
            "Configuration officielle" + (" et estimations" if j.get("estimable", True) else "")
    img = visuel(j["appid"])
    classe = ' class="avec-visuel"' if img else ""
    return f'<a href="/jeux/{j["slug"]}"{classe}>{img}<b>{e(j["nom"])}</b><span>{e(sous)}</span></a>'


def page_liste(jeux, style, auj, chemin, titre, desc, eyebrow, h1, lede, cartes, fil=None,
               avant="", nom_fil="Configs des jeux"):
    """Une page de liste (index, genre, carte graphique) : meme gabarit, meme filtre."""
    fil_html = (f'    <p class="fil"><a href="/">ORION</a> › <a href="/jeux">Configs des jeux</a> › {e(fil)}</p>\n'
                if fil else "")
    corps = f"""  <div class="tete">
{fil_html}    <p class="eyebrow">{e(eyebrow)}</p>
    <h1>{h1}</h1>
    <p class="lede">{lede}
      Mise à jour le {date_fr(auj)}.</p>
  </div>
{avant}  <section>
    <div class="filtre" id="filtre" hidden>
      <input type="search" id="filtre-jeux" placeholder="Chercher un jeu…" aria-label="Chercher un jeu dans la liste" autocomplete="off">
      <span id="filtre-compte"></span>
    </div>
    <div class="liste-jeux" id="liste-jeux">
{chr(10).join(cartes)}
    </div>
  </section>
  <section class="bloc">
    <p class="eyebrow">Sur votre PC</p>
    <h2>Le même calcul, avec votre vrai matériel</h2>
    <p>ORION est un launcher gratuit pour Windows. Il reconnaît votre carte graphique, votre
      processeur et votre écran, estime chaque jeu de votre bibliothèque, puis remplace
      l'estimation par des mesures réelles dès que vous jouez.</p>
    <div class="appel">
      <a class="btn" href="{EXE}">Télécharger ORION pour Windows</a>
      <a class="btn ghost" href="/">Découvrir le launcher</a>
    </div>
  </section>"""
    corps += """
  <script>
  (function () {
    var liens = document.querySelectorAll("#liste-jeux a"), boite = document.getElementById("filtre");
    var champ = document.getElementById("filtre-jeux"), compte = document.getElementById("filtre-compte");
    if (!boite || liens.length < 40) { return; }
    boite.hidden = false;
    function plat(t) { return t.normalize("NFD").replace(/[\\u0300-\\u036f]/g, "").toLowerCase(); }
    var noms = Array.prototype.map.call(liens, function (a) { return plat(a.querySelector("b").textContent); });
    function filtrer() {
      var q = plat(champ.value.trim()), n = 0;
      Array.prototype.forEach.call(liens, function (a, i) {
        var vu = !q || noms[i].indexOf(q) !== -1;
        a.hidden = !vu;
        if (vu) { n += 1; }
      });
      compte.textContent = q ? n + (n > 1 ? " jeux trouvés" : " jeu trouvé") : liens.length + " jeux";
    }
    champ.addEventListener("input", filtrer);
    filtrer();
  }());
  </script>"""
    miettes = [{"@type": "ListItem", "position": 1, "name": "ORION", "item": SITE + "/"},
               {"@type": "ListItem", "position": 2, "name": "Configs des jeux", "item": SITE + "/jeux"}]
    if fil:
        miettes.append({"@type": "ListItem", "position": 3, "name": fil, "item": SITE + chemin})
    ld = [
        {"@context": "https://schema.org", "@type": "ItemList", "name": h1_texte(h1),
         "itemListElement": [{"@type": "ListItem", "position": i + 1, "name": j["nom"],
                              "url": f"{SITE}/jeux/{j['slug']}"} for i, j in enumerate(jeux)]},
        {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": miettes},
    ]
    return gabarit(style, titre, desc, chemin, ld, corps)


def h1_texte(h):
    return html.unescape(re.sub(r"<[^>]+>", "", h))


def page_index(jeux, style, auj, genres, cartes_gpu):
    """/jeux : tous les jeux, puis les entrees par genre et par carte graphique."""
    liens_g = "".join(f'<a href="/jeux/genre/{slug(g)}">{e(g)} <span>{len(l)} jeux</span></a>'
                      for g, l in genres.items())
    liens_c = "".join(f'<a href="/jeux/carte/{slug(nom)}">{e(nom)} <span>{vram} Go</span></a>'
                      for _, nom, vram in cartes_gpu)
    liens_t = "".join(f'<a href="/jeux/{k}">{e(t["fil"])} <span>{len(selection_type(k, jeux))} jeux</span></a>'
                      for k, t in TYPES_PC.items())
    avant = f"""  <section class="bloc">
    <p class="eyebrow">Par genre</p>
    <h2>Les configurations par genre de jeu</h2>
    <div class="liste-jeux liste-courte">{liens_g}</div>
  </section>
  <section class="bloc">
    <p class="eyebrow">Par carte graphique</p>
    <h2>Quels jeux tournent sur votre carte ?</h2>
    <p>Pour chaque carte courante : les réglages et les images par seconde estimés, jeu par jeu.</p>
    <div class="liste-jeux liste-courte">{liens_c}</div>
  </section>
  <section class="bloc">
    <p class="eyebrow">Par type de PC</p>
    <h2>Petite config, PC portable, sans carte graphique</h2>
    <div class="liste-jeux liste-courte">{liens_t}</div>
  </section>
"""
    n_est = sum(1 for j in jeux if j.get("estimable", True))
    return page_liste(
        jeux, style, auj, "/jeux",
        "Configuration requise des jeux PC : quelle carte graphique ?",
        f"Configuration requise et réglages conseillés de {len(jeux)} jeux PC (Cyberpunk 2077, Elden Ring, "
        f"Battlefield 6…), estimés par carte graphique de 1080p à 4K.",
        f"Configs des jeux · {len(jeux)} jeux", "Votre PC fait-il tourner ce jeu ?",
        f"Pour chaque jeu : la configuration officielle et, pour {n_est} d'entre eux, le niveau de "
        f"réglages que l'on peut attendre de {NB_CARTES} cartes graphiques courantes, en 1080p, 1440p et 4K. "
        f"Les chiffres sont des estimations prudentes, calculées avec le moteur d'estimation du "
        f"launcher ORION.",
        [carte_jeu(j) for j in jeux], avant=avant)


def page_genre(genre, jeux, style, auj):
    chemin = f"/jeux/genre/{slug(genre)}"
    noms = ", ".join(j["nom"] for j in jeux[:4])
    return page_liste(
        jeux, style, auj, chemin,
        ajuste([f"Jeux {genre} PC : configuration requise ({len(jeux)} jeux)",
                f"Jeux {genre} PC : configuration requise", f"Jeux {genre} : config PC"], TITRE_MAX),
        ajuste([f"Configuration minimale et recommandée de {len(jeux)} jeux {genre} sur PC ({noms}…), "
                f"réglages estimés par carte graphique et prix du jour.",
                f"Configuration minimale et recommandée de {len(jeux)} jeux {genre} sur PC, réglages "
                f"estimés par carte graphique et prix du jour."], DESC_MAX),
        f"Jeux {genre} · {len(jeux)} jeux", f"Quelle configuration pour les jeux {e(genre)} ?",
        f"Les jeux {e(genre)} de notre catalogue, avec leur configuration officielle et, quand la "
        f"fiche le permet, les réglages estimés pour {NB_CARTES} cartes graphiques.",
        [carte_jeu(j) for j in jeux], fil=f"Jeux {genre}")


def page_carte(cle, nom, vram, jeux, style, auj):
    """/jeux/carte/<carte> : pour chaque jeu estimable, les reglages et les
    images par seconde attendus avec cette carte, en 1080p et 1440p."""
    chemin = f"/jeux/carte/{slug(nom)}"
    lignes, tient, juste, bloques = [], 0, 0, 0
    for j in jeux:
        if not j.get("estimable", True):
            continue
        ev1, ev2 = (evaluer(j["exig"], cle, vram, px, d) for _, d, px in DEFS[:2])
        if ev1.bloque:
            sous = "ne se lance pas : ray tracing matériel exigé"
            bloques += 1
        elif ev1.niveau in NIVEAU:
            bas, haut = ev1.fps[ev1.niveau]
            sous = f"1080p : {NIVEAU[ev1.niveau].lower()}, {reglages.fourchette(bas, haut, 'fr')}"
            if ev2.niveau in NIVEAU:
                b2, h2 = ev2.fps[ev2.niveau]
                sous += f" · 1440p : {NIVEAU[ev2.niveau].lower()}, {reglages.fourchette(b2, h2, 'fr')}"
            else:
                sous += " · 1440p : trop juste"
            tient += 1
        else:
            sous = "1080p : trop juste, moins de 30 i/s même au plus bas"
            juste += 1
        lignes.append(carte_jeu(j, sous))
    # « 565 tournent, 0 sont trop justes » (13 octobre) : la phrase suit les nombres
    bilan = ("Tous tournent" if not juste and not bloques else
             f"{tient} jeu{'x' if tient > 1 else ''} tourne{'nt' if tient > 1 else ''}"
             + (f", {juste} {'sont trop justes' if juste > 1 else 'est trop juste'}" if juste else "")
             + (f", {bloques} ne se lance{'nt' if bloques > 1 else ''} pas (ray tracing exigé)" if bloques else ""))
    # pour la description (155 caracteres) : sans la parenthese
    bilan_court = bilan.replace(" (ray tracing exigé)", "")
    juste += bloques
    return page_liste(
        [j for j in jeux if j.get("estimable", True)], style, auj, chemin,
        ajuste([f"{nom} : quels jeux tournent, FPS et réglages",
                f"Quels jeux tournent sur une {nom} ? ({tient + juste} jeux)",
                f"Jeux qui tournent sur une {nom}", f"{nom} : quels jeux ?"], TITRE_MAX),
        ajuste([f"{nom} ({vram} Go) : pour {tient + juste} jeux PC, le niveau de réglages et les images par "
                f"seconde estimés en 1080p et 1440p. {bilan}.",
                f"{nom} ({vram} Go) : réglages et images par seconde estimés pour {tient + juste} jeux PC en "
                f"1080p et 1440p. {bilan}.",
                f"{nom} ({vram} Go) : réglages et FPS estimés pour {tient + juste} jeux PC en 1080p et 1440p. "
                f"{bilan}.",
                f"{nom} ({vram} Go) : réglages et FPS estimés pour {tient + juste} jeux PC. {bilan_court}.",
                f"{nom} : réglages et FPS estimés pour {tient + juste} jeux PC. {bilan_court}."], DESC_MAX),
        f"{nom} · {tient + juste} jeux", f"Que fait tourner une {e(nom)} ?",
        f"Pour chaque jeu, le niveau de réglages le plus élevé qui reste fluide avec une {e(nom)} "
        f"({vram} Go de mémoire vidéo), et la fourchette d'images par seconde attendue, en 1080p puis "
        f"1440p. Estimation prudente depuis la configuration recommandée par l'éditeur, sans DLSS ni "
        f"FSR ; {bilan[0].lower() + bilan[1:]}.",
        lignes, fil=nom)


#: pages par type de PC (13 octobre : « jeux peu gourmands », « jeux PC
#: portable », « jeux sans carte graphique », des recherches courantes sans
#: page sur le site). Meme moteur que les pages de carte, sur des puces
#: modestes, avec 16 Go de memoire vive (un PC courant). L'indice d'une puce
#: est celui que l'application donne au nom que Windows lui donne
#: (`indice_gpu`) : le calcul est celui qu'ORION ferait sur ce PC.
#: (nom affiche, nom Windows, memoire video, definition)
TYPES_PC = {
    "peu-gourmands": {
        "fil": "Jeux peu gourmands",
        "puces": [("GTX 1650 en 1080p", "NVIDIA GeForce GTX 1650", 4, DEFS[0])],
        "fluide": True,                # « peu gourmand » : 60 images/s, pas seulement jouable
        "titres": ["Jeux PC peu gourmands : {n} jeux pour petite config", "Jeux PC peu gourmands ({n} jeux)",
                   "Jeux PC peu gourmands"],
        "desc": ["{n} jeux PC peu gourmands qui tournent à 60 images par seconde sur une petite config (GTX 1650, "
                 "16 Go de mémoire vive) : réglages et FPS estimés, jeu par jeu.",
                 "{n} jeux PC peu gourmands qui tournent à 60 images par seconde sur une petite config (GTX 1650, "
                 "16 Go) : réglages et FPS estimés, jeu par jeu."],
        "h1": "Jeux PC peu gourmands : ce qui tourne sur une petite config",
        "lede": "Les jeux de notre catalogue qu'une GeForce GTX 1650 (4 Go) fait tourner à 60 images par "
                "seconde en 1080p, avec 16 Go de mémoire vive : une configuration d'entrée de gamme encore "
                "très répandue. Les plus joués d'abord, avec le niveau de réglages et la fourchette d'images "
                "par seconde estimés.",
    },
    "pc-portable": {
        "fil": "Jeux pour PC portable",
        "puces": [("RTX 3050 portable", "NVIDIA GeForce RTX 3050 Laptop GPU", 4, DEFS[0]),
                  ("RTX 4050 portable", "NVIDIA GeForce RTX 4050 Laptop GPU", 6, DEFS[0])],
        "titres": ["Jeux pour PC portable : {n} jeux qui tournent bien", "Jeux pour PC portable ({n} jeux)",
                   "Jeux pour PC portable"],
        "desc": ["{n} jeux qui tournent sur un PC portable gamer d'entrée de gamme (RTX 3050 ou 4050 portable) : "
                 "réglages et images par seconde estimés en 1080p.",
                 "{n} jeux qui tournent sur un PC portable gamer (RTX 3050 ou 4050 portable) : réglages et FPS "
                 "estimés en 1080p."],
        "h1": "Jeux pour PC portable : ce qui tourne sur un portable gamer",
        "lede": "Les jeux de notre catalogue qu'une GeForce RTX 3050 portable fait tourner en 1080p à 30 images "
                "par seconde ou plus, avec 16 Go de mémoire vive, et ce que donne une RTX 4050 portable. Le "
                "calcul est celui d'ORION pour ces puces de portable, moins puissantes que les cartes de "
                "bureau du même nom. Branchez le portable sur secteur : sur batterie, il joue moins vite.",
    },
    "sans-carte-graphique": {
        "fil": "Jeux sans carte graphique",
        "puces": [("Radeon 780M en 1080p", "AMD Radeon 780M Graphics", 0, DEFS[0]),
                  ("Iris Xe en 720p", "Intel(R) Iris(R) Xe Graphics", 0, ("720p", "1280x720", 1280 * 720))],
        "titres": ["Jeux sans carte graphique : {n} jeux PC jouables", "Jeux PC sans carte graphique ({n} jeux)",
                   "Jeux PC sans carte graphique"],
        "desc": ["{n} jeux PC jouables sans carte graphique, sur la puce du processeur (Radeon 780M, Intel Iris "
                 "Xe) : réglages et images par seconde estimés.",
                 "{n} jeux PC jouables sans carte graphique (Radeon 780M, Intel Iris Xe) : réglages et FPS estimés."],
        "h1": "Jeux sans carte graphique : jouer avec la puce du processeur",
        "lede": "Les jeux de notre catalogue que la puce graphique d'un processeur récent (AMD Radeon 780M, celle "
                "des Ryzen 7 7840U, 7840HS, 8840U et 8700G) fait tourner en 1080p à 30 "
                "images par seconde ou plus, et ce qu'en tire une Intel Iris Xe, la puce de la plupart des "
                "portables de bureautique, en 720p. Avec 16 Go de mémoire vive, de préférence en deux barrettes.",
    },
}


def evaluer_puce(exig, nom_windows, vram, definition, ram=16):
    """Estimation pour une puce designee par son nom Windows (portable,
    graphiques integres), avec la memoire vive d'un PC courant."""
    from orion.puissance.references import indice_gpu
    _, indice = indice_gpu(nom_windows)
    _, d, px = definition
    m = Machine(gpu=indice, gpu_nom=nom_windows, vram_go=vram or None, ram_go=ram, pixels=px, definition=d)
    return estimer(exig.titre, exig, m)


def selection_type(cle, jeux):
    """[(jeu, texte sous le nom)] des jeux qui tournent sur la premiere puce du
    type de PC, les plus joues d'abord."""
    t = TYPES_PC[cle]
    choisis = []
    for j in jeux:
        if not j.get("estimable", True):
            continue
        evs = [evaluer_puce(j["exig"], nw, vram, df) for _, nw, vram, df in t["puces"]]
        if evs[0].niveau not in NIVEAU or (t.get("fluide") and not evs[0].fluide):
            continue
        morceaux = []
        for (court, *_), ev in zip(t["puces"], evs):
            if ev.niveau in NIVEAU:
                bas, haut = ev.fps[ev.niveau]
                morceaux.append(f"{court} : {NIVEAU[ev.niveau].lower()}, {reglages.fourchette(bas, haut, 'fr')}")
            elif ev.bloque:
                morceaux.append(f"{court} : ne se lance pas")
            else:
                morceaux.append(f"{court} : trop juste")
        choisis.append((j, " · ".join(morceaux), sum(ev.niveau in NIVEAU for ev in evs)))
    # jouables sur toutes les puces d'abord (l'Iris Xe avant la seule 780M), puis les plus joues
    choisis.sort(key=lambda x: (-x[2], -x[0].get("avis", 0), x[0]["nom"].lower()))
    return [(j, sous) for j, sous, _ in choisis]


def page_type(cle, jeux, style, auj):
    t = TYPES_PC[cle]
    choisis = selection_type(cle, jeux)
    n = len(choisis)
    autres = " · ".join(f'<a href="/jeux/{k}">{e(x["fil"][:1].lower() + x["fil"][1:])}</a>'
                        for k, x in TYPES_PC.items() if k != cle)
    avant = f"""  <section class="bloc">
    <p class="eyebrow">Comment lire cette liste</p>
    <p>Pour chaque jeu : le niveau de réglages le plus élevé qui reste jouable, et la fourchette d'images
      par seconde attendue. C'est une estimation prudente, calculée depuis la configuration recommandée
      par l'éditeur, sans DLSS ni FSR : les activer donne nettement plus d'images quand le jeu les propose.
      Le processeur, les pilotes et la température du PC la font varier ; ORION mesure les vraies images
      par seconde pendant que vous jouez. Voir aussi : {autres}, et <a href="/augmenter-fps">comment
      gagner des FPS</a>.</p>
  </section>
"""
    return page_liste(
        [j for j, _ in choisis], style, auj, f"/jeux/{cle}",
        ajuste([x.format(n=n) for x in t["titres"]], TITRE_MAX),
        ajuste([x.format(n=n) for x in t["desc"]], DESC_MAX),
        f"{t['fil']} · {n} jeux", e(t["h1"]), e(t["lede"]),
        [carte_jeu(j, sous) for j, sous in choisis], fil=t["fil"], avant=avant)


PRIX_JS = r"""/* Pages de jeux : remplace le prix Gamesplanet releve a la generation de la
   page par celui du dernier releve (toutes les vingt minutes). Si le releve
   ne repond pas, le prix de la page reste affiche avec sa date tant qu'il a
   moins de deux jours ; au-dela, il est retire plutot que de risquer un prix
   faux. Aucune donnee du visiteur n'est envoyee. */
(function () {
  "use strict";
  var bloc = document.getElementById("prix-gp");
  if (!bloc || !window.fetch) { return; }
  var appid = parseInt(bloc.getAttribute("data-appid"), 10);
  var slug = bloc.getAttribute("data-slug");
  var releve = parseInt(bloc.getAttribute("data-releve"), 10) || 0;
  var PERIME = 8 * 3600, VIEUX = 48 * 3600;
  function euros(v) { return v.toFixed(2).replace(".", ",") + "\u00a0\u20ac"; }
  function tous(selecteur, f) {
    Array.prototype.forEach.call(document.querySelectorAll(selecteur), f);
  }
  function sansPrix() { document.documentElement.classList.add("prix-inconnu"); }
  function ilYA(secondes) {
    var m = Math.max(0, Math.round(secondes / 60));
    if (m < 2) { return "\u00e0 l'instant"; }
    if (m < 90) { return "il y a " + m + " minutes"; }
    return "il y a " + Math.round(m / 60) + " heures";
  }
  function poser(produit, age) {
    var prix = Number(produit[1]), normal = Number(produit[2]);
    if (!(prix > 0 && prix <= normal && normal < 1000)) { sansPrix(); return; }
    var remise = normal > prix ? Math.round(100 - prix * 100 / normal) : 0;
    tous(".pg-final", function (el) { el.textContent = euros(prix); });
    tous(".pg-normal", function (el) { el.textContent = remise ? euros(normal) : ""; el.hidden = !remise; });
    tous(".pg-remise", function (el) { el.textContent = remise ? "-" + remise + " %" : ""; el.hidden = !remise; });
    tous(".pg-date", function (el) { el.textContent = "prix relev\u00e9 " + ilYA(age); });
  }
  if (!(appid > 0) || !slug) { return; }
  fetch("https://raw.githubusercontent.com/Sikher-kisa/orion-game-launcher/donnees/prix/" +
        ("0" + (Math.floor(appid / 10) % 100)).slice(-2) + ".json")
    .then(function (r) { if (!r.ok) { throw new Error("releve"); } return r.json(); })
    .then(function (d) {
      var age = Date.now() / 1000 - Number(d.releve);
      if (!(age > -3600 && age < PERIME)) { throw new Error("perime"); }
      var produits = (d.jeux || {})[String(appid)] || [], i;
      for (i = 0; i < produits.length; i += 1) {
        if (produits[i][3] === slug) { poser(produits[i], age); return; }
      }
      sansPrix();                       // le jeu n'est plus vendu sous cette fiche
    })
    .catch(function () {
      if (Date.now() / 1000 - releve > VIEUX) { sansPrix(); }
    });
}());
"""


#: pages de logiciels retirees de la liste (redirigees vers /jeux)
RETIRES: list[str] = []
#: idem pour les pages anglaises (redirigees vers /en/games)
RETIRES_EN: list[str] = []


def choisir(donnees, fiches, G):
    """Les jeux a publier. Les pages deja en ligne (`donnees`, premiere
    collecte) gardent leur nom, donc leur adresse ; les fiches de la tache
    « Fiches des jeux du site » s'y ajoutent, les plus connues d'abord."""
    brut = {}
    for appid, x in (fiches or {}).items():
        if not x.get("err") and x.get("n"):
            brut[appid] = dict(x, coupe=False)
    for appid, x in donnees.items():
        if x.get("err"):
            continue
        neuf = brut.get(appid)
        # fiche plus recente, mais meme nom : l'adresse de la page ne change pas
        brut[appid] = dict(neuf, n=x["n"], ancien=True) if neuf else dict(x, coupe=True, ancien=True)

    jeux, ecartes = [], []
    for appid, x in brut.items():
        nom = propre(x["n"])
        exig = Exigences(appid=appid, titre=nom)
        exig.minimum, exig.recommandee = lire_config(x.get("min", "")), lire_config(x.get("rec", ""))
        cites = repere(x.get("rec", ""), exig.recommandee)
        repere(x.get("min", ""), exig.minimum)
        if not (x.get("min") or "").strip():
            ecartes.append(nom)          # sans configuration officielle : rien a dire
            continue
        # sans carte citee des deux cotes, l'estimation serait inventee : la page
        # donne la configuration officielle et les prix, et le dit
        estimable = bool(exig.recommandee and exig.recommandee.gpu and exig.minimum and exig.minimum.gpu)
        gratuit = bool(x.get("free"))
        genres = x.get("g") or ["jeu"]
        if isinstance(genres, str):
            genres = [g.strip(" '\"") for g in genres.strip("[]").split(",") if g.strip(" '\"")] or ["jeu"]
        if est_un_logiciel(genres):
            RETIRES.append(slug(nom))
            continue
        jeux.append({"appid": appid, "nom": nom, "slug": slug(nom), "exig": exig, "estimable": estimable,
                     "img": x.get("img") or "",
                     "cites": cites, "genres": genres, "dev": x.get("dev") or "son studio",
                     "date": (x.get("d") or "").replace("aout", "août"),
                     "gratuit": gratuit, "ancien": bool(x.get("ancien")), "avis": int(x.get("avis") or 0),
                     "positifs": int(x.get("positifs") or 0),
                     "gp": None if gratuit else offre_gp(G, appid, x["n"], nom),
                     "min": champs(x.get("min", ""), x["coupe"]),
                     "rec": champs(x.get("rec", ""), x["coupe"])})
    # les pages deja en ligne d'abord, puis les jeux les plus connus
    jeux.sort(key=lambda j: (not j["ancien"], not j["estimable"], -j["avis"]))
    jeux = [j for j in jeux if j["slug"] and j["date"]]
    pris, gardes = set(), []
    for j in jeux:
        if j["slug"] in pris:
            # deux jeux du meme nom : le moins connu porte son numero. « ancien »
            # (page deja en ligne) ne vaut que pour le premier : le second a pris
            # ce drapeau parce que la page du premier existe, pas la sienne
            j["slug"] += "-" + j["appid"]
            j["ancien"] = False
        pris.add(j["slug"])
        gardes.append(j)
    return gardes[:PAGES_MAX], ecartes


def main(dossier, source, prix="", fiches=""):
    dossier = Path(dossier)
    donnees = json.loads(Path(source).read_text(encoding="utf-8"))
    nouvelles = (json.loads(Path(fiches).read_text(encoding="utf-8")).get("jeux") or {}) if fiches else {}
    G = charger_prix(prix) if prix else None
    auj = dt.date.today()
    accueil = (dossier / "index.html").read_text(encoding="utf-8")
    style = re.search(r"<style>(.*?)</style>", accueil, re.S).group(1)

    VISUELS.clear()
    import jaquettes
    VISUELS.update(jaquettes.disponibles(dossier))
    jeux, ecartes = choisir(donnees, nouvelles, G)
    rediriger(dossier, [f"/jeux/{r}" for r in RETIRES], "/jeux")
    jeux.sort(key=lambda j: j["nom"].lower())
    assert len({j["slug"] for j in jeux}) == len(jeux)
    (dossier / "prix.js").write_text(PRIX_JS, encoding="utf-8")

    cible = dossier / "jeux"
    cible.mkdir(exist_ok=True)
    for ancien in cible.glob("*.html"):
        ancien.unlink()
    genres = genres_de(jeux)
    for j in jeux:
        (cible / f"{j['slug']}.html").write_text(page_jeu(j, style, jeux, auj, set(genres)), encoding="utf-8")
    for sous in ("genre", "carte"):
        (cible / sous).mkdir(exist_ok=True)
        for ancien in (cible / sous).glob("*.html"):
            ancien.unlink()
    for g, l in genres.items():
        (cible / "genre" / f"{slug(g)}.html").write_text(page_genre(g, l, style, auj), encoding="utf-8")
    for cle, nom, vram in CARTES:
        (cible / "carte" / f"{slug(nom)}.html").write_text(page_carte(cle, nom, vram, jeux, style, auj),
                                                           encoding="utf-8")
    assert not {j["slug"] for j in jeux} & set(TYPES_PC), "un jeu porte le nom d'une page par type de PC"
    for k in TYPES_PC:
        (cible / f"{k}.html").write_text(page_type(k, jeux, style, auj), encoding="utf-8")
    (dossier / "jeux.html").write_text(page_index(jeux, style, auj, genres, CARTES), encoding="utf-8")
    # index de la barre de recherche du site (14 octobre) : les plus connus d'abord
    import gen_recherche
    gen_recherche.ecrire_index(dossier / "recherche.json", jeux, VISUELS, rang=lambda j: -j["avis"])

    plan = dossier / "sitemap.xml"
    x = plan.read_text(encoding="utf-8")
    x = re.sub(r"  <url>\n    <loc>" + re.escape(SITE) + r"/jeux[^<]*</loc>.*?</url>\n", "", x, flags=re.S)
    bloc = "".join(f"  <url>\n    <loc>{SITE}{c}</loc>\n    <lastmod>{auj.isoformat()}</lastmod>\n"
                   f"    <changefreq>monthly</changefreq>\n    <priority>{p}</priority>\n  </url>\n"
                   for c, p in [("/jeux", "0.9")]
                   + [(f"/jeux/genre/{slug(g)}", "0.8") for g in genres]
                   + [(f"/jeux/carte/{slug(nom)}", "0.8") for _, nom, _ in CARTES]
                   + [(f"/jeux/{k}", "0.8") for k in TYPES_PC]
                   + [(f"/jeux/{j['slug']}", "0.7") for j in jeux])
    x = x.replace("  <url>\n    <loc>" + SITE + "/mentions-legales",
                  bloc + "  <url>\n    <loc>" + SITE + "/mentions-legales")
    plan.write_text(x, encoding="utf-8")
    # bons plans (13 octobre) : memes jeux, meme releve Gamesplanet
    if G is not None:
        import gen_bons_plans
        gen_bons_plans.main(dossier, G, jeux, style)
    avec_prix = sum(1 for j in jeux if j["gp"])
    sans = sum(1 for j in jeux if not j.get("estimable", True))
    print(f"{len(jeux)} pages de jeux ({sans} sans estimation), dont {avec_prix} avec un prix Gamesplanet ; "
          f"{len(genres)} pages de genre, {len(CARTES)} pages de carte ; "
          f"{len(ecartes)} jeux ecartes faute de configuration ; "
          f"{sum(1 for j in jeux if j['appid'] in VISUELS)} avec leur visuel.")


if __name__ == "__main__":
    main(*sys.argv[1:5])
