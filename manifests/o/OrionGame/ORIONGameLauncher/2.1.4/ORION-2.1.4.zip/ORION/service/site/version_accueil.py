"""Met la page d'accueil (FR) au numero de version publie : donnees
structurees, phrase sous le bouton, bloc de telechargement (taille) et
empreinte SHA-256. Les pages anglaises reprennent ces valeurs a l'assemblage.

    python version_accueil.py <index.html> <version> <taille en Mo> <sha256>
"""
import re
import sys
from pathlib import Path


def main(chemin, version, taille, empreinte) -> None:
    empreinte = empreinte.lower()
    assert re.fullmatch(r"\d+\.\d+(\.\d+)?", version) and re.fullmatch(r"[0-9a-f]{64}", empreinte) and taille.isdigit()
    p = Path(chemin)
    s = p.read_text(encoding="utf-8")
    s, n1 = re.subn(r'"softwareVersion": "[^"]+"', f'"softwareVersion": "{version}"', s)
    s, n2 = re.subn(r'"fileSize": "[^"]+"', f'"fileSize": "{taille} Mo"', s)
    s, n3 = re.subn(r"(sans publicité\. Version )\d+\.\d+(?:\.\d+)?", lambda m: m.group(1) + version, s)
    s, n4 = re.subn(r"Version \d+\.\d+(?:\.\d+)?, Windows 10 et 11 en 64 bits, \d+ Mo",
                    f"Version {version}, Windows 10 et 11 en 64 bits, {taille} Mo", s)
    s, n5 = re.subn(r'<p class="hash">[0-9a-f]{64}</p>', f'<p class="hash">{empreinte}</p>', s)
    assert (n1, n2, n3, n4, n5) == (1, 1, 1, 1, 1), (n1, n2, n3, n4, n5)
    p.write_text(s, encoding="utf-8")
    print(f"accueil : version {version}, {taille} Mo, {empreinte[:12]}…")


if __name__ == "__main__":
    main(*sys.argv[1:5])
