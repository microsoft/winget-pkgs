"""Recherche du site : la barre de l'en-tete de chaque page, la liste qui s'ouvre
sous elle et la page des resultats (demande de l'auteur, 14 octobre 2026 :
« fais comme n'importe quel site de vente de jeu », avec Instant Gaming,
Kinguin et DLCompare pour modeles).

* `ecrire_index` (appele par gen_jeux et gen_jeux_en) : /recherche.json et
  /en/search.json, les jeux les plus connus d'abord : nom, adresse, visuel,
  genre, studio, prix Gamesplanet et remise quand ils sont connus ;
* `main` (appele par assembler.py, apres toutes les pages) : les pages du site
  (bons plans, genres, cartes graphiques...) ajoutees a l'index, la barre dans
  l'en-tete de chaque page, recherche.js, les pages /recherche et /en/search
  (hors index Google : « noindex »).

Le script et l'index sont servis par le site lui-meme ; l'index n'est lu
qu'au premier usage de la barre (aucune requete de plus sur l'accueil)."""
from __future__ import annotations

import hashlib
import html
import json
import re
from pathlib import Path

ICI = Path(__file__).resolve().parent
LOUPE = ('<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5" '
         'fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M15.5 15.5 21 21" stroke="currentColor" '
         'stroke-width="2.2" stroke-linecap="round"/></svg>')
FORMULAIRE = {
    "fr": ('<form class="cherche" action="/recherche" role="search">'
           '<input type="search" name="q" placeholder="Chercher un jeu" aria-label="Chercher un jeu" '
           'autocomplete="off" enterkeyhint="search" spellcheck="false">'
           f'<button type="submit" aria-label="Chercher">{LOUPE}</button></form>'),
    "en": ('<form class="cherche" action="/en/search" role="search">'
           '<input type="search" name="q" placeholder="Search a game" aria-label="Search a game" '
           'autocomplete="off" enterkeyhint="search" spellcheck="false">'
           f'<button type="submit" aria-label="Search">{LOUPE}</button></form>'),
}
CSS = """
  /* recherche (gen_recherche.py) */
  .cherche{position:relative;flex:1 1 150px;max-width:320px;min-width:120px;display:flex;align-items:center;}
  .cherche input{width:100%;background:rgba(239,234,224,.07);border:1px solid var(--line-hi,rgba(239,234,224,.22));
    border-radius:999px;padding:7px 38px 7px 15px;color:var(--ink,#EFEAE0);font:inherit;font-size:15px;line-height:1.4;}
  .cherche input::placeholder{color:var(--faint,#7780A0);}
  .cherche input:focus{outline:2px solid var(--accent,#A8CBFF);outline-offset:1px;background:rgba(239,234,224,.1);}
  .cherche input::-webkit-search-cancel-button{display:none;}
  .cherche button{position:absolute;right:6px;top:50%;transform:translateY(-50%);background:none;border:0;
    color:var(--dim,#A6AEC6);padding:6px;cursor:pointer;display:flex;}
  .ch-liste{position:absolute;top:calc(100% + 8px);right:0;width:min(580px,94vw);max-height:min(70vh,640px);overflow:auto;
    background:#121933;border:1px solid var(--line-hi,rgba(239,234,224,.22));border-radius:16px;padding:8px;
    box-shadow:0 30px 70px rgba(3,5,14,.7);z-index:60;}
  .ch-titre{margin:8px 10px 6px;font-size:12px;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--faint,#7780A0);}
  .ch-ligne{display:flex;align-items:center;gap:14px;padding:8px 10px;border-radius:12px;text-decoration:none;color:var(--ink,#EFEAE0);}
  .ch-ligne:hover,.ch-ligne.ch-actif,.ch-tuile.ch-actif,.ch-puce.ch-actif,.ch-tout.ch-actif{background:rgba(168,203,255,.12);}
  .ch-img{flex:none;width:96px;height:45px;border-radius:7px;object-fit:cover;display:block;}
  .ch-txt{flex:1 1 auto;min-width:0;display:flex;flex-direction:column;gap:3px;}
  .ch-txt b{font-size:15px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
  .ch-txt small{font-size:12.5px;color:var(--faint,#7780A0);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
  .ch-droite{flex:none;display:flex;align-items:center;gap:8px;}
  .ch-prix{font-weight:800;font-size:15px;}
  .ch-gratuit{color:var(--good,#57D98A);}
  .ch-remise{background:var(--good,#57D98A);color:#06210F;font-weight:800;font-size:12px;padding:3px 7px;border-radius:999px;}
  .ch-tuiles{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;padding:4px 6px 8px;}
  .ch-tuile{position:relative;display:flex;flex-direction:column;gap:6px;text-decoration:none;color:var(--ink,#EFEAE0);border-radius:10px;padding:4px;}
  .ch-tuile b{font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
  .ch-tuile .ch-remise{position:absolute;top:10px;right:10px;}
  .ch-timg{width:100%;aspect-ratio:460/215;border-radius:8px;object-fit:cover;display:block;}
  .ch-puces{display:flex;flex-wrap:wrap;gap:8px;padding:2px 8px 8px;}
  .ch-puce{border:1px solid var(--line-hi,rgba(239,234,224,.22));border-radius:999px;padding:6px 14px;font-size:13.5px;
    font-weight:700;color:var(--ink,#EFEAE0);text-decoration:none;}
  .ch-tout{display:block;margin:6px 4px 4px;padding:12px;border-radius:10px;text-align:center;font-weight:800;
    background:rgba(239,234,224,.06);color:var(--ink,#EFEAE0);text-decoration:none;}
  .ch-rien{margin:14px 12px;color:var(--dim,#A6AEC6);font-size:14.5px;}
  .ch-page{margin:28px 0 60px;}
  .ch-filtres{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:18px 0 10px;}
  .ch-filtre{background:none;border:1px solid var(--line-hi,rgba(239,234,224,.22));color:var(--ink,#EFEAE0);border-radius:999px;
    padding:7px 15px;font:inherit;font-size:14px;cursor:pointer;}
  .ch-filtre.ch-on{background:var(--accent,#A8CBFF);color:var(--accent-ink,#0C1122);border-color:transparent;font-weight:700;}
  .ch-tri{margin-left:auto;background:var(--panel,#131A33);color:var(--ink,#EFEAE0);border:1px solid var(--line-hi,rgba(239,234,224,.22));
    border-radius:8px;padding:7px 10px;font:inherit;font-size:14px;}
  .ch-resultats{display:flex;flex-direction:column;gap:4px;}
  .ch-resultats .ch-img{width:150px;height:70px;}
  @media (max-width:760px){
    .cherche{order:2;flex:1 0 100%;max-width:none;}
    .ch-liste{width:100%;left:0;right:auto;}
    .ch-img{width:72px;height:34px;}
    .ch-tuiles{grid-template-columns:repeat(2,1fr);}
    .ch-resultats .ch-img{width:110px;height:51px;}
  }
"""
#: pages du site proposees par la recherche (titre, adresse, mots qui y menent)
PAGES = {
    "fr": [("Bons plans", "/bons-plans", "promo promos reduction soldes affaire deal pas cher"),
           ("Jeux gratuits", "/gratuits", "gratuit gratuits free epic offert"),
           ("Sorties des jeux", "/sorties", "sortie sorties date compte a rebours bientot"),
           ("GTA 6 sur PC", "/gta-6-pc", "gta 6 vi grand theft auto pc"),
           ("Black Friday jeux PC", "/black-friday", "black friday promo"),
           ("Soldes Steam et Next Fest", "/soldes-steam", "soldes steam next fest festival dates"),
           ("Augmenter ses FPS", "/augmenter-fps", "fps lag performance saccades optimiser"),
           ("Config PC gamer 2026", "/config-pc-gamer-2026", "config pc gamer monter assembler montage build composants prix 2026"),
           ("Mon PC peut-il faire tourner ce jeu ?", "/mon-pc-peut-il-faire-tourner", "mon pc peut il faire tourner can i run it configuration requise minimale config est ce que"),
           ("Prix de la RAM", "/prix-ram", "prix ram memoire ddr5 ddr4 barrette penurie"),
           ("Prix des cartes graphiques", "/prix-cartes-graphiques", "prix carte graphique gpu rtx radeon rx"),
           ("Jeux peu gourmands", "/jeux/peu-gourmands", "petit pc peu gourmand portable sans carte graphique"),
           ("Pilotes par modèle de PC", "/pilotes", "pilote pilotes driver drivers"),
           ("Configs de tous les jeux", "/jeux", "configuration requise config jeux liste"),
           ("Télécharger ORION", "/#installer", "telecharger installer launcher orion gratuit")],
    "en": [("All games: PC requirements", "/en/games", "requirements specs games list"),
           ("Download ORION", "/en/#installer", "download install launcher orion free")],
}


def ecrire_index(chemin: Path, jeux, visuels, rang=lambda j: 0) -> None:
    """Index des jeux de la recherche, les plus connus d'abord (`rang` croissant)."""
    lignes = []
    for j in sorted(jeux, key=rang):
        gp = j.get("gp") or None
        lignes.append([j["nom"], j["slug"], j["appid"] if str(j["appid"]) in visuels else "",
                       " · ".join(j.get("genres", [])[:2]), j.get("dev", ""),
                       round(gp["prix"], 2) if gp else None, int(gp["remise"]) if gp else 0,
                       0, 1 if j.get("gratuit") else 0])
    chemin.parent.mkdir(parents=True, exist_ok=True)
    chemin.write_text(json.dumps({"v": 1, "j": lignes, "p": []}, ensure_ascii=False, separators=(",", ":")),
                      encoding="utf-8")


def _titre_de(page: Path) -> str:
    s = page.read_text(encoding="utf-8")
    m = re.search(r"<h1[^>]*>(.*?)</h1>", s, re.S) or re.search(r"<title>(.*?)</title>", s, re.S)
    return html.unescape(re.sub(r"<[^>]+>", "", m.group(1))).strip() if m else ""


def _pages(sortie: Path, langue: str) -> list:
    out = [list(p) for p in PAGES[langue]]
    racine, adresse = (sortie / "jeux", "/jeux") if langue == "fr" else (sortie / "en" / "games", "/en/games")
    for sous, mot in (("genre", "genre jeux" if langue == "fr" else "genre games"),
                      ("carte" if langue == "fr" else "gpu", "carte graphique gpu" if langue == "fr" else "graphics card gpu")):
        for p in sorted((racine / sous).glob("*.html")):
            titre = _titre_de(p)
            if titre:
                out.append([titre, f"{adresse}/{sous}/{p.stem}", mot])
    return out


def _page_resultats(sortie: Path, langue: str) -> None:
    modele = sortie / ("jeux.html" if langue == "fr" else "en/games.html")
    if not modele.is_file():
        return
    s = modele.read_text(encoding="utf-8")
    titre, desc, chemin = (("Rechercher un jeu PC : config et prix | ORION",
                            "Chercher un jeu PC sur ORION : configuration requise, réglages à attendre de votre carte "
                            "graphique et meilleur prix.", "/recherche") if langue == "fr" else
                           ("Search PC games: specs and prices | ORION",
                            "Search a PC game on ORION: official requirements, the settings to expect on your graphics "
                            "card and the best price.", "/en/search"))
    s = re.sub(r"<title>.*?</title>", f"<title>{titre}</title>", s, count=1, flags=re.S)
    s = re.sub(r'<meta name="description" content="[^"]*">', f'<meta name="description" content="{desc}">', s, count=1)
    s = re.sub(r'<meta name="robots" content="[^"]*">', '<meta name="robots" content="noindex, follow">', s, count=1)
    s = re.sub(r'<link rel="canonical" href="[^"]*">', f'<link rel="canonical" href="https://orion-launcher.com{chemin}">',
               s, count=1)
    s = re.sub(r'<script type="application/ld\+json">.*?</script>\n?', "", s, flags=re.S)
    s = re.sub(r"<script>.*?</script>\n?", "", s, flags=re.S)          # scripts propres a la liste des jeux
    s = s.replace(' aria-current="page"', "")
    s = re.sub(r'<meta property="og:(url|title|description)" content="[^"]*">\n?', "", s)
    s = re.sub(r'<link rel="alternate" hreflang="[^"]*" href="[^"]*">\n?', "", s)     # pas de jumelle a annoncer
    repli = (('<noscript><p>La recherche a besoin de JavaScript. <a href="/jeux">Tous les jeux, par ordre '
              'alphabétique</a>.</p></noscript>') if langue == "fr" else
             '<noscript><p>Search needs JavaScript. <a href="/en/games">All games, A to Z</a>.</p></noscript>')
    h1 = "Rechercher un jeu" if langue == "fr" else "Search a game"
    corps = f'<main class="wrap">\n<section id="resultats-recherche" class="ch-page">\n<h1 class="ch-h1">{h1}</h1>\n{repli}\n</section>\n</main>'
    s = re.sub(r'<main class="wrap">.*?</main>', corps, s, count=1, flags=re.S)
    (sortie / (chemin.lstrip("/") + ".html")).write_text(s, encoding="utf-8")


def _equiper(page: Path, langue: str) -> bool:
    s = page.read_text(encoding="utf-8")
    if 'class="cherche"' in s:
        return False
    debut = s.find('<header class="nav">')
    if debut < 0:
        return False
    fin = s.find("</header>", debut)
    sp = s.find('<span class="sp"></span>', debut, fin)
    if sp < 0:
        return False
    s = s[:sp] + FORMULAIRE[langue] + "\n    " + s[sp:]
    s = s.replace("</style>", CSS + "</style>", 1)
    s = s.replace("</body>", '<script src="/recherche.js" defer></script>\n</body>', 1)
    page.write_text(s, encoding="utf-8")
    return True


def main(sortie) -> int:
    sortie = Path(sortie)
    empreinte = hashlib.sha256()
    for langue, nom in (("fr", "recherche.json"), ("en", "en/search.json")):
        f = sortie / nom
        if not f.is_file():
            continue
        d = json.loads(f.read_text(encoding="utf-8"))
        d["p"] = _pages(sortie, langue)
        texte = json.dumps(d, ensure_ascii=False, separators=(",", ":"))
        f.write_text(texte, encoding="utf-8")
        empreinte.update(texte.encode("utf-8"))
        _page_resultats(sortie, langue)
    js = (ICI / "recherche.js").read_text(encoding="utf-8").replace("__VERSION__", empreinte.hexdigest()[:10])
    (sortie / "recherche.js").write_text(js, encoding="utf-8")
    n = 0
    for page in sortie.rglob("*.html"):
        langue = "en" if page.relative_to(sortie).parts[0] == "en" else "fr"
        n += _equiper(page, langue)
    print(f"recherche : barre ajoutee a {n} pages")
    return n


if __name__ == "__main__":
    import sys
    main(sys.argv[1])
