// Essai du service hors ligne : la vraie logique et le vrai SQL, sur une base
// SQLite en memoire qui imite la liaison D1. Lance par tests/test_compteur.py.
//   node --experimental-sqlite service/essai_worker.mjs
import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import worker, { validerCompteur, validerSante, choisirKinguin, choisirLoaded, lireOffre, zoneDe,
  lireVersions, releverTelechargements, lireDemandeItad, lireLot, lireEsprit, lireCoherence, routeSante,
  jourLocal, heureLocale, lireNvidia, releverPilotes, validerClicSite, destinationAller, estUnRobot, lireEpic, lireGamerPower, rssGratuits, ancreGratuit, imageSure, lecteurRss, compterLectureRss } from "./worker.js";

const base = new DatabaseSync(":memory:");
const DB = {
  prepare(sql) {
    let args = [];
    const p = {
      bind(...a) { args = a.map((x) => (x === undefined ? null : x)); return p; },
      async run() { const r = base.prepare(sql).run(...args); return { meta: { last_row_id: Number(r.lastInsertRowid), changes: Number(r.changes) } }; },
      async first() { return base.prepare(sql).get(...args) ?? null; },
      async all() { return { results: base.prepare(sql).all(...args) }; },
    };
    return p;
  },
};
const poste = "0123456789abcdef0123456789abcdef";
const envoyer = async (chemin, corps, cf = undefined) => {
  const texte = JSON.stringify(corps);
  const requete = new Request("https://api.exemple" + chemin, {
    method: "POST", body: texte,
    headers: { "content-type": "application/json", "content-length": String(texte.length) },
  });
  if (cf) Object.defineProperty(requete, "cf", { value: cf });   // ce que fournit l'hebergeur
  const r = await worker.fetch(requete, { DB });
  return [r.status, await r.json()];
};
const lire = (sql) => base.prepare(sql).all();

// -- validation : rien de libre n'entre
assert.equal(validerCompteur(null), null);
assert.equal(validerCompteur({ v: 1, poste: "x", evenements: [] }), null);
assert.equal(validerCompteur({ v: 1, poste, evenements: [] }), null);
const v = validerCompteur({ v: 1, poste, app: "1.9.6", canal: "pirate", evenements: [
  { nom: "ouverture", n: 1 },
  { nom: "page", detail: "boutique", n: 3 },
  { nom: "page", detail: "<script>", n: 1 },
  { nom: "clic", detail: "instant-gaming", origine: "boutique", n: 2 },
  { nom: "clic", detail: "https://exemple.com/jeu?x=1", origine: "fiche", n: 1 },
  { nom: "clic", detail: "steam", origine: "n'importe quoi", n: 1 },
  { nom: "autre", detail: "x", n: 1 }, { nom: "page", detail: "library", n: 0 }, null,
] });
assert.equal(v.ouverture, true);
assert.equal(v.canal, "installateur");
assert.deepEqual(v.lignes, [
  { nom: "page", detail: "boutique", origine: "", n: 3 },
  { nom: "clic", detail: "instant-gaming", origine: "boutique", n: 2 },
  { nom: "clic", detail: "steam", origine: "", n: 1 },
]);

// -- deux envois du meme PC le meme jour : un seul PC actif, compteurs additionnes
const corps = { v: 1, poste, app: "1.9.6", canal: "store", evenements: [
  { nom: "ouverture", n: 1 }, { nom: "page", detail: "boutique", n: 2 },
  { nom: "clic", detail: "kinguin", origine: "boutique", n: 1 }] };
assert.deepEqual(await envoyer("/compteur", corps), [200, { ok: true }]);
assert.deepEqual(await envoyer("/compteur", { ...corps, evenements: [
  { nom: "page", detail: "boutique", n: 5 }, { nom: "clic", detail: "kinguin", origine: "boutique", n: 2 }] }),
  [200, { ok: true }]);
const actifs = lire("SELECT * FROM actifs");
assert.equal(actifs.length, 1);
assert.equal(actifs[0].envois, 2);
assert.notEqual(actifs[0].poste, poste);                 // range hache, jamais en clair
assert.equal(actifs[0].canal, "store");
const c = Object.fromEntries(lire("SELECT nom, detail, origine, n FROM compteurs")
  .map((l) => [`${l.nom}|${l.detail}|${l.origine}`, l.n]));
assert.deepEqual(c, { "ouverture|store|": 1, "page|boutique|": 7, "clic|kinguin|boutique": 3 });
// les compteurs ne portent aucun identifiant
assert.deepEqual(Object.keys(lire("SELECT * FROM compteurs")[0]).sort(), ["detail", "jour", "n", "nom", "origine"]);

// -- un autre PC : deux actifs
await envoyer("/compteur", { ...corps, poste: "f".repeat(32) });
assert.equal(lire("SELECT COUNT(*) AS n FROM actifs")[0].n, 2);

// -- refus
assert.equal((await envoyer("/compteur", { v: 1, poste, evenements: [{ nom: "x" }] }))[0], 400);
assert.equal((await envoyer("/compteur", { v: 2 }))[0], 400);
assert.equal((await envoyer("/compteur", { ...corps, v: 4 }))[0], 400);     // v 3 : voir plus bas (bilan de fluidite)

// -- clic sur un lien partenaire depuis le site (2.0.2) : boutique et type de page, rien d'autre
assert.deepEqual(validerClicSite({ boutique: "instant-gaming", page: "jeu" }), { nom: "clic", detail: "instant-gaming", origine: "site-jeu", n: 1 });
assert.equal(validerClicSite({ boutique: "instant-gaming", page: "fiche" }), null);
assert.equal(validerClicSite({ boutique: "<script>", page: "jeu" }), null);
assert.equal(validerClicSite({ boutique: "steam" }), null);
assert.equal((await envoyer("/clic-site", { boutique: "gamesplanet", page: "sorties" }))[0], 200);
assert.equal((await envoyer("/clic-site", { boutique: "gamesplanet", page: "sorties" }))[0], 200);
assert.equal((await envoyer("/clic-site", { boutique: "gamesplanet", page: "ailleurs" }))[0], 400);
{
  const l = base.prepare("SELECT n FROM compteurs WHERE nom = 'clic' AND detail = 'gamesplanet' AND origine = 'site-sorties'").get();
  assert.equal(l.n, 2);
}

// -- 16 octobre : les autres pages du site ont leur origine ; clic sur Telecharger a part
assert.deepEqual(validerClicSite({ boutique: "gamesplanet", page: "bons-plans" }), { nom: "clic", detail: "gamesplanet", origine: "site-bons-plans", n: 1 });
assert.deepEqual(validerClicSite({ telecharger: true, page: "accueil" }), { nom: "telecharger", detail: "site", origine: "site-accueil", n: 1 });
assert.equal(validerClicSite({ telecharger: true, page: "nulle-part" }), null);
assert.equal(validerClicSite({ telecharger: "oui", page: "accueil" }), null);

// -- /aller/<site>?u=... : redirection comptee, identifiant ajoute ici, robots ecartes
assert.equal(destinationAller("kinguin", "https://www.kinguin.net/category/1/elden-ring?x=1"),
  "https://www.kinguin.net/category/1/elden-ring?x=1&r=w0405u433koc0");
assert.equal(destinationAller("kinguin", "https://www.kinguin.net/cat?r=autre"), "https://www.kinguin.net/cat?r=autre");
assert.equal(destinationAller("instant-gaming", "https://www.instant-gaming.com/fr/1-elden-ring/"),
  "https://www.instant-gaming.com/fr/1-elden-ring/?igr=Sikher");
assert.equal(destinationAller("loaded", "https://www.loaded.com/fr/elden-ring"),
  "https://go.loaded.com/xJDad5?u=" + encodeURIComponent("https://www.loaded.com/fr/elden-ring"));
assert.equal(destinationAller("gamesplanet", "https://fr.gamesplanet.com/game/elden-ring-steam-key--4266-1"),
  "https://fr.gamesplanet.com/game/elden-ring-steam-key--4266-1?ref=orion");
assert.equal(destinationAller("kinguin", "https://evil.example/?kinguin.net"), null);      // autre hote
assert.equal(destinationAller("kinguin", "https://kinguin.net.evil.example/x"), null);
assert.equal(destinationAller("kinguin", "http://www.kinguin.net/x"), null);                 // pas https
assert.equal(destinationAller("g2a", "https://www.g2a.com/x"), null);                        // site ecarte
assert.equal(destinationAller("kinguin", "pas une adresse"), null);
assert.ok(estUnRobot("Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)"));
assert.ok(!estUnRobot("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/130.0 Safari/537.36"));
{
  const aller = async (chemin, agent) => worker.fetch(new Request("https://api.exemple" + chemin,
    { headers: { "user-agent": agent || "Mozilla/5.0 Chrome/130.0" } }), { DB });
  const humain = await aller("/aller/kinguin?u=" + encodeURIComponent("https://www.kinguin.net/c/1?a=2") + "&p=jeu");
  assert.equal(humain.status, 302);
  assert.equal(humain.headers.get("location"), "https://www.kinguin.net/c/1?a=2&r=w0405u433koc0");
  assert.equal(humain.headers.get("cache-control"), "no-store");
  assert.equal(humain.headers.get("x-robots-tag"), "noindex, nofollow");
  const robot = await aller("/aller/kinguin?u=" + encodeURIComponent("https://www.kinguin.net/c/1") + "&p=jeu",
    "Mozilla/5.0 (compatible; Googlebot/2.1)");
  assert.equal(robot.status, 302);                                   // redirige, pas compte
  const sansPage = await aller("/aller/gamesplanet?u=" + encodeURIComponent("https://fr.gamesplanet.com/game/x"));
  assert.equal(sansPage.status, 302);
  assert.equal((await aller("/aller/kinguin?u=" + encodeURIComponent("https://evil.example/"))).status, 404);
  assert.equal((await aller("/aller/g2a?u=" + encodeURIComponent("https://www.g2a.com/"))).status, 404);
  const l = base.prepare("SELECT n FROM compteurs WHERE nom = 'clic' AND detail = 'kinguin' AND origine = 'site-jeu'").get();
  assert.equal(l.n, 1);                                              // l'humain, pas le robot
  const g = base.prepare("SELECT n FROM compteurs WHERE nom = 'clic' AND detail = 'gamesplanet' AND origine = 'site-autre'").get();
  assert.equal(g.n, 1);
  const robots = await worker.fetch(new Request("https://api.exemple/robots.txt"), { DB });
  assert.equal(robots.status, 200);
  assert.match(await robots.text(), /Disallow: \/aller\//);
}

// -- pays et region : seulement pour un envoi v2 (question acceptee), jamais la ville
const paca = { country: "FR", region: "Provence-Alpes-C\u00f4te d'Azur", city: "Nice", postalCode: "06000",
  latitude: "43.7", longitude: "7.2" };
assert.deepEqual(zoneDe(paca), { pays: "FR", region: "Provence-Alpes-C\u00f4te d'Azur" });
assert.deepEqual(zoneDe({ country: "FR", region: "<script>" }), { pays: "FR", region: "" });
assert.deepEqual(zoneDe({ country: "france", region: "Bretagne" }), { pays: "", region: "" });
assert.deepEqual(zoneDe({ country: "T1", region: "x" }), { pays: "", region: "" });
assert.deepEqual(zoneDe(undefined), { pays: "", region: "" });
//    un envoi v1 (ORION 1.9.6) n'est jamais situe, meme si l'hebergeur connait la zone
await envoyer("/compteur", corps, paca);
assert.equal(lire("SELECT name FROM sqlite_master WHERE name = 'zones'").length, 0);
//    un envoi v2 : compte par zone, et un nouveau PC compte une fois
const neuf = { ...corps, v: 2, poste: "a".repeat(32), app: "1.9.7" };
assert.equal((await envoyer("/compteur", neuf, paca))[0], 200);
assert.equal((await envoyer("/compteur", { ...neuf, evenements: [{ nom: "clic", detail: "kinguin", origine: "boutique", n: 4 }] }, paca))[0], 200);
const z = Object.fromEntries(lire("SELECT pays, region, nom, detail, n FROM zones")
  .map((l) => [`${l.pays}|${l.region}|${l.nom}|${l.detail}`, l.n]));
const P = "FR|Provence-Alpes-C\u00f4te d'Azur|";
assert.deepEqual(z, { [P + "ouverture|store"]: 1, [P + "page|boutique"]: 2, [P + "clic|kinguin"]: 5, [P + "pc|store"]: 1 });
//    aucune colonne ne porte un identifiant ni une ville, et la table des PC n'a pas de zone
assert.deepEqual(Object.keys(lire("SELECT * FROM zones")[0]).sort(), ["detail", "jour", "n", "nom", "pays", "region"]);
assert.deepEqual(Object.keys(lire("SELECT * FROM actifs")[0]).sort(), ["app", "canal", "envois", "jour", "poste"]);
assert.equal(JSON.stringify(lire("SELECT * FROM zones")).includes("Nice"), false);
//    sans zone connue de l'hebergeur : compte comme avant, rien dans « zones »
const avant = lire("SELECT SUM(n) AS n FROM zones")[0].n;
assert.equal((await envoyer("/compteur", { ...neuf, poste: "b".repeat(32) }))[0], 200);
assert.equal(lire("SELECT SUM(n) AS n FROM zones")[0].n, avant);

// -- plafond par PC et par jour
base.prepare("UPDATE actifs SET envois = 300").run();
assert.equal((await envoyer("/compteur", corps))[0], 429);

// -- les lignes « actifs » de plus de 400 jours sont effacees
base.prepare("UPDATE actifs SET envois = 1").run();
base.prepare("INSERT INTO actifs (jour, poste, envois) VALUES ('2020-01-01', 'vieux', 1)").run();
await envoyer("/compteur", corps);
assert.equal(lire("SELECT COUNT(*) AS n FROM actifs WHERE jour = '2020-01-01'")[0].n, 0);

// -- les routes existantes repondent toujours
const mesure = { v: 1, poste, appid: "730", gpu: 50, pixels: 2073600, preset: "haute", fps: 120, app: "1.9.6" };
assert.equal((await envoyer("/mesure", mesure))[0], 200);
const r = await worker.fetch(new Request("https://api.exemple/mesures.json"), { DB });
assert.equal((await r.json()).mesures.length, 1);
assert.equal((await envoyer("/signalement", { v: 1, poste, titre: "t", description: "d" }))[0], 200);
// ---------------------------------------------------------------------------
// Prix des revendeurs : la bonne fiche, un vendeur bien note, sinon rien
// ---------------------------------------------------------------------------
const fiche = (name, lowestOffer, extra = {}) => ({
  name, externalId: extra.id ?? "254461", price: { lowestOffer },
  attributes: { steamId: extra.steamId ?? "1643320", urlKey: extra.urlKey ?? "stalker-2-eu-pc-steam-cd-key",
    region: { id: 1, excludedCountries: extra.exclus ?? ["US"], activationCountries: extra.actifs ?? ["FR", "DE"] } },
});
const T = "S.T.A.L.K.E.R. 2 Heart of Chornobyl";
const produits = [
  fiche("S.T.A.L.K.E.R. 2: Heart of Chornobyl PC Steam Account", 990),
  fiche("S.T.A.L.K.E.R. 2: Heart of Chornobyl Steam Altergift", 1500),
  fiche("S.T.A.L.K.E.R. 2: Heart of Chornobyl or Mystery Steam CD Key", 300),
  fiche("S.T.A.L.K.E.R. 2: Heart of Chornobyl Ultimate Edition EU PC Steam CD Key", 2500),
  fiche("S.T.A.L.K.E.R. 2 - Cost of Hope DLC EU PC Steam CD Key", 2017, { steamId: "999" }),
  fiche("S.T.A.L.K.E.R. 2: Heart of Chornobyl LATAM PC Steam CD Key", 2000),
  fiche("S.T.A.L.K.E.R. 2: Heart of Chornobyl EU/NA PC Steam CD Key", 2900),
  fiche("S.T.A.L.K.E.R. 2: Heart of Chornobyl EU Xbox Series X|S CD Key", 2800),
  fiche("S.T.A.L.K.E.R. 2: Heart of Chornobyl PC Steam CD Key", 3300, { id: "254462", urlKey: "stalker-2-pc-steam-cd-key" }),
  fiche("S.T.A.L.K.E.R. 2: Heart of Chornobyl EU PC Steam CD Key", 3068),
  fiche("S.T.A.L.K.E.R. 2: Heart of Chornobyl EU PC Steam CD Key", 2000, { steamId: "42" }),     // autre jeu
  fiche("S.T.A.L.K.E.R. 2: Heart of Chornobyl EU PC Steam CD Key", 1900, { exclus: ["FR"] }),   // pas en France
  fiche("S.T.A.L.K.E.R. 2: Heart of Chornobyl EU PC Steam CD Key", 1800, { urlKey: "../mechant" }),
];
const choix = choisirKinguin(produits, T, "1643320", "FR");
assert.equal(choix.centimes, 3068);
assert.equal(choix.url, "https://www.kinguin.net/category/254461/stalker-2-eu-pc-steam-cd-key");
assert.equal(choisirKinguin(produits.slice(0, 8), T, "1643320", "FR"), null);      // que des offres a ecarter
assert.equal(choisirKinguin(produits, "Elden Ring", "1245620", "FR"), null);
assert.equal(choisirKinguin([fiche("Sid Meier's Civilization VI Steam CD Key", 500, { steamId: "" })],
  "Sid Meier\u2019s Civilization VI", "289070", "FR").centimes, 500);

const page = (note, ventes, devise = "EUR") => `<html><script>{"x":1,"offers":{"mainOffer":{"id":"a","productId":"b","productName":"n","sellerId":1246247,"type":"kinguin","price":{"amount":3068,"currency":"${devise}"},"unitPrice":3068,"seller":{"id":1246247,"name":"Green Keys","merchantStatistics":{"completedOrders":${ventes},"merchantRating":${note}}},"activeStockNumber":20}}}</script></html>`;
assert.deepEqual(lireOffre(page(0.9633862, 187881)),
  { centimes: 3068, devise: "EUR", vendeur: "Green Keys", ventes: 187881, note: 0.9633862 });
assert.equal(lireOffre("<html>rien</html>"), null);

// la route, avec un faux revendeur
const vraiFetch = globalThis.fetch;
let appels = 0;
let reponsePage = page(0.9633862, 187881);
let panne = false;
globalThis.fetch = async (adresse) => {
  appels += 1;
  if (panne) return new Response("non", { status: 503 });
  const u = String(adresse);
  if (u.includes("/products/search")) {
    assert.ok(u.includes("CD+Key") && !u.includes("regions"));
    return new Response(JSON.stringify({ _embedded: { products: produits } }), { status: 200 });
  }
  return new Response(reponsePage, { status: 200 });
};
const lirePrix = async (q) => {
  const r = await worker.fetch(new Request("https://api.exemple/prix?" + q), { DB });
  return [r.status, await r.json()];
};
const Q = "appid=1643320&titre=" + encodeURIComponent(T);
let [st, corpsPrix] = await lirePrix(Q + "&pays=FR");
assert.equal(st, 200);
assert.deepEqual(corpsPrix.kinguin, { prix: 30.68, devise: "EUR", vendeur: "Green Keys", note: 96.3,
  ventes: 187881, nom: "S.T.A.L.K.E.R. 2: Heart of Chornobyl EU PC Steam CD Key",
  url: "https://www.kinguin.net/category/254461/stalker-2-eu-pc-steam-cd-key" });
assert.equal(appels, 2);
[st, corpsPrix] = await lirePrix(Q + "&pays=FR");                 // garde : aucun nouvel appel
assert.equal(appels, 2);
assert.equal(corpsPrix.kinguin.prix, 30.68);
// vendeur moyen, ou trop peu de ventes, ou autre devise : pas de prix
for (const [p, cle] of [[page(0.91, 187881), "1"], [page(0.99, 40), "2"], [page(0.99, 5000, "USD"), "3"]]) {
  reponsePage = p;
  [st, corpsPrix] = await lirePrix("appid=164332" + cle + "&titre=" + encodeURIComponent(T));
  assert.equal(st, 200);
  assert.equal(corpsPrix.kinguin, null);
}
// fiche choisie a la main (Modern Warfare 4) : la recherche ne la trouve pas,
// le prix de vente de la fiche est lu quand meme, avec les memes exigences
{
  const avant = produits.splice(0, produits.length);
  reponsePage = page(0.9633862, 187881);
  let lu = "";
  const fetchAvant = globalThis.fetch;
  globalThis.fetch = async (adresse, o) => { lu = String(adresse); return fetchAvant(adresse, o); };
  [st, corpsPrix] = await lirePrix("appid=4435490&titre=" + encodeURIComponent("Call of Duty: Modern Warfare 4"));
  assert.equal(st, 200);
  assert.equal(corpsPrix.kinguin.prix, 30.68);
  assert.equal(corpsPrix.kinguin.choisi, true);
  assert.ok(corpsPrix.kinguin.url.startsWith("https://www.kinguin.net/fr/category/536535/"));
  assert.ok(lu.includes("/category/536535/"));
  [st, corpsPrix] = await lirePrix("appid=99999&titre=Autre");     // jeu sans fiche choisie : rien
  assert.equal(corpsPrix.kinguin, null);
  globalThis.fetch = fetchAvant;
  produits.push(...avant);
}
// revendeur en panne : reponse vide, retentee plus tard, jamais d'erreur pour ORION
panne = true;
[st, corpsPrix] = await lirePrix("appid=77&titre=Jeu");
assert.equal(st, 200);
assert.equal(corpsPrix.kinguin, null);
const retente = lire("SELECT maj FROM prix_revendeurs WHERE cle = 'prix|77|FR'")[0].maj;
assert.ok(retente < Math.floor(Date.now() / 1000) - 3600);          // sera relu sous 30 minutes
panne = false;
// demandes mal formees
assert.equal((await lirePrix("appid=abc&titre=Jeu"))[0], 400);
assert.equal((await lirePrix("appid=5&titre="))[0], 400);
// rien sur le demandeur n'est garde
assert.deepEqual(Object.keys(lire("SELECT * FROM prix_revendeurs")[0]).sort(), ["cle", "maj", "valeur"]);

// --- Loaded : le catalogue fourni aux affilies, lu avec un jeton secret ---
const L = (nom, prix, fiche, plus = {}) => ({ CatalogId: "12166", Name: nom, CurrentPrice: String(prix),
  Currency: "EUR", StockAvailability: "InStock", OriginalPrice: "59.99", Text1: "Europe & North America", Text3: "Steam",
  Url: "https://go.loaded.com/c/1/2/3?prodsku=x&u=" + encodeURIComponent("https://www.loaded.com/fr_fr/" + fiche + "?utm=1") + "&intsrc=CATF_1",
  ...plus });
const catalogue = [
  L("S.T.A.L.K.E.R. 2: Heart of Chornobyl - Ultimate Edition PC (EU & North America)", 48.39, "s-t-a-l-k-e-r-2-ultimate-edition-pc-steam"),
  L("S.T.A.L.K.E.R. 2: Cost of Hope PC - DLC", 20.59, "stalker-2-cost-of-hope-pc-dlc-steam"),
  L("S.T.A.L.K.E.R. 2: Heart of Chornobyl Xbox Series X|S (Europe & UK)", 35.49, "s-t-a-l-k-e-r-2-xbox-series-x-s-eu"),
  L("S.T.A.L.K.E.R. 2: Heart of Chornobyl PC (EU & North America)", 28.29, "s-t-a-l-k-e-r-2-heart-of-chernobyl-pc-steam"),
  L("S.T.A.L.K.E.R. 2: Heart of Chornobyl PC (EU & North America)", 9.99, "s-t-a-l-k-e-r-2-heart-of-chernobyl-pc-steam", { CatalogId: "12140", Currency: "GBP" }),
  L("S.T.A.L.K.E.R. 2: Heart of Chornobyl PC (EU & North America)", 12.00, "s-t-a-l-k-e-r-2-heart-of-chernobyl-pc-steam", { StockAvailability: "OutOfStock" }),
  L("S.T.A.L.K.E.R. 2: Heart of Chornobyl PC (North America)", 15.00, "s-t-a-l-k-e-r-2-na-pc-steam"),
  L("S.T.A.L.K.E.R. 2: Heart of Chornobyl PC (EN)", 14.00, "s-t-a-l-k-e-r-2-en-pc-steam"),
  L("S.T.A.L.K.E.R. 2: Heart of Chornobyl PC", 13.00, "s-t-a-l-k-e-r-2-heart-of-chernobyl-pc-origin"),   // pas une cle Steam
  L("S.T.A.L.K.E.R. 2: Heart of Chornobyl PC (GOG)", 11.00, "s-t-a-l-k-e-r-2-pc-gog"),
];
assert.deepEqual(choisirLoaded(catalogue, T), { prix: 28.29, devise: "EUR", public: 59.99,
  nom: "S.T.A.L.K.E.R. 2: Heart of Chornobyl PC (EU & North America)",
  url: "https://www.loaded.com/fr_fr/s-t-a-l-k-e-r-2-heart-of-chernobyl-pc-steam" });
assert.equal(choisirLoaded(catalogue, "Elden Ring"), null);
assert.equal(choisirLoaded(catalogue.slice(0, 3), T), null);                     // edition, DLC, console
assert.equal(choisirLoaded([L("Battlefield 2042 PC", 6.59, "battlefield-2042-pc-origin")], "Battlefield 2042"), null);
assert.equal(choisirLoaded([L("Hades II PC", 20, "hades-ii-pc-steam")], "Hades"), null);       // la suite, pas le jeu
assert.equal(choisirLoaded([L("Hades PC (WW)", 9.5, "hades-pc-steam")], "Hades").prix, 9.5);
assert.equal(choisirLoaded([L("Hades PC", 9.5, "../mechant")], "Hades"), null);
// la plate-forme et la region du catalogue comptent aussi
assert.equal(choisirLoaded([L("Hades PC", 9.5, "hades-pc-steam", { Text3: "Epic Games" })], "Hades"), null);
assert.equal(choisirLoaded([L("Hades PC", 9.5, "hades-pc-steam", { Text1: "North America" })], "Hades"), null);
assert.equal(choisirLoaded([L("Hades PC", 9.5, "hades-pc-steam", { Text1: "", OriginalPrice: "" })], "Hades").public, null);
// sans la langue dans l'adresse, la fiche est lue aussi
assert.equal(choisirLoaded([{ ...L("Hades PC", 9.5, "x"), Url: "https://go.loaded.com/c/1/2/3?u=https%3A%2F%2Fwww.loaded.com%2Fhades-pc-steam" }], "Hades").url,
  "https://www.loaded.com/hades-pc-steam");

let vus = [];
globalThis.fetch = async (adresse, options) => {
  const u = String(adresse);
  if (u.startsWith("https://api.impact.com/")) {
    vus.push(u);
    assert.ok(u.startsWith("https://api.impact.com/Mediapartners/sid-essai/Catalogs/ItemSearch?"));
    assert.equal(options.headers.authorization, "Basic " + btoa("sid-essai:jeton-essai"));
    if (panne) return new Response("non", { status: 503 });
    if (u.includes("Query=")) return new Response('{"Message":"filtre refuse"}', { status: 400 });
    return new Response(JSON.stringify({ "@total": "10", Items: catalogue }), { status: 200 });
  }
  if (u.includes("/products/search")) return new Response(JSON.stringify({ _embedded: { products: produits } }), { status: 200 });
  return new Response(page(0.9633862, 187881), { status: 200 });
};
const avecJeton = { DB, IMPACT_SID: " sid-essai", IMPACT_TOKEN: "jeton-essai\n" };   // colles avec un blanc
const lirePrixL = async (q) => {
  const r = await worker.fetch(new Request("https://api.exemple/prix?" + q), avecJeton);
  return [r.status, await r.text()];
};
let [stL, texteL] = await lirePrixL("appid=1643320&titre=" + encodeURIComponent(T) + "&pays=DE");
assert.equal(stL, 200);
assert.ok(!texteL.includes("sid-essai") && !texteL.includes("jeton-essai"));      // jamais dans une reponse
assert.deepEqual(JSON.parse(texteL).loaded, { prix: 28.29, devise: "EUR", public: 59.99,
  nom: "S.T.A.L.K.E.R. 2: Heart of Chornobyl PC (EU & North America)",
  url: "https://www.loaded.com/fr_fr/s-t-a-l-k-e-r-2-heart-of-chernobyl-pc-steam" });
assert.equal(JSON.parse(texteL).kinguin.prix, 30.68);
assert.equal(vus.length, 2);                                // filtre refuse, puis recherche entiere
assert.ok(vus[1].includes("Keyword=") && !vus[1].includes("Query="));
await lirePrixL("appid=1643320&titre=" + encodeURIComponent(T) + "&pays=DE");
assert.equal(vus.length, 2);                                // garde six heures
// hors zone euro : Loaded n'est pas interroge
[stL, texteL] = await lirePrixL("appid=900002&titre=" + encodeURIComponent(T) + "&pays=CA");
assert.equal(JSON.parse(texteL).loaded, null);
assert.equal(vus.length, 2);
// catalogue en panne : pas d'erreur pour ORION, Kinguin reste, et on retente bientot
panne = true;
[stL, texteL] = await lirePrixL("appid=900003&titre=Jeu&pays=FR");
assert.equal(stL, 200);
assert.equal(JSON.parse(texteL).loaded, null);
assert.ok(lire("SELECT maj FROM prix_revendeurs WHERE cle = 'prix|900003|FR'")[0].maj < Math.floor(Date.now() / 1000) - 3600);
panne = false;

// ---------------------------------------------------------------------------
// Prix par lot (cartes de la Boutique) : ce qui est deja su, plus Loaded seul
// ---------------------------------------------------------------------------
for (const refuse of [null, [], {}, { pays: "FR" }, { pays: "fr", jeux: [{ appid: "1", titre: "Jeu" }] },
  { pays: "FR", jeux: [] }, { pays: "FR", jeux: [{ appid: "1 OR 1", titre: "Jeu" }] },
  { pays: "FR", jeux: [{ appid: "1", titre: "J" }] }, { pays: "FR", jeux: [{ appid: "1", titre: "x".repeat(91) }] },
  { pays: "FR", jeux: Array.from({ length: 21 }, (_x, i) => ({ appid: String(i + 1), titre: "Jeu " + i })) }]) {
  assert.equal(lireLot(refuse), null, JSON.stringify(refuse)?.slice(0, 60));
}
assert.deepEqual(lireLot({ pays: "FR", jeux: [{ appid: 7, titre: " Hades " }, { appid: "7", titre: "Hades" }] }),
  { pays: "FR", jeux: [{ appid: "7", titre: "Hades" }] });
const lot = async (corps, env = avecJeton) => {
  const texte = JSON.stringify(corps);
  const r = await worker.fetch(new Request("https://api.exemple/prix/lot", { method: "POST", body: texte,
    headers: { "content-type": "application/json", "content-length": String(texte.length) } }), env);
  return [r.status, await r.text()];
};
let kinguinVu = 0;
const fetchLot = globalThis.fetch;
globalThis.fetch = async (adresse, options) => {
  const u = String(adresse);
  if (u.includes("kinguin")) kinguinVu += 1;
  if (u.startsWith("https://api.impact.com/") && u.includes("Query=")) {
    vus.push(u);
    if (panne) return new Response("non", { status: 503 });
    return new Response(JSON.stringify({ Items: [L("Hades PC (WW)", 9.5, "hades-pc-steam"), ...catalogue] }), { status: 200 });
  }
  return fetchLot(adresse, options);
};
vus = [];
assert.equal((await lot({ pays: "FR" }))[0], 400);
// le jeu deja releve en entier (fiche ouverte) rend Kinguin et Loaded ; les autres, Loaded seul
let [stLot, texteLot] = await lot({ pays: "DE", jeux: [{ appid: "1643320", titre: T }, { appid: "1145360", titre: "Hades" },
  { appid: "55", titre: "Jeu inconnu de Loaded" }] });
assert.equal(stLot, 200);
assert.ok(!texteLot.includes("sid-essai") && !texteLot.includes("jeton-essai"));
let rLot = JSON.parse(texteLot);
assert.equal(rLot.prix["1643320"].kinguin.prix, 30.68);
assert.equal(rLot.prix["1643320"].loaded.prix, 28.29);
assert.deepEqual(rLot.prix["1145360"], { loaded: { prix: 9.5, devise: "EUR", public: 59.99, nom: "Hades PC (WW)",
  url: "https://www.loaded.com/fr_fr/hades-pc-steam" } });
assert.deepEqual(rLot.prix["55"], { loaded: null });           // releve, rien de sur : dit aussi
assert.equal(rLot.reste, 0);
assert.equal(vus.length, 2);                                   // une lecture par jeu inconnu, aucune pour le jeu deja releve
assert.equal(kinguinVu, 0);                                    // Kinguin n'est jamais interroge par lot
await lot({ pays: "DE", jeux: [{ appid: "1145360", titre: "Hades" }, { appid: "55", titre: "Jeu inconnu de Loaded" }] });
assert.equal(vus.length, 2);                                   // garde
// huit nouveaux releves par demande : le reste est annonce, et vient a la demande suivante
const vingt = Array.from({ length: 20 }, (_x, i) => ({ appid: String(7000 + i), titre: "Jeu " + i }));
rLot = JSON.parse((await lot({ pays: "FR", jeux: vingt }))[1]);
assert.equal(Object.keys(rLot.prix).length, 8);
assert.equal(rLot.reste, 12);
rLot = JSON.parse((await lot({ pays: "FR", jeux: vingt }))[1]);
assert.equal(Object.keys(rLot.prix).length, 16);
// hors zone euro, ou sans jeton : rien a attendre, aucun appel
const avantLot = vus.length;
rLot = JSON.parse((await lot({ pays: "US", jeux: [{ appid: "8000", titre: "Hades" }] }))[1]);
assert.deepEqual(rLot, { prix: {}, reste: 0 });
rLot = JSON.parse((await lot({ pays: "FR", jeux: [{ appid: "8001", titre: "Hades" }] }, { DB }))[1]);
assert.deepEqual(rLot, { prix: {}, reste: 0 });
assert.equal(vus.length, avantLot);
// Loaded muet : rien n'est garde, le jeu sera redemande
panne = true;
rLot = JSON.parse((await lot({ pays: "FR", jeux: [{ appid: "8002", titre: "Hades" }] }))[1]);
assert.deepEqual(rLot, { prix: {}, reste: 1 });
assert.equal(lire("SELECT COUNT(*) AS n FROM prix_revendeurs WHERE cle = 'lot|8002|FR'")[0].n, 0);
panne = false;
// plafond de l'heure : plus aucun appel, ce qui est su reste rendu
base.prepare("UPDATE prix_revendeurs SET cle = cle WHERE 1 = 0").run();
for (let i = 0; i < 1200; i += 1) {
  base.prepare("INSERT OR REPLACE INTO prix_revendeurs (cle, valeur, maj) VALUES (?,?,?)")
    .run("lot|" + (500000 + i) + "|FR", '{"loaded":null}', Math.floor(Date.now() / 1000));
}
const avantPlafondLot = vus.length;
rLot = JSON.parse((await lot({ pays: "FR", jeux: [{ appid: "8003", titre: "Hades" }, { appid: "7000", titre: "Jeu 0" }] }))[1]);
assert.equal(vus.length, avantPlafondLot);
assert.deepEqual(Object.keys(rLot.prix), ["7000"]);
assert.equal(rLot.reste, 1);
// les lots ne mangent pas le plafond des releves par fiche
base.prepare("DELETE FROM prix_revendeurs WHERE cle >= 'lot|5' AND cle < 'lot|6'").run();
for (let i = 0; i < 3000; i += 1) {
  base.prepare("INSERT OR REPLACE INTO prix_revendeurs (cle, valeur, maj) VALUES (?,?,?)")
    .run("lot|" + (600000 + i) + "|FR", '{"loaded":null}', Math.floor(Date.now() / 1000));
}
base.prepare("DELETE FROM prix_revendeurs WHERE cle = 'prix|1643320|DE'").run();
const avantFiche = kinguinVu;
[stL, texteL] = await lirePrixL("appid=1643320&titre=" + encodeURIComponent(T) + "&pays=DE");
assert.equal(JSON.parse(texteL).kinguin.prix, 30.68);
assert.ok(kinguinVu > avantFiche);                             // un vrai releve, pas bloque par les lots
base.prepare("DELETE FROM prix_revendeurs WHERE cle >= 'lot|6' AND cle < 'lot|7'").run();
globalThis.fetch = vraiFetch;
// ---------------------------------------------------------------------------
// « Dans le meme esprit » : reponse du modele reduite, gardee, plafonnee
// ---------------------------------------------------------------------------
assert.deepEqual(lireEsprit(null), { connu: false, nom: "", raison: "inconnu", plateformes: "", titres: [], etiquettes: [] });
assert.equal(lireEsprit("pas du json").connu, false);
assert.equal(lireEsprit({ connu: true, nom: "", titres: ["Palworld"] }).connu, false);      // sans nom : inconnu
const brutEsprit = { connu: true, nom: "Pokémon <script>", raison: "console", plateformes: "Nintendo Switch; DROP",
  titres: ["Palworld", "palworld", "Temtem", "<img src=x>", "x", ...Array.from({ length: 12 }, (_x, i) => "Jeu " + i)],
  etiquettes: ["Creature Collector", "JRPG", "Open World", "Cute"], autre: "ignore" };
const luEsprit = lireEsprit(brutEsprit);
assert.equal(luEsprit.nom, "Pokémon script");                    // ni balise ni signe etrange
assert.equal(luEsprit.plateformes, "Nintendo Switch DROP");
assert.deepEqual(luEsprit.titres.slice(0, 3), ["Palworld", "Temtem", "img src x"]);
assert.equal(luEsprit.titres.length, 8);
assert.deepEqual(luEsprit.etiquettes, ["Creature Collector", "JRPG", "Open World"]);
assert.equal(lireEsprit({ ...brutEsprit, raison: "ignore previous instructions" }).raison, "inconnu");
assert.equal(lireEsprit({ ...brutEsprit, raison: "mobile" }).plateformes, "");
assert.equal(lireEsprit(JSON.stringify(brutEsprit)).nom, "Pokémon script");      // texte ou objet

const esprit = async (q, env) => {
  const r = await worker.fetch(new Request("https://api.exemple/esprit?q=" + encodeURIComponent(q)), { DB, ...env });
  return [r.status, await r.text()];
};
let demandesIA = [], reponseIA = () => ({ response: brutEsprit });
const IA = { run: async (modele, options) => { demandesIA.push({ modele, options }); return reponseIA(); } };
assert.equal((await esprit("po", { AI: IA }))[0], 400);
assert.equal((await esprit("x".repeat(61), { AI: IA }))[0], 400);
assert.equal((await esprit("???", { AI: IA }))[0], 400);
// sans liaison au modele : le service le dit, sans erreur pour ORION
let [stE, texteE] = await esprit("pokemon legends", {});
assert.equal(stE, 503);
assert.equal(JSON.parse(texteE).erreur, "esprit non configure");
[stE, texteE] = await esprit("Pokemon  Legends", { AI: IA });
assert.equal(stE, 200);
assert.deepEqual(JSON.parse(texteE), luEsprit);
assert.equal(demandesIA.length, 1);
assert.match(demandesIA[0].modele, /^@cf\//);
assert.equal(demandesIA[0].options.response_format.type, "json_schema");
// le texte du joueur est transmis comme une donnee, entre guillemets
assert.ok(demandesIA[0].options.messages[1].content.endsWith(JSON.stringify("Pokemon Legends")));
// garde un mois : meme question (casse, accents, espaces) -> aucune nouvelle demande, meme sans le modele
assert.deepEqual(JSON.parse((await esprit("pokémon legends", {}))[1]), luEsprit);
assert.equal(demandesIA.length, 1);
// modele en panne : pas d'erreur 500, et rien n'est garde
reponseIA = () => { throw new Error("capacite"); };
[stE, texteE] = await esprit("zelda breath", { AI: IA });
assert.equal(stE, 503);
assert.equal(lire("SELECT COUNT(*) AS n FROM esprit WHERE cle = 'zelda breath'")[0].n, 0);
// reponse hors forme : « inconnu » est garde, le modele n'est pas redemande a chaque fois
reponseIA = () => ({ response: "n'importe quoi" });
[stE, texteE] = await esprit("zzzz introuvable", { AI: IA });
assert.equal(JSON.parse(texteE).connu, false);
const avantEsprit = demandesIA.length;
await esprit("zzzz introuvable", { AI: IA });
assert.equal(demandesIA.length, avantEsprit);
// plafond du jour : plus aucune demande au modele
for (let i = 0; i < 150; i += 1) {
  base.prepare("INSERT OR REPLACE INTO esprit (cle, valeur, maj) VALUES (?,?,?)").run("plafond " + i, "{}", Math.floor(Date.now() / 1000));
}
[stE] = await esprit("encore un jeu", { AI: IA });
assert.equal(stE, 503);
assert.equal(demandesIA.length, avantEsprit);
base.prepare("DELETE FROM esprit WHERE cle LIKE 'plafond %'").run();

// ---------------------------------------------------------------------------
// Telechargements de l'installateur : releves sur GitHub, un total par jour
// ---------------------------------------------------------------------------
const SHA = "486dc3f787f08166d7f91fb5d1f0b850de55a0c2d4c8ba63a691d8dea30ab6bb";
let pageSite = () => new Response('<p class="meta">Version 2.0.0, Windows 10 et 11.</p><p class="hash">' + SHA + "</p>", { status: 200 });
const versionsGithub = (a, b) => [
  { tag_name: "v2.0.0", published_at: "2026-10-06T10:00:00Z", body: "Notes\nSHA-256 : `" + SHA + "`", assets: [
    { name: "Installateur-ORION.exe", download_count: a }, { name: "SHA256.txt", download_count: 999 }] },
  { tag_name: "v1.9.8", published_at: "2026-10-05T08:00:00Z", assets: [{ name: "Installateur-ORION.exe", download_count: b }] },
  { tag_name: "v1.9.7", draft: true, assets: [{ name: "Installateur-ORION.exe", download_count: 5000 }] },
  { tag_name: "<script>", assets: [{ name: "x.exe", download_count: 7 }] },
  { tag_name: "v1.0.0", assets: [{ name: "notes.txt", download_count: 3 }] }, null, "x"];
assert.deepEqual(lireVersions(versionsGithub(41, 230)), [
  { version: "v2.0.0", n: 41, publie: "2026-10-06T10:00:00Z" },
  { version: "v1.9.8", n: 230, publie: "2026-10-05T08:00:00Z" }]);
assert.deepEqual(lireVersions({ message: "API rate limit exceeded" }), []);
assert.deepEqual(lireVersions([{ tag_name: "v1.0", assets: [{ name: "a.exe", download_count: -4 }] }]),
  [{ version: "v1.0", n: 0, publie: "" }]);

let appelsGithub = 0, appelsSite = 0, reponseGithub = () => new Response("limite", { status: 403 });
globalThis.fetch = async (adresse, options) => {
  if (String(adresse) === "https://orion-launcher.com/") { appelsSite += 1; return pageSite(); }
  if (String(adresse).startsWith("https://gfwsl.geforce.com/")) return new Response("ferme", { status: 503 });
  appelsGithub += 1;
  assert.match(String(adresse), /^https:\/\/api\.github\.com\/repos\/Sikher-kisa\/orion-game-launcher\/releases/);
  assert.ok(options.headers["user-agent"], "GitHub refuse une demande sans agent");
  return reponseGithub();
};
const T0 = Date.parse("2026-10-06T12:00:00Z");
// GitHub refuse : rien n'est range, et on n'insiste pas avant une heure
assert.equal(await releverTelechargements(DB, T0), false);
assert.equal(await releverTelechargements(DB, T0 + 600e3), false);
assert.equal(appelsGithub, 1);
assert.equal(lire("SELECT COUNT(*) AS n FROM sqlite_master WHERE name = 'telechargements'")[0].n, 0);
// une heure plus tard : releve range
reponseGithub = () => Response.json(versionsGithub(41, 230));
assert.equal(await releverTelechargements(DB, T0 + 3601e3), true);
// et, dans la foulee, le site a ete compare a GitHub : meme version, meme empreinte
assert.equal(appelsSite, 1);
const coherence = JSON.parse(lire("SELECT valeur FROM etat WHERE cle = 'coherence'")[0].valeur);
assert.equal(coherence.ok, true);
assert.deepEqual(coherence.github, { version: "2.0.0", sha: SHA });
assert.deepEqual(coherence.site, { version: "2.0.0", sha: SHA });
const net = (x) => JSON.parse(JSON.stringify(x));      // lignes SQLite -> objets ordinaires
assert.deepEqual(net(lire("SELECT jour, version, n FROM telechargements ORDER BY version")), [
  { jour: "2026-10-06", version: "v1.9.8", n: 230 }, { jour: "2026-10-06", version: "v2.0.0", n: 41 }]);
// le meme jour : le total est remplace, pas additionne ; le lendemain : une nouvelle ligne
reponseGithub = () => Response.json(versionsGithub(50, 232));
assert.equal(await releverTelechargements(DB, T0 + 3 * 3600e3), true);
assert.equal(lire("SELECT SUM(n) AS n FROM telechargements")[0].n, 282);
reponseGithub = () => Response.json(versionsGithub(90, 240));
assert.equal(await releverTelechargements(DB, T0 + 86400e3), true);
assert.deepEqual(net(lire("SELECT jour, SUM(n) AS n FROM telechargements GROUP BY jour ORDER BY jour")),
  [{ jour: "2026-10-06", n: 282 }, { jour: "2026-10-07", n: 330 }]);
// le site en retard d'une version : verdict « differe », garde tel quel si le site tombe
pageSite = () => new Response('<p class="meta">Version 1.9.8, Windows.</p><p class="hash">75c0bcf1a1ca6ea6933d25f130e58b0b86c74f86f9d31ecd0801aa127ed550b1</p>');
await releverTelechargements(DB, T0 + 86400e3 + 7200e3);
assert.equal(JSON.parse(lire("SELECT valeur FROM etat WHERE cle = 'coherence'")[0].valeur).ok, false);
pageSite = () => { throw new Error("site injoignable"); };
await releverTelechargements(DB, T0 + 86400e3 + 2 * 3600e3 + 3601e3);
assert.equal(JSON.parse(lire("SELECT valeur FROM etat WHERE cle = 'coherence'")[0].valeur).ok, false, "dernier verdict garde");
pageSite = () => new Response('<p class="meta">Version 2.0.0</p><p class="hash">' + SHA + "</p>");
// lecture directe : empreinte en majuscules, etiquette v, brouillon ignore
assert.equal(lireCoherence(versionsGithub(1, 1), '<p class="hash">' + SHA.toUpperCase() + "</p> Version 2.0.0").ok, true);
assert.equal(lireCoherence([{ tag_name: "v2.0.0", body: "", assets: [{ name: "a.exe" }] }], "Version 2.0.0 " + SHA).ok, false, "GitHub sans empreinte");
assert.equal(lireCoherence([], "").github, null);
// reponse illisible ou panne : le releve precedent reste
reponseGithub = () => new Response("<html>", { status: 200 });
assert.equal(await releverTelechargements(DB, T0 + 2 * 86400e3), false);
reponseGithub = () => { throw new Error("reseau"); };
assert.equal(await releverTelechargements(DB, T0 + 3 * 86400e3), false);
assert.equal(lire("SELECT COUNT(*) AS n FROM telechargements")[0].n, 4);

// le service ne lit GitHub que si l'hebergeur lui donne de quoi le faire apres la reponse
const avantAppels = appelsGithub;
await envoyer("/compteur", { v: 2, app: "2.0.0", canal: "store", poste, evenements: [{ nom: "page", detail: "library", n: 1 }] });
assert.equal(appelsGithub, avantAppels);
const taches = [];
reponseGithub = () => Response.json(versionsGithub(95, 241));
const corpsC = JSON.stringify({ v: 2, app: "2.0.0", canal: "store", poste, evenements: [{ nom: "page", detail: "library", n: 1 }] });
base.prepare("DELETE FROM etat").run();
assert.equal((await worker.fetch(new Request("https://api.exemple/compteur", { method: "POST", body: corpsC,
  headers: { "content-length": String(corpsC.length) } }), { DB }, { waitUntil: (t) => taches.push(t) })).status, 200);
assert.equal(taches.length, 2);                  // telechargements, puis pilotes NVIDIA
assert.equal(await taches[0], true);
assert.equal(await taches[1], false);             // NVIDIA injoignable ici : rien d'invente
assert.equal(appelsGithub, avantAppels + 1);
globalThis.fetch = vraiFetch;

// ---------------------------------------------------------------------------
// Relais IsThereAnyDeal : la cle reste au service, les reponses sont gardees
// et rendues telles quelles
// ---------------------------------------------------------------------------
const requeteItad = (texte) => new URLSearchParams(texte);
const J1 = "018d937f-11e6-715a-a82c-205b93a2b6a2", J2 = "018d937f-2a3f-70c1-9d4e-000000000002",
  J3 = "018d937f-2a3f-70c1-9d4e-000000000003";
// seules les demandes dont ORION a besoin passent
assert.ok(lireDemandeItad("GET", "/deals/v2", requeteItad("country=FR&limit=200&mature=false&sort=-cut"), null));
assert.deepEqual(lireDemandeItad("GET", "/deals/v2", requeteItad("limit=200&country=FR"), null).params,
  [["country", "FR"], ["limit", "200"]]);                     // tries : meme demande, meme reponse gardee
assert.ok(lireDemandeItad("GET", "/games/search/v1", requeteItad("title=hades&results=12"), null));
assert.ok(lireDemandeItad("GET", "/games/lookup/v1", requeteItad("appid=1145360"), null));
assert.deepEqual(lireDemandeItad("POST", "/games/prices/v3", requeteItad("country=FR&nondeals=true&capacity=30"), [J1, J2, J1]).ids, [J1, J2]);
for (const [methode, chemin, requete, corps] of [
  ["GET", "/games/info/v2", "id=" + J1, null],                // chemin non prevu
  ["POST", "/deals/v2", "country=FR", null],                  // mauvaise methode
  ["GET", "/deals/v2", "country=FR&key=abc", null],           // une cle n'a rien a faire la
  ["GET", "/deals/v2", "country=France", null],
  ["GET", "/deals/v2", "country=FR&limit=5000", null],
  ["GET", "/deals/v2", "country=FR&country=US", null],
  ["GET", "/deals/v2", "country=FR&shops=61", null],
  ["GET", "/games/search/v1", "title=a", null],
  ["POST", "/games/prices/v3", "country=FR", null],           // pas de liste de jeux
  ["POST", "/games/prices/v3", "country=FR", []],
  ["POST", "/games/prices/v3", "country=FR", ["1 OR 1=1"]],
  ["POST", "/games/prices/v3", "country=FR", Array(61).fill(J1)],
  ["POST", "/games/historylow/v1", "country=FR&capacity=3", [J1]],
]) assert.equal(lireDemandeItad(methode, chemin, requeteItad(requete), corps), null, chemin + "?" + requete);

const CLE_ITAD = "cle-d-application-0123456789";
const itad = async (chemin, corps, env = { ITAD_CLE: CLE_ITAD }) => {
  const texte = corps ? JSON.stringify(corps) : undefined;
  const r = await worker.fetch(new Request("https://api.exemple/itad" + chemin, {
    method: corps ? "POST" : "GET", body: texte,
    headers: corps ? { "content-type": "application/json", "content-length": String(texte.length) } : {} }),
    { DB, ...env });
  return [r.status, await r.text(), r.headers];
};
let appelsItad = [], reponseItad = () => new Response("{}", { status: 500 });
globalThis.fetch = async (adresse, options) => {
  appelsItad.push({ adresse: String(adresse), corps: options.body, methode: options.method,
    type: options.headers["content-type"] });
  return reponseItad(String(adresse), options);
};
// sans secret : le relais se dit inactif et ne joint personne
assert.deepEqual(JSON.parse((await itad("/etat", null, {}))[1]), { actif: false });
assert.deepEqual(JSON.parse((await itad("/etat"))[1]), { actif: true });
let [stI, corpsI, enI] = await itad("/deals/v2?country=FR&limit=200", null, {});
assert.equal(stI, 503);
assert.deepEqual(JSON.parse(corpsI), { erreur: "relais non configure" });
assert.equal((await itad("/deals/v2?country=FR&key=x"))[0], 400);
assert.equal(appelsItad.length, 0);

// une demande : la cle est ajoutee par le service, la reponse rendue a l'octet pres
const VITRINE = '{"nextOffset":200,"hasMore":true,"list":[{"id":"' + J1 + '","title":"Hades","deal":{"url":"https://itad.link/abc/","price":{"amount":12.5}}}]}';
reponseItad = () => new Response(VITRINE, { status: 200 });
[stI, corpsI, enI] = await itad("/deals/v2?limit=200&country=FR&mature=false");
assert.equal(stI, 200);
assert.equal(corpsI, VITRINE);                                 // ni prix ni lien modifie
assert.equal(appelsItad.length, 1);
assert.equal(appelsItad[0].adresse,
  "https://api.isthereanydeal.com/deals/v2?country=FR&limit=200&mature=false&key=" + CLE_ITAD);
assert.ok(!corpsI.includes(CLE_ITAD) && ![...enI].some(([, v]) => v.includes(CLE_ITAD)));
assert.equal(appelsItad[0].type, undefined);                  // pas de type de corps sur une demande sans corps
// la meme demande, parametres dans un autre ordre : servie de memoire
reponseItad = () => { throw new Error("ne doit pas etre appele"); };
assert.equal((await itad("/deals/v2?country=FR&mature=false&limit=200"))[1], VITRINE);
assert.equal(appelsItad.length, 1);
// perimee : redemandee ; IsThereAnyDeal sature : l'ancienne reponse sert encore, et jamais de 429
base.prepare("UPDATE itad_cache SET maj = maj - 1300").run();
reponseItad = () => new Response("trop", { status: 429 });
[stI, corpsI] = await itad("/deals/v2?country=FR&mature=false&limit=200");
assert.equal(appelsItad.length, 2);
assert.equal(stI, 200);
assert.equal(corpsI, VITRINE);
[stI, corpsI] = await itad("/deals/v2?country=DE&limit=50");
assert.equal(stI, 503);
assert.deepEqual(JSON.parse(corpsI), { erreur: "relais sature" });
reponseItad = () => new Response("<html>", { status: 200 });
assert.equal((await itad("/games/search/v1?title=hades&results=12"))[0], 502);

// prix : chaque jeu est garde a part, seuls les jeux inconnus sont redemandes
appelsItad = [];
const prixDe = (id, montant) => ({ id, historyLow: { all: { amount: montant / 2 } },
  deals: [{ shop: { name: "Fanatical" }, price: { amount: montant }, url: "https://itad.link/" + id.slice(-4) + "/" }] });
reponseItad = (_a, o) => Response.json(JSON.parse(o.body).filter((id) => id !== J2).map((id) => prixDe(id, 10)));
[stI, corpsI] = await itad("/games/prices/v3?country=FR&nondeals=true&capacity=30", [J1, J2]);
assert.equal(stI, 200);
assert.deepEqual(JSON.parse(corpsI), [prixDe(J1, 10)]);        // J2 n'a pas de prix : absent, comme a la source
assert.deepEqual(JSON.parse(appelsItad[0].corps), [J1, J2]);
assert.equal(appelsItad[0].methode, "POST");
assert.equal(appelsItad[0].type, "application/json");
[stI, corpsI] = await itad("/games/prices/v3?capacity=30&country=FR&nondeals=true", [J3, J2, J1]);
assert.deepEqual(JSON.parse(appelsItad[1].corps), [J3]);       // J1 et J2 sont deja connus
assert.deepEqual(JSON.parse(corpsI).map((e) => e.id), [J3, J1]);   // dans l'ordre demande
await itad("/games/prices/v3?country=FR&nondeals=true&capacity=30", [J1, J3]);
assert.equal(appelsItad.length, 2);
// un autre pays ne recoit pas les prix du premier
await itad("/games/prices/v3?country=US&nondeals=true&capacity=30", [J1]);
assert.equal(appelsItad.length, 3);
// panne pendant qu'une partie est connue : ce qui est connu est rendu
reponseItad = () => new Response("panne", { status: 500 });
[stI, corpsI] = await itad("/games/prices/v3?country=FR&nondeals=true&capacity=30", [J1, "018d937f-2a3f-70c1-9d4e-000000000009"]);
assert.equal(stI, 200);
assert.deepEqual(JSON.parse(corpsI).map((e) => e.id), [J1]);
[stI] = await itad("/games/historylow/v1?country=FR", [J1]);
assert.equal(stI, 502);
// numeros Steam -> identifiants : une carte { jeu: identifiant }, chaque jeu garde a part
assert.equal(lireDemandeItad("POST", "/lookup/id/shop/61/v1", requeteItad(""), ["app/220", "app/311210"]).ids.length, 2);
for (const [chemin, requete, corps] of [
  ["/lookup/id/shop/61/v1", "", ["sub/220"]],                  // que des jeux
  ["/lookup/id/shop/61/v1", "", ["app/220 OR 1"]],
  ["/lookup/id/shop/61/v1", "", [J1]],
  ["/lookup/id/shop/61/v1", "", []],
  ["/lookup/id/shop/61/v1", "", Array.from({ length: 91 }, (_x, i) => "app/" + i)],
  ["/lookup/id/shop/61/v1", "country=FR", ["app/220"]],        // aucun parametre admis
  ["/lookup/id/shop/35/v1", "", ["app/220"]],                  // que le magasin Steam
  ["/games/prices/v3", "country=FR", ["app/220"]],             // et pas ailleurs
]) assert.equal(lireDemandeItad("POST", chemin, requeteItad(requete), corps), null, chemin + " " + JSON.stringify(corps).slice(0, 40));
assert.ok(lireDemandeItad("POST", "/lookup/id/shop/61/v1", requeteItad(""), Array.from({ length: 90 }, (_x, i) => "app/" + i)));
appelsItad = [];
reponseItad = (_a, o) => Response.json(Object.fromEntries(JSON.parse(o.body).map((a) => [a, a === "app/9" ? null : J1])));
[stI, corpsI] = await itad("/lookup/id/shop/61/v1", ["app/220", "app/9"]);
assert.equal(stI, 200);
assert.deepEqual(JSON.parse(corpsI), { "app/220": J1, "app/9": null });      // inconnu : null, comme a la source
assert.match(appelsItad[0].adresse, /^https:\/\/api\.isthereanydeal\.com\/lookup\/id\/shop\/61\/v1\?key=/);
assert.deepEqual(JSON.parse(appelsItad[0].corps), ["app/220", "app/9"]);
reponseItad = (_a, o) => Response.json(Object.fromEntries(JSON.parse(o.body).map((a) => [a, J3])));
[stI, corpsI] = await itad("/lookup/id/shop/61/v1", ["app/9", "app/311210", "app/220"]);
assert.deepEqual(JSON.parse(appelsItad[1].corps), ["app/311210"]);           // les deux autres sont connus, null compris
assert.deepEqual(JSON.parse(corpsI), { "app/9": null, "app/311210": J3, "app/220": J1 });
// une liste a la place de la carte : rien n'est garde, rien d'invente
reponseItad = () => Response.json([J1]);
[stI] = await itad("/lookup/id/shop/61/v1", ["app/777"]);
assert.equal(stI, 502);
reponseItad = () => new Response("panne", { status: 500 });
// plafond du jour : plus aucun appel
const jourItad = "itad_" + jourLocal();                     // le jour de Paris, comme le service (le test echouait entre 22 h et minuit UTC)
assert.ok(Number(lire("SELECT valeur FROM etat WHERE cle = '" + jourItad + "'")[0].valeur) >= 9);
base.prepare("UPDATE etat SET valeur = '40000' WHERE cle = ?").run(jourItad);
const avantPlafond = appelsItad.length;
[stI, corpsI] = await itad("/games/lookup/v1?appid=1145360");
assert.equal(stI, 503);
assert.equal(appelsItad.length, avantPlafond);
base.prepare("DELETE FROM etat WHERE cle = ?").run(jourItad);
globalThis.fetch = vraiFetch;

// ---------------------------------------------------------------------------
// Tableau de suivi : ferme sans la cle, lecture seule, texte libre jamais execute
// ---------------------------------------------------------------------------
const CLE = "essai-" + "x".repeat(30);
const lireTableau = async (chemin, env, cle) => {
  const r = await worker.fetch(new Request("https://api.exemple" + chemin, {
    headers: cle === undefined ? {} : { authorization: "Bearer " + cle } }), { DB, ...env });
  return [r.status, r.headers, await r.text()];
};
// la page : publique, sans un seul chiffre, et verrouillee par ses en-tetes
let [stT, enT, pageT] = await lireTableau("/tableau", {});
assert.equal(stT, 200);
assert.match(enT.get("content-type"), /text\/html/);
assert.match(enT.get("content-security-policy"), /default-src 'none'/);
assert.equal(enT.get("cache-control"), "no-store");
assert.ok(pageT.includes("ORION") && pageT.includes("CLE_TABLEAU") && !pageT.includes(CLE));
assert.ok(!/innerHTML|insertAdjacentHTML|document\.write|eval\(/.test(pageT), "texte recu : jamais interprete");
// de quoi l'installer sur l'ecran d'accueil : un nom et une icone, publics eux aussi
const manifeste = await worker.fetch(new Request("https://api.exemple/tableau/application.webmanifest"), { DB });
assert.match(manifeste.headers.get("content-type"), /manifest\+json/);
const m = await manifeste.json();
assert.equal(m.start_url, "/tableau");
assert.equal(m.display, "standalone");
assert.deepEqual([...new Set(m.icons.map((i) => i.sizes))], ["192x192", "512x512"]);
for (const i of m.icons) {
  const r = await worker.fetch(new Request("https://api.exemple" + i.src), { DB });
  const octets = new Uint8Array(await r.arrayBuffer());
  assert.equal(r.headers.get("content-type"), "image/png");
  assert.deepEqual([...octets.slice(0, 8)], [137, 80, 78, 71, 13, 10, 26, 10]);
  // largeur lue dans l'en-tete du fichier : c'est bien la taille annoncee
  assert.equal(new DataView(octets.buffer).getUint32(16), Number(i.sizes.split("x")[0]));
}
assert.ok(pageT.includes('rel="manifest"'));
// sans secret range, ou avec un secret trop court : ferme, meme avec la « bonne » cle
assert.equal((await lireTableau("/tableau/donnees", {}, CLE))[0], 503);
assert.equal((await lireTableau("/tableau/donnees", { CLE_TABLEAU: "court" }, "court"))[0], 503);
assert.equal((await lireTableau("/tableau/donnees", { CLE_TABLEAU: "" }, ""))[0], 503);
// secret range : rien sans cle, rien avec une cle fausse, proche ou vide
for (const fausse of [undefined, "", CLE + "x", CLE.slice(0, -1), CLE.toUpperCase(), "Bearer " + CLE]) {
  const [st, , corps] = await lireTableau("/tableau/donnees", { CLE_TABLEAU: CLE }, fausse);
  assert.equal(st, 401, "cle " + fausse);
  assert.deepEqual(JSON.parse(corps), { erreur: "cle refusee" });
}
for (const chemin of ["/tableau/signalement?id=1", "/tableau/autre", "/tableau/"]) {
  assert.equal((await lireTableau(chemin, { CLE_TABLEAU: CLE }, "fausse"))[0], 401, chemin);
}
// le tableau ne s'ecrit pas
const ecrit = await worker.fetch(new Request("https://api.exemple/tableau/donnees", {
  method: "POST", headers: { authorization: "Bearer " + CLE } }), { DB, CLE_TABLEAU: CLE });
assert.equal(ecrit.status, 404);

// un envoi du compteur entre dans le fil avec son heure d'arrivee, sans identifiant
const posteT = "fedcba9876543210fedcba9876543210";
const avantFil = lire("SELECT COUNT(*) AS n FROM journal")[0].n;
assert.equal((await envoyer("/compteur", { v: 2, app: "2.0.0", canal: "store", poste: posteT, evenements: [
  { nom: "ouverture", n: 1 }, { nom: "page", detail: "boutique", n: 2 },
  { nom: "clic", detail: "gamesplanet", origine: "fiche", n: 3 }] }, { country: "FR", region: "Bretagne" }))[0], 200);
const fil = lire("SELECT * FROM journal ORDER BY id DESC LIMIT 3");
assert.equal(lire("SELECT COUNT(*) AS n FROM journal")[0].n, avantFil + 3);
assert.deepEqual(fil.map((l) => l.nom).sort(), ["clic", "ouverture", "page"]);
assert.ok(fil.every((l) => Math.abs(l.quand - Date.now() / 1000) < 5));
assert.deepEqual(Object.keys(fil[0]).sort(), ["detail", "id", "n", "nom", "origine", "quand"]);
assert.ok(!JSON.stringify(lire("SELECT * FROM journal")).includes(posteT));
// le fil ne garde que trente jours
base.prepare("INSERT INTO journal (quand, nom, detail, origine, n) VALUES (?,?,?,?,?)")
  .run(Math.floor(Date.now() / 1000) - 31 * 86400, "clic", "ancien", "", 1);
await envoyer("/compteur", { v: 2, app: "2.0.0", canal: "store", poste: posteT,
  evenements: [{ nom: "page", detail: "library", n: 1 }] });
assert.equal(lire("SELECT COUNT(*) AS n FROM journal WHERE detail = 'ancien'")[0].n, 0);

// un signalement malveillant : rendu tel quel, comme du texte
const piege = "<img src=x onerror=alert(1)>";
const [, bug] = await envoyer("/signalement", { v: 1, poste: posteT, app: "2.0.0", titre: piege,
  description: "<script>alert(2)</script>", erreur: "Traceback", rapport: "R".repeat(900) });
// lecteurs du flux RSS (11 octobre, soir) : une famille, et les abonnes annonces, rien d'autre
assert.deepEqual(lecteurRss("Feedly/1.0 (+http://www.feedly.com/fetcher.html; 12 subscribers; like FeedFetcher-Google)"),
                 { famille: "feedly", abonnes: 12 });
assert.equal(lecteurRss("MonitoRSS [Feed Fetcher] (+https://monitorss.xyz)").famille, "monitorss");
assert.equal(lecteurRss("Mozilla/5.0 (Windows NT 10.0) Chrome/130").famille, "navigateur");
assert.equal(lecteurRss("python-requests/2.31").famille, "robot");
assert.equal(lecteurRss("").famille, "autre");
const jourF = jourLocal();
await compterLectureRss(DB, "Feedly/1.0 (+http://www.feedly.com/fetcher.html; 12 subscribers; )", jourF);
await compterLectureRss(DB, "Feedly/1.0 (+http://www.feedly.com/fetcher.html; 9 subscribers; )", jourF);
await compterLectureRss(DB, "MonitoRSS [Feed Fetcher]", jourF);
await compterLectureRss(DB, "MonitoRSS [Feed Fetcher]", jourF);
await compterLectureRss(DB, "Mozilla/5.0 Chrome/130", jourF);
assert.equal(lire("SELECT n FROM compteurs WHERE nom = 'flux-abonnes' AND detail = 'feedly'")[0].n, 12);   // le plus grand, pas la somme
assert.ok(!JSON.stringify(lire("SELECT * FROM compteurs WHERE nom LIKE 'flux%'")).includes("fetcher.html"));
// la route compte sans attendre, et repond meme si les boutiques sont injoignables
const fetchVrai = globalThis.fetch, attente = [];
globalThis.fetch = async () => new Response("", { status: 503 });
const rRss = await worker.fetch(new Request("https://api.exemple/gratuits.rss", { headers: { "user-agent": "Thunderbird/128.0" } }),
                                { DB }, { waitUntil: (p) => attente.push(p) });
await Promise.all(attente);
globalThis.fetch = fetchVrai;
assert.equal(rRss.status, 200);
assert.equal(lire("SELECT n FROM compteurs WHERE nom = 'flux' AND detail = 'thunderbird'")[0].n, 1);
let [stD, enD, corpsD] = await lireTableau("/tableau/donnees?jours=7", { CLE_TABLEAU: CLE }, CLE);
assert.equal(stD, 200);
assert.equal(enD.get("cache-control"), "no-store");
assert.match(enD.get("content-type"), /application\/json/);
const d = JSON.parse(corpsD);
const aujourdhui = jourLocal();
assert.equal(d.jours, 7);
assert.equal(d.aujourdhui, aujourdhui);
assert.equal(d.fuseau, "Europe/Paris");
assert.deepEqual(Object.fromEntries(d.flux.lectures.map((l) => [l.detail, l.n])),
                 { feedly: 2, monitorss: 2, navigateur: 1, thunderbird: 1 });
assert.deepEqual(d.flux.abonnes, [{ detail: "feedly", n: 12 }]);
assert.equal(d.flux.aujourdhui, 6);
// heure de Paris : un jour civil francais, une heure a deux chiffres
assert.equal(jourLocal(Date.parse("2026-10-06T23:30:00Z")), "2026-10-07");
assert.equal(jourLocal(Date.parse("2026-01-15T23:30:00Z")), "2026-01-16");
assert.equal(heureLocale(Date.parse("2026-10-06T23:30:05Z")), "01:30:05");
assert.equal(heureLocale(Date.parse("2026-10-06T22:00:00Z")), "00:00:00");
assert.equal(d.signalements.liste[0].heure, lire("SELECT heure FROM signalements ORDER BY id DESC LIMIT 1")[0].heure);
assert.match(d.signalements.liste[0].heure, /^\d\d:\d\d:\d\d$/);
assert.equal(d.signalements.liste[0].note, "");
// sante du service : les refus comptes par route, les tables pesees
assert.ok(d.service.aujourdhui.refus >= 1, "des demandes refusees ont ete comptees plus haut");
assert.ok(d.service.erreurs.every((x) => x.route && x.code >= 400 && x.n >= 1));
assert.ok(d.service.erreurs.some((x) => x.route === "/compteur" && x.code === 400));
assert.equal(d.service.esprit.max, 150);
assert.equal(d.service.esprit.configure, false);
assert.equal(d.service.itad.configure, false);
assert.ok(d.service.tables.signalements >= 1 && d.service.tables.journal >= 1 && d.service.tables.fluidite >= 0);
assert.equal(d.service.coherence.ok, true);
assert.equal(routeSante("/prix/lot"), "/prix/lot");
assert.equal(routeSante("/prix?appid=1"), "/prix");
assert.equal(routeSante("/itad/games/lookup/v1"), "/itad");
assert.equal(routeSante("/wp-admin"), "autre");
// une adresse au hasard : refusee, mais pas comptee ; un corps illisible : compte
const avantSante = lire("SELECT COALESCE(SUM(n), 0) AS n FROM sante")[0].n;
assert.equal((await worker.fetch(new Request("https://api.exemple/wp-login.php"), { DB })).status, 404);
assert.equal(lire("SELECT COALESCE(SUM(n), 0) AS n FROM sante")[0].n, avantSante);
assert.equal((await envoyer("/signalement", "pas un objet"))[0], 400);
assert.equal(lire("SELECT n FROM sante WHERE route = '/signalement' AND code = 400 AND jour = ?".replace("?", "'" + aujourdhui + "'"))[0].n >= 1, true);
assert.equal(lire("SELECT COALESCE(SUM(n), 0) AS n FROM sante")[0].n, avantSante + 1);
// une exception imprevue : reponse 500, comptee
const DBcassee = { prepare() { throw new Error("base en panne"); } };
const r500 = await worker.fetch(new Request("https://api.exemple/mesures.json"), { DB: DBcassee });
assert.equal(r500.status, 500);
assert.deepEqual(await r500.json(), { erreur: "erreur interne" });
// fluidite : le bilan d'une session 2.0.1, des additions sans identifiant
assert.equal(validerSante(null), null);
assert.equal(validerSante({ arrets: -1 }), null);
assert.deepEqual(net(validerSante({ arrets: "3", duree_ms: 900, erreurs: 0, demarrage_ms: 1800, causes: [
  { pile: "boutique_view._rendre:2046 < main_window._boutique_actualisee:1590", n: 2, ms: 700 },
  { pile: "C:/Users/moi/jeu.exe", n: 1, ms: 5 }, { pile: "free_view.__init__:111", n: "x", ms: 1 },
  { pile: "a.b", n: 1, ms: 1 }, { pile: "x".repeat(200) + ".y", n: 1, ms: 1 }] }).causes.map((c) => c.pile)),
  ["boutique_view._rendre:2046 < main_window._boutique_actualisee:1590", "a.b"]);
assert.equal(validerSante({ arrets: 0, duree_ms: 0, erreurs: 0 }).demarrage, null);
const envoiSante = { v: 3, app: "2.0.1", canal: "installateur", poste: posteT, evenements: [],
  sante: { arrets: 3, duree_ms: 900, erreurs: 1, demarrage_ms: 1800, causes: [{ pile: "boutique_view._rendre:2046", n: 2, ms: 700 }, { pile: "free_view.__init__:111", n: 1, ms: 200 }] } };
assert.equal((await envoyer("/compteur", envoiSante))[0], 200, "un bilan seul suffit");
assert.equal((await envoyer("/compteur", envoiSante))[0], 200);
assert.equal((await envoyer("/compteur", { ...envoiSante, v: 2 }))[0], 400, "v 2 : pas de bilan, et rien d'autre a compter");
assert.deepEqual(net(lire("SELECT cle, detail, n, total FROM fluidite WHERE app = '2.0.1' ORDER BY cle, detail")), [
  { cle: "cause", detail: "boutique_view._rendre:2046", n: 4, total: 1400 }, { cle: "cause", detail: "free_view.__init__:111", n: 2, total: 400 },
  { cle: "demarrage", detail: "", n: 2, total: 3600 }, { cle: "duree", detail: "", n: 2, total: 1800 },
  { cle: "erreurs", detail: "", n: 2, total: 2 }, { cle: "session", detail: "", n: 2, total: 6 }]);
const dF = JSON.parse((await lireTableau("/tableau/donnees?jours=7", { CLE_TABLEAU: CLE }, CLE))[2]).fluidite;
assert.equal(dF.sessions, 2);
assert.equal(dF.arrets, 6);
assert.equal(dF.causes[0].detail, "boutique_view._rendre:2046");
assert.deepEqual(net(dF.demarrages), { n: 2, t: 3600 });
assert.ok(dF.versions.some((v) => v.app === "2.0.1" && v.sessions === 2));
assert.ok(!JSON.stringify(dF).includes(posteT));
assert.equal(d.pc.aujourdhui, lire("SELECT COUNT(*) AS n FROM actifs WHERE jour = ?".replace("?", "'" + aujourdhui + "'"))[0].n);
assert.ok(d.pc.aujourdhui >= 2 && d.pc.periode >= d.pc.aujourdhui && d.pc.nouveaux >= d.pc.aujourdhui);
assert.equal(d.pc.parJour.at(-1).jour, aujourdhui);
assert.ok(d.pc.parJour.at(-1).store >= 1);
assert.ok(d.pc.versions.some((x) => x.app === "2.0.0"));
const clicT = d.compteurs.find((l) => l.nom === "clic" && l.detail === "gamesplanet" && l.origine === "fiche");
assert.equal(clicT.n, 3);
assert.equal(d.compteurs.filter((l) => l.nom === "clic").reduce((s, l) => s + l.n, 0),
  lire("SELECT SUM(n) AS n FROM compteurs WHERE nom = 'clic'")[0].n);
assert.ok(d.compteurs.every((l, i, t) => !i || t[i - 1].n >= l.n), "tries du plus au moins");
assert.equal(d.fil[0].nom, "page");                      // le plus recent d'abord
assert.ok(d.fil.every((l, i, t) => !i || t[i - 1].quand >= l.quand));
assert.equal(d.heures.reduce((s, h) => s + h.n, 0), lire("SELECT SUM(n) AS n FROM journal")[0].n);
assert.ok(d.zones.some((z) => z.pays === "FR" && z.region === "Bretagne" && z.pc >= 1 && z.clics >= 3));
assert.ok(d.signalements.attente >= 1 && d.signalements.total >= d.signalements.attente);
assert.equal(d.signalements.liste[0].titre, piege);
assert.equal(d.signalements.liste[0].pc.length, 6);
assert.ok(!("rapport" in d.signalements.liste[0]) && !("poste" in d.signalements.liste[0]));
assert.ok(!corpsD.includes(posteT) && !/[0-9a-f]{32}/.test(corpsD.split(SHA).join("")), "aucun identifiant de poste ne sort");
// telechargements : un total par jour releve, et le detail du dernier releve
assert.ok(d.telechargements.releve > 0);
assert.equal(d.telechargements.premier, "2026-10-06");
const jourReleve = lire("SELECT MAX(jour) AS j FROM telechargements")[0].j;
assert.deepEqual(d.telechargements.versions.map((x) => x.version), ["v2.0.0", "v1.9.8"]);
assert.equal(d.telechargements.versions.reduce((t, x) => t + x.n, 0),
  lire("SELECT SUM(n) AS n FROM telechargements WHERE jour = '" + jourReleve + "'")[0].n);
assert.ok(d.telechargements.parJour.every((x, i, t) => !i || t[i - 1].jour < x.jour));
// periode inconnue : sept jours ; un jour : seulement aujourd'hui
assert.equal(JSON.parse((await lireTableau("/tableau/donnees?jours=9999", { CLE_TABLEAU: CLE }, CLE))[2]).jours, 7);
const unJour = JSON.parse((await lireTableau("/tableau/donnees?jours=1", { CLE_TABLEAU: CLE }, CLE))[2]);
assert.equal(unJour.depuis, aujourdhui);
assert.equal(unJour.pc.parJour.length <= 14, true);
// le signalement en entier, pour le porteur de la cle seulement
const [stB, , corpsB] = await lireTableau("/tableau/signalement?id=" + bug.numero, { CLE_TABLEAU: CLE }, CLE);
assert.equal(stB, 200);
assert.equal(JSON.parse(corpsB).rapport.length, 900);
assert.equal((await lireTableau("/tableau/signalement?id=999999", { CLE_TABLEAU: CLE }, CLE))[0], 404);
assert.equal((await lireTableau("/tableau/signalement?id=1;DROP", { CLE_TABLEAU: CLE }, CLE))[0], 404);
// rien n'a ete modifie par ces lectures
assert.equal(lire("SELECT COUNT(*) AS n FROM signalements WHERE traite = 1")[0].n, 0);
// la seule ecriture : marquer traite, avec une note ; refusee sans la cle
const traiter = async (corps, cle = CLE) => {
  const t = JSON.stringify(corps);
  const r = await worker.fetch(new Request("https://api.exemple/tableau/signalement/traiter", { method: "POST", body: t,
    headers: { authorization: "Bearer " + cle, "content-type": "application/json", "content-length": String(t.length) } }),
    { DB, CLE_TABLEAU: CLE });
  return [r.status, await r.json()];
};
assert.equal((await traiter({ id: bug.numero, traite: true }, "fausse"))[0], 401);
assert.equal((await traiter({ id: "1;DROP", traite: true }))[0], 400);
assert.equal((await traiter({ id: 999999, traite: true }))[0], 404);
assert.deepEqual((await traiter({ id: bug.numero, traite: true, note: "Corrigé en 2.0.1 <b>" }))[1], { ok: true, id: bug.numero, traite: 1 });
const apres = lire("SELECT traite, note FROM signalements WHERE id = " + bug.numero)[0];
assert.equal(apres.traite, 1);
assert.equal(apres.note, "Corrigé en 2.0.1 <b>");       // du texte, jamais interprete
const dA = JSON.parse((await lireTableau("/tableau/donnees?jours=7", { CLE_TABLEAU: CLE }, CLE))[2]);
assert.equal(dA.signalements.attente, d.signalements.attente - 1);
assert.equal(dA.signalements.liste.find((b) => b.id === bug.numero).note, "Corrigé en 2.0.1 <b>");
assert.equal(JSON.parse((await lireTableau("/tableau/signalement?id=" + bug.numero, { CLE_TABLEAU: CLE }, CLE))[2]).traite, 1);
assert.deepEqual((await traiter({ id: bug.numero, traite: false, note: "x".repeat(600) }))[1], { ok: true, id: bug.numero, traite: 0 });
assert.equal(lire("SELECT LENGTH(note) AS n FROM signalements WHERE id = " + bug.numero)[0].n, 500);
assert.equal(lire("SELECT COUNT(*) AS n FROM signalements WHERE traite = 1")[0].n, 0);

// --------------------------------------------------------------------------
// pilotes NVIDIA : la derniere version par serie, relevee une fois par jour
// --------------------------------------------------------------------------
const reponseNvidia = (version, date, nom = "GeForce%20Game%20Ready%20Driver") => ({
  Success: "1", IDS: [{ downloadInfo: { Version: version, ReleaseDateTime: date, Name: nom, OSName: "Windows%2011",
    IsWHQL: "1", DetailsURL: "https://www.nvidia.com/en-us/drivers/details/280103/",
    DownloadURL: `https://us.download.nvidia.com/Windows/${version}/${version}-desktop-win10-win11-64bit-international-dch-whql.exe` } }] });
assert.deepEqual(lireNvidia(reponseNvidia("617.42", "Tue Oct 06, 2026")), {
  version: "617.42", date: "2026-10-06", nom: "GeForce Game Ready Driver",
  details: "https://www.nvidia.com/en-us/drivers/details/280103/",
  fichier: "https://us.download.nvidia.com/Windows/617.42/617.42-desktop-win10-win11-64bit-international-dch-whql.exe" });
assert.equal(lireNvidia({ Success: "0", IDS: [{ downloadInfo: { Success: "0", ID: "" } }] }), null);
assert.equal(lireNvidia(reponseNvidia("abc", "x")), null);
assert.equal(lireNvidia({ IDS: [{ downloadInfo: { Version: "617.42", DetailsURL: "https://pirate.example/", DownloadURL: "https://us.download.nvidia.com/x.exe" } }] }), null);
let appelsNvidia = 0;
globalThis.fetch = async (adresse) => {
  const u = new URL(String(adresse));
  assert.equal(u.host, "gfwsl.geforce.com");
  appelsNvidia += 1;
  const psid = u.searchParams.get("psid");
  if (psid === "101") return Response.json(reponseNvidia("582.78", "Wed Sep 30, 2026", "GeForce%20Security%20Update%20Driver"));
  if (psid === "133") return new Response("panne", { status: 500 });
  return Response.json(reponseNvidia("617.42", "Tue Oct 06, 2026"));
};
const TP = Date.parse("2026-10-08T09:00:00Z");
base.prepare("DELETE FROM etat WHERE cle IN ('pilotes_essai', 'pilotes')").run();   // l'essai du compteur a deja tente
assert.equal(await releverPilotes(DB, TP), true);
assert.equal(appelsNvidia, 9);
const pil = JSON.parse(lire("SELECT valeur FROM etat WHERE cle = 'pilotes'")[0].valeur);
assert.equal(pil.nvidia["40"].version, "617.42");
assert.equal(pil.nvidia["10"].version, "582.78");
assert.equal(pil.nvidia["10"].nom, "GeForce Security Update Driver");
assert.equal(pil.nvidia["50p"], undefined);                 // serie en panne : absente, pas inventee
assert.equal(pil.maj, "2026-10-08T09:00:00.000Z");
// pas de nouveau releve avant vingt heures ; la route sert la valeur gardee
assert.equal(await releverPilotes(DB, TP + 3600e3), false);
assert.equal(appelsNvidia, 9);
const rp = await worker.fetch(new Request("https://api.orion-launcher.com/pilotes"), { DB }, { waitUntil() {} });
assert.equal(rp.status, 200);
assert.equal((await rp.json()).nvidia["40"].details, "https://www.nvidia.com/en-us/drivers/details/280103/");
assert.equal(rp.headers.get("access-control-allow-origin"), "*");
globalThis.fetch = vraiFetch;

// recettes apprises par l'exemple (10 octobre) : gardees, jamais publiees seules
const recetteOk = { id: "exemple_aniimo", name: "Aniimo (appris par l'exemple)",
  match: { title: ["Aniimo"], appid: [2919500] }, confidence: "exact", creer_cles: false,
  derive: { ex_0: { from: "quality", map: { 0: "1", 1: "2", 2: "4", 3: "4" } } },
  targets: [{ format: "registry", paths: ["HKCU/Software/Aniimo/Aniimo"],
    entries: [{ key: "CBT2_VideoQuality_h3343041345", value: "{ex_0}" }] }] };
assert.equal((await envoyer("/recette", { poste, app: "2.1.0", recette: recetteOk }))[0], 200);
for (const piege of [
  { ...recetteOk, id: "cyberpunk2077" },                                              // pas une recette apprise
  { ...recetteOk, targets: [{ format: "registry", paths: ["HKCU/Software/Microsoft/Windows/CurrentVersion/Run"],
      entries: [{ key: "x", value: "c:/x.exe" }] }] },                                 // demarrage de Windows
  { ...recetteOk, targets: [{ format: "ini", paths: ["C:/Windows/win.ini"], entries: [{ key: "a", value: "1" }] }] },
  { ...recetteOk, targets: [{ format: "ini", paths: ["%APPDATA%/../x.ini"], entries: [{ key: "a", value: "1" }] }] },
  { ...recetteOk, script: "rm -rf" },                                                  // champ inconnu
]) {
  assert.equal((await envoyer("/recette", { poste, app: "2.1.0", recette: piege }))[0], 400, JSON.stringify(piege).slice(0, 80));
}
assert.equal(lire("SELECT COUNT(*) AS n FROM recettes")[0].n, 1);

// le comparateur du site : prix lisibles par le site d'ORION, et lui seul
{
  const { ouvrirAuSite } = await import("./worker.js");
  const rep = () => new Response("{}", { headers: { "content-type": "application/json" } });
  const req = (chemin, origine) => new Request("https://api.exemple" + chemin, { headers: origine ? { origin: origine } : {} });
  assert.equal(ouvrirAuSite(req("/prix?appid=1", "https://orion-launcher.com"), rep()).headers.get("access-control-allow-origin"), "https://orion-launcher.com");
  assert.equal(ouvrirAuSite(req("/itad/games/prices/v3", "https://orion-launcher.com"), rep()).headers.get("access-control-allow-origin"), "https://orion-launcher.com");
  assert.equal(ouvrirAuSite(req("/prix?appid=1", "https://autre.example"), rep()).headers.get("access-control-allow-origin"), null);
  assert.equal(ouvrirAuSite(req("/tableau", "https://orion-launcher.com"), rep()).headers.get("access-control-allow-origin"), null);
  assert.equal(ouvrirAuSite(req("/itad/deals/v2", "https://orion-launcher.com"), rep()).headers.get("access-control-allow-origin"), null);
  assert.equal(ouvrirAuSite(req("/gratuits", "https://orion-launcher.com"), rep()).headers.get("access-control-allow-origin"),
               "https://orion-launcher.com");
}

// --- /gratuits (11 octobre) : Epic et GamerPower, offres a garder seulement
{
  const maintenant = Date.parse("2026-10-11T10:00:00Z");
  const epic = { data: { Catalog: { searchStore: { elements: [
    { title: "Jeu Offert", offerType: "BASE_GAME", catalogNs: { mappings: [{ pageSlug: "jeu-offert" }] },
      keyImages: [{ type: "Thumbnail", url: "https://cdn1.epicgames.com/x/thumb.png" },
                  { type: "OfferImageWide", url: "https://cdn1.epicgames.com/x/wide.jpg?h=480&w=854" }],
      price: { totalPrice: { discountPrice: 0, originalPrice: 1999 } },
      promotions: { promotionalOffers: [{ promotionalOffers: [{ startDate: "2026-10-08T15:00:00Z",
        endDate: "2026-10-15T15:00:00Z", discountSetting: { discountPercentage: 0 } }] }] } },
    { title: "Pas Gratuit", price: { totalPrice: { discountPrice: 500 } },
      promotions: { promotionalOffers: [{ promotionalOffers: [{ discountSetting: { discountPercentage: 50 } }] }] } },
    { title: "Un DLC", offerType: "DLC", catalogNs: { mappings: [{ pageSlug: "dlc" }] },
      price: { totalPrice: { discountPrice: 0 } },
      promotions: { promotionalOffers: [{ promotionalOffers: [{ discountSetting: { discountPercentage: 0 } }] }] } },
  ] } } } };
  const e = lireEpic(epic, maintenant);
  assert.equal(e.length, 1);
  assert.equal(e[0].url, "https://store.epicgames.com/fr/p/jeu-offert");
  assert.equal(e[0].valeur, "19,99 €");
  const gp = lireGamerPower([
    { title: "Dwarven Realms (Steam) Key Giveaway", platforms: "PC, Steam", status: "Active", worth: "$4.99",
      published_date: "2026-10-09 18:20:00", image: "https://www.gamerpower.com/offers/1b/dwarven.png",
      end_date: "2026-10-20 23:59:00", open_giveaway_url: "https://www.gamerpower.com/open/dwarven-realms" },
    { title: "Best Plumber (PC) Giveaway", platforms: "PC, DRM-Free", status: "Active", worth: "$1,299.99",
      image: "javascript:alert(1)", thumbnail: "https://x.y/a b.jpg",
      open_giveaway_url: "https://www.gamerpower.com/open/best-plumber" },
    { title: "Mindcop (Epic Games) Giveaway", platforms: "PC, Epic Games Store", status: "Active",
      open_giveaway_url: "https://www.gamerpower.com/open/mindcop" },
    { title: "Some Game Free Weekend", platforms: "PC, Steam", status: "Active",
      open_giveaway_url: "https://www.gamerpower.com/open/x" },
  ]);
  assert.deepEqual(gp.map((g) => [g.titre, g.boutique]), [["Dwarven Realms", "Steam"], ["Best Plumber", "Sans DRM"]]);
  // 12 octobre : IndieGala demande un compte, et sa valeur annoncee n'est pas montree
  const ig = lireGamerPower([{ title: "Wordle (IndieGala) Giveaway", platforms: "PC, DRM-Free", status: "Active",
    worth: "$29.99", instructions: "2. Login into your free IndieGala account.",
    open_giveaway_url: "https://www.gamerpower.com/open/wordle" }]);
  assert.deepEqual(ig.map((g) => [g.titre, g.boutique, g.valeur]), [["Wordle", "IndieGala", ""]]);
  assert.ok(rssGratuits(ig, Date.UTC(2026, 9, 12)).includes("Wordle : gratuit sur IndieGala</title>"));
  assert.equal(gp[0].fin, "2026-10-20T23:59:00");
  assert.equal(gp[0].debut, "2026-10-09T18:20:00");
  assert.equal(gp[0].valeur, "4,99 $");                 // virgule, comme « 19,99 € »
  assert.equal(gp[1].valeur, "1299,99 $");
  assert.equal(e[0].debut, "2026-10-08T15:00:00.000Z");
  // jaquettes (11 octobre, soir) : la grande image d'Epic d'abord ; une adresse douteuse est ignoree
  assert.equal(e[0].image, "https://cdn1.epicgames.com/x/wide.jpg?h=480&w=854");
  assert.equal(gp[0].image, "https://www.gamerpower.com/offers/1b/dwarven.png");
  assert.equal(gp[1].image, "");
  assert.equal(imageSure("https://a.b/c.jpg\"><script>"), "");
  // flux RSS : un article par jeu, vers la ligne du jeu sur la page du site, texte echappe
  assert.equal(ancreGratuit("Tom Clancy’s Élan & Co"), "tom-clancy-s-elan-co");
  const flux = rssGratuits([...e, { titre: "A <b>&</b>", boutique: "GOG", url: "https://www.gog.com/x", fin: "", valeur: "" }],
                           Date.UTC(2026, 9, 11, 10));
  assert.ok(flux.startsWith('<?xml version="1.0" encoding="UTF-8"?>'));
  assert.equal((flux.match(/<item>/g) || []).length, 2);
  assert.ok(flux.includes("<link>https://orion-launcher.com/gratuits#jeu-offert</link>"));
  assert.ok(flux.includes("A &lt;b&gt;&amp;&lt;/b&gt; : gratuit sur GOG</title>"));
  assert.ok(flux.includes('<atom:link href="https://api.orion-launcher.com/gratuits.rss" rel="self"'));
  assert.ok(!/<item>[^]*<item>[^]*<item>/.test(flux));
  // 11 octobre, soir : la date d'un article est le début de l'offre, pas l'heure du relevé ;
  // sans date connue, minuit UTC du jour (stable entre deux relevés)
  assert.ok(flux.includes("<pubDate>Thu, 08 Oct 2026 15:00:00 GMT</pubDate>"));
  assert.ok(flux.includes("<pubDate>Sun, 11 Oct 2026 00:00:00 GMT</pubDate>"));
  assert.ok(!flux.includes("<pubDate>Sun, 11 Oct 2026 10:00:00 GMT</pubDate>"));
  const deux = rssGratuits(gp, Date.UTC(2026, 9, 11, 10, 15));
  assert.equal(rssGratuits(gp, Date.UTC(2026, 9, 11, 10)).replace(/<lastBuildDate>[^<]*/, ""),
               deux.replace(/<lastBuildDate>[^<]*/, ""));     // deux relevés, mêmes articles
  assert.ok(deux.includes("Best Plumber : gratuit, sans DRM</title>"));
  assert.ok(deux.includes("Best Plumber est offert sans DRM, en téléchargement direct (valeur 1299,99 $)."));
  assert.ok(!deux.includes("sur Sans DRM"));
  // l'image part dans le flux sous les deux formes que lisent les robots et les lecteurs
  assert.ok(flux.includes('xmlns:media="http://search.yahoo.com/mrss/"'));
  assert.ok(flux.includes('<enclosure url="https://cdn1.epicgames.com/x/wide.jpg?h=480&amp;w=854" length="0" type="image/jpeg"/>'));
  assert.ok(flux.includes('<media:content url="https://cdn1.epicgames.com/x/wide.jpg?h=480&amp;w=854" medium="image" type="image/jpeg"/>'));
  assert.ok(deux.includes('type="image/png"/>'));
  assert.equal((deux.match(/<enclosure/g) || []).length, 1);     // Best Plumber : pas d'image sure, pas de balise
}

console.log("service ok");
