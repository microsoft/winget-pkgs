# ORION — Game Launcher

**ORION lit votre PC et vous dit quoi jouer, avec quels réglages, à quel prix.**

Launcher de jeux gratuit pour Windows : il détecte tous les jeux
installés sur la machine, récupère leurs jaquettes, analyse le matériel et les
écrans, puis lance chaque jeu avec des réglages graphiques calculés pour votre
PC — **« Votre écran »** (le plus beau réglage qui tient la fréquence de votre
écran) ou **« Mon choix »** (vos graphismes et vos images par seconde). Une
Boutique qui compare les prix sur des sites sûrs, des fiches de jeu complètes
(infos, succès, captures, vidéos) et des conseils sur vos pilotes et réglages
Windows complètent l'ensemble.

---

## Installation

Double-cliquer sur **`Installateur-ORION.exe`**. Une fenêtre demande où
installer l'application et si vous voulez un raccourci sur le Bureau, puis
ORION démarre.

Aucun droit administrateur n'est demandé : le programme s'installe dans
`%LOCALAPPDATA%\Programs\ORION`, ses données dans `%LOCALAPPDATA%\ORION`
(configuration, bibliothèque, cache de jaquettes, sauvegardes, journaux).
Rien ailleurs, ni service, ni démarrage automatique.

ORION apparaît ensuite dans **Applications installées** de Windows, avec sa
désinstallation. Celle-ci propose de garder votre bibliothèque et vos
réglages, et ne touche jamais à vos jeux.

### À partir du code source

Pour travailler sur ORION plutôt que l'utiliser :

1. Double-cliquer sur **`Installer.bat`** (crée un environnement Python isolé
   dans `.venv` et installe les dépendances).
2. Lancer **`ORION.bat`**, ou `ORION-console.bat` pour voir les erreurs.
3. **`CONSTRUIRE-EXE.bat`** recompile l'exécutable et son installateur dans
   `dist\`.
4. `Installateur-ORION.exe --silencieux` installe sans poser de question,
   avec les valeurs par défaut : utile pour appliquer une mise à jour sans
   rouvrir la fenêtre.

---

## Ce que fait ORION

### Détection des jeux
Dix sources sont explorées à chaque analyse :

| Source | Méthode |
|---|---|
| Steam | `libraryfolders.vdf` + manifestes `.acf` de **toutes** les bibliothèques |
| Epic Games | manifestes `.item` de `ProgramData\Epic` |
| GOG | clés de registre `GOG.com\Games` |
| Ubisoft Connect | `Ubisoft\Launcher\Installs` |
| EA / Origin | clés `EA Games` et `Origin Games` |
| Battle.net | entrées Blizzard de la liste des programmes |
| Ankama | dossiers `%LOCALAPPDATA%\Ankama\<Jeu>` de l'Ankama Launcher (Dofus, Wakfu…), lancés par le lanceur |
| Xbox / Microsoft Store | paquets AppX de jeu et dossiers `XboxGames` |
| Dossiers libres | vos dossiers de jeux (installations manuelles, portables) |
| Programmes installés | rattrapage prudent via la base de registre |

Les doublons entre sources sont fusionnés par chemin d'installation, la source
la plus fiable l'emportant.

### Visuels
Jaquette verticale, bannière et logo officiels via le CDN Steam — y compris
pour les jeux **hors Steam**, dont l'identifiant est retrouvé à partir du
titre. Sans réseau ou pour un jeu inconnu, l'icône de l'exécutable est extraite
et une tuile colorée est générée : aucune case ne reste vide.
Une clé SteamGridDB (gratuite, facultative) améliore encore la couverture.

### Analyse de la machine
Processeur, mémoire, stockage, carte graphique (nom, VRAM, pilote) et
**capacités réelles** : DLSS, génération d'images, ray tracing, Reflex, FSR,
XeSS. Tous les écrans sont énumérés avec la totalité de leurs modes
(définition + fréquence).

### Ce que votre PC peut faire
Page **Ma machine** : la note de la machine, puis une seule liste claire — vos
jeux et des jeux à acheter — avec pour chacun le **niveau fluide** (le plus
beau réglage qui tient environ 60 images par seconde à la définition de votre
écran : Ultra, Haute, Moyenne, Basse ou Trop juste), les images par seconde
attendues, la source du résultat et où l'avoir. Filtres **Tous / Mes jeux /
À acheter**, recherche et tri (niveau, nom, images par seconde, prix).

Chaque résultat dit d'où il vient : **mesure** sur votre PC (la seule qui
peut classer un jeu en Ultra), **communauté** (au moins trois joueurs ORION
avec une carte proche) ou **estimation prudente** tirée de la configuration
recommandée du jeu.

### Les graphismes d'un jeu : deux cartes

| Carte | Ce qu'elle fait |
|---|---|
| **Votre écran** | Votre écran affiche 60, 144, 165 ou 240 images par seconde : ORION lit vos composants et cherche, du plus beau au plus léger (Ultra, Haute, Moyenne, Basse, avec DLSS, FSR ou XeSS quand ça aide), le premier réglage qui tient cet objectif de façon stable ; si même Basse ne le tient pas, il descend par paliers. Après une partie mesurée, il repart des images par seconde réellement vues. |
| **Mon choix** | Vous choisissez les graphismes (Ultra par défaut) et les images par seconde ; ORION montre ce que ça donne sur votre PC, écrit ce niveau et bride le jeu sur les images demandées. |

Une case **DLSS** (ou FSR, XeSS) apparaît quand le jeu et la carte le
permettent : cochée, toujours active ; décochée, jamais ; sans y toucher,
seulement s'il en faut pour tenir l'objectif. Le choix vaut pour ce jeu, et
« Jouer » refait le même calcul que la carte.

### Application des réglages
ORION règle l'écran choisi (définition + fréquence, via l'API Windows) et écrit
les options dans le jeu quand il sait le faire :

- **Unreal Engine** — `GameUserSettings.ini` (projet détecté automatiquement)
- **Unity** — clés de registre du jeu (noms calculés, comme le jeu les lit)
- **Source / idTech** — bloc isolé dans `autoexec.cfg`
- **Formats lus et écrits sur place** — INI, JSON, XML, KeyValues de Valve,
  texte « clé valeur », registre ; recettes pour GTA V, Red Dead Redemption 2,
  Far Cry, Battlefield et les jeux EA, Skyrim, Fallout, Starfield, Elden Ring,
  Baldur's Gate 3, The Witcher 3, Apex Legends, Minecraft, Cyberpunk 2077,
  Aniimo…
- **Jeu inconnu** — ORION cherche son fichier de réglages et n'y touche qu'aux
  clés sûres (définition, plein écran, synchronisation, limite d'images) ; les
  niveaux restent au guide

**Règles de sécurité, sans exception :**
- jamais une clé inventée, jamais une valeur d'une autre forme que celle en
  place : seules les clés présentes dans le fichier du jeu sont écrites ;
- **jamais pendant une partie** : un programme du jeu ou son lanceur ouvert,
  rien n'est écrit (la fiche le dit), et rien n'est jamais injecté dans un jeu
  ni dans sa mémoire ;
- une sauvegarde horodatée (fichiers copiés, clés de registre exportées) est
  créée avant modification ; la première, celle de l'état d'origine, n'est
  jamais écrasée ;
- chaque réglage écrit est relu : la fiche affiche un état honnête, par
  exemple *« Réglages appliqués : 12 sur 14 »* ;
- un fichier en lecture seule n'est jamais forcé : ORION le signale et écrit
  les autres ;
- **Redéfinir les paramètres par défaut** remet le jeu dans l'état d'avant la
  première intervention d'ORION ;
- la fréquence d'écran est appliquée de façon **non permanente** : un
  redémarrage suffit à tout remettre en place, et ORION la restaure déjà tout
  seul à la fermeture du jeu.

### Autonomie
ORION ne dépend d'aucun service payant ni d'aucun compte. Tout ce qui suit
fonctionne dès le premier lancement, sans rien configurer :

- détection des jeux sur les neuf sources, y compris les installations
  manuelles ;
- jaquettes officielles, retrouvées par le titre — la recherche passe par la
  boutique Steam, qui référence un jeu **le jour de sa sortie** ; si une fiche
  n'existe pas encore, ORION réessaie aux lancements suivants ;
- prix et avis Steam, prix GOG, actualités et notes de mise à jour ;
- analyse matérielle, gestion des écrans, optimisation, sauvegardes.

Une **veille automatique** vérifie toutes les dix minutes (réglable) si un jeu
vient d'être installé : il apparaît avec sa jaquette sans rien demander.

### La fiche d'un jeu
Tout sur un jeu de votre bibliothèque, au même endroit :

- **Infos** : studio, éditeur, date de sortie, genres, avis des joueurs Steam,
  note Metacritic et vos succès (obtenus, pourcentage, succès rares) ;
- **Succès** compacts : les prochains à viser, la liste complète en un clic ;
- **Captures d'écran** avec visionneuse ;
- **Vidéos** dans un lecteur intégré : gameplay en français (la vidéo choisie
  est retenue pour le jeu), lives YouTube (Twitch s'ouvre dans le
  navigateur) et bandes-annonces officielles Steam ;
- **Joueurs en ligne** pour les jeux en ligne vendus sur Steam.

Le jeu étant déjà à vous, la fiche n'affiche plus de prix ni de revendeurs du
marché gris ; le bouton **Boutique** ouvre toujours sa page sur sa
plateforme.

Le temps de jeu réel est lu dans les données Steam et s'ajoute à celui compté
par ORION ; la bibliothèque se trie par **temps de jeu** en un clic.

### Valeur de la bibliothèque
En haut de la bibliothèque, un bouton donne le prix actuel de vos jeux. Un
clic ouvre la liste des jeux comptés, du plus cher au moins cher, avec la
boutique d'où vient chaque prix, les jeux gratuits et ceux sans prix connu. À
côté, votre **carte de joueur** : un pseudo et une photo de profil si vous le
voulez (gardés sur votre PC, écrits seulement sur l'image), le total et vos
trois jeux les plus chers, enregistrée en PNG 1200 × 630. À titre
d'information seulement : ce n'est ni ce que vous avez payé, ni une valeur de
revente.

### Boutique
Une vitrine qui se lit de haut en bas :

- **À la une** : les gros jeux du moment, en grand ;
- **Pour vous** : des suggestions tirées de votre bibliothèque (genres,
  studios, séries, temps de jeu), calculées sur votre PC, sans compte — jamais
  un jeu que vous possédez déjà ;
- **Grosses promos**, **Au plus bas historique**, **Gratuits en ce moment** ;
- **Rechercher un jeu** : tout le catalogue, avec images, fautes et sigles
  acceptés (*gta*, *bg3*, *cyberpounk*).

Le prix retenu est toujours le plus bas parmi les boutiques **sûres**
(officielles et revendeurs agréés). Les places de marché de clés ne sont
jamais retenues comme meilleur prix. Les données **IsThereAnyDeal** arrivent par
le service d'ORION, sans clé (une clé personnelle reste possible dans les
Réglages) : plus de trente boutiques agréées, plus bas historique compris. Logiciels, formations et bandes originales sont toujours
écartés.

Trois revendeurs de clés de longue date (Instant Gaming, Kinguin, Loaded) sont
montrés à part, après les boutiques officielles, avec une règle visible : une
clé Steam du jeu lui-même, région Global ou celle de votre pays (Europe en
France), jamais un « Gift » ni un compte. G2A, Gamivo, Eneba et les autres
places de marché sont écartées.

Certaines boutiques utilisent des **liens partenaires** : votre prix ne change
pas, une petite commission finance ORION. Désactivable dans les Réglages.

### Assistant IA (facultatif)
ORION fonctionne entièrement sans IA. En collant une clé dans les Réglages
(Claude, ChatGPT, Gemini, Mistral, ou **Ollama en local sans clé ni
connexion**), quatre actions s'ajoutent sur chaque fiche :

| Action | Ce qu'elle apporte |
|---|---|
| **Apprendre ce jeu à ORION** | L'IA lit les fichiers de configuration réellement présents et **écrit la recette JSON** : le jeu passe de « non reconnu » à réglable automatiquement, pour toujours. C'est l'apport le plus concret. |
| **Conseils pour ce jeu** | Les options du menu qui pèsent vraiment, pour votre carte et votre écran. |
| **Pourquoi ça rame ?** | Diagnostic à partir du symptôme décrit et du matériel réel. |
| **Faut-il l'acheter ?** | Lecture des prix relevés : attendre ou acheter, et à quel prix. |

Chaque fournisseur a son tutoriel pas à pas intégré (où créer la clé, quoi
copier, combien ça coûte). Ce qui est envoyé est indiqué noir sur blanc dans
les Réglages ; avec Ollama, rien ne quitte le PC.

### Actualités et notes de patch
Les quatre dernières actualités du jeu (mises à jour, correctifs, saisons)
sont affichées sur la fiche, nettoyées et datées, avec le lien vers la note
complète. Source : le flux officiel Steam, sans clé.

### Performances réellement mesurées
Activée dans les Réglages, la mesure enregistre les images par seconde
pendant la partie (via PresentMon, l'outil d'Intel qu'ORION télécharge tout
seul) : moyenne, 1 % bas, 0,1 % bas et durée mesurée, sans compter les écrans
de chargement ni les menus. Windows doit autoriser la lecture des images
affichées (groupe « Utilisateurs du journal de performances ») : les Réglages
le disent quand il refuse, et le tuto donne la marche à suivre.

Chaque jeu mesuré sur votre PC corrige les estimations de tous les autres, et
la carte « Votre écran » repart des images par seconde réellement vues.

### Envies et veille de prix
Une page dédiée suit les jeux que vous n'avez pas encore. Import de la liste
de souhaits Steam en un clic (ORION retrouve le compte connecté sur la
machine), ou ajout par recherche. Pour chaque jeu : prix actuel, meilleure
offre, plus bas historique, avis, et un **seuil d'alerte** personnalisable.
ORION vérifie toutes les six heures et prévient par notification Windows.

### Sorties à venir
La page **Sorties** montre les plus grosses sorties annoncées sur PC,
PlayStation, Xbox et Switch : la plus attendue en grande affiche avec un
compte à rebours (jours, heures, minutes, secondes), les autres en cartes
filtrables par plateforme. Seules les dates officielles des éditeurs donnent
un compte à rebours ; un jeu annoncé sans date affiche sa période. La page se
renouvelle seule : un jeu sorti laisse sa place, trois jours après, au suivant
parmi les jeux à venir les plus suivis sur Steam (classement par listes de
souhaits). Les sorties consoles viennent d'une liste tenue à jour en ligne
(`sorties.json` sur le site).

### Joueurs en ligne
La fiche d'un jeu en ligne vendu sur Steam indique combien de joueurs y sont
connectés en ce moment (chiffre publié par Steam, actualisé toutes les
5 minutes). Seuls les joueurs Steam sont comptés.

### Jeux gratuits
L'onglet **Gratuits en ce moment** de la Boutique cherche en ligne, en temps réel, ce qui est offert en ce moment :
cadeaux des boutiques, week-ends gratuits, jeux gratuits pour toujours.
Sources interrogées à chaque passage : l'Epic Games Store, un agrégateur
public de cadeaux et de week-ends gratuits, les mises en avant Steam et le
catalogue GOG — toutes publiques, aucune clé.

Pour chaque jeu, ORION affiche le compte à rebours, le prix habituel, la
note des joueurs, et va chercher sur la fiche Steam ce qui décide vraiment :
**solo, multijoueur, coopération (en ligne ou en écran partagé), joueur
contre joueur, jeu en ligne, multijoueur multiplateforme**, ainsi que les
systèmes supportés (Windows, macOS, Linux). Un bouton ouvre directement la
page de récupération.

La distinction centrale est la **nature de la gratuité** :

| Nature | Ce que ça veut dire | Ce que fait ORION |
|---|---|---|
| Gratuit pour toujours | free-to-play ou définitivement offert | rien n'expire |
| À récupérer, gardé à vie | offre limitée, mais le jeu reste acquis | seule la fenêtre de récupération est décomptée |
| Gratuit temporairement | week-end gratuit, essai | à l'échéance, ORION prévient, propose de désinstaller, puis ouvre la page d'achat |

C'est le dernier cas qui justifie la page : un week-end gratuit laisse
souvent des dizaines de gigaoctets sur le disque pour un jeu devenu
injouable. ORION le repère, archive la sauvegarde, ouvre le désinstalleur de
la plateforme, et propose la page d'achat à ceux qui veulent continuer. Les
jeux gardés à vie ne sont jamais concernés.

### Sauvegardes de parties
ORION repère les dossiers de sauvegarde (Documents, %LOCALAPPDATA%,
%APPDATA%, Saved Games, Steam Cloud local, dossier du jeu), les archive en
zip horodaté — lisible sans ORION — et sait les restaurer. Archivage
automatique à la fin d'une partie, et avant toute désinstallation.

### Stockage
Une page croise taille, dernière partie et temps de jeu pour montrer ce qui
dort : *« 245 Go récupérables »*. Le bouton **Recalculer** remesure la taille
réelle de chaque jeu et la place libre de chaque disque. ORION ne supprime
jamais rien lui-même : il propose d'archiver la sauvegarde, puis ouvre le
désinstalleur de la plateforme concernée.

**Sauvegarder sur un autre disque** : ORION copie le jeu dans « Sauvegardes
ORION » sur le disque choisi (externe compris), avec la progression en
pourcentage, puis vérifie la copie fichier par fichier. Le jeu installé n'est
**jamais modifié** : Steam, Epic et les autres launchers continuent de
l'utiliser. Chaque sauvegarde peut être restaurée (copie vérifiée elle
aussi) ou supprimée. Les jeux déplacés avec l'ancienne fonction de la 1.8
peuvent être ramenés sur leur disque d'origine.

### Manette et affichage salon
Navigation complète au pad (XInput, aucune installation) : croix
directionnelle pour se déplacer, **A** pour ouvrir, **X** pour lancer, **B**
pour revenir, **Start** pour l'affichage salon — plein écran, grandes
jaquettes, interface épurée. Également accessible avec **F11**.

### Recettes partagées
ORION télécharge chaque jour les recettes publiées par les autres
utilisateurs : un jeu appris par quelqu'un devient réglable pour tout le
monde. Le bouton **Partager cette recette** prépare les fichiers à déposer
sur le dépôt. Vos recettes personnelles ne sont jamais envoyées sans action
de votre part, et priment toujours sur celles de la communauté.

### Comptes
Steam (connexion officielle), GOG et Xbox (connexions non officielles,
signalées comme telles) se connectent dans une fenêtre intégrée : ORION ne
voit jamais votre mot de passe. Les jeux, succès et temps de jeu des comptes
rejoignent la bibliothèque. Si Microsoft propose une clé de sécurité,
choisissez le mot de passe ou un code ; si Google refuse la fenêtre intégrée
de GOG, ORION l'explique et indique la marche à suivre.

### Conseils
Quatre rubriques, chacune avec la marche à suivre et les valeurs lues sur
votre PC :

- **Pilotes** : inventaire complet (graphique, chipset, réseau, audio,
  stockage, USB, Bluetooth) — périphériques sans pilote, pilotes génériques
  de Microsoft, pilotes anciens, avec le lien vers la bonne page ;
- **Windows** : mode Jeu, planification GPU accélérée, enregistrement en
  arrière-plan, plan d'alimentation, redémarrage en attente, fichier
  d'échange ;
- **Matériel** : fréquence et définition des écrans, mémoire hors profil
  XMP/EXPO, mémoire en simple canal, mémoire juste, disque presque plein,
  Windows sur disque dur ;
- **Jeux** : jeux installés sur un disque dur, mises à jour en attente.

ORION ne modifie rien lui-même dans Windows : chaque remarque explique
*pourquoi* elle est là et ouvre, si besoin, la bonne page.

---

## Utilisation

- **Bibliothèque** : rechercher, trier, filtrer par plateforme, voir ce que
  vaut la bibliothèque. Double-cliquer sur une tuile lance le jeu avec le
  choix fait pour lui.
- **Fiche d'un jeu** : infos, succès, captures et vidéos ; choisir l'écran et
  une des deux cartes (« Votre écran » ou « Mon choix »), lire les réglages
  calculés, puis **Jouer** : le choix s'écrit, après sauvegarde, et le jeu
  se lance.
- **Boutique** : vitrine, suggestions, promos, recherche et jeux gratuits.
- **Sorties** : les grosses sorties à venir, toutes plateformes.
- **Ma machine** : composants, écrans, changement de mode immédiat et ce que
  votre PC peut faire.
- **Stockage** : place occupée, jeux qui dorment, sauvegardes sur un autre
  disque.
- **Conseils** : pilotes, réglages Windows et matériel.
- **Réglages** : comportement, dossiers de jeux supplémentaires, jaquettes,
  taille des tuiles, accès aux dossiers d'extensions et de sauvegardes.

---

## Étendre ORION

Tout est modulaire. `ARCHITECTURE.md` détaille les points d'extension ; en deux
lignes :

- **Ajouter une plateforme** → un fichier Python dans
  `%LOCALAPPDATA%\ORION\plugins\scanners\`
- **Apprendre à régler un jeu précis** → un fichier JSON dans
  `%LOCALAPPDATA%\ORION\recipes\`
- **Ajouter une source de jeux gratuits** → un fichier Python dans
  `%LOCALAPPDATA%\ORION\plugins\freebies\`

Aucun fichier livré n'a besoin d'être modifié, et le bouton *Recharger les
extensions et recettes* les prend en compte sans redémarrer.


---

## Comment ORION est fait

**Entièrement développé en *vibe coding*** : pas une ligne tapée à la main.
L'application est née d'une conversation en français avec **Claude**
(Anthropic, modèle Opus 5), qui a conçu l'architecture, écrit les plus de
65 000 lignes de code, testé et corrigé directement sur la machine cible.

| Domaine | Technologie |
|---|---|
| Langage | Python 3.13 |
| Interface | PySide6 / Qt 6, thème sombre entièrement personnalisé |
| API Windows | ctypes : `user32` (écrans et changement de mode), `kernel32` (mémoire), XInput (manette), `winreg` (registre) |
| Réseau et processus | requests, psutil |
| Données de jeux | API publiques Steam (fiche, avis, actualités, recherche) et catalogue GOG ; IsThereAnyDeal par le service d'ORION ; SteamGridDB en option |
| Mesure des performances | PresentMon (Intel), téléchargé automatiquement |
| IA facultative | Claude, ChatGPT, Gemini, Mistral, Ollama (local) |

Aucune dépendance lourde, aucun service tiers installé, aucun compte requis.

---

## Soutenir le projet

ORION est gratuit, sans publicité et sans compte, et rien n'est envoyé sans votre accord. Le bouton
**Soutenir ORION** en bas de la barre latérale ouvre le lien de don officiel,
affiché dans *Réglages → Soutien au projet* et qu'aucun joueur ne peut
remplacer. Il peut être masqué en un clic.
