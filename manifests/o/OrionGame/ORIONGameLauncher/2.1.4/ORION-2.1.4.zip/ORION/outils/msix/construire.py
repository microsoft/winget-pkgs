"""Fabrique le paquet MSIX d'ORION pour le Microsoft Store.

A lancer apres la compilation normale (dist\\ORION doit exister). Le paquet
n'est pas signe : c'est le Store qui le signe a la reception, et c'est ce qui
supprime l'avertissement de Windows a l'installation.

    python outils\\msix\\construire.py

Besoins : `identite.json` rempli avec les trois valeurs de Partner Center, et
`makeappx.exe` (kit de developpement Windows). S'il manque, ce script le
recupere dans le paquet officiel Microsoft.Windows.SDK.BuildTools de
nuget.org, sans rien installer sur le systeme.
"""
from __future__ import annotations

import io
import json
import shutil
import subprocess
import sys
import urllib.request
import zipfile
from pathlib import Path
from xml.sax.saxutils import escape

ICI = Path(__file__).resolve().parent
RACINE = ICI.parents[1]
sys.path.insert(0, str(RACINE))

DIST = RACINE / "dist" / "ORION"
TRAVAIL = RACINE / "build" / "msix"
SORTIE = RACINE / "dist" / "ORION-Store.msix"
NUGET = "https://www.nuget.org/api/v2/package/Microsoft.Windows.SDK.BuildTools"
LOGOS = {"StoreLogo.png": (50, 50), "Square44x44Logo.png": (44, 44),
         "Square44x44Logo.targetsize-256_altform-unplated.png": (256, 256),
         "Square150x150Logo.png": (150, 150), "Square310x310Logo.png": (310, 310),
         "Wide310x150Logo.png": (310, 150)}

MANIFESTE = """<?xml version="1.0" encoding="utf-8"?>
<Package xmlns="http://schemas.microsoft.com/appx/manifest/foundation/windows10"
  xmlns:uap="http://schemas.microsoft.com/appx/manifest/uap/windows10"
  xmlns:rescap="http://schemas.microsoft.com/appx/manifest/foundation/windows10/restrictedcapabilities"
  xmlns:desktop="http://schemas.microsoft.com/appx/manifest/desktop/windows10"
  IgnorableNamespaces="uap rescap desktop">
  <Identity Name="{nom_paquet}" Publisher="{editeur}" Version="{version}"
    ProcessorArchitecture="x64" />
  <Properties>
    <DisplayName>ORION Game Launcher</DisplayName>
    <PublisherDisplayName>{nom_editeur}</PublisherDisplayName>
    <Logo>Assets\\StoreLogo.png</Logo>
  </Properties>
  <Dependencies>
    <TargetDeviceFamily Name="Windows.Desktop" MinVersion="10.0.17763.0"
      MaxVersionTested="10.0.26100.0" />
  </Dependencies>
  <Resources>
    <Resource Language="fr-FR" />
    <Resource Language="en-US" />
  </Resources>
  <Applications>
    <Application Id="ORION" Executable="ORION.exe"
      EntryPoint="Windows.FullTrustApplication">
      <uap:VisualElements DisplayName="ORION Game Launcher"
        Description="Tous vos jeux PC au meme endroit."
        BackgroundColor="transparent"
        Square150x150Logo="Assets\\Square150x150Logo.png"
        Square44x44Logo="Assets\\Square44x44Logo.png">
        <uap:DefaultTile Wide310x150Logo="Assets\\Wide310x150Logo.png"
          Square310x310Logo="Assets\\Square310x310Logo.png" />
      </uap:VisualElements>
      <Extensions>
        <desktop:Extension Category="windows.startupTask" Executable="ORION.exe"
          EntryPoint="Windows.FullTrustApplication">
          <desktop:StartupTask TaskId="{tache_demarrage}" Enabled="true"
            DisplayName="ORION Game Launcher" />
        </desktop:Extension>
      </Extensions>
    </Application>
  </Applications>
  <Capabilities>
    <Capability Name="internetClient" />
    <rescap:Capability Name="runFullTrust" />
  </Capabilities>
</Package>
"""


def arret(message: str) -> None:
    print("\n  ECHEC : " + message)
    sys.exit(1)


def identite() -> dict:
    d = json.loads((ICI / "identite.json").read_text(encoding="utf-8"))
    for cle in ("nom_paquet", "editeur", "nom_editeur"):
        if "A_REMPLIR" in str(d.get(cle, "A_REMPLIR")):
            arret(f"outils\\msix\\identite.json : « {cle} » n'est pas rempli.")
    return d


def version_store() -> str:
    """Le Store exige quatre nombres, le dernier a zero."""
    from orion.maj import version_tuple
    from orion.version import APP_VERSION
    a, b, c = version_tuple(APP_VERSION)[:3]
    return f"{a}.{b}.{c}.0"


def manifeste(d: dict) -> str:
    # tache de demarrage (2.1.2) : allumee par defaut (Windows l'active des
    # que l'application a ete ouverte une fois) ; la case « Lancer ORION au
    # demarrage de Windows » la coupe ou la rallume (une application du Store
    # ne peut pas s'inscrire dans la cle « Run »)
    from orion.demarrage import TACHE
    return MANIFESTE.format(version=version_store(), tache_demarrage=TACHE,
                            **{k: escape(str(v), {'"': "&quot;"}) for k, v in d.items()
                               if not k.startswith("_")})


def logos(dossier: Path) -> None:
    """Les vignettes demandees par Windows, a partir du logo d'ORION."""
    from PySide6.QtCore import Qt
    from PySide6.QtGui import QImage, QPainter
    source = QImage(str(RACINE / "orion" / "ui" / "assets" / "orion.png"))
    dossier.mkdir(parents=True, exist_ok=True)
    for nom, (l, h) in LOGOS.items():
        image = QImage(l, h, QImage.Format.Format_ARGB32)
        image.fill(Qt.GlobalColor.transparent)
        cote = int(min(l, h) * (1.0 if "targetsize" in nom or l <= 50 else 0.66))
        logo = source.scaled(cote, cote, Qt.AspectRatioMode.KeepAspectRatio,
                             Qt.TransformationMode.SmoothTransformation)
        p = QPainter(image)
        p.drawImage((l - logo.width()) // 2, (h - logo.height()) // 2, logo)
        p.end()
        image.save(str(dossier / nom))


def makeappx() -> Path:
    kits = Path(r"C:\Program Files (x86)\Windows Kits\10\bin")
    trouves = sorted(kits.glob("10.*/x64/makeappx.exe")) if kits.is_dir() else []
    local = sorted((ICI / "sdk").glob("**/x64/makeappx.exe"))
    if trouves or local:
        return (trouves or local)[-1]
    print("  Recuperation de makeappx (paquet officiel Microsoft, nuget.org)...")
    with urllib.request.urlopen(NUGET, timeout=120) as r:
        archive = zipfile.ZipFile(io.BytesIO(r.read()))
    for nom in archive.namelist():
        if "/x64/" in nom and nom.lower().endswith(("makeappx.exe", ".dll", ".manifest")):
            archive.extract(nom, ICI / "sdk")
    local = sorted((ICI / "sdk").glob("**/x64/makeappx.exe"))
    if not local:
        arret("makeappx.exe introuvable dans le paquet telecharge.")
    return local[-1]


def main() -> None:
    if not (DIST / "ORION.exe").is_file():
        arret("dist\\ORION\\ORION.exe absent : lancez d'abord la compilation.")
    d = identite()
    if TRAVAIL.exists():
        shutil.rmtree(TRAVAIL)
    print("  Copie du programme...")
    shutil.copytree(DIST, TRAVAIL)
    from orion.maj import MARQUE_STORE
    (TRAVAIL / MARQUE_STORE).write_text("Microsoft Store\n", encoding="utf-8")
    (TRAVAIL / "AppxManifest.xml").write_text(manifeste(d), encoding="utf-8")
    logos(TRAVAIL / "Assets")
    outil = makeappx()
    print("  Fabrication du paquet...")
    if SORTIE.exists():
        SORTIE.unlink()
    r = subprocess.run([str(outil), "pack", "/o", "/d", str(TRAVAIL), "/p", str(SORTIE)],
                       capture_output=True, text=True)
    if r.returncode or not SORTIE.is_file():
        arret("makeappx a refuse le paquet :\n" + (r.stdout or "") + (r.stderr or ""))
    print(f"\n  OK : {SORTIE}  ({SORTIE.stat().st_size // 1_000_000} Mo)")
    print("  A deposer dans Partner Center > Packages.")


if __name__ == "__main__":
    main()
