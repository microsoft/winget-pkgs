"""Avant de compiler : ecarte les fichiers qui ne sont plus dans les sources.

La compilation embarque TOUT ce qui se trouve sous `orion/` (modules avec
`--collect-submodules`, recettes, langues et images avec `--add-data`), et la
mise a jour des sources recopie `ORION.zip` par-dessus le dossier sans rien
retirer. Un module supprime des sources resterait donc sur le disque, serait
compile, et un plugin serait meme recharge au demarrage d'ORION.

Reference : l'archive des sources de LA MEME VERSION que le dossier
(`../ORION-<version>*.zip`, sinon `../ORION.zip`), verifiee par son
`orion/version.py`. Les fichiers en trop sont DEPLACES, jamais supprimes,
dans `../_a_supprimer/orion-<date>/`. Sans archive, si elle ne ressemble pas
aux sources ou si elle n'est pas de la meme version (constat du 8 octobre
2026 : ORION.zip 2.0.1 face a un dossier 2.0.2, les sept modules nouveaux
ecartes), rien n'est touche.

10 octobre 2026 : ORION.zip (dont tout est range sous « ORION/ ») extrait
DANS le dossier ORION ; Windows ne distinguant pas « ORION » de « orion »,
toute l'archive est tombee dans le paquet `orion/` (orion/CHANGELOG.md,
orion/orion/aide.py...), les vrais modules sont restes ceux de la veille et
l'installateur a ete compile avec eux. Le controle disait « 457 fichiers en
trop, rien n'est deplace » dans le journal, et la compilation continuait.
Desormais : la copie imbriquee est deplacee, et si les sources du dossier
different encore de l'archive de meme version, la compilation s'arrete
(code 3) et dit de lancer `COMPILER-SEUL.bat`, a cote de ORION.zip, qui
met l'archive au bon endroit puis compile.

Usage : python outils/sources_propres.py        (lance par CONSTRUIRE-EXE.bat)
"""
from __future__ import annotations

import re
import shutil
import sys
import time
import zipfile
from pathlib import Path

_VERSION = re.compile(r'^APP_VERSION\s*=\s*"([^"]+)"', re.M)

#: en dessous, l'archive n'est pas celle des sources : on ne touche a rien
MODULES_ATTENDUS = 100
#: au-dessus, l'archive et le dossier ne vont pas ensemble : on ne touche a rien
TROP = 40


def version_du_dossier(dossier: Path) -> str:
    try:
        m = _VERSION.search((dossier / "orion" / "version.py").read_text(encoding="utf-8"))
    except OSError:
        return ""
    return m.group(1) if m else ""


def version_de_l_archive(archive: Path) -> str:
    try:
        with zipfile.ZipFile(archive) as z:
            m = _VERSION.search(z.read("ORION/orion/version.py").decode("utf-8"))
    except (OSError, zipfile.BadZipFile, KeyError, UnicodeDecodeError):
        return ""
    return m.group(1) if m else ""


def archive_de(dossier: Path) -> Path | None:
    """L'archive des sources de la version du dossier, a cote du dossier :
    `ORION-<version>*.zip` d'abord, puis `ORION.zip` si elle est de la meme
    version. None sinon (et on ne touche a rien)."""
    version = version_du_dossier(dossier)
    if not version:
        return None
    candidates = sorted(dossier.parent.glob(f"ORION-{version}*.zip")) + [dossier.parent / "ORION.zip"]
    for c in candidates:
        if c.is_file() and version_de_l_archive(c) == version:
            return c
    return None


def en_trop(dossier: Path, archive: Path) -> list[Path] | None:
    """Fichiers de `dossier/orion` absents de l'archive (chemins relatifs a
    `dossier`). None si l'archive manque, n'est pas celle des sources ou
    n'est pas de la version du dossier."""
    if not archive.is_file():
        return None
    try:
        with zipfile.ZipFile(archive) as z:
            livres = {n[len("ORION/"):] for n in z.namelist()
                      if n.startswith("ORION/orion/") and not n.endswith("/")}
    except (OSError, zipfile.BadZipFile):
        return None
    if sum(1 for n in livres if n.endswith(".py")) < MODULES_ATTENDUS:
        return None
    if version_du_dossier(dossier) != version_de_l_archive(archive):
        return None
    presents = [p for p in (dossier / "orion").rglob("*")
                if p.is_file() and "__pycache__" not in p.parts]
    return sorted(p.relative_to(dossier) for p in presents
                  if p.relative_to(dossier).as_posix() not in livres)


def ecarter(dossier: Path, archive: Path, maintenant: float | None = None) -> list[Path]:
    """Deplace les fichiers en trop ; rend leurs chemins d'origine."""
    trop = en_trop(dossier, archive)
    if trop is None:
        va, vd = version_de_l_archive(archive), version_du_dossier(dossier)
        if va and vd and va != vd:
            print(f"Sources : {archive.name} est la {va}, le dossier est en {vd} : rien n'est verifie.")
        else:
            print("Sources : pas d'archive de reference, rien n'est verifie.")
        return []
    if not trop:
        print("Sources : aucun fichier d'une ancienne version.")
        return []
    if len(trop) > TROP:
        print(f"Sources : {len(trop)} fichiers absents de l'archive, c'est trop pour etre "
              "un reste : rien n'est deplace. Verifiez que ORION.zip est le bon.")
        return []
    date = time.strftime("%Y-%m-%d-%H%M%S", time.localtime(maintenant))
    cible = archive.parent / "_a_supprimer" / f"orion-{date}"
    for relatif in trop:
        destination = cible / relatif
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(dossier / relatif), str(destination))
        print(f"Sources : {relatif.as_posix()} n'est plus dans les sources, "
              f"deplace dans {cible}")
    return trop


#: code de sortie quand le dossier n'a pas les sources de l'archive
PAS_A_JOUR = 3


def _racines(archive: Path) -> set[str]:
    """Noms de premier niveau de l'archive (« CHANGELOG.md », « orion »,
    « tests »...), sous « ORION/ »."""
    with zipfile.ZipFile(archive) as z:
        return {n.split("/")[1] for n in z.namelist()
                if n.startswith("ORION/") and n.count("/") >= 1 and n.split("/")[1]}


def copie_imbriquee(dossier: Path, archive: Path) -> list[Path]:
    """Ce qu'une extraction de l'archive DANS le dossier a pose dans le paquet
    `orion/` : les noms de premier niveau de l'archive (le paquet n'en a
    aucun : pas de `orion/orion`, `orion/tests`, `orion/CHANGELOG.md`...)."""
    try:
        racines = _racines(archive)
    except (OSError, zipfile.BadZipFile):
        return []
    paquet = dossier / "orion"
    if not (paquet / "version.py").is_file() or "orion" not in racines:
        return []
    return sorted(paquet / nom for nom in racines if (paquet / nom).exists())


def ecarter_copie(dossier: Path, archive: Path, maintenant: float | None = None) -> list[Path]:
    """Deplace la copie imbriquee dans `_a_supprimer` ; rend ce qui a bouge."""
    trouve = copie_imbriquee(dossier, archive)
    if not trouve:
        return []
    date = time.strftime("%Y-%m-%d-%H%M%S", time.localtime(maintenant))
    cible = archive.parent / "_a_supprimer" / f"copie-imbriquee-{date}"
    cible.mkdir(parents=True, exist_ok=True)
    for p in trouve:
        shutil.move(str(p), str(cible / p.name))
    print(f"Sources : ORION.zip avait ete extrait DANS le dossier ({len(trouve)} element(s) "
          f"ranges dans orion\\), deplace dans {cible}")
    return trouve


def differents(dossier: Path, archive: Path) -> list[str]:
    """Fichiers de l'archive absents du dossier ou d'un autre contenu
    (fins de ligne ignorees). Le script de compilation en cours n'est pas
    compte : il ne peut pas etre remplace pendant qu'il tourne."""
    ecarts = []
    with zipfile.ZipFile(archive) as z:
        for n in z.namelist():
            if not n.startswith("ORION/") or n.endswith("/"):
                continue
            rel = n[len("ORION/"):]
            if rel == "CONSTRUIRE-EXE.bat":
                continue
            f = dossier / rel
            try:
                ici = f.read_bytes()
            except OSError:
                ecarts.append(rel)
                continue
            if ici.replace(b"\r\n", b"\n") != z.read(n).replace(b"\r\n", b"\n"):
                ecarts.append(rel)
    return ecarts


def _numero(version: str) -> tuple[int, ...]:
    return tuple(int(x) for x in re.findall(r"\d+", version or ""))


def a_jour(dossier: Path, reference: Path) -> str:
    """« » si le dossier a les sources de ORION.zip ; sinon la raison. Un
    dossier plus recent que l'archive (version superieure) n'est pas bloque."""
    va, vd = version_de_l_archive(reference), version_du_dossier(dossier)
    if not va or not vd:
        return ""
    if _numero(va) > _numero(vd):
        return f"{reference.name} est la {va}, le dossier est encore en {vd}"
    if va == vd:
        ecarts = differents(dossier, reference)
        if ecarts:
            return (f"{len(ecarts)} fichier(s) du dossier ne sont pas ceux de {reference.name} "
                    f"(par exemple {ecarts[0]})")
    return ""


def main() -> int:
    dossier = Path(__file__).resolve().parent.parent
    try:
        reference = dossier.parent / "ORION.zip"
        if reference.is_file():
            ecarter_copie(dossier, reference)
            raison = a_jour(dossier, reference)
            if raison:
                print(f"Sources : {raison}. Compilation arretee : lancez COMPILER-SEUL.bat, "
                      "a cote de ORION.zip.")
                return PAS_A_JOUR
        archive = archive_de(dossier)
        if archive is None:
            print(f"Sources : pas d'archive des sources {version_du_dossier(dossier)} a cote du dossier, "
                  "rien n'est verifie.")
            return 0
        ecarter(dossier, archive)
    except Exception as exc:            # ne jamais empecher une compilation
        print(f"Sources : verification impossible ({exc})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
