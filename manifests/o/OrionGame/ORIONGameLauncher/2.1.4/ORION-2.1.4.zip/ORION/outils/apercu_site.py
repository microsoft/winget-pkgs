"""Apercu du site sur ce PC, avant publication.

Sert un dossier du site comme le fait l'hebergeur (« /sorties » rend
« sorties.html ») et ouvre le navigateur. Rien ne sort de la machine.

    python outils/apercu_site.py <dossier du site> [port]

Fermer la fenetre arrete l'apercu.
"""
from __future__ import annotations

import functools
import http.server
import os
import sys
import webbrowser


class Pages(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *args) -> None:
        pass

    def send_head(self):
        chemin = self.translate_path(self.path.split("?")[0].split("#")[0])
        if (not os.path.exists(chemin) or os.path.isdir(chemin)) \
                and os.path.exists(chemin.rstrip("/\\") + ".html"):
            self.path = self.path.split("?")[0].split("#")[0].rstrip("/") + ".html"
        return super().send_head()


def main() -> int:
    if len(sys.argv) < 2 or not os.path.isfile(os.path.join(sys.argv[1], "index.html")):
        print("Dossier du site introuvable (il doit contenir index.html).")
        return 1
    port = int(sys.argv[2]) if len(sys.argv) > 2 else 8790
    serveur = http.server.ThreadingHTTPServer(
        ("127.0.0.1", port), functools.partial(Pages, directory=sys.argv[1]))
    adresse = f"http://localhost:{port}/"
    print(f"Apercu du site : {adresse}\nFermez cette fenetre pour l'arreter.")
    webbrowser.open(adresse)
    try:
        serveur.serve_forever()
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
