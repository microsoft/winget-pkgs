"""Outil de developpement : liste les textes d'interface a traduire.

Usage : python outils/extraire_textes.py sortie.json
Compare ensuite avec orion/langues/<code>.json pour voir ce qui manque.
"""
import ast, glob, re, json, sys
FICHIERS = sorted(set(glob.glob('orion/ui/**/*.py', recursive=True) + [
 'orion/aide.py','orion/nouveautes.py','orion/marche_gris.py','orion/optimizer/profiles.py',
 'orion/optimizer/advisor.py','orion/optimizer/adaptive.py','orion/optimizer/engine.py','orion/hardware/bilan.py',
 'orion/freebies.py','orion/plugins/freebies/base.py','orion/boutique.py','orion/plugins/boutique/confiance.py',
 'orion/deploiement/interface.py','orion/launch/launcher.py','orion/saves.py','orion/wishlist.py',
 'orion/storage.py','orion/library.py','orion/core/liens.py','orion/plugins/market/base.py','orion/market.py',
 'orion/community.py','orion/plugins/scanners/base.py','orion/optimizer/backup.py','orion/perf/presentmon.py',
 'orion/ai/client.py','orion/hardware/probe.py','orion/hardware/displays.py','orion/core/config.py',
 'orion/plugins/boutique/base.py','orion/plugins/scanners/_filters.py',
 'orion/comptes/__init__.py','orion/comptes/base.py','orion/comptes/steam.py',
 'orion/comptes/gog.py','orion/comptes/xbox.py','orion/puissance/estimation.py',
 'orion/puissance/__init__.py','orion/puissance/lecture.py','orion/deplacement.py','orion/sorties.py','orion/en_ligne.py',
 'orion/comptes/coffre.py','orion/suggestions.py','orion/videos.py','orion/valeur_catalogue.py',
 'orion/sauvegarde_disque.py','orion/optimizer/recommande.py','orion/optimizer/fiabilite.py',
 'orion/hardware/systeme.py','orion/affiliation.py',
 'orion/plugins/market/steam_store.py']))
LOGS = {'debug','info','warning','error','exception','critical'}
def est_texte(s):
    if len(s) < 2 or len(s) > 1500: return False
    if not re.search(r'[A-Za-zÀ-ÿ]{2}', s): return False
    if re.fullmatch(r'[a-z0-9_.\-/:%{}\\]+', s): return False          # cles, chemins
    if re.fullmatch(r'[A-Z][A-Za-z]+[A-Z][A-Za-z]*', s) and ' ' not in s: return False  # objectName
    if s.startswith(('http','#','Q','<?')) and ' ' not in s: return False
    if re.search(r'\{\{|\}\}|;\s*$|:\s*[#\d]', s) and 'QPushButton' in s: return False
    if 'QLabel#' in s or 'QPushButton#' in s or 'background:' in s: return False
    return True
exact = {}; modeles = {}
for f in FICHIERS:
    try: tree = ast.parse(open(f, encoding='utf-8').read())
    except Exception as e: print('ERR', f, e); continue
    ignores = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Module)):
            if node.body and isinstance(node.body[0], ast.Expr) and isinstance(node.body[0].value, ast.Constant):
                ignores.add(id(node.body[0].value))
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr in LOGS \
           and isinstance(node.func.value, ast.Name) and node.func.value.id in ('log','logger','_log'):
            for sub in ast.walk(node): ignores.add(id(sub))
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr in ('get','set','setObjectName','setProperty','startswith','endswith','replace','split','join','strftime','format','search','match','sub','compile','findall'):
            for a in node.args[:1]:
                if isinstance(a, ast.Constant): ignores.add(id(a))
        if isinstance(node, ast.Subscript):
            for sub in ast.walk(node.slice): ignores.add(id(sub))
        if isinstance(node, ast.Compare):
            for sub in node.comparators:
                if isinstance(sub, ast.Constant): ignores.add(id(sub))
    for node in ast.walk(tree):
        if isinstance(node, ast.JoinedStr) and id(node) not in ignores:
            parts = []; n = 0; ok = True
            for v in node.values:
                if isinstance(v, ast.Constant): parts.append(v.value)
                elif isinstance(v, ast.FormattedValue):
                    parts.append('{%d}' % n); n += 1
                    for sub in ast.walk(v): ignores.add(id(sub))
                else: ok = False
            modele = ''.join(parts)
            for v in node.values: ignores.add(id(v))
            texte_seul = re.sub(r'\{\d+\}', '', modele)
            if ok and n and est_texte(texte_seul) and re.search(r'[A-Za-zÀ-ÿ]{3}', texte_seul):
                modeles.setdefault(modele, f)
    for node in ast.walk(tree):
        if isinstance(node, ast.Constant) and isinstance(node.value, str) and id(node) not in ignores:
            if est_texte(node.value):
                exact.setdefault(node.value, f)
json.dump({'exact': exact, 'modeles': modeles}, open(sys.argv[1], 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
print(len(exact), sum(len(k) for k in exact), len(modeles), sum(len(k) for k in modeles))
