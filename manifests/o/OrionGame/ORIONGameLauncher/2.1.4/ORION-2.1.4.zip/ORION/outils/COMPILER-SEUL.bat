@echo off
chcp 65001 >nul
title ORION - compilation seule (sans installer)
rem A poser A COTE de ORION.zip (dossier "Claude creation"), pas dans ORION.
rem Met les sources du dossier ORION a jour depuis ORION.zip (au bon endroit :
rem le 10 octobre, l'archive extraite a la main DANS ORION avait fait compiler
rem les sources de la veille), puis compile. Copie de reference : ORION\outils.
set "BASE=%~dp0"
cd /d "%BASE%"
if not exist "%BASE%ORION.zip" (
  echo   ORION.zip introuvable a cote de ce fichier.
  pause
  exit /b 1
)
echo.
echo   ORION - mise a jour des sources et compilation (ORION reste ouvert)
echo.
echo   [1/2] Mise a jour des sources...
powershell -NoProfile -Command ^
  "Expand-Archive -LiteralPath '%BASE%ORION.zip' -DestinationPath '%BASE%maj_tmp' -Force;" ^
  "Copy-Item -Path '%BASE%maj_tmp\ORION\*' -Destination '%BASE%ORION' -Recurse -Force;" ^
  "Remove-Item '%BASE%maj_tmp' -Recurse -Force"
if not exist "%BASE%ORION\CONSTRUIRE-EXE.bat" (
  echo   ECHEC : sources introuvables.
  pause
  exit /b 1
)
echo   [2/2] Compilation... (plusieurs minutes)
cd /d "%BASE%ORION"
if exist "dist\Installateur-ORION.exe" del /q "dist\Installateur-ORION.exe"
call "%BASE%ORION\CONSTRUIRE-EXE.bat" --sans-pause > "%BASE%_compilation-seule.log" 2>&1
if exist "dist\Installateur-ORION.exe" (
  echo COMPILATION OK>> "%BASE%_compilation-seule.log"
  echo.
  echo   COMPILATION OK : ORION\dist\Installateur-ORION.exe
  timeout /t 6 >nul
  exit /b 0
)
echo COMPILATION ECHEC>> "%BASE%_compilation-seule.log"
echo.
echo   COMPILATION ECHEC. La raison :
findstr /c:"ARRET" /c:"ECHEC" /c:"Sources :" "%BASE%_compilation-seule.log" "%BASE%ORION\_compilation.log"
echo.
echo   Journaux : _compilation-seule.log et ORION\_compilation.log
pause
exit /b 1
