"""Captures d'ecran d'ORION pour le site et la fiche du Store (2.0).

La vraie fenetre d'ORION est construite avec une COPIE des donnees du joueur
(base lue en lecture seule, images du cache partagees) : rien n'est ecrit
dans le dossier d'ORION, et l'ORION deja ouvert n'est pas derange. La
fenetre n'apparait pas a l'ecran ; chaque page est dessinee dans une image.

    python outils/captures_site.py [dossier de sortie]
        --donnees DOSSIER   dossier des donnees a copier (defaut : celui d'ORION)
        --taille 1600x1000  taille de la fenetre
        --jeu "Titre"       jeu ouvert pour la fiche (bibliotheque et Boutique)
        --jeu-machine "T"   jeu explique dans « Ma machine » (defaut : un jeu
                            qu'un reglage ferait monter d'un niveau)
        --hors-ligne        aucun appel reseau (essais)

Les images sont a relire avant d'etre publiees : elles montrent la vraie
bibliotheque, le vrai materiel et les vrais comptes de la machine.
"""
from __future__ import annotations

import argparse
import os
import shutil
import sqlite3
import subprocess
import sys
import time
from pathlib import Path

RACINE = Path(__file__).resolve().parent.parent


def _donnees_par_defaut() -> Path:
    base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
    return Path(base) / "ORION"


def _copier_base(source: Path, cible: Path) -> None:
    """Copie coherente de la base, meme si ORION est ouvert et y ecrit."""
    if not source.exists():
        return
    if cible.exists():
        cible.unlink()
    try:
        lecture = sqlite3.connect(f"file:{source.as_posix()}?mode=ro", uri=True, timeout=10)
        ecriture = sqlite3.connect(str(cible))
        with ecriture:
            lecture.backup(ecriture)
        lecture.close()
        ecriture.close()
    except sqlite3.Error:
        shutil.copy2(source, cible)


def _lier(source: Path, cible: Path) -> bool:
    """`cible` montre le contenu de `source` sans le copier (jonction sous
    Windows, lien ailleurs). Faux si le lien n'a pas pu etre fait."""
    if cible.exists() or cible.is_symlink():
        return True
    try:
        if os.name == "nt":
            fait = subprocess.run(["cmd", "/c", "mklink", "/J", str(cible), str(source)],
                                  capture_output=True)
            return fait.returncode == 0
        os.symlink(source, cible, target_is_directory=True)
        return True
    except OSError:
        return False


def preparer(donnees: Path, travail: Path) -> None:
    travail.mkdir(parents=True, exist_ok=True)
    _copier_base(donnees / "orion.db", travail / "orion.db")
    for nom in ("config.json",):
        if (donnees / nom).exists():
            shutil.copy2(donnees / nom, travail / nom)
    if (donnees / "cache").is_dir() and not _lier(donnees / "cache", travail / "cache"):
        print("   (images du cache non reliees : les jaquettes seront retelechargees)")
    verrou = travail / ".session-en-cours"
    if verrou.exists():
        verrou.unlink()


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    p.add_argument("sortie", nargs="?", default=str(RACINE.parent / "captures-site"))
    p.add_argument("--donnees", default=str(_donnees_par_defaut()))
    p.add_argument("--taille", default="1600x1000")
    p.add_argument("--jeu", default="")
    p.add_argument("--jeu-machine", default="")
    p.add_argument("--hors-ligne", action="store_true")
    a = p.parse_args()

    sortie = Path(a.sortie).resolve()
    sortie.mkdir(parents=True, exist_ok=True)
    travail = sortie / "_donnees"
    preparer(Path(a.donnees), travail)
    os.environ["ORION_DATA_DIR"] = str(travail)
    sys.path.insert(0, str(RACINE))
    largeur, hauteur = (int(x) for x in a.taille.lower().split("x"))

    if a.hors_ligne:
        import requests

        def _non(*_a, **_k):
            raise requests.ConnectionError("hors ligne (captures)")
        requests.Session.request = _non

    from PySide6.QtCore import Qt
    from PySide6.QtGui import QIcon
    from PySide6.QtWidgets import QAbstractScrollArea, QApplication, QDialog, QMessageBox

    QApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    app = QApplication(["orion-captures"])
    # aucune boite de dialogue ne doit attendre une reponse que personne ne donnera
    QDialog.exec = lambda self, *args: 0
    QMessageBox.exec = lambda self, *args: 0

    from orion.core.config import CONFIG
    CONFIG.set("langue", "fr")
    CONFIG.set("ui.single_instance", False)
    CONFIG.set("ui.splash", False)
    from orion import i18n
    from orion.ui.icon import app_icon
    app.setWindowIcon(QIcon(app_icon()))
    i18n.activer()
    from orion.ui import defilement, repos
    from orion.ui.main_window import MainWindow
    defilement.installer(app)

    fenetre = MainWindow()
    fenetre.setAttribute(Qt.WidgetAttribute.WA_DontShowOnScreen, True)
    fenetre.resize(largeur, hauteur)
    fenetre.show()

    def attendre(secondes: float, jusqu_a=None) -> None:
        fin = time.perf_counter() + secondes
        while time.perf_counter() < fin:
            app.processEvents()
            if jusqu_a is not None and jusqu_a():
                break
            time.sleep(0.01)
        repos.tout_faire()
        app.processEvents()

    faites: list[str] = []

    def saisir(nom: str, widget=None, pause: float = 2.5) -> None:
        attendre(pause)
        image = (widget or fenetre).grab()
        chemin = sortie / f"{nom}.png"
        if image.save(str(chemin)):
            faites.append(f"{nom}.png  {image.width()}x{image.height()}")
            print("  ", faites[-1], flush=True)

    def defiler(page, part: float) -> None:
        """Fait defiler la plus grande zone de la page a `part` de sa course."""
        zones = [z for z in page.findChildren(QAbstractScrollArea)
                 if z.isVisible() and z.verticalScrollBar().maximum() > 0]
        if isinstance(page, QAbstractScrollArea) and page.verticalScrollBar().maximum() > 0:
            zones.append(page)
        if not zones:
            return
        zone = max(zones, key=lambda z: z.width() * z.height())
        barre = zone.verticalScrollBar()
        barre.setValue(int(barre.maximum() * part))

    def monter(page, widget) -> None:
        """Amene `widget` en haut de la zone qui le fait defiler."""
        from PySide6.QtWidgets import QScrollArea
        parent = widget.parentWidget()
        while parent is not None and not isinstance(parent, QScrollArea):
            parent = parent.parentWidget()
        if parent is None or parent.widget() is None:
            return
        haut = widget.mapTo(parent.widget(), widget.rect().topLeft()).y()
        parent.verticalScrollBar().setValue(max(0, haut - 14))

    def essayer(nom: str, action) -> None:
        try:
            action()
        except Exception as exc:                      # une page en echec n'arrete pas les autres
            print(f"   {nom} : ECHEC {type(exc).__name__} : {exc}", flush=True)

    print("Demarrage d'ORION (copie des donnees)...", flush=True)
    attendre(45 if not a.hors_ligne else 8,
             lambda: fenetre.hw is not None and bool(fenetre.boutique_view._catalogue)
             and not fenetre._boutique_busy)
    attendre(6 if not a.hors_ligne else 2)

    # -- Bibliotheque ---------------------------------------------------
    def bibliotheque():
        fenetre.show_page("library")
        # les jaquettes manquantes arrivent une a une : on attend la fin
        attendre(60 if not a.hors_ligne else 3,
                 lambda: not fenetre.library_view.progress.isVisible())
        try:                                 # la banniere tourne : son premier jeu
            fenetre.library_view.hero._show(0, animate=False)   # est le dernier joue
        except Exception:
            pass
        saisir("bibliotheque", pause=4)
    essayer("bibliotheque", bibliotheque)

    # -- Fiche d'un jeu ---------------------------------------------------
    jeux = list(fenetre.library.games())
    voulu = a.jeu.strip().lower()
    choisi = next((j for j in jeux if voulu and voulu in j.title.lower()), None)
    if choisi is None and jeux:
        installes = [j for j in jeux if not (j.extra or {}).get("non_installe")] or jeux
        choisi = max(installes, key=lambda j: getattr(j, "play_seconds", 0) or 0)

    def fiche():
        if choisi is None:
            return
        fenetre.open_game(choisi.uid)
        saisir("fiche-jeu", pause=6)
        # les deux cartes « Votre ecran » / « Mon choix » en haut de l'image
        # (2.1.0 : `CarteRecommande` n'existe plus, la capture echouait)
        from orion.ui.widgets import profile_card
        cartes = [c for c in fenetre.detail_view.findChildren(profile_card.ChoixGraphismes)
                  if c.isVisible()]
        if cartes:
            monter(fenetre.detail_view, cartes[0])
            saisir("fiche-jeu-reglages", pause=2)
        defiler(fenetre.detail_view, 0.5)
        saisir("fiche-jeu-videos", pause=2)
        defiler(fenetre.detail_view, 0.82)
        saisir("fiche-jeu-bas", pause=2)
    essayer("fiche d'un jeu", fiche)

    # -- Boutique ---------------------------------------------------------
    vue = fenetre.boutique_view

    def boutique():
        fenetre.show_page("boutique")
        fenetre.boutique_page.montrer("offres")
        vue.accueil()
        saisir("boutique", pause=8)
        defiler(vue, 0.22)
        saisir("boutique-rangees", pause=5)
        defiler(vue, 0.0)
    essayer("boutique", boutique)

    def boutique_type():
        types = list(getattr(vue, "_types_accueil", []) or [])
        if not types:
            return
        vue.choisir_type("fps" if "fps" in types else types[0])
        saisir("boutique-type", pause=6)
        vue.accueil()
    essayer("boutique, page d'un type", boutique_type)

    def boutique_fiche():
        connues = [f for f in vue._catalogue if f.meilleure and not f.gratuit
                   and len(f.offres_sures) >= 2]
        cible = next((f for f in connues if voulu and voulu in f.titre.lower()), None)
        if cible is None and connues:
            from orion import suggestions
            cible = max(connues, key=suggestions.notoriete)
        if cible is None:
            return
        dialogue = vue.ouvrir_fiche(cible)
        dialogue.hide()                      # elle s'ouvre d'elle-meme a l'ecran
        dialogue.setAttribute(Qt.WidgetAttribute.WA_DontShowOnScreen, True)
        dialogue.show()
        try:
            dialogue.ligne.bouton_comparer.setChecked(True)
        except Exception:
            pass
        saisir("boutique-fiche", dialogue, pause=7)
        dialogue.close()
    essayer("boutique, fiche d'un jeu", boutique_fiche)

    def gratuits():
        fenetre.show_page("boutique")
        fenetre.boutique_page.montrer("gratuits")
        saisir("jeux-gratuits", pause=6)
        fenetre.boutique_page.montrer("offres")
    essayer("jeux gratuits", gratuits)

    # -- Ma machine -------------------------------------------------------
    def machine():
        fenetre.show_page("hardware")
        saisir("ma-machine", pause=5)
        panneau = fenetre.hardware_view.puissance
        titres = panneau.titres_visibles()
        explique = a.jeu_machine.strip().lower()
        rang = next((i for i, t in enumerate(titres) if explique and explique in t.lower()),
                    None)
        if rang is None:
            # un jeu qui a une piste : c'est ce que la page montre de mieux
            rang = next((i for i, (_c, e) in enumerate(
                panneau.modele.tout[k] for k in panneau.modele.ordre) if e.piste), 0)
        if titres:
            panneau.choisir(rang)
        attendre(0.5)
        monter(fenetre.hardware_view, panneau)
        saisir("ma-machine-jeux", pause=2)
    essayer("ma machine", machine)

    # -- Les autres pages ---------------------------------------------------
    for page, nom in (("storage", "stockage"), ("advice", "conseils"),
                      ("comptes", "comptes"), ("settings", "reglages"),
                      ("sorties", "sorties"), ("wishlist", "envies"),
                      ("tutorial", "tuto")):
        essayer(nom, lambda page=page, nom=nom: (fenetre.show_page(page),
                                                 saisir(nom, pause=5)))

    # -- Fin : le lien vers le cache est retire, jamais son contenu -------
    fenetre.close()
    app.processEvents()
    cache = travail / "cache"
    try:
        if cache.is_symlink():
            cache.unlink()
        elif os.name == "nt" and cache.exists():
            os.rmdir(cache)             # retire la jonction, pas ce qu'elle montre
    except OSError:
        pass
    (sortie / "LISEZ-MOI.txt").write_text(
        "Captures d'ORION faites par outils/captures_site.py\n\n" + "\n".join(faites)
        + "\n\nA relire avant publication : elles montrent la vraie bibliotheque, le vrai\n"
          "materiel et les vrais comptes de cette machine.\n", encoding="utf-8")
    print(f"{len(faites)} capture(s) dans {sortie}", flush=True)
    return 0 if faites else 1


if __name__ == "__main__":
    code = main()
    # des fils de fond (veille des prix, visuels) peuvent encore tourner :
    # les images sont ecrites, on sort sans les attendre
    sys.stdout.flush()
    os._exit(code)
