"""Allege l'application compilee avant de fabriquer l'installateur (1.8).

Le navigateur integre (QtWebEngine) apporte avec lui beaucoup de fichiers
inutiles a ORION : versions « debug » de ses ressources, outils de
developpement, 44 langues, et des modules Qt que PyInstaller embarque par
precaution (3D, graphiques, PDF, QML...). On les retire ; la verification
qui suit la compilation charge ensuite une vraie page dans le navigateur
integre pour prouver qu'il fonctionne toujours.

Usage : python outils/alleger.py dist\\ORION
"""
import shutil
import sys
from pathlib import Path

GARDER_LANGUES = {"fr.pak", "en-US.pak", "en-GB.pak"}

MOTIFS_INUTILES = [
    # ressources du moteur web en version de debogage, et outils developpeur
    "resources/*.debug.pak", "resources/*.debug.bin",
    "resources/qtwebengine_devtools_resources*.pak",
    # rendu OpenGL logiciel de secours (ORION est une interface Widgets)
    "opengl32sw.dll",
    # modules Qt jamais utilises par ORION
    "qml", "Qt63D*", "Qt3D*", "Qt6Quick3D*", "QtQuick3D*", "Qt6Graphs*", "QtGraphs*",
    "Qt6Pdf*", "QtPdf*", "Qt6Charts*", "QtCharts*", "Qt6DataVisualization*",
    "QtDataVisualization*", "Qt6QuickControls2*", "QtQuickControls2*",
    "Qt6QuickDialogs2*", "Qt6QuickTemplates2*", "Qt6QuickLayouts*", "Qt6QuickShapes*",
    "Qt6QuickParticles*", "Qt6QuickTimeline*", "Qt6QuickVectorImage*",
    "Qt6Multimedia*", "QtMultimedia*", "Qt6SpatialAudio*", "Qt6Sensors*", "QtSensors*",
    "Qt6SerialPort*", "QtSerialPort*", "Qt6SerialBus*", "Qt6Bluetooth*", "QtBluetooth*",
    "Qt6Nfc*", "QtNfc*", "Qt6RemoteObjects*", "QtRemoteObjects*", "Qt6Scxml*",
    "QtScxml*", "Qt6StateMachine*", "QtStateMachine*", "Qt6TextToSpeech*",
    "QtTextToSpeech*", "Qt6VirtualKeyboard*", "Qt6Location*", "QtLocation*",
    "Qt6Designer*", "QtDesigner*", "Qt6Help*", "QtHelp*", "Qt6Test*", "QtTest*",
    "Qt6ShaderTools*", "Qt6HttpServer*", "QtHttpServer*", "Qt6Protobuf*",
    "Qt6Grpc*", "Qt6Sql*", "QtSql*", "Qt6UiTools*", "QtUiTools*",
]


def taille(p: Path) -> int:
    if p.is_file():
        return p.stat().st_size
    return sum(f.stat().st_size for f in p.rglob("*") if f.is_file())


def alleger(racine: Path) -> int:
    qt = racine / "_internal" / "PySide6"
    if not qt.is_dir():
        print("PySide6 introuvable :", qt)
        return 0
    gagne = 0
    for motif in MOTIFS_INUTILES:
        for p in qt.glob(motif):
            gagne += taille(p)
            if p.is_dir():
                shutil.rmtree(p, ignore_errors=True)
            else:
                p.unlink(missing_ok=True)
    for dossier in (qt / "translations" / "qtwebengine_locales",):
        if dossier.is_dir():
            for f in dossier.iterdir():
                if f.name not in GARDER_LANGUES:
                    gagne += taille(f)
                    f.unlink(missing_ok=True)
    trad = qt / "translations"
    if trad.is_dir():
        for f in trad.glob("*.qm"):
            if not any(f.name.endswith(s) for s in ("_fr.qm", "_en.qm")):
                gagne += taille(f)
                f.unlink(missing_ok=True)
    return gagne


if __name__ == "__main__":
    cible = Path(sys.argv[1] if len(sys.argv) > 1 else "dist/ORION")
    octets = alleger(cible)
    print(f"Allegement : {octets / 1024 ** 2:.0f} Mo retires "
          f"(reste {taille(cible / '_internal') / 1024 ** 2:.0f} Mo)")
