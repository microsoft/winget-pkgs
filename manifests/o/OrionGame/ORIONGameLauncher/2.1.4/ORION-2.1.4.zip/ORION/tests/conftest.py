"""Configuration commune : chaque test travaille dans un dossier de donnees
jetable, jamais dans le vrai %LOCALAPPDATA%\\ORION."""
import os
import sys
import tempfile
from pathlib import Path

RACINE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RACINE))

_DONNEES = tempfile.mkdtemp(prefix="orion-tests-")
os.environ["ORION_DATA_DIR"] = _DONNEES
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest  # noqa: E402


def _couper_le_reseau() -> None:
    """Aucun essai ne sort sur Internet. Les essais qui ont besoin d'une
    reponse la fournissent eux-memes ; sans cette garde, une fenetre
    principale laissee par un essai finissait par demarrer pour de bon et
    interrogeait Steam, GOG ou GitHub pendant la suite (lent, bruyant, et
    dependant du reseau du jour). Les adresses locales restent permises."""
    import socket
    vraie = socket.socket.connect

    def connect(self, adresse, *a, **k):
        hote = adresse[0] if isinstance(adresse, tuple) else ""
        if isinstance(adresse, tuple) and not str(hote).startswith(("127.", "::1", "localhost")):
            raise ConnectionRefusedError(f"pas de reseau pendant les essais ({hote})")
        return vraie(self, adresse, *a, **k)

    socket.socket.connect = connect
    for variable in ("HTTPS_PROXY", "https_proxy", "HTTP_PROXY", "http_proxy",
                     "ALL_PROXY", "all_proxy"):
        os.environ.pop(variable, None)


_couper_le_reseau()


@pytest.fixture(autouse=True)
def _detruire_ce_qui_doit_l_etre():
    """Apres chaque essai, ce qu'il a confie a `deleteLater()` est vraiment
    detruit. Sans boucle d'evenements Qt ne le fait jamais : chaque fenetre
    principale creee par un essai restait en vie, avec ses minuteries et ses
    taches de fond, et tournait pendant tous les essais suivants (suite plus
    lente, essais qui echouaient au hasard faute de fil libre)."""
    yield
    try:
        from PySide6.QtCore import QCoreApplication, QEvent
        if QCoreApplication.instance() is not None:
            QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
    except Exception:
        pass


@pytest.fixture
def base_neuve(tmp_path, monkeypatch):
    """Base SQLite vide, propre a un test."""
    from orion.core import base
    base.fermer()
    monkeypatch.setattr(base, "FICHIER", tmp_path / "orion.db")
    yield base
    base.fermer()


@pytest.fixture(autouse=True)
def _pas_de_fenetre_arret_brutal(monkeypatch):
    """Plusieurs fenetres principales naissent dans le meme dossier de donnees
    pendant les tests : sans ceci, la suivante croit a un arret brutal et
    ouvre une boite de dialogue qui bloque la suite."""
    try:
        from orion import signalement
        monkeypatch.setattr(signalement, "ouvrir_session", lambda *a, **k: False)
    except Exception:
        pass
    yield


@pytest.fixture(autouse=True)
def _pas_de_prix_en_ligne(monkeypatch):
    """Ouvrir un comparatif demande le prix des revendeurs au service
    d'ORION : jamais pendant les tests (ceux qui l'essaient le remplacent)."""
    try:
        from orion import prix_revendeurs
        monkeypatch.setattr(prix_revendeurs, "offres", lambda *a, **k: {})
        monkeypatch.setattr(prix_revendeurs, "lot", lambda *a, **k: {})   # cartes de la Boutique
        # ni le fichier des prix de Gamesplanet (meme regle)
        from orion import prix_gamesplanet
        monkeypatch.setattr(prix_gamesplanet, "actualiser", lambda *a, **k: False)
        monkeypatch.setitem(prix_gamesplanet._memo, "releve", 0.0)
        monkeypatch.setitem(prix_gamesplanet._memo, "jeux", {})
        # ni les plus bas historiques (relais IsThereAnyDeal) ; les essais qui
        # les verifient remettent la vraie methode
        from orion import boutique
        monkeypatch.setattr(boutique.BoutiqueService, "relever_plus_bas",
                            lambda self, fiches=None: 0)
        # ni la seconde partie de l'actualisation (types, fiches, plus bas),
        # lancee par la fenetre principale apres chaque releve
        monkeypatch.setattr(boutique.BoutiqueService, "completer",
                            lambda self, progress_cb=None: False)
        # ni les jeux « du meme esprit » (Steam, service d'ORION)
        monkeypatch.setattr(boutique.BoutiqueService, "dans_l_esprit",
                            lambda self, terme, sans_resultat=False: None)
        # ni les DLC d'un jeu (fiche Steam + fichiers du client Steam)
        from orion import dlc
        from orion.ui.widgets import dlc_panel
        monkeypatch.setattr(dlc_panel, "chercher_dlc", lambda appid: dlc.Resultat(str(appid)))
    except Exception:
        pass
    yield
