"""Le fil d'ecriture de la base (`core.base._Ecrivain`), relecture du 16/10 :
la fermeture d'ORION figeait 5 s (`vider` rejoignait un fil qui ne finit
jamais) et pouvait recouvrir la bibliotheque finale par une version plus
ancienne encore dans le fil."""
import threading
import time

import pytest


@pytest.fixture
def ecrivain(base_neuve, monkeypatch):
    base = base_neuve
    neuf = base._Ecrivain()
    monkeypatch.setattr(base, "_ecrivain", neuf)
    return base, neuf


def test_vider_revient_tout_de_suite_quand_tout_est_ecrit(ecrivain):
    base, ecr = ecrivain
    doc = base.Document("bib")
    doc.deposer({"v": 1})
    depart = time.monotonic()
    ecr.vider()
    assert time.monotonic() - depart < 1.0        # etait 5,0 s (join du fil)
    assert doc.lire() == {"v": 1}
    assert ecr._fil is not None and ecr._fil.is_alive()   # le fil reste pour la suite
    depart = time.monotonic()
    ecr.vider()                                    # rien a ecrire : immediat
    assert time.monotonic() - depart < 0.2


def test_la_fermeture_garde_la_derniere_version(ecrivain, monkeypatch):
    """Depot asynchrone lent en cours, puis ecriture finale : c'est la finale
    qui reste (avant : le fil recouvrait avec sa version plus ancienne)."""
    base, ecr = ecrivain
    doc = base.Document("bib")
    vrai_ecrire = base.Document.ecrire
    lent = threading.Event()

    def ecrire_lent(self, contenu):
        if not lent.is_set():
            lent.set()
            time.sleep(0.3)
        return vrai_ecrire(self, contenu)
    monkeypatch.setattr(base.Document, "ecrire", ecrire_lent)
    doc.deposer({"v": 1})
    lent.wait(2)                       # le fil est dans l'ecriture lente de v1
    doc.deposer({"v": 2}, attendre=True)   # fermeture : la finale, apres v1
    assert doc.lire() == {"v": 2}
    assert not ecr.en_attente()


def test_vider_attend_l_ecriture_en_cours(ecrivain, monkeypatch):
    base, ecr = ecrivain
    doc = base.Document("stats")
    vrai_ecrire = base.Document.ecrire
    monkeypatch.setattr(base.Document, "ecrire",
                        lambda self, c: (time.sleep(0.25), vrai_ecrire(self, c))[1])
    doc.deposer({"n": 7})
    time.sleep(0.05)
    assert ecr.en_attente()
    ecr.vider()
    assert not ecr.en_attente() and doc.lire() == {"n": 7}


def test_une_ecriture_qui_echoue_ne_tue_pas_le_fil(ecrivain, monkeypatch):
    base, ecr = ecrivain
    doc = base.Document("bib")
    vrai_ecrire = base.Document.ecrire
    etat = {"n": 0}

    def ecrire(self, contenu):
        etat["n"] += 1
        if etat["n"] == 1:
            raise RuntimeError("disque plein")
        return vrai_ecrire(self, contenu)
    monkeypatch.setattr(base.Document, "ecrire", ecrire)
    doc.deposer({"v": 1})
    ecr.vider()
    doc.deposer({"v": 2})
    ecr.vider()
    assert doc.lire() == {"v": 2} and etat["n"] == 2


def test_vider_depuis_le_fil_d_ecriture_ne_s_attend_pas(ecrivain, monkeypatch):
    base, ecr = ecrivain
    doc = base.Document("bib")
    vrai_ecrire = base.Document.ecrire
    duree = {}

    def ecrire(self, contenu):
        depart = time.monotonic()
        ecr.vider()                    # un document qui en ecrit un autre
        duree["s"] = time.monotonic() - depart
        return vrai_ecrire(self, contenu)
    monkeypatch.setattr(base.Document, "ecrire", ecrire)
    doc.deposer({"v": 1})
    ecr.vider()
    assert duree["s"] < 0.2 and doc.lire() == {"v": 1}


def test_plus_tard_avec_delai_depuis_un_autre_fil():
    """`plus_tard(obj, 50, fn)` demande depuis un fil Python doit sonner (avant :
    la minuterie partait d'un fil sans boucle Qt et ne sonnait jamais)."""
    from PySide6.QtCore import QEventLoop, QObject, QTimer
    from PySide6.QtWidgets import QApplication
    from orion.ui.minuteur import plus_tard
    app = QApplication.instance() or QApplication([])
    assert app
    proprietaire = QObject()
    boucle = QEventLoop()
    vu = []

    def fn():
        vu.append(threading.current_thread() is threading.main_thread())
        boucle.quit()
    threading.Thread(target=lambda: plus_tard(proprietaire, 50, fn)).start()
    QTimer.singleShot(2000, boucle.quit)   # garde-fou de l'essai
    boucle.exec()
    assert vu == [True]
