"""Compteur anonyme (1.9.6) : rien sans accord, rien de personnel, et un
seul passage pour les clics."""
import json
import shutil
import subprocess
from pathlib import Path

import pytest

from orion import affiliation, compteur, partage
from orion.core import reseau
from orion.core.config import CONFIG


@pytest.fixture
def envois(monkeypatch):
    recus = []

    class Rep:
        status_code = 200

    def faux(url, **k):
        recus.append((url, k.get("json")))
        return Rep()
    monkeypatch.setattr(reseau, "post", faux)
    monkeypatch.setattr(compteur, "ATTENTE", 3600.0)
    monkeypatch.setattr(compteur, "_ouverture_envoyee", False)
    compteur._vider()
    avant = {c: CONFIG.get(c) for c in ("partage.actif", "partage.demande", "partage.question")}
    yield recus
    compteur._vider()
    for c, v in avant.items():
        CONFIG.set(c, v)


def _accord(oui=True, question=partage.QUESTION):
    CONFIG.set("partage.demande", True)
    CONFIG.set("partage.actif", oui)
    CONFIG.set("partage.question", question)


def test_rien_sans_accord(envois, monkeypatch):
    monkeypatch.setattr(affiliation.webbrowser, "open", lambda u: True)
    _accord(False)
    compteur.page("boutique")
    compteur.clic("https://www.instant-gaming.com/fr/123-jeu/", "boutique")
    affiliation.ouvrir("https://store.steampowered.com/app/730/", "fiche")
    compteur.ouverture()
    assert compteur._attente == {} and compteur.envoyer() is False and envois == []


def test_un_oui_a_l_ancienne_question_ne_vaut_pas_pour_le_compteur(envois):
    """1.9.5 : la question ne parlait que des mesures. Ce oui-la ne couvre
    pas le compteur, et la question est reposee une fois."""
    _accord(True, question=1)
    assert partage.actif() and not compteur.autorise()
    assert partage.a_demander()
    compteur.page("boutique")
    assert compteur._attente == {} and envois == []
    partage.repondre(True)
    assert compteur.autorise() and not partage.a_demander()
    partage.repondre(False)
    assert not compteur.autorise() and not partage.a_demander()


def test_ce_qui_part_ne_contient_ni_jeu_ni_adresse(envois, monkeypatch):
    ouverts = []
    monkeypatch.setattr(affiliation.webbrowser, "open", lambda u: ouverts.append(u))
    _accord(True)
    compteur.page("boutique")
    compteur.page("boutique")
    compteur.page("page-inconnue")                       # ignoree
    affiliation.ouvreur("boutique")("https://www.instant-gaming.com/fr/4824-acheter-cyberpunk-2077/")
    affiliation.ouvrir("https://store.steampowered.com/app/1091500/Cyberpunk_2077/", "fiche")
    affiliation.ouvrir("https://github.com/x/y/releases/latest", "fond")   # pas une boutique
    affiliation.ouvrir("https://boutique-inconnue.example/jeu", "nimporte")
    assert len(ouverts) == 4
    assert compteur.envoyer() is True
    (url, corps), = envois
    assert url == partage.SERVICE + "/compteur"
    assert set(corps) == {"v", "app", "canal", "poste", "evenements"}
    assert corps["canal"] in ("store", "installateur") and len(corps["poste"]) == 32
    lignes = {(e["nom"], e["detail"], e["origine"]): e["n"] for e in corps["evenements"]}
    assert lignes == {("page", "boutique", ""): 2,
                      ("clic", "instant-gaming", "boutique"): 1,
                      ("clic", "steam", "fiche"): 1,
                      ("clic", "autre", ""): 1}
    texte = json.dumps(corps).lower()
    for interdit in ("cyberpunk", "1091500", "http", "4824", "example", "github"):
        assert interdit not in texte
    # deja envoye : rien ne repart
    assert compteur.envoyer() is False and len(envois) == 1


def test_ouverture_une_fois_par_lancement(envois):
    _accord(True)
    compteur.ouverture()
    compteur.ouverture()
    import time
    fin = time.time() + 3
    while not envois and time.time() < fin:
        time.sleep(0.01)
    compteur.envoyer()
    ouvertures = [e for _u, c in envois for e in c["evenements"] if e["nom"] == "ouverture"]
    assert len(ouvertures) == 1 and ouvertures[0]["n"] == 1


def test_le_compteur_ne_casse_jamais_rien(envois, monkeypatch):
    _accord(True)

    def panne(*a, **k):
        raise OSError("hors ligne")
    monkeypatch.setattr(reseau, "post", panne)
    compteur.page("sorties")
    assert compteur.envoyer() is False          # abandonne, jamais garde
    assert compteur._attente == {}
    compteur.clic(None, "boutique")
    compteur.fermer()
    compteur.attendre(2.0)


def test_retrait_de_l_accord_vide_l_attente(envois):
    _accord(True)
    compteur.page("boutique")
    _accord(False)
    compteur.fermer()
    assert compteur.attendre(2.0) and compteur._attente == {} and envois == []


def test_noms_de_boutiques():
    assert compteur.boutique_de("https://www.kinguin.net/category/1/x") == "kinguin"
    assert compteur.boutique_de("https://fr.gamesplanet.com/game/x") == "gamesplanet"
    assert compteur.boutique_de("https://www.gog.com/fr/game/x") == "gog"
    assert compteur.boutique_de("https://store.epicgames.com/fr/p/x") == "epic"
    assert compteur.boutique_de("https://isthereanydeal.com/game/x/") == "itad"
    assert compteur.boutique_de("") == "" and compteur.boutique_de("pas une adresse") == ""


def test_tous_les_liens_de_boutique_passent_par_le_passage_unique():
    """Garde-fou : une page ecrite demain qui ouvrirait une offre sans passer
    par `affiliation` ne serait ni affiliee ni comptee."""
    import re
    import orion
    racine = Path(orion.__file__).parent
    permis = {"affiliation.py",                 # le passage unique
              "settings_view.py", "tutorial_view.py", "donate_dialog.py",
              "advice_card.py", "dialogues.py",  # dons, cles d'API, aide, notes de version
              "note_store.py"}                   # page de notation du Store (pas une boutique)
    fautifs = sorted({f.name for f in racine.rglob("*.py")
                      if f.name not in permis
                      and re.search(r"webbrowser\.open\(", f.read_text(encoding="utf-8"))})
    assert not fautifs, fautifs
    # et chaque page declare d'ou vient le clic
    sans_origine = sorted({f.name for f in (racine / "ui").rglob("*.py")
                           if re.search(r"import ouvrir as ouvrir_lien", f.read_text(encoding="utf-8"))})
    assert not sans_origine, sans_origine


def test_les_pages_de_la_barre_sont_toutes_comptees():
    from orion.ui.widgets.sidebar import PAGES
    assert {cle for cle, _nom in PAGES} <= compteur.PAGES
    service = (Path(__file__).parents[1] / "service" / "worker.js").read_text(encoding="utf-8")
    for cle in compteur.PAGES:
        assert f'"{cle}"' in service, cle        # le service accepte les memes noms
    for origine in compteur.ORIGINES:
        assert f'"{origine}"' in service, origine


def test_service_en_ligne():
    """La vraie logique et le vrai SQL du service, sur une base en memoire."""
    node = shutil.which("node")
    if not node:
        pytest.skip("node absent")
    dossier = Path(__file__).parents[1] / "service"
    r = subprocess.run([node, "--experimental-sqlite", "essai_worker.mjs"], cwd=dossier,
                       capture_output=True, text=True, timeout=60)
    if "node:sqlite" in r.stderr and "ERR_UNKNOWN_BUILTIN_MODULE" in r.stderr:
        pytest.skip("node sans sqlite")
    assert r.returncode == 0 and "service ok" in r.stdout, r.stderr[-2000:]


def test_question_4_annonce_le_bilan_de_fluidite(envois):
    """2.0.1 : le dernier envoi porte le bilan de fluidite de la session. Un
    oui donne au texte de la 1.9.7 (question 3) ne le couvre pas : la question
    est reposee, et d'ici la plus rien n'est compte. L'envoi porte la version
    3 ; le service situe toujours (pays, region) les envois 2 et 3."""
    assert partage.QUESTION == 4
    _accord(True, question=3)
    assert partage.a_demander() and not compteur.autorise()
    compteur.page("boutique")
    assert not compteur._attente
    _accord(True)
    assert compteur.autorise() and not partage.a_demander()
    assert compteur.corps([])["v"] == 3
    assert "sante" not in compteur.corps([])
    from orion.ui.widgets import dialogues
    import inspect
    texte = inspect.getsource(dialogues.DialoguePartage)
    assert "le pays et la region" in texte and "jamais la ville" in texte
    assert "bilan de fluidite" in texte and "jamais un chemin" in texte
    from orion import aide
    from orion.ui.views import settings_view
    assert "bilan de fluidite" in inspect.getsource(aide) and "bilan de fluidite" in inspect.getsource(settings_view)


def test_bilan_de_fluidite_ne_porte_que_des_nombres_et_des_fonctions_d_orion(envois, monkeypatch):
    """Les causes sont des noms de fonctions d'ORION sans numero de ligne ni
    chemin ; ce qui est hors d'ORION (Qt) n'est pas nomme. Le bilan part avec
    le dernier envoi, meme quand rien d'autre n'attend."""
    from orion.core import fluidite
    assert fluidite.cause("boutique_view._rendre:2046 < main_window._boutique_actualisee:1590") \
        == "boutique_view._rendre < main_window._boutique_actualisee"
    assert fluidite.cause("[QtWidgets.pyd:exec] < free_view.__init__:111") == "free_view.__init__"
    assert fluidite.cause("a.b:1 < a.c:2 < a.d:3") == "a.b < a.d"
    assert fluidite.cause("(pile indisponible)") == ""
    assert fluidite.cause("[QtCore.pyd:exec]") == ""

    class Faux:
        arrets = [(0.43, "boutique_view._rendre:2046 < main_window._boutique_actualisee:1590"),
                  (0.25, "boutique_view._rendre:2050 < main_window._boutique_actualisee:1590"),
                  (0.69, "free_view.__init__:111"), (0.21, "(pile indisponible)")]
    monkeypatch.setattr(fluidite, "_vigie", Faux())
    fluidite.noter_demarrage(1834.6)
    b = fluidite.bilan_envoi()
    assert b["arrets"] == 4 and b["duree_ms"] == 1580 and b["demarrage_ms"] == 1835
    assert isinstance(b["erreurs"], int)
    assert b["causes"] == [
        {"pile": "boutique_view._rendre < main_window._boutique_actualisee", "n": 2, "ms": 680},
        {"pile": "free_view.__init__", "n": 1, "ms": 690}]
    assert all(c["pile"].replace(" < ", "").replace(".", "").replace("_", "").isalnum() for c in b["causes"])
    _accord(True)
    compteur.fermer()
    assert compteur.attendre(2.0) and envois, "le bilan seul suffit a un envoi"
    url, corps = envois[-1]
    assert corps["v"] == 3 and corps["sante"] == b and corps["evenements"] == []
    # sans vigie : pas de bilan, et un dernier envoi vide ne part pas
    monkeypatch.setattr(fluidite, "_vigie", None)
    assert compteur.bilan_session() is None
    n = len(envois)
    compteur.fermer()
    assert compteur.attendre(2.0) and len(envois) == n
