"""Guide « a faire dans le jeu » : jeux qu'ORION ne peut pas regler."""
import sys
sys.path.insert(0, "tests")

from orion.core.models import Game
from orion.optimizer import guide


def _reglages(**plus):
    s = {"window_mode": "fullscreen", "resolution_w": 2560, "resolution_h": 1440,
         "refresh": 165, "quality": 2, "upscaler": "dlss_quality", "fps_cap": 120,
         "vsync": False, "fx_motion_blur": False, "ray_tracing": "off"}
    s.update(plus)
    return s


def test_lignes_simples_et_completes():
    l = {x.nom: x for x in guide.lignes(_reglages())}
    assert l["Resolution"].valeur == "2560 x 1440"
    assert l["Frequence"].valeur == "165 Hz"
    assert l["Qualite graphique"].valeur == "Haute"
    assert l["DLSS"].valeur == "Qualite"
    assert l["Limite d'images par seconde"].valeur == "120"
    assert not l["Flou de mouvement"].essentiel
    assert all(x.aide for x in l.values())


def test_sans_super_resolution_ni_limite():
    l = {x.nom: x.valeur for x in guide.lignes(_reglages(upscaler="off", fps_cap=0))}
    assert l["DLSS, FSR ou XeSS"] == "Desactive"
    assert l["Limite d'images par seconde"] == "Aucune limite"


def test_texte_a_copier():
    t = guide.texte("Mon Jeu", guide.lignes(_reglages()))
    assert t.startswith("Reglages a faire dans Mon Jeu")
    assert "1. Lancez le jeu." in t and "- Resolution : 2560 x 1440" in t


def test_jeu_non_reglable_recoit_un_guide(tmp_path):
    import test_reglages_recommande as T
    from orion.optimizer.engine import Optimizer
    hw, ecran = T._hw()
    jeu = Game(title="Jeu maison", source="dossier", install_dir=str(tmp_path))
    plan = Optimizer().build_plan(jeu, "recommande", hw, ecran)
    assert not plan.tunable and plan.guide
    assert any(x.nom == "Qualite graphique" for x in plan.guide)


def test_fenetre_du_guide(qapp=None):
    from PySide6.QtWidgets import QApplication
    app = QApplication.instance() or QApplication([])
    from orion.ui.widgets.dialogues import DialogueGuide
    d = DialogueGuide("Mon Jeu", guide.lignes(_reglages()))
    assert len(d._cases) == 9 and "0 sur 9" in d.avancement.text()
    for c in d._cases:
        c.setChecked(True)
    assert "Tout est fait" in d.avancement.text()
    d._copier()
    assert "Mon Jeu" in app.clipboard().text()


def test_deux_propositions_images_ou_beaute():
    import test_reglages_recommande as T
    from orion.optimizer.recommande import choisir_niveau, recommander
    hw, ecran = T._hw()
    jeu = Game(title="Jeu", source="dossier")
    r = recommander(jeu, hw, ecran, ["upscaler"], runs={}, exig=T._exig(30), refresh=165)
    assert r.niveau_conseille == "basse" and r.niveau_beau == "haute"
    assert r.options["haute"].fps[0] >= 60 * 0.92          # belle, mais fluide
    choisir_niveau(jeu, "haute")
    r = recommander(jeu, hw, ecran, ["upscaler"], runs={}, exig=T._exig(30), refresh=165)
    assert r.niveau == "haute" and r.palier == 60
    # ecran 60 Hz : le PC tient tout, une seule proposition
    r = recommander(Game(title="Jeu", source="dossier"), hw, ecran, ["upscaler"], runs={},
                    exig=T._exig(30), refresh=60)
    assert r.niveau_beau == r.niveau_conseille


def test_pas_de_super_resolution_inventee(tmp_path, monkeypatch):
    """15 octobre : Rocket League (sans DLSS) recevait « Ultra + DLSS Qualite ».
    Sans recette ni fiche Steam qui cite une mise a l'echelle, le guide n'en
    propose pas ; des que la fiche en cite une, il la propose."""
    import test_reglages_recommande as T
    from orion.optimizer import recommande
    from orion.optimizer.engine import Optimizer
    from orion.puissance import exigences as X
    hw, ecran = T._hw()
    jeu = Game(title="Jeu maison", source="steam", source_id="252950", install_dir=str(tmp_path))
    monkeypatch.setattr(X, "en_cache", lambda appid: None)
    Optimizer().build_plan(jeu, "recommande", hw, ecran)
    assert "upscaler" not in (recommande.capacites_connues(jeu) or [])
    c = X.lire_config("Carte graphique : RTX 2060. Notes supplémentaires : 1080p/60 fps avec DLSS en mode Qualité.")
    assert c.mise_a_l_echelle
    monkeypatch.setattr(X, "en_cache", lambda appid: X.Exigences(appid="252950", recommandee=c))
    Optimizer().build_plan(jeu, "recommande", hw, ecran)
    assert "upscaler" in (recommande.capacites_connues(jeu) or [])
    assert not X.lire_config("Carte graphique : GTX 660. Notes : 1080p 60 fps").mise_a_l_echelle
