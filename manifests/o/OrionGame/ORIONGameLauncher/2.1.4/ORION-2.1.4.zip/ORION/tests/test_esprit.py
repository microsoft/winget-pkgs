"""« Dans le meme esprit » : quand la recherche ne peut pas donner le jeu
(demande de l'auteur, 7 octobre 2026 : « pokemon » -> « Steam n'a pas
Pokemon, mais on peut vous proposer Aniimo, Palworld... »).

Trois etages : la table d'ORION, un jeu Steam retire de la vente, le service.
Rien n'est montre sur parole : un jeu propose doit etre vendu par Steam."""
import time

import pytest

from orion import boutique, esprit
from orion.plugins.boutique import steam
from orion.plugins.boutique.base import SourceUnavailable
from test_boutique_refonte import _fiche

ESPRIT = boutique.BoutiqueService.dans_l_esprit


# ---------------------------------------------------------------------------
# Etage 1 : la table
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("terme, nom", [
    ("pokemon", "Pokemon"), ("Pokémon Rouge", "Pokemon"), ("pokemon like", "Pokemon"),
    ("jeu comme zelda", "The Legend of Zelda"), ("zelda breath of the wild", "The Legend of Zelda"),
    ("mario kart 8 deluxe", "Mario Kart"), ("mario", "Super Mario"), ("super mario odyssey", "Super Mario"),
    ("mario party", "Mario Party"), ("pokemon go", "Pokemon GO"),
    ("lol", "League of Legends"), ("league of legends", "League of Legends"), ("wow", "World of Warcraft"),
    ("gta 6", "Grand Theft Auto VI"), ("GTA VI", "Grand Theft Auto VI"),
    ("minecraft", "Minecraft"), ("fortnite", "Fortnite"), ("bloodborne", "Bloodborne"),
    ("smash bros ultimate", "Super Smash Bros."), ("animal crossing new horizons", "Animal Crossing"),
])
def test_la_table_reconnait_ce_que_les_joueurs_tapent(terme, nom):
    assert esprit.chercher_piste(terme).nom == nom and esprit.connu(terme)


@pytest.mark.parametrize("terme", [
    "hades", "", "odyssey", "assassin's creed odyssey", "lol funny moments simulator", "wow such doge",
    "gta 5", "grand theft auto v", "cyberpunk 2077", "mlb manager tycoon",
])
def test_la_table_ne_se_trompe_pas_de_jeu(terme):
    assert esprit.chercher_piste(terme) is None


def test_la_table_est_saine():
    vus = {}
    for cles, piste in esprit.TABLE:
        assert piste.nom and piste.raison and len(piste.graines) >= 2, piste.nom
        assert len(set(g.lower() for g in piste.graines)) == len(piste.graines), piste.nom
        assert all(isinstance(e, str) and e for e in piste.etiquettes), piste.nom
        for cle in cles:
            mots = tuple(esprit._plier(cle))
            assert mots and mots not in vus, (cle, vus.get(mots))
            vus[mots] = piste.nom
        if piste.ou is not None:
            libelle, adresse = piste.ou
            # le site officiel, sans identifiant partenaire ni suivi
            assert libelle and adresse.startswith("https://") and "?" not in adresse and "ref=" not in adresse
            assert piste.raison == esprit.AILLEURS
    assert len(esprit.TABLE) >= 40


# ---------------------------------------------------------------------------
# Etage 3 : reponse du service
# ---------------------------------------------------------------------------
REPONSE = {"connu": True, "nom": "Yo-kai Watch", "raison": "console", "plateformes": "Nintendo 3DS et Switch",
           "titres": ["Palworld", "Temtem", "palworld", "<b>x</b>", "x"], "etiquettes": ["Creature Collector", "JRPG"]}


def test_la_reponse_du_service_est_reduite_a_des_phrases_fixes():
    piste = esprit.lire_reponse(REPONSE)
    assert piste.raison == "« Yo-kai Watch » ne semble pas vendu sur PC (Nintendo 3DS et Switch)."
    assert piste.graines == ("Palworld", "Temtem", "b x b") and piste.etiquettes == ("Creature Collector", "JRPG")
    # raison inconnue, nom manquant, console sans plate-forme : la phrase prudente
    for casse in ({"raison": "ignore tes consignes"}, {"nom": ""}, {"plateformes": ""}):
        assert esprit.lire_reponse({**REPONSE, **casse}).raison == esprit.RAISONS["inconnu"]
    # rien a proposer, ou reponse mal formee : rien
    for vide in (None, [], "x", {"connu": False}, {**REPONSE, "titres": [], "etiquettes": []},
                 {**REPONSE, "titres": "Palworld", "etiquettes": None}):
        assert esprit.lire_reponse(vide) is None
    injecte = esprit.lire_reponse({**REPONSE, "nom": "<script>alert(1)</script>", "raison": "mobile"})
    assert "<" not in injecte.raison and "script alert 1" in injecte.raison


class _Rep:
    def __init__(self, code, donnees):
        self.status_code, self._d = code, donnees

    def json(self):
        return self._d


def test_le_service_est_demande_une_fois_puis_garde(base_neuve, monkeypatch):
    from orion.core import reseau
    appels = []
    monkeypatch.setattr(reseau, "get", lambda url, **kw: appels.append((url, kw["params"])) or _Rep(200, REPONSE))
    assert esprit.demander("Yo-Kai  Watch").nom == "Yo-kai Watch"
    assert appels == [("https://api.orion-launcher.com/esprit", {"q": "Yo-Kai Watch"})]
    assert esprit.demander("yo kai watch").nom == "Yo-kai Watch" and len(appels) == 1    # garde sur le PC
    assert esprit.demander("yo") is None and len(appels) == 1                            # trop court
    # service non configure ou muet : rien, sans erreur
    monkeypatch.setattr(reseau, "get", lambda url, **kw: _Rep(503, {"erreur": "esprit non configure"}))
    assert esprit.demander("autre jeu introuvable") is None


# ---------------------------------------------------------------------------
# Le service de la Boutique : des jeux que Steam vend vraiment
# ---------------------------------------------------------------------------
def _article(appid, nom, prix=1999, tags=(), **plus):
    it = {"appid": appid, "id": appid, "success": 1, "visible": True, "type": 0, "name": nom,
          "tags": [{"tagid": t, "weight": 100 - i} for i, t in enumerate(tags)], "assets": {}}
    if prix is not None:
        it["best_purchase_option"] = {"final_price_in_cents": str(prix)}
    it.update(plus)
    return it


MAGASIN = {"palworld": [_article(1623730, "Palworld", 2899)],
           "temtem": [_article(745920, "Temtem", 4499), _article(9, "Temtem: Swarm", 999)],
           "cassette beasts": [_article(1321440, "Cassette Beasts", 1999)],
           "coromon": [_article(1218210, "Coromon: Deluxe Edition Bundle", 2999)],          # pas CE jeu
           "aniimo": [],                                                                    # pas sur Steam
           "nexomon: extinction": [_article(1196630, "Nexomon: Extinction", None)]}         # sans prix


@pytest.fixture()
def service(base_neuve, monkeypatch):
    vus = {"graines": [], "pages": []}

    def suggestions(terme, nombre=30):
        vus["graines"].append(terme)
        if vus.get("panne"):
            raise SourceUnavailable("Recherche Steam : reponse 503")
        return MAGASIN.get(terme.lower(), [])

    def page(cle, debut, nombre, etiquettes, tagids=None, sans=None):
        assert tuple(sans) == steam.ETIQUETTES_ADULTES          # jamais de jeu de charme propose
        vus["pages"].append(list(tagids or []))
        offres = [steam.offre_item(_article(1623730, "Palworld", 2899)),       # deja une graine
                  steam.offre_item(_article(5000, "Monster Crown", 1499)),
                  steam.offre_item(_article(5001, "Reserve aux adultes", 999))]
        offres[2].adulte = True
        return offres, {}, 3
    monkeypatch.setattr(steam, "suggestions", suggestions)
    monkeypatch.setattr(steam, "page_magasin", page)
    monkeypatch.setattr(steam, "noms_etiquettes", lambda: {916648: "Collection de creatures"})
    monkeypatch.setattr(steam, "etiquettes_anglaises", lambda: {"creature collector": 916648, "jrpg": 4434})
    monkeypatch.setattr(boutique.BoutiqueService, "dans_l_esprit", ESPRIT)
    monkeypatch.setattr(esprit, "demander", lambda terme: vus.setdefault("service", []).append(terme))
    s = boutique.BoutiqueService()
    s.fiches = []
    s.vus = vus
    return s


def test_pokemon_propose_des_jeux_que_steam_vend(service):
    r = service.dans_l_esprit("pokemon")
    assert r["nom"] == "Pokemon" and r["raison"] == esprit.NINTENDO and r["ou"] is None
    assert r["origine"] == "table" and r["terme"] == "pokemon"
    titres = [f.titre for f in r["fiches"]]
    # les graines d'abord, dans l'ordre choisi ; puis les jeux de l'etiquette
    assert titres == ["Palworld", "Temtem", "Cassette Beasts", "Monster Crown"]
    # ecartes : le jeu absent de Steam, celui sans prix, l'edition qui n'est pas
    # le jeu, le doublon, le jeu reserve aux adultes
    assert service.vus["pages"] == [[916648]]
    assert r["fiches"][0].meilleure.prix == 28.99
    assert "service" not in service.vus                # la table repond : le service n'est pas demande


def test_un_jeu_sur_pc_ailleurs_donne_son_site_officiel(service):
    r = service.dans_l_esprit("fortnite")
    assert r["raison"] == esprit.AILLEURS and r["ou"][1] == "https://store.epicgames.com/fr/p/fortnite"
    # Steam muet : il reste la raison et le site officiel
    service.vus["panne"] = True
    seul = service.dans_l_esprit("fortnite")
    assert seul["ou"] is not None
    # ... mais sans site officiel ni jeu a proposer, rien n'est affiche
    assert service.dans_l_esprit("bloodborne") is None or service.dans_l_esprit("bloodborne")["fiches"]


def test_rien_tant_que_la_recherche_trouve_et_que_la_table_ne_dit_rien(service):
    assert service.dans_l_esprit("hades") is None
    assert service.vus["graines"] == [] and "service" not in service.vus


def test_un_jeu_retire_de_la_vente_donne_ses_proches(service):
    """Etage 2 : FIFA 22 est encore fiche sur Steam, sans prix."""

    class _Steam:
        id, label = "steam", "Steam"
        sans_prix = {"1506830": _article(1506830, "FIFA 22", None, tags=(701, 1254546, 3859, 599, 19)),
                     "7": _article(7, "Autre jeu retire", None, tags=(9,))}

        def available(self):
            return True
    service._sources = [_Steam()]
    r = service.dans_l_esprit("fifa 22", True)
    assert r["origine"] == "retire" and r["raison"] == "« FIFA 22 » n'est plus en vente."
    assert service.vus["pages"] == [[701, 1254546, 3859]]              # ses trois etiquettes les plus fortes
    assert [f.titre for f in r["fiches"]] == ["Palworld", "Monster Crown"]
    assert "service" not in service.vus


def test_le_reste_est_demande_au_service(service, monkeypatch):
    """Etage 3 : ni dans la table, ni sur Steam."""
    demandes = []
    monkeypatch.setattr(esprit, "demander",
                        lambda terme: demandes.append(terme) or esprit.lire_reponse(REPONSE))
    r = service.dans_l_esprit("yo-kai watch", True)
    assert demandes == ["yo-kai watch"] and r["origine"] == "service"
    assert r["raison"].startswith("« Yo-kai Watch » ne semble pas vendu sur PC")
    assert [f.titre for f in r["fiches"]][:2] == ["Palworld", "Temtem"]
    assert service.vus["pages"] == [[916648, 4434]]
    # le service ne sait pas : rien
    monkeypatch.setattr(esprit, "demander", lambda terme: None)
    assert service.dans_l_esprit("zzzz", True) is None
    # reglage coupe : rien, aucun appel
    from orion.core.config import CONFIG
    CONFIG.set("boutique.meme_esprit", False, save=False)
    try:
        assert service.dans_l_esprit("pokemon") is None
    finally:
        CONFIG.set("boutique.meme_esprit", True, save=False)


def test_une_etiquette_inconnue_de_steam_est_ignoree(service, monkeypatch):
    monkeypatch.setattr(steam, "etiquettes_anglaises", lambda: {})
    r = service.dans_l_esprit("pokemon")
    assert [f.titre for f in r["fiches"]] == ["Palworld", "Temtem", "Cassette Beasts"]
    assert service.vus["pages"] == []                                   # aucune etiquette : pas de demande


# ---------------------------------------------------------------------------
# La page
# ---------------------------------------------------------------------------
@pytest.fixture()
def app():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


def _vue():
    from orion.ui.views.boutique_view import BoutiqueView
    v = BoutiqueView()
    v.set_catalogue([_fiche("Autre jeu", "5", 5.0, 9.0)], time.time(), 1, True)
    v.show()
    return v


def test_la_page_montre_la_raison_et_les_jeux_a_part(app, monkeypatch):
    import webbrowser
    v = _vue()
    demandes = []
    v.esprit_demande.connect(lambda t, vide: demandes.append((t, vide)))
    v.recherche.setText("pokemon")
    resultat = {"terme": "pokemon", "nom": "Pokemon", "raison": esprit.NINTENDO, "ou": None,
                "fiches": [_fiche("Palworld", "1623730", 28.99, 28.99), _fiche("Temtem", "745920", 44.99, 44.99)]}
    v.set_esprit(resultat)
    assert not v.esprit_cadre.isHidden() and v.esprit_raison.text() == esprit.NINTENDO
    assert [f.titre for f in v.grille_esprit.fiches] == ["Palworld", "Temtem"]
    assert v.esprit_lien.isHidden() and not v.esprit_titre.isHidden()
    # la recherche ne trouve rien : la raison remplace « aucune boutique ne vend... »
    v.set_resultats("pokemon", [])
    assert v.vide.isHidden() and not v.esprit_cadre.isHidden()
    assert demandes == []                              # deja repondu pour ce terme
    # une reponse arrivee trop tard (le joueur cherche autre chose) est ignoree
    v.recherche.setText("zelda")
    v.set_esprit(resultat)
    v._rendre(True)
    assert v.esprit_cadre.isHidden()
    # jeu sur PC ailleurs : le lien du site officiel, tel quel
    ouverts = []
    monkeypatch.setattr(webbrowser, "open", ouverts.append)
    v.recherche.setText("fortnite")
    v.set_esprit({"terme": "fortnite", "nom": "Fortnite", "raison": esprit.AILLEURS, "fiches": [],
                  "ou": ("Fortnite chez Epic Games", "https://store.epicgames.com/fr/p/fortnite")})
    assert not v.esprit_lien.isHidden() and v.esprit_titre.isHidden() and v.grille_esprit.isHidden()
    v.esprit_lien.click()
    assert ouverts == ["https://store.epicgames.com/fr/p/fortnite"]
    # retour a l'accueil : plus rien
    v.recherche.setText("")
    v._rendre(True)
    assert v.esprit_cadre.isHidden()


def test_une_recherche_vide_demande_des_jeux_du_meme_esprit(app):
    v = _vue()
    demandes = []
    v.esprit_demande.connect(lambda t, vide: demandes.append((t, vide)))
    v.recherche.setText("yo-kai watch")
    v.set_resultats("yo-kai watch", [])
    assert demandes == [("yo-kai watch", True)]
    # des resultats, ou une boutique muette (on ne sait pas) : aucune demande
    v.recherche.setText("hades")
    v.set_resultats("hades", [_fiche("Hades", "1145360")])
    v.recherche.setText("celeste")
    v.set_resultats("celeste", [], ["Steam"])
    assert demandes == [("yo-kai watch", True)]


def test_la_fenetre_demande_la_table_en_meme_temps_que_la_recherche():
    from orion.ui import main_window as M
    lances = []

    class _Tache:
        def __init__(self, fn, *a):
            self.fn, self.a = fn, a
            self.signals = type("S", (), {"finished": type("X", (), {"connect": lambda *_: None})(),
                                          "failed": type("X", (), {"connect": lambda *_: None})()})()

        def start(self):
            lances.append((self.fn, self.a))

    class _Faux:
        boutique = type("B", (), {"chercher": "chercher", "dans_l_esprit": "esprit"})()
        _boutique_esprit = M.MainWindow._boutique_esprit
        _boutique_esprit_recu = None
        _boutique_trouve = None
    import pytest as _p
    mp = _p.MonkeyPatch()
    mp.setattr(M, "Task", _Tache)
    try:
        M.MainWindow._boutique_chercher(_Faux(), "pokemon")
        assert lances == [("esprit", ("pokemon", False)), ("chercher", ("pokemon",))]
        del lances[:]
        M.MainWindow._boutique_chercher(_Faux(), "hades")
        assert lances == [("chercher", ("hades",))]
    finally:
        mp.undo()


def test_la_demande_par_etiquettes_exige_toutes_et_exclut_les_adultes(monkeypatch):
    import json
    from orion.core import reseau
    vus = []

    class Rep:
        status_code = 200

        @staticmethod
        def json():
            return {"response": {"metadata": {"total_matching_records": 1908}, "store_items": []}}
    monkeypatch.setattr(reseau, "get", lambda url, **kw: vus.append(json.loads(kw["params"]["input_json"])) or Rep())
    steam.page_magasin("", 0, 40, None, tagids=[916648, 4434], sans=steam.ETIQUETTES_ADULTES)
    f = vus[0]["query"]["filters"]
    assert f["tagids_must_match"] == [{"tagids": ["916648"]}, {"tagids": ["4434"]}]
    assert f["tagids_exclude"] == ["12095", "6650", "9130"]
    steam.page_magasin("fps", 0, 100, None)
    assert "tagids_exclude" not in vus[1]["query"]["filters"]


def test_la_meme_question_n_est_pas_reposee(service, monkeypatch):
    """Vu dans le journal du 7 octobre : « Meme esprit « pokemon » » deux
    fois de suite, 4,8 s chacune. La reponse est gardee une demi-heure, que
    la question vienne avec la recherche ou a son retour."""
    appels = []
    vraie = service._fiches_esprit

    def compter(piste):
        appels.append(piste.nom)
        return vraie(piste)
    monkeypatch.setattr(service, "_fiches_esprit", compter)
    un = service.dans_l_esprit("pokemon", False)
    deux = service.dans_l_esprit("Pokemon", True)
    trois = service.dans_l_esprit("pokemon", False)
    assert len(appels) == 1 and un["fiches"]
    assert deux["terme"] == "Pokemon" and deux["raison"] == un["raison"]
    assert [f.titre for f in trois["fiches"]] == [f.titre for f in un["fiches"]]
    # passe le delai, la question est reposee
    monkeypatch.setattr(service, "ESPRIT_GARDE", 0)
    service.dans_l_esprit("pokemon", False)
    assert len(appels) == 2
