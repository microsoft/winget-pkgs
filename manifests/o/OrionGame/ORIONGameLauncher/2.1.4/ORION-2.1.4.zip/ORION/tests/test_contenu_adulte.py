"""Jeux reserves aux adultes : une seule regle, pour toutes les sources.

Ces tests ne verifient pas une boutique en particulier : ils verifient que
la regle est appliquee la ou toutes les sources se rejoignent, et qu'aucune
source ne peut etre branchee sans avoir declare comment elle signale ces
jeux."""
import pytest

from orion import contenu_adulte


# -- le detecteur commun ---------------------------------------------------
def test_descripteur_steam_3_seul():
    assert contenu_adulte.fiche_adulte({"content_descriptors": {"ids": [1, 3, 5]}})
    assert contenu_adulte.fiche_adulte({"content_descriptors": {"ids": ["3"]}})
    assert contenu_adulte.fiche_adulte({"content_descriptorids": [3]})
    # jeux grand public classes 18 ans (Cyberpunk 2077 : 1, 2, 5)
    assert not contenu_adulte.fiche_adulte({"content_descriptors": {"ids": [1, 2, 5]}})
    assert not contenu_adulte.fiche_adulte({"content_descriptors": {"ids": [4]}})
    for vide in ({}, None, {"content_descriptors": []},
                 {"content_descriptors": {"ids": ["x", None]}}):
        assert not contenu_adulte.fiche_adulte(vide)


@pytest.mark.parametrize("brut", [
    {"mature": True},                                         # IsThereAnyDeal
    {"tags": [{"name": "NSFW", "slug": "nsfw"},               # GOG (Being a DIK)
              {"name": "Sexual Content", "slug": "sexual-content"}]},
    {"tags": ["NSFW"], "genres": ["Nudity"]},                 # reparti sur deux listes
    {"tags": ["Hentai", "Casual"]},                           # etiquettes Steam
    {"genres": [{"description": "Adult Only"}]},
    {"isAdult": "true"},
    {"features": [{"name": "Réservé aux adultes"}]},
    {"content_descriptors": {"ids": [3]}},
    {"categories": [{"path": "x", "name": "Adults Only"}]},   # une boutique future
])
def test_produit_adulte_reconnu_quelle_que_soit_la_boutique(brut):
    assert contenu_adulte.produit_adulte(brut)


@pytest.mark.parametrize("brut", [
    {"mature": False},
    {"tags": [{"name": "Mature", "slug": "mature"}, {"name": "Nudity", "slug": "nudity"},
              {"name": "Sexual Content", "slug": "sexual-content"}]},   # Cyberpunk sur GOG
    {"tags": [{"name": "Mature", "slug": "mature"}, {"name": "Violent", "slug": "violent"},
              {"name": "Gore", "slug": "gore"}, {"name": "NSFW", "slug": "nsfw"}]},  # POSTAL 2 sur GOG
    {"genres": ["Action", "RPG"], "ratings": [{"ageRating": "18"}]},
    {"title": "Adult Swim Games Collection"},                  # le titre ne compte pas
    {},
])
def test_jeux_grand_public_18_ans_non_filtres(brut):
    assert not contenu_adulte.produit_adulte(brut)


def test_marquage_garde_en_base():
    contenu_adulte.marquer("987650001")
    assert contenu_adulte.est_marque("987650001")
    contenu_adulte.marquer("987650001", False)
    assert not contenu_adulte.est_marque("987650001")
    assert not contenu_adulte.est_marque("")


def test_jeu_adulte_par_extra_ou_par_fiche():
    class Jeu:
        def __init__(self, extra):
            self.extra = extra
    assert contenu_adulte.jeu_adulte(Jeu({contenu_adulte.CLE: True}))
    assert not contenu_adulte.jeu_adulte(Jeu({}))
    contenu_adulte.marquer("987650002")
    try:
        assert contenu_adulte.jeu_adulte(Jeu({"steam_appid": "987650002"}))
        assert contenu_adulte.jeu_adulte(Jeu({}), "987650002")
    finally:
        contenu_adulte.marquer("987650002", False)


# -- le contrat : aucune source sans declaration ---------------------------
def _sources():
    from orion.core.registry import discover
    from orion.plugins.boutique.base import SourceBoutique
    from orion.plugins.freebies.base import FreebieSource
    from orion.plugins.market.base import MarketProvider
    out = []
    for famille, base in (("boutique", SourceBoutique), ("freebies", FreebieSource),
                          ("market", MarketProvider)):
        for source in discover(base, "orion.plugins." + famille):
            out.append((famille, source))
    return out


def test_toutes_les_sources_sont_decouvertes():
    familles = {f for f, _ in _sources()}
    assert familles == {"boutique", "freebies", "market"}
    assert len(_sources()) >= 9


def test_chaque_source_declare_comment_elle_signale_les_jeux_adultes():
    """Une nouvelle boutique ou plateforme ne peut pas etre branchee sans
    avoir repondu a la question."""
    oublis = [f"{famille}/{type(s).__name__}" for famille, s in _sources()
              if len(str(getattr(s, "filtre_adulte", "") or "").strip()) < 15]
    assert not oublis, ("declaration `filtre_adulte` manquante : " + ", ".join(oublis))


# -- la decision centrale : Boutique ---------------------------------------
def test_boutique_ecarte_le_jeu_entier_des_qu_une_source_le_signale():
    from orion.boutique import fusionner
    from orion.contenu_adulte import visibles
    from orion.plugins.boutique.base import Offre
    offres = [
        Offre("Jeu normal", "Steam", 10.0, source="steam"),
        Offre("Jeu adulte", "Steam", 5.0, source="steam"),                # Steam ne dit rien
        Offre("Jeu adulte", "UneBoutiqueFuture", 4.0, source="futur", adulte=True),
    ]
    fiches = fusionner(offres)
    assert {f.titre for f in fiches} == {"Jeu normal", "Jeu adulte"}
    assert {f.titre for f in visibles(fiches)} == {"Jeu normal"}


def test_boutique_ecarte_un_jeu_d_apres_ses_etiquettes_steam(monkeypatch):
    """Aucune source n'a signale : la fiche Steam detaillee rattrape."""
    from orion import boutique
    from orion.contenu_adulte import visibles
    from orion.plugins.boutique.base import Offre
    fiche = boutique.Fiche("Jeu", [Offre("Jeu", "Steam", 5.0, source="steam",
                                         steam_appid="424242")])
    monkeypatch.setattr(boutique.MEMO, "get", lambda appid: {"tags": ["Casual", "Hentai"]})
    assert fiche.adulte and visibles([fiche]) == []
    monkeypatch.setattr(boutique.MEMO, "get", lambda appid: {"adulte": True})
    assert fiche.adulte
    monkeypatch.setattr(boutique.MEMO, "get", lambda appid: {"tags": ["Mature", "Nudity"]})
    assert not fiche.adulte


def test_chaque_boutique_transmet_le_signal():
    from orion.plugins.boutique import gog, steam
    adulte = {"title": "Jeu adulte", "price": {"final": "9.99", "base": "9.99"},
              "tags": [{"name": "NSFW", "slug": "nsfw"}, {"name": "Nudity", "slug": "nudity"}]}
    normal = {"title": "Cyberpunk 2077", "price": {"final": "29.99", "base": "59.99"},
              "tags": [{"name": "Mature", "slug": "mature"}]}
    assert [(o.titre, o.adulte) for o in gog._offres([adulte, normal])] == [
        ("Jeu adulte", True), ("Cyberpunk 2077", False)]
    assert steam.lire_item({"name": "X", "content_descriptorids": [3]})["adulte"]
    assert steam.lire_item({"name": "X", "tags": [{"tagid": 9, "weight": 5}]},
                           {9: "Hentai"})["adulte"]
    assert not steam.lire_item({"name": "X", "content_descriptorids": [1, 2, 5]})["adulte"]


def test_itad_signale_et_demande_sans_les_jeux_adultes(monkeypatch):
    from orion.plugins.boutique import itad
    monkeypatch.setattr(itad, "_pays", lambda: "FR")
    vus = []

    def faux(methode, chemin, params=None, *_a, **_k):
        vus.append(params)
        return {"list": [
            {"id": "a", "title": "Jeu normal", "type": "game", "deal": {}},
            {"id": "b", "title": "Jeu adulte", "type": "game", "mature": True, "deal": {}},
        ]}
    monkeypatch.setattr(itad, "_demander", faux)
    offres = itad.ITADBoutique().vitrine()
    assert {o.titre for o in contenu_adulte.visibles(offres)} == {"Jeu normal"}
    assert all(p.get("mature") == "false" for p in vus)


# -- la decision centrale : jeux gratuits ----------------------------------
def test_jeux_gratuits_adultes_jamais_listes():
    from orion.freebies import FreebiesService
    from orion.plugins.freebies.base import Freebie
    magasin = FreebiesService.__new__(FreebiesService)
    magasin.items = {
        "a": Freebie(key="a", title="Jeu offert"),
        "b": Freebie(key="b", title="Jeu adulte offert", adulte=True),
    }
    assert [fb.title for fb in magasin.all()] == ["Jeu offert"]


# -- la decision centrale : fiche d'un jeu ---------------------------------
def test_fiche_d_un_jeu_sans_captures_quel_que_soit_le_fournisseur():
    from orion.core.models import Game
    from orion.market import MarketService
    from orion.plugins.market.base import MarketInfo
    jeu = Game(title="Jeu", source="gog")
    info = MarketInfo(game_uid=jeu.uid, title="Jeu")
    info.screenshots = [{"thumb": "t", "full": "f", "local": ""}]
    info.adulte = True                      # signale par n'importe quel fournisseur
    MarketService._decider_adulte(jeu, info)
    assert info.screenshots == [] and info.captures_note == contenu_adulte.NOTE
    assert contenu_adulte.jeu_adulte(jeu)   # le lecteur video le saura aussi

    sain = Game(title="Autre", source="gog")
    sain.extra[contenu_adulte.CLE] = True   # ancien marquage errone
    info2 = MarketInfo(game_uid=sain.uid, title="Autre")
    info2.sources.append("steam_store")
    MarketService._decider_adulte(sain, info2)
    assert not contenu_adulte.jeu_adulte(sain)


def test_bandes_annonces_vides_pour_un_jeu_marque():
    from orion import videos
    contenu_adulte.marquer("987650003")
    try:
        assert videos.bandes_annonces("987650003") == []
    finally:
        contenu_adulte.marquer("987650003", False)


# -- le passage commun des fiches Steam ------------------------------------
def test_toute_fiche_steam_lue_marque_le_jeu():
    """Le module qui demande la fiche n'a rien a faire : le passage commun
    retient le marquage, et le leve si Steam change d'avis."""
    from orion.core import steam_limite
    appid = "987650010"
    try:
        steam_limite.fiche({appid: {"success": True, "data": {
            "steam_appid": int(appid), "content_descriptors": {"ids": [1, 3]}}}}, appid)
        assert contenu_adulte.est_marque(appid)
        # une fiche reduite aux prix ne dit rien : le marquage reste
        steam_limite.fiche({appid: {"success": True, "data": {"price_overview": {}}}}, appid)
        assert contenu_adulte.est_marque(appid)
        steam_limite.fiche({appid: {"success": True, "data": {
            "content_descriptors": {"ids": [1, 5]}}}}, appid)
        assert not contenu_adulte.est_marque(appid)
    finally:
        contenu_adulte.marquer(appid, False)


def test_aucun_module_ne_lit_une_fiche_steam_hors_du_passage_commun():
    """Garde-fou : un module qui interrogerait `appdetails` sans passer par
    `steam_limite` echapperait au marquage (et aux fiches renumerotees)."""
    from pathlib import Path
    racine = Path(contenu_adulte.__file__).parent
    fautifs = []
    for fichier in racine.rglob("*.py"):
        texte = fichier.read_text(encoding="utf-8")
        if "api/appdetails" in texte and "steam_limite.fiche" not in texte:
            fautifs.append(str(fichier.relative_to(racine)))
    assert not fautifs, "fiche Steam lue sans steam_limite : " + ", ".join(fautifs)


def test_recherche_des_envies_filtree(monkeypatch):
    from orion import wishlist
    from orion.core import reseau

    class Rep:
        status_code = 200

        @staticmethod
        def json():
            return {"items": [
                {"id": 1, "name": "Jeu normal", "tiny_image": ""},
                {"id": 2, "name": "Jeu signale", "tiny_image": "", "tags": ["NSFW", "Hentai"]},
                {"id": 987650011, "name": "Jeu deja marque", "tiny_image": ""},
            ]}
    monkeypatch.setattr(reseau, "get", lambda *a, **k: Rep())
    contenu_adulte.marquer("987650011")
    try:
        classe = next(c for c in vars(wishlist).values()
                      if isinstance(c, type) and hasattr(c, "search"))
        assert [r["title"] for r in classe.search("jeu")] == ["Jeu normal"]
    finally:
        contenu_adulte.marquer("987650011", False)
