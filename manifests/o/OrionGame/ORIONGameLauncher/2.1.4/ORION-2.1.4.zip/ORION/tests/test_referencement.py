"""Referencement du site (11 octobre 2026, « mettre le paquet pour le
referencement ») : titres et descriptions a la longueur que les moteurs
affichent, une page par sortie, GTA 6 PC sans date inventee."""
import datetime as dt
import sys
from pathlib import Path

RACINE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RACINE / "service" / "site"))

import gen_evenements as ev  # noqa: E402
import gen_jeux  # noqa: E402
from gen_sorties import chemin_fiche  # noqa: E402


def test_ajuste_prend_la_plus_riche_qui_tient():
    assert gen_jeux.ajuste(["a" * 70, "b" * 50, "c" * 10], 60) == "b" * 50
    assert gen_jeux.ajuste(["a" * 70, "b" * 65], 60) == "b" * 65          # rien ne tient : la plus courte
    assert gen_jeux.TITRE_MAX == 60 and gen_jeux.DESC_MAX == 155


def test_adresse_des_sorties():
    assert chemin_fiche({"titre": "Warhammer 40,000: Dawn of War IV"}) == "/sorties/warhammer-40000-dawn-of-war-iv"
    assert chemin_fiche({"titre": "x", "page": "/call-of-duty-modern-warfare-4"}) == "/call-of-duty-modern-warfare-4"


def _texte(html):
    import re
    return re.sub(r"<[^>]+>", " ", html)


def test_page_sortie_sans_rien_inventer():
    auj = dt.date(2026, 10, 11)
    s = {"id": "x", "titre": "Jeu Test", "date": "2026-12-03", "plateformes": ["pc"], "studio": "Studio",
         "genre": "Stratégie", "steam": "123", "source": "https://exemple.org/annonce"}
    p = ev.page_sortie(s, [], auj, "")
    assert "Sortie le 3 décembre 2026 sur PC" in p and 'data-comparatif data-auto="1"' in p
    assert '"@type": "FAQPage"' in p and '"datePublished": "2026-12-03"' in p
    sans = ev.page_sortie({"id": "y", "titre": "Sans Date", "plateformes": ["ps5"], "fenetre": "2027"}, [], auj, "")
    assert "datePublished" not in sans and "Aucune version PC" in sans and "data-comparatif" not in sans


def test_gta_6_pc_ne_promet_rien():
    auj = dt.date(2026, 10, 11)
    p = ev.page_gta({"id": "gta-6", "titre": "Grand Theft Auto VI", "date": "2026-11-19", "plateformes": ["ps5", "xbox"],
                     "lien": "https://www.rockstargames.com/VI"}, auj, "")
    t = _texte(p)
    assert "aucune version PC n'est annoncée" in t
    assert "14 avril 2015" in t and "5 novembre 2019" in t                    # precedents dates
    assert "Pas annoncée" in t and "Pas publiée" in t


def test_black_friday_est_le_vendredi_apres_le_quatrieme_jeudi():
    assert ev.black_friday(2026) == dt.date(2026, 11, 27)
    assert ev.black_friday(2027) == dt.date(2027, 11, 26)


def test_gratuits_lit_le_service():
    p = ev.page_gratuits(dt.date(2026, 10, 11), "")
    assert "https://api.orion-launcher.com/gratuits" in p and "store.epicgames.com/fr/free-games" in p


def test_pied_de_page_mene_aux_pages_d_entree():
    for f in (RACINE / "service" / "site" / "gen_jeux.py", RACINE / "service" / "site" / "accueil" / "corps.html"):
        t = f.read_text(encoding="utf-8")
        assert all(x in t for x in ('href="/gratuits"', 'href="/gta-6-pc"', 'href="/black-friday"')), f.name


# ---- pages de jeux en anglais (11 octobre) ----

DONNEES_EN = {
    "1091500": {"n": "Cyberpunk 2077", "d": "9 Dec, 2020", "g": ["RPG"], "dev": "CD PROJEKT RED", "free": False,
                "img": "", "s": "",
                "min": "Minimum:\nRequires a 64-bit processor and operating system\nOS: 64-bit Windows 10\n"
                       "Processor: Core i7-6700 or Ryzen 5 1600\nMemory: 12 GB RAM\n"
                       "Graphics: GeForce GTX 1060 6GB or Radeon RX 580 8GB\nDirectX: Version 12\n"
                       "Storage: 70 GB available space\nAdditional Notes: SSD required. Attention: long text.",
                "rec": "Recommended:\nOS *: 64-bit Windows 10\nProcessor: Core i7-12700 or Ryzen 7 7800X3D\n"
                       "Memory: 16 GB RAM\nGraphics: GeForce RTX 2060 SUPER or Radeon RX 5700 XT\n"
                       "Storage: 70 GB available space"},
    "999": {"n": "Cyberpunk 2077", "d": "1 Jan, 2021", "g": ["RPG"], "dev": "x", "free": False, "img": "", "s": "",
            "min": "Minimum:\nOS: Windows 10\nGraphics: GTX 1060", "rec": ""},
    "5": {"n": "Some Editor", "d": "1 Jan, 2020", "g": ["Utilities"], "dev": "x", "free": True, "img": "", "s": "",
          "min": "Minimum:\nOS: Windows 10", "rec": ""},
}


def test_fiche_steam_anglaise_lue_dans_l_ordre():
    import gen_jeux_en as en
    lignes = dict(en.champs(DONNEES_EN["1091500"]["min"]))
    assert lignes["OS"] == "64-bit Windows 10" and lignes["Memory"] == "12 GB RAM"
    assert lignes["Storage"] == "70 GB" and lignes["Publisher's note"] == "SSD required."
    assert dict(en.champs(DONNEES_EN["1091500"]["rec"]))["OS"] == "64-bit Windows 10"      # « OS * »
    assert en.sortie_en("9 Dec, 2020") == "December 9, 2020" and en.sortie_en("Q4 2026") == "Q4 2026"


def test_pages_anglaises_sans_doublon_ni_logiciel():
    import gen_jeux_en as en
    jeux = en.choisir(DONNEES_EN)
    assert [j["appid"] for j in jeux] == ["1091500"]          # meme nom : le plus connu ; logiciel ecarte
    assert jeux[0]["estimable"]


def test_page_anglaise_jumelle_et_sans_lien_partenaire():
    import gen_jeux_en as en
    jeux = en.choisir(DONNEES_EN)
    p = en.page_jeu(jeux[0], "", jeux, dt.date(2026, 10, 7), set(), {"1091500": "/jeux/cyberpunk-2077"})
    assert '<html lang="en">' in p and 'hreflang="fr" href="https://orion-launcher.com/jeux/cyberpunk-2077"' in p
    assert 'hreflang="x-default" href="https://orion-launcher.com/en/games/cyberpunk-2077"' in p
    assert "sponsored" not in p and "instant-gaming" not in p and "kinguin" not in p and "loaded" not in p
    assert "October 7, 2026" in p and '"@type": "FAQPage"' in p
    import re
    titre = re.search(r"<title>(.*?)</title>", p).group(1)
    desc = re.search(r'name="description" content="([^"]*)"', p).group(1)
    assert len(titre) <= 60 and 70 <= len(desc) <= 155


# ---- flux RSS (11 octobre) ----

def test_flux_rss_valides_et_annonces(tmp_path):
    import xml.etree.ElementTree as ET
    import gen_rss
    (tmp_path / "sorties").mkdir()
    (tmp_path / "sorties" / "fable.html").write_text(
        '<html><head><title>Fable : date de sortie</title><meta name="description" content="Desc &amp; plus">'
        '</head><body></body></html>', encoding="utf-8")
    (tmp_path / "index.html").write_text('<html><head><link rel="canonical" href="https://orion-launcher.com/">'
                                         '</head><body></body></html>', encoding="utf-8")
    (tmp_path / "versions.html").write_text('<html><head><link rel="canonical" href="https://orion-launcher.com/versions">'
                                            '</head><body><main>x</main></body></html>', encoding="utf-8")
    log = tmp_path / "CHANGELOG.md"
    log.write_text("# Journal\n\n## 2.1.0 — Bibliothèque & Boutique\n11 octobre 2026 · nouveautés\n- a\n", encoding="utf-8")
    gen_rss.main(tmp_path, log)
    for nom in ("sorties", "versions"):
        racine = ET.parse(tmp_path / "rss" / f"{nom}.xml").getroot()          # XML bien forme
        assert racine.tag == "rss" and racine.find("channel/title") is not None
    v = ET.parse(tmp_path / "rss" / "versions.xml").getroot().find("channel/item")
    assert v.findtext("title") == "ORION 2.1.0 : Bibliothèque & Boutique"
    assert v.findtext("link") == "https://orion-launcher.com/versions/2.1.0"
    s = ET.parse(tmp_path / "rss" / "sorties.xml").getroot().find("channel/item")
    if s is not None:                       # la fiche existe pour une sortie de la liste
        assert s.findtext("link").startswith("https://orion-launcher.com/sorties/")
    accueil = (tmp_path / "index.html").read_text(encoding="utf-8")
    assert accueil.count('type="application/rss+xml"') == 3 and "api.orion-launcher.com/gratuits.rss" in accueil
    versions = (tmp_path / "versions.html").read_text(encoding="utf-8")
    assert 'class="petit rss"' in versions and versions.index("rss") < versions.index("</main>")
    gen_rss.main(tmp_path, log)                                         # deux passages : pas de doublon
    assert (tmp_path / "index.html").read_text(encoding="utf-8").count('type="application/rss+xml"') == 3
