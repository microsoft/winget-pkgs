"""Vitrine 2.0 : la rangee « Promos Gamesplanet » et la notification des jeux
gratuits du jour.

Regles verifiees ici : le partenaire n'est mis en avant que la ou il est
vraiment le moins cher ; une rangee trop courte n'est pas montree ; un jeu
gratuit n'est annonce qu'une fois, le jour ou l'offre commence, par une seule
notification quel que soit le nombre de jeux."""
from __future__ import annotations

import time

import pytest

from orion import suggestions as sugg


@pytest.fixture(scope="module")
def app():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


def _fiche(titre, appid, steam=59.99, gp=None, normal=59.99, steam_normal=None):
    from orion.boutique import Fiche
    from orion.plugins.boutique.base import Offre

    def remise(prix, n):
        return int(round(100 - prix * 100 / n)) if n > prix else 0
    sn = steam_normal or normal
    offres = [Offre(titre=titre, boutique="Steam", prix=steam, prix_normal=sn,
                    remise=remise(steam, sn), source="steam", steam_appid=appid,
                    url=f"https://store.steampowered.com/app/{appid}", type_article="game")]
    if gp is not None:
        offres.append(Offre(titre=titre, boutique="Gamesplanet", prix=gp, prix_normal=normal,
                            remise=remise(gp, normal), source="gamesplanet",
                            steam_appid=appid, drm="Cle Steam",
                            url=f"https://fr.gamesplanet.com/game/jeu-{appid}"))
    return Fiche(titre=titre, offres=offres)


# ---------------------------------------------------------------------------
# Promos du partenaire
# ---------------------------------------------------------------------------
def test_le_partenaire_seulement_la_ou_il_est_le_moins_cher():
    moins_cher = _fiche("Hogwarts Legacy", "1", steam=59.99, gp=5.72)
    steam_gagne = _fiche("Stray", "2", steam=8.0, gp=11.75, normal=27.99)
    petite_remise = _fiche("Recent", "3", steam=59.99, gp=53.99)        # -10 %
    sans_partenaire = _fiche("Ailleurs", "4", steam=9.99)
    assert sugg.promo_partenaire(moins_cher)
    assert not sugg.promo_partenaire(steam_gagne)       # Steam est moins cher : pas de mise en avant
    assert not sugg.promo_partenaire(petite_remise)
    assert not sugg.promo_partenaire(sans_partenaire)
    grosse = _fiche("Civilization VI", "5", steam=59.99, gp=5.77)
    moyenne = _fiche("Age of Wonders 4", "6", steam=49.99, gp=23.58, normal=49.99)
    choix = sugg.promos_partenaire([moyenne, steam_gagne, moins_cher, petite_remise, grosse])
    assert [f.titre for f in choix] == ["Hogwarts Legacy", "Civilization VI", "Age of Wonders 4"]
    assert sugg.promos_partenaire([moyenne, moins_cher, grosse], limite=2) == choix[:2]


def test_rangee_promos_gamesplanet_dans_la_boutique(app):
    from orion.ui.views.boutique_view import BoutiqueView
    from orion.ui.widgets.cartes_animees import RangeePromos
    v = BoutiqueView()
    section, rangee = v.sections["gamesplanet"]
    assert isinstance(rangee, RangeePromos)
    puce = next(b for b in v.groupe.buttons() if b.property("cle") == "gamesplanet")
    promos = [_fiche(f"Jeu {i}", str(100 + i), gp=10.0 + i) for i in range(5)]
    autres = [_fiche(f"Plein tarif {i}", str(200 + i)) for i in range(3)]
    # trois promos seulement : pas de rangee a moitie vide, ni de filtre
    v.set_catalogue(promos[:3] + autres, time.time(), 12, True)
    assert section.isHidden() and rangee.isHidden() and puce.isHidden()
    v.set_catalogue(promos + autres, time.time(), 12, True)
    assert not section.isHidden() and not rangee.isHidden() and not puce.isHidden()
    assert {f.titre for f in rangee.fiches} == {f.titre for f in promos}
    assert all(f.meilleure.boutique == "Gamesplanet" for f in rangee.fiches)
    # « Tout voir » : la grille filtree sur ces promos
    section.lien.click()
    assert puce.isChecked()
    assert {f.titre for f in v.visibles()} == {f.titre for f in promos}
    assert not rangee.grab().isNull()


def test_un_jeu_de_la_rangee_partenaire_n_est_pas_repete_plus_bas(app):
    from orion.ui.views.boutique_view import BoutiqueView
    v = BoutiqueView()
    partenaire = [_fiche(f"GP {i}", str(300 + i), gp=6.0 + i) for i in range(5)]
    steam = [_fiche(f"Steam {i}", str(400 + i), steam=10.0 + i) for i in range(8)]
    v.set_catalogue(partenaire + steam, time.time(), 12, True)
    en_haut = {f.titre for f in v.sections["gamesplanet"][1].fiches}
    promos = {f.titre for f in v.sections["promos"][1].fiches}
    assert en_haut == {f.titre for f in partenaire}
    assert promos == {f.titre for f in steam}


# ---------------------------------------------------------------------------
# Jeux gratuits du jour
# ---------------------------------------------------------------------------
def _gratuit(cle, titre, **k):
    from orion.plugins.freebies.base import Freebie
    k.setdefault("shop", "Epic Games Store")
    return Freebie(key=cle, title=titre, **k)


def test_une_seule_notification_pour_les_gratuits_du_jour():
    from orion.freebies import annonce_du_jour
    from orion.plugins.freebies.base import DEFINITIF, TEMPORAIRE
    t0 = time.mktime((2026, 10, 8, 17, 30, 0, 0, 0, -1))
    fin = time.mktime((2026, 10, 15, 17, 0, 0, 0, 0, -1))
    un = _gratuit("epic:1", "Control", starts_at=t0 - 1800, ends_at=fin)
    assert annonce_du_jour([un], t0) == (
        "Jeu gratuit du jour", "Offert sur Epic Games Store jusqu'au 15/10 : Control")
    # annonce une fois : le releve suivant ne dit plus rien
    assert un.annonce and annonce_du_jour([un], t0 + 3600) is None

    # plusieurs jeux le meme jour : une notification, pas une par jeu
    lot = [_gratuit(f"epic:{i}", titre, starts_at=t0 - 60, ends_at=fin)
           for i, titre in enumerate(("Alan Wake", "Celeste", "Hades", "Inside", "Limbo"))]
    titre, message = annonce_du_jour(lot, t0)
    assert titre == "Jeux gratuits du jour"
    assert message == "5 jeux gratuits aujourd'hui : Alan Wake, Celeste, Hades (+2)"
    assert all(fb.annonce for fb in lot)

    # week-end gratuit, et offre sans date de fin
    essai = _gratuit("steam:9", "Rust", shop="Steam", kind=TEMPORAIRE,
                     starts_at=t0 - 60, ends_at=fin)
    assert annonce_du_jour([essai], t0)[1] == "Jouable gratuitement sur Steam jusqu'au 15/10 : Rust"
    sans_fin = _gratuit("gog:3", "Ancien jeu", shop="GOG", starts_at=t0 - 60)
    assert annonce_du_jour([sans_fin], t0)[1] == "Offert en ce moment sur GOG : Ancien jeu"

    # jamais annonces : gratuit en permanence, deja commence depuis plus d'un
    # jour, termine, pour adultes, ecarte ou deja recupere par le joueur
    muets = [
        _gratuit("s:1", "Free to play", kind=DEFINITIF, starts_at=t0 - 60),
        _gratuit("e:2", "Avant-hier", starts_at=t0 - 2 * 86400, ends_at=fin),
        _gratuit("e:3", "Fini", starts_at=t0 - 3600, ends_at=t0 - 60),
        _gratuit("e:4", "Adulte", starts_at=t0 - 60, adulte=True),
        _gratuit("e:5", "Ecarte", starts_at=t0 - 60, dismissed=True),
        _gratuit("e:6", "Deja pris", starts_at=t0 - 60, claimed_at=t0 - 30),
    ]
    assert annonce_du_jour(muets, t0) is None
    assert all(fb.annonce for fb in muets)             # et ils ne le seront jamais


def test_offre_a_venir_annoncee_le_jour_ou_elle_commence():
    """Epic annonce son jeu de la semaine suivante : la notification part le
    jour ou il devient gratuit, pas a son arrivee dans la liste."""
    from orion.freebies import annonce_du_jour
    t0 = time.mktime((2026, 10, 8, 10, 0, 0, 0, 0, -1))
    futur = _gratuit("epic:7", "Jeu de jeudi prochain", starts_at=t0 + 7 * 86400,
                     ends_at=t0 + 14 * 86400)
    assert annonce_du_jour([futur], t0) is None and not futur.annonce
    assert annonce_du_jour([futur], t0 + 3 * 86400) is None and not futur.annonce
    titre, message = annonce_du_jour([futur], t0 + 7 * 86400 + 600)
    assert titre == "Jeu gratuit du jour" and message.endswith(": Jeu de jeudi prochain")
    assert annonce_du_jour([futur], t0 + 7 * 86400 + 7200) is None


def test_premier_releve_et_offres_connues_d_avant():
    from orion.freebies import annonce_du_jour
    from orion.plugins.freebies.base import Freebie
    t0 = time.time()
    # premier releve : toute la liste est nouvelle ; sans date de debut, on
    # ne peut pas dire qu'une offre est du jour
    inconnue = _gratuit("x:1", "Sans date")
    datee = _gratuit("x:2", "Du jour", starts_at=t0 - 600)
    assert annonce_du_jour([inconnue, datee], t0, premiere_fois=True)[1].endswith(": Du jour")
    assert inconnue.annonce
    # ensuite, une offre sans date qui apparait est annoncee a son arrivee
    arrivee = _gratuit("x:3", "Nouvelle")
    assert annonce_du_jour([arrivee], t0)[1].endswith(": Nouvelle")
    # liste enregistree par une version precedente : rien n'est annonce apres
    # coup, sauf ce qui n'a pas encore commence
    ancien = Freebie.from_dict({"key": "y:1", "title": "Deja la", "starts_at": t0 - 600})
    a_venir = Freebie.from_dict({"key": "y:2", "title": "Bientot", "starts_at": t0 + 3600})
    assert ancien.annonce and not a_venir.annonce
    assert annonce_du_jour([ancien, a_venir], t0) is None
    # et le choix est garde d'un lancement a l'autre
    assert Freebie.from_dict(arrivee.to_dict()).annonce


def test_le_releve_n_annonce_qu_une_fois_et_garde_la_trace(tmp_path, monkeypatch):
    from orion import freebies as F
    from orion.plugins.freebies.base import FreebieSource

    class Source(FreebieSource):
        id, label, filtre_adulte = "essai", "Essai", "aucun jeu adulte"
        offres: list = []

        def fetch(self):
            return [_gratuit(c, t, starts_at=d) for c, t, d in self.offres]

    service = F.FreebiesService()
    service.items.clear()
    monkeypatch.setattr(service, "enabled_sources", lambda: [Source()])
    monkeypatch.setattr(service, "_enrich", lambda merged, step: None)
    monkeypatch.setattr(service, "save", lambda: None)
    maintenant = time.time()
    Source.offres = [("essai:1", "Premier", maintenant - 600)]
    r = service.refresh(force=True)
    assert r["premiere"] and r["annonce"][1].endswith(": Premier")
    # meme liste au releve suivant : plus rien ; un nouveau jeu : lui seul
    assert service.refresh(force=True)["annonce"] is None
    Source.offres.append(("essai:2", "Second", maintenant - 60))
    r = service.refresh(force=True)
    assert not r["premiere"] and r["annonce"][1].endswith(": Second")


def test_textes_traduits(app):
    from orion import i18n
    try:
        assert i18n.charger("en")
        for texte, attendu in (
                ("Promos Gamesplanet", "Gamesplanet deals"),
                ("ECONOMIE", "SAVE"),
                ("Jeu gratuit du jour", "Free game of the day"),
                ("Jeux gratuits du jour", "Free games of the day"),
                ("Offert sur Epic Games Store jusqu'au 15/10 : Control",
                 "Free to keep on Epic Games Store until 15/10: Control"),
                ("Jouable gratuitement sur Steam jusqu'au 15/10 : Rust",
                 "Free to play on Steam until 15/10: Rust"),
                ("Offert en ce moment sur GOG : Ancien jeu",
                 "Free to keep right now on GOG: Ancien jeu"),
                ("5 jeux gratuits aujourd'hui : Alan Wake, Celeste, Hades (+2)",
                 "5 free games today: Alan Wake, Celeste, Hades (+2)")):
            assert i18n.traduire(texte) == attendu, texte
    finally:
        i18n._exact, i18n._modeles, i18n._mots = {}, [], {}
        i18n.traduire.cache_clear()


def test_les_gratuits_sans_drm_et_leur_prix_habituel():
    """2.1.2 : « Sans DRM » n'est pas une boutique (la notification disait « sur Sans
    DRM »), et le prix habituel s'ecrit comme les autres prix (il disait « 29.99 USD »)."""
    from orion.core.config import CONFIG
    from orion.freebies import annonce_du_jour
    t0 = time.mktime((2026, 10, 8, 17, 30, 0, 0, 0, -1))
    fin = time.mktime((2026, 10, 15, 17, 0, 0, 0, 0, -1))
    a = _gratuit("gp:1", "Best Plumber", shop="Sans DRM", starts_at=t0 - 60, worth=29.99, currency="USD")
    assert annonce_du_jour([a], t0) == ("Jeu gratuit du jour", "Offert en ce moment, sans DRM : Best Plumber")
    b = _gratuit("gp:2", "Leaper", shop="Sans DRM", starts_at=t0 - 60, ends_at=fin)
    assert annonce_du_jour([b], t0)[1] == "Offert sans DRM jusqu'au 15/10 : Leaper"
    c = _gratuit("gp:3", "Control", shop="Steam", starts_at=t0 - 60)
    assert annonce_du_jour([c], t0)[1] == "Offert en ce moment sur Steam : Control"
    avant = CONFIG.get("langue", "fr")
    try:
        CONFIG.set("langue", "fr", save=False)
        assert a.worth_label == "29,99 $" and a.price_before_label == "29,99 $"
        assert _gratuit("x", "y", worth=20.0, currency="EUR").worth_label == "20 €"
        CONFIG.set("langue", "en", save=False)
        assert a.worth_label == "$29.99"
    finally:
        CONFIG.set("langue", avant, save=False)


def test_les_nouvelles_phrases_des_gratuits_sont_traduites():
    import json
    from pathlib import Path
    en = json.loads((Path(__file__).resolve().parent.parent / "orion" / "langues" / "en.json").read_text(encoding="utf-8"))
    for k in ("Jouable gratuitement, sans DRM, jusqu'au {0} : {1}", "Offert sans DRM jusqu'au {0} : {1}",
              "Offert en ce moment, sans DRM : {0}"):
        assert k in en["modeles"] and "DRM-free" in en["modeles"][k]
