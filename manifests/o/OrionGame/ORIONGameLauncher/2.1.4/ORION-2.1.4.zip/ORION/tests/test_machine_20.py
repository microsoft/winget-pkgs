"""Page Ma machine (2.0) : lecture du PC dans le panneau, filtre par niveau,
jeux rattrapables, detail du jeu choisi, configuration a copier."""
from __future__ import annotations

import pytest

from orion.puissance import Candidat, lecture
from orion.puissance.estimation import Machine, estimer
from orion.puissance.exigences import Config, Exigences

PX_4K = 3840 * 2160


@pytest.fixture(scope="module")
def app():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


def _machine(**k) -> Machine:
    base = dict(gpu=26.0, gpu_nom="NVIDIA GeForce RTX 3060", cpu=59.0,
                cpu_nom="AMD Ryzen 5 5600", vram_go=12.0, ram_go=16.0, pixels=PX_4K,
                definition="3840x2160", hz=60, mise_a_l_echelle="DLSS")
    base.update(k)
    return Machine(**base)


EXIGENCES = {
    "1": Exigences("1", "Leger", Config(gpu=3.0, gpu_nom="GTX 750 TI", ram_go=4.0),
                   Config(gpu=5.0, gpu_nom="GTX 1050", cpu=30.0, cpu_nom="4460", ram_go=8.0)),
    "2": Exigences("2", "Moyen", Config(gpu=9.0, gpu_nom="GTX 970", ram_go=8.0),
                   Config(gpu=19.0, gpu_nom="RTX 2060", cpu=50.0, cpu_nom="8700", ram_go=16.0)),
    "3": Exigences("3", "Lourd", Config(gpu=24.0, gpu_nom="RTX 2070", ram_go=16.0),
                   Config(gpu=50.0, gpu_nom="RTX 4070", cpu=70.0, cpu_nom="12400",
                          ram_go=16.0, vram_go=12.0)),
}


@pytest.fixture
def panneau(app, monkeypatch):
    from orion.puissance import exigences
    from orion.ui.widgets.puissance_panel import PuissancePanel
    monkeypatch.setattr(exigences, "en_cache", lambda appid: EXIGENCES.get(str(appid)))
    m = _machine()
    resultats = []
    for appid, x in EXIGENCES.items():
        e = estimer(x.titre, x, m)
        trouvees = lecture.pistes(x.titre, x, m, actuel=e)
        if trouvees:
            e.piste, e.niveau_piste = trouvees[0].court, trouvees[0].niveau
        resultats.append((Candidat(titre=x.titre, appid=appid, uid=f"u{appid}",
                                   installe=appid == "1", possede=appid in ("1", "2")), e))
    p = PuissancePanel()
    p.resize(1200, 1000)
    p.set_machine(m)
    p.set_resultats(resultats)
    p._montrer("tous")
    yield p
    p.deleteLater()


def test_la_lecture_du_pc_est_dans_le_panneau(panneau):
    p = panneau
    _nom, valeur, verdict = p.lignes_composants["gpu"]
    assert "NVIDIA GeForce RTX 3060" in valeur.text() and "indice 26" in valeur.text()
    assert "du niveau de :" in valeur.text()
    assert "retient" in verdict.text() and "sur 3" in verdict.text()
    assert p.lignes_composants["ram"][1].text().startswith("16 Go")
    assert p.frein.text().startswith("Jeux estimes fluides en Haute : ")
    assert "Parmi vos jeux" in p.frein.text()
    assert "Ecran 3840x2160 a 60 Hz" in p.machine.text()


def test_filtre_par_niveau_au_clic_sur_une_pastille(panneau):
    p = panneau
    niveaux = {c.titre: e.niveau for c, e in p._resultats}
    cible = niveaux["Lourd"]
    p.compteurs[cible].click()
    assert p._niveau == cible and p.compteurs[cible].isChecked()
    assert set(p.titres_visibles()) == {t for t, n in niveaux.items() if n == cible}
    p.compteurs[cible].click()                     # second clic : tout revient
    assert p._niveau == "" and len(p.titres_visibles()) == 3
    assert not any(b.isChecked() for b in p.compteurs.values())


def test_les_jeux_rattrapables_ont_leur_filtre_et_leur_piste_dans_la_liste(panneau):
    from orion.ui.widgets.puissance_panel import COL_NIVEAU, LIMITE
    p = panneau
    avec = [c.titre for c, e in p._resultats if e.piste]
    assert avec, "le jeu de donnees doit contenir un jeu rattrapable"
    assert p.filtres["pistes"].text() == f"Rattrapables  {len(avec)}"
    p._montrer("pistes")
    assert sorted(p.titres_visibles()) == sorted(avec)
    a_cote = p.modele.index(0, COL_NIVEAU).data(LIMITE)
    assert a_cote.startswith("→ ") and ("avec DLSS" in a_cote or " en " in a_cote)
    assert "Sans rien acheter" in p.modele.index(0, COL_NIVEAU).data(
        __import__("PySide6.QtCore").QtCore.Qt.ItemDataRole.ToolTipRole)


def test_le_detail_explique_le_jeu_choisi(panneau):
    p = panneau
    assert p.detail_titre.text() == "Cliquez un jeu de la liste"
    rangee = p.titres_visibles().index("Lourd")
    p.choisir(rangee)
    assert p.detail_titre.text() == "Lourd"
    assert "Ce qui" in p.detail_resume.text()
    lignes = p.detail_lignes.text()
    assert "RTX 4070 (indice 50)" in lignes and "NVIDIA GeForce RTX 3060" in lignes
    assert "Face a la configuration recommandee du jeu" in lignes
    assert not p.detail_pistes.isHidden() or not p.detail_manque.isHidden()
    if not p.detail_manque.isHidden():
        texte = p.detail_manque.text()
        assert "Ce sont des reperes de puissance" in texte
        # 2.1.0 : des pieces neuves compatibles suivent les reperes
        assert ("pieces compatibles avec votre PC sont en dessous" in texte) \
            == (not p.detail_pieces.isHidden())
        if not p.detail_pieces.isHidden():
            assert "ldlc.com/recherche" in p.detail_pieces.text()
    # un jeu fluide : ni piste ni manque
    p.choisir(p.titres_visibles().index("Leger"))
    assert p.detail_titre.text() == "Leger"
    assert "depasse la configuration recommandee" in p.detail_resume.text()
    assert p.detail_pistes.isHidden() and p.detail_manque.isHidden()


def test_le_detail_suit_le_jeu_quand_la_liste_change(panneau):
    p = panneau
    p.choisir(p.titres_visibles().index("Lourd"))
    p.trier("nom")
    assert p.detail_titre.text() == "Lourd"
    rangees = [i.row() for i in p.table.selectionModel().selectedRows()]
    assert rangees == [p.titres_visibles().index("Lourd")]
    p._montrer("mes")                              # « Lourd » n'est pas a moi
    assert "Lourd" not in p.titres_visibles()
    assert p.detail_titre.text() == "Cliquez un jeu de la liste"
    assert p._choisi == ""


def test_double_clic_ouvre_la_fiche_de_mes_jeux(panneau):
    p = panneau
    ouverts = []
    p.ouvrir_jeu.connect(ouverts.append)
    p._double_clic(p.titres_visibles().index("Leger"))
    p._double_clic(99)
    assert ouverts == ["u1"]


def test_recherche_tolerante_dans_le_panneau(panneau):
    p = panneau
    p.recherche.setText("lour")
    assert p._frappe.isActive()                    # attend la fin de la frappe
    p._appliquer_filtre()
    assert p.titres_visibles() == ["Lourd"]
    p.recherche.setText("zzz")
    p._appliquer_filtre()
    assert p.titres_visibles() == [] and "Aucun jeu ne correspond" in p.vide.text()


# ---------------------------------------------------------------------------
# page : configuration a copier, pas de reconstruction inutile
# ---------------------------------------------------------------------------
def _hw():
    from orion.core.models import Display, DisplayMode, GPUInfo, HardwareInfo
    modes = [DisplayMode(1920, 1080, 60), DisplayMode(1920, 1080, 144)]
    return HardwareInfo(
        cpu_name="Intel(R) Core(TM) i9-9900K CPU @ 3.60GHz", cpu_cores=8, cpu_threads=16,
        ram_gb=31.9, os_name="Windows 11", os_build="26100",
        gpus=[GPUInfo(name="NVIDIA GeForce RTX 3080", vendor="nvidia", vram_mb=10240,
                      driver_version="32.0.15.6094")],
        displays=[Display(device="\\\\.\\DISPLAY1", name="Ecran", primary=True,
                          current=modes[0], native=modes[0], max_refresh_at_native=144,
                          modes=modes)],
        disks=[{"mount": "C:\\", "total_gb": 931, "free_gb": 120}], score=74)


def test_configuration_en_texte_sans_rien_de_personnel():
    from orion.ui.views.hardware_view import texte_configuration
    texte = texte_configuration(_hw())
    lignes = texte.split("\n")
    assert lignes[0] == "Configuration (lue par ORION)"
    assert "Processeur : Intel(R) Core(TM) i9-9900K CPU @ 3.60GHz (8 coeurs / 16 fils)" in lignes
    assert "Carte graphique : NVIDIA GeForce RTX 3080, 10 Go" in lignes
    assert "Memoire vive : 32 Go" in lignes
    assert "Ecran : Ecran, 1920x1080 a 60 Hz (jusqu'a 144 Hz)" in lignes
    assert "Systeme : Windows 11 (build 26100)" in lignes
    assert "Disque C: 120 Go libres sur 931 Go" in lignes
    assert "Indice de configuration ORION : 74/100" in lignes
    assert "DISPLAY1" not in texte and "Users" not in texte


def test_copier_ma_configuration_et_pas_de_reconstruction_inutile(app):
    from PySide6.QtWidgets import QApplication, QLabel
    from orion.ui.views.hardware_view import HardwareView, texte_configuration
    v = HardwareView()
    assert not v.b_copier.isEnabled()
    hw = _hw()
    v.set_hardware(hw)
    assert v.b_copier.isEnabled()
    v.b_copier.click()
    assert QApplication.clipboard().text() == texte_configuration(hw)
    assert v.b_copier.text() == "Copie !"
    valeurs = [w for w in v.specs_panel.findChildren(QLabel) if not w.signalsBlocked()]
    v.set_hardware(_hw())                          # meme materiel : memes libelles
    assert [w for w in v.specs_panel.findChildren(QLabel)
            if not w.signalsBlocked()] == valeurs
    autre = _hw()
    autre.ram_gb = 63.9
    v.set_hardware(autre)
    assert [w for w in v.specs_panel.findChildren(QLabel)
            if not w.signalsBlocked()] != valeurs
