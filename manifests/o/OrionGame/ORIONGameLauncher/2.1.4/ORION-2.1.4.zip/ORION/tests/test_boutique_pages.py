"""Boutique 2.0 : une barre toujours a l'ecran, dont la recherche, les
filtres et le tri agissent sur la page en cours (accueil, type de jeu, liste,
recherche) ; des pages au lieu d'un long defilement ; une grille paginee."""
import time

import pytest

from test_boutique_refonte import _fiche


@pytest.fixture()
def app():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


@pytest.fixture()
def memo():
    from orion.boutique import MEMO
    MEMO.vider()
    yield MEMO._donnees
    MEMO.vider()


def _vue(memo, fps=60, rpg=12, bibliotheque=()):
    """Un catalogue : `fps` jeux de tir (du moins connu au plus connu, prix et
    remises varies, quelques gratuits), `rpg` jeux de role, un MOBA."""
    from orion.ui.views.boutique_view import BoutiqueView
    fiches = []
    for i in range(fps):
        memo[str(1000 + i)] = {"tags": ["FPS", "Action"], "avis": 500 * (i + 1), "positifs": 60 + i % 40}
        gratuit = i % 10 == 0
        fiches.append(_fiche(f"Tir {i:02d}", str(1000 + i), prix=0.0 if gratuit else 2.0 + i,
                             normal=0.0 if gratuit else (2.0 + i) * (2 if i % 3 == 0 else 1)))
    for i in range(rpg):
        memo[str(3000 + i)] = {"tags": ["RPG"], "avis": 800 * (i + 1), "positifs": 80}
        fiches.append(_fiche(f"Role {i:02d}", str(3000 + i), prix=10.0 + i, normal=40.0))
    memo["2000"] = {"tags": ["MOBA"], "avis": 5}
    fiches.append(_fiche("Arene", "2000"))
    v = BoutiqueView()
    if bibliotheque:
        v.set_bibliotheque(list(bibliotheque))
    v.set_catalogue(fiches, time.time(), 12, True)
    return v


def _cocher(v, cle):
    b = next(b for b in v.groupe.buttons() if b.property("cle") == cle)
    b.click()
    return b


def _trier(v, cle):
    v.tri.setCurrentIndex(v.tri.findData(cle))


# ---------------------------------------------------------------------------
# La page d'un type : tout agit dessus
# ---------------------------------------------------------------------------
def test_page_d_un_type_filtres_tri_et_recherche_restent_dans_le_type(app, memo):
    v = _vue(memo)
    v.choisir_type("fps")
    tous = v.visibles()
    assert len(tous) == 60 and all(f.titre.startswith("Tir") for f in tous)
    assert v.tri_applique() == "populaires" and tous[0].titre == "Tir 59"
    assert "FPS" in v.fil.text() and not v.fil.isHidden()
    # le tri agit sur la page du type
    _trier(v, "prix")
    prix = [f.meilleure.prix for f in v.visibles()]
    assert prix == sorted(prix) and len(prix) == 60
    _trier(v, "prix_desc")
    assert [f.meilleure.prix for f in v.visibles()] == sorted(prix, reverse=True)
    _trier(v, "titre")
    assert [f.titre for f in v.visibles()][:2] == ["Tir 00", "Tir 01"]
    # les filtres aussi, sans sortir du type
    _cocher(v, "5")
    assert v.visibles() and all(0 < f.meilleure.prix < 5 and f.titre.startswith("Tir") for f in v.visibles())
    _cocher(v, "gratuit")
    assert len(v.visibles()) == 6 and all(f.gratuit for f in v.visibles())
    _cocher(v, "affaires")
    assert v.visibles() and all(f.remise >= 20 and not f.gratuit for f in v.visibles())
    assert v._genre == "fps" and "FPS" in v.fil.text() and "Meilleures affaires" in v.fil.text()
    # une recherche par nom dans le type
    _cocher(v, "tout")
    _trier(v, "auto")
    v.recherche.setText("tir 4")
    v._rendre(True)
    trouves = [f.titre for f in v.visibles()]
    assert trouves and all(t.startswith("Tir") for t in trouves) and trouves[0].startswith("Tir 4")
    assert v._genre == "fps"                         # la saisie ne fait pas quitter le type
    assert v.tri_applique() == "pertinence"
    _trier(v, "prix")                               # et le tri s'applique aux resultats
    prix = [f.meilleure.prix for f in v.visibles()]
    assert prix == sorted(prix)


def test_un_filtre_vide_s_efface_et_aucun_nombre_n_est_affiche(app, memo):
    """Les nombres de jeux ont ete retires (7 octobre) : une page n'a pas de
    fin, la suite du magasin vient a la demande."""
    v = _vue(memo)
    puces = {b.property("cle"): b for b in v.groupe.buttons()}
    # accueil : pas de filtre « Gratuits » (ils ont leur onglet), ni de filtre vide
    assert puces["gratuit"].isHidden() and puces["gamesplanet"].isHidden()
    assert not puces["affaires"].isHidden()
    v.choisir_type("fps")
    assert not puces["gratuit"].isHidden()
    assert puces["tout"].text() == "Tout"
    assert all(b.text() == str(b.property("libelle")) for b in v.groupe.buttons())
    assert not any(c.isdigit() for b in v.boutons_types.values() for c in b.text())
    assert v.resume.text() == "FPS"
    _cocher(v, "affaires")
    assert v.visibles() and all(f.remise >= 20 for f in v.visibles())
    v.choisir_type("moba")                          # un seul jeu, plein tarif reduit
    assert puces["gratuit"].isHidden()


def test_le_tri_au_hasard_ne_change_pas_a_chaque_clic(app, memo):
    v = _vue(memo)
    v.choisir_type("fps")
    _trier(v, "hasard")
    a = [f.titre for f in v.visibles()]
    assert a != sorted(a) and a == [f.titre for f in v.visibles()] and len(a) == 60


# ---------------------------------------------------------------------------
# Des pages, pas un long defilement
# ---------------------------------------------------------------------------
def test_la_grille_est_paginee(app, memo):
    from orion.ui.views.boutique_view import PAR_PAGE, Pagination
    v = _vue(memo, fps=95)
    v.choisir_type("fps")
    assert len(v.visibles()) == 95
    assert len(v.grille.fiches) == PAR_PAGE and v.pages.total == 3 and not v.pages.isHidden()
    premiere = [f.titre for f in v.grille.fiches]
    v.pages.choisie.emit(2)
    assert v._page == 2 and len(v.grille.fiches) == 95 - 2 * PAR_PAGE
    assert not set(premiere) & {f.titre for f in v.grille.fiches}
    _cocher(v, "gratuit")                           # un filtre repart de la premiere page
    # une seule page : plus de numeros, seulement « Plus de jeux »
    assert v._page == 0 and v.pages.total == 1 and v.pages.bouton_plus is not None
    v.pages.choisie.emit(40)                        # page inexistante : la derniere
    assert v._page == 0
    assert Pagination.numeros(0, 3) == [0, 1, 2]
    assert Pagination.numeros(0, 12) == [0, 1, None, 11]
    assert Pagination.numeros(6, 12) == [0, None, 5, 6, 7, None, 11]
    assert Pagination.numeros(11, 12) == [0, None, 10, 11]


def test_un_filtre_ou_tout_voir_ouvre_une_liste_sans_defiler(app, memo):
    v = _vue(memo)
    assert not v.en_liste() and not v.bloc_accueil.isHidden() and v.retour.isHidden()
    assert not v.section_recherche.isHidden()       # accueil : les offres du moment sous la vitrine
    _cocher(v, "15")
    assert v.en_liste() and v.bloc_accueil.isHidden() and not v.retour.isHidden()
    assert v.section_recherche.isHidden() and v.defile.verticalScrollBar().value() == 0
    assert all(0 < f.meilleure.prix < 15 for f in v.visibles())
    v.retour.click()
    assert not v.en_liste() and not v.bloc_accueil.isHidden()
    assert v._filtre() == "affaires" and v.tri.currentData() == "auto"
    v.voir_tout("historique", "populaires")
    assert v.en_liste() and v._filtre() == "historique" and v.tri.currentData() == "populaires"
    v.accueil()
    # une recherche tapee sur l'accueil montre tout ce qu'elle trouve, puis rend l'accueil
    v.recherche.setText("role")
    assert v._filtre() == "tout" and v.en_liste()
    assert {f.titre[:4] for f in v.visibles()} == {"Role"}
    v.recherche.clear()
    assert v._filtre() == "affaires" and not v.en_liste()


def test_tous_les_liens_des_rangees_agissent(app, memo):
    """« Voir les gratuits » ne faisait rien : son signal n'etait branche
    nulle part. Chaque lien d'une rangee doit mener quelque part."""
    from PySide6.QtWidgets import QWidget
    from orion.ui.views.boutique_page import GRATUITS, OFFRES, BoutiquePage
    v = _vue(memo)
    gratuits = QWidget()
    page = BoutiquePage(v, gratuits)
    assert page.onglet == OFFRES
    v.sections["gratuits"][0].lien.click()
    assert page.onglet == GRATUITS and page.pile.currentWidget() is gratuits
    page.montrer(OFFRES)
    for cle, (section, _rangee) in v.sections.items():
        if cle == "gratuits" or section.isHidden() or not section.lien.text():
            continue
        v.accueil()
        section.lien.click()
        assert v.en_liste(), cle                    # le lien a ouvert une liste ou une page de type


def test_l_accueil_a_une_rangee_par_type_les_types_du_joueur_d_abord(app, memo):
    from orion.core.models import Game
    possede = Game(title="Role 00", source="steam", source_id="3000", uid="s1")
    v = _vue(memo, fps=60, rpg=12, bibliotheque=[possede])
    assert v._types_accueil[:2] == ["rpg", "fps"]    # il possede un jeu de role
    section, rangee = v.sections["type0"]
    assert not section.isHidden() and section.titre.text() == "RPG"
    assert rangee.fiches and all(f.titre.startswith("Role") for f in rangee.fiches)
    assert "Role 00" not in {f.titre for f in rangee.fiches}      # deja possede
    assert rangee.fiches[0].titre == "Role 11"                     # le plus connu d'abord
    assert v.sections["type2"][0].isHidden()                       # pas de troisieme type assez fourni
    section.lien.click()
    assert v._genre == "rpg" and len(v.visibles()) == 12
    # la page du type : ses promos en rangee, puis tous ses jeux
    promo, rangee_promo = v.sections_type["promo"]
    assert not promo.isHidden() and "RPG" in promo.titre.text() and len(rangee_promo.fiches) == 12
    assert not v.titre_gros.isHidden()
    _trier(v, "prix")                               # un tri choisi : la liste seule
    assert promo.isHidden() and v.titre_gros.isHidden()


# ---------------------------------------------------------------------------
# Recherche devancee
# ---------------------------------------------------------------------------
def test_la_recherche_partout_part_seule_et_une_seule_fois(app, memo):
    v = _vue(memo)
    demandes = []
    v.recherche_demandee.connect(demandes.append)
    v.recherche.setText("ha")                       # trop court : rien ne part
    assert not v._delai_partout.isActive()
    v.recherche.setText("hades")
    assert v._delai_partout.isActive()
    v._devancer()
    v._devancer()
    assert demandes == ["hades"]
    v._chercher()                                   # Entree pendant l'attente : pas de doublon
    assert demandes == ["hades"]
    trouve = _fiche("Hades", "1145360", prix=12.0, normal=24.0)
    v.set_resultats("hades", [trouve])
    assert [f.titre for f in v.visibles()] == ["Hades"]
    v._chercher()                                   # deja la : rien a redemander
    assert demandes == ["hades"]
    v.set_resultats("ancien", [trouve])             # reponse a une saisie depassee : ignoree
    assert v._terme == "hades"
    v.recherche.clear()
    assert v._resultats is None and not v._delai_partout.isActive()


def test_sur_la_page_d_un_type_le_reste_des_boutiques_est_a_part(app, memo):
    v = _vue(memo)
    v.choisir_type("fps")
    v.recherche.setText("tir 1")
    dehors = _fiche("Tir a l'arc 1", "9000", prix=5.0, normal=10.0)
    memo["9000"] = {"tags": ["Sport"], "avis": 10}
    v.set_resultats("tir 1", [v._catalogue[1], dehors])
    assert all(f.titre.startswith("Tir ") for f in v.visibles())
    assert [f.titre for f in v.ailleurs()] == ["Tir a l'arc 1"]
    assert not v.titre_ailleurs.isHidden() and [f.titre for f in v.grille_ailleurs.fiches] == ["Tir a l'arc 1"]
    v.choisir_type("")
    assert v.ailleurs() == [] and v.titre_ailleurs.isHidden()


# ---------------------------------------------------------------------------
# La suite du magasin : une page n'a pas de fin (7 octobre 2026)
# ---------------------------------------------------------------------------
def test_au_bout_d_une_page_la_suite_est_demandee_une_fois(app, memo):
    from orion.ui.views.boutique_view import PAR_PAGE
    v = _vue(memo, fps=95)
    demandes = []
    v.suite_demandee.connect(demandes.append)
    assert demandes == []                           # l'accueil ne demande rien
    v.choisir_type("fps")
    assert demandes == [] and v.pages.bouton_plus is not None and v.pages.bouton_plus.isEnabled()
    v.pages.choisie.emit(2)                         # derniere page : la suite part d'elle-meme
    assert demandes == ["fps"] and not v.pages.bouton_plus.isEnabled()
    v.pages.choisie.emit(2)
    v._rendre(False)
    assert demandes == ["fps"]                      # jamais deux demandes a la fois
    # cent jeux arrivent : la page garde sa place et gagne des pages
    for i in range(100):
        memo[str(5000 + i)] = {"tags": ["FPS"], "avis": 1}
    v.suite_recue("fps", [_fiche(f"Suite {i:03d}", str(5000 + i), prix=9.0, normal=9.0)
                          for i in range(100)], True)
    assert v._page == 2 and len(v.visibles()) == 195 and v.pages.total == 5
    assert len(v.grille.fiches) == PAR_PAGE and v.pages.bouton_plus.isEnabled()
    assert demandes == ["fps"]                      # pas de demande en chaine
    v.pages.choisie.emit(4)
    assert demandes == ["fps", "fps"]
    # le magasin est au bout : plus de bouton, plus de demande
    v.suite_recue("fps", [], False)
    assert v.pages.bouton_plus is None
    v.pages.choisie.emit(3)
    v.pages.choisie.emit(4)
    assert demandes == ["fps", "fps"]


def test_plus_de_jeux_sur_une_liste_et_jamais_pendant_une_recherche(app, memo):
    v = _vue(memo)
    demandes = []
    v.suite_demandee.connect(demandes.append)
    _cocher(v, "15")                                # une liste sans type : tout le magasin
    assert v.pages.bouton_plus is not None
    del demandes[:]
    v.pages.bouton_plus.click() if v.pages.bouton_plus.isEnabled() else None
    assert demandes in ([""], [])                   # deja partie d'elle-meme si une seule page
    v.suite_recue("", [], True)
    v.pages.plus.emit()
    assert demandes[-1] == ""
    # un jeu deja connu n'est pas ajoute deux fois
    avant = len(v._catalogue)
    v.suite_recue("", [v._catalogue[0]], True)
    assert len(v._catalogue) == avant
    # recherche par nom : elle interroge deja toutes les boutiques
    del demandes[:]
    v.recherche.setText("tir")
    v._rendre(True)
    assert v.pages.bouton_plus is None and demandes == []


def test_la_suite_ne_recompose_pas_les_pages_deja_vues(app, memo):
    """Vu dans la version compilee du 7 octobre : apres « Plus de jeux », la
    page 1 des FPS se recomposait (les jeux arrives, plus connus, passaient
    devant) et le joueur restait sur place sans voir ce qui etait arrive."""
    from orion.ui.views.boutique_view import PAR_PAGE
    v = _vue(memo, fps=95)
    v.choisir_type("fps")
    page_1 = [f.cle for f in v.grille.fiches]
    avant = [f.cle for f in v.visibles()]
    # cent jeux bien plus connus que ceux de la vitrine arrivent, a la demande
    for i in range(100):
        memo[str(5000 + i)] = {"tags": ["FPS"], "avis": 900000 + i}
    v.pages.plus.emit()
    v.suite_recue("fps", [_fiche(f"Suite {i:03d}", str(5000 + i), prix=9.0, normal=9.0)
                          for i in range(100)], True)
    apres = [f.cle for f in v.visibles()]
    assert apres[:95] == avant                      # rien n'a bouge devant
    assert all(f.titre.startswith("Suite ") for f in v.visibles()[95:])
    # « Plus de jeux » : ORION emmene a la premiere page qui montre du nouveau
    assert v._page == 95 // PAR_PAGE
    v.pages.choisie.emit(0)
    assert [f.cle for f in v.grille.fiches] == page_1
    # une suite partie d'elle-meme laisse le joueur ou il est
    for i in range(100):
        memo[str(6000 + i)] = {"tags": ["FPS"], "avis": 950000 + i}
    v.suite_recue("fps", [_fiche(f"Encore {i:03d}", str(6000 + i), prix=9.0, normal=9.0)
                          for i in range(100)], True)
    assert v._page == 0 and [f.cle for f in v.grille.fiches] == page_1
    # un tri choisi par le joueur porte, lui, sur tout ce qui est charge
    v._trier("titre")
    v._rendre(True)
    assert [f.titre for f in v.visibles()][0].startswith("Encore")
