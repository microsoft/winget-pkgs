"""Page Reglages et effet des reglages (2.0, 7 octobre 2026).

Constats : une case au libelle tres long elargissait toute la page au-dela de
la fenetre ; rien ne permettait de retrouver un reglage parmi vingt blocs ;
et plusieurs reglages ne prenaient effet qu'au redemarrage ou au prochain
rafraichissement (largeur des tuiles, jeux masques, manette, frequence de la
veille, pays des prix, cle d'IA)."""
from __future__ import annotations

import pytest

from orion.core.config import CONFIG, Config


@pytest.fixture(scope="module")
def app():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


@pytest.fixture
def vue(app):
    from orion.ui.views.settings_view import SettingsView
    v = SettingsView()
    v.resize(1100, 700)
    v.show()
    app.processEvents()
    yield v
    v.deleteLater()


def _titres(blocs) -> list[str]:
    from PySide6.QtWidgets import QLabel
    return [b.findChild(QLabel, "PanelTitle").text() for b in blocs]


# ---------------------------------------------------------------------------
# CONFIG previent ce qui depend d'un reglage
# ---------------------------------------------------------------------------
class _Oreille:
    def __init__(self):
        self.recus = []

    def entendre(self, chemin):
        self.recus.append(chemin)


def test_un_reglage_qui_change_previent_ses_ecouteurs(tmp_path, monkeypatch):
    from orion.core import config
    monkeypatch.setattr(config, "CONFIG_FILE", tmp_path / "config.json")
    c = Config()
    o = _Oreille()
    c.ecouter(o.entendre)
    c.set("ui.card_width", 240)
    c.set("ui.card_width", 240)                 # meme valeur : personne n'est derange
    c.set("ui.nouvelle_cle", True)
    assert o.recus == ["ui.card_width", "ui.nouvelle_cle"]


def test_un_ecouteur_disparu_ne_gene_plus(tmp_path, monkeypatch):
    import gc
    from orion.core import config
    monkeypatch.setattr(config, "CONFIG_FILE", tmp_path / "config.json")
    c = Config()
    o = _Oreille()
    c.ecouter(o.entendre)
    del o
    gc.collect()
    c.set("ui.card_width", 250)                 # ne plante pas
    assert c._ecouteurs == []


def test_un_ecouteur_en_echec_n_empeche_pas_les_autres(tmp_path, monkeypatch):
    from orion.core import config
    monkeypatch.setattr(config, "CONFIG_FILE", tmp_path / "config.json")
    c = Config()

    class Casse:
        def entendre(self, chemin):
            raise ValueError("boum")
    casse, o = Casse(), _Oreille()
    c.ecouter(casse.entendre)
    c.ecouter(o.entendre)
    c.set("ui.hero", False)
    assert o.recus == ["ui.hero"] and c.get("ui.hero") is False


# ---------------------------------------------------------------------------
# Table reglage -> effet
# ---------------------------------------------------------------------------
def test_chaque_effet_existe_dans_la_fenetre():
    from orion.ui.main_window import MainWindow
    from orion.ui.reglages_mixin import EFFETS
    for cles, methode in EFFETS:
        assert callable(getattr(MainWindow, methode, None)), methode
        assert cles


def test_les_reglages_d_affichage_ont_un_effet_immediat():
    from orion.ui.reglages_mixin import effets_de
    assert effets_de(["ui.card_width"]) == ["refresh_library"]
    assert effets_de(["ui.show_hidden", "ui.hero"]) == ["refresh_library"]
    assert effets_de(["ui.gamepad"]) == ["_appliquer_manette"]
    assert effets_de(["scan.watch_interval_min"]) == ["_appliquer_veille"]
    assert effets_de(["free.hide_demos"]) == ["refresh_free_view"]
    assert effets_de(["market.country"]) == ["_pays_change"]
    assert effets_de(["ai.api_key"]) == ["_ia_changee"]
    assert effets_de(["saves.keep"]) == []       # lu au moment ou il sert


@pytest.fixture(scope="module")
def _fenetre_du_module(app):
    """Une seule fenetre pour le fichier (une seconde a construire)."""
    from orion.ui.main_window import MainWindow
    # le demarrage (reseau) ne doit jamais partir : d'autres essais de ce
    # fichier font tourner la boucle d'evenements
    vrai = MainWindow._boot
    MainWindow._boot = lambda self: None
    try:
        w = MainWindow()
    finally:
        MainWindow._boot = vrai
    yield w
    w.close()
    w.deleteLater()


@pytest.fixture
def fenetre(_fenetre_du_module):
    w = _fenetre_du_module
    yield w
    w._reglages_actifs = False
    w._reglages_changes.clear()
    w._reglages_timer.stop()


def test_la_largeur_des_tuiles_refait_la_bibliotheque_une_seule_fois(fenetre, monkeypatch):
    w = fenetre
    appels = []
    monkeypatch.setattr(w, "refresh_library", lambda: appels.append(1))
    w._reglages_actifs = True
    ancienne = CONFIG.get("ui.card_width", 190)
    try:
        for largeur in (200, 210, 220):          # trois crans du champ numerique
            CONFIG.set("ui.card_width", largeur, save=False)
        assert w._reglages_changes == {"ui.card_width"}
        assert w._reglages_timer.isActive()
        w._appliquer_reglages()
        assert appels == [1]
        assert w._reglages_changes == set()
    finally:
        CONFIG.set("ui.card_width", ancienne, save=False)
        w._reglages_changes.clear()


def test_avant_la_fin_du_demarrage_rien_n_est_relance(fenetre):
    w = fenetre
    assert w._reglages_actifs is False
    ancienne = CONFIG.get("ui.hero", True)
    CONFIG.set("ui.hero", not ancienne, save=False)
    CONFIG.set("ui.hero", ancienne, save=False)
    assert w._reglages_changes == set()


def test_veille_jamais_arrete_vraiment_la_minuterie(fenetre):
    """« jamais » (0) redevenait 10 minutes : `0 or 10`."""
    w = fenetre
    ancien = CONFIG.get("scan.watch_interval_min", 10)
    try:
        CONFIG.set("scan.watch_interval_min", 25, save=False)
        w._appliquer_veille()
        assert w._watch_timer.isActive() and w._watch_timer.interval() == 25 * 60_000
        CONFIG.set("scan.watch_interval_min", 0, save=False)
        w._appliquer_veille()
        assert not w._watch_timer.isActive()
    finally:
        CONFIG.set("scan.watch_interval_min", ancien, save=False)
        w._watch_timer.stop()


def test_cocher_les_jeux_gratuits_apres_coup_lance_la_surveillance(fenetre, monkeypatch):
    w = fenetre
    appels = []
    monkeypatch.setattr(w, "refresh_free", lambda *a, **k: appels.append(1))
    ancien = CONFIG.get("free.enabled", True)
    try:
        CONFIG.set("free.enabled", False, save=False)
        w._appliquer_frequence_gratuits()
        assert not w._free_timer.isActive()
        w._reglages_actifs = True
        CONFIG.set("free.enabled", True, save=False)
        w._appliquer_frequence_gratuits()
        assert w._free_timer.isActive() and appels == [1]
    finally:
        CONFIG.set("free.enabled", ancien, save=False)
        w._free_timer.stop()
        w._reglages_changes.clear()


def test_changer_de_pays_relit_tout_ce_qui_porte_un_prix(fenetre, monkeypatch):
    w = fenetre
    appels = []
    monkeypatch.setattr(w, "refresh_boutique", lambda force=False: appels.append(("boutique", force)))
    monkeypatch.setattr(w, "refresh_free", lambda force=False: appels.append(("gratuits", force)))
    monkeypatch.setattr(w, "refresh_wishlist", lambda force=False: appels.append(("envies", force)))
    w._pays_change()
    assert appels == [("boutique", True), ("gratuits", True), ("envies", True)]


def test_un_releve_de_prix_d_un_autre_pays_est_perime(monkeypatch):
    import time
    from orion.core.models import Game
    from orion.market import MarketService
    from orion.plugins.market.base import MarketInfo
    m = MarketService()
    g = Game(title="Jeu", source="steam", source_id="10", uid="steam:10")
    info = MarketInfo(game_uid=g.uid, title=g.title)
    info.fetched_at = time.time()
    info.sources = ["steam_store"]
    info.categories = []
    brut = info.to_dict()
    brut["adulte"] = False
    m._cache[g.uid] = dict(brut, pays="FR")
    ancien = CONFIG.get("market.country", "FR")
    try:
        CONFIG.set("market.country", "FR", save=False)
        assert m.en_cache(g) is not None
        CONFIG.set("market.country", "US", save=False)
        assert m.en_cache(g) is None                       # a relire en dollars
        assert m.en_cache(g, meme_perime=True) is not None  # montre en attendant
    finally:
        CONFIG.set("market.country", ancien, save=False)


def test_la_cle_d_ia_reveille_le_bouton_de_ma_machine(fenetre):
    w = fenetre
    from orion.core.models import GPUInfo, HardwareInfo
    w.hw = HardwareInfo(cpu_name="Intel Core i5-12400", cpu_cores=6, cpu_threads=12,
                        ram_gb=16, gpus=[GPUInfo(name="NVIDIA GeForce RTX 3060", tier=1)])
    anciens = CONFIG.get("ai.provider", "anthropic"), CONFIG.get("ai.api_key", "")
    try:
        CONFIG.set("ai.provider", "anthropic", save=False)
        CONFIG.set("ai.api_key", "", save=False)
        w._refresh_bilan()
        assert not w.hardware_view.ai_button.isEnabled()
        CONFIG.set("ai.api_key", "cle-d-essai", save=False)
        w._ia_changee()
        assert w.hardware_view.ai_button.isEnabled()
    finally:
        CONFIG.set("ai.provider", anciens[0], save=False)
        CONFIG.set("ai.api_key", anciens[1], save=False)
        w._reglages_changes.clear()


# ---------------------------------------------------------------------------
# La page : rubriques, recherche, largeur
# ---------------------------------------------------------------------------
def test_chaque_bloc_est_range_dans_une_rubrique(vue):
    from orion.ui.views.settings_view import RUBRIQUES
    assert set(vue._panneaux) == {c for c, _n in RUBRIQUES}
    ranges = [p for blocs in vue._panneaux.values() for p in blocs]
    assert len(ranges) == len(vue._rangement) == len(set(ranges)) >= 22
    assert _titres(vue._panneaux["jeux"])[:2] == ["Lancement des jeux", "Detection des jeux"]
    # les donnees partagees ne sont plus cachees sous « Mises a jour »
    assert "Donnees partagees" in _titres(vue._panneaux["orion"])
    assert vue.cb_partage.parent().findChild(type(vue.cb_partage)) is not None


def test_la_recherche_ne_garde_que_les_blocs_concernes(vue, app):
    assert _titres(vue.correspondants("langue")) == ["Langue / Language"]
    assert "Interface" in _titres(vue.correspondants("tuiles"))
    assert "Prix et evaluations" in _titres(vue.correspondants("Pays"))
    assert "Sauvegardes de parties" in _titres(vue.correspondants("sauveg"))   # debut de mot
    assert "Assistant IA" in _titres(vue.correspondants("ia"))
    assert "Soutien au projet" not in _titres(vue.correspondants("ia"))        # « partenaires »
    assert "Mises a jour" in _titres(vue.correspondants("mise à jour"))        # accents
    vue.recherche.setText("manette")
    app.processEvents()
    visibles = [p for blocs in vue._panneaux.values() for p in blocs if not p.isHidden()]
    assert "Manette et affichage salon" in _titres(visibles) and len(visibles) <= 3
    assert vue._titres["boutique"].isHidden() and not vue._titres["apparence"].isHidden()
    vue.recherche.setText("")
    app.processEvents()
    assert all(not p.isHidden() for blocs in vue._panneaux.values() for p in blocs)
    assert vue.aucun.isHidden()


def test_recherche_sans_resultat_le_dit(vue, app):
    vue.recherche.setText("zzzz")
    app.processEvents()
    assert not vue.aucun.isHidden() and "zzzz" in vue.aucun.text()
    assert all(t.isHidden() for t in vue._titres.values())


def test_un_bouton_de_rubrique_y_mene(vue, app):
    barre = vue.scroll.verticalScrollBar()
    assert barre.maximum() > 0
    vue.recherche.setText("prix")
    vue.aller_a("orion")
    app.processEvents()
    assert vue.recherche.text() == ""           # la recherche ne masque pas la rubrique
    assert barre.value() > 0
    vue.aller_a("jeux")
    assert barre.value() <= 10


def test_aucun_libelle_n_elargit_la_page_au_dela_de_la_fenetre(vue, app):
    """Une case de 1 600 points de large poussait les boutons de droite de
    tous les blocs hors de l'ecran."""
    from PySide6.QtCore import QPoint
    from PySide6.QtWidgets import QCheckBox, QPushButton
    corps = vue.scroll.widget()
    assert corps.minimumSizeHint().width() <= 900
    for case in vue.findChildren(QCheckBox):
        assert case.minimumSizeHint().width() <= 760, case.text()[:60]
    largeur = vue.width()
    for b in vue.findChildren(QPushButton):
        if b.isVisible():
            assert b.mapTo(vue, QPoint(b.width(), 0)).x() <= largeur + 2, b.text()


def test_un_libelle_long_coche_sa_case_au_clic(vue, app):
    from PySide6.QtCore import Qt
    from PySide6.QtTest import QTest
    from orion.ui.views.settings_view import _Libelle
    libelle = next(w for w in vue.findChildren(_Libelle) if w._case is vue.cb_partage)
    assert libelle.wordWrap() and vue.cb_partage.text() == ""
    assert vue.cb_partage.accessibleName().startswith("Partager mes mesures")
    avant = vue.cb_partage.isChecked()
    ancien = CONFIG.get("partage.actif", False), CONFIG.get("partage.demande", False), \
        CONFIG.get("partage.question", 0)
    try:
        vue.scroll.ensureWidgetVisible(libelle)
        app.processEvents()
        QTest.mouseClick(libelle, Qt.MouseButton.LeftButton)
        assert vue.cb_partage.isChecked() is (not avant)
        assert CONFIG.get("partage.actif") is (not avant)
    finally:
        for cle, v in zip(("partage.actif", "partage.demande", "partage.question"), ancien):
            CONFIG.set(cle, v, save=False)


def test_ctrl_f_met_le_curseur_dans_la_recherche(vue, app):
    vue.activateWindow()
    vue.chercher()
    app.processEvents()
    assert vue.recherche.hasFocus() or vue.focusWidget() is vue.recherche
