"""Couverture des tables de reference (2.0).

Une carte que la table ne connait pas, c'est un joueur a qui ORION ne dit
rien : ni niveau, ni frein, ni piste. Les noms ci-dessous sont ceux que
Windows donne, tels que l'enquete materielle de Steam les publie
(septembre 2026 : ils couvrent environ neuf joueurs sur dix).
"""
import pytest

from orion.puissance import lecture
from orion.puissance.references import (GPU, GPU_INTEGREES, GPU_PORTABLES, HORS_VENTE,
                                        indice_cpu, indice_gpu, tous_les_cpu)

ENQUETE = """NVIDIA GeForce RTX 5070|NVIDIA GeForce RTX 5060|NVIDIA GeForce RTX 5060 Ti
NVIDIA GeForce RTX 4060|NVIDIA GeForce RTX 3060|NVIDIA GeForce RTX 4060 Laptop GPU
NVIDIA GeForce RTX 3050|NVIDIA GeForce RTX 4060 Ti|NVIDIA GeForce RTX 5060 Laptop GPU
NVIDIA GeForce GTX 1650|NVIDIA GeForce RTX 4070|NVIDIA GeForce RTX 3060 Ti
NVIDIA GeForce RTX 5080|NVIDIA GeForce RTX 3070|NVIDIA GeForce RTX 5070 Ti
NVIDIA GeForce RTX 4070 SUPER|NVIDIA GeForce RTX 3060 Laptop GPU
NVIDIA GeForce RTX 4050 Laptop GPU|NVIDIA GeForce RTX 2060|Intel Iris Xe Graphics
AMD Radeon Graphics|AMD Radeon RX 9070 XT|NVIDIA GeForce GTX 1060|NVIDIA GeForce RTX 3080
NVIDIA GeForce GTX 1660 SUPER|Intel(R) UHD Graphics|NVIDIA GeForce GTX 1050 Ti
NVIDIA GeForce RTX 4070 Ti|NVIDIA GeForce RTX 3070 Ti|NVIDIA GeForce RTX 4070 Laptop GPU
AMD Radeon(TM) Graphics|NVIDIA GeForce GTX 1660 Ti|AMD Radeon RX 9060 XT|AMD Radeon RX 6600
NVIDIA GeForce RTX 2060 SUPER|NVIDIA GeForce RTX 4070 Ti SUPER|NVIDIA GeForce RTX 4090
NVIDIA GeForce RTX 3050 6GB Laptop GPU|NVIDIA GeForce RTX 5070 Laptop GPU
NVIDIA GeForce RTX 4080 SUPER|NVIDIA GeForce RTX 2070 SUPER|NVIDIA GeForce RTX 4080
Intel UHD Graphics|AMD Radeon RX 7800 XT|NVIDIA GeForce RTX 3050 Ti Laptop GPU
NVIDIA GeForce GTX 1070|AMD Radeon RX 580 2048SP|NVIDIA GeForce RTX 3080 Ti
AMD Radeon RX 5700 XT|AMD Radeon RX 6700 XT|AMD Radeon RX 580|NVIDIA GeForce GTX 1050
Intel(R) Graphics|AMD Radeon RX 7600|NVIDIA GeForce RTX 2050|NVIDIA GeForce GTX 1660
AMD Radeon (TM) Graphics|NVIDIA GeForce RTX 5070 Ti Laptop GPU|NVIDIA GeForce RTX 2070
NVIDIA GeForce RTX 5090|AMD Radeon RX 7900 XTX|NVIDIA GeForce RTX 3070 Laptop GPU
NVIDIA GeForce RTX 5050 Laptop GPU|Intel UHD Graphics 620|NVIDIA GeForce GTX 1080
NVIDIA GeForce RTX 3050 Laptop GPU|NVIDIA GeForce GTX 1650 Ti|NVIDIA GeForce RTX 3090
AMD Radeon RX 570|AMD Radeon RX 7900 XT|NVIDIA GeForce GTX 1080 Ti
AMD Radeon 780M Graphics|AMD Radeon Vega 8 Graphics|AMD Radeon RX 6600 XT
Intel Arc Graphics|NVIDIA GeForce GTX 1650 SUPER|AMD Radeon RX 7700 XT
NVIDIA GeForce RTX 2080 SUPER|NVIDIA GeForce RTX 5050|AMD Radeon RX 6650 XT
AMD Radeon RX 6750 XT|Intel UHD Graphics 630|NVIDIA GeForce RTX 2080 Ti
AMD Radeon RX 6800 XT|NVIDIA GeForce RTX 3070 Ti Laptop GPU|AMD Radeon RX 9070
NVIDIA GeForce RTX 2080|AMD Radeon RX 550|NVIDIA GeForce GT 1030
NVIDIA GeForce GTX 1070 Ti|AMD Radeon RX 6500 XT|NVIDIA GeForce RTX 4080 Laptop GPU
Intel HD Graphics 520|AMD Radeon Vega 3 Graphics|Intel HD Graphics 620
NVIDIA GeForce GTX 970""".replace("\n", "|").split("|")


@pytest.mark.parametrize("nom", ENQUETE)
def test_toute_carte_de_l_enquete_steam_est_reconnue(nom):
    assert indice_gpu(nom) is not None, nom


def test_les_variantes_ne_sont_pas_confondues():
    assert indice_gpu("NVIDIA GeForce RTX 3050 Ti Laptop GPU")[0] == "rtx 3050 ti"
    assert indice_gpu("AMD Radeon RX 6600M")[0] == "rx 6600m"
    assert indice_gpu("AMD Radeon RX 6600")[0] == "rx 6600"
    assert indice_gpu("AMD Radeon RX 6600M")[1] < indice_gpu("AMD Radeon RX 6600")[1]
    assert indice_gpu("AMD Radeon RX Vega 64")[0] == "vega 64"       # pas « vega 6 »
    assert indice_gpu("NVIDIA GeForce MX450")[0] == indice_gpu("GeForce MX 450")[0] == "mx 450"
    assert indice_gpu("Microsoft Basic Display Adapter") is None      # rien d'invente


@pytest.mark.parametrize("nom, cle", [
    ("12th Gen Intel(R) Core(TM) i5-12450H", "12450"),
    ("13th Gen Intel(R) Core(TM) i7-13620H", "13620"),
    ("AMD Ryzen 7 7735HS with Radeon Graphics", "7735"),
    ("Intel(R) Core(TM) Ultra 7 155H", "155h"),
    ("AMD Ryzen AI 9 HX 370 w/ Radeon 890M", "hx 370"),
    ("11th Gen Intel(R) Core(TM) i5-1135G7 @ 2.40GHz", "1135g7"),
    ("AMD Ryzen 5 7500F 6-Core Processor", "7500f"),
    ("Intel(R) Core(TM) i9-9900K CPU @ 3.60GHz", "9900k"),
])
def test_processeurs_de_portables_et_recents(nom, cle):
    assert indice_cpu(nom)[0] == cle


def test_un_portable_vaut_moins_que_la_puce_de_bureau():
    assert indice_cpu("Intel(R) Core(TM) i7-12700H")[1] < indice_cpu("Intel Core i7-12700")[1]
    assert indice_cpu("Intel(R) Core(TM) i7-7700HQ CPU @ 2.80GHz")[1] < 41


def test_une_frequence_n_est_pas_un_modele():
    assert tous_les_cpu("Dual Core 2600 MHz") == []
    assert tous_les_cpu("Intel Core i5-4590 @ 3.30GHz ou AMD FX 8350 4.0 GHz") \
        == [("4590", 30), ("fx 8350", 18)]
    assert indice_cpu("Intel(R) Core(TM) i5-6600K CPU @ 3.50GHz")[0] == "6600k"


def test_ni_portable_ni_puce_integree_en_exemple_d_achat():
    assert HORS_VENTE == set(GPU_PORTABLES) | set(GPU_INTEGREES) and HORS_VENTE <= set(GPU)
    achetables = {k for _v, k in lecture._gpu_achetables()}
    assert not achetables & HORS_VENTE
    for indice in (3, 9, 20, 30):
        proches = lecture.equivalents_gpu(indice, combien=6).lower()
        assert not any(k in proches for k in ("radeon 8", "mx ", "6600m", "vega", "iris"))
