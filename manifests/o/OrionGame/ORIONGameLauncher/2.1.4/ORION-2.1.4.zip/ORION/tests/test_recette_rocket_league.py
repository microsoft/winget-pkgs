"""Rocket League (15 octobre 2026, enregistrement de l'auteur) : ORION n'avait
aucune recette ; il avait appris `TASystemSettings.ini` par l'exemple (une
seule cle, la synchronisation verticale) et classait le jeu « gere par
lui-meme ». La recette ecrit les cles qui existent dans le vrai fichier du
jeu (Unreal Engine 3), jamais une cle inventee.

Le fichier d'essai est le vrai `TASystemSettings.ini` de l'auteur (copie de
sauvegarde d'ORION du 15 octobre), sans aucune donnee personnelle."""
from __future__ import annotations

import re
import shutil
from pathlib import Path

import pytest

from orion.core.models import Display, DisplayMode, Game, GPUInfo, HardwareInfo

MODELE = Path(__file__).parent / "donnees" / "rocket_league_TASystemSettings.ini"


def _hw():
    natif = DisplayMode(2560, 1440, 165)
    ecran = Display(device="D1", primary=True, current=natif, native=natif,
                    max_refresh_at_native=165, modes=[natif])
    gpu = GPUInfo(name="NVIDIA GeForce RTX 3080", vendor="nvidia", vram_mb=10240,
                  tier=2, features=["dlss", "rt"])
    return HardwareInfo(cpu_name="Intel Core i9-9900K", cpu_threads=16, ram_gb=32,
                        gpus=[gpu], displays=[ecran]), ecran


@pytest.fixture
def rocket(tmp_path, monkeypatch):
    from orion.optimizer import discovery
    docs = tmp_path / "Documents"
    monkeypatch.setattr(discovery, "documents_dir", lambda: docs)
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))   # zone autorisee
    dossier = docs / "My Games" / "Rocket League" / "TAGame" / "Config"
    dossier.mkdir(parents=True)
    fichier = dossier / "TASystemSettings.ini"
    shutil.copy(MODELE, fichier)
    inst = tmp_path / "jeux" / "rocketleague"
    (inst / "Binaries" / "Win64").mkdir(parents=True)
    jeu = Game(title="Rocket League", source="steam", source_id="252950",
               install_dir=str(inst), executable=str(inst / "Binaries" / "Win64" / "RocketLeague.exe"))
    return jeu, fichier


def _systeme(fichier) -> dict:
    """Les cles de la section [SystemSettings] seulement (DetailMode existe
    aussi dans d'autres sections, qui ne doivent pas bouger)."""
    valeurs, dedans = {}, False
    for ligne in Path(fichier).read_text("utf-8").splitlines():
        if ligne.startswith("["):
            dedans = ligne.strip() == "[SystemSettings]"
            continue
        if dedans and "=" in ligne:
            k, v = ligne.split("=", 1)
            valeurs[k.strip()] = v.strip()
    return valeurs


def test_rocket_league_a_une_recette_qui_ecrit(rocket):
    from orion.optimizer.engine import Optimizer
    from orion.optimizer.recommande import choisir_niveau
    jeu, fichier = rocket
    texte_avant = fichier.read_text("utf-8")
    avant = _systeme(fichier)
    assert avant["ResX"] == "2560" and avant["UseVsync"] == "True"
    moteur = Optimizer()
    hw, ecran = _hw()
    choisir_niveau(jeu, "basse")
    plan = moteur.build_plan(jeu, "recommande", hw, ecran)
    assert "Rocket League" in plan.recipe_name and plan.confidence == "exact"
    assert plan.tunable and len(plan.ops) >= 12
    # rien d'invente : chaque cle visee existe dans le vrai fichier
    assert all(o.current is not None for o in plan.ops), [o.key for o in plan.ops if o.current is None]
    ok, msg = moteur.apply_plan(jeu, plan)
    assert ok, msg
    apres = _systeme(fichier)
    assert apres["ResX"] == "2560" and apres["ResY"] == "1440"
    assert apres["UseVsync"] == "False"                       # 165 Hz : pas de vsync
    assert apres["DynamicShadows"] == "False"                 # niveau Basse
    assert apres["AutoDetectDesktopResolution"] == "False"
    assert apres["AllowDynamicResolution"] == "False"
    # le reste du fichier (700 lignes, sections des autres plateformes) est intact
    assert fichier.read_text("utf-8").count("\n") == texte_avant.count("\n")
    assert fichier.read_text("utf-8").split("[SystemSettingsBucket1]")[1] == \
        texte_avant.split("[SystemSettingsBucket1]")[1]
    # relu et verifie : aucun reglage refuse
    from orion.optimizer import fiabilite
    etat = fiabilite.statut(moteur.build_plan(jeu, "recommande", hw, ecran), jeu)
    assert etat.cle not in (fiabilite.GERE_PAR_LE_JEU, fiabilite.NON_PRIS), etat


def test_rocket_league_ne_promet_pas_de_super_resolution(rocket):
    from orion.optimizer.engine import Optimizer
    jeu, fichier = rocket
    hw, ecran = _hw()
    plan = Optimizer().build_plan(jeu, "recommande", hw, ecran)
    assert not any(re.search(r"dlss|fsr|xess", str(o.key), re.I) for o in plan.ops)
    assert not any("DLSS" in c for c in (plan.guide or []))


def test_chaque_conseil_de_recette_est_traduit_en_anglais():
    """Les conseils (`advice`) des recettes sont affiches tels quels dans la
    fiche : chacun doit avoir sa traduction dans en.json (15 manquaient le 16/10)."""
    import glob
    import json
    from pathlib import Path
    racine = Path(__file__).resolve().parents[1] / "orion"
    en = json.loads((racine / "langues" / "en.json").read_text("utf-8"))["exact"]
    manquants = []
    for fichier in sorted(glob.glob(str(racine / "plugins" / "tweaks" / "recipes" / "*.json"))):
        for conseil in json.loads(Path(fichier).read_text("utf-8")).get("advice", []):
            if conseil not in en:
                manquants.append((Path(fichier).name, conseil[:60]))
    assert not manquants, manquants
