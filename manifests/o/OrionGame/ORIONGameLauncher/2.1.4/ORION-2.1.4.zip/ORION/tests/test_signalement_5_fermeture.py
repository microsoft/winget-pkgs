"""Signalement du 17 octobre 2026 (ORION 2.1.2, premier lancement, Windows 11
26200) : « Arret brutal d'ORION », sans aucune erreur dans le journal.

La 2.1.2 restait figee 5 s a la fermeture avant de retirer le temoin de
session : un processus coupe a ce moment-la (Windows « ne repond pas »,
gestionnaire des taches, outil de test) etait presente au demarrage suivant
comme un plantage. Desormais :
* la fermeture est notee des la demande : une session coupee pendant sa
  fermeture n'est plus un « arret brutal » ;
* un vrai plantage natif laisse une trace (`faulthandler`), jointe au rapport ;
* le rapport dit comment la session precedente a fini et d'ou vient ORION."""
import json

import pytest

from orion import signalement as S

#: la vraie fonction (conftest la remplace pour les autres essais)
VRAIE_OUVERTURE = S.ouvrir_session


@pytest.fixture
def session(tmp_path, monkeypatch):
    monkeypatch.setattr(S, "ouvrir_session", VRAIE_OUVERTURE)
    monkeypatch.setattr(S, "TEMOIN", tmp_path / ".session-en-cours")
    monkeypatch.setattr(S, "TRACE_NATIVE", tmp_path / "trace-native.txt")
    monkeypatch.setattr(S, "_precedente", {})
    actives = []
    monkeypatch.setattr(S, "_activer_trace_native", lambda: actives.append(1))
    return tmp_path


def test_premier_lancement_pas_d_arret_brutal(session):
    assert S.ouvrir_session() is False
    d = json.loads(S.TEMOIN.read_text("utf-8"))
    assert d["etat"] == "en_cours"


def test_une_session_coupee_pendant_la_fermeture_n_est_pas_un_plantage(session):
    S.ouvrir_session()
    S.marquer_fermeture()                 # le joueur ferme...
    # ... et le processus est tue avant la fin de l'ecriture finale
    assert S.ouvrir_session() is False
    assert "coupee pendant la fermeture" in "\n".join(S._resume_precedente())


def test_une_session_arretee_pendant_l_utilisation_reste_un_arret_brutal(session):
    S.ouvrir_session()
    assert S.ouvrir_session() is True
    assert "pendant l'utilisation" in "\n".join(S._resume_precedente())


def test_ancien_temoin_lu_comme_session_en_cours(session):
    S.TEMOIN.write_text("1792248052.9", "utf-8")       # format de la 2.1.3 et avant
    assert S.ouvrir_session() is True


def test_une_trace_native_prouve_un_plantage_meme_pendant_la_fermeture(session):
    S.ouvrir_session()
    S.marquer_fermeture()
    S.TRACE_NATIVE.write_text("Windows fatal exception: access violation\n\nThread 0x1 (most recent call first):\n"
                              '  File "orion\\\\ui\\\\main_window.py", line 2470 in closeEvent\n', "utf-8")
    assert S.ouvrir_session() is True
    assert "access violation" in "\n".join(S._resume_precedente())


def test_le_rapport_dit_la_fin_de_session_et_l_installation(session, monkeypatch):
    S.ouvrir_session()
    S.ouvrir_session()
    texte = S.rapport(description="Arret brutal d'ORION")
    assert "## Session precedente" in texte and "pendant l'utilisation" in texte
    assert "## Installation" in texte


def test_fin_propre_efface_temoin_et_trace(session):
    S.ouvrir_session()
    S.TRACE_NATIVE.write_text("", "utf-8")
    S.fermer_session()
    assert not S.TEMOIN.exists() and not S.TRACE_NATIVE.exists()
    assert S.ouvrir_session() is False


def test_la_trace_native_est_vraiment_branchee(tmp_path, monkeypatch):
    monkeypatch.setattr(S, "TRACE_NATIVE", tmp_path / "trace-native.txt")
    appels = {}

    class Faux:
        def enable(self, file=None, all_threads=False):
            appels["enable"] = (file.name, all_threads)

        def disable(self):
            appels["disable"] = True
    monkeypatch.setattr(S, "faulthandler", Faux())
    S._activer_trace_native()
    assert appels["enable"] == (str(tmp_path / "trace-native.txt"), True)
    S.fermer_session()
    assert appels.get("disable") and S._trace_fichier is None
