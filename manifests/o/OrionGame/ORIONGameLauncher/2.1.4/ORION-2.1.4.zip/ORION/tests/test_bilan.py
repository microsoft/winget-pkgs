"""Le bilan en une minute (2.0.2) : quatre phrases calculees a partir des
jeux, du calculateur de puissance, des conseils, de la liste d'envies et de
la valeur de la bibliotheque."""
from __future__ import annotations

from types import SimpleNamespace as NS

import pytest

from orion import bilan


def _ev(niveau, fluide=True, source="estime", installe=True):
    return (NS(installe=installe), NS(niveau=niveau, fluide=fluide, source=source))


def _conseil(titre, level="conseil", groupe="Pilotes"):
    return NS(title=titre, level=level, groupe=groupe)


def _envie(title, cut=0, dropped=False, reached=False):
    return NS(title=title, cut=cut, dropped=dropped, reached=reached)


def test_bibliotheque_vide_et_lecture_en_cours():
    b = bilan.calculer([], None, None, [], None)
    assert b.lignes[0].titre == "Aucun jeu trouve pour l'instant" and b.lignes[0].page == "library"
    assert not b.complet                          # conseils inconnus
    b = bilan.calculer([1, 2, 3], None, [], [], None)
    assert b.lignes[0].titre == "3 jeux trouves" and "se lisent en fond" in b.lignes[0].detail
    assert not b.complet
    # evalues mais tous inconnus : meme phrase
    b = bilan.calculer([1], [_ev("", source="inconnu")], [], [], None)
    assert b.lignes[0].titre == "1 jeu trouve"


def test_jeux_qui_tournent():
    res = [_ev("haute"), _ev("haute"), _ev("moyenne"), _ev("insuffisant"),
           _ev("", source="inconnu"), _ev("haute", installe=False)]
    b = bilan.calculer(list(range(6)), res, [], [], None)
    l = b.lignes[0]
    assert l.titre == "Votre PC fait tourner 2 de vos 4 jeux en qualite Haute"
    assert "1 jeu est en dessous de la configuration minimale." in l.details and "1 sans configuration connue." in l.details
    assert l.page == "hardware" and l.bouton
    b = bilan.calculer([1, 2], [_ev("haute"), _ev("haute")], [], [], None)
    assert b.lignes[0].titre == "Votre PC fait tourner vos 2 jeux en qualite Haute"
    b = bilan.calculer([1], [_ev("haute")], [], [], None)
    assert b.lignes[0].titre == "Votre PC fait tourner votre jeu en qualite Haute"
    # rien en Haute : on compte les jouables
    b = bilan.calculer([1, 2], [_ev("basse"), _ev("insuffisant")], [], [], None)
    assert b.lignes[0].titre == "Votre PC fait tourner 1 de vos 2 jeux"
    # « Haute » pas fluide ne compte pas comme Haute
    b = bilan.calculer([1], [_ev("haute", fluide=False)], [], [], None)
    assert b.lignes[0].titre == "Votre PC fait tourner 1 de vos 1 jeux"


def test_pilotes():
    conseils = [_conseil("Pilote plus recent chez Dell : reseau"), _conseil("Pilote audio ancien"),
                _conseil("13 pilotes analyses", "ok"), _conseil("Disque C: presque plein", "attention", "Materiel"),
                _conseil("Pilote graphique : 617.42 disponible")]
    b = bilan.calculer([1], [_ev("haute")], conseils, [], None)
    l = b.lignes[1]
    assert l.titre == "3 pilotes a mettre a jour" and "2 versions precises connues" in l.detail
    assert l.page == "advice" and l.bouton == "Voir les conseils"
    b = bilan.calculer([1], [_ev("haute")], [_conseil("13 pilotes analyses", "ok")], [], None)
    assert b.lignes[1].titre == "Pilotes a jour" and not b.lignes[1].bouton
    b = bilan.calculer([1], [_ev("haute")], [_conseil("Pilote audio ancien")], [], None)
    assert b.lignes[1].titre == "1 pilote a mettre a jour" and "fabricant" in b.lignes[1].detail


def test_valeur_et_envies():
    valeur = NS(connue=True, total=1234.5, devise="EUR", estimes=40, jeux=52, montant=lambda v: "1 235")
    b = bilan.calculer([1], [_ev("haute")], [], [], valeur)
    assert b.lignes[2].titre == "Votre bibliotheque vaut environ 1 235 EUR" and "40 jeux sur 52" in b.lignes[2].detail
    assert b.lignes[3].titre == "Aucun jeu suivi pour l'instant" and b.lignes[3].page == "wishlist"
    envies = [_envie("Hades II", cut=30, dropped=True), _envie("Elden Ring"), _envie("Silksong", cut=10, reached=True)]
    b = bilan.calculer([1], [_ev("haute")], [], envies, None)
    l = b.lignes[2]
    assert l.titre == "2 jeux de votre liste d'envies ont baisse" and "Hades II, Silksong" in l.detail
    assert l.bouton == "Voir les prix"
    b = bilan.calculer([1], [_ev("haute")], [], [_envie("Elden Ring")], None)
    assert b.lignes[2].titre == "1 jeu suivi dans votre liste d'envies"
    # valeur inconnue : pas de ligne
    b = bilan.calculer([1], [_ev("haute")], [], [], NS(connue=False))
    assert len(b.lignes) == 3 and b.complet


@pytest.fixture(scope="module")
def app():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


def test_fenetre_du_bilan_ouvre_la_page_demandee(app):
    from PySide6.QtWidgets import QPushButton
    from orion.ui.widgets.dialogues import DialogueBilan
    b = bilan.calculer([1, 2], [_ev("haute"), _ev("moyenne")], [_conseil("Pilote audio ancien")], [], None)
    d = DialogueBilan(b, None, premiere_fois=True)
    boutons = d.findChildren(QPushButton)
    libelles = {w.text() for w in boutons}
    assert "Voir les conseils" in libelles and "C'est parti" in libelles
    next(w for w in boutons if w.text() == "Voir les conseils").click()
    assert d.page_demandee == "advice" and d.result() == d.DialogCode.Accepted.value


def test_carte_a_partager(app, tmp_path):
    from orion.ui import carte
    valeur = NS(connue=True, total=1234.5, devise="EUR", estimes=40, jeux=52, montant=lambda v: "1 235")
    b = bilan.calculer(list(range(52)), [_ev("haute")] * 38 + [_ev("moyenne")] * 14,
                       [_conseil("Pilote audio ancien"), _conseil("Pilote reseau ancien")], [], valeur)
    hw = NS(cpu_name="Intel Core i9-9900K", gpu=NS(name="NVIDIA GeForce RTX 3080"))
    c = carte.depuis_bilan(b, hw)
    assert c.titre == "Mon PC fait tourner 38 de mes 52 jeux en qualite Haute"
    assert c.sous_titre.startswith("Environ 60 images par seconde")
    assert c.lignes[0] in ("Ma bibliotheque vaut environ 1 235 EUR", "Ma bibliothèque vaut environ 1 235 EUR")
    assert c.lignes[1] in ("2 pilotes a mettre a jour", "2 pilotes à mettre à jour")
    assert c.lignes[2] == "Intel Core i9-9900K · NVIDIA GeForce RTX 3080"
    assert "orion-launcher.com" in c.pied
    # rien de personnel : pas de nom de machine, pas de chemin
    texte = " ".join([c.titre, c.sous_titre, *c.lignes, c.pied])
    assert "Users" not in texte and "\\" not in texte
    img = carte.dessiner(c)
    assert img.width() == 1200 and img.height() == 630
    assert carte.enregistrer(img, tmp_path / "carte.png") and (tmp_path / "carte.png").stat().st_size > 10_000
    # bibliotheque vide : un titre neutre, jamais une phrase cassee
    c2 = carte.depuis_bilan(bilan.calculer([], None, None, [], None), NS(cpu_name="", gpu=NS(name="")))
    assert c2.titre == "Mon PC et mes jeux, lus par ORION" and c2.lignes == []
