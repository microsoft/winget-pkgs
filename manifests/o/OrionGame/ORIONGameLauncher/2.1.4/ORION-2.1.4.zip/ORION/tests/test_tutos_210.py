"""Tutos et Reglages relus pour la 2.1.0 (10 octobre, « je ne sais pas si tu
dois refaire la page des tutos, il y a eu du changement depuis. Analyse.
Pareil pour les reglages. ») : chaque texte suit le code qu'il decrit."""
import pathlib

from orion import aide, marche_gris

RACINE = pathlib.Path(__file__).resolve().parents[1]


def _article(ident):
    return next(a for r in aide.RUBRIQUES for a in r.articles if a.id == ident)


def _texte(a):
    return " ".join([a.title, a.summary, *a.body, *[x + " " + y for x, y in a.steps]])


def test_l_apprentissage_par_l_exemple_a_son_article():
    a = _article("apprendre")
    bouton = (RACINE / "orion" / "ui" / "widgets" / "profile_card.py").read_text("utf-8")
    assert '"Apprendre les niveaux de ce jeu"' in bouton
    assert "« Apprendre les niveaux de ce jeu »" in _texte(a)
    assert "par defaut du jeu" in _texte(a) and "Baldur's Gate 3" in _texte(a)
    assert aide.search("deja en place")            # le symptome mene a l'article


def test_la_case_dlss_est_expliquee():
    a = next(a for r in aide.RUBRIQUES for a in r.articles if a.title.startswith("Les graphismes"))
    assert "« Activer DLSS »" in _texte(a) and "+18 i/s" in _texte(a)


def test_la_mesure_dit_le_vrai_droit_demande():
    from orion.perf.presentmon import ACCES_REFUSE
    groupe = "Utilisateurs du journal de performances"
    assert groupe in ACCES_REFUSE
    a = next(a for r in aide.RUBRIQUES for a in r.articles if a.title == "Mesurer les images par seconde")
    assert groupe in _texte(a) and "net localgroup" in _texte(a) and "Performance Log Users" in _texte(a)
    reglages = (RACINE / "orion" / "ui" / "views" / "settings_view.py").read_text("utf-8")
    assert "La capture demande les droits" not in reglages and "Utilisateurs du journal de" in reglages


def test_la_boutique_nomme_les_revendeurs_retenus():
    from orion.ui.views import boutique_view
    a = next(a for r in aide.RUBRIQUES for a in r.articles if a.title.startswith("Boutique"))
    noms = {s.id: s.nom.split(" (")[0] for s in marche_gris.SITES}
    for texte in (_texte(a), boutique_view.POLITIQUE):
        for ident in marche_gris.RETENUS:
            assert noms[ident] in texte, (ident, texte[:80])
        assert "Gift" in texte and "G2A" in texte
        assert "Kinguin, Eneba, Instant Gaming" not in texte     # ancienne liste « ecartees »
    assert "Voir dans ma bibliotheque" in _texte(a)


def test_refus_de_mesure_retenu_puis_efface(monkeypatch):
    from orion.core.config import CONFIG
    from orion.launch.launcher import retenir_refus
    from orion.perf.presentmon import ACCES_REFUSE
    vu = {}
    monkeypatch.setattr(CONFIG, "set", lambda k, v: vu.__setitem__(k, v))
    monkeypatch.setattr(CONFIG, "get", lambda k, d=None: vu.get(k, d))
    retenir_refus(None, "trace trop courte (moins de 60 images)")
    assert "perf.acces_refuse" not in vu
    retenir_refus(None, ACCES_REFUSE)
    assert vu["perf.acces_refuse"] is True
    retenir_refus({"fps_avg": 90}, "")
    assert vu["perf.acces_refuse"] is False


def test_textes_revus_traduits_en_anglais():
    from orion import i18n
    from orion.ui.views import boutique_view
    try:
        assert i18n.charger("en")
        i18n.traduire.cache_clear()
        for a in (_article("apprendre"),):
            for x in [a.title, a.summary, *a.body]:
                assert x in i18n._exact, x[:60]
        assert boutique_view.POLITIQUE in i18n._exact
        assert i18n.traduire("Voir dans ma bibliotheque") == "See in my library"
    finally:
        i18n.charger("fr")
        i18n.traduire.cache_clear()
