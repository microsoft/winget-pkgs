"""Pages « alternative à… » du site (11 octobre 2026) : une page par langue,
hreflang dans les deux sens, données structurées valides, llms.txt, plan."""
import json
import re
import sys
from pathlib import Path

SITE = Path(__file__).resolve().parent.parent / "service" / "site"
sys.path.insert(0, str(SITE))


def _site(tmp_path):
    (tmp_path / "index.html").write_text("<html><head><style>body{}</style></head><body></body></html>", encoding="utf-8")
    (tmp_path / "sitemap.xml").write_text('<?xml version="1.0"?><urlset></urlset>', encoding="utf-8")
    # même forme que la vraie page : pas de <main>, un <footer> (le 11 octobre, le lien
    # « Voir aussi » n'était jamais posé sur le site parce que l'essai supposait </main>)
    (tmp_path / "comparatif.html").write_text(
        '<html><body><div class="page"><h1>x</h1><p>y</p>'
        '<footer><a href="/">Retour</a></footer></div></body></html>', encoding="utf-8")
    return tmp_path


def test_le_voir_aussi_se_pose_avant_le_pied_de_page(tmp_path):
    import gen_alternatives as g
    d = _site(tmp_path)
    g.main(d)
    s = (d / "comparatif.html").read_text(encoding="utf-8")
    assert s.index("/alternative-gog-galaxy") < s.index("<footer")
    # une page sans aucun point d'ancrage doit faire échouer la construction, pas passer en silence
    (d / "comparatif.html").write_text("<p>rien</p>", encoding="utf-8")
    import pytest
    with pytest.raises(RuntimeError):
        g.main(d)


def test_les_pages_alternatives(tmp_path):
    import gen_alternatives as g
    d = _site(tmp_path)
    assert g.main(d) == 6
    for p in g.PAGES:
        for lang, autre in (("fr", "en"), ("en", "fr")):
            s = (d / (p[lang].lstrip("/") + ".html")).read_text(encoding="utf-8")
            tete = s.split("</head>")[0]
            assert f'hreflang="{autre}" href="https://orion-launcher.com{p[autre]}"' in tete, p[lang]
            assert f'<html lang="{lang}">' in s
            titre = re.search(r"<title>(.*?)</title>", s).group(1)
            assert len(titre) <= 62, titre
            for bloc in re.findall(r'<script type="application/ld\+json">(.*?)</script>', s, re.S):
                json.loads(bloc)
            assert "FAQPage" in s and "/#installer" in s
    plan = (d / "sitemap.xml").read_text(encoding="utf-8")
    assert plan.count("<loc>") == 6
    assert "/alternative-gog-galaxy" in (d / "comparatif.html").read_text(encoding="utf-8")
    llms = (d / "llms.txt").read_text(encoding="utf-8")
    assert llms.startswith("# ORION Game Launcher") and "/en/gog-galaxy-alternative" in llms
    # deuxieme passage : rien en double dans le plan ni dans le comparatif
    g.main(d)
    assert (d / "sitemap.xml").read_text(encoding="utf-8").count("<loc>") == 6
    assert (d / "comparatif.html").read_text(encoding="utf-8").count("/alternative-gog-galaxy") == 1


def test_les_pages_ne_promettent_pas_winget_ni_l_absence_de_manette():
    """11 octobre : le site annonçait winget alors que la demande attend Microsoft,
    et le comparatif disait « pas de mode manette » alors qu'ORION en a un."""
    import gen_alternatives as g
    import gen_en
    texte = json.dumps(g.PAGES, ensure_ascii=False)
    assert "winget install" not in texte
    assert "winget install" not in Path(gen_en.__file__).read_text(encoding="utf-8")
    assert "affichage salon" in texte
