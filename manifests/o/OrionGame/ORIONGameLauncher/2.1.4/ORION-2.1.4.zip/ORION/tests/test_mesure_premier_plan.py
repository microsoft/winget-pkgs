"""Mesure des images par seconde (2.1.2) : le 11 octobre, Aniimo est reste
66 minutes en arriere-plan pendant une mesure. Le jeu, bride par lui-meme et
par Windows, ne faisait plus que 15 a 30 images par seconde ; le tri « menus
et chargements » a garde ces images d'attente et jete les vraies (~115 i/s),
et la carte « Votre ecran » annoncait ~20 i/s en Basse."""
from pathlib import Path

from orion.perf import presentmon as pm
from orion.perf import store


def _trace(dossier: Path, morceaux) -> Path:
    """Une trace PresentMon 2.x : (debut en s, fin en s, duree d'une image en ms)."""
    lignes = ["Application,ProcessID,SwapChainAddress,PresentMode,TimeInMs,MsBetweenPresents"]
    for debut, fin, ms in morceaux:
        t = debut * 1000.0
        while t < fin * 1000.0:
            lignes.append(f"Jeu.exe,42,0xA,Composed: Flip,{t:.3f},{ms}")
            t += ms
    chemin = dossier / "capture_x.csv"
    chemin.write_text("\n".join(lignes) + "\n", encoding="utf-8")
    return chemin


def test_les_images_hors_premier_plan_ne_comptent_pas(tmp_path):
    # 60 s de jeu a 125 i/s, puis 120 s en arriere-plan a 30 i/s
    trace = _trace(tmp_path, [(0, 60, 8.0), (60, 180, 33.3)])
    devant = [(float(t), t < 60) for t in range(1, 180)]
    stats = pm.analyse(trace, "x", "recommande", premier_plan=devant)
    assert stats and 115 <= stats["fps_avg"] <= 126, stats
    assert stats["hors_jeu"] > 3000 and not stats.get("douteuse")


def test_sans_releve_la_meme_trace_est_douteuse_et_jamais_retenue(tmp_path):
    trace = _trace(tmp_path, [(0, 60, 8.0), (60, 180, 33.3)])
    stats = pm.analyse(trace, "x", "recommande")
    # l'ancien tri a jete le jeu et garde l'attente : la mesure le dit
    assert stats["ecartees"] > stats["frames"] and stats["douteuse"] is True
    assert not store.fiable(stats)


def test_un_releve_inutilisable_ne_jette_rien(tmp_path):
    # jeu jamais vu devant (sa fenetre appartient a un autre programme) :
    # on ne jette pas toute la partie
    trace = _trace(tmp_path, [(0, 60, 8.0)])
    stats = pm.analyse(trace, "x", "recommande", premier_plan=[(float(t), False) for t in range(60)])
    assert stats and stats["frames"] > 7000 and "hors_jeu" not in stats
    assert pm.secondes_hors_jeu([]) is None
    assert pm.secondes_hors_jeu([(1.0, True)] * 20 + [(21.0, False)]) == {20, 21, 22}


def test_une_mesure_douteuse_ne_remplace_pas_une_bonne(monkeypatch):
    s = store.PerfStore.__new__(store.PerfStore)
    bonne = {"uid": "a", "profile": "recommande", "at": 100, "frames": 200417, "ecartees": 29, "fps_avg": 145.5}
    # la mesure du 11 octobre, enregistree avant la 2.1.2 (sans marque)
    ancienne = {"uid": "a", "profile": "recommande", "at": 200, "frames": 81876, "ecartees": 169789, "fps_avg": 20.7}
    marquee = {"uid": "a", "profile": "recommande", "at": 300, "frames": 9000, "ecartees": 10, "douteuse": True}
    s.runs = [bonne, ancienne, marquee]
    assert s.by_profile("a")["recommande"]["fps_avg"] == 145.5
    s.runs = [ancienne]
    assert s.by_profile("a") == {}


def test_la_capture_releve_le_premier_plan(monkeypatch):
    c = pm.Capture("Aniimo.exe", "x", "recommande", pid=13292)
    c.started_at = 1000.0
    vus = iter([(13292, "Aniimo.exe"), (777, "chrome.exe"), None, (0, ""), (999, "aniimo.exe")])
    monkeypatch.setattr(pm, "processus_au_premier_plan", lambda: next(vus))
    temps = iter([1001.0, 1002.0, 1003.0, 1004.0, 1005.0])
    monkeypatch.setattr(pm.time, "time", lambda: next(temps))

    class Arret:
        n = 0

        def wait(self, _delai):
            Arret.n += 1
            return Arret.n > 5
    c._veille_stop = Arret()
    c._veiller()
    # le releve inconnu (None) n'est pas compte ; le nom suffit si le numero differe
    assert c.premier_plan == [(1.0, True), (2.0, False), (3.0, False), (4.0, True)]
