"""Apprentissage par l'exemple (10 octobre, « ca va etre chiant s'il faut
tout refaire jeu par jeu ») : le joueur choisit des niveaux dans le menu du
jeu, ORION retient ce que le jeu ecrit et le reecrit ensuite seul."""
from __future__ import annotations

from pathlib import Path

from orion.core.models import Game
from orion.optimizer import exemple
from test_tous_les_jeux import BG3, _env, _hw

INI = """[Graphics]
ShadowQuality={ombres}
TextureQuality={textures}
ResolutionX=2560
WindowMode=1
[Account]
LastUserId={compte}
"""


def _ecrire(f: Path, **v) -> None:
    f.write_text(INI.format(**v), encoding="utf-8")


def test_ce_que_le_jeu_ecrit_pour_chaque_niveau(tmp_path, monkeypatch):
    _env(tmp_path, monkeypatch)
    f = tmp_path / "local" / "Jeu Maison" / "settings.ini"
    f.parent.mkdir(parents=True)
    jeu = Game(title="Jeu Maison", source="steam", source_id="42", install_dir=str(tmp_path / "jeu"))
    photos = {}
    for etape, ombres, textures, compte in (("bas", 0, "Low", "a1"), ("moyen", 1, "Medium", "b2"),
                                            ("haut", 3, "Epic", "c3")):
        _ecrire(f, ombres=ombres, textures=textures, compte=compte)
        photos[etape] = exemple.photographier(jeu)
    r = exemple.recette(jeu, photos)
    assert r and r["id"] == "exemple_jeu_maison" and r["match"] == {"title": ["Jeu Maison"], "appid": [42]}
    (t,) = r["targets"]
    assert t["format"] == "ini" and t["paths"] == ["%LOCALAPPDATA%/Jeu Maison/settings.ini"]
    cles = {e["key"]: r["derive"][e["value"].strip("{}")]["map"] for e in t["entries"]}
    # exactement les valeurs du jeu ; Haute = l'etape « eleve » sinon le plus haut ;
    # jamais la definition, la fenetre ni un identifiant de compte
    assert cles == {"ShadowQuality": {"0": "0", "1": "1", "2": "3", "3": "3"},
                    "TextureQuality": {"0": "Low", "1": "Medium", "2": "Epic", "3": "Epic"}}
    assert "a1" not in str(r) and str(tmp_path) not in str(r)      # rien de personnel


def test_sans_etape_moyenne_la_moyenne_reprend_le_plus_bas(tmp_path, monkeypatch):
    _env(tmp_path, monkeypatch)
    f = tmp_path / "local" / "Jeu Maison" / "settings.ini"
    f.parent.mkdir(parents=True)
    jeu = Game(title="Jeu Maison", source="dossier", install_dir=str(tmp_path / "jeu"))
    _ecrire(f, ombres=0, textures="Low", compte="x"); bas = exemple.photographier(jeu)
    _ecrire(f, ombres=3, textures="Epic", compte="x"); haut = exemple.photographier(jeu)
    r = exemple.recette(jeu, {"bas": bas, "haut": haut})
    carte = r["derive"]["ex_0"]["map"] if "ex_0" in r["derive"] else next(iter(r["derive"].values()))["map"]
    assert carte["1"] == carte["0"]
    assert exemple.recette(jeu, {"bas": bas, "haut": bas}) is None   # rien n'a change


def test_baldurs_gate_3_garde_la_definition_de_la_recette_livree(tmp_path, monkeypatch, ):
    _env(tmp_path, monkeypatch)
    f = tmp_path / "local" / "Larian Studios" / "Baldur's Gate 3" / "graphicSettings.lsx"
    f.parent.mkdir(parents=True)
    jeu = Game(title="Baldur's Gate 3", source="steam", source_id="1086940", install_dir=str(tmp_path / "jeu"))
    base = exemple.base_du_jeu(jeu)
    assert base and base["id"] == "baldurs_gate_3"
    photos = {}
    for etape, valeur in (("bas", "Bas_du_jeu"), ("haut", "Ultra")):
        f.write_text(BG3.replace('value="Custom"', f'value="{valeur}"'), "utf-8")
        photos[etape] = exemple.photographier(jeu, base)      # le fichier designe par la recette connue
    r = exemple.recette(jeu, photos, base)
    cles = [e["key"] for t in r["targets"] for e in t["entries"]]
    # le niveau appris remplace celui de la recette livree (« Low » etait faux) ;
    # la definition et la synchronisation restent
    assert cles.count("attribute[value=CurrentSettings]/attribute[id=Value]@value") == 1
    assert any("ScreenWidth" in c for c in cles) and any("VSync" in c for c in cles)
    appris = next(e for t in r["targets"] for e in t["entries"] if "CurrentSettings" in e["key"])
    assert r["derive"][appris["value"].strip("{}")]["map"] == {"0": "Bas_du_jeu", "1": "Bas_du_jeu",
                                                                "2": "Ultra", "3": "Ultra"}
    assert not any("config.lsf" in a for a in r["advice"])


def test_la_recette_apprise_est_ecrite_par_orion(tmp_path, monkeypatch):
    from orion.optimizer.engine import Optimizer, Recipe
    from orion.optimizer import securite
    _env(tmp_path, monkeypatch)
    f = tmp_path / "local" / "Jeu Maison" / "settings.ini"
    f.parent.mkdir(parents=True)
    jeu = Game(title="Jeu Maison", source="dossier", install_dir=str(tmp_path / "jeu"))
    _ecrire(f, ombres=0, textures="Low", compte="x"); bas = exemple.photographier(jeu)
    _ecrire(f, ombres=3, textures="Epic", compte="x"); haut = exemple.photographier(jeu)
    r = exemple.recette(jeu, {"bas": bas, "haut": haut})
    assert securite.verifier_recette(r, partagee=True)[0]          # passe le controle des recettes partagees
    moteur = Optimizer()
    moteur._recipes = [Recipe(r, tmp_path / "exemple_jeu_maison.json")]
    hw, ecran = _hw()
    plan = moteur.build_plan(jeu, "recommande", hw, ecran)
    ok, msg = moteur.apply_plan(jeu, plan)
    assert ok, msg
    texte = f.read_text("utf-8")
    assert "ShadowQuality=" in texte and "ResolutionX=2560" in texte and "LastUserId=x" in texte


def test_rien_qui_ressemble_a_un_identifiant():
    from orion.optimizer.exemple import _EXCLUES, _valeur_simple
    for v in ("0", "3", "1.5", "true", "Ultra", "DeepLearningSuperSampling", "x16", "Anisotropic16x"):
        assert _valeur_simple(v), v
    for v in ("1791581100", "e3b0c44298fc1c14", "a8f5f167f44f4964e6c998dee827110c", "user@mail.fr", "C:/x"):
        assert not _valeur_simple(v), v
    for nom in ("LastUserId", "SteamID", "uid", "PlayerName", "DeviceId", "Email", "SessionCount", "playTime"):
        assert _EXCLUES.search(nom), nom
    for nom in ("ShadowQuality", "CBT2_VideoQuality", "TextureQuality", "AntiAliasing", "CurrentSettings"):
        assert not _EXCLUES.search(nom), nom


def _larian(entrees: dict) -> str:
    """Un graphicSettings.lsx de Baldur's Gate 3 avec ces entrees (nom -> (Type, type, valeur))."""
    noeuds = "".join(
        f'''                <node id="ConfigEntry">
                    <attribute id="MapKey" type="FixedString" value="{k}"/>
                    <attribute id="Type" type="int32" value="{c}"/>
                    <attribute id="Value" type="{ty}" value="{v}"/>
                </node>
''' for k, (c, ty, v) in entrees.items())
    return ('<?xml version="1.0" encoding="UTF-8"?>\n<save>\n    <region id="Config">\n        <node id="root">\n'
            '            <children>\n' + noeuds + '            </children>\n        </node>\n    </region>\n</save>\n')


def test_baldurs_gate_3_reglages_ecrits_seulement_hors_defaut(tmp_path, monkeypatch):
    """10 octobre, essai de l'auteur : Baldur's Gate 3 n'ecrit une option que
    si elle differe de sa valeur par defaut. En Ultra (le defaut) les options
    sont absentes ; en Bas, presentes. L'apprentissage les retient (absentes =
    defaut du jeu), et ORION les ajoute ou les retire selon le niveau."""
    from orion.optimizer.engine import Optimizer, Recipe
    from orion.plugins.tweaks.xml_writer import ABSENT
    _env(tmp_path, monkeypatch)
    f = tmp_path / "local" / "Larian Studios" / "Baldur's Gate 3" / "graphicSettings.lsx"
    f.parent.mkdir(parents=True)
    jeu = Game(title="Baldur's Gate 3", source="steam", source_id="1086940", install_dir=str(tmp_path / "jeu"))
    base = exemple.base_du_jeu(jeu)
    commun = {"ScreenWidth": ("0", "int32", "2560"), "ScreenHeight": ("0", "int32", "1440"),
              "VSync": ("0", "int32", "0")}
    niveaux = {
        "bas": {"CurrentSettings": ("4", "LSString", "Low"), "TextureDetail": ("0", "int32", "0"),
                "ShadowQuality": ("0", "int32", "0"), "CASSharpness": ("2", "float", "0.19")},
        "moyen": {"CurrentSettings": ("4", "LSString", "Medium"), "TextureDetail": ("0", "int32", "1"),
                  "CASSharpness": ("2", "float", "0.19")},
        "eleve": {"CurrentSettings": ("4", "LSString", "High"), "CASSharpness": ("2", "float", "0.19")},
        "haut": {"CASSharpness": ("2", "float", "0.19")},            # Ultra : tout par defaut
    }
    photos = {}
    for etape, entrees in niveaux.items():
        f.write_text(_larian({**commun, **entrees}), "utf-8")
        photos[etape] = exemple.photographier(jeu, base)
    r = exemple.recette(jeu, photos, base)
    assert r
    from orion.optimizer import securite
    assert securite.verifier_recette(r, partagee=True)[0]          # partageable aux autres joueurs
    assert r["_appris"]["format"] == 2
    import re
    simple = re.compile(r"^-?\d{1,10}(\.\d{1,8})?$|^(true|false|True|False)$|^[A-Za-z][A-Za-z0-9_\-]{0,39}$")
    worker = (Path(__file__).resolve().parents[1] / "service" / "worker.js").read_text("utf-8")
    assert simple.pattern.replace("\\", "") in worker.replace("\\", "")    # meme regle que le service
    assert all(simple.match(str(v)) for d in r["derive"].values() for v in d["map"].values())
    cartes = {e["key"].split("]")[0].split("=")[1]: (r["derive"][e["value"].strip("{}")]["map"], e)
              for t in r["targets"] for e in t["entries"] if e["value"].startswith("{ex_")}
    assert set(cartes) == {"CurrentSettings", "TextureDetail", "ShadowQuality"}   # pas CASSharpness (constant)
    assert cartes["TextureDetail"][0] == {"0": "0", "1": "1", "2": ABSENT, "3": ABSENT}
    assert cartes["ShadowQuality"][0] == {"0": "0", "1": ABSENT, "2": ABSENT, "3": ABSENT}
    assert cartes["TextureDetail"][1]["section"] == "larian=0:int32" and cartes["TextureDetail"][1]["creer"]
    # ORION ecrit Basse depuis un fichier en Ultra : les entrees sont ajoutees
    f.write_text(_larian({**commun, **niveaux["haut"]}), "utf-8")
    moteur = Optimizer()
    moteur._recipes = [Recipe(r, tmp_path / "exemple_baldur_s_gate_3.json")]
    hw, ecran = _hw()
    from orion.optimizer import choix as choix_mod
    for niveau, attendu_present in (("basse", True), ("ultra", False)):
        choix_mod.choisir(jeu, niveau, 60)
        plan = moteur.build_plan(jeu, "recommande", hw, ecran)
        ok, msg = moteur.apply_plan(jeu, plan)
        assert ok, msg
        t = f.read_text("utf-8")
        assert ('value="TextureDetail"' in t) is attendu_present, (niveau, t)
        assert ('value="ShadowQuality"' in t) is attendu_present
        assert t.count('value="ScreenWidth"') == 1 and 'value="0.19"' in t        # le reste intact
    # relu apres ecriture : rien de plus a faire (pas de « deja en place » trompeur avant)
    plan = moteur.build_plan(jeu, "recommande", hw, ecran)
    assert not [o for o in plan.ops if o.changed]


def test_niveaux_de_bg3_appris_avant_le_correctif_ignores(tmp_path, monkeypatch):
    """La recette apprise le 10 octobre sur le PC de l'auteur ne retenait que
    « CurrentSettings » (« Appris : 1 reglage ») : elle faisait dire « deja en
    place » en Basse comme en Ultra. Elle est ignoree ; une recette apprise
    avec le correctif (format 2) est gardee."""
    from orion.optimizer import engine
    vieille = {"id": "exemple_baldur_s_gate_3", "_appris": {"cles": 1},
               "targets": [{"format": "xml", "paths": ["%LOCALAPPDATA%/Larian Studios/Baldur's Gate 3/graphicSettings.lsx"],
                            "entries": []}]}
    assert engine._apprise_perimee(vieille)
    assert not engine._apprise_perimee(dict(vieille, _appris={"cles": 9, "format": 2}))
    assert not engine._apprise_perimee(dict(vieille, id="baldurs_gate_3"))
    ini = dict(vieille, targets=[{"format": "ini", "paths": ["%LOCALAPPDATA%/Jeu/settings.ini"], "entries": []}])
    assert not engine._apprise_perimee(ini)                 # les autres jeux appris restent
