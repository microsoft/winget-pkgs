"""Page Sorties : fichier en ligne abime, visuels Steam, reseau (revue de code)."""
import datetime as dt
import json

import pytest

from orion import en_ligne
from orion import sorties as S


# ----------------------------------------------------------------------
# 1. fichier en ligne mal forme
# ----------------------------------------------------------------------
@pytest.mark.parametrize("doc", [
    None, [], "texte", 42, {"sorties": None}, {"sorties": {"a": 1}},
    {"sorties": "abc"}, {"sorties": [None, "x", 3, [], {"titre": None}]},
])
def test_lire_ne_leve_jamais(doc):
    assert S.lire(doc) == []


def test_entrees_abimees_ignorees_les_bonnes_gardees():
    doc = {"format": 1, "maj": "2099-01-01", "sorties": [
        None, "texte", {"id": "a"}, {"titre": "Sans id"},
        {"id": {"x": 1}, "titre": "Id objet"},
        {"id": "ok", "titre": "Bon jeu", "date": "2099-05-01",
         "couleurs": ["rouge", "#FFF"], "plateformes": "pc", "attente": "beaucoup",
         "steam": "12ab", "lien": "javascript:alert(1)", "rang": [1]},
        {"id": "ok2", "titre": "Autre", "fenetre": "2099", "couleurs": ["#112233", "#445566"],
         "plateformes": ["pc", "n64", None], "steam": 1234, "vedette": True},
    ]}
    liste = S.lire(doc)
    assert [s.id for s in liste] == ["ok", "ok2"]
    ok, ok2 = liste
    assert ok.couleurs == S.COULEURS_DEFAUT          # couleurs invalides remplacees
    assert ok.plateformes == () and ok.attente == 0 and ok.steam == "" and ok.lien == ""
    assert ok.rang == 0
    assert ok2.couleurs == ("#112233", "#445566") and ok2.plateformes == ("pc",)
    assert ok2.steam == "1234" and ok2.attente == 100


@pytest.mark.parametrize("couleurs", [None, "#112233", ["#112233"], [1, 2], ["#12345", "#123456"],
                                      {"a": "#112233", "b": "#445566"}, ["#GGGGGG", "#000000"]])
def test_couleurs_validees(couleurs):
    assert S.couleurs_valides(couleurs) == S.COULEURS_DEFAUT


def test_choisir_document_abime_rend_l_embarquee():
    for distant in (None, [], {"format": "x"}, {"format": 1, "maj": 20990101, "sorties": []},
                    {"format": 1, "maj": "2099-01-01", "sorties": {"id": "x"}},
                    {"format": 1, "maj": "2099-01-01", "sorties": [None, "x"]}):
        liste, maj = S.choisir(distant)
        assert maj == S.MAJ and len(liste) == len(S.embarquee())


def test_charger_ne_leve_jamais(monkeypatch):
    from orion.core import reseau
    monkeypatch.setattr(reseau, "get_json", lambda *a, **k: {"format": 1, "maj": "2099-01-01",
                                                              "sorties": [None, 1, "x"]})
    monkeypatch.setattr(S, "charger_steam", lambda: [])
    liste, maj = S.charger()
    assert liste and maj == S.MAJ
    liste, maj, en_ligne_ = S.charger_etat()
    assert en_ligne_ is True                   # le fichier a ete lu, meme inutilisable

    def panne(*a, **k):
        raise OSError("hors ligne")
    monkeypatch.setattr(reseau, "get_json", panne)
    liste, maj, en_ligne_ = S.charger_etat()
    assert liste and en_ligne_ is False        # hors ligne : liste embarquee, a refaire

    monkeypatch.setattr(S, "fusionner", lambda *a: 1 / 0)
    liste, maj, en_ligne_ = S.charger_etat()
    assert liste and maj == S.MAJ


def test_carte_et_affiche_peintes_meme_abimees(qapp_sorties):
    from PySide6.QtGui import QImage, QPainter
    from orion.ui.views.sorties_view import CarteSortie, Vedette
    s = S.Sortie("x", "Titre", date="2099-01-01", couleurs=("pas", "une couleur"))
    c = CarteSortie(s, 300)
    v = Vedette()
    v.resize(900, 440)
    v.definir(s)
    for w in (c, v):
        img = QImage(w.size(), QImage.Format.Format_ARGB32)
        w.render(img)
    # une donnee qui fait echouer la peinture ne doit pas remonter
    c.s = None
    img = QImage(c.size(), QImage.Format.Format_ARGB32)
    c.render(img)
    assert not QPainter(img).isActive() or True


@pytest.fixture
def qapp_sorties():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


# ----------------------------------------------------------------------
# 3. fusion : jamais sur une cle vide
# ----------------------------------------------------------------------
def test_fusion_titres_non_latins_pas_confondus():
    officielles = [S.Sortie("jp1", "ドラゴンクエスト XII", date="2099-01-01")]
    steam = [S.Sortie("steam-1", "モンスターハンター", date="2099-02-01", steam="1", rang=3),
             S.Sortie("steam-2", "ファイナルファンタジー", date="2099-03-01", steam="2", rang=4)]
    tout = S.fusionner(officielles, steam)
    assert [s.id for s in tout] == ["jp1", "steam-1", "steam-2"]
    assert tout[0].rang == 0


def test_fusion_ponctuation_et_chiffres_romains():
    officielles = [S.Sortie("rs", "RuneScape - Dragonwilds", date="2099-01-01")]
    steam = [S.Sortie("steam-9", "RuneScape: Dragonwilds", date="2099-01-01", steam="9", rang=7),
             S.Sortie("steam-10", "Hades II", date="2099-01-01", steam="10", rang=8)]
    tout = S.fusionner(officielles + [S.Sortie("h", "Hades 2", fenetre="2099")], steam)
    assert [s.id for s in tout] == ["rs", "h"]
    assert tout[0].rang == 7 and tout[1].rang == 8


# ----------------------------------------------------------------------
# 2. visuels : cache negatif et limitation Steam
# ----------------------------------------------------------------------
class _Rep:
    def __init__(self, corps, code=200):
        self._corps, self.status_code, self.headers = corps, code, {}

    def json(self):
        if isinstance(self._corps, Exception):
            raise self._corps
        return self._corps


@pytest.fixture
def visuels_tmp(monkeypatch, tmp_path):
    from orion.core import reseau, steam_limite
    monkeypatch.setattr(S, "dossier_visuels", lambda: tmp_path)
    monkeypatch.setattr(steam_limite, "en_pause", lambda: False)
    reseau.lever_pauses()
    yield tmp_path
    reseau.lever_pauses()


def test_fiche_sans_image_memorisee_24_h(monkeypatch, visuels_tmp):
    from orion.core import reseau
    appels = []

    def faux_get(url, **kw):
        appels.append(url)
        return _Rep({"77": {"success": False}})

    monkeypatch.setattr(reseau, "get", faux_get)
    s = S.Sortie("steam-77", "Sans fiche", steam="77")
    assert S.telecharger_visuels(s) == {}
    assert S.telecharger_visuels(s) == {}
    # (un fil d'arriere-plan d'un autre test peut lire les mesures partagees)
    assert len([u for u in appels if "steampowered" in u]) == 1   # pas avant 24 h
    assert S.sans_visuel_recent(s)
    assert not S.sans_visuel_recent(s, dt.datetime.now() + dt.timedelta(hours=25))
    # fiche avec donnees mais sans aucune image : meme chose
    monkeypatch.setattr(reseau, "get", lambda url, **kw: _Rep(
        {"78": {"success": True, "data": {"name": "x", "developers": ["Studio"]}}}))
    s2 = S.Sortie("steam-78", "Sans image", steam="78")
    S.telecharger_visuels(s2)
    assert S.sans_visuel_recent(s2)


def test_reponse_vide_steam_limite_et_boucle_arretee(monkeypatch, visuels_tmp):
    from orion.core import reseau, steam_limite
    pause = []
    monkeypatch.setattr(steam_limite, "signaler_refus", lambda: pause.append(1))
    monkeypatch.setattr(steam_limite, "en_pause", lambda: bool(pause))
    appels = []

    def faux_get(url, **kw):
        appels.append(kw["params"]["appids"])
        return _Rep(None)                       # corps « null »

    monkeypatch.setattr(reseau, "get", faux_get)
    liste = [S.Sortie(f"steam-{n}", f"Jeu {n}", steam=str(n)) for n in (1, 2, 3)]
    out = S.illustrer(liste)
    assert pause == [1] and appels == ["1"]      # arret des la premiere reponse vide
    assert list(out) == ["steam-1"]
    assert not S.sans_visuel_recent(liste[0])    # pas de cache negatif : on reessaiera


def test_illustration_arretee_par_une_partie(monkeypatch, visuels_tmp):
    from orion.core import reseau
    appels = []
    monkeypatch.setattr(reseau, "get", lambda url, **kw: appels.append(1) or _Rep({}))
    liste = [S.Sortie(f"steam-{n}", f"Jeu {n}", steam=str(n)) for n in (1, 2)]
    assert S.illustrer(liste, arreter=lambda: True) == {}
    assert appels == []


def test_visuels_meta_abime(visuels_tmp):
    s = S.Sortie("steam-5", "Jeu", steam="5")
    (visuels_tmp / "5-meta.json").write_text(json.dumps(["pas", "un", "dict"]), encoding="utf-8")
    assert S.visuels(s) == {}


# ----------------------------------------------------------------------
# 4. joueurs en ligne : le rafraichissement de 5 minutes rafraichit
# ----------------------------------------------------------------------
def test_joueurs_releve_rafraichi_avec_marge(monkeypatch):
    from orion.core import reseau
    appels = []

    class R:
        status_code = 200

        def json(self):
            return {"response": {"player_count": len(appels), "result": 1}}

    monkeypatch.setattr(reseau, "get", lambda url, **kw: appels.append(1) or R())
    en_ligne._memo.clear()
    en_ligne.joueurs("730", maintenant=1000)
    en_ligne.joueurs("730", maintenant=1000 + en_ligne.GARDER - 1)   # minuterie de 5 min
    assert len(appels) == 2
    en_ligne.joueurs("730", maintenant=1000 + en_ligne.GARDER + 60)
    assert len(appels) == 2                                          # garde de nouveau


# ----------------------------------------------------------------------
# 7. telechargement : reponse fermee, pas de reste .partiel
# ----------------------------------------------------------------------
class _Flux:
    def __init__(self, morceaux, total=0, erreur=None):
        self.morceaux, self.erreur = morceaux, erreur
        self.headers = {"Content-Length": str(total)} if total else {}
        self.ferme = False

    def raise_for_status(self):
        pass

    def iter_content(self, chunk_size=0):
        for m in self.morceaux:
            yield m
        if self.erreur:
            raise self.erreur

    def close(self):
        self.ferme = True


def test_telecharger_ferme_et_nettoie(monkeypatch, tmp_path):
    from orion.core import reseau
    cible = tmp_path / "f.jpg"
    flux = _Flux([b"abc", b"def"])
    monkeypatch.setattr(reseau, "requete", lambda *a, **k: flux)
    assert reseau.telecharger("https://x.example/f", cible) == 6
    assert cible.read_bytes() == b"abcdef" and flux.ferme

    for f in (_Flux([b"abc"], erreur=ConnectionError("coupe")), _Flux([b"abc"], total=10)):
        monkeypatch.setattr(reseau, "requete", lambda *a, _f=f, **k: _f)
        with pytest.raises(Exception):
            reseau.telecharger("https://x.example/g", tmp_path / "g.jpg")
        assert f.ferme
        assert not (tmp_path / "g.jpg.partiel").exists()
        assert not (tmp_path / "g.jpg").exists()


def test_telecharger_annule_par_la_progression(monkeypatch, tmp_path):
    from orion.core import reseau
    monkeypatch.setattr(reseau, "requete", lambda *a, **k: _Flux([b"a" * 10], total=10))

    def annuler(ecrit, total):
        raise KeyboardInterrupt

    with pytest.raises(KeyboardInterrupt):
        reseau.telecharger("https://x.example/h", tmp_path / "h.bin", progression=annuler)
    assert list(tmp_path.iterdir()) == []


# ----------------------------------------------------------------------
# 5 et 6. fenetre : hors ligne au demarrage, arret pendant une partie
# ----------------------------------------------------------------------
class _VueFactice:
    def __init__(self):
        self._montrees = []
        self.definitions = []

    def definir(self, liste, maj):
        self.definitions.append((len(liste), maj))

    def set_visuels(self, v):
        pass

    def set_prix_cartes(self, prix):
        pass

    def set_offre(self, o):
        pass

    class vedette:                       # noqa: N801 (pas de sortie a la une)
        s = None

    def a_illustrer(self):
        return []


def _fenetre():
    from orion.ui.sorties_mixin import SortiesMixin

    class F(SortiesMixin):
        en_partie = False

        def _differer(self, nom):
            self.differe = nom
            return False
    f = F()
    f.sorties_view = _VueFactice()
    f._sorties_lues = 0.0
    f._sorties_en_ligne = False
    f._sorties_occupe = False
    f._visuels_occupe = False
    f._offre_occupe = False
    return f


def test_demarrage_hors_ligne_pas_d_attente_de_6_h(monkeypatch):
    import time
    from orion.ui import sorties_mixin as M
    f = _fenetre()
    relances = []
    f.charger_sorties = lambda auto=False: relances.append(auto)
    M.SortiesMixin._sorties_chargees(f, (S.embarquee(), S.MAJ, False))
    assert time.time() - f._sorties_lues >= S.GARDER - M.REESSAI_HORS_LIGNE - 5
    assert not f._sorties_en_ligne
    M.SortiesMixin._sorties_reseau(f, True)          # retour du reseau
    assert relances == [False]
    M.SortiesMixin._sorties_chargees(f, (S.embarquee(), S.MAJ, True))
    assert time.time() - f._sorties_lues < 5 and f._sorties_en_ligne
    M.SortiesMixin._sorties_reseau(f, True)          # deja lue : rien a refaire
    assert relances == [False]


def test_arret_des_visuels_pendant_une_partie():
    from orion.core.config import CONFIG
    from orion.ui import sorties_mixin as M
    f = _fenetre()
    assert not f._sorties_a_arreter()
    f.en_partie = True
    CONFIG.set("jeu.discret", True)
    assert f._sorties_a_arreter()
    M.SortiesMixin._visuels_sorties(f, {})
    assert f.differe == "sorties"                    # repris a la fin de la partie


# ----------------------------------------------------------------------
# complements (audit) : version gardee hors ligne, image retiree, arret
# ----------------------------------------------------------------------
def test_version_gardee_hors_ligne_pas_consideree_comme_lue(monkeypatch):
    """Hors ligne, `get_json` rend la copie d'une session precedente : elle
    s'affiche, mais la lecture sera refaite au retour du reseau."""
    from orion.core import reseau
    doc = {"format": 1, "maj": "2099-01-01",
           "sorties": [{"id": "a", "titre": "Jeu A", "date": "2099-05-01"}]}
    monkeypatch.setattr(reseau, "get_json", lambda *a, **k: doc)
    monkeypatch.setattr(S, "charger_steam", lambda: [])
    monkeypatch.setattr(reseau, "hors_ligne", lambda: True)
    liste, maj, lue = S.charger_etat()
    assert [s.id for s in liste] == ["a"] and maj == "2099-01-01" and lue is False
    monkeypatch.setattr(reseau, "hors_ligne", lambda: False)
    assert S.charger_etat()[2] is True


class _ErreurHttp(Exception):
    def __init__(self, code):
        super().__init__(f"HTTP {code}")
        self.response = type("R", (), {"status_code": code})()


def _fiche(appid):
    return _Rep({appid: {"success": True, "data": {
        "header_image": "https://cdn.example/h.jpg",
        "screenshots": [{"path_full": "https://cdn.example/s.jpg"}]}}})


def test_images_retirees_memorisees_24_h(monkeypatch, visuels_tmp):
    from orion.core import reseau
    appels = []
    monkeypatch.setattr(reseau, "get", lambda url, **kw: appels.append(url) or _fiche("41"))

    def absent(url, cible, **kw):
        raise _ErreurHttp(404)
    monkeypatch.setattr(reseau, "telecharger", absent)
    s = S.Sortie("steam-41", "Images retirees", steam="41")
    assert S.telecharger_visuels(s) == {}
    assert S.sans_visuel_recent(s)
    S.telecharger_visuels(s)
    # (un fil d'arriere-plan d'un autre test peut lire les mesures partagees)
    assert len([u for u in appels if "steampowered" in u]) == 1   # pas avant 24 h


def test_image_en_panne_reseau_pas_de_cache_negatif(monkeypatch, visuels_tmp):
    from orion.core import reseau
    monkeypatch.setattr(reseau, "get", lambda url, **kw: _fiche("42"))

    def coupe(url, cible, **kw):
        raise ConnectionError("coupe")
    monkeypatch.setattr(reseau, "telecharger", coupe)
    s = S.Sortie("steam-42", "Coupure", steam="42")
    S.telecharger_visuels(s)
    assert not S.sans_visuel_recent(s)


def test_partie_commencee_entre_deux_images(monkeypatch, visuels_tmp):
    from orion.core import reseau
    monkeypatch.setattr(reseau, "get", lambda url, **kw: _fiche("43"))
    faits = []

    def telecharger(url, cible, **kw):
        faits.append(url)
        cible.write_bytes(b"x" * 2000)
    monkeypatch.setattr(reseau, "telecharger", telecharger)
    s = S.Sortie("steam-43", "Arret", steam="43")
    out = S.telecharger_visuels(s, arreter=lambda: bool(faits))
    assert len(faits) == 1 and "carte" in out and "fond" not in out
