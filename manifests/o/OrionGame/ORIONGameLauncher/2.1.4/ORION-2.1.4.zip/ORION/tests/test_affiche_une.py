"""Affiche de la sortie a la une (10 octobre, capture de l'auteur) : les
boutons de prix ne couvrent plus le compte a rebours, et la cle choisie a la
main dit ce qu'elle est (Kinguin vend une cle Microsoft Store, pas Steam)."""
import time

import pytest


@pytest.fixture
def app():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


def _une():
    from orion import sorties as S
    return next(s for s in S.embarquee() if s.id == "cod-mw4")


def _offre(s):
    from orion import prix_revendeurs
    from orion.precommandes import Offre
    o = Offre(appid=s.steam, titre=s.titre, url="https://store.steampowered.com/app/4435490/",
              prix=69.99, normal=69.99, lu_le=time.time())
    o.cle = {"prix": 61.97, "devise": "EUR", "site": "kinguin", "boutique": "Kinguin", "choisi": True,
             "url": "https://www.kinguin.net/fr/category/536535/call-of-duty-modern-warfare-4-pre-order-eu-pc-windows-cd-key"}
    o.cle["libelle"] = prix_revendeurs.libelle(o.cle, s)
    o.fidelite = s.fidelite["texte"] if s.fidelite else ""
    return o


def test_libelle_de_la_cle_choisie():
    from orion import prix_revendeurs
    s = _une()
    o = _offre(s)
    assert o.cle["libelle"] == "Cle Microsoft Store PC (Europe, precommande)"
    assert "Steam" not in o.texte_cle
    assert prix_revendeurs.libelle({"prix": 30, "url": "https://www.kinguin.net/x"}) == "Cle Steam verifiee"


def test_le_choix_du_service_est_garde():
    from orion import prix_revendeurs
    brut = {"prix": 61.97, "devise": "EUR", "url": "https://www.kinguin.net/fr/category/536535/x",
            "note": 98.7, "ventes": 139987, "vendeur": "V", "choisi": True}
    assert prix_revendeurs._valider("kinguin", brut)["choisi"] is True
    brut.pop("choisi")
    assert "choisi" not in prix_revendeurs._valider("kinguin", brut)


@pytest.mark.parametrize("largeur", [900, 1280, 1900])
def test_boutons_sous_le_compte_a_rebours(app, largeur):
    from orion.ui.views.sorties_view import Vedette
    s = _une()
    v = Vedette()
    v.resize(largeur, 440)
    v.definir(s)
    v.set_offre(_offre(s))
    v.show()
    app.processEvents()
    v.resize(largeur, v.sizeHint().height())
    app.processEvents()
    bas_affiche = v.hauteur_affiche()
    assert v.b_precommander.isVisible() and v.b_cle.isVisible()
    assert v.b_precommander.geometry().top() >= bas_affiche - 4
    assert v.b_cle.geometry().top() >= bas_affiche - 4
    assert v.b_ouvrir.geometry().bottom() <= v.height()
    assert "Steam" not in v.b_cle.text()
    v.close()
