"""Modules de la 1.7 : mise a jour, base, reseau, securite, detection..."""
import json
import zipfile

import pytest

from orion.core.models import Game


# -- version et journal ---------------------------------------------------
def test_journal_a_jour():
    from orion.nouveautes import JOURNAL
    from orion.version import APP_VERSION
    assert JOURNAL[0]["version"] == APP_VERSION, \
        "nouveautes.py doit decrire la version courante (regle du projet)"


def test_versions():
    from orion.maj import plus_recente, version_tuple
    assert version_tuple("v1.7.0") == (1, 7, 0)
    assert version_tuple("1.7") == (1, 7, 0)
    assert plus_recente("1.10.0", "1.9.9")
    assert not plus_recente("v1.6.2", "1.6.2")


def test_publication_github_avec_digest():
    from orion.maj import lire_publication
    pub = lire_publication({"tag_name": "v9.0.0", "name": "ORION 9", "body": "- Truc\n- Machin",
                            "assets": [{"name": "Installateur-ORION.exe", "size": 5,
                                        "browser_download_url": "https://x/y.exe",
                                        "digest": "sha256:" + "a" * 64}]})
    assert pub.disponible and pub.verifiable
    assert pub.sha256 == "a" * 64
    assert pub.points == ["Truc", "Machin"]


def test_publication_empreinte_dans_les_notes():
    from orion.maj import lire_publication
    pub = lire_publication({"tag_name": "v9.0.0", "body": "SHA-256 :\n```\n" + "B" * 64 + "\n```",
                            "assets": [{"name": "Installateur-ORION.exe",
                                        "browser_download_url": "https://x/y.exe"}]})
    assert pub.sha256 == "b" * 64 and pub.verifiable


def test_brouillon_ignore():
    from orion.maj import lire_publication
    assert not lire_publication({"tag_name": "v9.0.0", "draft": True}).version


# -- base SQLite ------------------------------------------------------------
def test_document_migration_json(base_neuve, tmp_path):
    ancien = tmp_path / "library.json"
    ancien.write_text(json.dumps({"games": [1, 2]}), "utf-8")
    doc = base_neuve.Document("bibliotheque", ancien)
    assert doc.lire() == {"games": [1, 2]}
    assert not ancien.exists() and (tmp_path / "library.json.avant-sqlite").exists()
    doc.ecrire({"games": [3]})
    assert base_neuve.Document("bibliotheque").lire() == {"games": [3]}


def test_table_bornee(base_neuve):
    t = base_neuve.Table("essai", maximum=10)
    for i in range(30):
        t.set(str(i), {"v": i})
    assert len(t) <= 11
    assert t.get("29") == {"v": 29}
    assert t.get("0") is None


def test_base_abimee_reconstruite(base_neuve, tmp_path):
    f = tmp_path / "orion.db"
    base_neuve.fermer()
    f.write_bytes(b"ceci n'est pas une base sqlite" * 100)
    base_neuve.Document("x").ecrire({"ok": 1})
    assert base_neuve.Document("x").lire() == {"ok": 1}
    assert list(tmp_path.glob("orion.abimee-*.db"))


# -- reseau -----------------------------------------------------------------
class _Rep:
    def __init__(self, code, entetes=None):
        self.status_code = code
        self.headers = entetes or {}


class _Session:
    def __init__(self, code, entetes=None):
        self.code, self.entetes, self.appels = code, entetes, 0

    def request(self, methode, url, **kw):
        self.appels += 1
        return _Rep(self.code, self.entetes)


def test_pause_apres_refus(monkeypatch):
    from orion.core import reseau
    reseau.lever_pauses()
    s = _Session(429, {"Retry-After": "120"})
    monkeypatch.setattr(reseau, "_session", lambda: s)
    r = reseau.get("https://api.example.org/x")
    assert r.status_code == 429
    assert reseau.en_pause("api.example.org")
    with pytest.raises(reseau.HoteEnPause):
        reseau.get("https://api.example.org/y")
    assert s.appels == 1                        # le second appel n'est pas parti
    reseau.lever_pauses()


def test_steam_403_est_un_refus(monkeypatch):
    from orion.core import reseau, steam_limite
    reseau.lever_pauses()
    monkeypatch.setattr(reseau, "_session", lambda: _Session(403))
    monkeypatch.setitem(reseau.POLITIQUES, "steampowered.com",
                        reseau.Politique(ecart=0, pause_refus=300, refus_403=True))
    reseau.get("https://store.steampowered.com/api/appdetails")
    assert steam_limite.en_pause()
    reseau.lever_pauses()


def test_hote_en_pause_est_une_erreur_requests():
    import requests
    from orion.core import reseau
    assert issubclass(reseau.HoteEnPause, requests.RequestException)


def test_groupes_de_limitation():
    from orion.core.reseau import _cle
    assert _cle("store.steampowered.com")[0] == "steampowered.com"
    # API Web de Steam : quotas distincts de la boutique (1.8.1)
    assert _cle("api.steampowered.com")[0] == "api.steampowered.com"
    assert _cle("exemple.fr")[0] == "exemple.fr"


# -- securite des recettes ----------------------------------------------------
def _recette(chemin, fmt="ini", valeur="1"):
    return {"id": "x", "name": "X", "targets": [
        {"format": fmt, "paths": [chemin], "entries": [{"key": "k", "value": valeur}]}]}


@pytest.mark.parametrize("chemin", [
    "%LOCALAPPDATA%/../../Windows/System32/x.ini",
    "{install_dir}/bin/jeu.exe",
    "C:/Windows/win.ini",
    "%APPDATA%/Microsoft/Windows/Start Menu/Programs/Startup/x.bat",
])
def test_recette_partagee_refusee(chemin):
    from orion.optimizer.securite import verifier_recette
    ok, raisons = verifier_recette(_recette(chemin), partagee=True)
    assert not ok and raisons


def test_valeur_multiligne_refusee():
    from orion.optimizer.securite import verifier_recette
    ok, _ = verifier_recette(_recette("{install_dir}/a.ini", valeur="1\n[Autre]\nx=2"))
    assert not ok


def test_registre_sensible_refuse():
    from orion.optimizer.securite import verifier_recette
    for cle in (r"HKLM\Software\X", r"HKCU\Software\Microsoft\Windows\CurrentVersion\Run"):
        ok, _ = verifier_recette(_recette(cle, "registry"), partagee=True)
        assert not ok


def test_recettes_livrees_acceptees():
    import glob
    from pathlib import Path
    from orion.optimizer.securite import verifier_recette
    racine = Path(__file__).resolve().parents[1]
    fichiers = glob.glob(str(racine / "orion/plugins/tweaks/recipes/*.json"))
    assert fichiers
    for f in fichiers:
        ok, raisons = verifier_recette(json.load(open(f, encoding="utf-8")), partagee=True)
        assert ok, (f, raisons)


def test_chemin_autorise(tmp_path, monkeypatch):
    from orion.optimizer.securite import chemin_autorise
    monkeypatch.setenv("LOCALAPPDATA", str(tmp_path / "local"))
    jeu = tmp_path / "Jeux" / "MonJeu"
    assert chemin_autorise(str(jeu / "cfg" / "a.cfg"), str(jeu))
    assert chemin_autorise(str(tmp_path / "local" / "Jeu" / "a.ini"), "")
    assert not chemin_autorise(str(jeu / "jeu.exe"), str(jeu))
    assert not chemin_autorise(str(tmp_path / "ailleurs" / "a.ini"), str(jeu))


# -- detection des parties en cours ----------------------------------------------
def test_jeux_en_cours():
    import os
    from orion.en_jeu import Processus, Veille, jeux_en_cours
    sep = os.sep
    racine = f"{sep}jeux"
    a = Game(title="A", source="steam", source_id="1", install_dir=f"{racine}{sep}A")
    b = Game(title="B", source="dossier", install_dir=f"{racine}{sep}A{sep}B")   # imbrique
    procs = [Processus(1, "steam.exe", f"{racine}{sep}A{sep}steam.exe"),
             Processus(2, "UnityCrashHandler64.exe", f"{racine}{sep}A{sep}UnityCrashHandler64.exe"),
             Processus(3, "b.exe", f"{racine}{sep}A{sep}B{sep}b.exe", 10)]
    trouves = jeux_en_cours([a, b], procs)
    assert set(trouves) == {b.uid}
    v = Veille()
    assert v.regarder([a, b], procs) == [("debut", b.uid)]
    v.par_orion.add(b.uid)
    fin = v.regarder([a, b], [])
    assert fin[0][0] == "fin" and fin[0][3] is True
    assert not v.actif


# -- signalement ----------------------------------------------------------------
def test_anonymisation(monkeypatch):
    from orion.signalement import anonymiser
    monkeypatch.setenv("USERNAME", "Sikher")
    t = anonymiser(r"C:\Users\Sikher\AppData x@y.fr 76561198012345678 "
                   "sk-abcdefghijklmnop ?key=SECRET&x=1 C:\\\\Users\\\\Bob\\\\a")
    for fuite in ("Sikher", "x@y.fr", "76561198012345678", "abcdefghijklmnop",
                  "SECRET", "Bob"):
        assert fuite not in t


def test_reglages_masques():
    from orion.signalement import _reglages_masques
    m = _reglages_masques({"ai": {"api_key": "abc", "model": "m"},
                           "wishlist": {"steamid": "123"}, "ui": {"accent": "#fff"}})
    assert m["ai"]["api_key"] == "<masque>" and m["ai"]["model"] == "m"
    assert m["wishlist"]["steamid"] == "<masque>"
    assert m["ui"]["accent"] == "#fff"


# -- jeux possedes ---------------------------------------------------------------
def test_catcache_epic(tmp_path):
    import base64
    from orion import possedes
    articles = [
        {"title": "Alan Wake 2", "namespace": "ns", "id": "cid",
         "categories": [{"path": "games"}], "releaseInfo": [{"appId": "Iris"}]},
        {"title": "Un DLC", "categories": [{"path": "addons"}],
         "releaseInfo": [{"appId": "Dlc"}], "mainGameItem": {"id": "x"}},
    ]
    f = tmp_path / "catcache.bin"
    f.write_bytes(base64.b64encode(json.dumps(articles).encode()))
    jeux = possedes.epic(f)
    assert [j.title for j in jeux] == ["Alan Wake 2"]
    assert jeux[0].extra["non_installe"] and "action=install" in jeux[0].launch_uri


def test_base_gog(tmp_path):
    import sqlite3
    from orion import possedes
    f = tmp_path / "galaxy-2.0.db"
    cx = sqlite3.connect(f)
    cx.executescript("""
        CREATE TABLE GamePieceTypes(id INTEGER, type TEXT);
        CREATE TABLE GamePieces(releaseKey TEXT, gamePieceTypeId INTEGER, value TEXT);
        CREATE TABLE LibraryReleases(releaseKey TEXT);
        INSERT INTO GamePieceTypes VALUES (1,'title');
        INSERT INTO GamePieces VALUES ('gog_1207658924',1,'{"title":"The Witcher"}');
        INSERT INTO GamePieces VALUES ('steam_20',1,'{"title":"Team Fortress Classic"}');
        INSERT INTO LibraryReleases VALUES ('gog_1207658924'),('steam_20');
    """)
    cx.commit(); cx.close()
    jeux = possedes.gog(f)
    assert [(j.title, j.source_id) for j in jeux] == [("The Witcher", "1207658924")]


def test_non_installes_sans_doublon(monkeypatch):
    from orion import possedes
    monkeypatch.setattr(possedes, "steam", lambda: [
        possedes._jeu("Portal 2", "steam", "620", "steam://install/620"),
        possedes._jeu("Half-Life", "steam", "70", "steam://install/70")])
    monkeypatch.setattr(possedes, "epic", lambda: [])
    monkeypatch.setattr(possedes, "gog", lambda: [])
    installe = Game(title="Portal 2", source="steam", source_id="620")
    reste = possedes.non_installes([installe])
    assert [g.title for g in reste] == ["Half-Life"]


# -- sauvegardes dans le cloud -----------------------------------------------------
def test_copie_nuage_et_relecture(tmp_path):
    from orion import nuage
    archive = tmp_path / "2026-01-01_10-00-00.zip"
    with zipfile.ZipFile(archive, "w") as z:
        z.writestr("save.dat", "x")
        z.writestr("_orion.json", json.dumps({"jeu": "Hades", "uid": "u1", "source": "C:/s"}))
    racine = tmp_path / "OneDrive"
    racine.mkdir()
    for i in range(4):
        copie = tmp_path / f"2026-01-0{i + 2}_10-00-00.zip"
        copie.write_bytes(archive.read_bytes())
        assert nuage.copier(copie, "Hades", str(racine), garder=2)
    trouvees = nuage.archives(str(racine))
    assert len(trouvees) == 2
    assert trouvees[0]["game_uid"] == "u1" and trouvees[0]["title"] == "Hades"


# -- traduction de l'interface -------------------------------------------------
def test_catalogue_anglais_coherent():
    import re
    from pathlib import Path
    racine = Path(__file__).resolve().parents[1]
    d = json.loads((racine / "orion/langues/en.json").read_text("utf-8"))
    assert len(d["exact"]) > 900
    for fr, en in d["modeles"].items():
        assert set(re.findall(r"\{\d+\}", fr)) == set(re.findall(r"\{\d+\}", en)), fr


def test_traduction_interface():
    from orion import i18n
    assert i18n.charger("en")
    assert i18n.traduire("Bibliotheque") == "Library"
    assert i18n.traduire("Reglages") == "Settings"
    assert i18n.traduire("12 sur 30 jeux") == "12 of 30 games"
    assert i18n.traduire("  Jouer  ") == "  Play  "
    assert i18n.traduire("PREMIERS PAS") == "GETTING STARTED"
    assert i18n.traduire("0 jeux\nAnalyse : 26/09 a 00:22") == "0 games\nLast scan: 26/09 at 00:22"
    assert i18n.traduire("Texte inconnu de personne") == "Texte inconnu de personne"


def test_accents_du_francais():
    """Le code est ecrit sans accents ; le catalogue fr.json les remet, sans
    jamais changer autre chose que les signes diacritiques."""
    import json
    import unicodedata
    from pathlib import Path
    from orion import i18n

    def nu(s):
        return "".join(c for c in unicodedata.normalize("NFD", s) if not unicodedata.combining(c))

    d = json.loads((Path(i18n.__file__).parent / "langues" / "fr.json").read_text("utf-8"))
    for rubrique in ("exact", "modeles", "mots"):
        for sans, avec in d[rubrique].items():
            assert nu(sans) == nu(avec), (sans, avec)
    try:
        assert i18n.charger("fr")
        assert i18n.traduire("Bibliotheque") == "Bibliothèque"
        assert i18n.traduire("REGLAGES") == "RÉGLAGES"
        assert i18n.traduire("  Reglages  ") == "  Réglages  "
        # texte absent du catalogue : mots sans ambiguite seulement
        assert i18n.traduire("zzz la bibliotheque est deja sur le disque") == \
            "zzz la bibliothèque est déjà sur le disque"
        assert i18n.traduire("zzz ORION installe le jeu sur le disque") == \
            "zzz ORION installe le jeu sur le disque"
        # un titre de jeu, un nom ou un chemin ne sont jamais touches
        assert i18n.traduire("Element 4 - Bibliotheque") == "Element 4 - Bibliotheque"
        assert i18n.traduire("C:/Jeux/Bibliotheque de la ville sur le disque") == \
            "C:/Jeux/Bibliotheque de la ville sur le disque"
        assert i18n.traduire("Steam") == "Steam"
    finally:
        i18n.charger("en")
        i18n._exact.clear(); i18n._modeles.clear(); i18n._mots.clear()
        i18n.traduire.cache_clear()
