"""Sorties a venir et joueurs en ligne (1.8.1)."""
import datetime as dt

from orion import en_ligne, sorties as S


def test_liste_embarquee_valide():
    liste = S.embarquee()
    assert len(liste) == len(S.EMBARQUEE)
    ids = [s.id for s in liste]
    assert len(ids) == len(set(ids))
    for s in liste:
        # une date exacte OU une fenetre, jamais une date inventee
        assert bool(s.jour) != bool(s.fenetre) or (not s.date and not s.fenetre)
        assert all(p in S.PLATEFORMES for p in s.plateformes)
        assert s.lien_boutique.startswith("https://")
        if s.jour:
            assert s.source.startswith("https://"), f"{s.titre} : date sans source"


def test_gta_et_zelda():
    d = {s.id: s for s in S.embarquee()}
    assert d["gta-6"].date == "2026-11-19" and d["gta-6"].vedette
    assert d["zelda-ocarina-of-time"].date == "2026-11-05"
    assert d["zelda-ocarina-of-time"].plateformes == ("switch2",)


def test_a_venir_ordre_et_disponibles():
    liste = S.embarquee()
    maintenant = dt.datetime(2026, 10, 3, 12, 0)
    datees, sans = S.a_venir(liste, maintenant)
    dates = [s.instant for s in datees]
    assert dates == sorted(dates)
    ids = [s.id for s in datees]
    assert "ace-combat-8" in ids                      # sorti hier : encore affiche
    assert "minecraft-dungeons-2" not in ids           # sorti il y a 4 jours : place libre
    datees, _ = S.a_venir(liste, dt.datetime(2026, 10, 1, 12))
    assert "minecraft-dungeons-2" in [s.id for s in datees]       # sorti avant-hier
    assert all(s.instant is None for s in sans) and sans


def test_vedette_gta_puis_suivante():
    liste = S.embarquee()
    # 2.1.0 : la sortie « a la une » (Modern Warfare 4) passe devant jusqu'a
    # trois jours apres sa sortie, puis la plus attendue reprend sa place
    datees, _ = S.a_venir(liste, dt.datetime(2026, 9, 27))
    assert S.vedette(datees, dt.datetime(2026, 9, 27)).id == "cod-mw4"
    lancement = dt.datetime(2026, 10, 24, 12)
    datees, _ = S.a_venir(liste, lancement)
    assert S.vedette(datees, lancement).id == "cod-mw4"
    fini = dt.datetime(2026, 10, 27)
    datees, _ = S.a_venir(liste, fini)
    assert S.vedette(datees, fini).id == "gta-6"
    apres = dt.datetime(2026, 11, 20)
    datees, _ = S.a_venir(liste, apres)
    v = S.vedette(datees, apres)
    assert v is not None and v.id != "gta-6" and v.instant > apres


def test_decompte():
    s = S.Sortie("x", "X", date="2026-11-19")
    delta = S.restant(s, dt.datetime(2026, 9, 27, 10, 20, 30))
    assert S.decompte(delta) == (52, 13, 39, 30)
    assert S.texte_decompte(delta) == "52 j  13 h  39 min  30 s"
    assert S.decompte(S.restant(s, dt.datetime(2026, 11, 19, 8))) is None
    assert S.texte_decompte(S.restant(s, dt.datetime(2026, 11, 19, 8))) == \
        "Disponible aujourd'hui"
    assert S.texte_decompte(S.restant(s, dt.datetime(2026, 11, 22, 8))) == \
        "Disponible depuis 3 jours"
    assert S.date_lisible(s) == "19 novembre 2026"
    assert S.date_lisible(S.Sortie("y", "Y", date="2027-04-01")) == "1er avril 2027"
    assert S.date_lisible(S.Sortie("z", "Z", fenetre="Fin 2027")) == "Fin 2027"


def test_filtre_plateforme():
    liste = S.embarquee()
    switch = S.filtrer(liste, "switch2")
    assert switch and all("switch2" in s.plateformes for s in switch)
    assert len(S.filtrer(liste, "toutes")) == len(liste)


def test_liste_en_ligne_choisie_seulement_si_valide_et_recente():
    doc = {"format": S.FORMAT, "maj": S.MAJ, "sorties": S.EMBARQUEE}
    liste, maj = S.choisir(doc)
    assert maj == S.MAJ and len(liste) == len(S.EMBARQUEE)
    recente = {"format": 1, "maj": "2099-01-01",
               "sorties": [{"id": "a", "titre": "A", "date": "2030-01-02",
                            "plateformes": ["pc", "inconnue"]},
                           {"titre": "sans id"}]}
    liste, maj = S.choisir(recente)
    assert maj == "2099-01-01" and [s.id for s in liste] == ["a"]
    assert liste[0].plateformes == ("pc",)
    ancienne = dict(recente, maj="2020-01-01")
    assert S.choisir(ancienne)[1] == S.MAJ
    assert S.choisir({"format": 2, "maj": "2099-01-01", "sorties": []})[1] == S.MAJ
    assert S.choisir(None)[1] == S.MAJ
    assert S.choisir("n'importe quoi")[1] == S.MAJ


def test_jeu_en_ligne_selon_categories():
    assert en_ligne.est_en_ligne([2, 1, 36])            # JcJ en ligne
    assert en_ligne.est_en_ligne([1, 38])               # coop en ligne
    assert en_ligne.est_en_ligne([20])                  # MMO
    assert en_ligne.est_en_ligne([1])                   # multijoueur seul
    assert not en_ligne.est_en_ligne([1, 24, 39])       # ecran partage seulement
    assert not en_ligne.est_en_ligne([2])               # solo
    assert not en_ligne.est_en_ligne([])


def test_texte_joueurs():
    assert en_ligne.texte(None) == ""
    assert en_ligne.texte(1) == "1 joueur en ligne sur Steam en ce moment"
    assert en_ligne.texte(1234567) == "1 234 567 joueurs en ligne sur Steam en ce moment"
    assert "Personne" in en_ligne.texte(0)


def test_joueurs_lit_steam_et_garde_5_minutes(monkeypatch):
    from orion.core import reseau
    appels = []

    class R:
        status_code = 200

        def json(self):
            return {"response": {"player_count": 812345, "result": 1}}

    def faux_get(url, **kw):
        appels.append(kw.get("params"))
        return R()

    monkeypatch.setattr(reseau, "get", faux_get)
    en_ligne._memo.clear()
    assert en_ligne.joueurs("730", maintenant=1000) == 812345
    assert en_ligne.joueurs("730", maintenant=1100) == 812345      # garde
    assert len(appels) == 1 and appels[0] == {"appid": "730"}
    assert en_ligne.joueurs("730", maintenant=1000 + en_ligne.GARDER + 1) == 812345
    assert len(appels) == 2
    assert en_ligne.joueurs("pas-un-id") is None


def test_joueurs_panne_reseau_rend_le_dernier_chiffre(monkeypatch):
    from orion.core import reseau
    en_ligne._memo.clear()
    en_ligne._memo["570"] = (0, 500000)

    def panne(url, **kw):
        raise OSError("hors ligne")

    monkeypatch.setattr(reseau, "get", panne)
    assert en_ligne.joueurs("570", maintenant=10_000) == 500000


def test_categories_gardees_dans_le_releve():
    from orion.plugins.market.base import MarketInfo
    info = MarketInfo.from_dict({"categories": [1, 36], "schema": 5})
    assert info.categories == [1, 36]
    assert MarketInfo().categories == []


# -- remplissage automatique par Steam --------------------------------------
PAGE_STEAM = {"results_html": (
    '<a href="x" data-ds-appid="2769570" class="search_result_row"><div>'
    '<span class="title">Fable</span></div>'
    '<div class="col search_released responsive_secondrow">23 Feb, 2027</div></a>'
    '<a data-ds-appid="4824610" class="search_result_row">'
    '<span class="title">Resident Evil Veronica</span>'
    '<div class="col search_released responsive_secondrow">2027</div></a>'
    '<a data-ds-appid="1422450" class="search_result_row">'
    '<span class="title">Deadlock</span>'
    '<div class="col search_released responsive_secondrow">To be announced</div></a>'
    '<a data-ds-appid="2054970,2593180" class="search_result_row">'
    '<span class="title">Dragon&#39;s Dogma 2: Dark Arisen</span>'
    '<div class="col search_released responsive_secondrow">9 Oct, 2026</div></a>'
    '<a data-ds-appid="555" class="search_result_row">'
    '<span class="title">Jeu Trimestre</span>'
    '<div class="col search_released responsive_secondrow">Q2 2027</div></a>')}


def test_dates_steam():
    assert S.date_steam("23 Feb, 2027") == ("2027-02-23", "")
    assert S.date_steam("Feb 23, 2027") == ("2027-02-23", "")
    assert S.date_steam("9 Oct, 2026") == ("2026-10-09", "")
    assert S.date_steam("Q1 2027") == ("", "1er trimestre 2027")
    assert S.date_steam("February 2027") == ("", "Fevrier 2027")
    assert S.date_steam("2027") == ("", "2027")
    assert S.date_steam("To be announced") == ("", "")
    assert S.date_steam("Coming soon") == ("", "")
    assert S.date_steam("31 Feb, 2027") == ("", "")


def test_lire_steam():
    liste = S.lire_steam(PAGE_STEAM)
    d = {s.titre: s for s in liste}
    assert set(d) == {"Fable", "Resident Evil Veronica", "Dragon's Dogma 2: Dark Arisen",
                      "Jeu Trimestre"}                  # « To be announced » ecarte
    assert d["Dragon's Dogma 2: Dark Arisen"].steam == "2054970"
    assert d["Fable"].rang == 1 and d["Fable"].date == "2027-02-23"
    assert d["Resident Evil Veronica"].fenetre == "2027"
    assert all(s.plateformes == ("pc",) and s.id.startswith("steam-") for s in liste)
    assert S.lire_steam({}) == [] and S.lire_steam(None) == []


def test_fusion_garde_la_fiche_officielle():
    officielles = S.embarquee()
    steam = S.lire_steam(PAGE_STEAM)
    tout = S.fusionner(officielles, steam)
    fables = [s for s in tout if s.titre == "Fable"]
    assert len(fables) == 1 and fables[0].id == "fable" and fables[0].rang == 1
    assert fables[0].plateformes == ("pc", "ps5", "xbox")
    assert any(s.id == "steam-4824610" for s in tout)      # nouveau jeu ajoute


def _steam_date(n, jour):
    return S.Sortie(f"steam-{n}", f"Jeu {n}", date=jour.isoformat(), steam=str(n),
                    plateformes=("pc",), attente=max(20, 90 - n), rang=n)


def test_un_jeu_sorti_laisse_sa_place_au_suivant():
    """La page garde AFFICHEES sorties datees : quand un jeu sort puis
    quitte la page, le suivant du classement Steam apparait tout seul."""
    base = dt.date(2027, 6, 1)
    officielles = [S.Sortie("off", "Officielle", date="2027-06-10", attente=90)]
    steam = [_steam_date(n, base + dt.timedelta(days=n)) for n in range(1, 60)]
    liste = S.fusionner(officielles, steam)
    avant = dt.datetime(2027, 5, 1)
    datees, sans = S.a_venir(liste, avant)
    montrees, _ = S.selection(datees, sans)
    assert len(montrees) == S.AFFICHEES
    assert "off" in [s.id for s in montrees]
    ids_avant = {s.id for s in montrees}
    # un mois plus tard, les premiers sont sortis depuis plus de 3 jours
    apres = dt.datetime(2027, 6, 12)
    datees, sans = S.a_venir(liste, apres)
    montrees, _ = S.selection(datees, sans)
    assert len(montrees) == S.AFFICHEES
    nouveaux = {s.id for s in montrees} - ids_avant
    assert nouveaux, "des jeux suivants doivent avoir pris la place des jeux sortis"
    assert all(s.instant > apres - dt.timedelta(days=S.DISPONIBLE_JOURS) for s in montrees)


def test_vedette_la_plus_attendue_des_4_prochains_mois():
    liste = S.embarquee()
    m = dt.datetime(2026, 11, 20)            # GTA VI vient de sortir
    datees, _ = S.a_venir(liste, m)
    v = S.vedette(datees, m)
    assert v.id in ("god-of-war-laufey", "fable")   # 85 : les plus attendus avant mars
    assert v.id == "god-of-war-laufey"               # a egalite, le plus proche


def test_visuel_officiel_et_mot_pour_un_jeu_hors_steam(monkeypatch, tmp_path):
    """GTA VI n'est pas sur Steam : son visuel vient du champ « image », et
    une remarque (« mot ») s'affiche sous la date."""
    d = {s.id: s for s in S.embarquee()}
    g = d["gta-6"]
    assert g.image.startswith("https://www.rockstargames.com/") and "PC" in g.mot
    assert all(not s.mot for s in d.values() if s.id not in ("gta-6", "cod-mw4", "kingmakers"))
    # une adresse non https ou farfelue est ignoree
    assert S.Sortie.depuis({"id": "x", "titre": "X", "image": "http://a/b.jpg"}).image == ""
    assert S.Sortie.depuis({"id": "x", "titre": "X", "image": ["a"]}).image == ""

    monkeypatch.setattr(S, "dossier_visuels", lambda: tmp_path)
    from orion.core import reseau

    def faux(url, cible, **k):
        open(cible, "wb").write(b"\xff\xd8\xff" + b"0" * 5000)
        return 5003
    monkeypatch.setattr(reseau, "telecharger", faux)
    v = S.telecharger_visuels(g)
    assert v["fond"] == v["carte"] and S.visuels(g)["carte"] == v["fond"]

    # un fichier qui n'est pas une image n'est pas garde, et l'echec est memorise
    autre = S.Sortie.depuis({"id": "y", "titre": "Y", "image": "https://a.example/b.jpg"})
    monkeypatch.setattr(reseau, "telecharger",
                        lambda url, cible, **k: open(cible, "wb").write(b"<html>" * 500))
    assert S.telecharger_visuels(autre) == {} and S.sans_visuel_recent(autre)


def test_image_large_du_bandeau_jamais_tranchee():
    """Bandeau tres allonge (grand ecran) et image de presse 1200x630 : l'image
    est montree entiere a droite au lieu d'etre recadree."""
    from PySide6.QtCore import QRectF
    from PySide6.QtGui import QPixmap
    from PySide6.QtWidgets import QApplication
    app = QApplication.instance() or QApplication([])
    from orion.ui.views import sorties_view as V
    presse = QPixmap(1200, 630)
    bandeau = QRectF(0, 0, 1980, 385)
    r = V.image_entiere(bandeau, presse)
    assert r is not None and abs(r.height() - 385) < 1 and abs(r.right() - 1980) < 1
    assert abs(r.width() / r.height() - 1200 / 630) < 0.01       # aucune deformation
    # image deja panoramique (fond Steam) : simple recadrage, comme avant
    assert V.image_entiere(QRectF(0, 0, 1200, 385), QPixmap(1920, 620)) is None


def test_une_fidelite_et_kingmakers():
    liste = S.embarquee()
    cod = next(s for s in liste if s.id == "cod-mw4")
    assert cod.une and cod.fidelite["serie"] == "call of duty" and "23 octobre" in cod.fidelite["texte"]
    km = next(s for s in liste if s.id == "kingmakers")
    assert km.jour is None and km.steam == "2109770"      # aucune date inventee
    # champs mal formes ignores
    x = S.Sortie.depuis({"id": "x", "titre": "X", "une": "oui", "fidelite": {"serie": "a"}})
    assert x.une is False and x.fidelite is None


def test_precommandes_prix_et_cle(monkeypatch):
    """Bloc prix de la une : prix officiel Steam, cle verifiee seulement si
    moins chere, offre de fidelite seulement avec un jeu de la serie."""
    from orion import precommandes, prix_revendeurs
    from orion.core.models import Game
    cod = next(s for s in S.embarquee() if s.id == "cod-mw4")
    monkeypatch.setattr(precommandes, "_steam", lambda appids, forcer: {"4435490": (69.99, 69.99)})
    vus = {}

    def offres(appid, titre, duree=None):
        vus["duree"] = duree
        return {"kinguin": None, "loaded": {"prix": 56.49, "devise": "EUR", "public": 69.99,
                                            "url": "https://www.loaded.com/x", "nom": "MW4"}}
    monkeypatch.setattr(prix_revendeurs, "offres", offres)
    o = precommandes.offre_une(cod, [], forcer=True)
    assert o.precommande and o.prix == 69.99 and o.url.endswith("/4435490/")
    assert o.cle["boutique"] == "Loaded" and o.cle["prix"] == 56.49
    assert vus["duree"] == precommandes.RAFRAICHIR_UNE and not o.fidelite
    bo6 = Game(title="Call of Duty®: Black Ops 6", source="steam")
    assert "Coffre d'armes" in precommandes.offre_une(cod, [bo6]).fidelite
    # une fiche sans prix (precommande pas encore ouverte) : rien a vendre
    monkeypatch.setattr(precommandes, "_steam", lambda appids, forcer: {})
    o = precommandes.offre_une(cod, [bo6])
    assert not o.precommande and o.cle is None and o.texte_officiel == ""
