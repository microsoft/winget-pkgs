"""Pages « Bons plans » du site (13 octobre 2026)."""
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "service" / "site"))
import gen_bons_plans as bp  # noqa: E402
import gen_jeux  # noqa: E402


class FauxReleve:
    """Le strict necessaire du module prix_gamesplanet."""
    def __init__(self, jeux):
        self._memo = {"releve": 1791880000.0, "jeux": jeux}

    def _produits(self, appid, pays):
        out = []
        for nom, prix, normal, fiche, type_cle, autorises, exclus in self._memo["jeux"].get(appid, []):
            if autorises and pays not in autorises.split(","):
                continue
            out.append({"nom": nom, "prix": prix, "normal": normal,
                        "url": "https://fr.gamesplanet.com/game/" + fiche, "type": type_cle})
        return out


def _jeu(appid, nom, avis, prix, normal, genres=("Action",), gratuit=False, positifs=90):
    remise = int(round(100 - prix * 100 / normal)) if prix < normal else 0
    return {"appid": appid, "nom": nom, "slug": gen_jeux.slug(nom), "avis": avis, "positifs": positifs,
            "genres": list(genres), "gratuit": gratuit, "cites": [],
            "gp": {"prix": prix, "normal": normal, "remise": remise, "slug": f"{appid}-key--1-1",
                   "url": f"https://fr.gamesplanet.com/game/{appid}-key--1-1?ref=orion", "cle": "Clé Steam"}}


JEUX = [
    _jeu("1", "Gros Jeu", 300000, 9.99, 39.99),
    _jeu("2", "Petit Inconnu", 200, 0.99, 19.99),                   # pas assez joue
    _jeu("3", "Presque Plein Tarif", 90000, 35.99, 39.99),           # -10 % : pas un bon plan
    _jeu("4", "Pepite", 20000, 4.99, 19.99, genres=("Indépendant",)),
    _jeu("5", "Gratuit Populaire", 900000, 0.0, 0.0, gratuit=True),
    _jeu("6", "Dead Rising", 60000, 9.99, 19.99),
]


def test_seulement_des_jeux_tres_joues_vraiment_remises():
    offres = bp.offres_du_jeu(JEUX)
    assert {o["nom"] for o in offres} == {"Gros Jeu", "Dead Rising", "Pepite"}
    assert offres[0]["nom"] == "Gros Jeu"              # le plus joue, et bien remise
    assert all(o["remise"] >= bp.REMISE_MIN and o["avis"] >= bp.AVIS_MIN for o in offres)


def test_carte_honnete_et_liens_partenaires_marques():
    o = bp.offres_du_jeu(JEUX)[0]
    html = bp.carte(o)
    assert '<s class="bp-normal">39,99' in html and '<b class="bp-final">9,99' in html
    assert ">-75 %<" in html and "Vous économisez <b>30,00" in html
    for lien in re.findall(r'<a [^>]*href="https://fr\.gamesplanet[^>]*>', html):
        assert 'rel="sponsored noopener"' in lien
    assert '<div data-comparatif data-appid="1" data-titre="Gros Jeu"></div>' in html   # au clic
    assert 'data-auto' not in html                     # jamais toute la page d'un coup
    assert 'href="/jeux/gros-jeu"' in html


def test_extensions_reconnues_sans_suites_ni_bandes_son():
    G = FauxReleve({
        "10": [["Gros Jeu - Season Pass", 4.99, 19.99, "a--1-1", "steam", "", ""]],
        "11": [["Gros Jeu: Soundtrack", 1.99, 9.99, "b--1-1", "steam", "", ""]],
        "12": [["Dead Rising 4 - Season Pass", 2.41, 9.99, "c--1-1", "steam", "", ""]],
        "13": [["Gros Jeu - Expansion Pass", 9.99, 14.99, "d--1-1", "steam", "", ""]],     # -33 %
        "14": [["Gros Jeu - Mega Pack", 1.0, 9.99, "e--1-1", "steam", "DE", ""]],           # pas en France
        **{str(20 + i): [[f"Gros Jeu - Pack {i}", 1.0, 9.99, f"p{i}--1-1", "steam", "", ""]] for i in range(5)},
    })
    noms = [o["nom"] for o in bp.extensions(JEUX, G)]
    assert "Gros Jeu: Soundtrack" not in noms and "Dead Rising 4 - Season Pass" not in noms
    assert "Gros Jeu - Mega Pack" not in noms
    assert len(noms) == bp.PAR_JEU                     # pas une page de packs d'un seul jeu
    d = bp.extensions(JEUX, G)[0]
    assert d["base"] == "Gros Jeu" and "Nécessite le jeu de base" in bp.carte(d)


def _site(tmp_path):
    site = tmp_path / "site"
    (site / "en").mkdir(parents=True)
    nav = ('<header class="nav"><nav><a href="/">Le launcher</a>\n      <a href="/jeux">Configs des jeux</a>\n'
           '      <a href="/sorties">Sorties</a></nav></header><main></main>'
           '<footer><a href="/gratuits">Jeux gratuits</a></footer>')
    (site / "index.html").write_text(f"<html><head><style>b{{}}</style></head><body>{nav}</body></html>",
                                     encoding="utf-8")
    (site / "en" / "index.html").write_text(nav.replace("/sorties", "/en/releases"), encoding="utf-8")
    (site / "sitemap.xml").write_text("<urlset>\n  <url>\n    <loc>https://orion-launcher.com/mentions-legales"
                                      "</loc>\n  </url>\n</urlset>\n", encoding="utf-8")
    return site


def test_pages_menu_et_plan_du_site(tmp_path):
    site = _site(tmp_path)
    comptes = bp.main(site, FauxReleve({}), JEUX)
    assert comptes["/bons-plans"] == 3 and comptes["/bons-plans/jeux-independants"] == 1
    for f in ("bons-plans.html", "bons-plans.js", "bons-plans/affaires-du-siecle.html",
              "bons-plans/moins-de-10-euros.html", "bons-plans/jeux-independants.html", "bons-plans/dlc.html"):
        assert (site / f).is_file(), f
    page = (site / "bons-plans.html").read_text(encoding="utf-8")
    assert 'id="bp-une"' in page and "L'affaire du jour" in page
    assert "jamais la commission" in page and "liens partenaires" in page
    assert '<a href="/bons-plans" aria-current="page">Tous les bons plans</a>' in page
    dlc = (site / "bons-plans" / "dlc.html").read_text(encoding="utf-8")
    assert "Aucune promotion de ce type" in dlc
    plan = (site / "sitemap.xml").read_text(encoding="utf-8")
    assert plan.index("/bons-plans</loc>") < plan.index("/mentions-legales")
    assert plan.count("/bons-plans") == 5

    assert bp.relier(site) >= 2
    accueil = (site / "index.html").read_text(encoding="utf-8")
    assert accueil.index('href="/bons-plans"') < accueil.index('href="/sorties"')
    assert '<a href="/bons-plans">Bons plans</a>\n      <a href="/gratuits">' in accueil
    assert "bons-plans" not in (site / "en" / "index.html").read_text(encoding="utf-8")
    page = (site / "bons-plans.html").read_text(encoding="utf-8")
    assert '<a href="/bons-plans" aria-current="page">Bons plans</a>' in page.split("<main")[0]
    assert bp.relier(site) == 0                     # une seule fois


def test_script_ne_parle_qu_au_releve_public():
    hotes = set(re.findall(r"https://([a-z0-9.-]+)/", bp.BONS_PLANS_JS))
    assert hotes == {"raw.githubusercontent.com"}
    assert "REMISE_MIN = 30" in bp.BONS_PLANS_JS and f"ROTATION = {bp.ROTATION}" in bp.BONS_PLANS_JS


def test_accueil_et_jeux_gratuits_relies(tmp_path):
    import datetime as dt
    site = tmp_path / "s"
    site.mkdir()
    (site / "index.html").write_text('<html><head><style>x{}</style></head><body><main>'
                                     '<section class="wrap partie" id="garanties"></section></main></body></html>',
                                     encoding="utf-8")
    (site / "gratuits.html").write_text('<html><head></head><body><p class="chapo">Les jeux offerts.</p></body></html>',
                                        encoding="utf-8")
    assert bp.accueil(site, bp.offres_du_jeu(JEUX))
    s = (site / "index.html").read_text(encoding="utf-8")
    assert s.index('id="bons-plans"') < s.index('id="garanties"')
    assert "<div data-comparatif" not in s
    assert "<script" not in s                    # l'accueil n'appelle aucun service tiers
    assert not bp.accueil(site, bp.offres_du_jeu(JEUX))          # une seule fois
    assert bp.onglets_gratuits(site)
    g = (site / "gratuits.html").read_text(encoding="utf-8")
    assert '<a href="/gratuits" aria-current="page">Jeux gratuits</a>' in g
    assert bp.de_mois(dt.date(2026, 10, 13)) == "d'octobre 2026"
    assert bp.de_mois(dt.date(2026, 3, 1)) == "de mars 2026"
