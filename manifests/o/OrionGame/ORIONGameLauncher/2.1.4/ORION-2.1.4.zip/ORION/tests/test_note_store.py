"""La demande de note sur le Microsoft Store : une fois, au cinquieme
lancement, seulement depuis le Store."""
from orion import note_store
from orion.core.config import CONFIG


def test_une_fois_au_cinquieme_lancement_depuis_le_store(monkeypatch):
    CONFIG.set("note.lancements", 0)
    CONFIG.set("note.demandee", False)
    for _ in range(4):
        note_store.compter_lancement()
        assert not note_store.a_demander(depuis_store=True)
    assert note_store.compter_lancement() == 5
    assert note_store.a_demander(depuis_store=True)
    assert not note_store.a_demander(depuis_store=False)          # installateur : jamais
    ouvert = []
    monkeypatch.setattr("os.startfile", lambda u: ouvert.append(u), raising=False)
    monkeypatch.setattr("webbrowser.open", lambda u: ouvert.append(u))
    note_store.repondre(False)
    assert not ouvert and not note_store.a_demander(depuis_store=True)     # « Non merci » : plus jamais
    CONFIG.set("note.demandee", False)
    note_store.repondre(True)
    assert ouvert and ouvert[0] == "ms-windows-store://review/?ProductId=9P91GMXV7FPW"
    assert not note_store.a_demander(depuis_store=True)
    for _ in range(50):
        note_store.compter_lancement()
    assert not note_store.a_demander(depuis_store=True)
