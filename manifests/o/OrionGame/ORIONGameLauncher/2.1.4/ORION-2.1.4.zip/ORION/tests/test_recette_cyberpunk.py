"""Signalement n° 2 (4 octobre 2026) : « le lancement avec les graphismes
preselectionnes ne fonctionne pas avec Cyberpunk ».

La cause n'etait pas le lanceur du jeu : ORION n'avait aucune recette pour
REDengine, donc n'ecrivait rien. Et son ecrivain JSON ne savait atteindre
que des cles simples, pas une option rangee dans une liste d'objets nommes.

Le fichier d'essai est tire du vrai `UserSettings.json` du jeu (version 140).
"""
from __future__ import annotations

import json
import shutil
from pathlib import Path

import pytest

from orion.core.models import Display, DisplayMode, Game, GPUInfo, HardwareInfo, TweakOp

MODELE = Path(__file__).parent / "donnees" / "cyberpunk_UserSettings.json"


def _hw(tier=2, feats=("dlss", "rt", "reflex")):
    natif = DisplayMode(2560, 1440, 165)
    ecran = Display(device="D1", primary=True, current=natif, native=natif,
                    max_refresh_at_native=165, modes=[natif])
    gpu = GPUInfo(name="NVIDIA GeForce RTX 3080", vendor="nvidia", vram_mb=10240,
                  tier=tier, features=list(feats))
    return HardwareInfo(cpu_name="Intel Core i9-9900K", cpu_threads=16, ram_gb=32,
                        gpus=[gpu], displays=[ecran]), ecran


@pytest.fixture
def cyberpunk(tmp_path, monkeypatch):
    local = tmp_path / "local"
    monkeypatch.setenv("LOCALAPPDATA", str(local))
    dossier = local / "CD Projekt Red" / "Cyberpunk 2077"
    dossier.mkdir(parents=True)
    fichier = dossier / "UserSettings.json"
    shutil.copy(MODELE, fichier)
    inst = tmp_path / "jeux" / "Cyberpunk 2077"
    (inst / "bin" / "x64").mkdir(parents=True)
    jeu = Game(title="Cyberpunk 2077", source="steam", source_id="1091500",
               install_dir=str(inst))
    return jeu, fichier


def _options(fichier) -> dict:
    data = json.loads(Path(fichier).read_text("utf-8"))
    return {(g["group_name"], o["name"]): o for g in data["data"] for o in g["options"]}


def test_cyberpunk_a_une_recette_qui_ecrit(cyberpunk):
    from orion.optimizer import fiabilite
    from orion.optimizer.engine import Optimizer
    jeu, fichier = cyberpunk
    avant = _options(fichier)
    moteur = Optimizer()
    hw, ecran = _hw()
    # 2.1.0 : le choix « Faible realisme » (niveau Basse impose) remplace l'ancien profil Esport
    from orion.optimizer.recommande import choisir_niveau
    choisir_niveau(jeu, "basse")
    plan = moteur.build_plan(jeu, "recommande", hw, ecran)
    assert "Cyberpunk 2077" in plan.recipe_name and plan.confidence == "exact"
    assert plan.tunable and len(plan.ops) >= 20
    # toutes les options visees existent dans le vrai fichier (rien d'invente)
    assert all(o.current is not None for o in plan.ops), [o.key for o in plan.ops if o.current is None]
    ok, msg = moteur.apply_plan(jeu, plan)
    assert ok, msg
    apres = _options(fichier)
    for (groupe, nom), o in apres.items():
        choix = o.get("values")
        if isinstance(choix, list):
            # une valeur proposee par le jeu, et l'index qui la suit
            assert o["value"] in choix and choix[o["index"]] == o["value"], (nom, o)
    # le profil esport baisse reellement le niveau
    assert apres[("/graphics/advanced", "ShadowMeshQuality")]["value"] != "High"
    assert apres[("/graphics/raytracing", "RayTracing")]["value"] is False
    # le jeu est mis a la definition de l'ecran (signalement du 4 octobre :
    # reste en 3620x2036 sur un ecran en 2560x1440, l'image debordait sur le
    # second ecran) ; l'index des listes dressees par le jeu lui est laisse
    assert apres[("/video/display", "Resolution")]["value"] == "2560x1440"
    assert apres[("/video/display", "Resolution")]["index"] == avant[("/video/display", "Resolution")]["index"]
    assert apres[("/video/display", "WindowMode")]["value"] == "Fullscreen"
    assert apres[("/graphics/presets", "ResolutionScaling")]["value"] == "DLSS"
    assert apres[("/graphics/presets", "DLSS")]["value"] in ("DLAA", "Quality", "Balanced", "Performance")
    # les gouts du joueur et ce qu'ORION ne connait pas n'ont pas bouge
    for cle in [("/video/display", "VSync"), ("/video/display", "OutputMonitor"),
                ("/graphics/basic", "MotionBlur"), ("/graphics/basic", "FilmGrain"),
                ("/graphics/basic", "FieldOfView"), ("/audio/volume", next(
                    n for (g, n) in avant if g == "/audio/volume"))]:
        assert apres[cle] == avant[cle], cle
    # deuxieme passage : tout est en place, l'etat le dit
    st = fiabilite.statut(moteur.build_plan(jeu, "esport", hw, ecran), jeu)
    assert st.cle == fiabilite.AUTO


def test_chaque_profil_ne_donne_que_des_valeurs_du_jeu(cyberpunk):
    from orion.optimizer.engine import Optimizer
    from orion.optimizer.profiles import PROFILES
    jeu, fichier = cyberpunk
    moteur = Optimizer()
    for tier, feats in ((0, ()), (1, ("dlss",)), (2, ("dlss", "rt")), (3, ("dlss", "rt", "dlss_fg"))):
        hw, ecran = _hw(tier, feats)
        for profil in PROFILES:
            shutil.copy(MODELE, fichier)
            plan = moteur.build_plan(jeu, profil, hw, ecran)
            assert not [o.key for o in plan.ops if "{" in o.value]
            ok, msg = moteur.apply_plan(jeu, plan)
            assert ok, (profil, tier, msg)


def test_ecrivain_json_respecte_ce_que_l_option_accepte(tmp_path):
    """La cause, au-dela de Cyberpunk : une option decrit ce qu'elle accepte
    (liste, bornes, type). ORION ne sort jamais de ce cadre et n'invente ni
    groupe ni option."""
    from orion.plugins.tweaks.json_writer import JsonWriter
    f = tmp_path / "UserSettings.json"
    shutil.copy(MODELE, f)
    w = JsonWriter()
    A = "data[group_name=/graphics/advanced].options[name=%s].value"

    def op(cle, valeur):
        return TweakOp(kind="json", target=str(f), section="", key=cle, value=valeur, label=cle)

    assert w.read(op(A % "Anisotropy", "")) == "16"
    n, msg = w.write([
        op(A % "Anisotropy", "8"),                                   # liste d'entiers
        op(A % "ShadowMeshQuality", "Psycho"),                       # pas dans la liste
        op(A % "OptionInconnue", "High"),                            # option absente
        op("data[group_name=/nexiste/pas].options[name=X].value", "1"),
        op("data[group_name=/video/display].options[name=Resolution].value", "1920x1080"),  # liste dressee par le jeu
        op("data[group_name=/video/display].options[name=OutputMonitor].value", "ecran"),  # pas un entier
        op("data[group_name=/video/display].options[name=MaximumFPS_Value].value", "999"),  # bornee a 240
        op("data[group_name=/graphics/raytracing].options[name=RayTracing].value", "High"),  # pas un booleen
    ])
    assert n == 3 and "non ecrit" in msg
    o = _options(f)
    assert o[("/graphics/advanced", "Anisotropy")]["value"] == 8
    assert o[("/graphics/advanced", "Anisotropy")]["index"] == 2
    assert o[("/graphics/advanced", "ShadowMeshQuality")]["value"] == "High"
    # liste dressee par le jeu : la valeur est ecrite, l'index reste au jeu
    assert o[("/video/display", "Resolution")]["value"] == "1920x1080"
    assert o[("/video/display", "Resolution")]["index"] == 18
    assert o[("/video/display", "OutputMonitor")]["value"] == 1
    assert o[("/video/display", "MaximumFPS_Value")]["value"] == 240
    assert o[("/graphics/raytracing", "RayTracing")]["value"] is False
    assert not any(g == "/nexiste/pas" for g, _n in o)
    # les cles simples marchent comme avant, creation comprise
    g = tmp_path / "simple.json"
    g.write_text('{"video": {"vsync": true}}', "utf-8")
    simple = TweakOp(kind="json", target=str(g), section="", key="video.qualite.ombres", value="2", label="x")
    assert w.write([simple])[0] == 1
    assert json.loads(g.read_text("utf-8")) == {"video": {"vsync": True, "qualite": {"ombres": 2}}}


def test_recette_partagee_reconnue_malgre_les_fins_de_ligne_de_windows(tmp_path, monkeypatch):
    """Vu dans le journal de l'auteur : « Recette partagee modifiee
    localement, ignoree », a chaque demarrage et pour les quatre recettes.
    Windows ecrivait le fichier avec ses fins de ligne, l'empreinte etait
    prise sur le texte d'avant : aucune recette partagee n'etait chargee."""
    from orion import community
    from orion.optimizer import engine, securite
    dossier = tmp_path / "communaute"
    dossier.mkdir()
    monkeypatch.setattr(engine, "RECIPE_COMMUNITY_DIR", dossier)
    monkeypatch.setattr(engine, "RECIPE_USER_DIR", tmp_path / "perso")
    recette = {"id": "essai_partage", "name": "Essai", "match": {"title": ["Jeu d'essai"]},
               "targets": [], "advice": ["Un conseil."]}
    texte = json.dumps(recette, indent=2, ensure_ascii=False)
    # le fichier tel que les versions precedentes l'ont laisse sur le disque
    (dossier / "essai_partage.json").write_bytes(texte.replace("\n", "\r\n").encode("utf-8"))
    (dossier / "_index_local.json").write_text(json.dumps({"recipes": {
        "essai_partage": {"version": 1, "sha256": securite.empreinte(texte.encode("utf-8"))}}}), "utf-8")
    engine._RECETTES_SIGNALEES.clear()
    assert "essai_partage" in [r.id for r in engine.load_recipes()]
    # un contenu reellement change reste refuse
    (dossier / "essai_partage.json").write_bytes(texte.replace("Un conseil", "Autre chose").encode("utf-8"))
    assert "essai_partage" not in [r.id for r in engine.load_recipes()]
    # et l'ecriture d'une recette telechargee garde exactement le texte de l'empreinte
    import inspect
    assert "write_bytes" in inspect.getsource(community)


def test_recette_partagee_ne_remplace_pas_celle_livree(tmp_path, monkeypatch):
    """Le depot partage contient d'anciennes copies des recettes generiques.
    Tant qu'elles etaient ecartees a tort, cela ne se voyait pas ; chargees,
    elles auraient pris la place des recettes a jour livrees avec ORION."""
    from orion.optimizer import engine, securite
    dossier = tmp_path / "communaute"
    dossier.mkdir()
    monkeypatch.setattr(engine, "RECIPE_COMMUNITY_DIR", dossier)
    monkeypatch.setattr(engine, "RECIPE_USER_DIR", tmp_path / "perso")
    vieille = {"id": "unreal_generic", "name": "Unreal (ancienne copie)",
               "match": {"engine": ["unreal"]}, "targets": [], "advice": ["Ancien conseil."]}
    texte = json.dumps(vieille, indent=2)
    (dossier / "unreal_generic.json").write_bytes(texte.encode("utf-8"))
    (dossier / "_index_local.json").write_text(json.dumps({"recipes": {
        "unreal_generic": {"version": 1, "sha256": securite.empreinte(texte.encode("utf-8"))}}}), "utf-8")
    jeu = Game(title="Jeu Unreal", source="dossier", engine="unreal")
    choisie = engine.select_recipe(jeu, engine.load_recipes())
    assert choisie.name != "Unreal (ancienne copie)" and "echelle_resolution" in choisie.capacites
    # une recette personnelle du meme nom garde le dernier mot
    perso = tmp_path / "perso"
    perso.mkdir()
    (perso / "unreal_generic.json").write_text(json.dumps({**vieille, "name": "La mienne"}), "utf-8")
    assert engine.select_recipe(jeu, engine.load_recipes()).name == "La mienne"


def test_dlss_suit_le_profil_et_reste_absent_sans_carte_dlss(cyberpunk):
    """Sans cela, le jeu gardait l'ancien niveau de DLSS du joueur (ici
    « Performance », regle pour une definition plus haute) : a la definition
    de l'ecran, l'image etait calculee en 720p. Le profil Recommande, qui ne
    demande aucune mise a l'echelle, donne DLAA : rendu a la definition de
    l'ecran."""
    from orion.optimizer.engine import Optimizer
    jeu, fichier = cyberpunk
    moteur = Optimizer()
    from orion.optimizer.recommande import choisir_niveau
    # 2.1.0 : un seul profil moteur ; le niveau vient du choix de la fiche.
    # Sans niveau impose, le point standard de cette machine (tier 3) ne
    # demande aucune mise a l'echelle : DLAA.
    choisir_niveau(jeu, "")
    shutil.copy(MODELE, fichier)
    hw, ecran = _hw(3, ("dlss", "rt", "reflex"))
    ok, msg = moteur.apply_plan(jeu, moteur.build_plan(jeu, "recommande", hw, ecran))
    assert ok, msg
    o = _options(fichier)
    assert o[("/graphics/presets", "DLSS")]["value"] in ("DLAA", "Quality", "Balanced", "Performance")
    assert o[("/graphics/presets", "ResolutionScaling")]["value"] == "DLSS"
    # carte sans DLSS : les deux lignes sont sautees, rien d'ecrit a leur place
    shutil.copy(MODELE, fichier)
    hw, ecran = _hw(3, ("fsr", "rt"))
    plan = moteur.build_plan(jeu, "recommande", hw, ecran)
    assert not [o for o in plan.ops if "DLSS" in o.key or "ResolutionScaling" in o.key]
