"""Recherche de la Boutique facon site de vente de jeux (demande de l'auteur,
14 octobre 2026, avec trois enregistrements : Instant Gaming, Kinguin,
DLCompare) : la barre en haut de la page, a cote des onglets ; des la
premiere lettre, une liste sous la barre (jeux avec leur prix, types de jeux,
« Voir les resultats ») ; champ vide : vus recemment ou tendances ; clavier."""
import pytest
from PySide6.QtWidgets import QWidget

from test_boutique_pages import _vue, app, memo  # noqa: F401  (fixtures)


@pytest.fixture()
def vue(app, memo):  # noqa: F811
    from orion.core.config import CONFIG
    CONFIG.set("boutique.vus_recemment", [])
    v = _vue(memo)
    v.resize(1400, 900)
    v.show()
    v.recherche.hasFocus = lambda: True          # pas de fenetre active hors ecran
    yield v
    v.hide()
    CONFIG.set("boutique.vus_recemment", [])


def _taper(v, texte):
    v.recherche.setText(texte)
    v._maj_panneau()


def _genres(v):
    return [g for _r, g, _v in v.panneau.zones]


def test_la_liste_s_ouvre_des_la_saisie_avec_les_jeux_et_leurs_prix(vue):
    _taper(vue, "tir 0")
    p = vue.panneau
    assert p.isVisible()
    jeux = [x for _r, g, x in p.zones if g == "fiche"]
    assert 1 <= len(jeux) <= 6 and all(f.titre.lower().startswith("tir 0") for f in jeux)
    assert _genres(vue)[-1] == "tout"                      # « Voir les resultats » en bas
    assert not p.grab().isNull()                             # le dessin passe


def test_fautes_et_types_de_jeux(vue):
    _taper(vue, "rpg")
    types = [x for _r, g, x in vue.panneau.zones if g == "type"]
    assert "rpg" in types
    _taper(vue, "rol 03")                                    # faute de frappe
    assert any(g == "fiche" and x.titre == "Role 03" for _r, g, x in vue.panneau.zones)


def test_clavier_et_ouverture_de_la_fiche(vue):
    ouvertes = []
    vue.ouvrir_fiche = ouvertes.append
    _taper(vue, "role 05")
    vue.panneau.deplacer(1)
    assert vue.panneau.activer()
    assert ouvertes and ouvertes[0].titre == "Role 05" and not vue.panneau.isVisible()


def test_voir_les_resultats_ouvre_la_page(vue):
    _taper(vue, "tir")
    vue.panneau.tout_voir.emit()
    assert not vue.panneau.isVisible() and vue.en_liste()


def test_champ_vide_vus_recemment_sinon_tendances(vue):
    _taper(vue, "")
    assert vue.panneau.isVisible() and set(_genres(vue)) == {"tuile"}      # tendances
    from orion.ui.views.boutique_view import FicheDialogue  # noqa: F401
    for titre in ("Role 01", "Tir 07"):
        f = next(f for f in vue._catalogue if f.titre == titre)
        vue._noter_vu(f)
    _taper(vue, "")
    tuiles = [x.titre for _r, g, x in vue.panneau.zones if g == "tuile"]
    assert tuiles[:2] == ["Tir 07", "Role 01"]                # le plus recent d'abord


def test_la_barre_est_en_haut_de_la_page_et_sert_depuis_les_gratuits(vue):
    from orion.ui.views.boutique_page import GRATUITS, OFFRES, BoutiquePage
    page = BoutiquePage(vue, QWidget())
    assert vue.recherche.parentWidget() is page            # dans l'en-tete, a cote des onglets
    page.montrer(GRATUITS)
    vue.recherche.textEdited.emit("hades")
    assert page.onglet == OFFRES
