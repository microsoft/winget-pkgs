"""Chaque bug corrige devient un test : il ne doit plus jamais revenir."""
from orion.core.models import Game


# -- doublons registre + Steam (1.6.0) -------------------------------------
def test_doublon_registre_steam_par_identifiant_natif():
    from orion.core.doublons import dedoublonner
    steam = Game(title="Cyberpunk 2077", source="steam", source_id="1091500",
                 install_dir=r"D:\SteamLibrary\steamapps\common\Cyberpunk 2077")
    reg = Game(title="Cyberpunk 2077", source="registre", source_id="Steam App 1091500",
               install_dir=r"D:\SteamLibrary\steamapps\common\Cyberpunk 2077",
               extra={"native": ["steam", "1091500"]}, play_seconds=600)
    restants = dedoublonner([reg, steam], {"steam": 100})
    assert len(restants) == 1
    assert restants[0].source == "steam"
    assert restants[0].play_seconds == 600          # temps de l'autre fiche conserve


def test_deux_plateformes_meme_titre_restent_separees():
    from orion.core.doublons import dedoublonner
    a = Game(title="Rocket League", source="steam", source_id="252950",
             install_dir=r"C:\Steam\common\rocketleague")
    b = Game(title="Rocket League", source="epic", source_id="Sugar",
             install_dir=r"C:\Epic\rocketleague")
    assert len(dedoublonner([a, b])) == 2


def test_chemins_vdf_double_antislash():
    from orion.core.doublons import chemin_cle
    assert chemin_cle("D:\\\\Games\\\\X") == chemin_cle(r"d:\games\x\\")


# -- recherche : le ™ creait des doublons dans la Boutique (1.6.1) ----------
def test_marque_deposee_ignoree():
    from orion.core.recherche import normaliser
    assert normaliser("FOR HONOR™") == normaliser("For Honor")
    assert normaliser("Tom Clancy's®") == normaliser("tom clancy's")


def test_recherche_tolerante():
    from orion.core.recherche import correspond, classer
    assert correspond("cyberpunk", "Cyberpunk 2077")
    assert correspond("witcher", "The Witcher 3: Wild Hunt")
    assert classer("gta", ["Grand Theft Auto V", "Portal 2"])[0] == "Grand Theft Auto V"


# -- traduction : decoupage sans perte (bug rfind -1, 1.6.1) ----------------
def test_decoupage_sans_perte():
    from orion.core.traduction import decouper
    texte = ("Premier paragraphe. " * 80 + "\n\n" + "motsansespace" * 300
             + "\nFin.")
    morceaux = decouper(texte, 500)
    assert "".join(morceaux) == texte
    assert all(len(m) <= 500 for m in morceaux)


def test_detection_langue():
    from orion.core.traduction import langue_probable, semble_anglais_plutot_que_francais
    assert langue_probable("Привет мир") == "ru"
    assert langue_probable("Hello world") == "en"
    assert semble_anglais_plutot_que_francais("This is the update for the game and we have fixed it")
    assert not semble_anglais_plutot_que_francais("Voici la mise a jour du jeu avec des correctifs")


# -- Steam renomme les cles d'appdetails (1.6.1) ----------------------------
def test_fiche_steam_cle_renommee():
    from orion.core.steam_limite import fiche, fiches_groupees
    rep = {"4443530": {"success": True, "data": {"steam_appid": 585420, "name": "Trailmakers"}}}
    assert fiche(rep, 585420)["data"]["name"] == "Trailmakers"
    assert fiche({"1": {"success": True}}, 1)["success"]
    groupe = fiches_groupees({"9": {"a": 1}, "8": {"b": 2}}, ["1", "2"])
    assert groupe == {"1": {"a": 1}, "2": {"b": 2}}


# -- jaquette grise « image vide » du CDN (1.6.2) ---------------------------
def test_image_vide_detectee(tmp_path):
    from PySide6.QtGui import QImage, QColor
    from orion.plugins.artwork.base import image_vide
    img = QImage(300, 450, QImage.Format.Format_Grayscale8)
    img.fill(QColor(128, 128, 128))
    f = tmp_path / "gris.jpg"
    img.save(str(f), "JPG", 60)
    assert image_vide(f)


# -- consignes GamerPower traduites localement (1.6.1) ----------------------
def test_consignes_traduites():
    from orion.plugins.freebies.consignes import traduire_consignes
    fr, complet = traduire_consignes("Click the button to visit the giveaway page.")
    assert fr and "Cliquez" in fr
