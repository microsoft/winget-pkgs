"""La region de cle conseillee suit le pays du joueur (11 octobre 2026) :
un joueur americain lisait « Global ou Europe », et une cle Europe ne
s'active pas aux Etats-Unis."""
import json
from pathlib import Path

from orion import marche_gris as mg

RACINE = Path(__file__).resolve().parents[1]


def test_consigne_par_pays():
    assert "Europe" in mg.consigne("FR") and "Europe" in mg.consigne("BE") and "Europe" in mg.consigne("CH")
    assert "Etats-Unis (US)" in mg.consigne("US") and "Europe" not in mg.consigne("US")
    assert "Royaume-Uni (UK)" in mg.consigne("GB")
    assert "Amerique du Nord" in mg.consigne("CA")
    assert mg.consigne("JP") == mg.CONSIGNES["autre"]
    assert all("« Gift » ni « Account »" in c for c in mg.CONSIGNES.values())


def test_consigne_suit_le_reglage_du_pays(monkeypatch):
    from orion.core import region
    monkeypatch.setattr(region, "pays", lambda: "US")
    assert mg.consigne() == mg.CONSIGNES["US"]


def test_chaque_consigne_est_traduite():
    for nom in ("fr", "en"):
        exact = json.loads((RACINE / "orion" / "langues" / f"{nom}.json").read_text(encoding="utf-8"))["exact"]
        for c in mg.CONSIGNES.values():
            assert c in exact, (nom, c)
    en = json.loads((RACINE / "orion" / "langues" / "en.json").read_text(encoding="utf-8"))["exact"]
    assert "United States (US)" in en[mg.CONSIGNES["US"]]


def test_la_boutique_affiche_la_consigne_du_pays():
    source = (RACINE / "orion" / "ui" / "views" / "boutique_view.py").read_text(encoding="utf-8")
    assert "QLabel(consigne())" in source and "QLabel(CONSIGNE)" not in source
