"""Refonte de la Boutique : A la une, Pour vous, recherche libre.

* suggestions calculees sur la bibliotheque (jamais un jeu possede, raison
  lisible) ;
* vitrine : carrousel, rangees reutilisees (pas de reconstruction), jeux
  possedes absents des rangees ;
* images chargees en arriere-plan et gardees en cache ;
* liens : tout passe par `affiliation.ouvrir`, Gamesplanet prevu sans
  identifiant (lien intact tant qu'il n'est pas renseigne).
"""
from __future__ import annotations

import time

import pytest

from orion.core.models import Game


@pytest.fixture(scope="module")
def app():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


@pytest.fixture(autouse=True)
def hors_ligne(monkeypatch):
    """Aucune image telechargee pendant les tests (adresse suivante, ou
    degrade d'attente)."""
    from orion.ui.widgets.boutique_images import ChargeurImages
    monkeypatch.setattr(ChargeurImages, "telecharger", staticmethod(lambda url, cible: False))
    yield
    ChargeurImages.instance()._pool.waitForDone(3000)     # rien ne part apres le test


@pytest.fixture
def memo(monkeypatch):
    """Fiches Steam detaillees en memoire, propres au test."""
    from orion.boutique import MEMO
    donnees: dict = {}
    monkeypatch.setattr(MEMO, "_donnees", donnees)
    return donnees


def _fiche(titre, appid, prix=9.99, normal=19.99, boutique="Steam", populaire=0):
    from orion.boutique import Fiche
    from orion.plugins.boutique.base import Offre
    remise = int(round(100 - prix * 100 / normal)) if normal > prix else 0
    return Fiche(titre=titre, offres=[Offre(
        titre=titre, boutique=boutique, prix=prix, prix_normal=normal, remise=remise,
        url=f"https://store.steampowered.com/app/{appid}", source="steam",
        steam_appid=appid, type_article="game", populaire=populaire)])


def _catalogue(memo):
    memo.update({
        "1145360": {"tags": ["Roguelike", "Action", "Mythologie"], "devs": ["Supergiant Games"]},
        "1145350": {"tags": ["Roguelike", "Action", "Mythologie"], "devs": ["Supergiant Games"],
                    "avis": 90000, "positifs": 94, "hero": "https://img.test/h2.jpg"},
        "237930": {"tags": ["Action", "RPG", "Science-fiction"], "devs": ["Supergiant Games"],
                   "avis": 30000, "positifs": 95},
        "588650": {"tags": ["Roguelike", "Action", "Metroidvania"], "devs": ["Motion Twin"],
                   "avis": 120000, "positifs": 95},
        "413150": {"tags": ["Simulation", "Agriculture"], "devs": ["ConcernedApe"],
                   "avis": 600000, "positifs": 98},
        "1174180": {"tags": ["Monde ouvert", "Aventure"], "devs": ["Rockstar Games"],
                    "avis": 650000, "positifs": 91, "hero": "https://img.test/rdr2.jpg"},
    })
    return [
        _fiche("Hades", "1145360", 12.49, 24.99),          # deja possede
        _fiche("Hades II", "1145350", 22.49, 29.99, populaire=85),
        _fiche("Transistor", "237930", 3.99, 19.99),
        _fiche("Dead Cells", "588650", 9.99, 24.99),
        _fiche("Stardew Valley", "413150", 10.49, 13.99),
        _fiche("Red Dead Redemption 2", "1174180", 19.79, 59.99, "GOG", populaire=90),
    ]


def _bibli():
    return [Game(title="Hades", source="steam", source_id="1145360", uid="s1",
                 external_seconds=95 * 3600, last_played=time.time() - 3600)]


# ---------------------------------------------------------------------------
# Suggestions
# ---------------------------------------------------------------------------
def test_suggestions_jamais_un_jeu_possede_et_raison_lisible(memo):
    from orion import suggestions as sugg
    fiches = _catalogue(memo)
    jeux = _bibli()
    prof = sugg.profil(jeux, {}, memo, fiches)
    assert prof.nb_jeux == 1
    choix = sugg.suggerer(fiches, prof, sugg.Possedes.depuis(jeux))
    titres = [s.fiche.titre for s in choix]
    assert "Hades" not in titres                     # possede
    assert titres[0] == "Hades II"                   # meme serie, meme studio
    raisons = {s.fiche.titre: s.raison for s in choix}
    assert raisons["Hades II"] == "Dans la lignee de Hades"
    assert raisons["Transistor"] == "Du studio de Hades"
    assert raisons["Dead Cells"] == "Parce que vous jouez a Hades"
    assert "Stardew Valley" not in titres            # rien en commun


def test_a_la_une_gros_jeux_sans_possedes(memo):
    from orion import suggestions as sugg
    fiches = _catalogue(memo)
    une = sugg.a_la_une(fiches, sugg.Possedes.depuis(_bibli()), 3)
    titres = [f.titre for f in une]
    assert titres[0] == "Red Dead Redemption 2"      # notoriete + prix de base
    assert "Hades" not in titres
    assert len(set(sugg.cle_serie(t) for t in titres)) == len(titres)


# ---------------------------------------------------------------------------
# La vue
# ---------------------------------------------------------------------------
def test_vitrine_dans_l_ordre_une_pour_vous_recherche(app, memo):
    from orion.ui.views.boutique_view import BoutiqueView
    vue = BoutiqueView()
    vue.set_bibliotheque(_bibli())
    vue.set_catalogue(_catalogue(memo), time.time(), 12, True)
    # la vitrine d'accueil (a la une, pour vous...) puis les offres du moment
    ordre = [vue.rangees.indexOf(w) for w in (vue.une, vue.sections["pour_vous"][0])]
    assert ordre == sorted(ordre) and -1 not in ordre
    ordre = [vue.vitrine.indexOf(w) for w in (vue.bloc_accueil, vue.section_recherche, vue.grille)]
    assert ordre == sorted(ordre) and -1 not in ordre
    # la recherche ne defile pas avec la page : elle reste dans la barre
    assert vue.barre.isAncestorOf(vue.recherche) and not vue.defile.isAncestorOf(vue.recherche)
    assert vue.une.fiches and vue.une.fiches[0].titre == "Red Dead Redemption 2"
    pour_vous = vue.sections["pour_vous"][1].fiches
    assert pour_vous and all(f.titre != "Hades" for f in pour_vous)
    assert vue.sections["pour_vous"][1].raisons
    # la grille de recherche garde les jeux possedes, marques
    hades = next(f for f in vue._catalogue if f.titre == "Hades")
    assert vue.grille.possede(hades)


def test_actualisation_reutilise_les_widgets_et_garde_la_position(app, memo):
    from orion.ui.views.boutique_view import BoutiqueView
    vue = BoutiqueView()
    vue.resize(900, 700)
    vue.set_bibliotheque(_bibli())
    fiches = [_fiche(f"Jeu {i}", str(1000 + i), 4.99, 19.99) for i in range(20)]
    vue.set_catalogue(fiches, time.time(), 12, True)
    rangee = vue.sections["promos"][1]
    une, grille = vue.une, vue.grille
    rangee.resize(900, rangee.height())
    rangee._decalage = 300.0
    # memes jeux, prix actualises : memes widgets, meme position
    vue.set_catalogue([_fiche(f"Jeu {i}", str(1000 + i), 3.99, 19.99) for i in range(20)],
                      time.time(), 12, True)
    assert vue.sections["promos"][1] is rangee and vue.une is une and vue.grille is grille
    assert rangee._decalage == 300.0
    assert rangee._fondus()[0] > 0 and rangee._fondus()[1] > 0
    # autre selection : retour au debut
    vue.set_catalogue(list(reversed(fiches)), time.time(), 12, True)
    assert rangee._decalage == 0.0


def test_set_bibliotheque_ne_recalcule_pas_sans_changement(app, memo, monkeypatch):
    from orion import suggestions as sugg
    from orion.ui.views import boutique_view
    vue = boutique_view.BoutiqueView()
    vue.set_catalogue(_catalogue(memo), time.time(), 12, True)
    appels = []
    vrai = sugg.suggerer
    monkeypatch.setattr(boutique_view.sugg, "suggerer",
                        lambda *a, **k: appels.append(1) or vrai(*a, **k))
    vue.set_bibliotheque(_bibli())
    vue.set_bibliotheque(_bibli())                  # identique : rien a refaire
    assert len(appels) == 1
    autre = _bibli() + [Game(title="Celeste", source="steam", source_id="504230", uid="s3")]
    vue.set_bibliotheque(autre)
    assert len(appels) == 2


def test_jeux_possedes_absents_des_rangees_de_promos(app, memo):
    from orion.ui.views.boutique_view import BoutiqueView
    vue = BoutiqueView()
    vue.set_bibliotheque(_bibli())
    vue.set_catalogue(_catalogue(memo), time.time(), 12, True)
    for cle in ("promos", "historique"):
        assert all(f.titre != "Hades" for f in vue.sections[cle][1].fiches)


def test_pour_vous_invite_a_analyser_sans_bibliotheque(app, memo):
    from orion.ui.views.boutique_view import INDICE_SANS_JEUX, BoutiqueView
    vue = BoutiqueView()
    vue.set_bibliotheque([])
    vue.set_catalogue(_catalogue(memo), time.time(), 12, True)
    assert not vue.sections["pour_vous"][1].fiches
    assert not vue.indice_pour_vous.isHidden()
    assert vue.indice_pour_vous.text() == INDICE_SANS_JEUX


def test_carrousel_en_pause_quand_la_page_est_cachee(app, memo):
    from PySide6.QtCore import QVariantAnimation
    from orion.ui.widgets.boutique_une import CarrouselUne
    c = CarrouselUne()
    c.resize(1200, 420)
    c.set_fiches(_catalogue(memo)[1:])
    c.show()
    app.processEvents()
    assert c._progres.state() == QVariantAnimation.State.Running
    c.hide()
    assert c._progres.state() == QVariantAnimation.State.Paused
    c.show()
    assert c._progres.state() == QVariantAnimation.State.Running
    c.aller(2)
    assert c.index == 2
    c.hide()


# ---------------------------------------------------------------------------
# Images
# ---------------------------------------------------------------------------
def test_images_chargees_en_arriere_plan_et_gardees(app, tmp_path):
    from PySide6.QtCore import QSize
    from PySide6.QtGui import QColor, QImage
    from orion.ui.widgets.boutique_images import ChargeurImages
    img = QImage(616, 353, QImage.Format.Format_RGB32)
    img.fill(QColor(30, 120, 200))
    chemin = tmp_path / "capsule.jpg"
    img.save(str(chemin))
    ch = ChargeurImages()
    ch.local("https://img.test/capsule.jpg", str(chemin))
    pretes = []
    ch.prete.connect(pretes.append)
    urls = ["https://img.test/absente.jpg", "https://img.test/capsule.jpg"]
    assert ch.image(urls, QSize(200, 114)) is None            # rien de bloquant
    for _ in range(100):
        ch._pool.waitForDone(20)
        app.processEvents()
        pix = ch.image(urls, QSize(200, 114))
        if pix is not None:
            break
    assert pix is not None and pix.size() == QSize(200, 114)
    assert "https://img.test/absente.jpg" in ch._echecs        # adresse suivante essayee
    assert ch.image(urls, QSize(200, 114)) is pix              # deja a la bonne taille


# ---------------------------------------------------------------------------
# Liens : affiliation et Gamesplanet
# ---------------------------------------------------------------------------
def test_gamesplanet_identifiant_dans_le_lien():
    from orion import affiliation as af
    from orion import marche_gris
    from orion.core.config import CONFIG
    CONFIG.set("boutique.liens_partenaires", True, save=False)
    gp = next(p for p in af.PROGRAMMES if p.id == "gamesplanet")
    assert gp.parametres == {"ref": "orion"} and gp.actif
    lien = marche_gris.lien_officiel("gamesplanet", "Hades II")
    assert lien == "https://fr.gamesplanet.com/search?query=Hades+II&ref=orion"
    assert af.est_partenaire(lien)
    # sans identifiant, le lien reste intact
    table = (af.Programme("gamesplanet", "Gamesplanet", ("gamesplanet.com",), {"ref": ""}),)
    nu = "https://fr.gamesplanet.com/search?query=Hades+II"
    assert af.affilier(nu, table) == nu


def test_eneba_et_allkeyshop_jamais_presentes_comme_partenaires():
    from orion import affiliation as af
    from orion import marche_gris
    for site, url in marche_gris.liens("Hades II"):
        if site.id in ("eneba", "allkeyshop"):
            assert not af.est_partenaire(url)
    eneba = next(p for p in af.PROGRAMMES if p.id == "eneba")
    assert not eneba.actif
    assert all(p.id != "allkeyshop" for p in af.PROGRAMMES)


def test_fiche_bouton_gamesplanet_passe_par_affiliation(app, memo, monkeypatch):
    import webbrowser
    from orion import affiliation as af
    from orion.ui.views.boutique_view import FicheLigne
    ouverts = []
    monkeypatch.setattr(webbrowser, "open", ouverts.append)
    monkeypatch.setattr(af, "PROGRAMMES", (
        af.Programme("gamesplanet", "Gamesplanet", ("gamesplanet.com",), {"ref": "Oriongames"}),))
    ligne = FicheLigne(_catalogue(memo)[1], set(), avec_image=False)
    assert ligne.bouton_officiel is not None
    ligne.bouton_officiel.click()
    assert ouverts == ["https://fr.gamesplanet.com/search?query=Hades+II&ref=Oriongames"]
    # jamais de bouton Gamesplanet quand la meilleure offre y est deja
    gp = _fiche("Jeu GP", "42", boutique="Gamesplanet")
    assert FicheLigne(gp, set(), avec_image=False).bouton_officiel is None


def test_fiche_detaillee_jamais_plus_large_que_sa_fenetre(app):
    """Les prix restent a l'ecran : le contenu de la fiche tient dans la
    fenetre, meme avec les liens de boutiques et le comparatif ouvert."""
    from orion.core.config import CONFIG
    from orion.ui.views import boutique_view as B
    CONFIG.set("marche_gris.afficher", True)
    f = _fiche("Red Dead Redemption 2", "1174180", 14.99, 59.99)
    d = B.FicheDialogue(f, set())
    d.ligne.bouton_comparer.setChecked(True)
    d.show()
    assert not hasattr(d.ligne, "bouton_cles")           # bouton retire en 1.9.6
    assert d.ligne.minimumSizeHint().width() <= d.width() - 36


def test_comparatif_separe_officiels_et_revendeurs_de_cles(app, monkeypatch):
    """Les revendeurs de cles ont leur bloc, sous les boutiques officielles,
    avec la regle d'achat ; jamais dans la meme liste."""
    import webbrowser
    from PySide6.QtWidgets import QLabel
    from orion.core.config import CONFIG
    from orion.ui.views import boutique_view as B
    ouverts = []
    monkeypatch.setattr(webbrowser, "open", ouverts.append)
    CONFIG.set("marche_gris.afficher", True)
    CONFIG.set("boutique.liens_partenaires", True)
    ligne = B.FicheLigne(_fiche("Elden Ring", "1245620", 41.99, 59.99), set(), avec_image=False)
    ligne.remplir_comparatif()
    lay = ligne.comparatif_lay
    widgets = [lay.itemAt(i).widget() for i in range(lay.count()) if lay.itemAt(i).widget()]
    textes = [w.text() for w in widgets if isinstance(w, QLabel)]
    i_off = next(i for i, w in enumerate(widgets) if isinstance(w, B.OffreLigne))
    i_rev = next(i for i, w in enumerate(widgets) if isinstance(w, B.RevendeurLigne))
    entetes = [i for i, w in enumerate(widgets) if isinstance(w, QLabel) and w.text().isupper()]
    assert len(entetes) == 2 and entetes[0] < i_off < entetes[1] < i_rev
    assert [r.site.id for r in ligne.lignes_revendeurs] == ["instant-gaming", "kinguin", "loaded"]
    assert B.consigne() in textes          # consigne du pays du joueur (11 octobre)
    ligne.lignes_revendeurs[1].bouton.click()
    assert ouverts and "kinguin.net" in ouverts[0] and "Elden+Ring+CD+Key" in ouverts[0] and "regions" not in ouverts[0] \
        and "r=w0405u433koc0" in ouverts[0]
    # option coupee dans les Reglages : plus aucun revendeur
    CONFIG.set("marche_gris.afficher", False)
    try:
        ligne.remplir_comparatif()
        assert ligne.lignes_revendeurs == []
    finally:
        CONFIG.set("marche_gris.afficher", True)


def test_fenetre_comparer_garde_ses_prix(app):
    """Dans la fenetre « Comparer les boutiques », le comparatif est ouvert
    d'office et aucun bouton ne peut le refermer."""
    from orion.ui.views import boutique_view as B
    v = B.BoutiqueView()
    d = v.ouvrir_fiche(_fiche("Nox", "0", 1.25, 5.45, boutique="GOG"))
    assert d.ligne.bouton_comparer.isHidden()
    assert not d.ligne.comparatif.isHidden()
    assert d.ligne.comparatif_lay.count() >= 2          # l'offre et la note
    d.close()


def test_prix_du_revendeur_seulement_s_il_est_sur_et_moins_cher(app, monkeypatch):
    """Le prix Kinguin n'apparait que s'il est moins cher que la meilleure
    boutique officielle ; le bouton ouvre alors la fiche du jeu, avec
    l'identifiant partenaire."""
    import webbrowser
    from orion.core.config import CONFIG
    from orion.ui.views import boutique_view as B
    ouverts = []
    monkeypatch.setattr(webbrowser, "open", ouverts.append)
    CONFIG.set("marche_gris.afficher", True)
    CONFIG.set("boutique.liens_partenaires", True)
    offre = {"prix": 30.68, "devise": "EUR", "note": 96.3, "ventes": 187881, "vendeur": "V",
             "nom": "n", "url": "https://www.kinguin.net/category/254461/stalker-2-eu-pc-steam-cd-key"}
    ligne = B.FicheLigne(_fiche("S.T.A.L.K.E.R. 2", "1643320", 41.99, 59.99), set(), avec_image=False)
    ligne.remplir_comparatif()
    kinguin = next(r for r in ligne.lignes_revendeurs if r.site.id == "kinguin")
    assert kinguin.prix.text() == "Chercher sur le site"
    ligne._prix_revendeur_recu(offre)
    kinguin = next(r for r in ligne.lignes_revendeurs if r.site.id == "kinguin")
    assert "30,68" in kinguin.prix.text() and kinguin.economie.text() == "-27 %"
    assert "96" in kinguin.vendeur.text() and "187 881" in kinguin.vendeur.text()
    kinguin.bouton.click()
    assert ouverts == [offre["url"] + "?r=w0405u433koc0"]
    # le prix reste apres un nouveau remplissage du comparatif
    ligne.remplir_comparatif()
    kinguin = next(r for r in ligne.lignes_revendeurs if r.site.id == "kinguin")
    assert "30,68" in kinguin.prix.text()
    # pas moins cher que la boutique officielle : rien n'est affiche
    cher = B.FicheLigne(_fiche("S.T.A.L.K.E.R. 2", "1643320", 25.00, 59.99), set(), avec_image=False)
    cher.remplir_comparatif()
    cher._prix_revendeur_recu(offre)
    assert all(r.prix.text() == "Chercher sur le site" for r in cher.lignes_revendeurs)
    # aucune reponse sure du service : rien non plus
    ligne2 = B.FicheLigne(_fiche("Jeu", "5", 41.99, 59.99), set(), avec_image=False)
    ligne2.remplir_comparatif()
    ligne2._prix_revendeur_recu(None)
    assert all(r.prix.text() == "Chercher sur le site" for r in ligne2.lignes_revendeurs)


def test_prix_loaded_vendeur_unique_et_meme_jeu(app, monkeypatch):
    """Loaded (2.0) : vendeur unique, prix lu dans son catalogue par le
    service. Affiche seulement s'il bat les boutiques officielles et si son
    prix public correspond au prix normal du jeu (pas un homonyme)."""
    import webbrowser
    from orion.core.config import CONFIG
    from orion.ui.views import boutique_view as B
    ouverts = []
    monkeypatch.setattr(webbrowser, "open", ouverts.append)
    CONFIG.set("marche_gris.afficher", True)
    CONFIG.set("boutique.liens_partenaires", True)
    offre = {"prix": 28.29, "devise": "EUR", "public": 58.99, "nom": "n",
             "url": "https://www.loaded.com/fr_fr/s-t-a-l-k-e-r-2-heart-of-chernobyl-pc-steam"}
    ligne = B.FicheLigne(_fiche("S.T.A.L.K.E.R. 2", "1643320", 41.99, 59.99), set(), avec_image=False)
    ligne.remplir_comparatif()
    ligne._prix_revendeur_recu({"kinguin": None, "loaded": offre})
    loaded = next(r for r in ligne.lignes_revendeurs if r.site.id == "loaded")
    kinguin = next(r for r in ligne.lignes_revendeurs if r.site.id == "kinguin")
    assert "28,29" in loaded.prix.text() and loaded.economie.text() == "-33 %"
    assert loaded.vendeur.text() == "vendeur unique"
    assert kinguin.prix.text() == "Chercher sur le site"
    loaded.bouton.click()
    assert ouverts == ["https://go.loaded.com/xJDad5?u=https%3A%2F%2Fwww.loaded.com%2Ffr_fr%2F"
                       "s-t-a-l-k-e-r-2-heart-of-chernobyl-pc-steam"]
    # les deux revendeurs a la fois
    k = {"prix": 30.18, "devise": "EUR", "note": 97.5, "ventes": 274244, "vendeur": "V", "nom": "n",
         "url": "https://www.kinguin.net/category/254461/x"}
    ligne._prix_revendeur_recu({"kinguin": k, "loaded": offre})
    assert all("," in r.prix.text() for r in ligne.lignes_revendeurs if r.site.id in ("kinguin", "loaded"))
    # prix public tres different du prix normal du jeu : un homonyme, rien n'est affiche
    autre = B.FicheLigne(_fiche("S.T.A.L.K.E.R. 2", "1643320", 41.99, 19.99), set(), avec_image=False)
    autre.remplir_comparatif()
    autre._prix_revendeur_recu({"loaded": {**offre, "prix": 9.0}})
    assert all(r.prix.text() == "Chercher sur le site" for r in autre.lignes_revendeurs)


def test_offres_des_revendeurs_lues_au_service(monkeypatch, tmp_path):
    """Une seule demande au service pour tous les revendeurs ; la reponse est
    verifiee revendeur par revendeur, puis gardee."""
    import importlib
    from orion import prix_revendeurs
    from orion.core import region, reseau
    P = importlib.reload(prix_revendeurs)         # la vraie fonction (remplacee pendant les tests)
    monkeypatch.setattr(region, "devise", lambda: "EUR")
    monkeypatch.setattr(region, "pays", lambda: "FR")
    appels = []

    class R:
        status_code = 200

        def json(self):
            return {"kinguin": {"prix": 30.18, "devise": "EUR", "note": 97.5, "ventes": 274244,
                                "vendeur": "V", "nom": "n", "url": "https://www.kinguin.net/category/1/x"},
                    "loaded": {"prix": 28.29, "devise": "EUR", "public": 58.99, "nom": "n",
                               "url": "https://www.loaded.com/fr_fr/x-pc-steam"}}

    def get(adresse, **k):
        appels.append((adresse, k["params"]))
        return R()
    monkeypatch.setattr(reseau, "get", get)
    lues = P.offres("987650001", "S.T.A.L.K.E.R. 2: Heart of Chornobyl")
    assert lues["kinguin"]["prix"] == 30.18 and lues["loaded"] == {
        "prix": 28.29, "devise": "EUR", "public": 58.99, "nom": "n",
        "url": "https://www.loaded.com/fr_fr/x-pc-steam"}
    assert appels[0][0].endswith("/prix") and set(appels[0][1]) == {"appid", "titre", "pays"}
    assert P.offres("987650001", "S.T.A.L.K.E.R. 2: Heart of Chornobyl") == lues and len(appels) == 1
    assert P.kinguin("987650001", "S.T.A.L.K.E.R. 2: Heart of Chornobyl")["prix"] == 30.18
    assert P.offres("abc", "x") == {"kinguin": None, "loaded": None}
    # meme jeu ou homonyme
    assert P.meme_jeu(lues["loaded"], 59.99) and not P.meme_jeu(lues["loaded"], 19.99)
    assert not P.meme_jeu(lues["loaded"], 0) and P.meme_jeu(lues["kinguin"], 0)


def test_reponse_du_service_verifiee(monkeypatch):
    from orion import prix_revendeurs as P
    bon = {"prix": 30.68, "devise": "EUR", "note": 96.3, "ventes": 187881, "vendeur": "V",
           "nom": "n", "url": "https://www.kinguin.net/category/1/x"}
    assert P._valider("kinguin", bon)["prix"] == 30.68
    for mauvais in (None, {}, {**bon, "url": "https://exemple.com/x"}, {**bon, "devise": "USD"},
                    {**bon, "prix": "abc"}, {**bon, "prix": -1}, {**bon, "url": "javascript:alert(1)"}):
        assert P._valider("kinguin", mauvais) is None
    # Loaded : vendeur unique, donc ni note ni ventes, mais un prix public obligatoire
    loaded = {"prix": 28.29, "devise": "EUR", "public": 58.99, "nom": "n",
              "url": "https://www.loaded.com/fr_fr/x-pc-steam"}
    assert P._valider("loaded", loaded)["public"] == 58.99
    for mauvais in ({**loaded, "public": None}, {**loaded, "public": 10}, {**loaded, "devise": "GBP"},
                    {**loaded, "url": "https://www.loaded.com.exemple.net/x"},
                    {**loaded, "url": "https://go.loaded.com/c/1"}, {**bon}):
        assert P._valider("loaded", mauvais) is None
    assert P._valider("kinguin", loaded) is None


def test_fiche_s_agrandit_avec_le_nombre_de_boutiques(app):
    """Toutes les lignes se lisent sans defiler, tant que l'ecran le permet."""
    from orion import boutique
    from orion.core.config import CONFIG
    from orion.plugins.boutique.base import Offre
    from orion.ui.views import boutique_view as B
    CONFIG.set("marche_gris.afficher", True)
    petite = B.FicheDialogue(_fiche("Jeu", "1", 10.0, 20.0), set())
    petite.ligne.bouton_comparer.setChecked(True)
    petite.show()
    app.processEvents()
    offres = [Offre("Gros jeu", f"Boutique {i}", 20.0 + i, prix_normal=60.0, source="steam" if i == 0 else "gog",
                    steam_appid="2" if i == 0 else "", url=f"https://exemple.com/{i}") for i in range(9)]
    grande = B.FicheDialogue(boutique.Fiche("Gros jeu", offres), set())
    grande.ligne.bouton_comparer.setChecked(True)
    grande.show()
    app.processEvents()
    # sur un grand ecran : la fenetre suit le nombre de lignes, et une fois a
    # cette hauteur plus rien ne defile (la hauteur est mesuree, pas supposee)
    assert grande.hauteur_voulue(3000) > petite.hauteur_voulue(3000) >= B.FicheDialogue.HAUTEUR_MIN
    assert grande.manque() > 0
    # la fiche se remesure d'elle-meme quand son contenu change (revendeurs,
    # DLC, visuel arrives d'un fil de fond) et se borne alors a l'ecran, qui
    # est petit ici : cet essai mesure la hauteur demandee, pas ce bornage
    app.processEvents()
    grande._ajuster = lambda: None
    grande.resize(grande.width(), grande.hauteur_voulue(3000))
    app.processEvents()
    assert grande.manque() <= 0
    assert grande.defile.verticalScrollBar().maximum() == 0
    # un texte qui passe sur deux lignes dans une fenetre etroite est compte
    etroite = grande.hauteur_voulue(3000)
    grande.resize(grande.minimumWidth(), etroite)
    app.processEvents()
    grande.resize(grande.width(), grande.hauteur_voulue(3000))
    app.processEvents()
    assert grande.defile.verticalScrollBar().maximum() == 0
    # sur un petit ecran : jamais plus haute que l'ecran, la fiche defile
    assert grande.hauteur_voulue(700) == 700
    petite.close(); grande.close()


def test_fiche_ajustee_toute_seule_a_l_ouverture(app, monkeypatch):
    """Le chemin reel : la fenetre s'ouvre, le comparatif arrive ensuite, puis
    le prix du revendeur ; a chaque fois elle prend la hauteur qu'il faut,
    sans qu'on la redimensionne."""
    from orion import boutique
    from orion.core.config import CONFIG
    from orion.plugins.boutique.base import Offre
    from orion.ui.views import boutique_view as B
    CONFIG.set("marche_gris.afficher", True)
    monkeypatch.setattr(B.FicheDialogue, "limite", lambda self: 3000)
    offres = [Offre("Gros jeu", "Steam", 41.99, prix_normal=59.99, source="steam",
                    steam_appid="2", url="https://exemple.com/0")]
    fiche = boutique.Fiche("Gros jeu", offres)
    d = B.FicheDialogue(fiche, set())
    d.ligne.bouton_comparer.setChecked(True)
    d.show()
    for _ in range(4):
        app.processEvents()
    assert d.defile.verticalScrollBar().maximum() == 0
    # le comparatif complet arrive : huit boutiques de plus
    fiche.offres.extend(Offre("Gros jeu", f"Boutique {i}", 45.0 + i, prix_normal=60.0, source="gog",
                              url=f"https://exemple.com/{i}") for i in range(1, 9))
    d.ligne.remplir_comparatif()
    for _ in range(4):
        app.processEvents()
    assert d.defile.verticalScrollBar().maximum() == 0
    assert d.height() > B.FicheDialogue.HAUTEUR_MIN
    d.close()
