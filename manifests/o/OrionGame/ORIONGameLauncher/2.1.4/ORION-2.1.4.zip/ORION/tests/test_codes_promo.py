"""Codes promo des revendeurs partenaires (orion/codes_promo.py, 15 octobre 2026)."""
import datetime as dt
import json
import re
from pathlib import Path

from orion import codes_promo
from orion.marche_gris import RETENUS

RACINE = Path(__file__).resolve().parent.parent
KINGUIN = {"site": "kinguin", "code": "SPOOK5", "remise": "-5 %", "debut": "2026-10-01", "fin": "2026-10-31",
           "quoi": "jeux, logiciels et objets en jeu", "limites": "panier de 150 € au plus, 2 utilisations par client"}


def test_embarques_valides_et_retenus():
    for c in codes_promo.EMBARQUES:
        assert codes_promo.valide(c), c
        assert c["site"] in RETENUS, c


def test_actif_entre_ses_dates_seulement(monkeypatch):
    monkeypatch.setattr(codes_promo, "EMBARQUES", [KINGUIN])
    monkeypatch.setattr(codes_promo, "_distants", None)
    assert [c["code"] for c in codes_promo.actifs("kinguin", dt.date(2026, 10, 1))] == ["SPOOK5"]
    assert [c["code"] for c in codes_promo.actifs("kinguin", dt.date(2026, 10, 31))] == ["SPOOK5"]
    assert codes_promo.actifs("kinguin", dt.date(2026, 9, 30)) == []
    assert codes_promo.actifs("kinguin", dt.date(2026, 11, 1)) == []
    assert codes_promo.actifs("loaded", dt.date(2026, 10, 15)) == []
    assert [c["code"] for c in codes_promo.actifs(None, dt.date(2026, 10, 15))] == ["SPOOK5"]


def test_texte_lisible():
    assert codes_promo.texte(KINGUIN, anglais=False) == ("Code SPOOK5 : -5 % jusqu'au 31 octobre (jeux, logiciels et objets en jeu ; "
                                          "panier de 150 € au plus, 2 utilisations par client).")
    assert codes_promo.texte({**KINGUIN, "fin": "2026-11-01", "quoi": "", "limites": ""}, anglais=False) == "Code SPOOK5 : -5 % jusqu'au 1er novembre."
    assert codes_promo.texte({**KINGUIN, "quoi": "", "limites": ""}, anglais=True) == "Code SPOOK5: -5% until 31 October."


def test_valide_ecarte_les_codes_douteux():
    assert not codes_promo.valide({**KINGUIN, "code": "SPOOK 5"})          # espace : pas un code
    assert not codes_promo.valide({**KINGUIN, "code": "<script>"})
    assert not codes_promo.valide({**KINGUIN, "debut": "2026-11-01"})      # fin avant debut
    assert not codes_promo.valide({**KINGUIN, "fin": "31/10/2026"})
    assert not codes_promo.valide({**KINGUIN, "remise": ""})
    assert not codes_promo.valide("SPOOK5")


def test_liste_en_ligne_remplace_l_embarquee(monkeypatch):
    monkeypatch.setattr(codes_promo, "EMBARQUES", [KINGUIN])
    monkeypatch.setattr(codes_promo, "_distants", None)
    autre = {**KINGUIN, "site": "loaded", "code": "NOEL10", "remise": "-10 %"}
    from orion.core import reseau
    monkeypatch.setattr(reseau, "get_json", lambda url, **k: {"format": 1, "codes": [autre, "bidon"]})
    assert codes_promo.rafraichir()
    assert [c["code"] for c in codes_promo.actifs(None, dt.date(2026, 10, 15))] == ["NOEL10"]
    # format inconnu : la liste en place reste
    monkeypatch.setattr(reseau, "get_json", lambda url, **k: {"format": 99})
    assert not codes_promo.rafraichir()
    assert [c["code"] for c in codes_promo.actifs(None, dt.date(2026, 10, 15))] == ["NOEL10"]
    # panne reseau : pareil
    def casse(url, **k):
        raise OSError("hors ligne")
    monkeypatch.setattr(reseau, "get_json", casse)
    assert not codes_promo.rafraichir()
    monkeypatch.setattr(codes_promo, "_distants", None)


def test_site_meme_source():
    """Le site inscrit la liste de l'application : repere present dans
    comparatif.js, et pour_le_site() ne rend que des codes valides."""
    script = (RACINE / "service" / "site" / "comparatif.js").read_text(encoding="utf-8")
    assert "/*CODES*/[]" in script
    assert "function ligneCode" in script
    contenu = codes_promo.pour_le_site()
    assert contenu["format"] == codes_promo.FORMAT
    assert all(codes_promo.valide(c) for c in contenu["codes"])
    json.dumps(contenu)
    assert re.fullmatch(r"\d{4}-\d{2}-\d{2}", contenu["maj"])
