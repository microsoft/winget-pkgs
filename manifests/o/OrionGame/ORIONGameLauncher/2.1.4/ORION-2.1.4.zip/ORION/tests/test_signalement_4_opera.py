"""Signalement n° 4 (7 octobre 2026, ORION 1.9.8) : « Arret brutal d'ORION ».

Le journal joint disait tout : « Partie detectee : Opera Stable 136.0.6008.52 »
puis « ORION se met en retrait jusqu'a la fin de la partie ». Le scanner des
programmes installes avait garde Opera, et le navigateur, toujours ouvert,
tenait ORION en mode discret (fenetre cachee, mise a jour reportee). Trois
verrous, pour que ni ce cas ni ses cousins ne reviennent."""
import os
import types

from orion.core.models import Game


def test_un_navigateur_ou_un_logiciel_courant_n_est_jamais_un_jeu():
    from orion.plugins.scanners._filters import is_game
    for titre in ("Opera Stable 136.0.6008.52", "Opera GX Stable 120.0.5543.93", "Google Chrome",
                  "Mozilla Firefox (x64 fr)", "Microsoft Edge", "Brave", "Vivaldi 7.1",
                  "Discord", "Spotify", "OBS Studio", "VLC media player", "Telegram Desktop"):
        assert not is_game(titre), titre
    for titre in ("Cyberpunk 2077", "Opera Omnia", "Chrome Valley Customs", "Firefall",
                  "Discolored", "Brave Frontier", "Aniimo", "Counter-Strike 2", "Edge of Eternity"):
        assert is_game(titre), titre


def test_le_scanner_du_registre_ecarte_les_navigateurs(monkeypatch, tmp_path):
    from orion.plugins.scanners import registry_uninstall as R
    opera = tmp_path / "Games" / "Opera"           # installe dans un dossier « Games » : piege
    opera.mkdir(parents=True)
    (opera / "opera.exe").write_bytes(b"MZ" + b"\0" * 600_000)
    jeu = tmp_path / "Games" / "Aniimo"
    jeu.mkdir()
    (jeu / "Aniimo.exe").write_bytes(b"MZ" + b"\0" * 600_000)
    entrees = {
        "Opera 136": {"DisplayName": "Opera Stable 136.0.6008.52", "InstallLocation": str(opera),
                      "Publisher": "Opera Norway AS"},
        "Aniimo": {"DisplayName": "Aniimo", "InstallLocation": str(jeu), "Publisher": "Gamesplanet"},
    }
    monkeypatch.setattr(R, "PATHS", ((0, "racine"),))
    monkeypatch.setattr(R, "reg_subkeys", lambda root, base: list(entrees))
    monkeypatch.setattr(R, "reg_values", lambda root, chemin: entrees[chemin.rsplit("\\", 1)[1]])
    monkeypatch.setattr(R, "PATH_GAME", R.re.compile(r"games", R.re.I))
    titres = [g.title for g in R.RegistryScanner().scan()]
    assert titres == ["Aniimo"]


def test_un_navigateur_ouvert_n_est_pas_une_partie_meme_dans_un_dossier_de_jeu():
    from orion.en_jeu import Processus, jeux_en_cours
    sep = os.sep
    opera = Game(title="Opera Stable", source="registre", source_id="op",
                 install_dir=f"{sep}Games{sep}Opera")
    jeu = Game(title="Aniimo", source="steam", source_id="1", install_dir=f"{sep}Games{sep}Aniimo")
    procs = [Processus(1, "opera.exe", f"{sep}Games{sep}Opera{sep}opera.exe", 500),
             Processus(2, "Aniimo-Win64-Shipping.exe",
                       f"{sep}Games{sep}Aniimo{sep}Aniimo{sep}Binaries{sep}Win64{sep}Aniimo-Win64-Shipping.exe", 4000)]
    assert set(jeux_en_cours([opera, jeu], procs)) == {jeu.uid}
    assert jeux_en_cours([opera], procs[:1]) == {}


def test_le_rapport_donne_la_memoire_video_et_les_ecrans():
    from orion.signalement import _machine
    gpu = types.SimpleNamespace(name="NVIDIA GeForce RTX 5090", vram_mb=32607)
    ecran = types.SimpleNamespace(name="ASUS VG249",
                                  current=types.SimpleNamespace(width=1920, height=1080, refresh=60))
    hw = types.SimpleNamespace(cpu_name="AMD Ryzen 7 9800X3D", cpu_threads=16, ram_gb=61.6,
                               gpus=[gpu, gpu], displays=[ecran])
    lignes = _machine(hw)
    assert "Carte graphique : NVIDIA GeForce RTX 5090 (32 Go)" in lignes
    assert lignes.count("Carte graphique : NVIDIA GeForce RTX 5090 (32 Go)") == 1    # pas deux fois
    assert "Ecran : ASUS VG249 1920x1080 @ 60 Hz" in lignes
    assert not any("?" in l for l in lignes)
