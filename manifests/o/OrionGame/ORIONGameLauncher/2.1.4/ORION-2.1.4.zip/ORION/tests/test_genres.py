"""Types de jeux de la Boutique : reconnaissance et ordre d'affichage."""
import sys
sys.path.insert(0, "tests")

from orion import genres


class _F:
    def __init__(self, titre, etiquettes, avis=0):
        self.titre, self.etiquettes, self.avis = titre, etiquettes, avis


def test_reconnaissance_des_types():
    assert genres.types_de(["FPS", "Multijoueur"]) >= {"fps"}
    assert genres.types_de(["Stratégie en temps réel"]) >= {"rts", "strategie"}
    assert "rts" not in genres.types_de(["Stratégie"])          # « str » : mot entier
    assert genres.types_de(["MMORPG"]) == {"mmorpg"}
    assert genres.types_de(["Massivement multijoueur"]) == {"mmo"}
    assert genres.types_de(["MOBA"]) == {"moba"}
    assert genres.types_de(["Rogue-like", "Indépendant"]) == {"roguelike", "inde"}
    assert genres.types_de([]) == set()


def test_colonne_des_types_dans_la_boutique():
    from PySide6.QtWidgets import QApplication
    app = QApplication.instance() or QApplication([])
    import test_boutique_refonte as T
    from orion.boutique import MEMO
    from orion.ui.views import boutique_view as B
    MEMO._donnees = {str(1000 + i): {"tags": ["FPS", "Action"], "avis": 1000 * i}
                     for i in range(20)}
    MEMO._donnees["2000"] = {"tags": ["MOBA"], "avis": 5}
    fiches = [T._fiche(f"Tir {i}", str(1000 + i)) for i in range(20)] + [T._fiche("Arene", "2000")]
    v = B.BoutiqueView()
    v.set_catalogue(fiches, 0.0, 12, False)
    assert {"", "fps", "moba", "action"} <= set(v.boutons_types)
    # un type sans jeu releve a son bouton aussi : sa page se remplit a la
    # demande depuis le magasin (7 octobre : « tout doit etre dispo »)
    assert "rts" in v.boutons_types and v.boutons_types["fps"].text() == "FPS"
    v.choisir_type("fps")
    # la page du type : ses vingt jeux, le plus connu en tete, rien d'autre
    titres = [f.titre for f in v.visibles()]
    assert len(titres) == 20 and titres[0] == "Tir 19" and "Arene" not in titres
    assert v.en_liste() and v.bloc_accueil.isHidden() and not v.retour.isHidden()
    assert v.boutons_types["fps"].isChecked()
    v.choisir_type("")
    assert not v.en_liste() and not v.bloc_accueil.isHidden() and v.retour.isHidden()
    assert v.boutons_types[""].isChecked()
    MEMO.vider()
