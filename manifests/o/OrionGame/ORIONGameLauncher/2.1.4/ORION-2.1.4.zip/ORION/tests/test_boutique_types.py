"""Pages de type bien remplies : ORION demande a Steam les jeux les plus en
vue de chaque type (FPS, MOBA, Battle Royale...), en promotion ou non.
Reponses de Steam relevees le 6 octobre 2026 (formes reelles, raccourcies)."""
import time

import pytest

from orion.plugins.boutique import steam
from orion.plugins.boutique.base import SourceUnavailable

ETIQUETTES = {1663: "FPS", 1718: "MOBA", 113: "Free-to-play", 19: "Action", 122: "RPG",
              3859: "Multijoueur", 1695: "Monde ouvert", 4175: "Realiste"}
OVERWATCH = {"item_type": 0, "id": 2357570, "success": 1, "visible": True, "name": "Overwatch®",
             "appid": 2357570, "type": 0, "is_free": True, "tagids": [113, 1663, 3859],
             "tags": [{"tagid": 113, "weight": 900}, {"tagid": 1663, "weight": 800}, {"tagid": 3859, "weight": 500}],
             "reviews": {"summary_filtered": {"review_count": 426375, "percent_positive": 31}},
             "basic_info": {"developers": [{"name": "Blizzard Entertainment"}]}, "assets": {}}
CYBERPUNK = {"item_type": 0, "id": 1091500, "success": 1, "visible": True, "name": "Cyberpunk 2077",
             "appid": 1091500, "type": 0, "content_descriptorids": [1, 2, 5], "tagids": [122, 1695, 19],
             "tags": [{"tagid": 122, "weight": 900}, {"tagid": 1695, "weight": 800}, {"tagid": 19, "weight": 500}],
             "reviews": {"summary_filtered": {"review_count": 720000, "percent_positive": 76}},
             "basic_info": {"developers": [{"name": "CD PROJEKT RED"}]}, "assets": {},
             "best_purchase_option": {"final_price_in_cents": "1799", "original_price_in_cents": "5999",
                                      "discount_pct": 70, "active_discounts": [{"discount_end_date": 1791478800}]}}
PLEIN_TARIF = {"id": 111, "appid": 111, "success": 1, "visible": True, "name": "Arena  of   Kings",
               "type": 0, "tagids": [1718], "tags": [{"tagid": 1718, "weight": 10}], "assets": {},
               "best_purchase_option": {"final_price_in_cents": "1999"}}
SANS_PRIX = {"id": 222, "appid": 222, "success": 1, "visible": True, "name": "Pas encore en vente", "type": 0}
DLC = {"id": 333, "appid": 333, "success": 1, "visible": True, "name": "Un DLC", "type": 4,
       "best_purchase_option": {"final_price_in_cents": "499"}}
CACHE = {"id": 444, "appid": 444, "success": 1, "visible": False, "name": "Cache", "type": 0, "is_free": True}
ADULTE = {"id": 555, "appid": 555, "success": 1, "visible": True, "name": "Reserve", "type": 0,
          "content_descriptorids": [3], "best_purchase_option": {"final_price_in_cents": "999"}}


def test_offre_d_un_article_du_magasin():
    o = steam.offre_item(CYBERPUNK)
    assert (o.titre, o.prix, o.prix_normal, o.remise) == ("Cyberpunk 2077", 17.99, 59.99, 70)
    assert o.fin_promo == 1791478800 and o.steam_appid == "1091500" and o.type_article == "game"
    assert o.url == "https://store.steampowered.com/app/1091500" and o.boutique == "Steam"
    gratuit = steam.offre_item(OVERWATCH)
    assert gratuit.prix == 0 and gratuit.gratuit and gratuit.remise == 0
    plein = steam.offre_item(PLEIN_TARIF)
    assert (plein.titre, plein.prix, plein.prix_normal, plein.remise) == ("Arena of Kings", 19.99, 19.99, 0)
    for invendable in (SANS_PRIX, DLC, CACHE, {}, {"appid": "x"}):
        assert steam.offre_item(invendable) is None


class _Reponse:
    def __init__(self, code, donnees):
        self.status_code, self._d = code, donnees

    def json(self):
        return self._d


def _steam(monkeypatch, items, code=200, vus=None):
    from orion.core import reseau

    def get(url, **kw):
        if vus is not None:
            vus.append((url, kw.get("params")))
        return _Reponse(code, {"response": {"store_items": items}})
    monkeypatch.setattr(reseau, "get", get)


def test_par_type_un_appel_et_le_jeu_reste_dans_son_type(monkeypatch):
    import json
    from orion import genres
    vus = []
    _steam(monkeypatch, [OVERWATCH, PLEIN_TARIF, SANS_PRIX, DLC, ADULTE, None], vus=vus)
    offres, fiches = steam.par_type("moba", etiquettes=ETIQUETTES)
    assert len(vus) == 1 and vus[0][0] == steam.QUERY
    demande = json.loads(vus[0][1]["input_json"])
    assert demande["query"]["filters"]["tagids_must_match"] == [{"tagids": ["1718"]}]
    assert demande["query"]["filters"]["type_filters"] == {"include_games": True}
    assert demande["query"]["count"] == 100 and demande["query"]["sort"] == steam.TRI_EN_VUE
    assert [o.titre for o in offres] == ["Overwatch®", "Arena of Kings", "Reserve"]
    assert [o.adulte for o in offres] == [False, False, True]     # la Boutique ecartera le dernier
    # Overwatch n'a pas « MOBA » dans ses premieres etiquettes : le type lui est ajoute
    assert "moba" in genres.types_de(fiches["2357570"]["tags"])
    assert fiches["2357570"]["tags"][:2] == ["Free-to-play", "FPS"] and fiches["2357570"]["avis"] == 426375
    assert fiches["111"]["tags"] == ["MOBA"]                      # deja la : pas de doublon
    # sans les noms d'etiquettes, pas de fiche bancale : elle sera lue plus tard
    assert steam.par_type("moba")[1] == {}
    assert steam.par_type("type-inconnu") == ([], {})
    _steam(monkeypatch, [], code=429)
    with pytest.raises(SourceUnavailable):
        steam.par_type("fps", etiquettes=ETIQUETTES)


def test_chaque_type_d_orion_a_son_etiquette_steam():
    from orion import genres
    assert set(steam.ETIQUETTES_TYPES) == set(genres.LIBELLES)
    assert len(set(steam.ETIQUETTES_TYPES.values())) == len(steam.ETIQUETTES_TYPES)


@pytest.fixture()
def service(monkeypatch, tmp_path):
    from orion import boutique
    from orion.core.config import CONFIG
    s = boutique.BoutiqueService.__new__(boutique.BoutiqueService)
    s._etiquettes = dict(ETIQUETTES)
    s._types = {}                                    # un dictionnaire a la place de la table

    class Table(dict):
        def set(self, cle, valeur):
            self[cle] = valeur
    s._types = Table()
    ajoutes = {}
    monkeypatch.setattr(boutique.MEMO, "ajouter", ajoutes.update)
    avant = CONFIG.get("boutique.types_complets")
    CONFIG.set("boutique.types_complets", True, save=False)
    yield s, ajoutes
    CONFIG.set("boutique.types_complets", avant, save=False)


def test_les_types_se_remplissent_peu_a_peu_et_restent_en_memoire(service, monkeypatch):
    from orion.core.config import CONFIG
    s, ajoutes = service
    demandes = []

    def par_type(cle, nombre=100, etiquettes=None):
        demandes.append(cle)
        o = steam.offre_item(dict(PLEIN_TARIF, appid=1000 + len(demandes), name="Jeu " + cle))
        return [o], {o.steam_appid: {"tags": ["x"]}}
    monkeypatch.setattr(steam, "par_type", par_type)
    # par defaut tous les types sont relus d'un coup (apres l'affichage) ; le
    # passage par lots reste possible, et c'est lui qu'on essaie ici
    assert s.TYPES_PAR_PASSAGE >= len(steam.ETIQUETTES_TYPES)
    monkeypatch.setattr(type(s), "TYPES_PAR_PASSAGE", 4)
    assert s.offres_par_type(relire=False) == [] and demandes == []     # sans reseau : ce qui est garde
    offres = s.offres_par_type()
    assert len(demandes) == s.TYPES_PAR_PASSAGE == len(offres)     # quelques types par passage
    assert len(ajoutes) == s.TYPES_PAR_PASSAGE
    premiers = list(demandes)
    offres = s.offres_par_type()
    assert len(demandes) == 2 * s.TYPES_PAR_PASSAGE and not set(premiers) & set(demandes[4:])
    assert len(offres) == 2 * s.TYPES_PAR_PASSAGE                  # les premiers viennent de la memoire
    while len(s._types) < len(steam.ETIQUETTES_TYPES):
        s.offres_par_type()
    n = len(demandes)
    assert sorted(demandes) == sorted(steam.ETIQUETTES_TYPES)
    assert len(s.offres_par_type()) == len(steam.ETIQUETTES_TYPES) and len(demandes) == n   # tout est frais
    # six heures plus tard : les plus anciens sont relus
    for v in s._types.values():
        v["le"] = time.time() - s.TYPES_DUREE - 10
    s.offres_par_type()
    assert len(demandes) == n + s.TYPES_PAR_PASSAGE

    # Steam ne repond pas : rien n'est perdu, et on n'insiste pas
    def panne(cle, nombre=100, etiquettes=None):
        demandes.append("panne")
        raise SourceUnavailable("Steam")
    monkeypatch.setattr(steam, "par_type", panne)
    assert len(s.offres_par_type()) == len(steam.ETIQUETTES_TYPES)
    assert demandes.count("panne") == 1
    # reglage coupe : aucune demande, aucune offre
    CONFIG.set("boutique.types_complets", False, save=False)
    assert s.offres_par_type() == [] and demandes.count("panne") == 1


def test_un_jeu_plein_tarif_arrive_sur_la_page_de_son_type():
    """De bout en bout : offre de Steam -> catalogue -> page « MOBA »."""
    from PySide6.QtWidgets import QApplication
    app = QApplication.instance() or QApplication([])   # noqa: F841
    from orion import boutique
    from orion.ui.views.boutique_view import BoutiqueView
    boutique.MEMO.vider()
    try:
        offres = [steam.offre_item(PLEIN_TARIF), steam.offre_item(OVERWATCH), steam.offre_item(CYBERPUNK)]
        boutique.MEMO._donnees.update({
            "111": steam.lire_item(PLEIN_TARIF, ETIQUETTES),
            "2357570": dict(steam.lire_item(OVERWATCH, ETIQUETTES),
                            tags=["Free-to-play", "FPS", "Multijoueur", "MOBA"]),
            "1091500": steam.lire_item(CYBERPUNK, ETIQUETTES)})
        v = BoutiqueView()
        v.set_catalogue(boutique.fusionner(offres), time.time(), 12, True)
        v.choisir_type("moba")
        assert [f.titre for f in v.visibles()] == ["Overwatch®", "Arena of Kings"]   # le plus connu d'abord
        # plein tarif : present dans « Tout », absent des « Meilleures affaires »
        next(b for b in v.groupe.buttons() if b.property("cle") == "affaires").click()
        assert v.visibles() == []
        v.accueil()
        assert [f.titre for f in v.visibles()] == ["Cyberpunk 2077"]      # l'accueil reste aux promotions
    finally:
        boutique.MEMO.vider()


# ---------------------------------------------------------------------------
# La suite du magasin, a la demande (7 octobre 2026)
# ---------------------------------------------------------------------------
def test_page_du_magasin_a_partir_d_un_rang(monkeypatch):
    import json
    from orion.core import reseau
    vus = []

    def get(url, **kw):
        vus.append(json.loads(kw["params"]["input_json"]))
        return _Reponse(200, {"response": {"metadata": {"total_matching_records": 7093, "start": 100,
                                                        "count": 100},
                                           "store_items": [CYBERPUNK, PLEIN_TARIF, DLC, SANS_PRIX]}})
    monkeypatch.setattr(reseau, "get", get)
    offres, fiches, total = steam.page_magasin("fps", 100, 100, ETIQUETTES)
    assert total == 7093 and [o.titre for o in offres] == ["Cyberpunk 2077", "Arena of Kings"]
    q = vus[0]["query"]
    assert q["start"] == 100 and q["count"] == 100
    assert q["filters"]["tagids_must_match"] == [{"tagids": ["1663"]}]
    assert "FPS" in fiches["1091500"]["tags"]
    # tout le magasin : pas de filtre d'etiquette
    steam.page_magasin("", 2000, 100, ETIQUETTES)
    assert "tagids_must_match" not in vus[1]["query"]["filters"] and vus[1]["query"]["start"] == 2000
    assert steam.page_magasin("pas-un-type") == ([], {}, 0)


def test_le_service_avance_de_cent_en_cent_et_garde_la_suite(base_neuve, monkeypatch):
    from orion import boutique
    appels = []

    def page(cle, debut, nombre, etiquettes):
        appels.append((cle, debut))
        if debut >= 300:
            return [], {}, 250
        offres = [steam._offre(90000 + debut + i, f"Jeu {cle} {debut + i}", 999, 999) for i in range(3)]
        return offres, {o.steam_appid: {"tags": ["FPS"]} for o in offres}, 250
    monkeypatch.setattr(steam, "page_magasin", page)
    monkeypatch.setattr(steam, "noms_etiquettes", lambda: ETIQUETTES)
    s = boutique.BoutiqueService()
    s.SUITE_UTILE = 1                               # ici, un lot par demande
    s.fiches = []
    assert s.suite_possible("fps")
    nouvelles = s.suite("fps")
    assert appels == [("fps", 0)] and len(nouvelles) == 3 and len(s.fiches) == 3
    assert [f.titre for f in s.suite("fps")] == ["Jeu fps 100", "Jeu fps 101", "Jeu fps 102"]
    s.suite("fps")                                  # rang 200 : Steam annonce 250 jeux, c'est le bout
    assert appels[-1] == ("fps", 200) and not s.suite_possible("fps")
    assert s.suite("fps") == [] and len(appels) == 3        # plus aucun appel
    assert len(s.fiches) == 9
    # tout le magasin a son propre compteur
    s.suite("")
    assert ("", 0) in appels
    # un jeu deja au catalogue n'est pas ajoute deux fois
    s._suites["fps"] = {"debut": 0, "fini": False, "total": 0}
    assert s.suite("fps") == []
    # une actualisation garde ce qui a ete charge a la demande
    assert len(s._suite_gardee()) == 9
    for o in s._offres_suite.values():
        o.releve_le -= 7 * 3600
    assert s._suite_gardee() == [] and s._suites == {}


def test_steam_muet_la_page_garde_ce_qu_elle_a(base_neuve, monkeypatch):
    from orion import boutique

    def page(*a):
        raise SourceUnavailable("Jeux du type fps : reponse 503")
    monkeypatch.setattr(steam, "page_magasin", page)
    monkeypatch.setattr(steam, "noms_etiquettes", lambda: ETIQUETTES)
    s = boutique.BoutiqueService()
    assert s.suite("fps") == [] and s.suite_possible("fps")     # on pourra redemander


def test_la_suite_des_promotions(base_neuve, monkeypatch):
    from orion import boutique
    vus = []

    def fetch(url, params=None, **kw):
        vus.append(dict(params or {}))
        return {"items": [{"name": "Cyberpunk 2077", "logo": "https://x/steam/apps/1091500/c.jpg"},
                          {"name": "Un lot", "logo": "https://x/steam/bundles/5/c.jpg"},
                          {"name": "Arena", "logo": "https://x/steam/apps/111/c.jpg"}]}
    monkeypatch.setattr(steam, "fetch_json", fetch)
    monkeypatch.setattr(steam, "articles", lambda ids: [a for a in (CYBERPUNK, PLEIN_TARIF)
                                                        if str(a["appid"]) in ids])
    monkeypatch.setattr(steam, "noms_etiquettes", lambda: ETIQUETTES)
    s = boutique.BoutiqueService()
    s.fiches = []
    nouvelles = s.suite("promos")
    assert vus[0]["specials"] == 1 and vus[0]["start"] == 200 and vus[0]["category1"] == 998
    assert {f.titre for f in nouvelles} == {"Cyberpunk 2077", "Arena of Kings"}
    s.suite("promos")
    assert vus[1]["start"] == 300 and s.suite_possible("promos")


def test_les_listes_de_promotions_demandent_la_suite_des_promotions():
    from PySide6.QtWidgets import QApplication
    QApplication.instance() or QApplication([])
    import test_boutique_pages as P
    from orion.boutique import MEMO
    MEMO.vider()
    v = P._vue(MEMO._donnees)
    demandes = []
    v.suite_demandee.connect(demandes.append)
    P._cocher(v, "affaires")
    v.pages.plus.emit()
    P._cocher(v, "15")
    v.pages.plus.emit()
    v.choisir_type("fps")
    P._cocher(v, "affaires")
    v.pages.plus.emit()
    assert [d for i, d in enumerate(demandes) if i == 0 or d != demandes[i - 1]] == ["promos", "", "fps"]
    MEMO.vider()


def test_plus_de_jeux_en_amene_meme_si_le_premier_lot_est_deja_connu(base_neuve, monkeypatch):
    """Vu dans le journal du 7 octobre : « 3 jeux de plus (fps, rang 100) »
    pour un clic. Un lot qui n'apporte presque rien fait demander le suivant
    dans la foulee, trois lots au plus."""
    from orion import boutique
    appels = []

    def page(cle, debut, nombre, etiquettes):
        appels.append(debut)
        combien = 2 if debut == 0 else 40
        offres = [steam._offre(70000 + debut + i, f"Jeu {debut + i}", 999, 999) for i in range(combien)]
        return offres, {o.steam_appid: {"tags": ["FPS"]} for o in offres}, 7000
    monkeypatch.setattr(steam, "page_magasin", page)
    monkeypatch.setattr(steam, "noms_etiquettes", lambda: ETIQUETTES)
    s = boutique.BoutiqueService()
    s.fiches = []
    nouvelles = s.suite("fps")
    assert appels == [0, 100] and len(nouvelles) == 42
    # Steam muet au deuxieme lot : on rend ce qu'on a, sans insister
    appels.clear()

    def muet(cle, debut, nombre, etiquettes):
        appels.append(debut)
        raise boutique.SourceUnavailable("Steam ne repond pas")
    monkeypatch.setattr(steam, "page_magasin", muet)
    assert s.suite("fps") == [] and appels == [200]

