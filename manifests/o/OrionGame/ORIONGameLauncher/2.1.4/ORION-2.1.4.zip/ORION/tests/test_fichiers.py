"""Chemins qui ne se laissent pas interroger (orion/core/fichiers.py, 15 octobre 2026)."""
from pathlib import Path
from unittest import mock

from orion.core import fichiers


def test_existe_et_est_dossier_sans_exception(tmp_path):
    assert fichiers.existe(tmp_path) and fichiers.est_dossier(tmp_path)
    assert not fichiers.existe(tmp_path / "absent") and not fichiers.est_dossier(tmp_path / "absent")
    f = tmp_path / "f.txt"; f.write_text("x")
    assert fichiers.est_fichier(f) and not fichiers.est_dossier(f)
    # une jonction morte : Windows repond « Fonction incorrecte » (WinError 1)
    with mock.patch("os.path.exists", side_effect=OSError(22, "Fonction incorrecte")), \
            mock.patch("os.path.isdir", side_effect=OSError(22, "Fonction incorrecte")):
        assert not fichiers.existe(tmp_path) and not fichiers.est_dossier(tmp_path)
    assert not fichiers.existe("\x00")                 # ValueError : chemin impossible


def test_remise_en_ordre_passe_au_jeu_suivant(tmp_path, monkeypatch):
    """Un jeu deplace sur un disque debranche (jonction morte) est signale,
    et les autres jeux sont quand meme verifies (avant : exception, et plus
    rien n'etait examine, scan compris)."""
    from orion import deplacement as D
    from orion.core.models import Game
    mort = Game(uid="a", title="Undisputed", source="steam", source_id="1", install_dir=str(tmp_path / "Undisputed"))
    mort.extra["deplace"] = {"vers": "F:\\Jeux ORION\\Undisputed", "le": 1.0}
    vivant = Game(uid="b", title="Autre", source="steam", source_id="2", install_dir=str(tmp_path / "Autre"))
    (tmp_path / "Autre").mkdir()
    monkeypatch.setattr(D, "est_jonction", lambda p: Path(p).name == "Undisputed")
    monkeypatch.setattr(D, "existe", lambda p: False if Path(p).name == "Undisputed" else Path(p).exists())
    vus = []
    monkeypatch.setattr(D, "_reparer_jeu", lambda g, r: vus.append(g.title))
    r = D.reparer_restes([mort, vivant], [])
    assert vus == ["Autre"]
    # 16 octobre : un disque absent n'est pas une copie interrompue (la boite
    # « Copie de jeu interrompue » s'ouvrait a chaque lancement d'ORION)
    assert r.restes == []
    assert any("Undisputed" in x and "disque absent" in x for x in r.absents)


def test_plan_d_un_jeu_sur_jonction_morte_ne_plante_pas(tmp_path):
    """16 octobre (journal de l'auteur, 281 fois) : `build_plan` sur Half Sword,
    dont le dossier Steam est une jonction vers un disque debranche, levait
    `OSError [WinError 1] Fonction incorrecte` dans `discovery.unreal_project`
    (Path.is_dir), et la fiche affichait « Erreur : Fonction incorrecte »."""
    import os
    from orion.core.models import Game
    from orion.optimizer import discovery
    mort = str(tmp_path / "Half Sword")
    vrai_stat = os.stat

    def stat_mort(chemin, *a, **k):
        if str(chemin).startswith(mort):
            raise OSError(1, "Fonction incorrecte", str(chemin))
        return vrai_stat(chemin, *a, **k)
    jeu = Game(uid="hs", title="Half Sword", source="steam", source_id="2397300",
               install_dir=mort, engine="unreal")
    with mock.patch("os.stat", side_effect=stat_mort):
        with mock.patch.dict(os.environ, {"LOCALAPPDATA": str(tmp_path / "local")}):
            ctx = discovery.context_for(jeu)        # ne leve plus
    assert ctx["install_dir"] == mort
    assert isinstance(ctx.get("ue_project"), str)


def test_resolution_des_cibles_sur_jonction_morte(tmp_path):
    import os
    from orion.optimizer import engine
    mort = tmp_path / "Half Sword"
    vrai_stat = os.stat

    def stat_mort(chemin, *a, **k):
        if str(chemin).startswith(str(mort)):
            raise OSError(1, "Fonction incorrecte", str(chemin))
        return vrai_stat(chemin, *a, **k)
    with mock.patch("os.stat", side_effect=stat_mort):
        trouves = engine._resolve_paths([str(mort / "Saved" / "Config" / "Engine.ini")], {}, True)
    assert trouves == []
