"""IsThereAnyDeal sans cle a creer : ORION passe par le relais de son service,
qui porte la cle de l'application. Une cle personnelle fait passer en direct."""
import time

import pytest

from orion import itad
from orion.core.config import CONFIG


class Reponse:
    def __init__(self, code=200, donnees=None):
        self.status_code, self._d = code, donnees

    def json(self):
        if self._d is None:
            raise ValueError("pas de JSON")
        return self._d


@pytest.fixture()
def reseau(monkeypatch):
    """Remplace le reseau : `appels` recoit chaque demande, `repondre` la sert."""
    from orion.core import reseau as r
    avant = {k: CONFIG.get(k) for k in ("market.itad_key", itad.ETAT, "market.country")}
    CONFIG.set("market.itad_key", "", save=False)
    CONFIG.set(itad.ETAT, {}, save=False)
    CONFIG.set("market.country", "FR", save=False)
    etat = {"appels": [], "repondre": lambda *a, **k: Reponse(200, {})}

    def requete(methode, url, **kw):
        etat["appels"].append((methode, url, dict(kw.get("params") or {}), kw.get("json")))
        return etat["repondre"](methode, url, **kw)
    monkeypatch.setattr(r, "requete", requete)
    monkeypatch.setattr(CONFIG, "save", lambda *a, **k: None, raising=False)
    yield etat
    for k, v in avant.items():
        CONFIG.set(k, v, save=False)


def test_sans_cle_la_demande_passe_par_le_service_et_ne_porte_aucune_cle(reseau):
    assert itad.actif()                                  # rien a configurer
    reseau["repondre"] = lambda *a, **k: Reponse(200, {"list": []})
    assert itad.demander("GET", "/deals/v2", {"country": "FR", "limit": 200, "sort": ""}) == {"list": []}
    methode, url, params, corps = reseau["appels"][0]
    assert (methode, url) == ("GET", "https://api.orion-launcher.com/itad/deals/v2")
    assert params == {"country": "FR", "limit": 200} and "key" not in params and corps is None
    assert CONFIG.get(itad.ETAT)["actif"] is True


def test_avec_une_cle_personnelle_la_demande_part_en_direct(reseau):
    CONFIG.set("market.itad_key", "ma-cle", save=False)
    reseau["repondre"] = lambda *a, **k: Reponse(200, [])
    itad.demander("POST", "/games/prices/v3", {"country": "FR"}, ["abc"])
    methode, url, params, corps = reseau["appels"][0]
    assert url == "https://api.isthereanydeal.com/games/prices/v3"
    assert params == {"country": "FR", "key": "ma-cle"} and corps == ["abc"]
    assert not CONFIG.get(itad.ETAT)                      # l'etat du relais n'est pas touche


def test_relais_ferme_orion_le_retient_puis_reessaie(reseau):
    reseau["repondre"] = lambda *a, **k: Reponse(503, {"erreur": "relais non configure"})
    with pytest.raises(itad.Indisponible):
        itad.demander("GET", "/deals/v2", {"country": "FR"})
    assert not itad.actif()                              # la Boutique retombe sur Steam et GOG
    CONFIG.set(itad.ETAT, {"actif": False, "vu": time.time() - itad.RETENTER - 5}, save=False)
    assert itad.actif()                                  # quelques heures plus tard : nouvel essai
    CONFIG.set("market.itad_key", "ma-cle", save=False)
    CONFIG.set(itad.ETAT, {"actif": False, "vu": time.time()}, save=False)
    assert itad.actif()                                  # une cle personnelle suffit


def test_une_panne_passagere_ne_ferme_pas_le_relais(reseau):
    for reponse in (Reponse(503, {"erreur": "relais sature"}), Reponse(502, {"erreur": "x"}),
                    Reponse(200, None), Reponse(503, None)):
        reseau["repondre"] = lambda *a, r=reponse, **k: r
        with pytest.raises(itad.Indisponible):
            itad.demander("GET", "/games/lookup/v1", {"appid": "10"})
        assert itad.actif()

    def panne(*a, **k):
        raise OSError("pas de reseau")
    reseau["repondre"] = panne
    with pytest.raises(itad.Indisponible):
        itad.demander("GET", "/games/lookup/v1", {"appid": "10"})
    assert itad.actif()


def test_la_boutique_lit_la_vitrine_par_le_relais(reseau):
    from orion.plugins.boutique.itad import ITADBoutique
    from orion.plugins.boutique.base import SourceUnavailable
    source = ITADBoutique()
    assert source.available()
    jeu = {"id": "018d937f-11e6-715a-a82c-205b93a2b6a2", "title": "Hades", "type": "game",
           "deal": {"shop": {"name": "Fanatical"}, "price": {"amount": 12.5, "currency": "EUR"},
                    "regular": {"amount": 25.0}, "cut": 50, "url": "https://itad.link/abc/"}}
    reseau["repondre"] = lambda *a, **k: Reponse(200, {"list": [jeu]})
    offres = source.vitrine()
    assert len(reseau["appels"]) == 3 and all(u.endswith("/itad/deals/v2") for _m, u, _p, _c in reseau["appels"])
    assert [p.get("sort") for _m, _u, p, _c in reseau["appels"]] == ["-trending", "rank", "-cut"]
    assert all("key" not in p and p["country"] == "FR" for _m, _u, p, _c in reseau["appels"])
    assert offres[0].boutique == "Fanatical" and offres[0].prix == 12.5
    assert offres[0].url == "https://itad.link/abc/"       # le lien d'IsThereAnyDeal, tel quel
    # prix de beaucoup de jeux : par lots de soixante
    reseau["appels"].clear()
    reseau["repondre"] = lambda *a, **k: Reponse(200, [])
    source.prix({f"id{i}": {"title": f"Jeu {i}"} for i in range(130)})
    assert [len(c) for _m, _u, _p, c in reseau["appels"]] == [60, 60, 10]
    # relais ferme : la source se retire, sans erreur pour le reste de la Boutique
    reseau["repondre"] = lambda *a, **k: Reponse(503, {"erreur": "relais non configure"})
    with pytest.raises(SourceUnavailable):
        source.vitrine()
    assert not source.available()


def test_les_prix_d_un_jeu_de_la_bibliotheque_passent_par_le_relais(reseau):
    from orion.core.models import Game
    from orion.plugins.market.base import MarketInfo
    from orion.plugins.market.itad import ITADProvider
    jeu = Game(title="Hades", source="steam", source_id="1145360", uid="s1")
    reponses = {
        "/games/lookup/v1": {"found": True, "game": {"id": "ID1", "title": "Hades"}},
        "/games/prices/v3": [{"id": "ID1", "deals": [
            {"shop": {"name": "GOG"}, "price": {"amount": 9.99, "currency": "EUR"}, "cut": 60,
             "url": "https://itad.link/x/"}]}],
        "/games/historylow/v1": [{"id": "ID1", "low": {"amount": 4.99, "shop": {"name": "Steam"}}}],
    }
    reseau["repondre"] = lambda m, url, **k: Reponse(200, reponses[url.split("/itad", 1)[1]])
    info = MarketInfo(game_uid="s1", title="Hades")
    ITADProvider().fetch(jeu, info)
    assert [u.split("/itad", 1)[1] for _m, u, _p, _c in reseau["appels"]] == list(reponses)
    assert info.best.shop == "GOG" and info.best.price == 9.99 and info.historical_low == 4.99
    assert info.best.url == "https://itad.link/x/"
    # relais ferme : une note claire, et aucun appel
    CONFIG.set(itad.ETAT, {"actif": False, "vu": time.time()}, save=False)
    reseau["appels"].clear()
    info = MarketInfo(game_uid="s1", title="Hades")
    ITADProvider().fetch(jeu, info)
    assert not reseau["appels"] and "indisponible" in info.note


def test_aucune_cle_d_application_dans_le_programme():
    """La cle d'ORION est un secret du service : rien dans les sources."""
    import re
    from pathlib import Path
    racine = Path(__file__).parents[1]
    worker = (racine / "service" / "worker.js").read_text(encoding="utf-8")
    assert "env.ITAD_CLE" in worker and not re.search(r"ITAD_CLE\s*[:=]\s*[\"']", worker)
    for f in (racine / "orion").rglob("*.py"):
        texte = f.read_text(encoding="utf-8")
        assert not re.search(r"key[\"']?\s*[:=]\s*[\"'][0-9a-f]{32,}[\"']", texte), f.name
