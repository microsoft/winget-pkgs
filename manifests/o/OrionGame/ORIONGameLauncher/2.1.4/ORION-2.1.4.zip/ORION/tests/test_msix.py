"""Paquet Microsoft Store : manifeste, vignettes, mode « Store »."""
import importlib.util
import sys
from pathlib import Path
from xml.dom import minidom

from orion import maj

RACINE = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location(
    "construire_msix", RACINE / "outils" / "msix" / "construire.py")
msix = importlib.util.module_from_spec(spec)
spec.loader.exec_module(msix)


def test_manifeste_valide():
    xml = msix.manifeste({"_aide": "x", "nom_paquet": "1234Sikher.ORION",
                          "editeur": "CN=ABC-123", "nom_editeur": "Sik & Co"})
    doc = minidom.parseString(xml)
    ident = doc.getElementsByTagName("Identity")[0]
    assert ident.getAttribute("Name") == "1234Sikher.ORION"
    assert ident.getAttribute("Publisher") == "CN=ABC-123"
    v = ident.getAttribute("Version").split(".")
    assert len(v) == 4 and v[3] == "0"
    assert doc.getElementsByTagName("PublisherDisplayName")[0].firstChild.data == "Sik & Co"


def test_vignettes(tmp_path):
    from PySide6.QtGui import QImage
    msix.logos(tmp_path)
    for nom, (l, h) in msix.LOGOS.items():
        i = QImage(str(tmp_path / nom))
        assert (i.width(), i.height()) == (l, h)
    assert f"Assets\\{'StoreLogo.png'}" in msix.MANIFESTE


def test_mode_store(tmp_path, monkeypatch):
    exe = tmp_path / "ORION.exe"
    exe.write_bytes(b"")
    monkeypatch.setattr(sys, "executable", str(exe))
    assert not maj.depuis_store()
    (tmp_path / maj.MARQUE_STORE).write_text("x")
    assert maj.depuis_store()
