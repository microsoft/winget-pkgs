"""Fluidite de l'interface (2.0, 7 octobre 2026).

Constat mesure sur les donnees reelles de l'auteur : la Boutique redessinait
toutes ses cartes en Python a chaque cran de molette (80 a 100 ms par image),
la page Sorties redessinait tout chaque seconde, chaque frappe dans la
recherche relisait deux mille titres, et les resultats des taches de fond
tombaient dans le fil d'affichage au milieu d'un geste. Ces essais gardent
les remedes : dessins gardes en image, lectures gardees en memoire, mises a
jour de fond au repos, et une vigie qui note tout arret de l'affichage.
"""
import threading
import time

import pytest

from test_boutique_pages import _vue, memo  # noqa: F401  (fabrique et memoire des fiches)
from test_boutique_refonte import _fiche


@pytest.fixture()
def app():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


# ---------------------------------------------------------------------------
# La vigie : tout arret de l'affichage est note, avec sa cause
# ---------------------------------------------------------------------------
def test_la_vigie_note_un_arret_et_ce_qui_tournait(app):
    from orion.core import fluidite
    v = fluidite.Vigie(app, periode=0.02, seuil=0.08, premier_plan=lambda: True)
    v.demarrer()
    try:
        fin = time.perf_counter() + 0.15        # ce que d'autres essais ont laisse s'ecoule
        while time.perf_counter() < fin:
            app.processEvents()
        del v.arrets[:]
        time.sleep(0.35)                            # le fil d'affichage ne repond plus
        app.processEvents()
        longs = [(d, pile) for d, pile in v.arrets if d >= 0.2]
        assert len(longs) == 1 and longs[0][0] <= 1.5 and longs[0][1]
        assert "accrochage" in v.bilan()
    finally:
        v.arreter()


def _arret(app, v, duree=0.35):
    fin = time.perf_counter() + 0.15
    while time.perf_counter() < fin:
        app.processEvents()
    del v.arrets[:]
    v.ecartes = 0
    time.sleep(duree)
    app.processEvents()
    return [d for d, _ in v.arrets if d >= 0.2]


def test_un_arret_derriere_un_jeu_n_est_pas_un_accrochage(app):
    # journal du 10 octobre : 30 arrets sur 98 pendant une partie de Baldur's Gate 3
    from orion.core import fluidite
    v = fluidite.Vigie(app, periode=0.02, seuil=0.08, premier_plan=lambda: False)
    v.demarrer()
    try:
        assert _arret(app, v) == [] and v.ecartes >= 1
        assert "non compte" in v.bilan()
    finally:
        v.arreter()


def test_une_fenetre_de_windows_n_est_pas_un_accrochage(app, monkeypatch):
    # journal du 11 octobre : « i18n.fonction < fenetre_valeur.enregistrer_carte »,
    # c'etait la fenetre « Enregistrer sous » de Windows
    from PySide6.QtWidgets import QFileDialog
    from orion.core import fluidite
    v = fluidite.Vigie(app, periode=0.02, seuil=0.08, premier_plan=lambda: True)
    monkeypatch.setattr(fluidite, "_vigie", v)
    vus = []
    monkeypatch.setattr(QFileDialog, "getSaveFileName",
                        staticmethod(lambda *a, **k: vus.append(v._systeme) or time.sleep(0.35) or ("", "")))
    fluidite._enrober_fenetres_systeme()
    v.demarrer()
    try:
        fin = time.perf_counter() + 0.15
        while time.perf_counter() < fin:
            app.processEvents()
        del v.arrets[:]
        assert QFileDialog.getSaveFileName(None, "x") == ("", "")
        app.processEvents()
        assert vus == [1] and v._systeme == 0
        assert [d for d, _ in v.arrets if d >= 0.2] == [] and v.ecartes >= 1
        assert _arret(app, v) != []                  # hors de la fenetre : compte de nouveau
    finally:
        v.arreter()


def test_la_pile_ne_garde_que_les_appels_d_orion():
    import sys
    from orion.core import fluidite, recherche

    photo = {}

    def espion(*a, **k):
        photo["pile"] = fluidite._pile(sys._getframe())
        return 0.0
    ancien, recherche.sigle = recherche.sigle, espion
    try:
        recherche.score.cache_clear()
        recherche.score("zzqx", "Un titre inconnu")
    finally:
        recherche.sigle = ancien
        recherche.score.cache_clear()
    # ce qui tourne vraiment (entre crochets s'il est hors d'ORION), puis les
    # appels d'ORION qui y ont mene ; rien de ce qui est au-dessus d'ORION
    morceaux = photo["pile"].split(" < ")
    assert morceaux[0] == "[test_fluidite.py:espion]"
    assert morceaux[1].startswith("recherche.score:") and "pytest" not in photo["pile"]
    assert all(m.count(":") == 1 and m.split(":")[1].isdigit() for m in morceaux[1:])


def test_un_long_arret_dit_tous_les_travaux_qui_l_ont_occupe():
    from orion.core import fluidite
    photos = ["a.x:1 < vue.remplir:10 < fenetre.demarrer:5"] * 6 \
        + ["b.y:7 < gratuits.poser:3 < fenetre.demarrer:5"] * 3 + ["[difflib.py:ratio] < r.score:9"]
    resume = fluidite.resumer(photos)
    assert resume.startswith("60 % a.x:1") and "30 % b.y:7" in resume
    assert fluidite.resumer(["seule.pile:1"]) == "seule.pile:1"


# ---------------------------------------------------------------------------
# Mises a jour de fond : jamais au milieu d'un geste
# ---------------------------------------------------------------------------
def test_une_mise_a_jour_de_fond_attend_la_fin_du_geste(app, monkeypatch):
    from orion.ui import repos
    r = repos._Repos(app)
    monkeypatch.setattr(repos, "_instance", r)
    faites = []
    repos.geste()                                   # le joueur fait defiler
    repos.differer("boutique", lambda: faites.append("ancienne"))
    repos.differer("boutique", lambda: faites.append("boutique"))   # la plus recente seulement
    repos.differer("free", lambda: faites.append("free"))
    r._tic()
    assert faites == [] and repos.en_attente("boutique")
    monkeypatch.setattr(repos, "_dernier_geste", time.monotonic() - repos.CALME - 0.1)
    r._tic()
    assert faites == ["boutique"]                   # une seule par passage
    r._tic()
    assert faites == ["boutique", "free"] and not r._minuteur.isActive()


def test_la_page_ouverte_reclame_sa_mise_a_jour_et_rien_ne_se_perd(app, monkeypatch):
    from orion.ui import repos
    r = repos._Repos(app)
    monkeypatch.setattr(repos, "_instance", r)
    faites = []
    repos.geste()
    repos.differer("hardware", lambda: faites.append("hardware"))
    assert repos.faire("hardware") and faites == ["hardware"]
    assert not repos.faire("hardware")              # deja faite
    # le joueur ne s'arrete jamais : la mise a jour part quand meme
    repos.differer("library", lambda: faites.append("library"))
    r.travaux["library"] = (r.travaux["library"][0], time.monotonic() - repos.PATIENCE - 1)
    repos.geste()
    r._tic()
    assert faites == ["hardware", "library"]
    # une mise a jour en echec n'arrete pas les suivantes
    repos.differer("a", lambda: 1 / 0)
    repos.differer("b", lambda: faites.append("b"))
    repos.tout_faire()
    assert faites[-1] == "b"


def test_la_fenetre_applique_tout_de_suite_hors_service_normal():
    from orion.ui.main_window import MainWindow

    class Fenetre:
        mises_a_jour_au_repos = False
        _au_repos = MainWindow._au_repos
    faites = []
    Fenetre()._au_repos("boutique", lambda: faites.append(1))
    assert faites == [1]


# ---------------------------------------------------------------------------
# Dessins gardes en image
# ---------------------------------------------------------------------------
def test_un_dessin_fixe_n_est_refait_que_si_sa_cle_change(app):
    from PySide6.QtGui import QPainter, QPixmap
    from PySide6.QtWidgets import QWidget
    from orion.ui.widgets.tampon import Tampon
    w = QWidget()
    w.resize(120, 60)
    cible = QPixmap(120, 60)
    tampon, dessins = Tampon(), []

    def dessiner(q):
        dessins.append(1)
        return "ici"
    for cle in ("a", "a", "a", "b"):
        p = QPainter(cible)
        tampon.peindre(w, p, cle, dessiner)
        p.end()
    assert len(dessins) == 2 and tampon.rendu == "ici"
    w.resize(140, 60)                               # une autre taille : a refaire
    p = QPainter(cible)
    tampon.peindre(w, p, "b", dessiner)
    p.end()
    assert len(dessins) == 3


def test_une_carte_de_la_boutique_est_dessinee_une_fois(app, memo, monkeypatch):  # noqa: F811
    from PySide6.QtCore import QRectF
    from PySide6.QtGui import QFont
    from orion.ui.widgets import boutique_cartes as bc
    bc.vider_tampons()
    appels = []
    vrai = bc.dessiner_carte
    monkeypatch.setattr(bc, "dessiner_carte", lambda *a, **k: (appels.append(1), vrai(*a, **k))[1])
    f = _fiche("Tir 01", "1001", prix=9.0, normal=18.0)
    r, police = QRectF(10.5, 4.5, 235, 228), QFont()
    un = bc.carte_gardee(r, f, None, False, police, police.key(), "", False, 1.0)
    deux = bc.carte_gardee(r.translated(300, 0), f, None, False, police, police.key(), "", False, 1.0)
    assert un is deux and len(appels) == 1          # meme carte ailleurs : recopiee
    bc.carte_gardee(r, f, None, True, police, police.key(), "", False, 1.0)      # survolee
    assert len(appels) == 2
    f.offres[0].prix = 7.0                          # le prix change : a redessiner
    trois = bc.carte_gardee(r, f, None, False, police, police.key(), "", False, 1.0)
    assert trois is not un and len(appels) == 3
    f.revendeur = {"boutique": "Loaded", "prix": 5.0}
    bc.carte_gardee(r, f, None, False, police, police.key(), "", False, 1.0)
    assert len(appels) == 4
    # la memoire accordee aux cartes est bornee
    monkeypatch.setattr(bc, "TAMPONS_OCTETS", 3 * 238 * 231 * 4)
    for i in range(12):
        bc.carte_gardee(r, _fiche(f"Jeu {i}", str(5000 + i)), None, False, police, police.key(),
                        "", False, 1.0)
    assert len(bc._TAMPONS) <= 4
    bc.vider_tampons()


def test_faire_defiler_la_boutique_ne_redessine_aucune_carte(app, memo, monkeypatch):  # noqa: F811
    from orion.ui.widgets import boutique_cartes as bc
    v = _vue(memo, fps=60)
    v.resize(1400, 900)
    v.show()
    v.choisir_type("fps")
    v.grab()                                        # premier affichage : les cartes sont dessinees
    appels = []
    vrai = bc.dessiner_carte
    monkeypatch.setattr(bc, "dessiner_carte", lambda *a, **k: (appels.append(1), vrai(*a, **k))[1])
    barre = v.defile.verticalScrollBar()
    for _ in range(6):
        barre.setValue(min(barre.maximum(), barre.value() + 60))
        v.grab()
    for _ in range(6):
        barre.setValue(max(0, barre.value() - 60))
        v.grab()
    visibles = len(v.grille.fiches)
    assert len(appels) <= visibles, (len(appels), visibles)   # chaque carte au plus une fois
    avant = len(appels)
    for _ in range(4):
        v.grab()
    assert len(appels) == avant                     # image fixe : plus aucun dessin
    v.close()


def test_le_decor_est_compose_une_fois(app, monkeypatch):
    from orion.ui.backdrop import Backdrop
    b = Backdrop()
    b.resize(800, 450)
    compositions = []
    vrai = b._composer
    monkeypatch.setattr(b, "_composer", lambda *a, **k: (compositions.append(1), vrai(*a, **k))[1])
    for _ in range(5):
        b.grab()
    assert len(compositions) == 1
    b.resize(900, 450)
    b.grab()
    assert len(compositions) == 2                   # autre taille : recompose


def test_la_page_sorties_ne_redessine_que_le_compte_a_rebours(app, monkeypatch):
    import datetime as dt
    from orion import sorties as S
    from orion.ui.views.sorties_view import CarteSortie
    futur = (dt.date.today() + dt.timedelta(days=40)).isoformat()
    s = S.lire({"format": S.FORMAT, "maj": "2026-10-07", "sorties": [
        {"id": "essai", "titre": "Jeu attendu", "date": futur, "plateformes": ["pc"]}]})[0]
    c = CarteSortie(s, 300)
    fixes, vifs = [], []
    vrai_fixe, vrai_vif = c._peindre, c._peindre_vif
    monkeypatch.setattr(c, "_peindre", lambda p: (fixes.append(1), vrai_fixe(p))[1])
    monkeypatch.setattr(c, "_peindre_vif", lambda p, d: (vifs.append(1), vrai_vif(p, d))[1])
    for _ in range(5):                              # cinq secondes de compte a rebours
        c.grab()
    assert len(fixes) == 1 and len(vifs) == 5
    c._survol = True                                # le contour s'allume sans rien refaire
    c.grab()
    assert len(fixes) == 1


# ---------------------------------------------------------------------------
# Lectures gardees en memoire
# ---------------------------------------------------------------------------
def test_les_fiches_sont_figees_le_temps_d_un_calcul():
    from orion import boutique
    f = _fiche("Tir 01", "1001", prix=9.0, normal=18.0)
    assert f.meilleure.prix == 9.0
    with boutique.gele():
        assert f.meilleure.prix == 9.0 and f.remise == 50
        f.offres[0].prix = 4.5                      # change pendant le calcul : pas vu
        assert f.meilleure is f.meilleure and f.remise == 50
        vu_ailleurs = []
        fil = threading.Thread(target=lambda: vu_ailleurs.append(f.remise))
        fil.start()
        fil.join()
        assert vu_ailleurs == [75]                  # une tache de fond recalcule toujours
        with boutique.gele():                       # imbrique : meme calcul
            assert f.remise == 50
    assert f.remise == 75                           # le calcul fini, la reponse est juste


def test_cle_et_etiquettes_suivent_les_changements(memo):  # noqa: F811
    memo["1001"] = {"tags": ["FPS", "Action"]}
    f = _fiche("Tir 01", "1001", prix=9.0, normal=18.0)
    cle, etiquettes = f.cle, f.etiquettes
    assert f.cle is cle and f.etiquettes is etiquettes         # gardees
    memo["1001"] = {"tags": ["RPG"]}
    assert "RPG" in f.etiquettes and "FPS" not in f.etiquettes
    f.titre = "Autre jeu"
    f.offres[0].steam_appid = ""
    assert f.cle != cle


def test_la_ressemblance_bornee_rend_la_valeur_exacte_quand_elle_compte():
    from difflib import SequenceMatcher
    from orion.core import recherche as r
    for q, texte in (("cyberpounk", "cyberpunk"), ("wakfou", "wakfu"), ("reddead", "reddeadredemption"),
                     ("asasincrid", "assassinscreed"), ("battlefield", "battlefeild")):
        exacte = SequenceMatcher(None, q, texte).ratio()
        if exacte >= 0.78:
            assert r._ratio(q, texte, 0.78) == exacte
        else:
            assert exacte <= r._ratio(q, texte, 0.78) < 0.78
    # sans rapport : une borne basse, jamais au-dessus du seuil
    assert r._ratio("fifa", "phasmophobia", 0.78) < 0.78
    assert r._ratio("", "", 0.78) == 1.0


def test_une_frappe_relit_le_catalogue_sans_tout_recalculer():
    from orion.core import recherche as r
    titres = [f"Jeu numero {i} : l'aventure {i % 7}" for i in range(400)] + ["Cyberpunk 2077"]
    r.score.cache_clear()
    variantes = r.variantes("cyberp")
    assert r.classer_variantes(variantes, titres) == ["Cyberpunk 2077"]
    apres_un = r.score.cache_info()
    assert r.classer_variantes(variantes, titres) == ["Cyberpunk 2077"]
    apres_deux = r.score.cache_info()
    assert apres_deux.misses == apres_un.misses     # second passage : tout vient de la memoire
    assert apres_deux.hits >= apres_un.hits + len(titres)


def test_les_types_d_un_jeu_etiquette_par_etiquette():
    from orion import genres
    etiquettes = ("FPS", "Tir à la première personne", "Monde ouvert", "Stratégie", "JRPG", "STR")
    attendu = {cle for cle, mots in genres._MOTS.items()
               if any(genres._contient(genres._plat(e), m) for e in etiquettes for m in mots)}
    assert genres.types_de(etiquettes) == attendu and "fps" in attendu
    assert genres.types_de(["Strategie"]) == {"strategie"}      # « str » n'y est pas reconnu
    assert genres.types_de([]) == set()


# ---------------------------------------------------------------------------
# Rien n'est reconstruit quand rien n'a change
# ---------------------------------------------------------------------------
def test_la_colonne_des_types_n_est_pas_refaite_a_chaque_actualisation(app, memo):  # noqa: F811
    v = _vue(memo)
    boutons = dict(v.boutons_types)
    v.choisir_type("rpg")
    v.set_catalogue(list(v._catalogue), time.time(), 12, True)
    assert v.boutons_types == boutons and all(a is boutons[c] for c, a in v.boutons_types.items())
    assert v.boutons_types["rpg"].isChecked()


def test_le_tableau_de_puissance_n_est_pas_rempli_deux_fois_pour_rien(app):
    from types import SimpleNamespace as N
    from orion.ui.widgets.puissance_panel import PuissancePanel
    p = PuissancePanel()
    remises = []
    p.modele.modelReset.connect(lambda: remises.append(1))

    def resultats(niveau):
        return [(N(titre=f"Jeu {i}", installe=i == 0, possede=False, prix=9.99, boutique="Steam",
                   url="", appid="", uid=""),
                 N(niveau=niveau, source="estime", limite="", fps_affiche=None, notes=[]))
                for i in range(5)]
    p.set_resultats(resultats("haute"))
    apres_une = len(remises)
    assert apres_une >= 1 and p.modele.rowCount() == 1        # « Mes jeux » : un seul
    p.set_resultats(resultats("haute"))             # meme evaluation : rien a refaire
    assert len(remises) == apres_une
    p.set_resultats(resultats("moyenne"))
    assert len(remises) > apres_une


def test_le_tableau_de_puissance_ne_lit_que_les_lignes_a_l_ecran(app):
    """Deux mille jeux evalues : le modele ne prepare le texte que des lignes
    que la vue demande (avant, sept mille cellules etaient creees)."""
    from types import SimpleNamespace as N
    from orion.ui.widgets.puissance_panel import PuissancePanel
    p = PuissancePanel()
    p.resize(1200, 900)
    p.show()
    resultats = [(N(titre=f"Jeu {i:04d}", installe=False, possede=False, prix=float(i),
                    boutique="Steam", url="", appid=str(i), uid=""),
                  N(niveau="haute", source="estime", limite="", fps_affiche=((60, 80), "haute"),
                    notes=[], piste="", calibration=1.0)) for i in range(2000)]
    debut = time.perf_counter()
    p.set_resultats(resultats)
    app.processEvents()
    duree = time.perf_counter() - debut
    assert p.modele.rowCount() == 2000
    assert len(p.modele._textes) < 200, len(p.modele._textes)
    assert duree < 0.5, duree
    p.deleteLater()


def test_deux_mises_a_jour_d_une_meme_page_ne_s_ecrasent_pas(app):
    """« Ma machine » attend l'analyse du materiel ET le tableau de puissance :
    sous la meme cle, la seconde effacait la premiere (la page restait vide)."""
    from orion.ui import repos
    repos.tout_faire()
    faits = []
    repos.geste()
    repos.differer("hardware", lambda: faits.append("materiel"))
    repos.differer("hardware:puissance", lambda: faits.append("puissance"))
    repos.differer("advice", lambda: faits.append("conseils"))
    assert repos.en_attente("hardware") and repos.en_attente("hardware:puissance")
    assert repos.faire("hardware") is True          # ouverture de la page
    assert faits == ["materiel", "puissance"]
    assert repos.en_attente("advice")
    assert repos.faire("hardware") is False
    repos.tout_faire()
    assert faits == ["materiel", "puissance", "conseils"]


def test_l_analyse_du_materiel_attend_le_repos_sauf_sur_sa_page(app, monkeypatch):
    from orion.core.models import GPUInfo, HardwareInfo
    from orion.ui import repos
    from orion.ui.main_window import PAGES, MainWindow
    monkeypatch.setattr(MainWindow, "_boot", lambda self: None)
    w = MainWindow()
    try:
        monkeypatch.setattr(w, "actualiser_puissance", lambda: None)
        w.mises_a_jour_au_repos = True
        repos.tout_faire()
        repos.geste()
        hw = HardwareInfo(cpu_name="Intel Core i5-12400", cpu_cores=6, cpu_threads=12,
                          ram_gb=16, gpus=[GPUInfo(name="NVIDIA GeForce RTX 3060", tier=1)],
                          score=44)
        w.show_page("library")
        w._hardware_done(hw)
        assert w.hw is hw                               # connu tout de suite
        assert w.hardware_view.hw is None               # la page, elle, attend
        assert repos.en_attente("hardware") and repos.en_attente("advice")
        w.show_page("hardware")                         # l'ouvrir applique ce qui attend
        assert w.hardware_view.hw is hw and "44/100" in w.hardware_view.score.text()
        assert repos.en_attente("advice")
        # sur la page concernee, le resultat s'affiche sans attendre
        autre = HardwareInfo(cpu_name="Intel Core i5-12400", cpu_cores=6, cpu_threads=12,
                             ram_gb=32, gpus=[GPUInfo(name="NVIDIA GeForce RTX 3060", tier=1)],
                             score=46)
        w._hardware_done(autre)
        assert w.hardware_view.hw is autre and PAGES[w.stack.currentIndex()] == "hardware"
    finally:
        repos.tout_faire()
        w.close()
        w.deleteLater()


def test_arrivee_du_catalogue_en_trois_temps(qapp_fluidite=None):
    """L'accueil de la Boutique relit tout le catalogue trois fois (a la une
    et promotions, « Pour vous », rangees par type) : chaque partie est
    remise a part, pour ne pas faire un seul arret de l'affichage."""
    from PySide6.QtWidgets import QApplication
    QApplication.instance() or QApplication([])
    from orion.ui.views.boutique_view import BoutiqueView
    vue = BoutiqueView()
    remis = {}
    vue.differer = lambda cle, fonction: remis.__setitem__(cle, fonction)
    vue.set_catalogue([], 0.0, 12, True)
    assert list(remis) == ["boutique:pour_vous", "boutique:abondance"]
    for fonction in remis.values():
        fonction()                       # s'appliquent sans erreur, dans l'ordre
    # sans fenetre principale (essais, apercu) : tout est fait tout de suite
    vue2 = BoutiqueView()
    assert vue2.differer is None
    vue2.set_catalogue([], 0.0, 12, True)


def test_programme_partenaire_garde_par_adresse(monkeypatch):
    from orion import affiliation as A
    url = "https://fr.gamesplanet.com/game/x-1234"
    p = A.programme_de(url)
    assert p is not None and p.id == "gamesplanet" and A.programme_de(url) is p
    assert url in A._memo
    assert A.programme_de("https://store.steampowered.com/app/1") is None
    # une table passee a la main n'est jamais gardee, et une table remplacee
    # vide la memoire
    assert A.programme_de(url, ()) is None and A._memo[url] is p
    monkeypatch.setattr(A, "PROGRAMMES", ())
    assert A.programme_de(url) is None


def test_jaquette_des_gratuits_lue_petite_et_gardee(tmp_path):
    """692 ms d'arret releves chez l'auteur : chaque ligne relisait sa jaquette
    entiere. Elle est lue a petite taille, une seule fois."""
    from PySide6.QtCore import QSize
    from PySide6.QtGui import QColor, QImage
    from PySide6.QtWidgets import QApplication
    QApplication.instance() or QApplication([])
    from orion.ui.views import free_view as F
    chemin = tmp_path / "jaquette.jpg"
    image = QImage(600, 900, QImage.Format.Format_RGB32)
    image.fill(QColor("#335577"))
    assert image.save(str(chemin), "JPG", 90)
    F._MINIATURES.clear()
    pix = F.miniature(str(chemin), QSize(58, 87))
    assert not pix.isNull() and pix.width() <= 600 // 4 and pix.width() >= 58 * 2
    assert F.miniature(str(chemin), QSize(58, 87)) is pix          # gardee
    assert F.miniature(str(tmp_path / "absente.jpg"), QSize(58, 87)).isNull()


def test_lignes_des_gratuits_par_lots_en_service():
    from PySide6.QtWidgets import QApplication
    app = QApplication.instance() or QApplication([])
    from orion.plugins.freebies.base import Freebie
    from orion.ui.views.free_view import FreeRow, FreeView
    import inspect
    champs = inspect.signature(Freebie).parameters
    def offre(i):
        k = dict(title=f"Jeu {i}")
        for nom, valeur in (("key", f"k{i}"), ("shop", "steam"), ("url", "https://exemple.com")):
            if nom in champs:
                k[nom] = valeur
        return Freebie(**k)
    offres = [offre(i) for i in range(15)]
    vue = FreeView()
    vue.set_items(offres, {}, {}, {})
    assert len(vue.findChildren(FreeRow)) == 15                    # essais : tout d'un bloc
    vue2 = FreeView()
    vue2.etaler = True
    vue2.set_items(offres, {}, {}, {})
    assert len(vue2.findChildren(FreeRow)) == FreeView.PREMIERES   # le reste suit par lots
    import time
    fin = time.time() + 3
    while time.time() < fin and len(vue2.findChildren(FreeRow)) < 15:
        app.processEvents()
        time.sleep(0.01)
    lignes = [vue2.rows.itemAt(i).widget() for i in range(vue2.rows.count())
              if isinstance(vue2.rows.itemAt(i).widget(), FreeRow)]
    assert [r.item.title for r in lignes] == [o.title for o in offres]     # dans l'ordre
    # une nouvelle liste annule les lots de la precedente
    vue2.set_items(offres[:8], {}, {}, {})
    vue2.set_items(offres[:2], {}, {}, {})
    for _ in range(40):
        app.processEvents()
        time.sleep(0.01)
    assert len([i for i in range(vue2.rows.count())
                if isinstance(vue2.rows.itemAt(i).widget(), FreeRow)]) == 2
