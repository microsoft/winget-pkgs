"""DLC d'un jeu (2.0) : ceux qui existent, ceux deja acquis, les autres au
meilleur prix.

Regles verifiees ici : « deja acquis » ne vient que des fichiers du client
Steam ; un fichier a moitie compris ne sert jamais a conclure ; un DLC acquis
n'est jamais propose a l'achat ; l'offre Gamesplanet n'est prise que pour une
cle Steam du meme DLC ; Steam muet n'est jamais confondu avec « aucun DLC ».
"""
from __future__ import annotations

import struct
import time

import pytest

from orion import dlc as D
from orion.core.models import Game, HardwareInfo


@pytest.fixture(scope="module")
def app():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


# ---------------------------------------------------------------------------
# fabrique de fichiers Steam
# ---------------------------------------------------------------------------
def _kv(d: dict) -> bytes:
    """Dictionnaire -> « KeyValues » binaire de Valve (sans la fin)."""
    out = b""
    for cle, v in d.items():
        k = str(cle).encode() + b"\x00"
        if isinstance(v, dict):
            out += b"\x00" + k + _kv(v) + b"\x08"
        elif isinstance(v, str):
            out += b"\x01" + k + v.encode() + b"\x00"
        elif isinstance(v, float):
            out += b"\x03" + k + struct.pack("<f", v)
        elif v > 0x7FFFFFFF:
            out += b"\x07" + k + struct.pack("<q", v)
        else:
            out += b"\x02" + k + struct.pack("<i", v)
    return out


def _packageinfo(lots: dict[int, list[int]], version: int = 0x28) -> bytes:
    out = bytes([version]) + b"UV\x06" + struct.pack("<I", 1)
    for numero, apps in lots.items():
        out += struct.pack("<I", numero) + b"\x11" * 20 + struct.pack("<I", 12345)
        if version >= 0x28:
            out += struct.pack("<Q", 987654321)
        out += _kv({str(numero): {
            "packageid": numero, "billingtype": 1, "licensetype": 1, "status": 0,
            "extended": {"allowcrossregiontradingandgifting": "false", "poids": 1.5,
                         "jeton": 2 ** 40},
            "appids": {str(i): a for i, a in enumerate(apps)},
            "depotids": {"0": 11, "1": 12}, "appitems": {}}}) + b"\x08"
    return out + struct.pack("<I", 0xFFFFFFFF)


MANIFESTE = '''"AppState"
{
	"appid"		"1245620"
	"name"		"ELDEN RING"
	"StateFlags"		"4"
	"installdir"		"ELDEN RING"
	"InstalledDepots"
	{
		"1245621"
		{
			"manifest"		"111"
			"size"		"5000"
		}
		"2778581"
		{
			"manifest"		"222"
			"size"		"900"
			"dlcappid"		"2778580"
		}
	}
}
'''


def _steam(tmp_path, lots=None, manifeste=MANIFESTE):
    racine = tmp_path / "Steam"
    (racine / "steamapps").mkdir(parents=True)
    (racine / "appcache").mkdir()
    if manifeste:
        (racine / "steamapps" / "appmanifest_1245620.acf").write_text(manifeste, "utf-8")
    if lots is not None:
        (racine / "appcache" / "packageinfo.vdf").write_bytes(_packageinfo(lots))
    return racine


def _item(appid, nom, final=None, initial=None, remise=None, type_=4, **kw):
    it = {"item_type": 0, "id": appid, "appid": appid, "success": 1, "visible": True,
          "name": nom, "type": type_, "related_items": {"parent_appid": 1245620},
          "assets": {"asset_url_format": f"steam/apps/{appid}/${{FILENAME}}?t=1",
                     "header": "header.jpg"},
          "release": {"steam_release_date": 1718920829}}
    if final is not None:
        it["best_purchase_option"] = {"packageid": 1, "final_price_in_cents": str(final)}
        if initial is not None:
            it["best_purchase_option"]["original_price_in_cents"] = str(initial)
        if remise is not None:
            it["best_purchase_option"]["discount_pct"] = remise
    it.update(kw)
    return it


# ---------------------------------------------------------------------------
# 1) fiches Steam
# ---------------------------------------------------------------------------
def test_un_article_steam_devient_un_dlc():
    d = D.lire_item(_item(2778580, "ELDEN RING Shadow of the Erdtree", 3999))
    assert (d.appid, d.nom, d.prix, d.prix_normal, d.remise) == (
        "2778580", "ELDEN RING Shadow of the Erdtree", 39.99, 39.99, 0)
    assert d.vendu and not d.gratuit and d.nature == "dlc"
    assert d.image == ("https://shared.akamai.steamstatic.com/store_item_assets/"
                       "steam/apps/2778580/header.jpg?t=1")
    promo = D.lire_item(_item(5, "Promo", 1999, 3999, 50))
    assert (promo.prix, promo.prix_normal, promo.remise) == (19.99, 39.99, 50)
    # remise non donnee par Steam : calculee, jamais inventee au-dela
    assert D.lire_item(_item(5, "Promo", 2999, 3999)).remise == 25


def test_gratuit_pas_vendu_seul_cache_ou_pas_un_dlc():
    gratuit = D.lire_item(_item(6, "Pack gratuit", is_free=True))
    assert gratuit.gratuit and gratuit.vendu and gratuit.prix == 0
    seul = D.lire_item(_item(7, "Dans un lot seulement"))
    assert not seul.vendu and not seul.gratuit
    assert D.lire_item(_item(8, "Bande originale", 999, type_=11)).nature == "musique"
    assert D.lire_item(_item(9, "Cache", 999, visible=False)) is None
    assert D.lire_item(_item(10, "Un jeu", 999, type_=0)) is None       # pas un DLC
    assert D.lire_item({"appid": 11, "success": 42}) is None
    assert D.lire_item(None) is None
    # un DLC garde en memoire ne garde jamais « acquis » d'une fois sur l'autre
    assert "acquis" not in gratuit.to_dict() and "offres" not in gratuit.to_dict()
    assert D.Dlc.from_dict(dict(gratuit.to_dict(), acquis=True)).acquis is False


class _Reponse:
    def __init__(self, corps, code=200):
        self._corps, self.status_code, self.headers = corps, code, {}

    def json(self):
        if self._corps is None:
            raise ValueError("pas de JSON")
        return self._corps

    def raise_for_status(self):
        if self.status_code >= 400:
            raise RuntimeError(f"HTTP {self.status_code}")


def test_liste_des_dlc_gardee_et_steam_muet_n_est_pas_aucun_dlc(base_neuve, monkeypatch):
    from orion.core import reseau
    appels = []

    def get(url, **kw):
        appels.append(kw.get("params"))
        return _Reponse({"1245620": {"success": True, "data": {
            "type": "game", "dlc": [3655690, 2778590, 2778580, 2778580, 0]}}})
    monkeypatch.setattr(reseau, "get", get)
    assert D.liste("1245620") == ["3655690", "2778590", "2778580"]
    assert appels[0]["filters"] == "basic" and appels[0]["appids"] == "1245620"
    assert D.liste("1245620") == ["3655690", "2778590", "2778580"] and len(appels) == 1

    # jeu sans DLC : liste vide, gardee elle aussi
    monkeypatch.setattr(reseau, "get", lambda url, **kw: _Reponse(
        {"620": {"success": True, "data": {"type": "game"}}}))
    assert D.liste("620") == []

    # Steam ne repond pas : None (« je ne sais pas »), jamais « aucun DLC »
    def panne(url, **kw):
        raise OSError("hors ligne")
    monkeypatch.setattr(reseau, "get", panne)
    assert D.liste("999") is None
    assert D.liste("pas un numero") == []
    # la fiche complete lue ailleurs (page du jeu) evite un second appel
    D.memoriser("4242", [1, "2", "x"])
    assert D.liste("4242") == ["1", "2"]


def test_fiches_groupees_gardees_et_panne(base_neuve, monkeypatch):
    from orion.core import reseau
    appels = []

    def get(url, **kw):
        appels.append(kw["params"]["input_json"])
        return _Reponse({"response": {"store_items": [
            _item(2778580, "Shadow of the Erdtree", 3999),
            _item(3655690, "Tarnished Pack", 499),
            {"appid": 77, "success": 42}]}})
    monkeypatch.setattr(reseau, "get", get)
    f = D.fiches(["2778580", "3655690", "77", "88"])
    assert set(f) == {"2778580", "3655690"} and f["3655690"].prix == 4.99
    assert '"include_all_purchase_options": true' in appels[0]
    assert D.fiches(["2778580", "3655690", "77", "88"]).keys() == f.keys() and len(appels) == 1

    def panne(url, **kw):
        raise OSError("hors ligne")
    monkeypatch.setattr(reseau, "get", panne)
    assert D.fiches(["123456"]) is None                 # rien de lu : pas « aucun »
    assert set(D.fiches(["2778580", "123456"])) == {"2778580"}


# ---------------------------------------------------------------------------
# 2) fichiers du client Steam
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("version", [0x27, 0x28])
def test_packageinfo_lu_dans_ses_deux_versions(version):
    lots = D.lire_packageinfo(_packageinfo({0: [7], 451234: [1245620, 2778580], 9: []},
                                           version))
    assert lots == {0: {"7"}, 451234: {"1245620", "2778580"}, 9: set()}


@pytest.mark.parametrize("abime", [
    b"", b"\x29UV\x06\x01\x00\x00\x00", b"PK\x03\x04" + b"\x00" * 40,
    _packageinfo({5: [1, 2]})[:-4],                     # sans la marque de fin
    _packageinfo({5: [1, 2]})[:60],                     # coupe au milieu d'un lot
    _packageinfo({5: [1, 2]}).replace(b"\x02packageid", b"\x0cpackageid"),
])
def test_packageinfo_abime_ne_sert_jamais_a_conclure(abime):
    with pytest.raises(D.FichierInattendu):
        D.lire_packageinfo(abime)


def test_dlc_installes_lus_dans_le_manifeste(tmp_path):
    from orion.core.winutil import parse_vdf
    assert D.dlc_installes(parse_vdf(MANIFESTE)) == {"2778580"}
    assert D.dlc_installes({}) == set()
    assert D.dlc_installes({"AppState": {"InstalledDepots": {"1": "x", "2": {"dlcappid": "0"}}}}) == set()


def test_possession_lit_les_licences_et_les_dlc_installes(tmp_path):
    racine = _steam(tmp_path, {100: [1245620, 3655690], 200: [620]})
    p = D.possession(racine)
    assert p.verifie and p.client
    assert p.installes == {"2778580"}
    assert p.acquis == {"1245620", "3655690", "620", "2778580"}
    # relu seulement quand Steam a change ses fichiers
    assert D.possession(racine) is p
    time.sleep(0.01)
    (racine / "appcache" / "packageinfo.vdf").write_bytes(_packageinfo({100: [1245620]}))
    assert D.possession(racine).acquis == {"1245620", "2778580"}


def test_des_lots_sans_aucun_numero_ne_prouvent_rien(tmp_path):
    # format change (lots lus, mais plus aucun numero) : rien n'est affirme
    p = D.possession(_steam(tmp_path, {100: [], 200: []}))
    assert p.client and not p.verifie and p.acquis == {"2778580"}


def test_plusieurs_comptes_steam_sur_le_pc(tmp_path, app):
    racine = _steam(tmp_path, {100: [1245620]})
    assert D.possession(racine).comptes == 0          # fichier absent : inconnu
    (racine / "config").mkdir()
    (racine / "config" / "loginusers.vdf").write_text(
        '"users"\n{\n\t"76561190000000001"\n\t{\n\t\t"AccountName"\t\t"a"\n\t}\n'
        '\t"76561190000000002"\n\t{\n\t\t"AccountName"\t\t"b"\n\t}\n}\n', "utf-8")
    assert D.possession(racine).comptes == 2          # relu : le fichier a change
    from orion.ui.widgets import dlc_panel as P
    panneau = P.PanneauDlc()
    d = D.Dlc("2778580", "Shadow of the Erdtree", prix=39.99, prix_normal=39.99)
    panneau.montrer(D.Resultat("1245620", [d], verifie=True, client=True, comptes=2))
    assert panneau.message.text() == P.NOTE_COMPTES
    panneau.montrer(D.Resultat("1245620", [d], verifie=True, client=True, comptes=1))
    assert panneau.message.text() == P.NOTE


def test_le_dossier_de_steam_n_est_que_lu(tmp_path, base_neuve):
    """ORION ne cree, ne modifie et ne supprime rien dans le dossier de Steam,
    que ses fichiers soient lisibles ou non."""
    racine = _steam(tmp_path, {100: [1245620, 3655690]})
    (racine / "config").mkdir()
    (racine / "config" / "loginusers.vdf").write_text('"users"\n{\n}\n', "utf-8")

    def etat():
        return {str(f.relative_to(racine)): (f.stat().st_mtime_ns, f.read_bytes())
                for f in sorted(racine.rglob("*")) if f.is_file()}
    avant = etat()
    D.possession(racine)
    D.pour_jeu("1245620", racine)            # Steam muet dans les tests : rien a ecrire non plus
    assert etat() == avant
    (racine / "appcache" / "packageinfo.vdf").write_bytes(b"(UV\x06 abime")
    avant = etat()
    assert not D.possession(racine).verifie
    assert etat() == avant


def test_sans_licences_lisibles_rien_n_est_affirme(tmp_path):
    # packageinfo absent : les DLC installes restent surs, le reste est inconnu
    p = D.possession(_steam(tmp_path / "a"))
    assert not p.verifie and p.client and p.acquis == {"2778580"}
    # packageinfo illisible : meme prudence, sans plantage
    racine = _steam(tmp_path / "b", {1: [5]})
    (racine / "appcache" / "packageinfo.vdf").write_bytes(b"n'importe quoi")
    p = D.possession(racine)
    assert not p.verifie and p.acquis == {"2778580"}
    # pas de client Steam du tout
    import orion.plugins.scanners.steam as S
    orig = S.steam_root
    S.steam_root = lambda: None
    try:
        p = D.possession()
    finally:
        S.steam_root = orig
    assert not p.verifie and not p.client and not p.acquis


# ---------------------------------------------------------------------------
# 3) tout ensemble
# ---------------------------------------------------------------------------
GP = {
    "2778580": [["ELDEN RING Shadow of the Erdtree", 35.99, 39.99,
                 "elden-ring-shadow-of-the-erdtree-steam-key--4266-3", "steam", "", ""]],
    "2778590": [["ELDEN RING Shadow of the Erdtree Premium Bundle", 51.99, 49.99,
                 "faux-prix--1-1", "steam", "", ""]],
    "555": [["DLC Ubisoft", 5.0, 10.0, "dlc-ubisoft-uplay--5-1", "uplay", "", ""]],
}


@pytest.fixture
def monde(monkeypatch, tmp_path):
    from orion import prix_gamesplanet as G
    from orion.core import region
    monkeypatch.setattr(region, "devise", lambda: "EUR")
    monkeypatch.setattr(region, "pays", lambda: "FR")
    monkeypatch.setitem(G._memo, "releve", time.time())
    monkeypatch.setitem(G._memo, "jeux", GP)
    fiches = {
        "3655690": D.Dlc("3655690", "ELDEN RING Tarnished Pack", 4.99, 4.99),
        "2778590": D.Dlc("2778590", "ELDEN RING Shadow of the Erdtree Premium Bundle", 49.99, 49.99),
        "2778580": D.Dlc("2778580", "ELDEN RING Shadow of the Erdtree", 39.99, 39.99),
        "555": D.Dlc("555", "DLC Ubisoft", 10.0, 10.0),
        "666": D.Dlc("666", "Pack gratuit", gratuit=True),
        "777": D.Dlc("777", "Dans un lot", vendu=False),
    }
    monkeypatch.setattr(D, "liste", lambda appid: list(fiches))
    monkeypatch.setattr(D, "fiches", lambda ids: {a: D.Dlc.from_dict(fiches[a].to_dict())
                                                   for a in ids if a in fiches})
    return _steam(tmp_path, {100: [1245620, 3655690]})


def test_acquis_sans_offre_et_meilleur_prix_pour_les_autres(monde):
    res = D.pour_jeu("1245620", monde)
    assert res.verifie and not res.indisponible and res.autres == 0
    par = {d.appid: d for d in res.dlc}
    # acquis (licence) et installe (manifeste) : jamais proposes a l'achat
    assert par["3655690"].acquis and not par["3655690"].installe and par["3655690"].offres == []
    assert par["2778580"].acquis and par["2778580"].installe and par["2778580"].offres == []
    assert res.acquis == 2
    # a acheter, puis deja acquis, puis ce qui n'a pas de prix (gratuit, lot)
    assert [d.acquis for d in res.dlc] == [False, False, True, True, False, False]
    assert {d.appid for d in res.dlc[4:]} == {"666", "777"}
    # a acheter : Steam seul quand Gamesplanet annonce un prix incoherent
    assert [o.boutique for o in par["2778590"].offres] == ["Steam"]
    # un DLC Ubisoft Connect ne s'ajoute pas a un jeu Steam
    assert [o.boutique for o in par["555"].offres] == ["Steam"]
    assert par["666"].offres == [] and par["777"].offres == [] and par["777"].meilleure is None


def test_gamesplanet_gagne_quand_il_est_moins_cher(monde, tmp_path):
    vide = _steam(tmp_path / "autre", {1: [42]}, manifeste="")
    res = D.pour_jeu("1245620", vide)
    d = next(x for x in res.dlc if x.appid == "2778580")
    assert not d.acquis
    assert [(o.boutique, o.prix) for o in d.offres] == [("Gamesplanet", 35.99), ("Steam", 39.99)]
    assert d.meilleure.boutique == "Gamesplanet" and d.meilleure.type_article == "dlc"
    assert d.meilleure.url.startswith("https://fr.gamesplanet.com/game/")


def test_steam_muet_et_jeu_a_beaucoup_de_dlc(monde, monkeypatch):
    monkeypatch.setattr(D, "liste", lambda appid: None)
    res = D.pour_jeu("1245620", monde)
    assert res.indisponible and res.dlc == []
    monkeypatch.setattr(D, "liste", lambda appid: [])
    res = D.pour_jeu("1245620", monde)
    assert not res.indisponible and res.dlc == []
    monkeypatch.setattr(D, "liste", lambda appid: [str(i) for i in range(1000, 1250)])
    demandes = []
    monkeypatch.setattr(D, "fiches", lambda ids: demandes.append(list(ids)) or {})
    res = D.pour_jeu("1245620", monde)
    assert len(demandes[0]) == D.MAXIMUM and res.autres == 150
    monkeypatch.setattr(D, "fiches", lambda ids: None)
    assert D.pour_jeu("1245620", monde).indisponible
    assert D.pour_jeu("", monde).dlc == [] and D.pour_jeu("abc", monde).dlc == []


# ---------------------------------------------------------------------------
# 4) a l'ecran
# ---------------------------------------------------------------------------
def _resultat(verifie=True, client=True, autres=0, n=3):
    from orion.plugins.boutique.base import Offre
    achat = D.Dlc("2778580", "Shadow of the Erdtree", 39.99, 39.99)
    achat.offres = [
        Offre("Shadow of the Erdtree", "Gamesplanet", 35.99, 39.99, 10,
              url="https://fr.gamesplanet.com/game/x-steam-key--1-1", source="gamesplanet"),
        Offre("Shadow of the Erdtree", "Steam", 39.99, 39.99,
              url="https://store.steampowered.com/app/2778580", source="steam")]
    acquis = D.Dlc("3655690", "Tarnished Pack", 4.99, 4.99, acquis=True)
    installe = D.Dlc("11", "Deja la", 4.99, 4.99, acquis=True, installe=True)
    return D.Resultat("1245620", [achat, acquis, installe][:n], autres=autres,
                      verifie=verifie, client=client)


def test_panneau_acquis_ou_meilleur_prix(app):
    from orion.ui.widgets.dlc_panel import DlcLigne, PanneauDlc
    ouverts = []
    p = PanneauDlc()
    p._ouvrir = ouverts.append
    p.montrer(_resultat())
    lignes = p.findChildren(DlcLigne)
    assert [l.etat for l in lignes] == ["A acheter", "Deja acquis", "Installe"]
    # un DLC acquis n'a aucun bouton d'achat
    assert lignes[1].bouton is None and lignes[2].bouton is None
    assert lignes[0].bouton.text() == "Acheter"
    lignes[0].bouton.click()
    assert ouverts == ["https://fr.gamesplanet.com/game/x-steam-key--1-1"]   # le moins cher
    assert p.resume.text() == "3 DLC  ·  2 deja acquis"
    assert not p.alerte.isVisibleTo(p) and "client Steam" in p.message.text()


def test_panneau_dit_quand_il_n_a_pas_pu_verifier(app):
    from orion.ui.widgets import dlc_panel as P
    p = P.PanneauDlc()
    p.montrer(_resultat(verifie=False))
    assert p.alerte.isVisibleTo(p) and p.alerte.text() == P.NON_VERIFIE
    # sans client Steam sur ce PC : rien a verifier, pas d'alerte inutile
    p.montrer(_resultat(verifie=False, client=False))
    assert not p.alerte.isVisibleTo(p) and p.message.text() == P.NOTE_SANS_STEAM
    p.montrer(D.Resultat("1", indisponible=True))
    assert p.message.text() == P.INDISPONIBLE and not p.findChildren(P.DlcLigne)
    p.montrer(None)
    assert p.message.text() == P.INDISPONIBLE
    p.montrer(D.Resultat("1"))
    assert p.message.text() == P.AUCUN


def test_panneau_replie_les_longues_listes(app):
    from orion.ui.widgets import dlc_panel as P
    res = D.Resultat("1", [D.Dlc(str(i), f"DLC {i}", gratuit=True) for i in range(20)],
                     autres=150, verifie=True, client=True)
    p = P.PanneauDlc()
    p.appid = "1"
    p.montrer(res)
    assert len(p.findChildren(P.DlcLigne)) == P.VISIBLES
    assert p.plus.text() == "Afficher les 12 autres DLC" and p.plus.isVisibleTo(p)
    assert p.steam.text() == "Voir les 150 autres sur Steam"
    assert p.resume.text() == "170 DLC"
    p.plus.click()
    app.processEvents()
    visibles = [l for l in p.findChildren(P.DlcLigne) if l.parent() is p]
    assert len(visibles) == 20 and not p.plus.isVisibleTo(p)
    ouverts = []
    p._ouvrir = ouverts.append
    p.steam.click()
    assert ouverts == ["https://store.steampowered.com/dlc/1"]


def test_reponse_d_un_jeu_quitte_ignoree_et_meme_jeu_pas_redemande(app, monkeypatch):
    from orion.core import tasks
    from orion.ui.widgets import dlc_panel as P
    lancees = []

    class Tache:
        def __init__(self, fn, *a):
            self.fn, self.a = fn, a
            self.signals = type("S", (), {})()
            self.signals.finished = type("F", (), {"connect": lambda s, f: setattr(self, "fini", f)})()
            self.signals.failed = type("F", (), {"connect": lambda s, f: setattr(self, "rate", f)})()

        def start(self):
            lancees.append(self)
    monkeypatch.setattr(tasks, "Task", Tache)
    p = P.PanneauDlc(cacher_si_vide=True)
    assert p.isHidden()
    p.definir_jeu("10")
    p.definir_jeu("10")                              # deja en cours : rien de plus
    assert len(lancees) == 1 and p.message.text() == "Recherche des DLC..."
    p.definir_jeu("20")
    assert len(lancees) == 2
    lancees[0].fini(_resultat())                     # reponse du jeu 10, deja quitte
    assert p.resultat is None and not p.findChildren(P.DlcLigne) and p.isHidden()
    lancees[1].fini(_resultat())
    assert len(p.findChildren(P.DlcLigne)) == 3 and not p.isHidden()
    p.definir_jeu("20")                              # deja affiche
    assert len(lancees) == 2
    p.definir_jeu("30")
    lancees[2].rate("boum")
    assert p.message.text() == P.INDISPONIBLE and p.isHidden()
    p.vider()
    assert p.appid == "" and p.isHidden()


def test_bouton_dlc_dans_la_fiche_de_la_boutique(app, monkeypatch):
    from orion.boutique import Fiche
    from orion.plugins.boutique.base import Offre
    from orion.ui.views import boutique_view as B
    from orion.ui.widgets import dlc_panel as P
    demandes = []
    monkeypatch.setattr(P.PanneauDlc, "definir_jeu", lambda self, a: demandes.append(a))
    f = Fiche(titre="Elden Ring")
    f.ajouter(Offre("Elden Ring", "Steam", 41.99, 59.99, 30, source="steam",
                    steam_appid="1245620", url="https://store.steampowered.com/app/1245620"))
    ligne = B.FicheLigne(f, set(), avec_image=False)
    assert ligne.bouton_dlc is not None and ligne.dlc is None      # rien avant le clic
    changements = []
    ligne.contenu_change.connect(lambda: changements.append(1))
    ligne.bouton_dlc.setChecked(True)
    assert demandes == ["1245620"] and ligne.dlc is not None and not ligne.dlc.isHidden()
    assert changements
    ligne.bouton_dlc.setChecked(False)
    assert ligne.dlc.isHidden()
    ligne.bouton_dlc.setChecked(True)
    assert demandes == ["1245620"]                                 # pas redemande
    # sans numero Steam : pas de DLC a chercher
    g = Fiche(titre="Jeu GOG")
    g.ajouter(Offre("Jeu GOG", "GOG", 9.99, 19.99, source="gog"))
    assert B.FicheLigne(g, set(), avec_image=False).bouton_dlc is None


def test_page_du_jeu_dlc_pour_steam_seulement(app, monkeypatch):
    from orion.plugins.market.base import MarketInfo
    from orion.ui.views.detail_view import DetailView
    from orion.ui.widgets import dlc_panel as P
    demandes = []
    monkeypatch.setattr(P.PanneauDlc, "definir_jeu", lambda self, a: demandes.append(a))
    v = DetailView()
    assert v.dlc.isHidden()
    steam = Game(title="Elden Ring", source="steam", source_id="1245620", uid="s")
    v.set_game(steam, HardwareInfo())
    assert demandes == []                            # apres le releve seulement
    v.set_market(MarketInfo(game_uid="s", title="Elden Ring"))
    assert demandes == ["1245620"]
    # un jeu Epic qui a une fiche Steam : ses DLC Steam ne lui serviraient pas
    epic = Game(title="Elden Ring", source="epic", source_id="x", uid="e",
                extra={"steam_appid": "1245620"})
    v.set_game(epic, HardwareInfo())
    v.set_market(MarketInfo(game_uid="e", title="Elden Ring"))
    assert demandes == ["1245620"]


def test_changer_de_jeu_efface_les_dlc_du_precedent(app):
    from orion.ui.views.detail_view import DetailView
    from orion.ui.widgets import dlc_panel as P
    v = DetailView()
    v.dlc.appid = "1245620"
    v.dlc.montrer(_resultat())
    # page d'un jeu : un encart de cartes, pas la liste de la Boutique
    assert len(v.dlc.rangee.fiches) == 3 and not v.dlc.findChildren(P.DlcLigne)
    assert not v.dlc.isHidden() and not v.dlc.rangee.isHidden()
    v.set_game(Game(title="Autre", source="steam", source_id="620", uid="b"), HardwareInfo())
    app.processEvents()
    assert v.dlc.appid == "" and v.dlc.isHidden() and v.dlc.resume.text() == ""
    assert v.dlc.rangee.fiches == [] and v.dlc.rangee.isHidden()


def test_encart_de_cartes_etat_et_clic(app, monkeypatch):
    """Encart illustre de la page d'un jeu : chaque carte dit son etat, un
    clic mene a la meilleure offre, jamais nulle part pour un DLC acquis."""
    from orion.ui.widgets import dlc_panel as P
    from orion.ui.widgets.cartes_animees import RangeeDlc
    ouverts = []
    monkeypatch.setattr(P, "ouvreur", lambda origine: ouverts.append)
    panneau = P.PanneauDlc(cartes=True, origine="fiche")
    res = _resultat()
    gratuit = D.Dlc("666", "Pack gratuit", gratuit=True)
    lot = D.Dlc("777", "Dans un lot", vendu=False)
    res.dlc += [gratuit, lot]
    panneau.montrer(res)
    achat, acquis, installe = res.dlc[:3]
    assert [RangeeDlc.etat(d) for d in res.dlc] == [
        "A acheter", "Deja acquis", "Installe", "Gratuit", "Non vendu seul"]
    assert panneau.resume.text() == "5 DLC  ·  2 deja acquis"
    # le clic : la meilleure offre (Gamesplanet ici), la page Steam sans prix
    assert P.PanneauDlc.lien(achat).startswith("https://fr.gamesplanet.com/")
    assert P.PanneauDlc.lien(gratuit) == D.PAGE.format(appid="666")
    assert P.PanneauDlc.lien(acquis) == "" and P.PanneauDlc.lien(installe) == ""
    for d in (achat, acquis, lot):
        panneau.rangee.cliquee.emit(d)
    assert ouverts == [P.PanneauDlc.lien(achat), D.PAGE.format(appid="777")]
    # une carte acquise ne reagit pas au survol : rien a y faire
    assert panneau.rangee.survolable(achat) and not panneau.rangee.survolable(acquis)
    # le modele sert de « fiche » aux rangees de cartes
    assert (achat.cle, achat.titre) == ("2778580", "Shadow of the Erdtree")


def test_cartes_animees_entree_survol_et_peinture(app):
    """L'entree en cascade part de zero et finit en place ; sans animation
    (tests, captures) l'etat final est peint tout de suite ; rien ne tourne
    une fois les cartes au repos."""
    from orion.ui.widgets.cartes_animees import RangeeAnimee, RangeeDlc
    r = RangeeDlc()
    r.resize(900, r.height())
    r.set_fiches(_resultat().dlc)
    assert r._a_jouer and r.apparition(0) == 1.0          # pas encore vue
    r.jouer_entree()
    assert r.apparition(0) == 0.0 and r.apparition(2) == 0.0
    r._avancer(r.ENTREE + r.CASCADE)                      # la 2e carte arrive
    assert r.apparition(0) == 1.0 and r.apparition(1) == 1.0 and 0 < r.apparition(2) < 1
    r._temps.stop()
    r._entree_finie()
    assert [r.apparition(i) for i in range(3)] == [1.0, 1.0, 1.0]
    # memes DLC (prix actualises) : l'entree n'est pas rejouee
    r.set_fiches(_resultat().dlc)
    assert not r._a_jouer
    # survol : la carte a acheter se leve, la carte acquise non
    r._survol = 0
    r._reveiller()
    for _ in range(40):
        r._refroidir()
    assert r._chaleur == {0: 1.0} and not r._pouls.isActive()
    r._survol = 1
    r._reveiller()
    for _ in range(40):
        r._refroidir()
    assert r._chaleur == {} and not r._pouls.isActive()
    # peinture complete, avec et sans animation, sans erreur
    assert not r.grab().isNull()
    ancien = RangeeAnimee.ANIMER
    try:
        RangeeAnimee.ANIMER = False
        fixe = RangeeDlc()
        fixe.resize(900, fixe.height())
        fixe.set_fiches(_resultat().dlc)
        assert not fixe.grab().isNull() and fixe.apparition(2) == 1.0
        assert fixe._temps.state() != fixe._temps.State.Running
    finally:
        RangeeAnimee.ANIMER = ancien


def test_la_fiche_steam_du_jeu_retient_ses_dlc(base_neuve, monkeypatch):
    """La page d'un jeu lit deja la fiche Steam complete : la liste des DLC y
    est, elle n'est pas redemandee."""
    import inspect
    from orion.plugins.market import steam_store
    assert "dlc.memoriser(appid, data.get(\"dlc\"))" in inspect.getsource(
        steam_store.SteamStoreProvider._details)


def test_textes_des_dlc_traduits(app):
    from orion import i18n
    from orion.ui.widgets import dlc_panel as P
    try:
        assert i18n.charger("en")
        for texte, attendu in (
                (P.TITRE, "Add-on content (DLC)"), ("Deja acquis", "Already owned"),
                ("Installe", "Installed"), ("Non vendu seul", "Not sold separately"),
                (P.NON_VERIFIE, None), (P.NOTE, None), (P.NOTE_COMPTES, None), (P.AUCUN, None), (P.INDISPONIBLE, None),
                ("3 DLC  ·  2 deja acquis", "3 DLC  ·  2 already owned"),
                ("Afficher les 12 autres DLC", "Show the 12 other DLC"),
                ("Voir les 150 autres sur Steam", "See the 150 others on Steam"),
                ("Dans votre compte Steam", "In your Steam account"),
                ("chez Gamesplanet", "at Gamesplanet")):
            rendu = i18n.traduire(texte)
            assert rendu != texte, texte
            if attendu:
                assert rendu == attendu
        assert i18n.charger("fr")
        assert i18n.traduire("Deja acquis") == "Déjà acquis"
        assert i18n.traduire("3 DLC  ·  2 deja acquis") == "3 DLC  ·  2 déjà acquis"
    finally:
        i18n.charger("fr")
        i18n.traduire.cache_clear()


def test_rangee_dlc_qui_deborde_se_peint_sans_planter(app):
    """15 octobre (signalement n° 5) : une rangee de DLC plus large que la
    fenetre passait par le chemin des fiches de jeu (`fiche.visuels`) des
    qu'un bord etait fondu, et ORION plantait au passage en affichage salon.
    La rangee animee peint ses propres cartes, bord fondu ou non."""
    from orion.ui.widgets.cartes_animees import RangeeDlc
    r = RangeeDlc(largeur=222)
    r.ANIMER = False
    r.resize(700, r.height())
    r.set_fiches([D.Dlc(str(1000 + i), f"DLC {i}", 4.99, 9.99, remise=50) for i in range(12)])
    r._decalage = 300                                   # defilee : fondu a gauche et a droite
    assert all(r._fondus())
    from PySide6.QtGui import QPixmap
    r.render(QPixmap(r.size()))                         # passe par paintEvent -> _peindre_fondue
    assert r._tampon is not None and r._tampon.size().width() > 0
    # et la rangee de base (fiches de jeu) garde son tampon avec sa cle
    from orion.ui.widgets.boutique_cartes import RangeeCartes
    assert RangeeCartes._peindre_fondue is not RangeeDlc._peindre_fondue
