"""2.1.0 : pieces neuves compatibles quand le PC retient un jeu."""
from __future__ import annotations

from dataclasses import dataclass, field

import pytest

from orion import materiel
from orion.puissance.estimation import Machine
from orion.puissance.lecture import Besoin
from orion.puissance.references import CPU_PORTABLES


@dataclass
class Etat:
    boitier: str = "bureau"
    barrettes: list = field(default_factory=list)


@pytest.mark.parametrize("nom, attendu", [
    ("AMD Ryzen 5 5600X 6-Core Processor", "AM4"),
    ("AMD Ryzen 7 7800X3D 8-Core Processor", "AM5"),
    ("AMD Ryzen 7 7840HS w/ Radeon 780M Graphics", ""),         # portable
    ("AMD Ryzen Threadripper 3960X", ""),
    ("Intel(R) Core(TM) i5-12400F CPU @ 2.50GHz", "LGA1700"),
    ("13th Gen Intel(R) Core(TM) i7-13700K", "LGA1700"),
    ("Intel(R) Core(TM) i5-10400", "LGA1200"),
    ("Intel(R) Core(TM) i7-8700K CPU @ 3.70GHz", "LGA1151v2"),
    ("Intel(R) Core(TM) i7-1165G7 @ 2.80GHz", ""),              # portable
    ("Intel(R) Core(TM) Ultra 7 265K", "LGA1851"),
    ("Intel(R) Core(TM) Ultra 9 185H", ""),
    ("", ""),
])
def test_support_du_processeur(nom, attendu):
    assert materiel.support(nom) == attendu


def test_processeurs_du_meme_support_seulement():
    am4 = materiel.processeurs(60, "AM4")
    assert am4 and all(n.startswith("Ryzen") for n in am4)
    assert "Ryzen 5 5600X" in am4                      # juste suffisant, AM4
    assert not materiel.processeurs(90, "AM4")        # hors de portee sur AM4
    lga = materiel.processeurs(60, "LGA1700")
    assert lga and all(n.startswith("Core i") for n in lga)
    assert not materiel.processeurs(60, "")


def test_processeurs_portables_jamais_proposes():
    assert "7840" in CPU_PORTABLES and "14650" in CPU_PORTABLES
    for socket in ("AM4", "AM5", "LGA1700", "LGA1851"):
        for indice in (40, 60, 80):
            for nom in materiel.processeurs(indice, socket):
                assert nom.split()[-1].lower() not in CPU_PORTABLES


def test_memoire_en_place():
    assert materiel.memoire_en_place(
        [{"type": 26, "vitesse": 3200, "configuree": 3200}, {"type": 26, "vitesse": 3200}],
        False) == ("DDR4", 3200, 2)
    assert materiel.memoire_en_place([{"type": 34, "configuree": 5600}], True) \
        == ("SO-DIMM DDR5", 5600, 1)
    assert materiel.memoire_en_place([], False) == ("", 0, 0)
    # types melanges ou inconnus : pas de famille
    assert materiel.memoire_en_place([{"type": 26}, {"type": 34}], False)[0] == ""
    assert materiel.memoire_en_place([{"type": 0}], False)[0] == ""


def test_liens_de_recherche_sans_partenaire(monkeypatch):
    liens = materiel.recherche("GeForce RTX 4060")
    assert [li.boutique for li in liens] == ["LDLC", "Materiel.net"]
    assert liens[0].url == "https://www.ldlc.com/recherche/GeForce%20RTX%204060/"
    assert liens[1].url.startswith("https://www.materiel.net/recherche/")
    # aucun programme signe : jamais presente comme lien partenaire
    assert not any(li.partenaire for li in liens)


def test_pieces_bureau_complet():
    b = Besoin("haute", "Pour le niveau Haute", gpu=50, cpu=60, ram_go=16, vram_go=8)
    machine = Machine(gpu=30, cpu=45, cpu_nom="AMD Ryzen 5 3600 6-Core Processor", ram_go=8)
    etat = Etat("bureau", [{"type": 26, "vitesse": 3200}])
    pieces = materiel.pieces(b, machine, etat)
    assert [p.cle for p in pieces] == ["gpu", "cpu", "ram"]
    gpu, cpu, ram = pieces
    assert gpu.achetable and gpu.exemples and gpu.precision == "8 Go de memoire video"
    assert "alimentation" in gpu.reserve
    for e in gpu.exemples:
        assert any(k in gpu.liens[e][0].url for k in ("GeForce", "Radeon", "Intel"))
    assert cpu.achetable and cpu.precision == "support AM4"
    assert all(n.startswith("Ryzen") for n in cpu.exemples)
    assert ram.achetable and ram.exemples == ["DDR4 3200 16 Go"]
    assert "1 barrette(s)" in ram.reserve


def test_pieces_portable_sans_carte_ni_processeur():
    b = Besoin("haute", "Pour le niveau Haute", gpu=50, cpu=60, ram_go=16)
    machine = Machine(gpu=30, cpu=45, cpu_nom="AMD Ryzen 7 7840HS", ram_go=8)
    etat = Etat("portable", [{"type": 34, "configuree": 5600}])
    pieces = materiel.pieces(b, machine, etat)
    gpu, cpu, ram = pieces
    assert not gpu.achetable and "portable" in gpu.reserve
    assert not cpu.achetable and "portable" in cpu.reserve
    assert ram.achetable and ram.exemples == ["SO-DIMM DDR5 5600 16 Go"]


def test_pieces_sans_etat_systeme():
    """Etat du systeme pas encore lu : carte graphique avec reserve « PC de
    bureau », memoire sans lien (type inconnu)."""
    b = Besoin("haute", "Pour le niveau Haute", gpu=50, ram_go=16)
    pieces = materiel.pieces(b, Machine(gpu=30, cpu=45, ram_go=8), None)
    gpu, ram = pieces
    assert gpu.achetable and gpu.reserve.startswith("Sur un PC de bureau.")
    assert not ram.achetable and "non lu" in ram.reserve


def test_processeur_hors_support():
    """Un processeur trop fort pour le support en place n'est pas propose."""
    b = Besoin("haute", "Pour le niveau Haute", cpu=90)
    (cpu,) = materiel.pieces(b, Machine(gpu=60, cpu=45, cpu_nom="AMD Ryzen 5 3600"), Etat())
    assert not cpu.achetable and "autre carte mere" in cpu.reserve
    assert cpu.exemples                                    # les reperes restent cites


def test_pieces_du_jeu_prend_l_objectif_haute():
    besoins = [Besoin("basse", "Pour qu'il soit jouable", gpu=30),
               Besoin("haute", "Pour le niveau Haute", gpu=50)]
    pieces = materiel.pieces_du_jeu(besoins, Machine(gpu=20, cpu=45), Etat())
    assert pieces and pieces[0].cle == "gpu"
    assert not materiel.pieces_du_jeu([], Machine(gpu=20), Etat())


def test_besoins_et_phrases_coherents():
    """Les phrases « Ce qu'il manque » viennent des besoins structures."""
    b = Besoin("haute", "Pour le niveau Haute", cpu=60, gpu=50, ram_go=16, vram_go=8)
    phrase = b.phrase
    assert phrase.startswith("Pour le niveau Haute : un processeur du niveau d'un ")
    assert "une carte graphique du niveau d'une " in phrase
    assert phrase.endswith("(8 Go de memoire video), 16 Go de memoire vive.")
    seul = Besoin("haute", "Pour le niveau Haute", vram_go=8)
    assert seul.phrase == "Pour le niveau Haute : une carte graphique avec 8 Go de memoire video."


# --------------------------------------------------------------------------
# Dans le panneau Ma machine
# --------------------------------------------------------------------------
@pytest.fixture
def app():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


def test_le_panneau_montre_les_pieces_avec_leurs_liens(app, monkeypatch):
    from orion.hardware import systeme
    from orion.puissance.lecture import Explication
    from orion.ui.widgets.puissance_panel import PuissancePanel
    monkeypatch.setattr(systeme, "en_cache", lambda: Etat("bureau", [{"type": 26, "vitesse": 3200}]))
    x = Explication(titre="Jeu", besoins=[Besoin("haute", "Pour le niveau Haute", gpu=50, ram_go=16)])
    machine = Machine(gpu=30, cpu=45, cpu_nom="AMD Ryzen 5 3600", ram_go=8)
    html = PuissancePanel._pieces_html(x, machine)
    assert "Materiel neuf compatible avec votre PC" in html
    assert "href='https://www.ldlc.com/recherche/" in html
    assert "href='https://www.materiel.net/recherche/DDR4%203200%2016%20Go/'" in html
    assert "lien partenaire" not in html                  # aucun programme signe
    assert "ORION ne vend rien" in html
    # rien d'achetable (portable, memoire inconnue) : rien d'affiche
    monkeypatch.setattr(systeme, "en_cache", lambda: Etat("portable", []))
    assert PuissancePanel._pieces_html(x, machine) == ""
    assert PuissancePanel._pieces_html(Explication(titre="Jeu"), machine) == ""


def test_le_panneau_signale_un_vrai_lien_partenaire(app, monkeypatch):
    from orion import affiliation
    from orion.hardware import systeme
    from orion.puissance.lecture import Explication
    from orion.ui.widgets.puissance_panel import PuissancePanel
    monkeypatch.setattr(systeme, "en_cache", lambda: Etat("bureau"))
    monkeypatch.setattr(affiliation, "est_partenaire", lambda url: "ldlc.com" in url)
    x = Explication(titre="Jeu", besoins=[Besoin("haute", "Pour le niveau Haute", gpu=50)])
    html = PuissancePanel._pieces_html(x, Machine(gpu=30, cpu=45))
    assert html.count("lien partenaire") == html.count("ldlc.com")


def test_memoire_bridee_et_kit_optimise_amd_sur_intel():
    """10 octobre (« des RAM optimisees AMD sur un processeur Intel, donc pas
    de XMP ... il faudra le prendre en compte » pour le materiel en vente) :
    la recherche reprend la vitesse prevue, et le profil a choisir est dit."""
    assert materiel.memoire_en_place([{"type": 26, "vitesse": 3200, "configuree": 2666}] * 2, False) \
        == ("DDR4", 3200, 2)
    machine = Machine(gpu=30, cpu=45, cpu_nom="Intel(R) Core(TM) i9-9900K CPU @ 3.60GHz", ram_go=8)
    etat = Etat("bureau", [{"type": 26, "vitesse": 3200, "configuree": 2666}] * 2)
    ram = next(p for p in materiel.pieces(Besoin("haute", "Pour le niveau Haute", ram_go=32), machine, etat) if p.cle == "ram")
    assert ram.exemples == ["DDR4 3200 32 Go"] and "Intel XMP" in ram.reserve and "optimise AMD" in ram.reserve
    assert "EXPO" in materiel.profil_memoire("AMD Ryzen 7 7800X3D", "DDR5")
    assert materiel.profil_memoire("AMD Ryzen 5 3600", "DDR4") == ""
