"""Unreal ecrit ses reglages sous le nom de la classe reelle du jeu (2.0.2).

Constat du 9 octobre 2026 (Ready or Not) : ORION ecrivait la section
Engine et [ScalabilityGroups] ; le jeu, qui derive GameUserSettings, gardait
ShadowQuality=3, TextureQuality=3... dans SA section et restait en Epic."""
from orion.core.models import TweakOp
from orion.optimizer import unreal

RON = """[/Script/Engine.GameUserSettings]
bUseDesiredScreenHeight=False

[ScalabilityGroups]
sg.ReflectionQuality=3
sg.ShadingQuality=3

[/Script/ReadyOrNot.ReadyOrNotGameUserSettings]
GlobalIlluminationQuality=3
ViewDistanceQuality=3
EffectsQuality=3
ResolutionSizeX=2560
bUseDynamicResolution=False
GraphicsPresetIndex=0
PostProcessQuality=3
FrameRateLimit=144.000000
ResolutionSizeY=1440
AntiAliasingQuality=3
ShadowQuality=3
TextureQuality=3
FullscreenMode=0
ReflectionQuality=3
bUseVSync=False
"""


def _op(section, key, value, label="x"):
    return TweakOp(kind="ini", target="C:/x/GameUserSettings.ini", section=section, key=key, value=value, label=label)


def test_sections_du_jeu():
    s = unreal.sections_du_jeu(RON)
    assert list(s) == ["/Script/ReadyOrNot.ReadyOrNotGameUserSettings"]
    assert {"ShadowQuality", "TextureQuality", "FrameRateLimit", "GraphicsPresetIndex"} <= s["/Script/ReadyOrNot.ReadyOrNotGameUserSettings"]
    # un jeu sans classe derivee : rien a refleter
    assert unreal.sections_du_jeu("[/Script/Engine.GameUserSettings]\nResolutionSizeX=1920\n[ScalabilityGroups]\nsg.ShadowQuality=1\n") == {}
    assert unreal.sections_du_jeu("") == {}


def test_les_reglages_sont_recopies_dans_la_section_du_jeu():
    ops = [_op("/Script/Engine.GameUserSettings", "ResolutionSizeX", "1920", "Largeur"),
           _op("/Script/Engine.GameUserSettings", "FrameRateLimit", "60.000000", "Limite"),
           _op("/Script/Engine.GameUserSettings", "bUseVSync", "True", "VSync"),
           _op("ScalabilityGroups", "sg.ShadowQuality", "0", "Ombres"),
           _op("ScalabilityGroups", "sg.TextureQuality", "2", "Textures"),
           _op("ScalabilityGroups", "sg.FoliageQuality", "1", "Vegetation"),      # absent de la section du jeu
           _op("ScalabilityGroups", "sg.ResolutionQuality", "67.000000", "Echelle")]
    miroir = unreal.ops_miroir(ops, RON)
    vus = {(o.section, o.key): o.value for o in miroir}
    S = "/Script/ReadyOrNot.ReadyOrNotGameUserSettings"
    assert vus == {(S, "ResolutionSizeX"): "1920", (S, "FrameRateLimit"): "60.000000", (S, "bUseVSync"): "True",
                   (S, "ShadowQuality"): "0", (S, "TextureQuality"): "2"}
    assert all(o.target == ops[0].target and o.kind == "ini" and o.current is None for o in miroir)
    assert miroir[0].label == "Largeur (section du jeu)"
    # une cle deja prevue pour cette section n'est pas doublee
    deja = ops + [_op(S, "ShadowQuality", "0")]
    assert (S, "ShadowQuality") not in {(o.section, o.key) for o in unreal.ops_miroir(deja, RON)}


def test_plan_complet_sur_un_fichier_reel(tmp_path, monkeypatch):
    """Le plan d'un jeu Unreal a classe derivee ecrit la section du jeu, et
    l'ecriture reelle change bien les niveaux que le jeu relit."""
    from orion.plugins.tweaks.ini_writer import IniWriter, lire_valeur
    f = tmp_path / "GameUserSettings.ini"
    f.write_text(RON, encoding="utf-8")
    ops = [_op("ScalabilityGroups", "sg.ShadowQuality", "0", "Ombres"),
           _op("/Script/Engine.GameUserSettings", "FrameRateLimit", "60.000000", "Limite")]
    for o in ops:
        o.target = str(f)
    tous = ops + unreal.ops_miroir(ops, f.read_text(encoding="utf-8"))
    n, msg = IniWriter().write(tous)
    assert n == len(tous) == 4, msg
    texte = f.read_text(encoding="utf-8")
    S = "/Script/ReadyOrNot.ReadyOrNotGameUserSettings"
    assert lire_valeur(texte, S, "ShadowQuality") == "0"
    assert lire_valeur(texte, S, "FrameRateLimit") == "60.000000"
    assert lire_valeur(texte, "ScalabilityGroups", "sg.ShadowQuality") == "0"
    assert lire_valeur(texte, S, "TextureQuality") == "3"           # non prevu : intact
