"""Mesures partagees : rien sans accord, rien de personnel, lecture regroupee."""
from orion import partage
from orion.core.config import CONFIG
from orion.puissance import estimation


def _machine():
    m = estimation.Machine()
    m.gpu, m.gpu_nom, m.cpu, m.cpu_nom, m.pixels = 55.0, "NVIDIA GeForce RTX 3070", 66.0, "i5-12400", 2560 * 1440
    return m


STATS = {"fps_avg": 135.0, "fps_low_1": 90.0, "seconds": 900, "profile": "recommande",
         "preset": "haute", "upscaler_mode": "quality", "uid": "abc"}


def test_ligne_anonyme_et_ramenee_au_natif():
    l = partage.ligne("730", STATS, _machine(), 2560 * 1440)
    assert l["appid"] == "730" and l["preset"] == "haute" and l["fps"] == 100.0
    assert len(l["poste"]) == 32 and l["poste"] == partage.poste()
    assert set(l) == {"v", "app", "poste", "appid", "gpu", "gpu_nom", "cpu", "cpu_nom",
                      "pixels", "preset", "mode", "fps", "bas"}


def test_mesures_non_partageables():
    m = _machine()
    assert partage.ligne("", STATS, m, 1) is None                       # hors Steam
    assert partage.ligne("730", dict(STATS, seconds=30), m, 1) is None  # trop court
    assert partage.ligne("730", dict(STATS, fps_avg=0), m, 1) is None
    assert partage.ligne("730", STATS, estimation.Machine(), 1) is None  # carte inconnue


def test_rien_n_est_envoye_sans_accord(monkeypatch):
    appels = []
    from orion.core import reseau
    monkeypatch.setattr(reseau, "post", lambda *a, **k: appels.append(a))
    CONFIG.set("partage.actif", False)
    assert partage.envoyer({"appid": "730"}) is False and not appels


def test_question_posee_une_fois():
    CONFIG.set("partage.demande", False)
    assert partage.a_demander()
    partage.repondre(False)
    assert not partage.a_demander() and not partage.actif()
    partage.repondre(True)
    assert partage.actif()
    CONFIG.set("partage.actif", False)


def test_lecture_des_mesures_regroupees():
    m = _machine()
    une = [{"appid": "730", "gpu": 55, "pixels": 2560 * 1440, "preset": "haute",
            "fps": 100, "min": 90, "max": 115, "n": 4}]
    ev = estimation.depuis_communaute("CS2", "730", m, une)
    assert ev is not None and ev.fps["haute"] == (90, 115)
    assert "4 mesures" in ev.notes[0]
    seule = [dict(une[0], n=2)]
    assert estimation.depuis_communaute("CS2", "730", m, seule) is None   # moins de 3


def test_jeu_hors_steam_partageable():
    from orion.core.models import Game
    jeu = Game(title="Aniimo", source="dossier")
    assert partage.cle_jeu(jeu) == "t:aniimo"
    assert partage.cle_jeu(Game(title="CS2", source="steam", source_id="730")) == "730"
    l = partage.ligne(partage.cle_jeu(jeu), STATS, _machine(), 2560 * 1440)
    assert l and l["appid"] == "t:aniimo"


def test_recommande_se_sert_des_mesures_partagees(monkeypatch):
    import sys
    sys.path.insert(0, "tests")
    import test_reglages_recommande as T
    from orion import puissance
    from orion.core.models import Game
    from orion.optimizer.recommande import recommander
    hw, ecran = T._hw()
    m = estimation.machine_depuis(hw)
    monkeypatch.setattr(puissance, "_MESURES", [
        {"appid": "t:aniimo", "gpu": m.gpu, "pixels": 2560 * 1440, "preset": "haute",
         "fps": 150, "min": 140, "max": 160, "n": 5}])
    r = recommander(Game(title="Aniimo", source="dossier"), hw, ecran, [], runs={}, refresh=60)
    assert r.source == "communaute" and r.niveau == "haute"
