"""Vitrines etrangeres d'une meme enseigne (10 octobre, test de la page Sorties :
GamesPlanet US, vendu en dollars, passait en tete pour un joueur francais)."""
import json
import pathlib
import re

from orion import itad

RACINE = pathlib.Path(__file__).resolve().parents[1]


def _deal(ident, nom, prix):
    return {"shop": {"id": ident, "name": nom}, "price": {"amount": prix, "currency": "EUR"}}


# offres relevees le 10 octobre pour Warhammer 40,000: Dawn of War IV (pays FR)
DAWN = [_deal(29, "GamesPlanet US", 44.62), _deal(2, "AllYouPlay", 47.89),
        _deal(28, "GamesPlanet FR", 49.99), _deal(27, "GamesPlanet DE", 49.99),
        _deal(26, "GamesPlanet UK", 51.99), _deal(61, "Steam", 53.99)]


def test_joueur_francais_garde_les_vitrines_en_euros_une_par_enseigne():
    noms = [d["shop"]["name"] for d in itad.du_pays(DAWN, "FR")]
    assert noms == ["AllYouPlay", "GamesPlanet FR", "Steam"]


def test_joueur_allemand_garde_sa_vitrine():
    noms = [d["shop"]["name"] for d in itad.du_pays(DAWN, "DE")]
    assert noms == ["AllYouPlay", "GamesPlanet DE", "Steam"]


def test_joueur_belge_garde_une_seule_vitrine_en_euros():
    noms = [d["shop"]["name"] for d in itad.du_pays(DAWN, "BE")]
    assert noms.count("GamesPlanet FR") + noms.count("GamesPlanet DE") == 1
    assert "GamesPlanet US" not in noms and "GamesPlanet UK" not in noms


def test_joueur_americain_garde_les_vitrines_en_dollars():
    offres = DAWN + [_deal(64, "WinGameStore", 40.0)]
    noms = [d["shop"]["name"] for d in itad.du_pays(offres, "US")]
    assert "GamesPlanet US" in noms and "WinGameStore" in noms
    assert "GamesPlanet FR" not in noms


def test_wingamestore_ecarte_en_france_et_rien_ne_casse_sur_vide():
    assert itad.du_pays([_deal(64, "WinGameStore", 21.86)], "FR") == []
    assert itad.du_pays(None, "FR") == []
    assert itad.du_pays([{}], "FR") == [{}]


def test_lecteur_de_prix_de_l_application_applique_la_regle(monkeypatch):
    from orion.plugins.market import itad as marche
    from orion.plugins.market.base import MarketInfo
    monkeypatch.setattr(marche.acces, "demander", lambda *a, **k: [{"deals": DAWN}])
    info = MarketInfo()
    marche.ITADProvider._prices(marche.ITADProvider.__new__(marche.ITADProvider), "", "FR", "x", info)
    assert info.best.shop == "AllYouPlay"
    assert [o.shop for o in info.offers] == ["AllYouPlay", "GamesPlanet FR", "Steam"]


def test_le_comparateur_du_site_a_la_meme_table():
    js = (RACINE / "service" / "site" / "comparatif.js").read_text(encoding="utf-8")
    bloc = re.search(r"var VITRINES = (\{.*?\});", js, re.S).group(1)
    table = json.loads(re.sub(r"(\d+):", r'"\1":', bloc))
    assert {int(k): tuple(v) for k, v in table.items()} == itad.VITRINES


def test_recherche_instant_gaming_compte_les_precommandes():
    from orion import marche_gris
    js = (RACINE / "service" / "site" / "comparatif.js").read_text(encoding="utf-8")
    assert "product_types%5B%5D=preorder" in js
    modele = next(s for s in marche_gris.SITES if s.id == "instant-gaming").modele
    assert "product_types%5B%5D=preorder" in modele
