"""Fenetre de connexion integree : identite du navigateur, cles de securite
masquees chez Microsoft, refus de Google, erreurs en francais, fenetres
surgissantes et ordre de destruction (page avant profil)."""
import os
import re
import sys

# moteur web en tant que root (bac a sable des tests) : sans cela Chromium
# refuse de demarrer ; a regler avant le premier profil
if sys.platform.startswith("linux") and hasattr(os, "geteuid") and os.geteuid() == 0:
    os.environ.setdefault("QTWEBENGINE_DISABLE_SANDBOX", "1")

import pytest  # noqa: E402

from orion.comptes import PLATEFORMES, Plateforme  # noqa: E402
from orion.ui.widgets import connexion as cx  # noqa: E402

ACCENTS = re.compile(r"[àâäéèêëîïôöùûüçÀÂÉÈÊËÎÏÔÖÙÛÜÇ]")


# ----------------------------------------------------------------------
# aides pures
# ----------------------------------------------------------------------
def test_ua_standard_retire_qtwebengine():
    win = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like "
           "Gecko) QtWebEngine/6.8.1 Chrome/122.0.6261.171 Safari/537.36")
    assert cx.ua_standard(win) == ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                                   "AppleWebKit/537.36 (KHTML, like Gecko) "
                                   "Chrome/122.0.6261.171 Safari/537.36")
    chrome = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like "
              "Gecko) Chrome/140.0.0.0 Safari/537.36")
    assert cx.ua_standard(chrome) == chrome
    assert cx.ua_standard("") == ""


def test_script_sans_cle_vise_seulement_les_domaines_donnes():
    s = cx.script_sans_cle(("login.live.com", ".Account.Live.com", ""))
    assert '["account.live.com", "login.live.com"]' in s
    assert "location.hostname" in s and "if (!vise) { return; }" in s
    assert "delete window.PublicKeyCredential" in s
    assert "navigator.credentials" in s and "NotAllowedError" in s
    # ne lit rien de la page ni des mots de passe, n'envoie rien
    for interdit in ("password", "fetch(", "XMLHttpRequest", "sendBeacon", "value)", "input"):
        assert interdit not in s
    assert "__DOMAINES__" not in s


def test_refus_google_reconnu():
    assert cx.refus_google("https://accounts.google.com/signin/rejected?rrk=46&hl=fr")
    assert cx.refus_google("https://accounts.google.com/v3/signin/rejected?x=1")
    assert cx.refus_google("https://accounts.google.com/signin/oauth/error?authError="
                           "ChRkaXNhbGxvd2VkX3VzZXJhZ2VudBI&client_id=1")
    assert cx.refus_google("https://accounts.google.com/o/oauth2/x?e=disallowed_useragent")
    assert not cx.refus_google("https://accounts.google.com/v3/signin/identifier?hl=fr")
    assert not cx.refus_google("https://accounts.google.com/signin/oauth/error?authError=YWJj")
    assert not cx.refus_google("https://evil.example/signin/rejected")
    assert not cx.refus_google("")


def test_messages_d_erreur_en_francais():
    assert "Pas de connexion Internet" in cx.message_erreur(-106, "auth.gog.com")
    assert "auth.gog.com est introuvable" in cx.message_erreur(105, "auth.gog.com")
    assert "ne repond pas" in cx.message_erreur(-118, "login.live.com")
    assert "certificat" in cx.message_erreur(-202, "login.live.com")
    assert "(erreur -999)" in cx.message_erreur(-999, "x.com")
    assert "la plateforme" in cx.message_erreur(-999, "")
    assert "date et l'heure" in cx.message_certificat("x.com")


def test_plateformes_microsoft_et_gog():
    x, g = PLATEFORMES["xbox"], PLATEFORMES["gog"]
    assert "login.live.com" in x.domaines_sans_cle
    assert "login.microsoftonline.com" in x.domaines_sans_cle
    assert x.conseil_connexion.startswith(
        "Si Microsoft propose une cle de securite : « Autres facons de se connecter » "
        "puis « Mot de passe »")
    assert g.aide_refus_google.startswith(
        "Google refuse les fenetres integrees : connectez-vous a GOG avec e-mail et "
        "mot de passe, ou liez Google dans votre compte GOG")
    assert "Mot de passe oublie" in g.aide_refus_google
    assert not g.domaines_sans_cle and not PLATEFORMES["steam"].domaines_sans_cle
    for texte in (x.conseil_connexion, g.aide_refus_google, cx.CLE_INDISPONIBLE,
                  cx.REFUS_GOOGLE, cx.REFUS_GOOGLE_ANNEXE, cx.TELECHARGEMENT_IGNORE,
                  cx.message_certificat("x"), cx.message_erreur(-106, "x")):
        assert not ACCENTS.search(texte), texte


# ----------------------------------------------------------------------
# navigateur integre (si utilisable ici)
# ----------------------------------------------------------------------
web = pytest.mark.skipif(not cx.web_disponible(), reason="QtWebEngine absent")


class _Essai(Plateforme):
    id = "essai"
    nom = "Essai"
    nature = "officiel"
    domaines_sans_cle = ("login.live.com",)
    conseil_connexion = "Conseil d'essai"

    def adresse_connexion(self) -> str:
        return "about:blank"

    def est_retour(self, adresse: str) -> bool:
        return adresse.startswith("https://orion.localhost/retour")


@pytest.fixture
def app():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


@pytest.fixture
def messages_qt():
    from PySide6.QtCore import qInstallMessageHandler
    recus: list[str] = []

    def garder(_type, _ctx, texte):
        recus.append(str(texte))
    ancien = qInstallMessageHandler(garder)
    yield recus
    qInstallMessageHandler(ancien)


def _attendre(app, condition, delai_ms=8000) -> bool:
    from PySide6.QtCore import QElapsedTimer
    chrono = QElapsedTimer()
    chrono.start()
    while not condition() and chrono.elapsed() < delai_ms:
        app.processEvents()
    return condition()


def _detruire(app, objet) -> None:
    from PySide6.QtCore import QCoreApplication, QEvent
    objet.deleteLater()
    for _ in range(5):
        QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
        app.processEvents()


def _js(app, page, code):
    res = {}
    page.runJavaScript(code, 0, lambda v: res.setdefault("v", v))
    if not _attendre(app, lambda: "v" in res):
        pytest.skip("moteur web inutilisable ici (JavaScript sans reponse)")
    return res["v"]


@web
def test_fenetre_profil_surgissante_et_destruction(app, messages_qt):
    from PySide6.QtWebEngineCore import QWebEnginePage
    d = cx.FenetreConnexion(_Essai())
    d.show()
    assert "QtWebEngine" not in d.profil.httpUserAgent()
    assert "Chrome/" in d.profil.httpUserAgent()
    assert d.profil.isOffTheRecord()
    assert d.profil.scripts().find("orion-sans-cle-de-securite")
    assert d.conseil.text() == "Conseil d'essai"

    # « Se connecter avec Google » / nouvel onglet : vraie fenetre, meme profil
    p = d.page.createWindow(QWebEnginePage.WebWindowType.WebBrowserWindow)
    assert isinstance(p, cx._Page) and p is not d.page
    assert p.profile() is d.profil
    onglet = d.page.createWindow(QWebEnginePage.WebWindowType.WebBrowserTab)
    assert isinstance(onglet, cx._Page)
    assert len(d.fenetres_ouvertes()) == 2
    f = d.fenetres_ouvertes()[0]
    assert f.isVisible() and f.surface.vue.page() is p

    # Google refuse : explication dans les deux fenetres
    d._adresse_annexe(f, cx.QUrl("https://accounts.google.com/signin/rejected?rrk=46"))
    assert "ORION ne contourne pas" in d.conseil.text()
    assert not f.conseil.isHidden()

    # la page surgissante ferme sa fenetre (window.close())
    onglet.windowCloseRequested.emit()
    assert _attendre(app, lambda: len(d.fenetres_ouvertes()) == 1, 3000)

    # retour intercepte dans la surgissante : connexion terminee
    p.retour.emit("https://orion.localhost/retour?code=abc")
    assert d.resultat == "https://orion.localhost/retour?code=abc"
    assert _attendre(app, lambda: not d.isVisible(), 3000)
    assert not d.fenetres_ouvertes() or not any(x.isVisible() for x in d.fenetres_ouvertes())

    _detruire(app, d)
    assert not [m for m in messages_qt if "Release of profile" in m], messages_qt


@web
def test_fenetre_detruite_avec_surgissante_ouverte(app, messages_qt):
    """Destruction directe (sans fermeture prealable) : la surgissante part
    avant la page principale, le profil en dernier."""
    from PySide6.QtWebEngineCore import QWebEnginePage
    d = cx.FenetreConnexion(_Essai())
    d.show()
    d.page.createWindow(QWebEnginePage.WebWindowType.WebDialog)
    assert len(d.fenetres_ouvertes()) == 1
    _detruire(app, d)
    assert not [m for m in messages_qt if "Release of profile" in m], messages_qt


@web
def test_window_open_garde_le_lien_avec_la_page(app, messages_qt):
    d = cx.FenetreConnexion(_Essai())
    d.show()
    charge = {}
    d.page.loadFinished.connect(lambda ok: charge.setdefault("ok", ok))
    d.page.setHtml("<html><body>gog</body></html>", cx.QUrl("https://example.org/"))
    if not _attendre(app, lambda: "ok" in charge):
        pytest.skip("moteur web inutilisable ici (page non chargee)")
    assert _js(app, d.page, "window.__w = window.open('about:blank', 'google', "
                            "'width=480,height=600'); !!window.__w") is True
    assert _attendre(app, lambda: len(d.fenetres_ouvertes()) == 1, 3000)
    f = d.fenetres_ouvertes()[0]
    assert _attendre(app, lambda: f.width() == 500, 3000)   # taille demandee
    assert _js(app, f.page, "window.opener !== null") is True
    assert "QtWebEngine" not in _js(app, f.page, "navigator.userAgent")
    _js(app, d.page, "window.__w.close(); 1")
    assert _attendre(app, lambda: not d.fenetres_ouvertes(), 3000)
    d.reject()
    _detruire(app, d)
    assert not [m for m in messages_qt if "Release of profile" in m], messages_qt


class _Info:
    def __init__(self, statut, domaine, code, adresse, page_erreur=False):
        self._v = (statut, domaine, code, adresse, page_erreur)

    def status(self):
        return self._v[0]

    def errorDomain(self):              # noqa: N802
        return self._v[1]

    def errorCode(self):                # noqa: N802
        return self._v[2]

    def url(self):
        return cx.QUrl(self._v[3])

    def isErrorPage(self):              # noqa: N802
        return self._v[4]


@web
def test_erreurs_de_chargement_en_francais(app):
    from PySide6.QtWebEngineCore import QWebEngineLoadingInfo as L
    S, D = L.LoadStatus, L.ErrorDomain
    d = cx.FenetreConnexion(_Essai())
    s = d.surface
    s._chargement(_Info(S.LoadFailedStatus, D.ConnectionErrorDomain, -3, "https://a.com"))
    assert not s.en_erreur()                         # navigation interrompue
    s._chargement(_Info(S.LoadFailedStatus, D.HttpStatusCodeDomain, 404, "https://a.com"))
    assert not s.en_erreur()                         # le site affiche sa page
    s._chargement(_Info(S.LoadFailedStatus, D.ConnectionErrorDomain, -106,
                        "https://orion.localhost/retour?code=1"))
    assert not s.en_erreur()                         # retour intercepte
    s._chargement(_Info(S.LoadFailedStatus, D.ConnectionErrorDomain, -106,
                        "https://auth.gog.com/auth"))
    assert s.en_erreur() and "Pas de connexion Internet" in s.message.text()
    assert s.reessayer.text() == "Reessayer"
    s._chargement(_Info(S.LoadSucceededStatus, D.NoErrorDomain, 0, "https://auth.gog.com"))
    assert not s.en_erreur()
    s._chargement(_Info(S.LoadFailedStatus, D.CertificateErrorDomain, -202,
                        "https://login.live.com/"))
    assert s.en_erreur() and "certificat" in s.message.text()
    s._reessayer()
    assert not s.en_erreur()
    d.reject()
    _detruire(app, d)


@web
def test_cles_de_securite_masquees_chez_microsoft_seulement(app):
    d = cx.FenetreConnexion(_Essai())
    d.show()
    charge = {}
    d.page.loadFinished.connect(lambda ok: charge.setdefault("ok", ok))
    d.page.setHtml("<html><body>ms</body></html>", cx.QUrl("https://login.live.com/"))
    if not _attendre(app, lambda: "ok" in charge):
        pytest.skip("moteur web inutilisable ici (page non chargee)")
    assert _js(app, d.page, "location.hostname") == "login.live.com"
    assert _js(app, d.page, "typeof window.PublicKeyCredential") == "undefined"
    natif = ("String(navigator.credentials && navigator.credentials.get)"
             ".indexOf('native code') >= 0")
    if _js(app, d.page, "!!navigator.credentials"):
        assert _js(app, d.page, natif) is False

    charge.clear()
    d.page.setHtml("<html><body>autre</body></html>", cx.QUrl("https://example.org/"))
    assert _attendre(app, lambda: "ok" in charge)
    if _js(app, d.page, "!!navigator.credentials"):
        assert _js(app, d.page, natif) is True      # autres sites : intacts
    d.reject()
    _detruire(app, d)
