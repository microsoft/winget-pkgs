"""Decor 2.0 : le fond du jour et la banniere de saison.

Regles verifiees ici : la saison change le jour meme de l'equinoxe ou du
solstice ; une banniere existe pour chaque saison de chaque annee livree, et
les annees suivantes en retrouvent une ; le fond du jour est le meme toute la
journee et change le lendemain ; les images livrees restent sombres ; l'image
choisie par le joueur garde la priorite ; tout se coupe dans les reglages."""
from __future__ import annotations

import datetime as dt
from zoneinfo import ZoneInfo

import pytest

from orion import saisons as S

PARIS = ZoneInfo("Europe/Paris")


@pytest.fixture(scope="module")
def app():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


def test_dates_des_saisons_a_paris():
    """Dates connues des equinoxes et solstices (heure de Paris)."""
    connues = {
        2026: ("03-20", "06-21", "09-23", "12-21"), 2027: ("03-20", "06-21", "09-23", "12-22"),
        2028: ("03-20", "06-20", "09-22", "12-21"), 2029: ("03-20", "06-21", "09-22", "12-21"),
        2030: ("03-20", "06-21", "09-23", "12-21"),
    }
    for annee, attendu in connues.items():
        d = S.debuts(annee, PARIS)
        assert tuple(d[s].strftime("%m-%d") for s in S.SAISONS) == attendu, annee
    # l'equinoxe de septembre 2026 : le 23 a 2 h a Paris, encore le 22 a New York
    assert S.debuts(2026, ZoneInfo("America/New_York"))["automne"] == dt.date(2026, 9, 22)


def test_la_saison_change_le_jour_meme():
    def s(a, m, j, sud=False):
        return S.saison(dt.date(a, m, j), sud, PARIS)
    assert s(2026, 9, 22) == ("ete", 2026) and s(2026, 9, 23) == ("automne", 2026)
    assert s(2026, 12, 20) == ("automne", 2026) and s(2026, 12, 21) == ("hiver", 2026)
    # l'hiver porte l'annee ou il commence, jusqu'a la veille du printemps
    assert s(2027, 1, 1) == ("hiver", 2026) and s(2027, 3, 19) == ("hiver", 2026)
    assert s(2027, 3, 20) == ("printemps", 2027) and s(2027, 6, 21) == ("ete", 2027)
    # hemisphere sud : saisons inversees, memes jours
    assert s(2026, 12, 21, sud=True) == ("ete", 2026) and s(2026, 10, 5, sud=True) == ("printemps", 2026)


def test_une_banniere_par_saison_et_par_an():
    for annee in range(S.PREMIERE_ANNEE, S.PREMIERE_ANNEE + S.ANNEES):
        for nom in S.SAISONS:
            assert (S.BANNIERES / f"{nom}-{annee}.jpg").is_file(), (nom, annee)
    assert S.banniere(dt.date(2026, 10, 5)).name == "automne-2026.jpg"
    assert S.banniere(dt.date(2027, 2, 1)).name == "hiver-2026.jpg"
    assert S.banniere(dt.date(2028, 7, 14)).name == "ete-2028.jpg"
    # apres les annees livrees, les bannieres reviennent dans le meme ordre
    assert S.banniere(dt.date(2031, 10, 5)).name == "automne-2026.jpg"
    assert S.banniere(dt.date(2033, 5, 1)).name == "printemps-2028.jpg"
    assert len({S.banniere(dt.date(a, 7, 14)).name for a in range(2026, 2031)}) == 5


def test_banniere_absente_ou_dossier_vide(tmp_path):
    assert S.banniere(dt.date(2026, 10, 5), tmp_path) is None
    assert S.banniere(dt.date(2026, 10, 5), tmp_path / "absent") is None
    (tmp_path / "automne-2029.jpg").write_bytes(b"x")          # une seule image d'automne
    assert S.banniere(dt.date(2026, 10, 5), tmp_path).name == "automne-2029.jpg"
    assert S.fond_du_jour(dt.date(2026, 10, 5), tmp_path / "absent") is None


def test_fond_du_jour_meme_compte_que_le_site():
    images = sorted(S.FONDS.glob("*.jpg"))
    assert len(images) >= 50
    jour = dt.date(2026, 10, 5)
    # le site calcule Date.UTC(annee, mois, jour) / 86 400 000 : meme nombre
    assert S.numero_du_jour(jour) == int(dt.datetime(2026, 10, 5, tzinfo=dt.timezone.utc).timestamp()) // 86400
    assert S.fond_du_jour(jour) == images[S.numero_du_jour(jour) % len(images)]
    assert S.fond_du_jour(jour) == S.fond_du_jour(jour)
    assert S.fond_du_jour(jour) != S.fond_du_jour(jour + dt.timedelta(days=1))
    # un tour complet avant de revoir la meme image
    tour = [S.fond_du_jour(jour + dt.timedelta(days=i)) for i in range(len(images))]
    assert len(set(tour)) == len(images)


def test_images_livrees_sombres_et_legeres(app):
    """Lisibilite : aucun fond livre n'est plus clair que les bornes fixees a
    sa generation, et une banniere reste eteinte a gauche, sous le titre."""
    from PySide6.QtGui import QImage
    def moyenne(image, x0, x1):
        petit = image.copy(x0, 0, x1 - x0, image.height()).scaled(16, 9).convertToFormat(
            QImage.Format.Format_Grayscale8)
        return sum(petit.pixelColor(x, y).red() for x in range(16) for y in range(9)) / 144
    for chemin in sorted(S.FONDS.glob("*.jpg")):
        image = QImage(str(chemin))
        assert (image.width(), image.height()) == (1920, 1080), chemin.name
        assert 14 <= moyenne(image, 0, image.width()) <= 33, chemin.name
        assert chemin.stat().st_size < 160_000, chemin.name
    for chemin in sorted(S.BANNIERES.glob("*.jpg")):
        image = QImage(str(chemin))
        assert (image.width(), image.height()) == (2560, 128), chemin.name
        assert moyenne(image, 0, image.width() // 8) < 16, chemin.name


def test_decor_de_la_fenetre(app, monkeypatch, tmp_path):
    from PySide6.QtWidgets import QHBoxLayout, QWidget
    from orion.core.config import CONFIG
    from orion.ui import backdrop as B
    valeurs = {"ui.fond_du_jour": True, "ui.banniere_saison": True, "ui.background": "",
               "ui.background_dim": 78, "ui.dynamic_background": True}
    monkeypatch.setattr(CONFIG, "get", lambda cle, defaut=None: valeurs.get(cle, defaut))
    fond = B.Backdrop()
    lay = QHBoxLayout(fond)
    lay.setContentsMargins(0, 0, 0, 0)
    lay.setSpacing(0)
    barre, pages = QWidget(), QWidget()
    barre.setFixedWidth(220)
    lay.addWidget(barre)
    lay.addWidget(pages, 1)
    fond.set_pages(pages)
    fond.resize(1400, 800)
    lay.activate()
    # fond du jour et banniere de la saison, en haut des pages seulement
    assert fond._source == str(S.fond_du_jour())
    assert fond._banniere_source == str(S.banniere())
    zone = fond.zone_banniere()
    assert (zone.left(), zone.top(), zone.width(), zone.height()) == (220, 0, 1180, B.HAUTEUR_BANNIERE)
    assert not fond.grab().isNull()
    rendu = fond._rendre_banniere(zone.size()).toImage()
    assert rendu.pixelColor(2, 10).alpha() < 12                    # eteinte a gauche, sous le titre
    assert rendu.pixelColor(1100, 10).alpha() > 240
    assert rendu.pixelColor(1100, B.HAUTEUR_BANNIERE - 1).alpha() < 12   # et fondue vers le contenu
    # fiche d'un jeu : pas de banniere
    fond.montrer_banniere(False)
    assert fond.zone_banniere().isEmpty()
    fond.montrer_banniere(True)
    # l'image du joueur garde la priorite sur le fond du jour
    perso = tmp_path / "moi.jpg"
    perso.write_bytes((S.FONDS / "001.jpg").read_bytes())
    valeurs["ui.background"] = str(perso)
    fond.reload()
    assert fond._source == str(perso)
    # tout se coupe : la constellation d'Orion revient, sans banniere
    valeurs.update({"ui.background": "", "ui.fond_du_jour": False, "ui.banniere_saison": False})
    fond.reload()
    assert fond._source == str(B.BUILTIN) and fond.zone_banniere().isEmpty()
    # le lendemain, ORION toujours ouvert : le decor suit le calendrier
    valeurs.update({"ui.fond_du_jour": True, "ui.banniere_saison": True})
    fond.reload()
    fond._jour = dt.date.today() - dt.timedelta(days=1)
    fond._source = "hier"
    fond.suivre_le_jour()
    assert fond._jour == dt.date.today() and fond._source == str(S.fond_du_jour())


def test_textes_du_decor_traduits(app):
    from orion import i18n
    try:
        assert i18n.charger("en")
        for texte in ("Banniere de saison en haut des pages", "Celles d'ORION",
                      "Changer de fond chaque jour (sinon : la constellation d'Orion)",
                      "celles livrees avec ORION"):
            assert i18n.traduire(texte) != texte, texte
    finally:
        i18n._exact, i18n._modeles, i18n._mots = {}, [], {}
        i18n.traduire.cache_clear()


# ---------------------------------------------------------------------------
# Lisibilite des textes secondaires
# ---------------------------------------------------------------------------
def _contraste(a: str, b: str) -> float:
    def lum(h: str) -> float:
        r, g, bl = (int(h[i:i + 2], 16) / 255 for i in (1, 3, 5))
        f = lambda c: c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4   # noqa: E731
        return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(bl)
    x, y = sorted((lum(a), lum(b)), reverse=True)
    return (x + 0.05) / (y + 0.05)


def test_les_textes_secondaires_se_lisent_sur_tous_les_fonds():
    """Un petit texte demande un contraste d'au moins 4,5 (regle d'accessibilite
    AA) : l'ancien gris des mentions n'atteignait que 3,6."""
    from orion.ui.theme import PALETTE
    for fond in ("bg", "bg_alt", "surface", "surface_hi"):
        assert _contraste(PALETTE["text_faint"], PALETTE[fond]) >= 4.5, fond
        assert _contraste(PALETTE["text_dim"], PALETTE[fond]) >= 7, fond
    # l'ordre reste lisible : texte, attenue, discret
    assert (_contraste(PALETTE["text"], PALETTE["bg"]) > _contraste(PALETTE["text_dim"], PALETTE["bg"])
            > _contraste(PALETTE["text_faint"], PALETTE["bg"]))


def test_aucune_copie_des_anciens_gris():
    """Ces deux couleurs sont recopiees en dur dans quelques fichiers (panneaux
    dessines a la main, lecteur video, installateur) : une copie restee sur
    l'ancienne valeur donnerait deux gris differents a l'ecran."""
    import re
    from pathlib import Path
    from orion.ui.theme import PALETTE
    racine = Path(__file__).parents[1] / "orion"
    anciens = re.compile(r"#96A1B8|#5F6B84", re.I)
    restes = [str(f.relative_to(racine)) for f in racine.rglob("*.py")
              if anciens.search(f.read_text(encoding="utf-8"))]
    assert not restes, restes
    copies = {"ui/widgets/profile_card.py", "ui/widgets/puissance_panel.py", "ui/widgets/succes_panel.py",
              "optimizer/fiabilite.py", "videos.py", "deploiement/interface.py"}
    for nom in copies:
        texte = (racine / nom).read_text(encoding="utf-8").upper()
        assert PALETTE["text_dim"].upper() in texte or PALETTE["text_faint"].upper() in texte, nom
