"""9 octobre : 36 mesures sur 36 perdues. PresentMon 2.x ne connait plus
« --no_top » (1.x) : il affichait son aide et s'arretait. Son aide parle
d'« administrator », ce qui n'est pas un refus d'acces."""
from __future__ import annotations

import inspect

from orion.perf import presentmon


def test_options_de_presentmon_2():
    src = inspect.getsource(presentmon.PresentMonCapture.start) if hasattr(presentmon, "PresentMonCapture") \
        else inspect.getsource(presentmon)
    assert '"--no_top"' not in src and '"--no_console_stats"' in src


def test_aide_n_est_pas_un_refus_d_acces():
    aide = ("  --stop_existing_session  If a trace session...\n"
            "  --restart_as_admin  If not running with elevated privilege, restart and request "
            "to be run as administrator.")
    assert presentmon._aide(aide) and not presentmon._acces_refuse(aide)
    avertissement = ("warning: PresentMon requires elevated privilege in order to query processes that are "
                     "short-running... can't be targeted by --process_name nor trigger --terminate_on_proc_exit")
    assert not presentmon._aide(avertissement)
    assert presentmon._acces_refuse("error: failed to start trace session (access denied).")


def test_le_jeu_est_suivi_par_son_numero(tmp_path, monkeypatch):
    """Un jeu protege par un anti-triche n'a pas de nom pour PresentMon sans
    droits d'administrateur : ORION le designe par son numero de processus."""
    vus = {}

    class Faux:
        def __init__(self, args, **k):
            vus["args"] = args
    monkeypatch.setattr(presentmon, "installed_path", lambda: tmp_path / "PresentMon.exe")
    monkeypatch.setattr(presentmon.subprocess, "Popen", Faux)
    monkeypatch.setattr(presentmon, "TOOL_DIR", tmp_path)
    assert presentmon.Capture("Aniimo.exe", "u", "p", pid=4242).start()
    assert vus["args"][1:3] == ["--process_id", "4242"]
    assert presentmon.Capture("Aniimo.exe", "u", "p").start()
    assert vus["args"][1:3] == ["--process_name", "Aniimo.exe"]


def test_session_a_son_nom_pour_ne_pas_couper_frameview(tmp_path, monkeypatch):
    """9 octobre : « a trace session named "PresentMon" is already running and
    it will be stopped » : ORION coupait la mesure de FrameView (meme nom de
    session par defaut). ORION ouvre sa propre session."""
    vus = {}

    class Faux:
        def __init__(self, args, **k):
            vus["args"] = args
    monkeypatch.setattr(presentmon, "installed_path", lambda: tmp_path / "PresentMon.exe")
    monkeypatch.setattr(presentmon.subprocess, "Popen", Faux)
    monkeypatch.setattr(presentmon, "TOOL_DIR", tmp_path)
    assert presentmon.Capture("bg3_dx11.exe", "u", "p", pid=7).start()
    a = vus["args"]
    assert a[a.index("--session_name") + 1] == presentmon.SESSION != "PresentMon"


def test_les_chargements_ne_gonflent_plus_la_moyenne(tmp_path):
    """Aniimo bride a 40 i/s : 52,4 i/s de moyenne, maximum 1 075 i/s. Les
    rafales des ecrans de chargement sont ecartees ; la trace est gardee."""
    lignes = ["Application,SwapChainAddress,MsBetweenPresents"]
    lignes += ["Aniimo.exe,0x1,25.0"] * 3600            # 90 s de jeu a 40 i/s
    lignes += ["Aniimo.exe,0x1,1.0"] * 1500             # 1,5 s de chargement a 1 000 i/s
    lignes += ["Aniimo.exe,0x2,5.0"] * 100              # une autre chaine (menu, outil)
    trace = tmp_path / "capture_u.csv"
    trace.write_text("\n".join(lignes) + "\n", encoding="utf-8")
    stats = presentmon.analyse(trace, "u", "p")
    assert stats["fps_avg"] == 40.0 and stats["fps_max"] == 40.0
    assert stats["ecartees"] == 1500
    assert (tmp_path / presentmon.DERNIERE_TRACE).exists() and not trace.exists()


def test_un_avertissement_n_est_pas_l_erreur():
    """Les avertissements de PresentMon (droits, session) ne sont plus pris
    pour la cause d'un echec ; seule une ligne « error: » l'est."""
    src = inspect.getsource(presentmon.Capture.stop)
    assert 'startswith("error")' in src and "suivi sans droits" not in src


def test_arret_propre_de_la_mesure(tmp_path, monkeypatch):
    """La mesure s'arrete en fermant sa session Windows (PresentMon sort de
    lui-meme, releve complet) ; le programme n'est tue qu'en dernier recours."""
    appels = []

    class Proc:
        returncode = 0
        def __init__(self):
            self.vivant = True
        def poll(self):
            return None if self.vivant else 0
        def wait(self, timeout=None):
            self.vivant = False
        def terminate(self):
            appels.append("tue")
        def communicate(self, timeout=None):
            return b"", b""
    monkeypatch.setattr(presentmon, "installed_path", lambda: tmp_path / "PresentMon.exe")
    monkeypatch.setattr(presentmon.subprocess, "run", lambda args, **k: appels.append(args[1:]))
    monkeypatch.setattr(presentmon, "TOOL_DIR", tmp_path)
    monkeypatch.setattr(presentmon.time, "sleep", lambda s: None)
    c = presentmon.Capture("bg3_dx11.exe", "u", "p", pid=7)
    c.proc = Proc()
    c.stop()
    assert appels == [["--session_name", presentmon.SESSION, "--terminate_existing_session"]]
