"""Page Conseils (1.9) : inventaire des pilotes, reglages Windows, memoire,
disques et jeux. Tout part d'une sortie PowerShell factice : rien ne depend
de Windows."""
from __future__ import annotations

import datetime as dt

import pytest

AUJOURDHUI = dt.date(2026, 10, 1)


def _p(nom, classe, version, date, fournisseur, fabricant=""):
    return {"DeviceName": nom, "DeviceClass": classe, "DriverVersion": version,
            "DriverDate": date, "DriverProviderName": fournisseur,
            "Manufacturer": fabricant or fournisseur, "IsSigned": True}


def donnees_factices(**changer) -> dict:
    """Sortie du script PowerShell d'un PC de bureau Ryzen + RTX 4070 sur une
    carte mere ASUS, avec plusieurs choses a corriger."""
    pilotes = [
        _p("NVIDIA GeForce RTX 4070", "DISPLAY", "31.0.15.5186", "2024-01-18", "NVIDIA"),
        _p("NVIDIA High Definition Audio", "MEDIA", "1.4.0.1", "2024-01-01", "NVIDIA"),
        _p("AMD GPIO Controller", "SYSTEM", "2.2.0.130", "2023-02-10",
           "Advanced Micro Devices, Inc"),
        _p("AMD PSP 11.0 Device", "SYSTEM", "5.17.0.0", "2023-03-02",
           "Advanced Micro Devices, Inc"),
        _p("AMD SMBus", "SYSTEM", "5.12.0.38", "2022-11-20",
           "Advanced Micro Devices, Inc"),
        *[_p(f"Peripherique systeme {i}", "SYSTEM", "10.0.1", "2006-06-21", "Microsoft")
          for i in range(10)],
        _p("Realtek PCIe 2.5GbE Family Controller", "NET", "10.38.1",
           "2019-07-08", "Microsoft", "Realtek"),
        _p("Intel(R) Wi-Fi 6 AX200 160MHz", "NET", "23.60.0.10", "2026-06-02", "Intel"),
        _p("WAN Miniport (IP)", "NET", "10.0.1", "2006-06-21", "Microsoft"),
        _p("High Definition Audio Device", "MEDIA", "10.0.22621.1", "2006-06-21",
           "Microsoft", "Realtek"),
        _p("Standard NVM Express Controller", "SCSIADAPTER", "10.0.22621.1",
           "2006-06-21", "Microsoft"),
        _p("AMD USB 3.10 eXtensible Host Controller - 1.10 (Microsoft)", "USB",
           "10.0.22621.1", "2006-06-21", "Microsoft"),
        _p("Intel(R) Wireless Bluetooth(R)", "BLUETOOTH", "23.60.0.1", "2026-05-20", "Intel"),
        _p("Bluetooth LE Generic Attribute Service", "BLUETOOTH", "10.0.1",
           "2006-06-21", "Microsoft"),
    ]
    d = {
        "pilotes": pilotes,
        "sans_pilote": [{"nom": "Controleur PCI simple", "classe": "", "code": 28}],
        "mode_jeu": 0,
        "hags": 1,
        "capture_fond": 0,
        "plans": "GUID du mode de gestion de l'alimentation : "
                 "a1841308-3541-4fab-bc81-f71556f20b4a  (Economies d'energie) *\n"
                 "GUID du mode de gestion de l'alimentation : "
                 "381b4222-f694-41f0-9685-ff5bb260df2e  (Utilisation normale)",
        "boitier": [3],
        "batteries": 0,
        "pc": {"fabricant": "System manufacturer", "modele": "System Product Name",
               "type": 1, "pagination_auto": False},
        "carte_mere": {"fabricant": "ASUSTeK COMPUTER INC.", "modele": "TUF GAMING B650-PLUS"},
        "barrettes": [
            {"capacite": 17179869184, "vitesse": 4800, "configuree": 4800,
             "emplacement": "DIMM_A2", "banque": "P0 CHANNEL A",
             "reference": "F5-6000J3038F16G", "type": 34},
            {"capacite": 17179869184, "vitesse": 4800, "configuree": 4800,
             "emplacement": "DIMM_B2", "banque": "P0 CHANNEL B",
             "reference": "F5-6000J3038F16G", "type": 34},
        ],
        "disques": [{"numero": "0", "nom": "Samsung SSD 980 PRO 1TB", "type": "SSD",
                     "bus": "NVMe"},
                    {"numero": "1", "nom": "ST2000DM008", "type": "HDD", "bus": "SATA"}],
        "partitions": [{"lettre": "C", "disque": "0"}, {"lettre": "D", "disque": "1"}],
        "redemarrage": {"cbs": False, "wu": True},
        "pagination": [],
        "pagination_usage": [],
    }
    d.update(changer)
    return d


def machine_factice(etat=None):
    from orion.core.models import Display, DisplayMode, GPUInfo, HardwareInfo
    from orion.hardware import systeme
    hw = HardwareInfo(cpu_name="AMD Ryzen 7 7800X3D 8-Core Processor", cpu_cores=8,
                      cpu_threads=16, cpu_ghz=4.2, ram_gb=31.1,
                      os_name="Windows 11 Pro 24H2", os_build="26100.2033")
    hw.gpus = [GPUInfo(name="NVIDIA GeForce RTX 4070", vendor="nvidia", vram_mb=12282,
                       driver_version="551.86", driver_date="1-18-2024", tier=2,
                       features=["dlss", "dlss_fg", "rt"])]
    modes = [DisplayMode(2560, 1440, r) for r in (60, 120, 144, 165)]
    hw.displays = [Display(device="\\\\.\\DISPLAY1", name="LG ULTRAGEAR", primary=True,
                           current=DisplayMode(2560, 1440, 60),
                           native=DisplayMode(2560, 1440, 165), modes=modes)]
    hw.disks = [{"mount": "C:\\", "type": "fixed", "total_gb": 931, "free_gb": 38},
                {"mount": "D:\\", "type": "fixed", "total_gb": 1863, "free_gb": 712}]
    hw.systeme = etat if etat is not None else systeme.interpreter(donnees_factices())
    return hw


def jeux_factices():
    from orion.core.models import Game
    return [Game(title="Cyberpunk 2077", source="steam", source_id="1091500",
                 install_dir="D:\\SteamLibrary\\steamapps\\common\\Cyberpunk 2077",
                 size_bytes=71 * 1024 ** 3),
            Game(title="Baldur's Gate 3", source="steam", source_id="1086940",
                 install_dir="D:\\SteamLibrary\\steamapps\\common\\Baldurs Gate 3",
                 size_bytes=122 * 1024 ** 3, update_pending=True),
            Game(title="Hades II", source="steam", source_id="1145350",
                 install_dir="C:\\Steam\\steamapps\\common\\Hades II",
                 size_bytes=9 * 1024 ** 3)]


@pytest.fixture
def advisor():
    from orion.optimizer import advisor
    return advisor


def _titres(conseils):
    return [a.title for a in conseils]


# ----------------------------------------------------------------------
# lecture de la sortie PowerShell
# ----------------------------------------------------------------------
def test_interpreter_classe_les_pilotes():
    from orion.hardware import systeme as s
    e = s.interpreter(s.lire_json("AVERTISSEMENT bruit\n" + __import__("json").dumps(
        donnees_factices())))
    cats = {p.nom: p.categorie for p in e.pilotes}
    assert cats["NVIDIA GeForce RTX 4070"] == "graphique"
    assert cats["AMD GPIO Controller"] == "chipset"
    assert cats["Realtek PCIe 2.5GbE Family Controller"] == "reseau"
    assert cats["High Definition Audio Device"] == "audio"
    assert cats["Standard NVM Express Controller"] == "stockage"
    assert cats["AMD USB 3.10 eXtensible Host Controller - 1.10 (Microsoft)"] == "usb"
    assert cats["Intel(R) Wireless Bluetooth(R)"] == "bluetooth"
    # son HDMI, interfaces virtuelles et services Bluetooth : ignores
    for ignore in ("NVIDIA High Definition Audio", "WAN Miniport (IP)",
                   "Bluetooth LE Generic Attribute Service"):
        assert ignore not in cats
    reseau = next(p for p in e.pilotes if p.categorie == "reseau" and p.generique)
    assert reseau.marque == "realtek" and reseau.date == dt.date(2019, 7, 8)
    assert e.plan_actif == s.PLAN_ECONOMIE and e.bureau and e.pagination_auto is False
    assert e.type_disque("C") == "SSD" and e.type_disque("d:") == "HDD"
    assert e.classes_brutes["SYSTEM"] == 13


def test_lecture_robuste():
    from orion.hardware import systeme as s
    assert s.lire_json("") == {} and s.lire_json("pas de json") == {}
    e = s.interpreter({"pilotes": _p("NVIDIA GeForce GTX 1060", "DISPLAY", "1", "5-14-2024",
                                     "NVIDIA")})            # tableau aplati
    assert len(e.pilotes) == 1 and e.pilotes[0].date == dt.date(2024, 5, 14)
    assert s.interpreter({"erreur_pilotes": "WMI"}).pilotes is None
    assert s.lire_date("/Date(1715644800000)/") == dt.date(2024, 5, 14)
    assert s.lire_date("20240514000000.000000+000") == dt.date(2024, 5, 14)
    assert s.vitesse_annoncee("CMK32GX4M2D3600C18") == 3600
    assert s.vitesse_annoncee("KF560C36-16") == 6000
    assert s.canal("DIMM_A2") == "A" and s.canal("ChannelB-DIMM1") == "B"


def test_collecte_hors_windows_et_en_echec(monkeypatch):
    from orion.hardware import systeme as s
    monkeypatch.setattr(s, "is_windows", lambda: False)
    assert s.collecter(force=True) is None
    monkeypatch.setattr(s, "is_windows", lambda: True)

    def panne():
        raise FileNotFoundError("powershell introuvable")
    monkeypatch.setattr(s, "_executer", panne)
    e = s.collecter(force=True)
    assert e is not None and e.pilotes is None and "powershell" in e.erreurs[0]
    monkeypatch.setattr(s, "_CACHE", None)


def test_execution_sans_fenetre(monkeypatch):
    """PowerShell est lance par popen_propre, sans fenetre, avec un delai."""
    import subprocess
    from orion.core import lancement
    from orion.hardware import systeme as s
    vu = {}

    class Faux:
        def communicate(self, timeout=None):
            vu["timeout"] = timeout
            return b'{"mode_jeu": 1}', b""

    def popen(args, **kw):
        vu.update(args=args, **kw)
        return Faux()
    monkeypatch.setattr(lancement, "popen_propre", popen)
    assert s.lire_json(s._executer()) == {"mode_jeu": 1}
    assert vu["creationflags"] == s.CREATE_NO_WINDOW and vu["timeout"] == s.DELAI_MAX
    assert "-EncodedCommand" in vu["args"] and vu["stdin"] == subprocess.DEVNULL


# ----------------------------------------------------------------------
# pilotes
# ----------------------------------------------------------------------
def test_pilotes_tous_analyses(advisor):
    hw = machine_factice()
    c = advisor.conseils_pilotes(hw.systeme, hw, AUJOURDHUI)
    par_titre = {a.title: a for a in c}
    assert set(par_titre) >= {
        "Peripheriques sans pilote ou en erreur", "Pilote graphique ancien",
        "Pilotes du chipset anciens", "Carte reseau sous pilote generique Microsoft",
        "Puce audio sous pilote generique Microsoft"}
    gpu = par_titre["Pilote graphique ancien"]
    assert gpu.level == "attention" and gpu.action_url == advisor.LIENS["nvidia"]
    assert "31.0.15.5186" in gpu.preuve and "18/01/2024" in gpu.preuve
    chipset = par_titre["Pilotes du chipset anciens"]
    # tour montee sur carte ASUS : la page support de la carte mere, pour ce modele precis
    assert chipset.action_url == "https://www.asus.com/supportonly/tuf%20gaming%20b650-plus/helpdesk_download/"
    assert "AMD" in chipset.detail and "TUF GAMING B650-PLUS" in chipset.detail
    assert chipset.action == "Pilotes ASUS pour TUF GAMING B650-PLUS"
    # pilote reseau generique : renvoi vers la page support de la carte mere
    reseau = par_titre["Carte reseau sous pilote generique Microsoft"]
    assert "asus.com" in reseau.action_url and "TUF GAMING B650-PLUS" in reseau.detail
    # les pilotes recents (Wi-Fi, Bluetooth Intel) ne sont pas signales
    assert not any("Wi-Fi" in a.preuve for a in c if a.level != "ok")
    recap = c[-1]
    assert recap.level == "ok" and recap.title == "10 pilotes analyses"
    for cat in ("Carte graphique", "Reseau", "Audio", "Chipset", "Stockage", "USB",
                "Bluetooth"):
        assert cat in recap.preuve
    assert all(a.groupe == "Pilotes" for a in c)


def test_pilotes_a_jour_rien_a_signaler(advisor):
    from orion.hardware import systeme as s
    d = donnees_factices(sans_pilote=[], pilotes=[
        _p("NVIDIA GeForce RTX 4070", "DISPLAY", "32.0.15.8100", "2026-08-20", "NVIDIA"),
        _p("Intel(R) Ethernet Controller I226-V", "NET", "2.1.4.3", "2025-11-03", "Intel"),
        _p("Realtek High Definition Audio", "MEDIA", "6.0.9600.1", "2025-02-01", "Realtek"),
    ])
    hw = machine_factice(s.interpreter(d))
    c = advisor.conseils_pilotes(hw.systeme, hw, AUJOURDHUI)
    assert len(c) == 1 and c[0].title == "3 pilotes analyses, rien a signaler"


def test_dates_factices_et_chipset_absent(advisor):
    from orion.hardware import systeme as s
    pilotes = [_p("Intel(R) Management Engine Interface #1", "SYSTEM", "2406.5.5.0",
                  "1968-07-18", "Intel")]
    pilotes += [_p(f"Peripherique {i}", "SYSTEM", "1", "2006-06-21", "Microsoft")
                for i in range(12)]
    hw = machine_factice(s.interpreter(donnees_factices(pilotes=pilotes, sans_pilote=[])))
    c = advisor.conseils_pilotes(hw.systeme, hw, AUJOURDHUI)
    # date 1968 du paquet Intel : aucune alerte d'age inventee
    assert "Pilotes du chipset anciens" not in _titres(c)
    # processeur AMD sans aucun pilote systeme AMD
    assert "Pilotes du chipset AMD absents" in _titres(c)


def test_carte_graphique_sans_pilote_et_inventaire_impossible(advisor):
    from orion.hardware import systeme as s
    d = donnees_factices(pilotes=[_p("Microsoft Basic Display Adapter", "DISPLAY",
                                     "10.0.1", "2006-06-21", "Microsoft")])
    hw = machine_factice(s.interpreter(d))
    c = advisor.conseils_pilotes(hw.systeme, hw, AUJOURDHUI)
    assert "Carte graphique sans pilote" in _titres(c)
    vide = s.EtatSysteme(erreurs=["delai depasse"])
    c = advisor.conseils_pilotes(vide, hw, AUJOURDHUI)
    assert _titres(c) == ["Inventaire des pilotes indisponible"]
    assert advisor.conseils_pilotes(None, hw) == []


# ----------------------------------------------------------------------
# Windows
# ----------------------------------------------------------------------
def test_reglages_windows(advisor):
    hw = machine_factice()
    titres = _titres(advisor.conseils_windows(hw.systeme, hw))
    assert titres == ["Mode jeu de Windows desactive",
                      "Planification GPU acceleree desactivee",
                      "Plan Economie d'energie actif", "Redemarrage en attente",
                      "Fichier d'echange desactive"]
    hags = advisor.conseils_windows(hw.systeme, hw)[1]
    assert hags.level == "attention" and "DLSS" in hags.detail      # RTX 40 : DLSS FG


def test_windows_bien_regle(advisor):
    from orion.hardware import systeme as s
    d = donnees_factices(mode_jeu=1, hags=2, redemarrage={"cbs": False, "wu": False},
                         plans="GUID : 381b4222-f694-41f0-9685-ff5bb260df2e  (Normal) *",
                         pc={"type": 1, "pagination_auto": True})
    hw = machine_factice(s.interpreter(d))
    assert advisor.conseils_windows(hw.systeme, hw) == []


def test_x3d_double_bloc_et_portable(advisor):
    from orion.hardware import systeme as s
    d = donnees_factices(plans="GUID : 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c  (Perf) *")
    hw = machine_factice(s.interpreter(d))
    hw.cpu_name, hw.cpu_cores = "AMD Ryzen 9 7950X3D 16-Core Processor", 16
    assert "Plan d'alimentation inadapte au Ryzen X3D" in _titres(
        advisor.conseils_windows(hw.systeme, hw))
    d = donnees_factices(boitier=[10], batteries=1)
    hw = machine_factice(s.interpreter(d))
    plan = next(a for a in advisor.conseils_windows(hw.systeme, hw)
                if a.title == "Plan Economie d'energie actif")
    assert plan.level == "conseil"                       # sur batterie : simple conseil


def test_fichier_echange_petit(advisor):
    from orion.hardware import systeme as s
    d = donnees_factices(pagination=[{"nom": "C:\\pagefile.sys", "initial": 1024,
                                      "maximum": 2048}])
    hw = machine_factice(s.interpreter(d))
    assert "Fichier d'echange tres petit" in _titres(advisor.conseils_windows(hw.systeme, hw))


# ----------------------------------------------------------------------
# materiel et jeux
# ----------------------------------------------------------------------
def test_memoire_sous_sa_vitesse(advisor):
    hw = machine_factice()
    c = advisor.conseils_materiel(hw.systeme, hw)
    assert _titres(c) == ["Memoire a 4800 MT/s au lieu de 6000"]
    assert c[0].level == "attention" and "EXPO" in c[0].detail
    assert "DIMM_A2" in c[0].preuve


def test_simple_canal_et_meme_canal(advisor):
    from orion.hardware import systeme as s
    b = donnees_factices()["barrettes"][0]
    hw = machine_factice(s.interpreter(donnees_factices(barrettes=[dict(b, configuree=6000)])))
    assert _titres(advisor.conseils_materiel(hw.systeme, hw)) == ["Memoire en simple canal"]
    deux = [dict(b, configuree=6000), dict(b, configuree=6000, emplacement="DIMM_A1")]
    hw = machine_factice(s.interpreter(donnees_factices(barrettes=deux)))
    assert _titres(advisor.conseils_materiel(hw.systeme, hw)) == ["Barrettes sur le meme canal"]


def test_windows_sur_disque_dur(advisor):
    from orion.hardware import systeme as s
    d = donnees_factices(partitions=[{"lettre": "C", "disque": "1"}])
    hw = machine_factice(s.interpreter(d))
    assert "Windows est installe sur un disque dur" in _titres(
        advisor.conseils_materiel(hw.systeme, hw))


def test_jeux_sur_disque_dur(advisor):
    hw = machine_factice()
    c = advisor.conseils_jeux(jeux_factices(), hw.systeme, hw)
    hdd = c[0]
    assert hdd.title == "2 jeux installes sur un disque dur"
    assert hdd.preuve.splitlines()[0].startswith("Baldur's Gate 3 · D: (ST2000DM008)")
    assert "Deplacer le dossier d'installation" in hdd.detail and "C:\\" in hdd.detail
    assert c[1].title == "Un jeu attend une mise a jour"


def test_ecran_et_disque_systeme(advisor):
    hw = machine_factice()
    titres = _titres(advisor.for_system(hw))
    assert "LG ULTRAGEAR tourne a 60 Hz" in titres
    plein = next(a for a in advisor.for_system(hw) if a.title.endswith("presque plein"))
    assert plein.groupe == "Materiel" and "38 Go" in plein.preuve      # 4 % de 931 Go
    hw.disks[0]["free_gb"] = 80
    assert "Espace limite sur C:\\" in _titres(advisor.for_system(hw))
    hw.disks[0]["free_gb"] = 300
    assert not any("C:" in t for t in _titres(advisor.for_system(hw)))
    # un grand disque de donnees bien rempli n'est pas signale pour 10 %
    hw.disks = [{"mount": "D:\\", "type": "fixed", "total_gb": 4000, "free_gb": 300}]
    assert not any("D:" in t for t in _titres(advisor.for_system(hw)))


def test_page_complete_groupee_et_triee(advisor):
    hw = machine_factice()
    c = advisor.for_system(hw, jeux_factices())
    assert {a.groupe for a in c} == {"Pilotes", "Windows", "Materiel", "Jeux"}
    rangs = [a.rank for a in c]
    assert rangs == sorted(rangs)
    # sans etat systeme (hors Windows) : uniquement les regles de base
    hw.systeme = None
    c = advisor.for_system(hw, [])
    assert all(a.groupe in ("Pilotes", "Materiel") for a in c)
    assert "Pilote graphique ancien" in _titres(c)            # repli registre


def test_regle_en_echec_n_empeche_rien(advisor, monkeypatch):
    def casse(hw):
        raise RuntimeError("boum")
    monkeypatch.setattr(advisor, "SYSTEM_RULES", [casse] + advisor.SYSTEM_RULES)
    assert advisor.for_system(machine_factice())


# ----------------------------------------------------------------------
# page
# ----------------------------------------------------------------------
@pytest.fixture
def app():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


def test_page_conseils(app, advisor):
    from orion.ui.views.advice_view import AdviceView, resume
    from orion.ui.widgets.advice_card import AdviceCard
    v = AdviceView()
    assert "Analyse" in v.count.text()
    v.set_advice(advisor.for_system(machine_factice(), jeux_factices()))
    assert v.tuiles["Pilotes"].property("etat") == "attention"
    assert v.tuiles["Jeux"].property("etat") == "conseil"
    cartes = v.findChildren(AdviceCard)
    assert len(cartes) == len(v.items)
    recap = next(c for c in cartes if c.advice.level == "ok")
    assert recap.deplier is not None and "Afficher" in recap.deplier.text()
    recap.deplier.click()
    assert recap.preuve.text().count("\n") >= 6
    assert resume([]) == ("vide", 0, "Rien a signaler")
    demandes = []
    v.refresh_requested.connect(lambda: demandes.append(1))
    v._actualiser()
    assert demandes == [1] and "Analyse" in v.count.text()


# ----------------------------------------------------------------------
# page (2.0) : pas de reconstruction inutile, conseils masquables, rapport
# ----------------------------------------------------------------------
@pytest.fixture
def reglages_conseils():
    from orion.core.config import CONFIG
    anciens = CONFIG.get("advisor.masques", []), CONFIG.get("advisor.a_traiter", False)
    CONFIG.set("advisor.masques", [], save=False)
    CONFIG.set("advisor.a_traiter", False, save=False)
    yield CONFIG
    CONFIG.set("advisor.masques", anciens[0], save=False)
    CONFIG.set("advisor.a_traiter", anciens[1], save=False)


def test_la_page_ne_se_reconstruit_pas_si_rien_n_a_change(app, advisor, reglages_conseils):
    from orion.ui.views.advice_view import AdviceView
    from orion.ui.widgets.advice_card import AdviceCard
    v = AdviceView()
    hw, jeux = machine_factice(), jeux_factices()
    v.set_advice(advisor.for_system(hw, jeux))
    cartes = v.findChildren(AdviceCard)
    heure = v.quand.text()
    v.set_occupe(True)
    v.set_advice(advisor.for_system(hw, jeux), analyse=False)     # simple visite
    assert v.findChildren(AdviceCard) == cartes                   # les memes objets
    assert v.bouton.isEnabled() and "point(s) d'attention" in v.count.text()
    assert v.quand.text() == heure
    # un conseil de moins : la page suit
    jeux[1].update_pending = False
    v.set_advice(advisor.for_system(hw, jeux))
    assert len([c for c in v.findChildren(AdviceCard) if c.parent() is not None
                and not c.signalsBlocked()]) == len(cartes) - 1


def test_un_conseil_masque_disparait_et_se_retrouve(app, advisor, reglages_conseils):
    from orion.ui.views.advice_view import AdviceView
    from orion.ui.widgets.advice_card import AdviceCard, cle

    def cartes(vue):
        return [c for c in vue.findChildren(AdviceCard) if not c.signalsBlocked()]

    v = AdviceView()
    recus = []
    v.alertes_changees.connect(recus.append)
    v.set_advice(advisor.for_system(machine_factice(), jeux_factices()))
    alertes = recus[-1]
    assert alertes == sum(1 for a in v.items if a.level == "attention") >= 5
    cible = next(c for c in cartes(v) if c.advice.title == "Fichier d'echange desactive")
    assert not hasattr(next(c for c in cartes(v) if c.advice.level == "ok"), "b_masquer")
    avant = len(cartes(v))
    cible.b_masquer.click()
    assert len(cartes(v)) == avant - 1
    assert recus[-1] == alertes - 1                       # la pastille du menu suit
    assert reglages_conseils.get("advisor.masques") == [cle(cible.advice)]
    assert v.tuiles["Windows"].chiffre.text() == "4"      # 3 a corriger + 2 conseils - 1
    assert any("1 conseil(s) masque(s) : Fichier d'echange desactive" in e.text()
               for e in v.body.findChildren(type(v.count)) if not e.signalsBlocked())
    # une nouvelle analyse ne le ramene pas
    v.set_advice(advisor.for_system(machine_factice(), jeux_factices()))
    assert "Fichier d'echange desactive" not in [c.advice.title for c in cartes(v)]
    v.b_reafficher.click()
    assert len(cartes(v)) == avant and recus[-1] == alertes
    assert reglages_conseils.get("advisor.masques") == []


def test_la_cle_d_un_conseil_ignore_les_chiffres_pas_le_disque(advisor):
    from orion.optimizer.advisor import Advice
    from orion.ui.widgets.advice_card import cle
    a = Advice("conseil", "2 jeux installes sur un disque dur", "", groupe="Jeux")
    b = Advice("conseil", "3 jeux installes sur un disque dur", "", groupe="Jeux")
    assert cle(a) == cle(b)
    c = Advice("attention", "Disque C:\\ presque plein", "", groupe="Materiel")
    d = Advice("attention", "Disque D:\\ presque plein", "", groupe="Materiel")
    assert cle(c) != cle(d)
    assert cle(Advice("conseil", "Redemarrage en attente", "", groupe="Windows")) != \
        cle(Advice("conseil", "Redemarrage en attente", "", groupe="Pilotes"))


def test_a_traiter_seulement_replie_ce_qui_est_deja_bon(app, advisor, reglages_conseils):
    from orion.ui.views.advice_view import AdviceView
    from orion.ui.widgets.advice_card import AdviceCard
    v = AdviceView()
    v.set_advice(advisor.for_system(machine_factice(), jeux_factices()))
    tout = len([c for c in v.findChildren(AdviceCard) if not c.signalsBlocked()])
    v.a_traiter.setChecked(True)
    restes = [c for c in v.findChildren(AdviceCard) if not c.signalsBlocked()]
    assert 0 < len(restes) < tout
    assert {c.advice.level for c in restes} <= {"attention", "conseil"}
    assert reglages_conseils.get("advisor.a_traiter") is True
    assert v.tuiles["Pilotes"].property("etat") == "attention"     # les tuiles ne changent pas
    v.a_traiter.setChecked(False)
    assert len([c for c in v.findChildren(AdviceCard) if not c.signalsBlocked()]) == tout


def test_le_rapport_copie_tout_en_texte(app, advisor, reglages_conseils):
    from PySide6.QtWidgets import QApplication
    from orion.ui.views.advice_view import AdviceView
    v = AdviceView()
    v.set_advice(advisor.for_system(machine_factice(), jeux_factices()))
    texte = v.rapport()
    assert texte.startswith("ORION - Conseils")
    for rubrique in ("== Pilotes ==", "== Windows ==", "== Materiel ==", "== Jeux =="):
        assert rubrique in texte
    assert "[A corriger] Fichier d'echange desactive" in texte
    assert "<" not in texte                                 # pas de balises
    v.copier.click()
    assert QApplication.clipboard().text() == texte
    assert v.copier.text() == "Copie !"


# ----------------------------------------------------------------------
# portable ou PC de marque : les pilotes viennent du constructeur
# (retour de l'auteur, 8 octobre : un portable HP renvoyait vers Intel)
# ----------------------------------------------------------------------
def test_portable_hp_pilotes_chez_le_constructeur(advisor):
    from orion.hardware import systeme as s
    d = donnees_factices(boitier=[10], batteries=1,
                         pc={"fabricant": "HP", "modele": "Victus by HP Laptop 16-e0xxx",
                             "type": 2, "pagination_auto": True, "sku": "4M4R6EA#ABF"},
                         carte_mere={"fabricant": "HP", "modele": "88D4"},
                         pilotes=[
        _p("Intel(R) Wi-Fi 6 AX201 160MHz", "NET", "22.10.0.7", "2022-01-05", "Intel"),
        _p("Synaptics HD Audio", "MEDIA", "8.65.1.0", "2021-11-02", "Synaptics"),
        _p("Intel(R) Chipset SATA/PCIe RST Premium Controller", "SCSIADAPTER",
           "18.1.0.1012", "2021-06-01", "Intel"),
        _p("NVIDIA GeForce RTX 3060 Laptop GPU", "DISPLAY", "31.0.15.5186", "2024-01-18", "NVIDIA"),
    ])
    etat = s.interpreter(d)
    assert etat.boitier == "portable" and etat.pc_sku == "4M4R6EA#ABF"
    c = advisor.conseils_pilotes(etat, machine_factice(), AUJOURDHUI)
    par_titre = {a.title: a for a in c}
    for titre in ("Pilote reseau ancien", "Pilote audio ancien", "Pilote de stockage ancien"):
        a = par_titre[titre]
        assert "support.hp.com" in a.action_url, titre
        assert a.action == "Pilotes HP pour ce modele", titre
        assert "16-e0xxx" in a.detail and "4M4R6EA#ABF" in a.detail, titre
        assert "intel.com" not in a.action_url and "Intel Driver" not in a.action
    # la carte graphique NVIDIA reste chez NVIDIA
    assert par_titre["Pilote graphique ancien"].action_url == advisor.LIENS["nvidia"]


def test_tour_montee_soi_meme_garde_les_liens_des_puces(advisor):
    from orion.hardware import systeme as s
    d = donnees_factices(pc={"fabricant": "Micro-Star International Co., Ltd.", "modele": "MS-7D75",
                             "type": 1, "pagination_auto": True, "sku": "To be filled by O.E.M."},
                         carte_mere={"fabricant": "Micro-Star International Co., Ltd.",
                                     "modele": "MAG B650 TOMAHAWK WIFI (MS-7D75)"},
                         pilotes=[
        _p("Intel(R) Wi-Fi 6E AX210 160MHz", "NET", "22.10.0.7", "2022-01-05", "Intel"),
        _p("Realtek High Definition Audio", "MEDIA", "6.0.9235.1", "2021-11-02", "Realtek"),
    ])
    etat = s.interpreter(d)
    assert etat.pc_sku == ""
    c = advisor.conseils_pilotes(etat, machine_factice(), AUJOURDHUI)
    par_titre = {a.title: a for a in c}
    wifi = par_titre["Pilote reseau ancien"]
    assert wifi.action == "Pilotes Wi-Fi Intel" and wifi.action_url.endswith("/19351/intel-wireless-wi-fi-drivers-for-windows-10-and-windows-11.html")
    assert "MAG B650 TOMAHAWK WIFI" in wifi.detail and "page support de MSI" in wifi.detail
    audio = par_titre["Pilote audio ancien"]
    assert audio.action_url == "https://www.msi.com/Motherboard/MAG-B650-TOMAHAWK-WIFI/support"
    assert audio.action == "Pilotes MSI pour MAG B650 TOMAHAWK WIFI (MS-7D75)"


# ----------------------------------------------------------------------
# Windows Update : le pilote plus recent propose pour cette puce
# ----------------------------------------------------------------------
def test_windows_update_lecture_et_cle():
    from orion.hardware import maj_pilotes as wu
    res = wu.interpreter({"pilotes": [
        {"titre": "Intel Corporation - Net - 22.250.1.1", "classe": "Net", "fabricant": "Intel Corporation",
         "modele": "Intel(R) Wi-Fi 6 AX201 160MHz", "fournisseur": "Intel", "date": "2025-09-02",
         "id": "PCI\\VEN_8086&DEV_2723&SUBSYS_00848086", "taille": 4300000.0, "telecharge": False},
        {"titre": "HP Inc. - Firmware - 1.4.0.0", "classe": "Firmware", "fabricant": "HP Inc.",
         "id": "ACPI\\HPQ0004", "date": "2025-08-01"},
    ]}, lu=1_800_000_000)
    assert [m.version for m in res.pilotes] == ["22.250.1.1", "1.4.0.0"]
    assert res.pilotes[0].cle_materiel == "PCI\\VEN_8086&DEV_2723"
    assert res.pour("PCI\\VEN_8086&DEV_2723") is res.pilotes[0]
    assert res.pour("PCI\\VEN_10DE&DEV_2504") is None and res.pour("") is None
    # un seul element : ConvertTo-Json rend un objet, pas une liste
    seul = wu.interpreter({"pilotes": {"titre": "Realtek - MEDIA - 6.0.9800.1", "id": "HDAUDIO\\FUNC_01&VEN_10EC&DEV_0256"}})
    assert len(seul.pilotes) == 1 and seul.pilotes[0].cle_materiel == "HDAUDIO\\VEN_10EC&DEV_0256"
    assert wu.interpreter({"erreur": "Exception HRESULT"}).erreur.startswith("Exception")


def test_windows_update_propose_un_pilote_plus_recent(advisor):
    from orion.hardware import systeme as s
    from orion.hardware import maj_pilotes as wu
    d = donnees_factices(pc={"fabricant": "HP", "modele": "HP EliteDesk 800 G6 TWR", "type": 1,
                             "pagination_auto": True, "sku": "1D2M3EA#ABF"},
                         carte_mere={"fabricant": "HP", "modele": "8715"},
                         pilotes=[
        dict(_p("Intel(R) Wi-Fi 6 AX201 160MHz", "NET", "22.10.0.7", "2022-01-05", "Intel"),
             HardwareID="PCI\\VEN_8086&DEV_2723&SUBSYS_00848086&REV_1A"),
        dict(_p("Synaptics HD Audio", "MEDIA", "8.65.1.0", "2021-11-02", "Synaptics"),
             HardwareID="HDAUDIO\\FUNC_01&VEN_14F1&DEV_50F4&SUBSYS_103C8715"),
        dict(_p("NVIDIA GeForce RTX 3060", "DISPLAY", "31.0.15.5186", "2024-01-18", "NVIDIA"),
             HardwareID="PCI\\VEN_10DE&DEV_2504&SUBSYS_00000000"),
    ])
    etat = s.interpreter(d)
    assert etat.pilotes[0].cle_materiel == "PCI\\VEN_8086&DEV_2723"
    maj = wu.interpreter({"pilotes": [
        {"titre": "Intel Corporation - Net - 22.250.1.1", "classe": "Net", "fabricant": "Intel Corporation",
         "date": "2025-09-02", "id": "PCI\\VEN_8086&DEV_2723&SUBSYS_00848086", "taille": 4300000.0},
        {"titre": "HP Inc. - Firmware - 1.4.0.0", "classe": "Firmware", "fabricant": "HP Inc.",
         "id": "ACPI\\HPQ0004"},
    ]}, lu=1_800_000_000)
    c = advisor.conseils_pilotes(etat, machine_factice(), AUJOURDHUI, maj=maj)
    par_titre = {a.title: a for a in c}
    wifi = par_titre["Pilote plus recent dans Windows Update : reseau"]
    assert wifi.level == "conseil" and wifi.action_url == wu.ADRESSE_WINDOWS_UPDATE
    assert "22.10.0.7" in wifi.detail and "22.250.1.1" in wifi.detail and "02/09/2025" in wifi.detail
    assert "Intel Corporation - Net - 22.250.1.1" in wifi.preuve and "4 Mo" in wifi.preuve
    # pas de doublon « Pilote reseau ancien » pour la meme puce
    assert "Pilote reseau ancien" not in par_titre
    # l'audio, lui, reste « ancien » : Windows Update n'en propose pas, et on le dit
    audio = par_titre["Pilote audio ancien"]
    assert "Windows Update n'en propose pas de plus recent" in audio.detail
    assert "support.hp.com" in audio.action_url and "1D2M3EA#ABF" in audio.detail
    # le pilote facultatif hors inventaire est signale a part
    autres = par_titre["1 autre(s) pilote(s) facultatif(s) dans Windows Update"]
    assert autres.level == "info" and "HP Inc. - Firmware - 1.4.0.0" in autres.preuve
    # sans resultat Windows Update : l'ancienne phrase prudente
    c2 = advisor.conseils_pilotes(etat, machine_factice(), AUJOURDHUI, maj=wu.Resultat(lu=0, erreur="x"))
    assert "l'outil du fabricant confirmera" in {a.title: a for a in c2}["Pilote audio ancien"].detail


# ----------------------------------------------------------------------
# NVIDIA : la derniere version de la serie, par le service
# ----------------------------------------------------------------------
def test_nvidia_serie_et_versions():
    from orion.hardware import pilotes_nvidia as nv
    import types
    assert nv.serie("NVIDIA GeForce RTX 4070") == "40"
    assert nv.serie("NVIDIA GeForce RTX 4070 Laptop GPU") == "40p"
    assert nv.serie("NVIDIA GeForce RTX 3060", portable=True) == "30p"
    assert nv.serie("NVIDIA GeForce GTX 1660 SUPER") == "16"
    assert nv.serie("NVIDIA GeForce GTX 1080 Ti") == "10"
    assert nv.serie("NVIDIA GeForce RTX 5090") == "50" and nv.serie("AMD Radeon RX 7800 XT") == ""
    assert nv.version_installee(types.SimpleNamespace(driver_version="581.42")) == "581.42"
    assert nv.version_installee(types.SimpleNamespace(driver_version="32.0.15.6174")) == "561.74"
    assert nv.version_installee(types.SimpleNamespace(driver_version="31.0.15.5186")) == "551.86"
    assert nv.version_installee(types.SimpleNamespace(driver_version="")) == ""
    assert nv.plus_recente("561.74", "617.42") and not nv.plus_recente("617.42", "617.42")
    assert not nv.plus_recente("x", "617.42")
    d = nv.interpreter({"maj": "2026-10-08T09:00:00Z", "nvidia": {
        "40": {"version": "617.42", "date": "2026-10-06", "nom": "GeForce Game Ready Driver",
               "details": "https://www.nvidia.com/en-us/drivers/details/280103/", "fichier": "https://us.download.nvidia.com/x.exe"},
        "10": {"version": "582.78", "date": "2026-09-30", "nom": "GeForce Security Update Driver", "details": "https://www.nvidia.com/en-us/drivers/details/280034/"},
        "x": {"version": "pas une version"}, "y": {"version": "617.42", "details": "https://pirate.example/"}}})
    assert set(d) == {"40", "10"} and d["40"].version == "617.42" and d["10"].nom == "GeForce Security Update Driver"


def test_nvidia_plus_recent_et_a_jour(advisor):
    from orion.hardware import systeme as s
    from orion.hardware import pilotes_nvidia as nv
    d = donnees_factices()
    etat = s.interpreter(d)
    hw = machine_factice()
    assert hw.gpu.vendor == "nvidia" and "4070" in hw.gpu.name
    hw.gpu.driver_version = "551.86"
    dern = nv.interpreter({"nvidia": {"40": {"version": "617.42", "date": "2026-10-06", "nom": "GeForce Game Ready Driver",
                                             "details": "https://www.nvidia.com/en-us/drivers/details/280103/"}}})
    c = advisor.conseils_pilotes(etat, hw, AUJOURDHUI, maj=None, nvidia=dern)
    par_titre = {a.title: a for a in c}
    a = par_titre["Pilote graphique : 617.42 disponible"]
    assert a.level == "conseil" and a.action_url == "https://www.nvidia.com/en-us/drivers/details/280103/"
    assert "551.86" in a.detail and "617.42" in a.detail and "serie 40" in a.preuve
    assert "Pilote graphique ancien" not in par_titre          # un seul verdict sur la carte
    # a jour : verdict « ok », et plus de « pilote graphique ancien » fonde sur la date
    hw.gpu.driver_version = "617.42"
    c2 = advisor.conseils_pilotes(etat, hw, AUJOURDHUI, maj=None, nvidia=dern)
    t2 = {a.title: a for a in c2}
    assert "Pilote graphique a jour (617.42)" in t2 and t2["Pilote graphique a jour (617.42)"].level == "ok"
    assert "Pilote graphique ancien" not in t2
    # serie inconnue du service : on retombe sur le jugement par la date
    c3 = advisor.conseils_pilotes(etat, hw, AUJOURDHUI, maj=None, nvidia={})
    assert "Pilote graphique ancien" in {a.title for a in c3}


# ----------------------------------------------------------------------
# Releve reel : HP EliteDesk 800 G4 WKS TWR de l'auteur (8 octobre 2026)
# ----------------------------------------------------------------------

def test_elitedesk_releve_reel_et_windows_update_vide(advisor):
    """Ce que les deux fichiers d'essai de l'auteur ont donne : identifiants
    materiels presents, Windows Update joignable mais sans pilote facultatif
    (15 s), et deux faux « pilotes audio » (le son HDMI d'Intel sous son nom
    francais, le peripherique logiciel AMD) qui ne doivent pas ressortir."""
    from orion.hardware import systeme as s
    from orion.hardware import maj_pilotes as wu

    def h(nom, classe, version, date, fournisseur, id_, fabricant=""):
        return dict(_p(nom, classe, version, date, fournisseur, fabricant), HardwareID=id_,
                    DeviceID=id_ + "\\3&11583659&0&E0")
    d = donnees_factices(
        pc={"fabricant": "HP", "modele": "HP EliteDesk 800 G4 WKS TWR", "type": 1,
            "pagination_auto": True, "sku": "4RX11ET#ABF"},
        carte_mere={"fabricant": "HP", "modele": "83E0"}, boitier=[3], batteries=0,
        pilotes=[
            h("Intel(R) Ethernet Connection (7) I219-LM", "NET", "12.19.2.62", "2024-07-18", "Intel",
              "PCI\\VEN_8086&DEV_15BB&SUBSYS_83E0103C&REV_10"),
            h("Intel(R) SMBus - A323", "SYSTEM", "10.1.16.7", "1968-07-18", "INTEL",
              "PCI\\VEN_8086&DEV_A323&SUBSYS_83E0103C&REV_10"),
            h("Son Intel(R) pour écrans", "MEDIA", "10.26.0.4", "2018-11-20", "Intel(R) Corporation",
              "HDAUDIO\\FUNC_01&VEN_8086&DEV_280B&SUBSYS_80860101&REV_1000"),
            h("Synaptics HD Audio", "MEDIA", "8.65.319.200", "2022-06-16", "Synaptics",
              "HDAUDIO\\FUNC_01&VEN_14F1&DEV_5098&SUBSYS_103C83E0&REV_1001"),
            h("AMD High Definition Audio Device", "MEDIA", "10.0.1.30", "2024-04-29",
              "Advanced Micro Devices", "HDAUDIO\\FUNC_01&VEN_1002&DEV_AA01&SUBSYS_00AA0100&REV_1007"),
            h("AMD Streaming Audio Device", "MEDIA", "1.0.0.9", "2024-04-29", "AMD",
              "Root\\AMDSAFD&FUN_01&REV_01"),
            h("Intel(R) 300 Series Chipset Family SATA AHCI Controller", "HDC", "17.11.0.1000",
              "2021-09-30", "Intel", "PCI\\VEN_8086&DEV_A352&SUBSYS_83E0103C&REV_10"),
            h("Standard NVM Express Controller", "SCSIADAPTER", "10.0.26100.9549", "2006-06-21",
              "Microsoft", "PCI\\VEN_15B7&DEV_5002&SUBSYS_500215B7&REV_01"),
            h("Intel(R) UHD Graphics 630", "DISPLAY", "30.0.101.1339", "2022-01-21", "Intel Corporation",
              "PCI\\VEN_8086&DEV_3E92&SUBSYS_83E0103C&REV_00"),
            h("Radeon(TM) RX 580", "DISPLAY", "31.0.21925.1001", "2026-05-20",
              "Advanced Micro Devices, Inc.", "PCI\\VEN_1002&DEV_67DF&SUBSYS_E3871DA2&REV_E7"),
            h("USB xHCI Compliant Host Controller", "USB", "10.0.26100.9549", "2026-09-17",
              "Microsoft", "PCI\\VEN_8086&DEV_A36D&SUBSYS_83E0103C&REV_10"),
        ])
    etat = s.interpreter(d)
    assert etat.pc == ("HP", "HP EliteDesk 800 G4 WKS TWR") and etat.pc_sku == "4RX11ET#ABF"
    assert etat.boitier == "bureau" and advisor._pc_de_marque(etat)
    noms = {p.nom: p for p in etat.pilotes}
    # les codecs HDMI (Intel 8086, AMD 1002) et le peripherique logiciel AMD (bus ROOT) sont ecartes
    assert "Son Intel(R) pour écrans" not in noms and "AMD High Definition Audio Device" not in noms
    assert "AMD Streaming Audio Device" not in noms and "Synaptics HD Audio" in noms
    assert noms["Intel(R) Ethernet Connection (7) I219-LM"].cle_materiel == "PCI\\VEN_8086&DEV_15BB"
    assert noms["Synaptics HD Audio"].cle_materiel == "HDAUDIO\\VEN_14F1&DEV_5098"

    maj = wu.interpreter({"pilotes": [], "duree_s": 15}, lu=1_800_000_000)
    assert not maj.erreur and maj.pilotes == []
    c = advisor.conseils_pilotes(etat, machine_factice(), AUJOURDHUI, maj=maj, nvidia={})
    par_titre = {a.title: a for a in c}
    # un seul conseil audio (Synaptics), vers la page HP du modele, Windows Update dit « rien »
    audio = par_titre["Pilote audio ancien"]
    assert "Synaptics HD Audio" in audio.detail and "8.65.319.200" in audio.detail
    assert "Windows Update n'en propose pas de plus recent" in audio.detail
    assert "support.hp.com" in audio.action_url and "4RX11ET#ABF" in audio.detail
    assert audio.action == "Pilotes HP pour ce modele"
    assert sum(1 for a in c if a.title == "Pilote audio ancien") == 1
    assert "Pilote reseau ancien" in par_titre and "Pilote de stockage ancien" in par_titre, sorted(par_titre)
    # la date factice Intel (1968) ne fait pas un conseil chipset ; rien d'autre dans Windows Update
    assert "Pilotes du chipset anciens" not in par_titre
    assert not any("facultatif(s) dans Windows Update" in t for t in par_titre)
    assert not any("plus recent dans Windows Update" in t for t in par_titre)


def test_tour_msi_releve_reel_carte_reseau_asus_et_rtx_3080(advisor):
    """Second relevé de l'auteur (8 octobre 2026) : tour montee soi-meme sur
    carte mere MSI MS-7B51 (sku « Default string »), deux cartes reseau (Intel
    soudee, ASUS 10G ajoutee), RTX 3080, Windows Update sans rien (38 s)."""
    from orion.hardware import systeme as s
    from orion.hardware import maj_pilotes as wu
    from orion.hardware import pilotes_nvidia as nv
    from orion.ui.widgets.advice_card import cle
    from orion.core.models import GPUInfo

    def h(nom, classe, version, date, fournisseur, id_, fabricant=""):
        return dict(_p(nom, classe, version, date, fournisseur, fabricant), HardwareID=id_)
    d = donnees_factices(
        pc={"fabricant": "Micro-Star International Co., Ltd.", "modele": "MS-7B51",
            "sku": "Default string", "type": 1, "pagination_auto": True},
        carte_mere={"fabricant": "Micro-Star International Co., Ltd.", "modele": "MPG Z390 GAMING EDGE AC (MS-7B51)"},
        boitier=[3], batteries=0,
        pilotes=[
            h("Intel(R) Ethernet Connection (7) I219-V", "NET", "12.19.2.45", "2022-01-30", "Intel",
              "PCI\\VEN_8086&DEV_15BC&SUBSYS_7B511462&REV_10"),
            h("ASUS XG-C100C 10G PCI-E Network Adapter", "NET", "3.1.7.0", "2022-02-06", "Marvell",
              "PCI\\VEN_1D6A&DEV_07B1&SUBSYS_87411043&REV_02"),
            h("Realtek High Definition Audio", "MEDIA", "6.0.10007.1", "2026-06-23",
              "Realtek Semiconductor Corp.", "HDAUDIO\\FUNC_01&VEN_10EC&DEV_0892&SUBSYS_1462EB51&REV_1003"),
            h("NVIDIA High Definition Audio", "MEDIA", "1.4.6.3", "2026-07-23", "NVIDIA Corporation",
              "HDAUDIO\\FUNC_01&VEN_10DE&DEV_009A&SUBSYS_196E136B&REV_1001"),
            h("NVIDIA GeForce RTX 3080", "DISPLAY", "32.0.16.1692", "2026-04-09", "NVIDIA",
              "PCI\\VEN_10DE&DEV_2206&SUBSYS_136B196E&REV_A1"),
            h("Intel(R) Management Engine Interface #1", "SYSTEM", "2131.1.4.0", "2021-07-27", "Intel",
              "PCI\\VEN_8086&DEV_A360&SUBSYS_7B511462&REV_10"),
            h("Intel(R) SMBus - A323", "SYSTEM", "10.1.16.7", "1968-07-18", "INTEL",
              "PCI\\VEN_8086&DEV_A323&SUBSYS_7B511462&REV_10"),
            h("Standard NVM Express Controller", "SCSIADAPTER", "10.0.26100.9549", "2006-06-21",
              "Microsoft", "PCI\\VEN_1987&DEV_5012&SUBSYS_50121987&REV_01"),
            h("USB Audio Device", "MEDIA", "10.0.26100.9457", "2026-12-09", "Microsoft",
              "USB\\VID_1038&PID_12E0&REV_0130&MI_00"),
            h("Meta Virtual Monitor", "DISPLAY", "15.52.32.370", "2026-04-23", "Meta Inc.",
              "Root\\MetaVirtualScreenDriver"),
        ])
    etat = s.interpreter(d)
    assert etat.pc_sku == "" and not advisor._pc_de_marque(etat)        # « Default string » n'est pas un numero
    noms = {p.nom: p for p in etat.pilotes}
    assert "NVIDIA High Definition Audio" not in noms and "Meta Virtual Monitor" not in noms
    assert noms["ASUS XG-C100C 10G PCI-E Network Adapter"].fabricant_carte == "1043"
    assert noms["Intel(R) Ethernet Connection (7) I219-V"].fabricant_carte == "1462"
    gpu = GPUInfo(name="NVIDIA GeForce RTX 3080", vendor="nvidia", vram_mb=10240,
                  driver_version="32.0.16.1692", driver_date="2026-04-09")
    assert nv.version_installee(gpu) == "616.92" and nv.serie(gpu.name) == "30"
    hw = machine_factice(); hw.gpus = [gpu]
    maj = wu.interpreter({"pilotes": [], "duree_s": 38}, lu=1_800_000_000)
    dern = {"30": nv.Derniere(version="617.42", date="2026-10-06", nom="GeForce Game Ready Driver",
                              details="https://www.nvidia.com/fr-fr/drivers/details/123/")}
    c = advisor.conseils_pilotes(etat, hw, AUJOURDHUI, maj=maj, nvidia=dern)
    par_titre = {a.title: a for a in c}
    # Retour de l'auteur (8 octobre) : la carte Intel soudee sur la carte mere
    # MSI renvoyait vers l'assistant Intel, la carte ASUS vers le centre de
    # telechargement general d'ASUS. Maintenant : le pack Ethernet d'Intel
    # (derniere version de la famille), et la page ASUS de la XG-C100C.
    intel = par_titre["Pilote reseau ancien : Intel"]
    asus = par_titre["Pilote reseau ancien : ASUS"]
    assert intel.action == "Pilotes reseau Intel (pack complet)"
    assert intel.action_url.endswith("/15084/intel-ethernet-adapter-complete-driver-pack.html")
    assert "MPG Z390 GAMING EDGE AC" in intel.detail and "page support de MSI" in intel.detail
    assert asus.action == "Pilotes ASUS XG-C100C"
    assert asus.action_url == "https://www.asus.com/supportonly/xg-c100c/helpdesk_download/"
    assert "carte ASUS ajoutee dans le PC" in asus.detail and "pour le modele XG-C100C" in asus.detail
    assert "intel-driver-support-assistant" not in intel.action_url + asus.action_url
    chip = par_titre["Pilotes du chipset anciens"]
    assert chip.action == "Pilotes du chipset Intel (INF)" and chip.action_url.endswith("/19347/chipset-inf-utility.html")
    assert cle(intel) != cle(asus)                      # masquer l'un ne masque pas l'autre
    # la RTX 3080 : version NVIDIA lue depuis la version Windows, et la derniere de la serie 30
    g = par_titre["Pilote graphique : 617.42 disponible"]
    assert "616.92" in g.detail and g.action_url.startswith("https://www.nvidia.com/")
    assert "Pilote graphique ancien" not in par_titre
    # chipset : juge sur le plus recent date (MEI 2021), pas sur la date factice Intel de 1968
    assert "2131.1.4.0" in par_titre["Pilotes du chipset anciens"].detail
    # un seul groupe audio : le titre reste simple ; rien pour le Realtek de juin 2026
    assert not any(t.startswith("Pilote audio ancien") for t in par_titre)


def test_tri_par_bus_et_base_des_fabricants(advisor):
    """Le bus de l'identifiant d'instance tranche materiel / logiciel, quel
    que soit le nom ; la base publique pci.ids / usb.ids nomme n'importe quel
    fabricant de carte ; une puce Intel sur un portable HP n'est pas une
    « carte Intel ajoutee »."""
    from orion.hardware import systeme as s
    assert s.bus("ROOT\\MEDIA\\0003") == "ROOT" and s.bus("PCI\\VEN_8086&DEV_15BC\\3&11583659&0&FE") == "PCI"
    assert s.bus("{8e7bd593-6e6c-4c52-86a6-77175494dd8e}\\MsVhdHba") == "{8E7BD593-6E6C-4C52-86A6-77175494DD8E}"
    assert s.bus("") == "" and s.bus("XvddRootDevice") == ""
    # logiciel malgre un nom et un HardwareID qui se disent USB (NVIDIA Virtual Audio)
    assert s.categorie("MEDIA", "NVIDIA Virtual Audio Device (Wave Extensible) (WDM)",
                       "USB\\VID_0955&PID_9000", "ROOT\\UNNAMED_DEVICE\\0000") == ""
    assert s.categorie("NET", "Wintun Userspace Tunnel", "Wintun", "SWD\\WINTUN\\{ABC}") == ""
    assert s.categorie("DISPLAY", "Meta Virtual Monitor", "Root\\MetaVirtualScreenDriver", "ROOT\\DISPLAY\\0001") == ""
    # materiel malgre un nom qui contient un mot de la liste des virtuels
    assert s.categorie("NET", "Intel(R) Ethernet Virtual Function 700 Series", "PCI\\VEN_8086&DEV_154C",
                       "PCI\\VEN_8086&DEV_154C&SUBSYS_00008086\\4&1&0&00E0") == "reseau"
    # sans identifiant (ancien releve), la liste de noms sert encore
    assert s.categorie("NET", "Microsoft Wi-Fi Direct Virtual Adapter") == ""
    assert s.categorie("NET", "Intel(R) Wi-Fi 6 AX201 160MHz") == "reseau"
    # base des fabricants et marque par identifiant
    assert s.nom_fabricant("pci", "1043") == "ASUS" and s.nom_fabricant("usb", "2357") == "TP-Link"
    assert s.nom_fabricant("pci", "1FC9") == "Tehuti Networks" and s.nom_fabricant("pci", "ZZZZ") == ""
    assert s.fabricant_carte("USB\\VID_2357&PID_0138&REV_0200") == "2357"
    assert s.marque("Carte reseau", identifiant="PCI\\VEN_10EC&DEV_8125&SUBSYS_86771043") == "realtek"
    assert s.marque("Killer E3100G", identifiant="PCI\\VEN_1A56&DEV_1F1F") == "intel"
    assert s.marque("Realtek(R) Audio") == "realtek"                          # sans identifiant : le nom

    def h(nom, classe, version, date, fournisseur, hid, did):
        return dict(_p(nom, classe, version, date, fournisseur), HardwareID=hid, DeviceID=did)
    d = donnees_factices(pc={"fabricant": "HP", "modele": "HP Pavilion Gaming Laptop 15-ec2xxx", "type": 2,
                             "pagination_auto": True, "sku": "4A0M5EA#ABF"},
                         carte_mere={"fabricant": "HP", "modele": "88DD"}, boitier=[10], batteries=1,
                         pilotes=[
        h("Intel(R) Wireless Bluetooth(R)", "BLUETOOTH", "22.40.0.4", "2022-04-20", "Intel Corporation",
          "USB\\VID_8087&PID_0026&REV_0002", "USB\\VID_8087&PID_0026\\5&2A3&0&14"),
        h("TP-Link Wireless USB Adapter", "NET", "1030.38.712.2019", "2019-07-12", "TP-Link",
          "USB\\VID_2357&PID_0138&REV_0200", "USB\\VID_2357&PID_0138\\5&2A3&0&3"),
        h("Realtek(R) Audio", "MEDIA", "6.0.9239.1", "2021-09-14", "Realtek Semiconductor Corp.",
          "HDAUDIO\\FUNC_01&VEN_10EC&DEV_0256&SUBSYS_103C88DD", "HDAUDIO\\FUNC_01&VEN_10EC&DEV_0256&SUBSYS_103C88DD\\4&1&0&0001"),
    ])
    etat = s.interpreter(d)
    assert etat.boitier == "portable"
    bt, tp, rt = etat.pilotes
    assert bt.bus == "USB" and bt.fabricant_carte == "8087" and advisor._carte_ajoutee(bt, etat) == ("", "", "")
    # « TP-Link Wireless USB Adapter » ne donne pas de modele : la page generale de TP-Link
    assert advisor._carte_ajoutee(tp, etat) == ("TP-Link", "https://www.tp-link.com/fr/support/download/", "")
    assert advisor._carte_ajoutee(rt, etat) == ("", "", "")
    c = advisor.conseils_pilotes(etat, machine_factice(), AUJOURDHUI, nvidia={})
    par_titre = {a.title: a for a in c}
    assert "tp-link.com" in par_titre["Pilote reseau ancien"].action_url
    assert "un appareil TP-Link ajoute dans le PC" in par_titre["Pilote reseau ancien"].detail
    assert "support.hp.com" in par_titre["Pilote Bluetooth ancien"].action_url      # puce Intel du portable HP
    assert "support.hp.com" in par_titre["Pilote audio ancien"].action_url


def test_barrettes_optimisees_amd_sur_carte_intel(advisor):
    """10 octobre (PC de l'auteur : Core i9-9900K, Z390, kit DDR4 « optimise
    AMD ») : pas de « activez XMP » sans nuance, le conseil le dit."""
    from orion.hardware import systeme as s
    b = dict(donnees_factices()["barrettes"][0], reference="CMK16GX4M2Z3200C16", vitesse=3200,
             configuree=2666, type=26)
    hw = machine_factice(s.interpreter(donnees_factices(barrettes=[b, dict(b, emplacement="DIMM_B2")])))
    hw.cpu_name = "Intel(R) Core(TM) i9-9900K CPU @ 3.60GHz"
    c = next(a for a in advisor.conseils_materiel(hw.systeme, hw) if a.title.startswith("Memoire a"))
    assert "optimisees AMD" in c.detail and "a la main" in c.detail and "A-XMP" in c.detail
    b5 = dict(b, reference="F5-6000J3038F16GX2-TZ5NR", vitesse=6000, configuree=4800, type=34)
    hw = machine_factice(s.interpreter(donnees_factices(barrettes=[b5, dict(b5, emplacement="DIMM_B2")])))
    hw.cpu_name = "Intel(R) Core(TM) i7-14700K"
    c = next(a for a in advisor.conseils_materiel(hw.systeme, hw) if a.title.startswith("Memoire a"))
    assert "EXPO" in c.detail and "ne lit pas ce profil" in c.detail


def test_jeu_ankama_desinstalle_par_son_lanceur(monkeypatch):
    """10 octobre (capture de l'auteur) : Dofus Retro ouvrait son dossier
    « a vous de le supprimer » ; l'Ankama Launcher s'en charge."""
    from orion import storage
    from orion.core.models import Game
    from orion.plugins.scanners import ankama
    monkeypatch.setattr(ankama, "lanceur", lambda: r"C:\Users\x\AppData\Local\Programs\zaap\Ankama Launcher.exe")
    cmd, desc = storage.uninstall_command(Game(title="Dofus Retro", source="ankama", install_dir=r"C:\jeux\retro"))
    assert cmd.endswith('Ankama Launcher.exe"') and "Ankama Launcher" in desc and "supprimer" not in desc
