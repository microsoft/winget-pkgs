"""Pays, devise et langue des donnees : un Americain voit des dollars."""
from orion.core import region
from orion.core.config import CONFIG


def _regler(langue, pays):
    CONFIG.set("langue", langue, save=False)
    CONFIG.set("market.country", pays, save=False)


def test_prix_selon_le_pays_et_la_langue():
    try:
        _regler("fr", "FR")
        assert region.devise() == "EUR" and region.prix(59.99) == "59,99 €"
        assert region.prix(1234.5) == "1 234,50 €" and region.langue_steam() == "french"
        assert region.prix(5, decimales=False) == "5 €"
        _regler("en", "US")
        assert region.devise() == "USD" and region.prix(59.99) == "$59.99"
        assert region.prix(1234.5) == "$1,234.50" and region.langue_steam() == "english"
        assert region.cc() == "us" and region.locale_gog() == "en-US"
        _regler("en", "GB")
        assert region.prix(9.5) == "£9.50"
        _regler("fr", "CH")
        assert region.prix(9.5) == "9,50 CHF"
        _regler("fr", "CA")
        assert region.prix(9.5) == "9,50 $ CA"
        # la devise donnee par la boutique l'emporte sur celle du pays
        assert region.prix(9.5, "USD") == "9,50 $"
        CONFIG.set("market.country", "n'importe quoi", save=False)
        assert region.pays() == "FR"
    finally:
        _regler("fr", "FR")


def test_detection_au_premier_lancement():
    assert region.detecter("fr-FR") == ("fr", "FR")
    assert region.detecter("en-US") == ("en", "US")
    assert region.detecter("en-GB") == ("en", "GB")
    assert region.detecter("fr-CA") == ("fr", "CA")
    assert region.detecter("fr-SN") == ("fr", "FR")      # francophone hors liste
    assert region.detecter("pt-BR") == ("en", "US")      # region inconnue
    assert region.detecter("") == ("en", "US")
    assert region.detecter("de_DE") == ("en", "DE")


def test_installation_existante_jamais_modifiee(monkeypatch):
    try:
        _regler("fr", "FR")
        CONFIG.set("region_detectee", False, save=False)
        monkeypatch.setattr(CONFIG, "nouvelle", False, raising=False)
        monkeypatch.setattr(region, "_locale_windows", lambda: "en-US")
        assert region.premier_lancement() is False
        assert CONFIG.get("langue") == "fr" and CONFIG.get("market.country") == "FR"
        # tout premier lancement : Windows decide
        CONFIG.set("region_detectee", False, save=False)
        monkeypatch.setattr(CONFIG, "nouvelle", True, raising=False)
        assert region.premier_lancement() is True
        assert CONFIG.get("langue") == "en" and CONFIG.get("market.country") == "US"
        assert region.premier_lancement() is False        # une seule fois
    finally:
        _regler("fr", "FR")
        CONFIG.set("region_detectee", False, save=False)
