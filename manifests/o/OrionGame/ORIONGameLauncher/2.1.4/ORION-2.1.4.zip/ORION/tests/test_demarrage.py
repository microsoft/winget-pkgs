"""Lancer ORION au demarrage de Windows (2.1.2) : cle « Run » de
l'utilisateur pour la version de l'installateur, tache de demarrage pour le
paquet du Store, case en tete des Reglages et dans l'installateur."""
from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path
from xml.dom import minidom

import pytest

from orion import demarrage as d

RACINE = Path(__file__).resolve().parents[1]


class FauxRegistre:
    def __init__(self) -> None:
        self.valeurs: dict[tuple[str, str], object] = {}

    def lire(self, cle, nom):
        return self.valeurs.get((cle, nom))

    def ecrire(self, cle, nom, valeur):
        self.valeurs[(cle, nom)] = valeur

    def effacer(self, cle, nom):
        self.valeurs.pop((cle, nom), None)


@pytest.fixture
def reg(monkeypatch):
    faux = FauxRegistre()
    monkeypatch.setattr(d, "registre", faux)
    return faux


@pytest.fixture
def installe(monkeypatch, tmp_path):
    """ORION compile et installe (hors Store)."""
    exe = tmp_path / "ORION" / "ORION.exe"
    exe.parent.mkdir()
    exe.write_bytes(b"")
    monkeypatch.setattr(d, "disponible", lambda: True)
    monkeypatch.setattr(sys, "executable", str(exe))
    return exe


@pytest.fixture
def app():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


# ---------------------------------------------------------------------------
# Cle « Run » (installateur du site)
# ---------------------------------------------------------------------------
def test_commande_entre_guillemets_avec_l_argument(tmp_path):
    exe = tmp_path / "Mes Programmes" / "ORION.exe"
    assert d.commande(exe) == f'"{exe}" --demarrage-windows'


def test_activer_puis_retirer(reg, tmp_path):
    reg.ecrire(d.APPROUVE, d.NOM, bytes([3, 0, 0, 0]))       # coupe autrefois
    d.activer_cle(tmp_path / "ORION.exe")
    assert reg.lire(d.RUN, d.NOM) == d.commande(tmp_path / "ORION.exe")
    assert reg.lire(d.APPROUVE, d.NOM) is None                  # la demande l'emporte
    d.retirer_cle()
    assert reg.valeurs == {}


def test_coupure_du_gestionnaire_des_taches(reg):
    assert not d.coupe_dans_le_gestionnaire()
    for octet, coupe in ((2, False), (6, False), (3, True), (7, True)):
        reg.ecrire(d.APPROUVE, d.NOM, bytes([octet]) + bytes(11))
        assert d.coupe_dans_le_gestionnaire() is coupe


def test_une_mise_a_jour_garde_le_choix(reg, tmp_path):
    assert not d.suivre_installation(tmp_path / "neuf" / "ORION.exe")
    assert reg.valeurs == {}                       # jamais inscrit d'office
    reg.ecrire(d.RUN, d.NOM, d.commande(tmp_path / "ancien" / "ORION.exe"))
    reg.ecrire(d.APPROUVE, d.NOM, bytes([3]) + bytes(11))
    assert d.suivre_installation(tmp_path / "neuf" / "ORION.exe")
    assert "neuf" in reg.lire(d.RUN, d.NOM)
    assert d.coupe_dans_le_gestionnaire()         # la coupure de l'utilisateur reste


def test_etat_et_reglage(reg, installe):
    assert d.etat() == d.Etat(False)
    ok, etat = d.regler(True)
    assert ok and etat.actif
    assert reg.lire(d.RUN, d.NOM) == d.commande(installe)
    reg.ecrire(d.APPROUVE, d.NOM, bytes([3]) + bytes(11))     # coupe dans le Gestionnaire
    assert d.etat() == d.Etat(False)
    assert d.regler(True) == (True, d.Etat(True))              # la case le rallume
    ok, etat = d.regler(False)
    assert ok and not etat.actif
    # coupe, mais toujours dans « Applications de demarrage » (Desactive)
    assert reg.lire(d.RUN, d.NOM) == d.commande(installe)
    assert d.coupe_dans_le_gestionnaire()


def test_marque_de_coupure_comme_le_gestionnaire_des_taches(reg, tmp_path):
    assert d.marque_coupee(0).hex() == "0300000000803ed5deb19d01"     # 1er janvier 1970
    marque = d.marque_coupee()
    assert len(marque) == 12 and marque[0] == 3
    d.couper_cle(tmp_path / "ORION.exe")
    assert d.inscrit() and d.coupe_dans_le_gestionnaire()
    d.activer_cle(tmp_path / "ORION.exe")
    assert d.inscrit() and not d.coupe_dans_le_gestionnaire()


def test_depuis_les_sources_la_case_est_grisee(monkeypatch):
    monkeypatch.setattr(d, "disponible", lambda: False)
    e = d.etat()
    assert not e.actif and not e.modifiable and e.note == d.HORS_INSTALLATION
    assert d.regler(True)[0] is False


# ---------------------------------------------------------------------------
# Paquet du Microsoft Store : tache de demarrage
# ---------------------------------------------------------------------------
def test_etats_de_la_tache_du_store():
    assert d.etat_store(d.ACTIVEE) == d.Etat(True)
    assert d.etat_store(d.DESACTIVEE) == d.Etat(False)
    coupee = d.etat_store(d.COUPEE_PAR_L_UTILISATEUR)
    assert not coupee.actif and coupee.parametres and "Parametres" in coupee.note
    assert not d.etat_store(d.INTERDITE).modifiable
    imposee = d.etat_store(d.IMPOSEE)
    assert imposee.actif and not imposee.modifiable


def test_le_store_passe_par_la_tache_jamais_par_la_cle(reg, installe, monkeypatch):
    (installe.parent / d.MARQUE_STORE).write_text("x")
    appels = []

    def tache(action="lire"):
        appels.append(action)
        return {"lire": d.DESACTIVEE, "allumer": d.ACTIVEE, "couper": d.DESACTIVEE}[action]
    monkeypatch.setattr(d, "_tache_store", tache)
    assert d.etat() == d.Etat(False)
    assert d.regler(True) == (True, d.Etat(True))
    assert d.regler(False)[0] is True
    assert appels == ["lire", "allumer", "couper"]
    assert reg.valeurs == {}          # la cle « Run » d'un paquet MSIX ne sert a rien


def test_store_coupe_dans_windows_renvoie_aux_parametres(installe, monkeypatch):
    (installe.parent / d.MARQUE_STORE).write_text("x")
    monkeypatch.setattr(d, "_tache_store", lambda action="lire": d.COUPEE_PAR_L_UTILISATEUR)
    ok, etat = d.regler(True)
    assert not ok and etat.parametres and not etat.actif


def test_store_sans_reponse_de_windows(installe, monkeypatch):
    (installe.parent / d.MARQUE_STORE).write_text("x")

    def panne(action="lire"):
        raise ModuleNotFoundError("winrt")
    monkeypatch.setattr(d, "_tache_store", panne)
    ok, etat = d.regler(True)
    assert not ok and not etat.actif and etat.parametres and etat.note == d.SANS_API


def test_temoin_du_store_identique_a_celui_des_mises_a_jour():
    from orion import maj
    assert d.MARQUE_STORE == maj.MARQUE_STORE


def test_appel_windows_hors_du_fil_de_l_interface():
    import threading
    principal = threading.get_ident()
    assert d._dans_un_fil(lambda: threading.get_ident()) != principal
    with pytest.raises(ValueError):
        d._dans_un_fil(lambda: (_ for _ in ()).throw(ValueError("x")))


# ---------------------------------------------------------------------------
# Lance par Windows
# ---------------------------------------------------------------------------
def test_lance_par_windows(monkeypatch):
    assert d.lance_par_windows(["ORION.exe", d.ARGUMENT])
    assert not d.lance_par_windows(["ORION.exe"])
    assert d.interroger(["ORION.exe", d.ARGUMENT])() is True
    assert d.interroger(["ORION.exe"])(0.1) is False


def test_rappel_garde_la_fenetre_en_grand(app):
    from PySide6.QtCore import Qt
    from PySide6.QtWidgets import QWidget

    from orion.app import rappeler
    w = QWidget()
    w.setWindowState(Qt.WindowState.WindowMaximized | Qt.WindowState.WindowMinimized)
    rappeler(w)
    etat = w.windowState()
    assert etat & Qt.WindowState.WindowMaximized
    assert not etat & Qt.WindowState.WindowMinimized
    w.deleteLater()


def test_ouverture_reduite_sans_ecran_de_demarrage():
    source = (RACINE / "orion" / "app.py").read_text(encoding="utf-8")
    assert "and not par_windows" in source            # pas d'ecran de demarrage
    assert "window.showMinimized()" in source


# ---------------------------------------------------------------------------
# Installateur
# ---------------------------------------------------------------------------
def test_installation_regle_le_demarrage(reg, monkeypatch, tmp_path):
    from orion.deploiement import installation as inst
    monkeypatch.setattr(inst, "is_windows", lambda: True)
    exe = tmp_path / "ORION.exe"
    inst.regler_demarrage(exe, None)          # mise a jour sans choix connu : allume
    assert reg.lire(d.RUN, d.NOM) == d.commande(exe) and not d.coupe_dans_le_gestionnaire()
    inst.regler_demarrage(exe, False)         # case decochee : coupe, toujours liste
    assert d.inscrit() and d.coupe_dans_le_gestionnaire()
    inst.regler_demarrage(tmp_path / "ailleurs" / "ORION.exe", None)     # mise a jour
    assert "ailleurs" in reg.lire(d.RUN, d.NOM)
    assert d.coupe_dans_le_gestionnaire()     # le « non » reste un non
    inst.regler_demarrage(exe, True)
    assert d.inscrit() and not d.coupe_dans_le_gestionnaire()
    inst.regler_demarrage(None, False)        # desinstallation : tout part
    assert reg.valeurs == {}


def test_install_transmet_le_choix(monkeypatch, tmp_path):
    from orion.deploiement import installation as inst
    vus = []
    monkeypatch.setattr(inst, "regler_demarrage", lambda exe, voulu: vus.append((exe, voulu)))
    monkeypatch.setattr(inst, "make_shortcut", lambda *a, **k: None)
    monkeypatch.setattr(inst, "register_uninstall", lambda *a, **k: True)
    source = tmp_path / "programme"
    source.mkdir()
    (source / inst.EXE_NAME).write_bytes(b"x")
    cible = tmp_path / "Programs" / "ORION"
    assert inst.install(source, cible, desktop_shortcut=False, demarrage=True)[0]
    assert inst.install(source, cible, desktop_shortcut=False)[0]
    assert vus == [(cible / inst.EXE_NAME, True), (cible / inst.EXE_NAME, None)]


def test_case_de_l_installateur(app, monkeypatch):
    import inspect

    from orion.deploiement import installation as inst
    from orion.deploiement import interface as itf
    monkeypatch.setattr(inst, "is_installed", lambda: False)
    classe = [c for _n, c in inspect.getmembers(itf, inspect.isclass)
              if c.__module__ == itf.__name__ and hasattr(c, "_corps_installation")][0]
    w = classe("installer")
    assert w.demarrage.text() == "Lancer ORION au démarrage de Windows"
    assert w.demarrage.isChecked()                     # cochee d'office (12 octobre)
    assert "ni démarrage automatique" not in inspect.getsource(itf)
    source = inspect.getsource(classe._lancer)
    assert "demarrage=self.demarrage.isChecked()" in source
    w.deleteLater()


# ---------------------------------------------------------------------------
# Reglages
# ---------------------------------------------------------------------------
def test_case_en_tete_des_reglages(app):
    from orion.ui.views.settings_view import DEMARRAGE, SettingsView
    vue = SettingsView()
    case = vue.cb_demarrage
    assert case.text() == DEMARRAGE
    # hors des rubriques (et de leur defilement) : en tete, toujours visible
    assert not any(case in p.findChildren(type(case))
                   for blocs in vue._panneaux.values() for p in blocs)
    assert not vue.scroll.widget().isAncestorOf(case)
    vue._poser_demarrage(d.Etat(True))
    assert case.isChecked() and case.isEnabled()
    vue._poser_demarrage(d.Etat(False, False, d.HORS_INSTALLATION))
    assert not case.isChecked() and not case.isEnabled()
    assert "installee" in case.toolTip() or "installée" in case.toolTip()
    vue.deleteLater()


def test_cocher_la_case_regle_windows(app, monkeypatch):
    from orion.ui.views.settings_view import SettingsView
    demandes = []

    def regler(actif):
        demandes.append(actif)
        return True, d.Etat(actif)
    monkeypatch.setattr(d, "regler", regler)
    vue = SettingsView()
    vue._poser_demarrage(d.Etat(False))
    vue.cb_demarrage.setChecked(True)
    import time
    fin = time.time() + 5
    while not demandes or not vue.cb_demarrage.isEnabled():
        app.processEvents()
        if time.time() > fin:
            break
        time.sleep(0.01)
    assert demandes == [True] and vue.cb_demarrage.isChecked()
    vue.deleteLater()


def test_refus_de_windows_explique(app, monkeypatch):
    from orion.ui.views import settings_view as sv
    vue = sv.SettingsView()
    montres = []
    monkeypatch.setattr(vue, "expliquer_demarrage", lambda etat: montres.append(etat))
    vue._demarrage_regle((False, d.etat_store(d.COUPEE_PAR_L_UTILISATEUR)))
    assert montres and montres[0].parametres and not vue.cb_demarrage.isChecked()
    vue.deleteLater()


# ---------------------------------------------------------------------------
# Paquet MSIX, compilation, textes
# ---------------------------------------------------------------------------
def test_manifeste_declare_la_tache_coupee():
    spec = importlib.util.spec_from_file_location(
        "construire_msix", RACINE / "outils" / "msix" / "construire.py")
    msix = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(msix)
    xml = msix.manifeste({"nom_paquet": "1234Sikher.ORION", "editeur": "CN=ABC",
                          "nom_editeur": "Sik"})
    doc = minidom.parseString(xml)
    assert "desktop" in doc.documentElement.getAttribute("IgnorableNamespaces").split()
    ext = doc.getElementsByTagName("desktop:Extension")[0]
    assert ext.getAttribute("Category") == "windows.startupTask"
    assert ext.getAttribute("Executable") == "ORION.exe"
    tache = doc.getElementsByTagName("desktop:StartupTask")[0]
    assert tache.getAttribute("TaskId") == d.TACHE
    assert tache.getAttribute("Enabled") == "true"        # allumee par defaut
    assert ext.parentNode.parentNode.tagName == "Application"


def test_compilation_embarque_winrt_pour_l_application_seulement():
    req = (RACINE / "requirements.txt").read_text(encoding="utf-8")
    for paquet in ("winrt-runtime", "winrt-Windows.Foundation",
                   "winrt-Windows.ApplicationModel", "winrt-Windows.ApplicationModel.Activation"):
        assert any(l.startswith(paquet) and 'sys_platform == "win32"' in l
                   for l in req.splitlines()), paquet
    bat = (RACINE / "CONSTRUIRE-EXE.bat").read_bytes()
    assert b"\r\n" in bat and b"\n" not in bat.replace(b"\r\n", b"")
    texte = bat.decode("ascii")
    application, installateur = texte.split("[2/2]")
    assert "--hidden-import winrt.windows.applicationmodel ^" in application
    assert "--hidden-import winrt.windows.applicationmodel.activation ^" in application
    assert "--exclude-module winrt ^" in installateur


def test_textes_traduits():
    from orion import aide, nouveautes
    from orion.ui.views import settings_view as sv
    textes = [sv.DEMARRAGE, sv.AIDE_DEMARRAGE, d.COUPEE_DANS_WINDOWS, d.INTERDIT, d.IMPOSE,
              d.HORS_INSTALLATION, d.SANS_API, "Ouvrir les Parametres de Windows",
              "Windows a refuse le changement.",
              "Windows a refuse le changement (detail dans le journal)."]
    textes.append([b for r in aide.RUBRIQUES for a in r.articles for b in a.body
                   if "se lance au demarrage de Windows" in b][0])
    entree = next(e for e in nouveautes.JOURNAL if e["version"] == "2.1.2")
    point = entree["points"][0]
    assert point.startswith("Nouveau : ORION se lance au demarrage de Windows")
    textes.append(point)
    for code in ("fr", "en"):
        exact = json.loads((RACINE / "orion" / "langues" / f"{code}.json")
                           .read_text(encoding="utf-8"))["exact"]
        for texte in textes:
            assert texte in exact, (code, texte[:60])
        assert not any("rien ne demarre avec Windows" in k for k in exact)
    changelog = (RACINE / "CHANGELOG.md").read_text(encoding="utf-8")
    assert "« Lancer ORION au démarrage de Windows »" in changelog.split("## 2.1.1")[0]
