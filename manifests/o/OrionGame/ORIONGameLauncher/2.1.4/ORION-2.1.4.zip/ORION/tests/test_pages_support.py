"""Pages de pilotes precises, construites depuis ce qu'ORION a lu (2.0.2).

Retour de l'auteur (8 octobre, tour MSI) : les pilotes Intel de la carte
mere renvoyaient vers l'assistant Intel, la carte ASUS XG-C100C vers le
centre de telechargement general d'ASUS. Adresses verifiees en ligne le
8 octobre 2026."""
from orion.hardware import pages_support as ps


def test_modele_tire_du_nom_de_l_appareil():
    assert ps.modele_dans_nom("ASUS XG-C100C 10G PCI-E Network Adapter", "ASUS") == "XG-C100C"
    assert ps.modele_dans_nom("ASUS PCE-AX58BT", "ASUSTeK Computer Inc.") == "PCE-AX58BT"
    assert ps.modele_dans_nom("TP-Link Archer T4E", "TP-Link") == "Archer T4E"
    # pas de modele : des mots de famille ou de bus, jamais pris pour un code
    assert ps.modele_dans_nom("TP-Link Wireless USB Adapter", "TP-Link") == ""
    assert ps.modele_dans_nom("Realtek USB GbE Family Controller", "Realtek") == ""
    assert ps.modele_dans_nom("Creative Sound Blaster Z", "Creative") == ""
    assert ps.modele_dans_nom("", "ASUS") == ""


def test_page_d_une_carte_ajoutee():
    assert ps.page_carte("ASUS", "ASUS XG-C100C 10G PCI-E Network Adapter") == (
        "https://www.asus.com/supportonly/xg-c100c/helpdesk_download/", "XG-C100C")
    assert ps.page_carte("TP-Link", "TP-Link Archer T4E") == (
        "https://www.tp-link.com/fr/support/download/archer-t4e/", "Archer T4E")
    assert ps.page_carte("Creative", "Creative Sound Blaster Z") == ("", "")
    assert ps.page_carte("Corsair", "Corsair HS80 RGB") == ("", "HS80")       # modele lu, pas d'adresse par modele


def test_page_du_modele_de_carte_mere_ou_de_pc():
    assert ps.page_modele("Micro-Star International Co., Ltd.", "MPG Z390 GAMING PLUS (MS-7B51)") == (
        "https://www.msi.com/Motherboard/MPG-Z390-GAMING-PLUS/support", "MSI")
    assert ps.page_modele("Micro-Star International Co., Ltd.", "GF63 Thin 11SC", "portable") == (
        "https://www.msi.com/Laptop/GF63-Thin-11SC/support", "MSI")
    assert ps.page_modele("ASUSTeK COMPUTER INC.", "PRIME Z390-A") == (
        "https://www.asus.com/supportonly/prime%20z390-a/helpdesk_download/", "ASUS")
    assert ps.page_modele("Gigabyte Technology Co., Ltd.", "Z390 AORUS PRO") == (
        "https://www.gigabyte.com/Search?kw=Z390%20AORUS%20PRO", "Gigabyte")
    assert ps.page_modele("ASRock", "Z390 Phantom Gaming 4", plateforme="Intel") == (
        "https://www.asrock.com/mb/Intel/Z390%20Phantom%20Gaming%204/index.asp#Download", "ASRock")
    assert ps.page_modele("ASRock", "B550M") == ("", "")                  # plateforme inconnue
    assert ps.page_modele("Dell Inc.", "XPS 15 9530", "portable") == (
        "https://www.dell.com/support/home/fr-fr/product-support/product/xps-15-9530/drivers", "Dell")
    # un code seul (« MS-7B51 », Win32_ComputerSystem), un nom vide ou factice : pas d'adresse inventee
    assert ps.page_modele("Micro-Star International Co., Ltd.", "MS-7B51") == ("", "")
    assert ps.page_modele("To Be Filled By O.E.M.", "To Be Filled By O.E.M.") == ("", "")
    assert ps.page_modele("Hewlett-Packard", "HP EliteDesk 800 G4") == ("", "")   # HP : page generale + catalogue


def test_page_du_fabricant_de_la_puce_par_famille():
    assert ps.page_puce("intel", "reseau", "Intel(R) Ethernet Connection (7) I219-V") == (
        "Pilotes reseau Intel (pack complet)",
        "https://www.intel.com/content/www/us/en/download/15084/intel-ethernet-adapter-complete-driver-pack.html")
    assert ps.page_puce("intel", "reseau", "Intel(R) Wi-Fi 6 AX200 160MHz")[0] == "Pilotes Wi-Fi Intel"
    assert ps.page_puce("intel", "chipset", "")[1].endswith("/19347/chipset-inf-utility.html")
    assert ps.page_puce("intel", "bluetooth", "")[0] == "Pilotes Bluetooth Intel"
    assert ps.page_puce("intel", "stockage", "") == ("", "")                # vient de la carte mere
    assert ps.page_puce("realtek", "audio", "") == ("", "")
    assert ps.page_puce("amd", "chipset", "") == ("", "")


def test_les_conseils_en_anglais_sont_entiers():
    """Chaque phrase d'un conseil pilote a son entree ; les combinaisons
    (fabricant, modele, source) sont traduites phrase par phrase."""
    from orion import i18n
    assert i18n.charger("en")
    try:
        t = ("Intel(R) Ethernet Connection (7) I219-V : version 12.19.2.45 du 30/01/2022, soit environ 4 ans. "
             "Windows Update n'en propose pas de plus recent (verifie le 15/01/2027) : la version a jour, si elle "
             "existe, est chez le fabricant. Intel publie la derniere version de ce pilote pour toute la famille de "
             "la puce ; la version validee pour la carte mere MPG Z390 GAMING PLUS est aussi sur la page support de MSI.")
        en = i18n.traduire(t)
        assert en == ("Intel(R) Ethernet Connection (7) I219-V: version 12.19.2.45 from 30/01/2022, about 4 years old. "
                      "Windows Update offers nothing newer (checked on 15/01/2027): the up-to-date version, if any, is at "
                      "the manufacturer's. Intel publishes the latest version of this driver for the whole chip family; "
                      "the version validated for the MPG Z390 GAMING PLUS motherboard is also on MSI's support page.")
        t2 = ("C'est une carte ASUS ajoutee dans le PC : son pilote se prend sur la page support de ASUS pour le "
              "modele XG-C100C, pas sur celle de la carte mere ni chez le fabricant de la puce.")
        assert i18n.traduire(t2) == ("This ASUS card was added to the PC: its driver comes from ASUS's support page "
                                     "for the XG-C100C model, not from the motherboard's page nor from the chip maker.")
        assert i18n.traduire("Pilotes ASUS XG-C100C") == "ASUS XG-C100C drivers"
        assert i18n.traduire("Pilotes MSI pour MPG Z390 GAMING PLUS (MS-7B51)") == "MSI drivers for MPG Z390 GAMING PLUS (MS-7B51)"
        assert i18n.traduire("Pilote plus recent dans Windows Update : reseau") == "Newer driver in Windows Update: network"
    finally:
        i18n.charger("fr")
        i18n.traduire.cache_clear()
