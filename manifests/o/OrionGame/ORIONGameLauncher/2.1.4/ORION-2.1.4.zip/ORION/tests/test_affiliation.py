"""Liens partenaires du site (orion/affiliation.py, 16 octobre 2026)."""


def test_lien_site_passe_par_le_service():
    """16 octobre : sur le site, les liens partenaires passent par /aller/ du
    service (qui ajoute l'identifiant et compte le clic, robots ecartes) ;
    l'adresse ecrite dans la page ne porte plus d'identifiant."""
    from orion import affiliation as A
    lien = A.lien_site("https://www.kinguin.net/c/1?a=2&r=w0405u433koc0", "jeu")
    assert lien == "https://api.orion-launcher.com/aller/kinguin?u=https%3A%2F%2Fwww.kinguin.net%2Fc%2F1%3Fa%3D2&p=jeu"
    assert "w0405u433koc0" not in lien
    lien = A.lien_site("https://fr.gamesplanet.com/game/x?ref=orion", "bons-plans")
    assert lien == "https://api.orion-launcher.com/aller/gamesplanet?u=https%3A%2F%2Ffr.gamesplanet.com%2Fgame%2Fx&p=bons-plans"
    lien = A.lien_site("https://go.loaded.com/xJDad5?u=https%3A%2F%2Fwww.loaded.com%2Ffr%2Fx")
    assert lien == "https://api.orion-launcher.com/aller/loaded?u=https%3A%2F%2Fwww.loaded.com%2Ffr%2Fx"
    # une boutique sans suivi par le service : lien direct, comme avant
    assert A.lien_site("https://www.gog.com/fr/game/x", "jeu") == "https://www.gog.com/fr/game/x"
    assert A.lien_site("") == ""
    # itad.link : jamais touche
    assert A.lien_site("https://itad.link/x") == "https://itad.link/x"
