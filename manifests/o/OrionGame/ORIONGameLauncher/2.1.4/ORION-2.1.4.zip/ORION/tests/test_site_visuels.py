"""Visuels des jeux sur les pages /jeux et /en/games (12 octobre 2026) :
servis par le site, jamais charges depuis Steam par le visiteur."""
import json
import re
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "service" / "site"))
import gen_jeux  # noqa: E402
import gen_jeux_en  # noqa: E402
import jaquettes  # noqa: E402

CONFIG_MIN = ("Minimale :\nSystème d'exploitation : Windows 10\nProcesseur : Intel Core i5-8400\n"
              "Mémoire vive : 8 Go de mémoire\nGraphiques : GeForce GTX 1060 6 Go")
CONFIG_REC = ("Recommandée :\nSystème d'exploitation : Windows 10\nProcesseur : Intel Core i7-10700\n"
              "Mémoire vive : 16 Go de mémoire\nGraphiques : GeForce RTX 3070")
STEAM = "https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/{}/header.jpg?t=1"


def _site(tmp_path: Path, avec: tuple[str, ...]) -> Path:
    site = tmp_path / "site"
    (site / "img" / "jeux").mkdir(parents=True)
    (site / "index.html").write_text("<html><head><style>body{}</style></head></html>", encoding="utf-8")
    (site / "sitemap.xml").write_text(
        "<urlset>\n  <url>\n    <loc>https://orion-launcher.com/mentions-legales</loc>\n  </url>\n</urlset>\n",
        encoding="utf-8")
    from PIL import Image
    for appid in avec:
        Image.new("RGB", (460, 215), (20, 40, 60)).save(site / "img" / "jeux" / f"{appid}.jpg")
    return site


def _donnees(tmp_path: Path) -> Path:
    jeux = {}
    for appid, nom in (("1001", "Jeu Avec Visuel"), ("1002", "Jeu Sans Visuel"),
                       *((str(2000 + i), f"Action {i}") for i in range(5))):
        jeux[appid] = {"n": nom, "d": "1 janv. 2024", "g": ["Action"], "dev": "Studio",
                       "min": CONFIG_MIN, "rec": CONFIG_REC, "img": STEAM.format(appid)}
    f = tmp_path / "jeux.json"
    f.write_text(json.dumps(jeux, ensure_ascii=False), encoding="utf-8")
    return f


@pytest.fixture
def genere(tmp_path):
    site = _site(tmp_path, ("1001", "2000", "2001", "2002", "2003", "2004"))
    gen_jeux.main(site, _donnees(tmp_path))
    return site


def test_page_d_un_jeu_avec_son_visuel(genere):
    page = (genere / "jeux" / "jeu-avec-visuel.html").read_text(encoding="utf-8")
    assert 'class="tete-jeu"' in page
    assert '<img class="visuel" src="/img/jeux/1001.jpg"' in page
    assert 'loading="eager"' in page and 'fetchpriority="high"' in page
    assert 'og:image" content="https://orion-launcher.com/img/jeux/1001.jpg"' in page
    ld = [json.loads(x) for x in re.findall(r'<script type="application/ld\+json">(.*?)</script>', page)]
    assert ld[0]["image"] == "https://orion-launcher.com/img/jeux/1001.jpg"


def test_sans_visuel_la_page_reste_comme_avant(genere):
    page = (genere / "jeux" / "jeu-sans-visuel.html").read_text(encoding="utf-8")
    assert 'class="tete-jeu"' not in page and "/img/jeux/" not in page
    assert 'og:image" content="https://orion-launcher.com/img/og.jpg"' in page


def test_listes_avec_vignettes_chargees_a_la_demande(genere):
    for chemin in ("jeux.html", "jeux/genre/action.html", "jeux/carte/geforce-rtx-4060.html"):
        page = (genere / chemin).read_text(encoding="utf-8")
        cartes = re.findall(r'<a href="/jeux/[^"]+"( class="avec-visuel")?>(<img[^>]*>)?<b>', page)
        assert cartes, chemin
        for classe, img in cartes:
            assert bool(classe) == bool(img)
            if img:
                assert 'loading="lazy"' in img and 'width="460" height="215"' in img and 'alt=""' in img
    index = (genere / "jeux.html").read_text(encoding="utf-8")
    assert '<a href="/jeux/jeu-sans-visuel"><b>' in index           # pas d'image, pas de trou


def test_jamais_une_image_chargee_depuis_steam(genere):
    for page in genere.rglob("*.html"):
        for src in re.findall(r'<img[^>]*\bsrc="([^"]+)"', page.read_text(encoding="utf-8")):
            assert src.startswith("/"), (page.name, src)


def test_pages_anglaises(tmp_path):
    site = _site(tmp_path, ("1001",))
    gen_jeux.VISUELS.clear()
    gen_jeux.VISUELS.update(jaquettes.disponibles(site))
    jeux = gen_jeux_en.choisir({"1001": {"n": "Game One", "d": "1 Jan, 2024", "g": ["Action"],
                                         "min": "Minimum:\nOS: Windows 10\nProcessor: Intel Core i5-8400\n"
                                                "Memory: 8 GB RAM\nGraphics: GeForce GTX 1060 6GB",
                                         "rec": "", "img": STEAM.format("1001")}})
    assert jeux
    carte = gen_jeux_en.carte_jeu(jeux[0])
    assert carte.startswith('<a href="/en/games/game-one" class="avec-visuel"><img src="/img/jeux/1001.jpg"')


def test_liste_de_telechargement_et_preparation(tmp_path):
    from PIL import Image
    brut = tmp_path / "brut"
    brut.mkdir()
    Image.new("RGB", (616, 353), (200, 10, 10)).save(brut / "42.jpg")       # autre format
    (brut / "43.jpg").write_bytes(b"<html>404</html>")                       # page d'erreur
    faits, rates = jaquettes.preparer(brut, tmp_path / "img" / "jeux")
    assert faits == 1 and rates == ["43"]
    with Image.open(tmp_path / "img" / "jeux" / "42.jpg") as im:
        assert im.size == (460, 215)
    assert jaquettes.disponibles(tmp_path) == {"42"}


def test_le_script_du_pc_est_en_crlf_ascii():
    bat = Path(__file__).resolve().parent.parent / "service" / "site" / "JAQUETTES-SITE.bat"
    donnees = bat.read_bytes()
    donnees.decode("ascii")
    assert b"\n" not in donnees.replace(b"\r\n", b"")
    texte = donnees.decode("ascii")
    assert 'ren "images\\%%a.tmp" "%%a.jpg"' in texte          # jamais de fichier efface
    assert " del " not in texte.lower() and "rmdir" not in texte.lower()
