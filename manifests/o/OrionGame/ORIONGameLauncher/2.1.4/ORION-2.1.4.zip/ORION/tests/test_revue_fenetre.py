"""Revue de la fenetre principale et du calculateur de puissance : plans
perimes, filtres de sources, veille des prix, lecture des configurations.

La fenetre est construite sans boucle d'evenements : les minuteries du
demarrage (reseau) ne partent donc jamais pendant les tests."""
from __future__ import annotations

import pytest

from orion.core.models import Game, OptimizationPlan


@pytest.fixture(scope="module")
def app():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


@pytest.fixture
def fenetre(app):
    from orion.ui.main_window import MainWindow
    w = MainWindow()
    yield w
    w.deleteLater()


def _jeu(uid: str, titre: str = "") -> Game:
    return Game(title=titre or uid, source="manuel", source_id=uid, uid=uid)


# ---------------------------------------------------------------------------
# calculateur de puissance
# ---------------------------------------------------------------------------
def test_processeurs_sans_marque_lus_dans_la_bonne_table():
    from orion.puissance.references import CPU_INTEL, tous_les_cpu
    lus = dict(tous_les_cpu("Core i5-7600 ou Ryzen 5 1600"))
    assert lus["7600"] == CPU_INTEL["7600"]          # i5-7600, pas Ryzen 5 7600
    assert lus["1600"] == 31
    assert dict(tous_les_cpu("i7-2600 / FX-8350")) == {"2600": CPU_INTEL["2600"],
                                                       "fx 8350": 18}
    assert dict(tous_les_cpu("AMD Ryzen 5 7600"))["7600"] == 74
    assert dict(tous_les_cpu("Intel Core i5-7600 / AMD Ryzen 5 1600"))["7600"] == 38


def test_carte_intel_uhd_ne_vise_pas_la_4k():
    from orion.puissance.exigences import lire_config
    brut = ("<strong>Minimum :</strong><br><ul><li><strong>Processeur :</strong> "
            "Core i5-4460<br></li><li><strong>Graphiques :</strong> GTX 960 ou Intel "
            "UHD Graphics 630 (720p)<br></li></ul>")
    c = lire_config(brut)
    assert c.cible_px == 1280 * 720
    assert lire_config("<li>Graphics: Intel UHD 630, textures 4K en option</li>").cible_px is None
    assert lire_config("<li>Graphics: RTX 3080 (4K, 60 fps)</li>").cible_px == 3840 * 2160


def test_mesure_communaute_mal_formee_ignoree():
    from orion.puissance.estimation import Machine, depuis_communaute
    m = Machine(gpu=50)
    bonnes = [{"appid": "1", "gpu": 50, "fps": 70, "preset": "haute"}] * 3
    mauvaises = [{"appid": "1", "gpu": "cinquante", "fps": 70, "preset": "haute"},
                 {"appid": "1", "gpu": 50, "fps": None, "preset": "haute"},
                 "pas un dictionnaire"]
    ev = depuis_communaute("Jeu", "1", m, mauvaises + bonnes)
    assert ev is not None and ev.fps["haute"] == (70, 70)


def test_mesure_non_fluide_garde_sa_fourchette_affichee():
    from orion.puissance.estimation import evaluer, Machine
    ev = evaluer("C", Machine(gpu=50), None, {"photo": {"fps_avg": 48, "fps_low_1": 30}})
    assert ev.niveau == "basse" and ev.fps_niveau is None
    assert ev.fps_affiche == ((30, 48), "ultra")


def test_panneau_puissance_montre_la_mesure_et_son_niveau(app):
    from orion.puissance import Candidat
    from orion.puissance.estimation import evaluer, Machine
    from orion.ui.widgets.puissance_panel import PuissancePanel
    ev = evaluer("C", Machine(gpu=50), None, {"photo": {"fps_avg": 48, "fps_low_1": 30}})
    p = PuissancePanel()
    p.set_resultats([(Candidat(titre="C", installe=True), ev)])
    p._montrer("vos")
    assert p.modele.index(0, 2).data() == "30 a 48 (Ultra)"


def test_echec_evaluation_rend_le_bouton(fenetre):
    panneau = fenetre.hardware_view.puissance
    panneau.set_etat("Configurations des jeux : 100 %", True)
    fenetre._puissance_echec("boum")
    assert panneau.b_analyser.isEnabled()


# ---------------------------------------------------------------------------
# fiche de jeu : rien du jeu precedent
# ---------------------------------------------------------------------------
def test_fiche_oublie_plan_profil_et_sauvegardes_du_jeu_precedent(app, monkeypatch):
    from orion.core.config import CONFIG
    from orion.core.models import HardwareInfo
    from orion.ui.views.detail_view import DetailView
    monkeypatch.setitem(CONFIG.data.setdefault("optimizer", {}), "default_profile", "detente")
    v = DetailView()
    a = _jeu("a")
    v.set_game(a, HardwareInfo())
    v.plan = OptimizationPlan(game_uid="a", profile="recommande")

    class Lieu:
        path, files, size_mb = "C:/saves/A", 3, 1
    v.set_saves([Lieu()], [])
    assert v.save_combo.count() == 1

    v.set_game(_jeu("b"), HardwareInfo())
    assert v.plan is None
    assert v.profile_id == "recommande"              # 2.1.0 : un seul profil moteur, meme pour un ancien reglage « detente »
    assert v.save_combo.count() == 0 and not v.save_now.isEnabled()


def test_plan_perime_ignore(fenetre):
    a, b = _jeu("a"), _jeu("b")
    fenetre.detail_view.game = b
    fenetre.detail_view.profile_id = "detente"
    fenetre._plan_ready(a, "detente", OptimizationPlan(game_uid="a", profile="detente"), None)
    assert fenetre.detail_view.plan is None
    # meme jeu, autre profil choisi entre-temps
    fenetre._plan_ready(b, "esport", OptimizationPlan(game_uid="b", profile="esport"), None)
    assert fenetre.detail_view.plan is None


def test_appliquer_recalcule_un_plan_d_un_autre_jeu(fenetre, monkeypatch):
    b = _jeu("b")
    monkeypatch.setattr(fenetre.library, "get", lambda uid: b if uid == "b" else None)
    fenetre.detail_view.plan = OptimizationPlan(game_uid="a", profile="detente")
    demandes, appliques = [], []

    def construire(game, profil, hw, display):
        demandes.append((game.uid, profil))
        return OptimizationPlan(game_uid=game.uid, profile=profil)
    monkeypatch.setattr(fenetre.optimizer, "build_plan", construire)
    monkeypatch.setattr(fenetre.optimizer, "apply_plan",
                        lambda g, p: appliques.append(p) or (True, "ok"))
    monkeypatch.setattr(fenetre, "_build_plan", lambda *a: None)
    fenetre.apply_only("b", "detente")
    assert demandes == [("b", "detente")]
    assert all(p.game_uid == "b" for p in appliques)  # jamais le plan du jeu A


def test_resultat_ia_d_un_autre_jeu_ignore(fenetre):
    fenetre.detail_view.game = _jeu("b")
    fenetre.detail_view.set_ai_output("")
    fenetre._ai_ready("advise", (True, "conseils pour A"), "a")
    assert fenetre.detail_view.ai_output.text() == ""
    fenetre._ai_ready("advise", (True, "conseils pour B"), "b")
    assert fenetre.detail_view.ai_output.text() == "conseils pour B"


# ---------------------------------------------------------------------------
# analyse, notifications, veille des prix
# ---------------------------------------------------------------------------
def test_echec_d_une_autre_tache_ne_libere_pas_l_analyse(fenetre):
    fenetre._busy = True
    fenetre._task_failed("prix injoignables")
    assert fenetre._busy is True
    fenetre._scan_echec("disque illisible")
    assert fenetre._busy is False


def test_notification_longue_pas_effacee_par_une_courte(fenetre):
    fenetre.notify("court", 2)
    fenetre.notify("long", 30)
    assert fenetre.status_label.text() == "long"
    assert fenetre._timer_notify.remainingTime() > 20_000


def test_veille_des_prix_minuterie_et_verification_unique(fenetre, monkeypatch):
    from orion.core.config import CONFIG
    monkeypatch.setitem(CONFIG.data.setdefault("wishlist", {}), "check_hours", 3)
    fenetre._appliquer_frequence_envies()
    assert fenetre._wish_timer.interval() == 3 * 3600 * 1000
    monkeypatch.setitem(CONFIG.data["wishlist"], "check_hours", 12)
    fenetre._appliquer_frequence_envies()
    assert fenetre._wish_timer.interval() == 12 * 3600 * 1000

    lancees = []
    import orion.ui.main_window as mw

    class FausseTache:
        def __init__(self, *a, **k):
            from orion.core.tasks import _Signals
            self.signals = _Signals()
            lancees.append(self)

        def start(self):
            return self
    monkeypatch.setattr(mw, "Task", FausseTache)
    monkeypatch.setattr(fenetre.wishlist, "items", {"1": object()})
    fenetre.refresh_wishlist(True)
    fenetre.refresh_wishlist(True)                  # deuxieme « Suivre »
    assert len(lancees) == 1 and fenetre._wish_encore
    fenetre._wishlist_echec("hors ligne")
    assert fenetre._wish_busy is False


def test_liste_d_envies_enregistre_une_copie(tmp_path):
    from orion.wishlist import WishlistService
    w = WishlistService()
    w.items.clear()
    w.add("10", "Jeu")
    vus = []

    class Doc:
        def ecrire(self, d):
            vus.append(d)
            w.items["11"] = w.items["10"]           # l'interface ajoute pendant l'ecriture
    w._doc = Doc()
    w.save()
    assert len(vus[0]["items"]) == 1


def test_desinstallation_refusee_ne_retire_pas_l_alerte(fenetre, monkeypatch):
    monkeypatch.setattr(fenetre, "_uninstall_game", lambda uid: False)

    class Offre:
        title, key = "Jeu", "k"
    monkeypatch.setattr(fenetre.free, "get", lambda key: Offre())
    retirees = []
    monkeypatch.setattr(fenetre.free, "dismiss", lambda key: retirees.append(key))
    monkeypatch.setattr(fenetre, "_offer_purchase", lambda fb: retirees.append("achat"))
    fenetre._free_expired = {"k": "uid"}
    fenetre._free_uninstall("k")
    assert retirees == []


def test_ecran_choisi_conserve_apres_analyse_du_materiel(fenetre, monkeypatch):
    from orion.core.models import Display, DisplayMode, HardwareInfo
    ecrans = [Display(device="\\\\.\\DISPLAY1", name="Un", primary=True,
                      current=DisplayMode(1920, 1080, 60)),
              Display(device="\\\\.\\DISPLAY2", name="Deux",
                      current=DisplayMode(2560, 1440, 144))]
    hw = HardwareInfo(displays=ecrans)
    monkeypatch.setattr(fenetre, "actualiser_puissance", lambda: None)
    fenetre.detail_view.set_displays(ecrans, "\\\\.\\DISPLAY2")
    fenetre._hardware_done(hw)
    assert fenetre.detail_view.selected_display() == "\\\\.\\DISPLAY2"


def test_materiel_analyse_reevalue_la_puissance(fenetre, monkeypatch):
    from orion.core.models import HardwareInfo
    appels = []
    monkeypatch.setattr(fenetre, "actualiser_puissance", lambda: appels.append(1))
    fenetre._hardware_done(HardwareInfo())
    assert appels == [1]


# ---------------------------------------------------------------------------
# filtres de sources
# ---------------------------------------------------------------------------
def test_filtres_de_sources_gardent_leur_etat(app):
    from orion.ui.widgets.sidebar import Sidebar
    s = Sidebar()
    recus = []
    s.filters_changed.connect(recus.append)
    s.set_sources({"steam": 3, "epic": 2}, {})
    assert recus == []                               # tout coche : aucun filtre
    s._boxes["epic"].setChecked(False)
    assert recus[-1] == {"steam"}
    s.set_sources({"steam": 3, "epic": 2, "gog": 1}, {})   # rafraichissement
    assert not s._boxes["epic"].isChecked()
    assert s._boxes["gog"].isChecked()
    assert recus[-1] == {"steam", "gog"}             # la nouvelle source est montree
    s._boxes["epic"].setChecked(True)
    assert recus[-1] is None                         # tout recoche : plus de filtre


def test_bibliotheque_sans_filtre_rend_la_banniere(app):
    from orion.ui.views.library_view import LibraryView
    v = LibraryView()
    v.set_source_filter({"steam"})
    assert v._filter_sources == {"steam"}
    v.set_source_filter(None)
    assert v._filter_sources is None
