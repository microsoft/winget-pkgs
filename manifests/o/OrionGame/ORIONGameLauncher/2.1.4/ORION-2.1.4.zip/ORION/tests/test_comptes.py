"""Comptes des plateformes (1.8) : coffre, Steam, GOG, Xbox — reseau simule."""
import json

import pytest


class Rep:
    def __init__(self, donnees=None, statut=200, texte=""):
        self._d, self.status_code, self.text = donnees, statut, texte or json.dumps(donnees)

    def json(self):
        return self._d

    def raise_for_status(self):
        if self.status_code >= 400:
            raise RuntimeError(f"HTTP {self.status_code}")


@pytest.fixture
def reseau_simule(monkeypatch, base_neuve):
    from orion.core import reseau
    appels = []
    reponses = {}

    def repondre(methode):
        def f(url, **kw):
            appels.append((methode, url, kw))
            for motif, rep in reponses.items():
                if motif in url:
                    return rep(url, kw) if callable(rep) else rep
            raise AssertionError(f"appel inattendu : {url}")
        return f
    monkeypatch.setattr(reseau, "get", repondre("GET"))
    monkeypatch.setattr(reseau, "post", repondre("POST"))
    monkeypatch.setattr(reseau, "get_json",
                        lambda url, garder=0, **kw: repondre("GET")(url, **kw).json())
    return reponses, appels


def test_coffre_aller_retour(base_neuve):
    from orion.comptes import coffre
    coffre.enregistrer("steam", {"steamid": "76561198000000000", "cle": "A" * 32})
    assert coffre.lire("steam")["cle"] == "A" * 32
    brut = base_neuve.Table("coffre").get("steam")["donnees"]
    assert "A" * 32 not in brut                     # jamais en clair dans la base
    coffre.oublier("steam")
    assert coffre.lire("steam") is None


def test_coffre_illisible_oublie(base_neuve):
    from orion.comptes import coffre
    base_neuve.Table("coffre").set("gog", {"le": 0, "donnees": "@@pas-du-base64@@"})
    assert coffre.lire("gog") is None


def test_steam_openid_verifie(reseau_simule):
    from orion.comptes.steam import RETOUR, Steam
    reponses, appels = reseau_simule
    reponses["openid/login"] = Rep(texte="ns:http://specs.openid.net/auth/2.0\nis_valid:true\n")
    s = Steam()
    assert "openid.return_to=https%3A%2F%2Forion.localhost" in s.adresse_connexion()
    retour = (RETOUR + "?openid.mode=id_res&openid.claimed_id="
              "https%3A%2F%2Fsteamcommunity.com%2Fopenid%2Fid%2F76561198012345678"
              "&openid.sig=abc")
    assert s.est_retour(retour)
    assert s.retour_connexion(retour) == {"steamid": "76561198012345678"}
    assert appels[0][2]["data"]["openid.mode"] == "check_authentication"


def test_steam_openid_refuse(reseau_simule):
    from orion.comptes.steam import RETOUR, Steam
    reponses, _ = reseau_simule
    reponses["openid/login"] = Rep(texte="is_valid:false")
    retour = (RETOUR + "?openid.mode=id_res&openid.claimed_id="
              "https%3A%2F%2Fsteamcommunity.com%2Fopenid%2Fid%2F76561198012345678")
    with pytest.raises(ValueError):
        Steam().retour_connexion(retour)
    with pytest.raises(ValueError):
        Steam().retour_connexion(RETOUR + "?openid.mode=cancel")


def test_steam_cle_reperee_dans_la_page():
    from orion.comptes.steam import Steam
    texte = "Your Steam Web API Key\nKey: 0123456789ABCDEF0123456789ABCDEF\nDomain Name: x"
    assert Steam.cle_dans_page(texte) == "0123456789ABCDEF0123456789ABCDEF"
    assert Steam.cle_dans_page("Register a Steam Web API Key") == ""


def test_steam_profil_jeux_succes(reseau_simule):
    from orion.comptes import coffre, resume_succes
    from orion.comptes.steam import Steam
    reponses, _ = reseau_simule
    coffre.enregistrer("steam", {"steamid": "76561198012345678", "cle": "B" * 32})
    reponses["GetPlayerSummaries"] = Rep({"response": {"players": [{
        "personaname": "Sikher", "avatarfull": "a.jpg", "profileurl": "https://s/id/x",
        "communityvisibilitystate": 3, "timecreated": 1300000000}]}})
    reponses["GetBadges"] = Rep({"response": {"badges": [{}, {}, {}], "player_level": 27,
                                              "player_xp": 4210,
                                              "player_xp_needed_to_level_up": 90}})
    reponses["GetOwnedGames"] = Rep({"response": {"games": [
        {"appid": 1086940, "name": "Baldur's Gate 3", "playtime_forever": 14000,
         "img_icon_url": "abc"}, {"appid": 10, "name": "Counter-Strike"}]}})
    reponses["GetSchemaForGame"] = Rep({"game": {"availableGameStats": {"achievements": [
        {"name": "A1", "displayName": "Premier pas", "description": "d1"},
        {"name": "A2", "displayName": "Legende", "hidden": 1}]}}})
    reponses["GetPlayerAchievements"] = Rep({"playerstats": {"achievements": [
        {"apiname": "A1", "achieved": 1, "unlocktime": 1700000000},
        {"apiname": "A2", "achieved": 0, "unlocktime": 0}]}})
    reponses["GetGlobalAchievementPercentages"] = Rep({"achievementpercentages": {
        "achievements": [{"name": "A1", "percent": "81.5"}, {"name": "A2", "percent": 2.25}]}})
    s = Steam()
    p = s.profil(forcer=True)
    assert (p.pseudo, p.niveau, p.badges, p.xp, p.prive) == ("Sikher", 27, 3, 4210, False)
    jeux = s.jeux(forcer=True)
    assert [j.titre for j in jeux] == ["Baldur's Gate 3", "Counter-Strike"]
    assert jeux[0].minutes == 14000 and jeux[0].image.endswith("/1086940/abc.jpg")
    assert s.jeux_gardes()[0].titre == "Baldur's Gate 3"       # cache
    liste = s.succes("1086940")
    assert [(a.nom, a.obtenu, a.rarete, a.cache) for a in liste] == [
        ("Premier pas", True, 81.5, False), ("Legende", False, 2.2, True)]
    r = resume_succes(liste)
    assert (r["obtenus"], r["manquants"], r["pourcentage"], r["rares_obtenus"]) == (1, 1, 50, 0)


def test_steam_sans_cle(reseau_simule):
    from orion.comptes import coffre
    from orion.comptes.steam import Steam
    coffre.enregistrer("steam", {"steamid": "76561198012345678"})
    s = Steam()
    p = s.profil(forcer=True)
    assert p.extra.get("cle_manquante") and s.jeux(forcer=True) == []
    assert s.etape_apres_connexion() is not None


def test_gog_connexion_et_renouvellement(reseau_simule, monkeypatch):
    import time
    from orion.comptes.gog import GOG, RETOUR
    reponses, appels = reseau_simule
    jetons = iter([
        {"access_token": "AT1", "refresh_token": "RT1", "expires_in": 3600, "user_id": 42},
        {"access_token": "AT2", "refresh_token": "RT2", "expires_in": 3600}])
    reponses["auth.gog.com/token"] = lambda url, kw: Rep(next(jetons))
    reponses["userData.json"] = Rep({"username": "sik", "galaxyUserId": "42",
                                     "avatars": {"medium": "m.jpg"}})
    g = GOG()
    p = g.connecter(RETOUR + "&code=CODE123")
    assert p.pseudo == "sik" and g.secret()["access_token"] == "AT1"
    assert appels[0][2]["params"]["grant_type"] == "authorization_code"
    # jeton expire : renouvele avec le refresh_token, sans reconnexion
    g.maj_secret(expire=time.time() - 1)
    g.profil(forcer=True)
    assert g.secret()["access_token"] == "AT2" and g.secret()["user_id"] == "42"
    entetes = [kw.get("headers") for m, u, kw in appels if "userData" in u]
    assert entetes[-1]["Authorization"] == "Bearer AT2"


def test_gog_retour_sans_code():
    from orion.comptes.gog import GOG
    with pytest.raises(ValueError):
        GOG().retour_connexion("https://embed.gog.com/on_login_success?origin=client")


def test_xbox_chaine_de_jetons_et_succes(reseau_simule):
    from orion.comptes.xbox import RETOUR, Xbox
    reponses, appels = reseau_simule
    reponses["oauth20_token"] = Rep({"access_token": "MS", "refresh_token": "MSR"})
    reponses["user/authenticate"] = Rep({"Token": "XBL"})
    reponses["xsts/authorize"] = Rep({"Token": "XSTS", "NotAfter": "2099-01-01T00:00:00.1234567Z",
                                      "DisplayClaims": {"xui": [{"uhs": "U", "xid": "2535",
                                                                 "gtg": "SikherFR"}]}})
    reponses["profile/settings"] = Rep({"profileUsers": [{"settings": [
        {"id": "Gamertag", "value": "SikherFR"}, {"id": "Gamerscore", "value": "12450"}]}]})
    reponses["titlehistory"] = Rep({"titles": [
        {"titleId": "1234", "name": "Forza Horizon 5", "type": "Game",
         "achievement": {"currentAchievements": 40, "totalAchievements": 100},
         "titleHistory": {"lastTimePlayed": "2026-09-01T10:00:00.0000000Z"}},
        {"titleId": "9", "name": "Netflix", "type": "App"}]})
    reponses["achievements.xboxlive.com"] = Rep({"achievements": [
        {"id": "1", "name": "Bienvenue", "progressState": "Achieved",
         "progression": {"timeUnlocked": "2026-08-01T12:00:00.123Z"},
         "rarity": {"currentPercentage": 70.1}},
        {"id": "2", "name": "Secret", "progressState": "NotStarted", "isSecret": True,
         "lockedDescription": "Continuez a jouer", "rarity": {"currentPercentage": 1.5}}]})
    x = Xbox()
    p = x.connecter(RETOUR + "?code=M.C123")
    assert (p.pseudo, p.score) == ("SikherFR", 12450)
    entete = [kw["headers"] for m, u, kw in appels if "profile/settings" in u][0]
    assert entete["Authorization"] == "XBL3.0 x=U;XSTS"
    jeux = x.jeux(forcer=True)
    assert [(j.titre, j.succes_obtenus, j.succes_total) for j in jeux] == [
        ("Forza Horizon 5", 40, 100)]
    assert jeux[0].derniere_partie > 0
    liste = x.succes("1234")
    assert [(a.nom, a.obtenu, a.rarete, a.cache) for a in liste] == [
        ("Bienvenue", True, 70.1, False), ("Secret", False, 1.5, True)]
    assert liste[1].description == "Continuez a jouer" and liste[0].date > 0


def test_deconnexion_efface_tout(reseau_simule):
    from orion.comptes import coffre
    from orion.comptes.steam import Steam
    coffre.enregistrer("steam", {"steamid": "76561198012345678"})
    s = Steam()
    s.profil(forcer=True)
    s.deconnecter()
    assert not s.connecte() and s.profil_garde() is None and s.jeux_gardes() == []


def test_jeux_des_comptes_dans_les_possedes(reseau_simule):
    from orion.comptes import coffre
    from orion.comptes.base import _cache
    from orion.possedes import jeux_des_comptes
    coffre.enregistrer("steam", {"steamid": "1", "cle": "C" * 32})
    _cache("jeux").set("steam", {"maj": 0, "jeux": [
        {"plateforme": "steam", "id": "620", "titre": "Portal 2", "minutes": 300}]})
    jeux = jeux_des_comptes()
    assert [(g.title, g.launch_uri, g.external_seconds) for g in jeux] == [
        ("Portal 2", "steam://install/620", 18000)]


def test_journal_masque_les_secrets():
    import logging
    from orion.core.logging_setup import MasqueSecrets
    r = logging.LogRecord("x", 20, "", 0, "echec %s",
                          ("https://api.steampowered.com/a?key=ABCD1234&steamid=1",), None)
    MasqueSecrets().filter(r)
    assert "ABCD1234" not in r.getMessage()


# ----------------------------------------------------------------------
# deplacement de jeux entre disques
# ----------------------------------------------------------------------
def _jeu_factice(dossier):
    (dossier / "bin").mkdir(parents=True)
    (dossier / "jeu.exe").write_bytes(b"x" * 1000)
    (dossier / "bin" / "data.pak").write_bytes(b"y" * 5000)


def test_deplacer_puis_ramener(tmp_path, monkeypatch):
    from orion import deplacement as dep
    monkeypatch.setattr(dep, "MARGE_FIXE", 0)
    src = tmp_path / "C" / "Steam" / "common" / "MonJeu"
    _jeu_factice(src)
    etapes = []
    nouveau = dep.deplacer(str(src), str(tmp_path / "D"), lambda m, p: etapes.append(p))
    assert nouveau == str(tmp_path / "D" / "Jeux ORION" / "MonJeu")
    assert dep.est_jonction(src)
    assert (src / "bin" / "data.pak").read_bytes() == b"y" * 5000   # vu a l'ancien endroit
    assert not (src.parent / "MonJeu.ancien-orion").exists()
    assert etapes and etapes[-1] == 100
    with pytest.raises(dep.DeplacementImpossible):
        dep.deplacer(str(src), str(tmp_path / "E"))                  # deja deplace
    dep.ramener(str(src))
    assert not dep.est_jonction(src) and (src / "jeu.exe").exists()
    assert not (tmp_path / "D" / "Jeux ORION" / "MonJeu").exists()


def test_deplacement_jeu_utilise_ne_perd_rien(tmp_path, monkeypatch):
    from pathlib import Path
    from orion import deplacement as dep
    monkeypatch.setattr(dep, "MARGE_FIXE", 0)
    src = tmp_path / "C" / "MonJeu"
    _jeu_factice(src)
    vrai = Path.rename

    def rename(self, cible):
        if self == src:
            raise PermissionError("utilise")
        return vrai(self, cible)
    monkeypatch.setattr(Path, "rename", rename)
    with pytest.raises(dep.DeplacementImpossible, match="encore utilise"):
        dep.deplacer(str(src), str(tmp_path / "D"))
    assert (src / "bin" / "data.pak").exists() and not dep.est_jonction(src)
    assert not any((tmp_path / "D" / "Jeux ORION").iterdir())


def test_deplacement_place_insuffisante(tmp_path, monkeypatch):
    from orion import deplacement as dep
    src = tmp_path / "C" / "MonJeu"
    _jeu_factice(src)
    monkeypatch.setattr(dep, "espace_libre", lambda chemin: 10)
    with pytest.raises(dep.DeplacementImpossible, match="place insuffisante"):
        dep.deplacer(str(src), str(tmp_path / "D"))
    assert (src / "jeu.exe").exists()


def test_copie_incomplete_detectee(tmp_path, monkeypatch):
    from orion import deplacement as dep
    monkeypatch.setattr(dep, "MARGE_FIXE", 0)
    src = tmp_path / "C" / "MonJeu"
    _jeu_factice(src)
    vrai = dep.mesurer
    monkeypatch.setattr(dep, "mesurer", lambda d: dep.Bilan(1, 1) if "copie-en-cours" in str(d) else vrai(d))
    with pytest.raises(dep.DeplacementImpossible, match="incomplete"):
        dep.deplacer(str(src), str(tmp_path / "D"))
    assert (src / "jeu.exe").exists() and not dep.est_jonction(src)


# ----------------------------------------------------------------------
# calculateur de puissance
# ----------------------------------------------------------------------
def test_references_materiel():
    from orion.puissance.references import indice_cpu, indice_gpu
    assert indice_gpu("NVIDIA GeForce RTX 4070 Ti SUPER") == ("rtx 4070 ti super", 69)
    assert indice_gpu("AMD Radeon RX 6700XT")[0] == "rx 6700 xt"
    assert indice_gpu("NVIDIA GeForce RTX 3060 Laptop GPU")[1] < 26
    assert indice_cpu("Intel(R) Core(TM) i9-9900K CPU @ 3.60GHz")[0] == "9900k"
    assert indice_cpu("AMD Ryzen 7 5800X3D 8-Core Processor")[0] == "5800x3d"
    assert indice_gpu("Carte inconnue XYZ") is None


def test_configuration_steam_lue():
    from orion.puissance.exigences import lire_config
    c = lire_config("<li>Necessite un processeur 64 bits</li><li><strong>Processeur :</strong> "
                    "Intel Core i7-8700K / AMD Ryzen 5 3600X</li><li><strong>Memoire vive :"
                    "</strong> 16 GB de memoire</li><li><strong>Graphiques :</strong> NVIDIA "
                    "GeForce RTX 2060 Super / AMD Radeon RX 5700 XT (8 GB VRAM)</li>"
                    "<li><strong>Notes :</strong> 1440p @ 60 FPS</li>")
    # l'une OU l'autre suffit : la moins puissante est la demande (regle 2)
    assert (c.gpu_nom, c.cpu_nom, c.ram_go, c.vram_go) == ("RTX 2060 SUPER", "3600X", 16.0, 8.0)
    assert (c.cible_px, c.cible_fps) == (2560 * 1440, 60)


def _machine():
    from orion.puissance.estimation import Machine
    return Machine(gpu=49, cpu=57, vram_go=10, ram_go=32, pixels=2560 * 1440,
                   definition="2560x1440")


def test_estimation_prudente_jamais_ultra():
    from orion.puissance.estimation import ESTIME, estimer
    from orion.puissance.exigences import Config, Exigences
    e = Exigences("1", "A", minimum=Config(gpu=5, cpu=30, ram_go=8),
                  recommandee=Config(gpu=11.5, cpu=40, ram_go=8, vram_go=4))
    ev = estimer("A", e, _machine())
    assert ev.source == ESTIME and ev.niveau == "haute" and "ultra" not in ev.fps
    bas, haut = ev.fps["haute"]
    assert bas < haut and bas >= 55


def test_estimation_memoire_video_et_processeur():
    from orion.puissance.estimation import estimer
    from orion.puissance.exigences import Config, Exigences
    e = Exigences("2", "L", recommandee=Config(gpu=63, cpu=80, ram_go=16, vram_go=12,
                                                cible_px=2560 * 1440))
    ev = estimer("L", e, _machine())
    assert ev.niveau in ("moyenne", "basse") and any("video" in n for n in ev.notes)
    e = Exigences("3", "M", minimum=Config(gpu=5, ram_go=64))
    assert estimer("M", e, _machine()).niveau == "insuffisant"


def test_sans_information_on_le_dit():
    from orion.puissance.estimation import INCONNU, Machine, estimer
    assert estimer("X", None, _machine()).source == INCONNU
    assert estimer("X", None, Machine()).source == INCONNU


def test_mesure_prioritaire_et_seule_a_dire_ultra():
    from orion.puissance.estimation import MESURE, evaluer
    runs = {"photo": {"fps_avg": 88, "fps_low_1": 62}, "detente": {"fps_avg": 110,
                                                                    "fps_low_1": 80}}
    ev = evaluer("C", _machine(), None, runs)
    assert ev.source == MESURE and ev.niveau == "ultra" and ev.fps["ultra"] == (62, 88)
    runs = {"photo": {"fps_avg": 48, "fps_low_1": 30}}
    assert evaluer("C", _machine(), None, runs).niveau == "basse"


def test_communaute_trois_mesures_proches():
    from orion.puissance.estimation import COMMUNAUTE, depuis_communaute
    m = _machine()
    mesures = [{"appid": "9", "gpu": g, "pixels": 2560 * 1440, "preset": "ultra", "fps": f}
               for g, f in ((48, 70), (50, 75), (47, 68))]
    ev = depuis_communaute("J", "9", m, mesures)
    assert ev.source == COMMUNAUTE and ev.niveau == "ultra"
    assert depuis_communaute("J", "9", m, mesures[:2]) is None          # pas assez
    loin = [dict(x, gpu=100) for x in mesures]
    assert depuis_communaute("J", "9", m, loin) is None                  # cartes trop differentes


def test_calibration_bornee():
    """9 octobre : une seule partie mesuree suffit (c'est une vraie mesure),
    et l'ecart de Baldur's Gate 3 (x 2,4) doit pouvoir etre appris."""
    from orion.puissance.estimation import calibrer
    assert calibrer([]) == 1.0
    assert calibrer([(120, 100)]) == 1.2
    assert calibrer([(120, 100), (130, 100)]) == 1.25
    assert calibrer([(236, 100)]) == 2.36
    assert calibrer([(900, 100)]) == 2.5
    # 15 octobre : seule, une partie moins bonne que prevu ne descend pas sous 0,75 ;
    # deux jeux qui s'accordent peuvent aller jusqu'a 0,5
    assert calibrer([(10, 100)]) == 0.75 and calibrer([(10, 100), (12, 100)]) == 0.5


def test_partie_hachee_jamais_une_reference():
    """15 octobre : Sparking ZERO mesure a 46,9 i/s de moyenne, 3,6 au 0,1 %
    le plus bas et 192 au maximum pendant un enregistrement d'ecran : la
    partie est hachee, elle ne recale pas le PC. Une mesure douteuse non plus."""
    from orion.puissance.estimation import Machine, mesure_hachee, paires_du_pc
    from orion.puissance.exigences import Config, Exigences
    m = Machine(gpu=200, cpu=100, ram_go=32, vram_go=10, pixels=1920 * 1080, definition="1920x1080")
    ex = Exigences(appid="1790600", recommandee=Config(gpu=100, cpu=100, ram_go=16, vram_go=8))
    hachee = {"appid": "1790600", "preset": "basse", "fps_avg": 46.9, "fps_low_1": 27.7, "fps_low_01": 3.6,
              "fps_max": 192.5, "frames": 22949, "at": 3}
    assert mesure_hachee(hachee)
    assert paires_du_pc([hachee], m, lambda a: ex) == []
    douteuse = {"appid": "1790600", "preset": "basse", "fps_avg": 60, "fps_low_1": 40, "fps_low_01": 30,
                "frames": 100, "douteuse": True, "at": 3}
    assert paires_du_pc([douteuse], m, lambda a: ex) == []
    bonne = dict(douteuse, douteuse=False)
    assert len(paires_du_pc([bonne], m, lambda a: ex)) == 1


def test_les_parties_mesurees_corrigent_les_estimations_du_pc():
    """Avant : seules les mesures du profil « Detente » (disparu en 2.1.0)
    corrigeaient les estimations. Toute partie mesuree compte, a son niveau ;
    une partie bridee (1 % le plus bas colle a la moyenne) est ignoree."""
    from orion.puissance.estimation import Machine, estimer, paires_du_pc, MARGE_BASSE, MARGE_HAUTE
    from orion.puissance.exigences import Config, Exigences
    m = Machine(gpu=200, cpu=100, ram_go=32, vram_go=10, pixels=1920 * 1080, definition="1920x1080")
    ex = Exigences(appid="1086940", recommandee=Config(gpu=100, cpu=100, ram_go=16, vram_go=8))
    haute = sum(estimer("", ex, m).fps["haute"]) / 2 / ((MARGE_BASSE + MARGE_HAUTE) / 2)
    runs = [{"appid": "1086940", "preset": "ultra", "fps_avg": 130, "fps_low_1": 92, "at": 2},
            {"appid": "1086940", "preset": "ultra", "fps_avg": 50, "fps_low_1": 30, "at": 1},   # plus ancienne
            {"appid": "2", "preset": "haute", "fps_avg": 40, "fps_low_1": 39.5, "at": 3},       # bridee
            {"preset": "haute", "fps_avg": 60, "fps_low_1": 40}]                                # sans fiche
    paires = paires_du_pc(runs, m, exig_de=lambda appid: ex)
    assert len(paires) == 1
    mesure, estime = paires[0]
    assert mesure == 130 and abs(estime - haute * 0.77) < 0.01


def test_candidats_fusion_et_prix():
    from orion.boutique import Fiche
    from orion.core.models import Game
    from orion.plugins.boutique.base import Offre
    from orion.puissance import candidats
    fiches = [Fiche("Hades II", [Offre("Hades II", "Steam", 24.5, url="https://x",
                                       steam_appid="1145350")])]
    inst = [Game(title="Hades II", source="epic", uid="h")]
    liste = candidats(inst, [], [], fiches)
    assert len(liste) == 1 and liste[0].installe and liste[0].appid == "1145350"


# ----------------------------------------------------------------------
# liens partenaires
# ----------------------------------------------------------------------
def test_affiliation_parametre_et_gabarit(monkeypatch):
    from orion import affiliation as af
    from orion.core.config import CONFIG
    CONFIG.set("boutique.liens_partenaires", True)
    table = (af.Programme("ig", "Instant Gaming", ("instant-gaming.com",), {"igr": "orion"}),
             af.Programme("hb", "Humble", ("humblebundle.com",),
                          gabarit="https://reseau.example/c/1/2?u={url}"))
    u = af.affilier("https://www.instant-gaming.com/fr/rechercher/?q=elden+ring", table)
    assert u == "https://www.instant-gaming.com/fr/rechercher/?q=elden+ring&igr=orion"
    # un identifiant deja present (celui d'un autre) est remplace, pas double
    u = af.affilier("https://www.instant-gaming.com/fr/1234-x/?igr=autre", table)
    assert u.count("igr=") == 1 and u.endswith("igr=orion")
    u = af.affilier("https://www.humblebundle.com/store/hades", table)
    assert u == "https://reseau.example/c/1/2?u=https%3A%2F%2Fwww.humblebundle.com%2Fstore%2Fhades"


def test_affiliation_jamais_sur_isthereanydeal_ni_inconnu():
    from orion import affiliation as af
    table = (af.Programme("hb", "Humble", ("humblebundle.com", "itad.link"), {"x": "1"}),)
    lien = "https://itad.link/019eb700/?app=60vq30"
    assert af.affilier(lien, table) == lien
    assert af.affilier("https://store.steampowered.com/app/620", table) == \
        "https://store.steampowered.com/app/620"


def test_affiliation_desactivable():
    from orion import affiliation as af
    from orion.core.config import CONFIG
    table = (af.Programme("ig", "IG", ("instant-gaming.com",), {"igr": "orion"}),)
    CONFIG.set("boutique.liens_partenaires", False)
    try:
        u = "https://www.instant-gaming.com/fr/"
        assert af.affilier(u, table) == u
    finally:
        CONFIG.set("boutique.liens_partenaires", True)


def test_affiliation_sans_identifiant_lien_intact():
    from orion import affiliation as af
    u = "https://www.eneba.com/fr/store/all?text=hades"
    assert af.affilier(u) == u or "eneba" in u          # tant qu'aucun identifiant n'est renseigne
    assert all(not p.parametres.get("") for p in af.PROGRAMMES)


def test_affiliation_identifiants_reels_sur_les_recherches():
    """Le joueur arrive sur la recherche du jeu, avec l'identifiant partenaire."""
    from orion import marche_gris
    from orion.core.config import CONFIG
    CONFIG.set("boutique.liens_partenaires", True)
    d = {s.id: u for s, u in marche_gris.liens("Hades II")}
    assert d["instant-gaming"] == ("https://www.instant-gaming.com/fr/rechercher/"
                                   "?query=Hades+II&platform%5B%5D=1"
                                   "&type%5B%5D=Steam&type%5B%5D=Rockstar&type%5B%5D=Ubisoft+Connect"
                                   "&type%5B%5D=Microsoft+Store&type%5B%5D=Instant+Gaming&type%5B%5D=GOG.com"
                                   "&type%5B%5D=Epic+Games&type%5B%5D=EA+App&type%5B%5D=Battle.net"
                                   "&product_types%5B%5D=game&product_types%5B%5D=preorder&os%5B%5D=1&igr=Sikher")
    assert "type%5B%5D=Steam" in d["instant-gaming"]           # jamais une liste sans Steam
    # Kinguin : « CD Key » dans la recherche ecarte les offres « Account ».
    # Jamais le filtre des regions (il cachait S.T.A.L.K.E.R. 2) ni « Steam »
    # (il cachait les cles Rockstar ou Battle.net) ; depuis le 7 octobre, les
    # plates-formes PC et le pays d'activation, essayes sur le site
    assert d["kinguin"] == "https://www.kinguin.net/listing?platforms=25,3,1,18,15,26,23,4,27,22,2,5&countries=FR&active=1&hideUnavailable=1&type=all&phrase=Hades+II+CD+Key&page=0&size=50&sort=bestseller.score,DESC&r=w0405u433koc0"
    for site, url in marche_gris.liens_revendeurs("S.T.A.L.K.E.R. 2: Heart of Chornobyl"):
        assert "regions" not in url and "Steam+CD" not in url
    # le pays du joueur passe dans le filtre d'activation
    CONFIG.set("market.country", "BE", save=False)
    try:
        assert "countries=BE" in dict((s.id, u) for s, u in marche_gris.liens("Hades II"))["kinguin"]
    finally:
        CONFIG.set("market.country", "FR", save=False)
    assert d["g2a"] == "https://www.g2a.com/fr/search?query=Hades+II&gtag=6ce1b9d684"
    assert d["gamivo"] == "https://www.gamivo.com/search/Hades%20II?glv=Oriongames"
    # sites sans identifiant (encore en attente) : lien intact
    assert "?" in d["eneba"] and "glv" not in d["eneba"] and "gtag" not in d["eneba"]


def test_aucune_donnee_personnelle_dans_les_programmes():
    """Seuls des identifiants publics : ni e-mail, ni IBAN, ni page de gestion."""
    import re
    from orion import affiliation as af
    texte = repr(af.PROGRAMMES)
    assert not re.search(r"@|IBAN|FR76|dashboard|/account|/login|password", texte, re.I)


def test_revendeurs_retenus_et_filtres():
    """Seuls Instant Gaming, Kinguin et Loaded sont proposes, avec
    l'identifiant partenaire. Kinguin : recherche par le texte (« CD Key »),
    sans filtre du site, car ses filtres cachaient des jeux entiers."""
    from orion import marche_gris
    from orion.core.config import CONFIG
    CONFIG.set("marche_gris.afficher", True)
    d = {s.id: u for s, u in marche_gris.liens_revendeurs("Hades II")}
    assert set(d) == {"instant-gaming", "kinguin", "loaded"}
    # Loaded : le lien de suivi du reseau enveloppe la recherche du jeu
    assert d["loaded"] == ("https://go.loaded.com/xJDad5?u="
                           "https%3A%2F%2Fwww.loaded.com%2Fcatalogsearch%2Fresult%2F%3Fq%3DHades%2BII%2BPC")
    from orion import affiliation
    assert affiliation.affilier(d["loaded"]) == d["loaded"]            # jamais enveloppe deux fois
    assert affiliation.est_partenaire("https://www.loaded.com/fr_fr/hades-ii-pc-steam")
    CONFIG.set("boutique.liens_partenaires", False)
    try:
        assert affiliation.affilier("https://www.loaded.com/x") == "https://www.loaded.com/x"
    finally:
        CONFIG.set("boutique.liens_partenaires", True)
    # filtres du site qui ne cachent pas le jeu (7 octobre) : plates-formes PC,
    # pays d'activation du joueur, pas de rupture ; jamais celui des regions
    assert "platforms=25,3,1" in d["kinguin"] and "countries=FR" in d["kinguin"]
    assert "hideUnavailable=1" in d["kinguin"] and "regions" not in d["kinguin"]
    assert "phrase=Hades+II+CD+Key" in d["kinguin"] and "r=" in d["kinguin"]
    assert "igr=Sikher" in d["instant-gaming"]
    assert "Gift" in marche_gris.CONSIGNE and "Account" in marche_gris.CONSIGNE
    CONFIG.set("marche_gris.afficher", False)
    assert marche_gris.liens_revendeurs("Hades II") == []
    CONFIG.set("marche_gris.afficher", True)
