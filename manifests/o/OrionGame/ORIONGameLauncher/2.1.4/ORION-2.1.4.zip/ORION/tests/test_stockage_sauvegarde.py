"""Page Stockage (1.9) : « Recalculer », sauvegarde d'un jeu sur un autre
disque, restauration, suppression, et affichage des sauvegardes.

Tout se passe dans des dossiers temporaires ; un « disque » est un dossier
racine (les lettres Windows ne servent qu'aux essais d'affichage)."""
from __future__ import annotations

import os
import time
from pathlib import Path

import pytest


@pytest.fixture
def app():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


@pytest.fixture
def sd(monkeypatch):
    from orion import deplacement, sauvegarde_disque
    monkeypatch.setattr(deplacement, "MARGE_FIXE", 0)
    return sauvegarde_disque


def _jeu_factice(dossier: Path) -> Path:
    (dossier / "bin").mkdir(parents=True)
    (dossier / "vide").mkdir()
    (dossier / "jeu.exe").write_bytes(b"x" * 1000)
    (dossier / "bin" / "data.pak").write_bytes(b"y" * 50_000)
    return dossier


def _contenu(dossier: Path) -> dict:
    return {str(p.relative_to(dossier)): p.read_bytes()
            for p in sorted(dossier.rglob("*")) if p.is_file()}


def _attendre(app, condition, delai: float = 10.0) -> None:
    from PySide6.QtCore import QThreadPool
    fin = time.monotonic() + delai
    while time.monotonic() < fin:
        QThreadPool.globalInstance().waitForDone(50)
        app.processEvents()
        if condition():
            return
    raise AssertionError("delai depasse")


# ----------------------------------------------------------------------
# sauvegarder
# ----------------------------------------------------------------------
def test_sauvegarde_copie_verifiee_sans_toucher_au_jeu(tmp_path, sd):
    src = _jeu_factice(tmp_path / "C" / "Steam" / "common" / "MonJeu")
    avant = _contenu(src)
    messages = []
    r = sd.sauvegarder(str(src), str(tmp_path / "F"), "Mon Jeu",
                       progress_cb=lambda m, p: messages.append((m, p)), version="1.2")
    dst = tmp_path / "F" / "Sauvegardes ORION" / "Mon Jeu"
    assert r["chemin"] == str(dst) and r["octets"] == 51_000 and r["fichiers"] == 2
    assert r["version"] == "1.2" and r["restes"] == [] and r["duree"] >= 0
    assert _contenu(dst) == avant and (dst / "vide").is_dir()
    # le jeu d'origine est intact : ni renomme, ni remplace par un lien
    assert _contenu(src) == avant and not os.path.islink(src)
    assert not list((tmp_path / "C" / "Steam" / "common").glob("*orion*"))
    assert not (dst.parent / "Mon Jeu.copie-en-cours").exists()
    # avancement detaille : taille copiee / totale, puis verification
    assert any("sur" in m and "Ko" in m for m, _ in messages)
    assert messages[-1] == ("Verification de la copie, fichier par fichier...", 100)


def test_sauvegarde_existante_puis_mise_a_jour(tmp_path, sd):
    src = _jeu_factice(tmp_path / "C" / "MonJeu")
    sd.sauvegarder(str(src), str(tmp_path / "F"), "MonJeu")
    with pytest.raises(sd.SauvegardeExistante):
        sd.sauvegarder(str(src), str(tmp_path / "F"), "MonJeu")
    (src / "nouveau.dat").write_bytes(b"n" * 10)
    r = sd.sauvegarder(str(src), str(tmp_path / "F"), "MonJeu", remplacer=True)
    dst = Path(r["chemin"])
    assert (dst / "nouveau.dat").exists() and r["fichiers"] == 3
    assert [p.name for p in dst.parent.iterdir()] == ["MonJeu"]   # aucun reste


def test_annulation_supprime_la_copie_partielle(tmp_path, sd, monkeypatch):
    from orion import deplacement
    monkeypatch.setattr(deplacement.Suivi, "PAS", 0)
    src = _jeu_factice(tmp_path / "C" / "MonJeu")
    for i in range(5):
        (src / f"gros{i}.bin").write_bytes(os.urandom(200_000))
    annulation = sd.Annulation()

    def progression(message, pourcent):
        if 0 < pourcent < 100:
            annulation.annuler()               # le joueur clique « Annuler »
    with pytest.raises(sd.SauvegardeAnnulee) as err:
        sd.sauvegarder(str(src), str(tmp_path / "F"), "MonJeu", progress_cb=progression,
                       annulation=annulation)
    assert "annulee" in str(err.value) and sd.ORIGINAL_INTACT in str(err.value)
    assert not any((tmp_path / "F" / "Sauvegardes ORION").iterdir())
    assert (src / "gros4.bin").stat().st_size == 200_000


def test_place_insuffisante_avant_toute_copie(tmp_path, sd, monkeypatch):
    from orion import deplacement
    src = _jeu_factice(tmp_path / "C" / "MonJeu")
    monkeypatch.setattr(deplacement, "espace_libre", lambda chemin: 10)
    with pytest.raises(sd.SauvegardeImpossible, match="place insuffisante"):
        sd.sauvegarder(str(src), str(tmp_path / "F"), "MonJeu")
    assert not any((tmp_path / "F" / "Sauvegardes ORION").iterdir())


def test_copie_differente_detectee(tmp_path, sd, monkeypatch):
    from orion import deplacement
    src = _jeu_factice(tmp_path / "C" / "MonJeu")
    vrai = deplacement.mesurer
    monkeypatch.setattr(deplacement, "mesurer", lambda d: deplacement.Bilan(1, 1)
                        if "copie-en-cours" in str(d) else vrai(d))
    with pytest.raises(sd.SauvegardeImpossible, match="incomplete ou differente"):
        sd.sauvegarder(str(src), str(tmp_path / "F"), "MonJeu")
    assert not any((tmp_path / "F" / "Sauvegardes ORION").iterdir())


def test_refus_jeu_deplace_et_meme_dossier(tmp_path, sd):
    src = _jeu_factice(tmp_path / "C" / "MonJeu")
    with pytest.raises(sd.SauvegardeImpossible, match="dossier du jeu"):
        sd.sauvegarder(str(src), str(src), "X")
    lien = tmp_path / "C" / "Lien"
    os.symlink(src, lien, target_is_directory=True)        # « jonction » hors Windows
    with pytest.raises(sd.SauvegardeImpossible, match="ancienne version"):
        sd.sauvegarder(str(lien), str(tmp_path / "F"), "X")


def test_nom_dossier_et_disques():
    from orion.sauvegarde_disque import disques_sauvegarde, nom_dossier
    assert nom_dossier('Baldur\'s Gate 3: "Deluxe" / Edition?') == "Baldur's Gate 3 Deluxe Edition"
    assert nom_dossier("CON") == "CON (jeu)"
    assert nom_dossier("...", "C:\\Jeux\\Truc") == "Truc"
    cibles = disques_sauvegarde([
        {"mount": "C:\\", "type": "fixed"}, {"mount": "F:\\", "type": "fixed"},
        {"mount": "G:\\", "type": "removable"}, {"mount": "Z:\\", "type": "network"},
        {"mount": "R:\\", "type": "cdrom"}], "C:\\Jeux\\X")
    assert [c["lettre"] for c in cibles] == ["F:", "G:"] and cibles[1]["amovible"]


def test_suivi_message_lisible(monkeypatch):
    from orion import deplacement as dep
    assert dep.taille_lisible(48.25 * 1024 ** 3) == "48,2 Go"
    assert dep.duree_lisible(372) == "6 min 12 s" and dep.duree_lisible(3900) == "1 h 05 min"
    recu = []
    s = dep.Suivi(4 * 1024 ** 3, lambda m, p: recu.append((m, p)))
    s.debut -= 10                                    # 10 s ecoulees
    s.fichier("bin\\data.pak")
    s._dernier = 0
    s.ajouter(1024 ** 3)
    message, pourcent = recu[-1]
    assert pourcent == 25
    assert message.startswith("1,0 Go sur 4,0 Go") and "restantes" in message
    assert message.endswith("\nbin\\data.pak")


# ----------------------------------------------------------------------
# restaurer et supprimer
# ----------------------------------------------------------------------
def test_restaurer_un_jeu_desinstalle(tmp_path, sd):
    src = _jeu_factice(tmp_path / "C" / "MonJeu")
    avant = _contenu(src)
    r = sd.sauvegarder(str(src), str(tmp_path / "F"), "MonJeu")
    sd.dep._supprimer(src)                            # jeu desinstalle
    res = sd.restaurer(r["chemin"], str(src))
    assert _contenu(src) == avant and res["remplace"] is False
    assert _contenu(Path(r["chemin"])) == avant           # sauvegarde intacte
    assert not (src.parent / "MonJeu.restauration-en-cours").exists()


def test_restaurer_par_dessus_demande_un_accord(tmp_path, sd):
    src = _jeu_factice(tmp_path / "C" / "MonJeu")
    avant = _contenu(src)
    r = sd.sauvegarder(str(src), str(tmp_path / "F"), "MonJeu")
    (src / "jeu.exe").write_bytes(b"abime")
    with pytest.raises(sd.JeuPresent):
        sd.restaurer(r["chemin"], str(src))
    assert (src / "jeu.exe").read_bytes() == b"abime"          # rien n'a bouge
    res = sd.restaurer(r["chemin"], str(src), remplacer=True)
    assert _contenu(src) == avant and res["remplace"] is True and res["restes"] == []
    assert sorted(p.name for p in src.parent.iterdir()) == ["MonJeu"]


def test_restaurer_jeu_utilise_ne_perd_rien(tmp_path, sd, monkeypatch):
    src = _jeu_factice(tmp_path / "C" / "MonJeu")
    r = sd.sauvegarder(str(src), str(tmp_path / "F"), "MonJeu")
    (src / "jeu.exe").write_bytes(b"actuel")
    vrai = Path.rename

    def rename(self, cible):
        if self == src:
            raise PermissionError("utilise")
        return vrai(self, cible)
    monkeypatch.setattr(Path, "rename", rename)
    with pytest.raises(sd.SauvegardeImpossible, match="utilises") as err:
        sd.restaurer(r["chemin"], str(src), remplacer=True)
    assert sd.JEU_INTACT in str(err.value)
    assert (src / "jeu.exe").read_bytes() == b"actuel"
    assert sorted(p.name for p in src.parent.iterdir()) == ["MonJeu"]


def test_supprimer_sauvegarde(tmp_path, sd):
    src = _jeu_factice(tmp_path / "C" / "MonJeu")
    r = sd.sauvegarder(str(src), str(tmp_path / "F"), "MonJeu")
    with pytest.raises(sd.SauvegardeImpossible, match="par securite"):
        sd.supprimer_sauvegarde(str(src))               # jamais un jeu installe
    assert sd.supprimer_sauvegarde(r["chemin"]) == []
    assert not Path(r["chemin"]).exists() and (src / "jeu.exe").exists()
    assert sd.supprimer_sauvegarde(r["chemin"]) == []      # deja partie : rien a faire


def test_noter_et_oublier(sd):
    from orion.core.models import Game
    g = Game(title="X", source="steam", source_id="1", install_dir="C:\\X")
    sd.noter(g, {"chemin": "F:\\Sauvegardes ORION\\X", "octets": 5, "fichiers": 1,
                 "date": 10, "duree": 3, "restes": []})
    sd.noter(g, {"chemin": "F:\\Sauvegardes ORION\\X", "octets": 7, "fichiers": 2,
                 "date": 20, "version": "1.1"})
    assert g.extra["sauvegardes_disque"] == [{"chemin": "F:\\Sauvegardes ORION\\X",
                                              "date": 20, "octets": 7, "fichiers": 2,
                                              "version": "1.1"}]
    sd.oublier(g, "F:\\Sauvegardes ORION\\X")
    assert "sauvegardes_disque" not in g.extra


def test_reparer_restes_apres_arret_brutal(tmp_path, sd):
    from orion.core.models import Game
    disque = tmp_path / "F"
    base = disque / "Sauvegardes ORION"
    (base / "A.copie-en-cours").mkdir(parents=True)
    (base / "B.ancienne-sauvegarde").mkdir()                    # B a disparu
    jeu = tmp_path / "C" / "MonJeu"
    _jeu_factice(tmp_path / "C" / "MonJeu.remplace-orion")      # bascule interrompue
    (tmp_path / "C" / "MonJeu.restauration-en-cours").mkdir()
    g = Game(title="Mon Jeu", source="steam", source_id="1", install_dir=str(jeu))
    r = sd.reparer_restes([g], [str(disque)])
    assert not (base / "A.copie-en-cours").exists()
    assert (base / "B").is_dir() and not (base / "B.ancienne-sauvegarde").exists()
    assert (jeu / "jeu.exe").exists()
    assert sorted(p.name for p in jeu.parent.iterdir()) == ["MonJeu"]
    assert len(r.actions) == 4 and not r.restes


# ----------------------------------------------------------------------
# bibliotheque : les sauvegardes survivent aux scans
# ----------------------------------------------------------------------
def test_scan_garde_les_sauvegardes_et_le_jeu_desinstalle(base_neuve, tmp_path):
    from orion.core.models import Game
    from orion.core.store import LibraryStore
    assert "sauvegardes_disque" in LibraryStore.EXTRA_CONSERVES
    store = LibraryStore()
    fiche = [{"chemin": "F:\\Sauvegardes ORION\\A", "date": 1, "octets": 1}]
    a = Game(title="A", source="steam", source_id="1", install_dir=str(tmp_path / "A"),
             extra={"sauvegardes_disque": list(fiche)})
    (tmp_path / "A").mkdir()
    b = Game(title="B", source="steam", source_id="2", install_dir=str(tmp_path / "absent"),
             extra={"sauvegardes_disque": list(fiche)})
    c = Game(title="C", source="steam", source_id="3", install_dir=str(tmp_path / "parti"))
    for g in (a, b, c):
        store.games[g.uid] = g
    neuf = Game(title="A", source="steam", source_id="1", install_dir=str(tmp_path / "A"))
    store.merge_scan([neuf])
    assert store.games[neuf.uid].extra["sauvegardes_disque"] == fiche
    # B est desinstalle mais sauvegarde : sa fiche reste, marquee introuvable
    assert store.games[b.uid].extra.get("missing") is True
    assert c.uid not in store.games


# ----------------------------------------------------------------------
# inventaire et recalcul
# ----------------------------------------------------------------------
def test_inventaire_compte_les_sauvegardes_par_disque():
    from orion.core.models import Game, HardwareInfo
    from orion.storage import disks_in_use, inventory
    s = {"chemin": "F:\\Sauvegardes ORION\\A", "date": time.time(), "octets": 2 * 1024 ** 3}
    a = Game(title="A", source="steam", source_id="1", install_dir="C:\\A",
             size_bytes=10 * 1024 ** 3, last_played=time.time(), play_seconds=9000,
             extra={"sauvegardes_disque": [s]})
    b = Game(title="B", source="steam", source_id="2", install_dir="D:\\B",
             size_bytes=5 * 1024 ** 3, extra={"missing": True, "sauvegardes_disque": [
                 dict(s, chemin="F:\\Sauvegardes ORION\\B")]})
    c = Game(title="C", source="steam", source_id="3", install_dir="D:\\C",
             extra={"missing": True})
    hw = HardwareInfo()
    hw.disks = [{"mount": "C:\\", "total_gb": 100, "free_gb": 50}]
    entries = inventory([a, b, c], hw)
    assert [e.game.title for e in entries] == ["A", "B"]
    assert entries[1].installe is False and "sauvegarde disponible" in entries[1].state_label
    assert entries[0].sauvegarde_label.startswith("F:  ·  ")
    disques = {d["mount"]: d for d in disks_in_use(entries, hw)}
    assert disques["C:\\"]["jeux"] == 1 and disques["C:\\"]["sauvegardes"] == 0
    assert disques["F:"]["sauvegardes"] == 2 and disques["F:"]["sauvegardes_go"] == 4.0
    assert disques["F:"]["jeux"] == 0 and "D:" not in disques      # B n'est plus installe


def test_mesurer_stockage(tmp_path):
    from orion.storage import mesurer_stockage
    src = _jeu_factice(tmp_path / "MonJeu")
    etapes = []
    r = mesurer_stockage([("u1", str(src)), ("u2", str(tmp_path / "absent"))],
                         [str(tmp_path)], lambda m, p: etapes.append(p))
    assert r["tailles"] == {"u1": 51_000}
    assert r["disques"][str(tmp_path)]["total_gb"] >= 0 and etapes[-1] == 100


# ----------------------------------------------------------------------
# page Stockage
# ----------------------------------------------------------------------
def _vue_avec_donnees(tmp_path):
    from orion.core.models import Game, HardwareInfo
    from orion.storage import disks_in_use, inventory
    from orion.ui.views.storage_view import StorageView
    sauv = tmp_path / "F" / "Sauvegardes ORION" / "A"
    sauv.mkdir(parents=True)
    a = Game(title="A", source="steam", source_id="1", install_dir="C:\\A",
             size_bytes=3 * 1024 ** 3, extra={"sauvegardes_disque": [
                 {"chemin": str(sauv), "date": time.time(), "octets": 3 * 1024 ** 3,
                  "fichiers": 12, "version": "1.0"},
                 {"chemin": "G:\\Sauvegardes ORION\\A", "date": 1, "octets": 1}]})
    b = Game(title="B", source="steam", source_id="2", install_dir="C:\\B",
             extra={"missing": True, "sauvegardes_disque": [{"chemin": str(sauv), "date": 1}]})
    hw = HardwareInfo()
    entries = inventory([a, b], hw)
    v = StorageView()
    v.set_data(entries, disks_in_use(entries, hw), hw)
    return v, a, b, sauv


def test_vue_montre_et_pilote_les_sauvegardes(app, tmp_path):
    from PySide6.QtWidgets import QFrame, QPushButton
    v, a, b, sauv = _vue_avec_donnees(tmp_path)
    assert v.table.columnCount() == 7
    assert v.table.horizontalHeaderItem(5).text() == "Sauvegarde"
    assert any(c.sauvegardes.text().startswith("1 sauvegarde") for c in v._cards)
    v.table.setCurrentCell(0, 0)
    assert v.sauvegardes_titre.text() == "Sauvegardes de A"

    def lignes_montrees():
        return [w for w in v.carte_sauvegardes.findChildren(QFrame)
                if w.objectName() == "SauvegardeLigne" and not w.signalsBlocked()]

    # la presence des sauvegardes est verifiee hors du fil d'affichage (un
    # disque externe en veille figeait la fenetre) : d'abord « verification »
    assert sorted(w.property("etat") for w in lignes_montrees()) == ["inconnue"] * 2
    _attendre(app, lambda: "inconnue" not in [w.property("etat") for w in lignes_montrees()])
    lignes = lignes_montrees()
    assert len(lignes) == 2
    etats = sorted(w.property("etat") for w in lignes)
    assert etats == ["absente", "presente"]            # G: est introuvable
    recu = []
    v.restaurer_requested.connect(lambda uid, c: recu.append(("r", uid, c)))
    v.supprimer_sauvegarde_requested.connect(lambda uid, c: recu.append(("s", uid, c)))
    presente = next(w for w in lignes if w.property("etat") == "presente")
    for bouton in presente.findChildren(QPushButton):
        if bouton.text() in ("Restaurer la sauvegarde", "Supprimer la sauvegarde"):
            bouton.click()
    assert recu == [("r", a.uid, str(sauv)), ("s", a.uid, str(sauv))]
    sauver = []
    v.sauvegarder_requested.connect(sauver.append)
    assert v.sauvegarder.text() == "Sauvegarder sur un autre disque"
    v.sauvegarder.click()
    assert sauver == [a.uid]
    # jeu desinstalle : on peut restaurer, pas desinstaller ni sauvegarder
    v.table.setCurrentCell(1, 0)
    assert not v.uninstall.isEnabled() and not v.sauvegarder.isEnabled()
    # pendant une copie, plus rien ne lance une autre operation
    v.table.setCurrentCell(0, 0)
    v.set_occupe(True)
    assert not v.sauvegarder.isEnabled()
    boutons = [b for b in v.carte_sauvegardes.findChildren(QPushButton)
               if b.text() == "Restaurer la sauvegarde" and b.parent().parent() is not None]
    assert boutons and not any(b.isEnabled() for b in boutons)


def _vue_de_tri(app):
    from orion.core.models import Game, HardwareInfo
    from orion.storage import disks_in_use, inventory
    from orion.ui.views.storage_view import StorageView
    jour = 86400
    maintenant = time.time()
    jeux = [
        Game(title="Gros Dormeur", source="steam", source_id="1", install_dir="C:\\G",
             size_bytes=120 * 1024 ** 3, last_played=maintenant - 300 * jour,
             play_seconds=7200),
        Game(title="Actif", source="steam", source_id="2", install_dir="D:\\A",
             size_bytes=40 * 1024 ** 3, last_played=maintenant - 2 * jour,
             play_seconds=360000),
        Game(title="Jamais Lance", source="epic", source_id="3", install_dir="C:\\J",
             size_bytes=60 * 1024 ** 3, installed_at=maintenant - 40 * jour),
        Game(title="Petit Sauve", source="gog", source_id="4", install_dir="D:\\P",
             size_bytes=2 * 1024 ** 3, last_played=maintenant - 5 * jour,
             play_seconds=5000,
             extra={"sauvegardes_disque": [{"chemin": "F:\\Sauvegardes ORION\\P",
                                            "date": maintenant, "octets": 2 * 1024 ** 3}]}),
    ]
    hw = HardwareInfo()
    entries = inventory(jeux, hw)
    v = StorageView()
    v.set_data(entries, disks_in_use(entries, hw), hw)
    return v, jeux


def _titres_stockage(v):
    return [v.table.item(r, 0).text() for r in range(v.table.rowCount())]


def test_la_liste_se_trie_en_cliquant_un_en_tete(app):
    from orion.ui.views import storage_view as sv
    v, _jeux = _vue_de_tri(app)
    assert _titres_stockage(v) == ["Gros Dormeur", "Jamais Lance", "Actif", "Petit Sauve"]
    v.trier_par(sv.COL_JEU)
    assert _titres_stockage(v) == ["Actif", "Gros Dormeur", "Jamais Lance", "Petit Sauve"]
    v.trier_par(sv.COL_JEU)                              # second clic : sens inverse
    assert _titres_stockage(v)[0] == "Petit Sauve"
    v.trier_par(sv.COL_TEMPS)                            # les plus joues d'abord
    assert _titres_stockage(v)[0] == "Actif"
    v.trier_par(sv.COL_DERNIERE)                         # jamais lance, puis le plus ancien
    assert _titres_stockage(v)[:2] == ["Jamais Lance", "Gros Dormeur"]
    v.trier_par(sv.COL_ETAT)                             # ce qui dort d'abord
    assert set(_titres_stockage(v)[:2]) == {"Gros Dormeur", "Jamais Lance"}
    v.trier_par(sv.COL_SAUVEGARDE)
    assert _titres_stockage(v)[0] == "Petit Sauve"
    entete = v.table.horizontalHeader()
    assert entete.sortIndicatorSection() == sv.COL_SAUVEGARDE


def test_le_tri_garde_le_jeu_choisi_et_les_desinstalles_a_la_fin(app, tmp_path):
    from orion.ui.views import storage_view as sv
    v, a, b, _sauv = _vue_avec_donnees(tmp_path)
    v.table.setCurrentCell(0, 0)
    assert v._selected_uid() == a.uid
    v.trier_par(sv.COL_JEU)
    v.trier_par(sv.COL_JEU)                              # Z -> A
    assert v._selected_uid() == a.uid                    # la selection suit le jeu
    assert _titres_stockage(v) == ["A", "B"]             # B (desinstalle) reste dernier


def test_filtres_ce_qui_dort_et_sauvegardes(app):
    v, _jeux = _vue_de_tri(app)
    assert v.filtres["tout"].text().endswith("4")
    assert v.filtres["dormants"].text().endswith("2")
    assert v.filtres["sauvegardes"].text().endswith("1")
    v.table.setCurrentCell(2, 0)                         # « Actif »
    v.filtres["dormants"].click()
    assert _titres_stockage(v) == ["Gros Dormeur", "Jamais Lance"]
    assert v._selected_uid() == ""                       # « Actif » n'est plus affiche
    assert not v.uninstall.isEnabled()
    assert "180 Go affiches" in v.summary.text()
    v.filtres["sauvegardes"].click()
    assert _titres_stockage(v) == ["Petit Sauve"]
    v._choose("C:")                                      # les compteurs suivent le disque
    assert v.filtres["dormants"].text().endswith("2") and v.filtres["tout"].text().endswith("2")
    v.filtrer("tout")
    assert _titres_stockage(v) == ["Gros Dormeur", "Jamais Lance"]
    v._choose("*")
    assert len(_titres_stockage(v)) == 4 and "rien ne dort" not in v.summary.text()


def test_recherche_dans_le_stockage(app):
    v, _jeux = _vue_de_tri(app)
    v.recherche.setText("dorm")
    assert _titres_stockage(v) == ["Gros Dormeur"]
    v.recherche.setText("jamais lancé")                  # accents, casse
    assert _titres_stockage(v) == ["Jamais Lance"]
    v.recherche.setText("")
    assert len(_titres_stockage(v)) == 4


def test_double_clic_ouvre_la_fiche_d_un_jeu_installe(app, tmp_path):
    v, a, b, _sauv = _vue_avec_donnees(tmp_path)
    ouverts = []
    v.ouvrir_fiche_requested.connect(ouverts.append)
    v._double_clic(0, 0)
    v._double_clic(1, 3)                                 # B est desinstalle : rien
    v._double_clic(9, 0)
    assert ouverts == [a.uid]


def test_la_presence_d_une_sauvegarde_ne_bloque_pas_l_affichage(app, monkeypatch):
    """Un disque externe en veille met des secondes a repondre : la question
    est posee dans un fil de fond, la ligne dit « verification... »."""
    import threading
    from orion.ui.views import storage_view as sv
    feu_vert = threading.Event()
    fils = []
    vrai = sv.os.path.isdir
    cible = "F:\\Sauvegardes ORION\\P"

    def lent(chemin):
        if chemin != cible:              # d'autres fils du programme s'en servent
            return vrai(chemin)
        fils.append(threading.current_thread().name)
        feu_vert.wait(5)
        return True
    monkeypatch.setattr(sv.os.path, "isdir", lent)
    p = sv.Presences()
    recus = []
    p.connue.connect(lambda c, ok: recus.append((c, ok)))
    debut = time.monotonic()
    assert p.lire("F:\\Sauvegardes ORION\\P") is None      # rend la main tout de suite
    assert p.lire("F:\\Sauvegardes ORION\\P") is None      # une seule question a la fois
    assert time.monotonic() - debut < 0.5
    feu_vert.set()
    _attendre(app, lambda: bool(recus))
    assert recus == [("F:\\Sauvegardes ORION\\P", True)]
    assert fils == ["orion-presence"]
    assert p.lire("F:\\Sauvegardes ORION\\P") is True       # gardee en memoire
    assert len(fils) == 1


def test_vue_recalcul_et_progression(app, tmp_path):
    v, *_ = _vue_avec_donnees(tmp_path)
    demandes = []
    v.recalcul_requested.connect(lambda: demandes.append(1))
    v.refresh.click()
    assert demandes == [1]
    v.set_calcul(True, "mesure en cours...")
    assert not v.refresh.isEnabled() and v.refresh.text() == "Calcul en cours..."
    v.progression_calcul("Mesure des jeux (1/2)", 40)
    assert v.refresh.text() == "Calcul... 40 %"
    v.set_calcul(False, "calcule a 14:32")
    assert v.refresh.isEnabled() and v.calcul_info.text() == "calcule a 14:32"

    annule = []
    v.annuler_requested.connect(lambda: annule.append(1))
    v.debut_copie("Sauvegarde de A", "vers F:\\Sauvegardes ORION\\A", True)
    assert not v.copie.isHidden()
    v.progression_copie("1,0 Go sur 4,0 Go  ·  environ 2 min restantes\nbin\\a.pak", 25)
    assert v.copie.pourcent.text() == "25 %" and v.copie.barre.value() == 25
    assert v.copie.detail.text().startswith("1,0 Go sur 4,0 Go")
    assert "a.pak" in v.copie.fichier.text()
    v.copie.bouton.click()
    assert annule == [1] and not v.copie.bouton.isEnabled()
    v.fin_copie()
    assert v.copie.isHidden()


# ----------------------------------------------------------------------
# fenetre : recalcul, sauvegarde et restauration de bout en bout
# ----------------------------------------------------------------------
class _Biblio:
    def __init__(self, jeux):
        self.jeux = {g.uid: g for g in jeux}
        self.sauvee = 0

    def get(self, uid):
        return self.jeux.get(uid)

    def games(self, include_hidden=False):
        return list(self.jeux.values())

    def save(self):
        self.sauvee += 1


def _hote(jeux, hw):
    from PySide6.QtWidgets import QLabel, QWidget
    from orion.storage import disks_in_use, inventory
    from orion.ui.comptes_mixin import StockageMixin
    from orion.ui.views.storage_view import StorageView

    class Hote(StockageMixin, QWidget):
        def __init__(self):
            super().__init__()
            self.storage_view = StorageView()
            self.library = _Biblio(jeux)
            self.hw = hw
            self.status_label = QLabel()
            self.notes = []
            self.en_cours = set()
            self._init_stockage()

        def refresh_storage(self):
            entries = inventory(self.library.games(), self.hw)
            self.storage_view.set_data(entries, disks_in_use(entries, self.hw), self.hw)

        def notify(self, message, seconds=6):
            self.notes.append(message)

        def _jeu_en_cours(self, game):
            return game.uid in self.en_cours
    return Hote()


def test_recalculer_mesure_vraiment(app, tmp_path):
    from orion.core.models import Game, HardwareInfo
    src = _jeu_factice(tmp_path / "C" / "MonJeu")
    g = Game(title="Mon Jeu", source="steam", source_id="1", install_dir=str(src),
             size_bytes=999)                           # taille annoncee, fausse
    hw = HardwareInfo()
    hw.disks = [{"mount": str(tmp_path), "total_gb": 0, "free_gb": 0}]
    h = _hote([g], hw)
    h.storage_view.refresh.click()                      # le vrai bouton
    assert not h.storage_view.refresh.isEnabled()      # occupe tout de suite
    _attendre(app, lambda: h.storage_view.refresh.isEnabled())
    assert g.size_bytes == 51_000 and h.library.sauvee == 1
    assert hw.disks[0]["total_gb"] > 0
    assert h.storage_view.calcul_info.text().startswith("calcule a ")
    assert h.storage_view._all and h.storage_view._all[0].game is g


def test_sauvegarder_puis_restaurer_depuis_la_page(app, tmp_path, sd, monkeypatch):
    from PySide6.QtWidgets import QInputDialog, QMessageBox
    from orion.core.models import Game, HardwareInfo
    src = _jeu_factice(tmp_path / "C" / "MonJeu")
    avant = _contenu(src)
    g = Game(title="Mon Jeu", source="steam", source_id="1", install_dir=str(src),
             size_bytes=51_000, extra={"version": "2.0"})
    h = _hote([g], HardwareInfo())
    disque = str(tmp_path / "F")
    monkeypatch.setattr(sd, "disques_sauvegarde", lambda disques, dossier: [
        {"lettre": disque, "libre_go": 500, "total_go": 1000, "amovible": False}])
    monkeypatch.setattr(QInputDialog, "getItem", lambda *a, **k: (a[3][0], True))
    fins = []
    monkeypatch.setattr(type(h), "_dialogue_fin",
                        lambda self, titre, texte, details, dossier, restes:
                        fins.append((titre, details, dossier)))

    # jeu lance : refus
    h.en_cours.add(g.uid)
    infos = []
    monkeypatch.setattr(QMessageBox, "information", lambda *a: infos.append(a[2]))
    h.sauvegarder_jeu(g.uid)
    assert "Quittez le jeu" in infos[-1] and not h._deplacement_en_cours
    h.en_cours.clear()

    h.sauvegarder_jeu(g.uid)
    assert h._deplacement_en_cours and h._lancement_bloque(g)
    assert not h.storage_view.copie.isHidden()
    _attendre(app, lambda: not h._deplacement_en_cours)
    chemin = str(tmp_path / "F" / "Sauvegardes ORION" / "Mon Jeu")
    assert fins[-1][0] == "Sauvegarde terminee" and fins[-1][2] == chemin
    assert "Emplacement" in fins[-1][1] and "Duree" in fins[-1][1]
    assert g.extra["sauvegardes_disque"][0]["chemin"] == chemin
    assert g.extra["sauvegardes_disque"][0]["version"] == "2.0"
    assert h.storage_view.copie.isHidden() and _contenu(src) == avant

    # restauration : le jeu est present, il faut un accord explicite
    (src / "jeu.exe").write_bytes(b"abime")
    h.en_cours.add(g.uid)
    h.restaurer_sauvegarde(g.uid, chemin)
    assert "Quittez le jeu" in infos[-1] and not h._deplacement_en_cours
    h.en_cours.clear()
    textes = []

    def exec_boite(boite):
        textes.append(boite.text())
        bouton = next(b for b in boite.buttons() if b.text() == "Remplacer les fichiers actuels")
        bouton.click()
        return 0
    monkeypatch.setattr(QMessageBox, "exec", exec_boite)
    h.restaurer_sauvegarde(g.uid, chemin)
    assert textes == ["Remplacer les fichiers actuels de Mon Jeu ?"]
    _attendre(app, lambda: not h._deplacement_en_cours)
    assert fins[-1][0] == "Restauration terminee" and _contenu(src) == avant


def test_annuler_depuis_la_page(app, tmp_path, sd, monkeypatch):
    from PySide6.QtWidgets import QInputDialog, QMessageBox
    from orion.core.models import Game, HardwareInfo
    src = _jeu_factice(tmp_path / "C" / "MonJeu")
    g = Game(title="Mon Jeu", source="steam", source_id="1", install_dir=str(src))
    h = _hote([g], HardwareInfo())
    monkeypatch.setattr(sd, "disques_sauvegarde", lambda disques, dossier: [
        {"lettre": str(tmp_path / "F"), "libre_go": 500, "total_go": 1000}])
    monkeypatch.setattr(QInputDialog, "getItem", lambda *a, **k: (a[3][0], True))
    infos = []
    monkeypatch.setattr(QMessageBox, "information", lambda *a: infos.append(a[2]))
    # la copie attend que l'annulation soit demandee
    vrai = sd.copier_dossier

    def copier_lent(src_, dst, total, progress_cb=None, annulation=None):
        fin = time.monotonic() + 5
        while not annulation.demandee and time.monotonic() < fin:
            time.sleep(0.01)
        return vrai(src_, dst, total, progress_cb, annulation)
    monkeypatch.setattr(sd, "copier_dossier", copier_lent)
    h.sauvegarder_jeu(g.uid)
    h.storage_view.copie.bouton.click()                 # « Annuler »
    _attendre(app, lambda: not h._deplacement_en_cours)
    assert "annulee" in infos[-1]
    assert "sauvegardes_disque" not in g.extra
    assert not any((tmp_path / "F" / "Sauvegardes ORION").iterdir())


def test_supprimer_depuis_la_page(app, tmp_path, sd, monkeypatch):
    from PySide6.QtWidgets import QMessageBox
    from orion.core.models import Game, HardwareInfo
    src = _jeu_factice(tmp_path / "C" / "MonJeu")
    r = sd.sauvegarder(str(src), str(tmp_path / "F"), "MonJeu")
    g = Game(title="Mon Jeu", source="steam", source_id="1", install_dir=str(src))
    sd.noter(g, r)
    h = _hote([g], HardwareInfo())
    monkeypatch.setattr(QMessageBox, "question",
                        lambda *a, **k: QMessageBox.StandardButton.Yes)
    h.supprimer_sauvegarde(g.uid, r["chemin"])
    _attendre(app, lambda: not h._deplacement_en_cours)
    assert not Path(r["chemin"]).exists() and "sauvegardes_disque" not in g.extra
    assert (src / "jeu.exe").exists()


def test_fermeture_pendant_une_copie(app, monkeypatch):
    from PySide6.QtWidgets import QMessageBox
    from orion.core.models import HardwareInfo
    from orion.sauvegarde_disque import Annulation
    h = _hote([], HardwareInfo())
    assert h._stockage_fermeture_permise()
    h._deplacement_en_cours, h._annulation = True, Annulation()
    monkeypatch.setattr(QMessageBox, "question", lambda *a, **k: QMessageBox.StandardButton.No)
    assert not h._stockage_fermeture_permise() and not h._annulation.demandee
    monkeypatch.setattr(QMessageBox, "question", lambda *a, **k: QMessageBox.StandardButton.Yes)
    assert h._stockage_fermeture_permise() and h._annulation.demandee


def test_un_jeu_installe_cette_semaine_n_est_pas_dit_dormant():
    from orion.core.models import Game, HardwareInfo
    from orion.storage import analyse
    maintenant = time.time()
    neuf = Game(title="Tout Neuf", source="steam", source_id="1", install_dir="C:\\N",
                size_bytes=80 * 1024 ** 3, installed_at=maintenant - 2 * 86400)
    oublie = Game(title="Oublie", source="steam", source_id="2", install_dir="C:\\O",
                  size_bytes=80 * 1024 ** 3, installed_at=maintenant - 60 * 86400)
    sans_date = Game(title="Sans Date", source="dossier", source_id="3", install_dir="C:\\S",
                     size_bytes=80 * 1024 ** 3)
    titres = [c.game.title for c in analyse([neuf, oublie, sans_date], HardwareInfo())]
    assert "Tout Neuf" not in titres
    assert set(titres) == {"Oublie", "Sans Date"}
