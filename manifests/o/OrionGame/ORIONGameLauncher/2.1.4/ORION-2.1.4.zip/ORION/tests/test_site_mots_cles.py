"""Site 218 (13 octobre 2026) : mots-clés « paramètres », « FPS », « mon PC
peut-il faire tourner », pages par type de PC, soldes Steam, guide FPS,
RX 9060 XT, pied de page et compte TikTok."""
import datetime as dt
import json
import re
import sys
from pathlib import Path

RACINE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RACINE / "service" / "site"))
import assembler  # noqa: E402
import gen_evenements as ev  # noqa: E402
import gen_guides  # noqa: E402
import gen_jeux  # noqa: E402
import soldes_steam as st  # noqa: E402

MIN = ("Minimale :\nSystème d'exploitation : Windows 10\nProcesseur : Processeur Intel Core i5-8400\n"
       "Mémoire vive : 8 Go de mémoire\nGraphiques : GeForce GTX 1060 6 Go")
REC = ("Recommandée :\nSystème d'exploitation : Windows 10\nProcesseur : Intel Core i7-10700\n"
       "Mémoire vive : 16 Go de mémoire\nGraphiques : GeForce RTX 3070")


def test_elision_et_nombre_de_cartes():
    assert gen_jeux.de("Elden Ring") == "d'Elden Ring" and gen_jeux.de("Écho") == "d'Écho"
    assert gen_jeux.de("Cyberpunk 2077") == "de Cyberpunk 2077" and gen_jeux.de("Hades") == "de Hades"
    assert gen_jeux.NB_CARTES == len(gen_jeux.CARTES)
    assert ("rx 9060 xt", "Radeon RX 9060 XT", 16) in gen_jeux.CARTES


def _site(tmp_path):
    site = tmp_path / "site"
    site.mkdir()
    (site / "index.html").write_text("<html><head><style>body{}</style></head></html>", encoding="utf-8")
    (site / "sitemap.xml").write_text("<urlset>\n  <url>\n    <loc>https://orion-launcher.com/mentions-legales"
                                      "</loc>\n  </url>\n</urlset>\n", encoding="utf-8")
    jeux = {str(1000 + i): {"n": f"Action {i}" if i else "Elden Ring", "d": "1 janv. 2024", "g": ["Action"],
                            "dev": "Studio", "min": MIN, "rec": REC, "avis": 1000 - i} for i in range(6)}
    f = tmp_path / "jeux.json"
    f.write_text(json.dumps(jeux, ensure_ascii=False), encoding="utf-8")
    gen_jeux.main(site, f)
    return site


def test_page_de_jeu_parametres_fps_et_mon_pc(tmp_path):
    site = _site(tmp_path)
    p = (site / "jeux" / "elden-ring.html").read_text(encoding="utf-8")
    titre = re.search(r"<title>(.*?)</title>", p).group(1)
    assert "paramètres" in titre and "FPS" in titre and len(titre) <= gen_jeux.TITRE_MAX
    assert "<h1>Elden Ring : configuration requise, paramètres et FPS sur PC</h1>" in p
    desc = re.search(r'name="description" content="([^"]*)"', p).group(1)
    assert "d&#x27;Elden Ring" in desc and "de Elden" not in p and len(desc) <= gen_jeux.DESC_MAX
    faq = re.findall(r"<summary>(.*?)</summary>", p)
    assert faq[0] == "Mon PC peut-il faire tourner Elden Ring ?"
    assert "Combien de FPS sur Elden Ring avec une RTX 4060 ?" in faq
    reponse = re.search(r"<summary>Mon PC peut-il.*?<p>(.*?)</p>", p).group(1)
    assert "processeur : Intel Core i5-8400" in reponse and "processeur : Processeur" not in reponse
    assert "mémoire vive : 8 Go" in reponse and "GeForce RTX 3070" in reponse
    ld = [json.loads(x) for x in re.findall(r'<script type="application/ld\+json">(.*?)</script>', p)]
    assert ld[1]["mainEntity"][0]["name"] == "Mon PC peut-il faire tourner Elden Ring ?"
    perf = re.search(r'<table class="perf">.*?</table>', p, re.S).group(0)
    assert perf.count('<th scope="row">') == len(gen_jeux.CARTES) and "radeon-rx-9060-xt" in perf


def test_pages_par_type_de_pc(tmp_path):
    site = _site(tmp_path)
    for k in gen_jeux.TYPES_PC:
        p = (site / "jeux" / f"{k}.html").read_text(encoding="utf-8")
        assert len(re.search(r"<title>(.*?)</title>", p).group(1)) <= gen_jeux.TITRE_MAX
        assert f'<link rel="canonical" href="https://orion-launcher.com/jeux/{k}">' in p
        for n in (6, 999):                     # avec beaucoup de jeux aussi, la description tient
            assert len(gen_jeux.ajuste([x.format(n=n) for x in gen_jeux.TYPES_PC[k]["desc"]],
                                       gen_jeux.DESC_MAX)) <= gen_jeux.DESC_MAX
        for autre in gen_jeux.TYPES_PC:
            if autre != k:
                assert f'href="/jeux/{autre}"' in p
    index = (site / "jeux.html").read_text(encoding="utf-8")
    assert all(f'href="/jeux/{k}"' in index for k in gen_jeux.TYPES_PC)
    plan = (site / "sitemap.xml").read_text(encoding="utf-8")
    assert all(f"/jeux/{k}</loc>" in plan for k in gen_jeux.TYPES_PC)
    # une puce de portable est lue comme l'application la lit (« Laptop GPU »)
    exig = gen_jeux.choisir({"1": {"n": "Jeu", "d": "1 janv. 2024", "g": ["Action"], "min": MIN, "rec": REC}},
                            {}, None)[0][0]["exig"]
    portable = gen_jeux.evaluer_puce(exig, "NVIDIA GeForce RTX 3050 Laptop GPU", 4, gen_jeux.DEFS[0])
    bureau = gen_jeux.evaluer_puce(exig, "NVIDIA GeForce RTX 3050", 4, gen_jeux.DEFS[0])
    assert portable.fps["haute"][0] < bureau.fps["haute"][0]


def test_calendrier_steam():
    assert st.heure_paris(dt.date(2026, 12, 17)) == 19
    assert st.heure_paris(dt.date(2027, 3, 18)) == 18           # l'Amerique passe a l'heure d'ete avant
    assert st.prochaine(dt.date(2026, 10, 13))[0] == "Soldes d'hiver 2026"
    assert st.prochaine(dt.date(2026, 12, 20))[0] == "Soldes d'hiver 2026"   # en cours
    assert st.au_black_friday(dt.date(2026, 11, 27)) is None
    assert st.periode(dt.date(2026, 10, 1), dt.date(2026, 10, 8)) == "du 1er au 8 octobre 2026"
    assert st.periode(dt.date(2026, 12, 17), dt.date(2027, 1, 4)) == "du 17 décembre 2026 au 4 janvier 2027"


def test_black_friday_ne_promet_plus_les_soldes_steam():
    p = ev.page_black_friday([], dt.date(2026, 10, 13), "")
    assert "chaque année" not in p
    assert "Steam n&#x27;a pas de soldes cette semaine-là" in p and "17 décembre 2026" in p
    assert 'href="/soldes-steam"' in p
    p27 = ev.page_black_friday([], dt.date(2027, 10, 13), "")
    assert "pas encore annoncé la date de ses soldes d&#x27;automne 2027" in p27


def test_page_soldes_steam():
    p = gen_guides.page_soldes(dt.date(2026, 10, 13), "")
    titre = re.search(r"<title>(.*?)</title>", p).group(1)
    assert titre.startswith("Soldes Steam d&#x27;hiver 2026") and len(titre.replace("&#x27;", "'")) <= 60
    assert st.SOURCE in p and "17 décembre 2026" in p and "19 h" in p
    assert 'data-debut="2026-12-17T10:00:00-08:00"' in p
    assert '<tr class="fini"><td>Soldes d&#x27;automne 2026</td>' in p
    assert "date pas encore annoncée par Valve" in p
    assert '"@type": "FAQPage"' in p and 'href="/bons-plans"' in p
    # pendant les soldes, la page le dit
    pendant = gen_guides.page_soldes(dt.date(2026, 12, 20), "")
    assert "sont en cours, jusqu&#x27;au 4 janvier 2027" in pendant or "sont en cours, jusqu'au 4 janvier 2027" in pendant


def test_guide_fps():
    p = gen_guides.page_fps(dt.date(2026, 10, 13), "")
    assert len(re.search(r"<title>(.*?)</title>", p).group(1)) <= 60
    desc = re.search(r'name="description" content="([^"]*)"', p).group(1)
    assert 70 <= len(desc) <= 155
    assert p.count("<li><b>") == len(gen_guides.ETAPES_FPS) == 10
    assert '"@type": "Article"' in p and '"@type": "FAQPage"' in p
    for lien in ("/jeux/pc-portable", "/jeux/sans-carte-graphique", "/jeux/peu-gourmands", "/pilotes"):
        assert f'href="{lien}"' in p
    assert not re.search(r"\+\s?\d+\s?%", p)                 # aucun gain chiffre invente


PIED_FR = ('<html><body><footer><nav aria-label="Liens du pied de page">\n      <a href="/jeux">Jeux</a>\n'
           '      <a href="/sorties">Calendrier des sorties</a>\n      <a href="/versions">Versions</a>\n'
           '    </nav></footer></body></html>')
PIED_EN = ('<html><body><footer><nav aria-label="Footer links">\n      <a href="/en/games">Games</a>\n'
           '    </nav></footer></body></html>')


def test_pied_de_page_un_seul_endroit(tmp_path):
    (tmp_path / "en").mkdir()
    (tmp_path / "a.html").write_text(PIED_FR, encoding="utf-8")
    (tmp_path / "en" / "b.html").write_text(PIED_EN, encoding="utf-8")
    assert assembler.completer_pieds(tmp_path) == 2
    fr = (tmp_path / "a.html").read_text(encoding="utf-8")
    hrefs = re.findall(r'href="([^"]+)"', fr)
    attendus = [h for h, _ in assembler.ENTREES]
    assert hrefs[hrefs.index("/sorties") + 1:hrefs.index("/sorties") + 1 + len(attendus)] == attendus
    assert hrefs[-1] == assembler.TIKTOK and fr.count(assembler.TIKTOK) == 1
    en = (tmp_path / "en" / "b.html").read_text(encoding="utf-8")
    assert assembler.TIKTOK in en and "/soldes-steam" not in en
    assert assembler.completer_pieds(tmp_path) == 0                  # une seule fois


def test_un_profil_tiktok_n_est_pas_un_courriel(tmp_path):
    assert not assembler.AROBASE.search('<a href="https://www.tiktok.com/@oriongamelauncher">')
    assert assembler.AROBASE.search("Contact : oriongamelauncher@gmail.com")
    (tmp_path / "index.html").write_text(
        '<html><head><script type="application/ld+json">{"@type": "SoftwareApplication", "name": "ORION"}'
        '</script></head><body></body></html>', encoding="utf-8")
    assembler.profils_publics(tmp_path)
    d = json.loads(re.search(r'<script type="application/ld\+json">(.*?)</script>',
                             (tmp_path / "index.html").read_text(encoding="utf-8"), re.S).group(1))
    assert assembler.TIKTOK in d["sameAs"] and any("apps.microsoft.com" in x for x in d["sameAs"])


def test_sources_de_l_accueil_et_des_pages_ont_les_memes_entrees():
    for f in (RACINE / "service" / "site" / "gen_jeux.py", RACINE / "service" / "site" / "accueil" / "corps.html"):
        t = f.read_text(encoding="utf-8")
        assert all(f'href="{h}"' in t for h, _ in assembler.ENTREES), f.name
        assert assembler.TIKTOK in t, f.name
