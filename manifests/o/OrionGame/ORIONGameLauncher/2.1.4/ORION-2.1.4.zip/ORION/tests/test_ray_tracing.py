"""Jeux qui exigent le ray tracing materiel (13 octobre 2026, le soir).

DOOM: The Dark Ages, Indiana Jones et le Cercle Ancien et Ace Combat 8 ne
demarrent que sur une carte qui calcule le ray tracing. Le site les donnait
jouables sur GTX 1660 Super (« Bas, 42–58 i/s ») et sur RX 580.
"""
import sys
from dataclasses import asdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "service" / "site"))

from orion.puissance import exigences as X  # noqa: E402
from orion.puissance import lecture  # noqa: E402
from orion.puissance.estimation import NOTE_RAY_TRACING, Machine, estimer  # noqa: E402
from orion.puissance.exigences import Exigences, exige_ray_tracing, lire_config  # noqa: E402
from orion.puissance.references import indice_gpu, ray_tracing_materiel  # noqa: E402

DOOM_MIN = ("Minimale :\nSystème d'exploitation : Windows 10 64-Bit / Windows 11 64-Bit\n"
            "Processeur : AMD Ryzen 7 3700X or better, or Intel Core i7 10700K or better\n"
            "Mémoire vive : 16 GB de mémoire\nGraphiques : NVIDIA or AMD hardware Raytracing-capable GPU with 8GB "
            "dedicated VRAM or better (examples: NVIDIA RTX 2060 SUPER or better, AMD RX 6600 or better)\n"
            "Espace disque : 100 GB d'espace disque disponible")
DOOM_REC = ("Recommandée :\nSystème d'exploitation : Windows 10 64-Bit / Windows 11 64-Bit\n"
            "Processeur : AMD Ryzen 7 5700X or better, or Intel Core i7 12700K or better\n"
            "Mémoire vive : 32 GB de mémoire\nGraphiques : NVIDIA or AMD hardware Raytracing-capable GPU with 10GB "
            "dedicated VRAM or better (examples: NVIDIA RTX 3080 or better, AMD RX 6800 or better)")
ORDINAIRE = ("Minimale :\nProcesseur : Intel Core i5-8400\nMémoire vive : 8 Go de mémoire\n"
             "Graphiques : GeForce GTX 1060 6 Go")
RE4 = ("Recommandée :\nGraphiques : AMD Radeon RX 5700 / NVIDIA GeForce GTX 1070\nNotes supplémentaires : "
       "AMD Radeon RX 6700 XT ou NVIDIA GeForce RTX 2060 sont nécessaires pour bénéficier du ray tracing.")


def _machine(nom, vram=8.0):
    return Machine(gpu=indice_gpu(nom)[1], gpu_nom=nom, cpu=80.0, cpu_nom="Ryzen 7 7700", vram_go=vram, ram_go=32.0)


def _doom():
    return Exigences(appid="3017860", titre="DOOM: The Dark Ages", minimum=lire_config(DOOM_MIN),
                     recommandee=lire_config(DOOM_REC))


def test_l_exigence_est_lue_et_pas_l_option():
    assert exige_ray_tracing(DOOM_MIN)
    assert exige_ray_tracing("Notes supplémentaires : SSD required; GPU Hardware Ray Tracing Required; "
                             "Graphic Preset: Low")
    assert exige_ray_tracing("This game requires an SSD, a hardware ray tracing-enabled graphics card, and DirectX 12")
    assert exige_ray_tracing("Carte graphique compatible ray tracing obligatoire")
    assert not exige_ray_tracing(RE4)                                 # seulement pour l'activer
    assert not exige_ray_tracing("Ray tracing: optional, requires an RTX card")
    assert not exige_ray_tracing("Graphiques : GeForce RTX 2060 (ray tracing supported)")
    assert not exige_ray_tracing(ORDINAIRE)
    assert _doom().ray_tracing and not lire_config(ORDINAIRE).ray_tracing


def test_les_cartes_qui_le_calculent():
    oui = ["NVIDIA GeForce RTX 2060", "NVIDIA GeForce RTX 3050 Laptop GPU", "AMD Radeon RX 6600", "rx 9060 xt",
           "AMD Radeon RX 6500 XT", "Intel(R) Arc(TM) B580 Graphics", "AMD Radeon 780M Graphics"]
    non = ["NVIDIA GeForce GTX 1660 SUPER", "gtx 1060", "AMD Radeon RX 580 2048SP", "AMD Radeon RX 5700 XT",
           "AMD Radeon RX Vega 64", "Intel(R) Iris(R) Xe Graphics", "Intel(R) UHD Graphics 630", "NVIDIA GeForce MX450"]
    assert all(ray_tracing_materiel(n) is True for n in oui)
    assert all(ray_tracing_materiel(n) is False for n in non)
    # on ne sait pas : jamais declaree incapable
    assert ray_tracing_materiel("AMD Radeon(TM) Graphics") is None
    assert ray_tracing_materiel("Carte inconnue 9000") is None


def test_sans_ray_tracing_le_jeu_ne_se_lance_pas():
    ev = estimer("DOOM", _doom(), _machine("NVIDIA GeForce GTX 1660 SUPER", 6))
    assert ev.bloque == "ray_tracing" and ev.niveau == "insuffisant" and not ev.fps
    assert NOTE_RAY_TRACING in ev.notes and ev.fps_affiche is None
    # meme une carte puissante sans ray tracing (GTX 1080 Ti)
    assert estimer("DOOM", _doom(), _machine("NVIDIA GeForce GTX 1080 Ti", 11)).bloque
    ok = estimer("DOOM", _doom(), _machine("NVIDIA GeForce RTX 3080", 10))
    assert not ok.bloque and ok.niveau in ("haute", "moyenne", "basse") and ok.fps
    assert not estimer("DOOM", _doom(), _machine("AMD Radeon(TM) Graphics", 2)).bloque
    # un jeu ordinaire tourne toujours sur une GTX
    ordinaire = Exigences("1", "Jeu", lire_config(ORDINAIRE), None)
    assert not estimer("Jeu", ordinaire, _machine("NVIDIA GeForce GTX 1660 SUPER", 6)).bloque


def test_l_explication_le_dit_et_propose_une_carte_qui_le_calcule():
    m = _machine("NVIDIA GeForce GTX 1080 Ti", 11)
    ev = estimer("DOOM", _doom(), m)
    x = lecture.expliquer("DOOM", ev, _doom(), m)
    assert x.resume == lecture.RESUME_RAY_TRACING and not x.pistes
    assert x.manque and all("avec ray tracing materiel" in p for p in x.manque)
    assert "GTX" not in " ".join(x.manque)


def test_une_fiche_gardee_est_relue_sans_reseau(base_neuve):
    from orion.core.base import Table
    memo = asdict(_doom())
    for champ in ("minimum", "recommandee"):
        memo[champ].pop("ray_tracing")                 # ecrite par la 2.1.2 d'avant ce soir
    Table("exigences").set("3017860", dict(memo, regle=4, lu_le=9e9))
    assert not X.perimee(Table("exigences").get("3017860"))          # texte complet : pas de Steam
    assert X.en_cache("3017860").ray_tracing
    assert Table("exigences").get("3017860")["regle"] == X.REGLE


def test_le_site_l_affiche():
    import gen_jeux
    import gen_jeux_en
    import reglages
    ev = gen_jeux.evaluer(_doom(), "gtx 1660 super", 6, 1920 * 1080, "1920x1080")
    assert "Ne se lance pas" in gen_jeux.cellule(ev) and "Won't launch" in gen_jeux_en.cellule(ev)
    assert "Ne se lance pas" not in gen_jeux.cellule(gen_jeux.evaluer(_doom(), "rtx 3080", 10, 1920 * 1080,
                                                                      "1920x1080"))
    k = reglages.conseiller(_doom(), "GeForce GTX 1660 Super", 6, 1920, 1080)
    assert k.bloque and "Ne se lance pas" in reglages._cellule(k, "fr")
    assert not reglages.conseiller(_doom(), "GeForce RTX 4060", 8, 1920, 1080).bloque
    texte = gen_jeux.objectif_editeur({"exig": _doom(), "nom": "DOOM: The Dark Ages", "appid": "3017860"})
    assert "exige une carte graphique avec ray tracing matériel" in texte
