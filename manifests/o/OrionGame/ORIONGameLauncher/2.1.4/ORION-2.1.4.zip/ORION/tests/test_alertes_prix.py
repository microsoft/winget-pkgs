"""Alertes de prix (2.0) : seuil fixe par le joueur, ou baisse nette d'un jeu
suivi sans seuil (les jeux importes de la liste de souhaits Steam n'en ont
pas). Le prix de Gamesplanet compte dans la meilleure offre."""
from __future__ import annotations

import time
from types import SimpleNamespace

import pytest


def _item(**k):
    from orion.wishlist import WishItem
    return WishItem(appid=k.pop("appid", "10"), title=k.pop("title", "Hades II"), **k)


def test_quand_prevenir():
    # seuil atteint
    i = _item(target_price=20, current_price=17.49, previous_price=24.99, cut=30)
    assert i.alert() == "seuil"
    i.notified_price = 17.49
    assert i.alert() == ""                                   # deja signale a ce prix
    i.current_price = 15.0
    assert i.alert() == "seuil"                              # encore moins cher : on previent
    # sans seuil : baisse d'au moins 10 % sur un jeu en promotion
    b = _item(current_price=17.49, previous_price=24.99, cut=30)
    assert b.dropped and b.alert() == "baisse" and b.alert(baisses=False) == ""
    assert _item(current_price=23.99, previous_price=24.99, cut=4).alert() == ""      # baisse trop faible
    assert _item(current_price=17.49, previous_price=0, cut=30).alert() == ""         # premiere verification
    assert _item(current_price=17.49, previous_price=24.99, cut=0).alert() == ""      # pas une promotion
    # avec un seuil non atteint, la baisse seule ne previent pas : le joueur a dit son prix
    assert _item(target_price=10, current_price=17.49, previous_price=24.99, cut=30).alert() == ""


def _service(tmp_path, monkeypatch, items):
    from orion import wishlist
    monkeypatch.setattr(wishlist, "WISHLIST_FILE", tmp_path / "envies.json")
    s = wishlist.WishlistService()
    s.items = {i.appid: i for i in items}
    return s


class Marche:
    def __init__(self, prix):
        self.prix = prix          # {appid: (prix, remise, prix normal)}

    def get(self, game, force=False):
        p, cut, base = self.prix[game.source_id]
        offre = SimpleNamespace(price=p, shop="Steam", url="https://store.steampowered.com/app/" + game.source_id, cut=cut)
        return SimpleNamespace(best=offre, current=offre, historical_low=0, review_score=0,
                               base_price=base, adulte=False)


def test_veille_previent_des_baisses_et_des_seuils(base_neuve, tmp_path, monkeypatch):
    from orion.core.config import CONFIG
    CONFIG.set("wishlist.alerte_baisse", True)
    s = _service(tmp_path, monkeypatch, [
        _item(appid="1", title="Seuil", target_price=20, current_price=24.99),
        _item(appid="2", title="Baisse", current_price=24.99),
        _item(appid="3", title="Stable", current_price=24.99),
        _item(appid="4", title="Nouveau"),
    ])
    marche = Marche({"1": (17.49, 30, 24.99), "2": (17.49, 30, 24.99), "3": (24.99, 0, 24.99), "4": (9.99, 50, 19.99)})
    alertes = s.refresh(marche)
    assert [(a.title, a.alert_kind) for a in alertes] == [("Seuil", "seuil"), ("Baisse", "baisse")]
    assert s.items["2"].previous_price == 24.99 and s.items["4"].previous_price == 0
    # meme prix a la verification suivante : plus rien
    assert s.refresh(marche) == []
    # le prix remonte, puis rebaisse : la nouvelle promotion est signalee
    marche.prix["2"] = (24.99, 0, 24.99)
    assert s.refresh(marche) == [] and s.items["2"].notified_price == 0
    marche.prix["2"] = (12.49, 50, 24.99)
    assert [a.title for a in s.refresh(marche)] == ["Baisse"]
    # option coupee : seuls les seuils previennent
    CONFIG.set("wishlist.alerte_baisse", False)
    try:
        marche.prix["3"] = (9.99, 60, 24.99)
        assert s.refresh(marche) == []
    finally:
        CONFIG.set("wishlist.alerte_baisse", True)


def test_veille_prend_le_prix_gamesplanet(base_neuve, tmp_path, monkeypatch):
    from orion import prix_gamesplanet as G
    from orion.core import region
    monkeypatch.setattr(region, "devise", lambda: "EUR")
    monkeypatch.setattr(region, "pays", lambda: "FR")
    monkeypatch.setitem(G._memo, "releve", time.time())
    monkeypatch.setitem(G._memo, "jeux", {
        "1": [["Moins Cher", 19.99, 39.99, "moins-cher-steam-key--1-1", "steam", "", ""]],
        "2": [["Plus Cher", 35.0, 39.99, "plus-cher-steam-key--2-1", "steam", "", ""]]})
    s = _service(tmp_path, monkeypatch, [
        _item(appid="1", title="Moins Cher", current_price=39.99),
        _item(appid="2", title="Plus Cher", current_price=39.99)])
    alertes = s.refresh(Marche({"1": (29.99, 25, 39.99), "2": (29.99, 25, 39.99)}))
    un, deux = s.items["1"], s.items["2"]
    assert (un.current_price, un.best_shop, un.cut) == (19.99, "Gamesplanet", 50)
    assert un.best_url == "https://fr.gamesplanet.com/game/moins-cher-steam-key--1-1"
    assert (deux.current_price, deux.best_shop) == (29.99, "Steam")
    assert [a.title for a in alertes] == ["Moins Cher", "Plus Cher"]


def test_message_de_la_notification():
    from orion import i18n
    from orion.wishlist import message_alertes
    a = _item(title="Hades II", current_price=17.49, best_shop="Gamesplanet", cut=30, alert_kind="baisse")
    b = _item(title="Elden Ring", current_price=29.99, best_shop="Steam", cut=0, alert_kind="seuil")
    assert message_alertes([]) == ("", "")
    titre, texte = message_alertes([a])
    assert titre == "Baisse de prix" and texte == "Baisse : Hades II a 17,49 € chez Gamesplanet (-30 %)"
    assert message_alertes([b]) == ("Prix voulu atteint", "Prix voulu : Elden Ring a 29,99 € chez Steam")
    titre, texte = message_alertes([a, b, a, b])
    assert titre == "Bons plans reperes" and texte.startswith("4 jeux en baisse ou au prix voulu : Hades II (17,49 €), ") \
        and texte.endswith(" ...")
    # les trois formes sont traduites
    try:
        assert i18n.charger("en")
        assert i18n.traduire(message_alertes([a])[1]) == "Price drop: Hades II at 17,49 € from Gamesplanet (-30 %)"
        assert i18n.traduire(message_alertes([b])[1]).startswith("Target price: Elden Ring at ")
        assert i18n.traduire(message_alertes([a, b])[1]).startswith("2 games on sale or at your target price: ")
        assert i18n.traduire("Bons plans reperes") == "Deals spotted"
        assert i18n.charger("fr")
        assert i18n.traduire(message_alertes([a])[1]) == "Baisse : Hades II à 17,49 € chez Gamesplanet (-30 %)"
    finally:
        i18n._exact.clear(); i18n._modeles.clear(); i18n._mots.clear()
        i18n.traduire.cache_clear()
