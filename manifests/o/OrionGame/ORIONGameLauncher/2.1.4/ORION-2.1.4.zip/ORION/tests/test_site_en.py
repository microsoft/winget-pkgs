"""Pages anglaises du site (2.0.2) : generees depuis l'accueil francais,
version/taille/empreinte reprises, hreflang dans les deux sens, sitemap."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "service" / "site"))
import gen_en  # noqa: E402

TETE = """<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>ORION lit votre PC</title>
<meta name="description" content="Accueil FR.">
<link rel="canonical" href="https://orion-launcher.com/">
<meta property="og:locale" content="fr_FR">
<meta property="og:url" content="https://orion-launcher.com/">
<meta property="og:title" content="Titre FR">
<meta property="og:description" content="Desc FR">
<script type="application/ld+json">
{"@type": "SoftwareApplication"}
</script>
<style>.lede{color:red}</style>
</head>
"""
ACCUEIL = TETE + """<body>
<p>Version 2.0.2, Windows 10 et 11 en 64 bits, 283 Mo</p>
<p class="hash">0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef</p>
</body>
</html>
"""
ENVOIE = TETE.replace('href="https://orion-launcher.com/"', 'href="https://orion-launcher.com/ce-qu-orion-envoie"') + "<body>\n<p>FR</p>\n</body>\n</html>\n"
PLAN = """<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://orion-launcher.com/</loc>
  </url>
  <url>
    <loc>https://orion-launcher.com/mentions-legales</loc>
  </url>
</urlset>
"""


def _site(tmp_path):
    (tmp_path / "index.html").write_text(ACCUEIL, encoding="utf-8")
    (tmp_path / "ce-qu-orion-envoie.html").write_text(ENVOIE, encoding="utf-8")
    (tmp_path / "sitemap.xml").write_text(PLAN, encoding="utf-8")
    return tmp_path


def test_accueil_anglais(tmp_path):
    gen_en.main(_site(tmp_path))
    en = (tmp_path / "en" / "index.html").read_text(encoding="utf-8")
    assert '<html lang="en">' in en and "<style>.lede{color:red}</style>" in en
    assert "Version 2.0.2 for Windows 10 and 11" in en and "283 MB" in en
    assert '<p class="hash">0123456789abcdef' in en
    assert '<link rel="canonical" href="https://orion-launcher.com/en/">' in en
    assert 'hreflang="fr" href="https://orion-launcher.com/"' in en
    assert "ld+json" not in en and 'og:locale" content="en_US"' in en
    assert "ORION reads your PC and tells you what to play, with which settings, at what price." in en
    assert "Installateur-ORION.exe" in en and "9P91GMXV7FPW" in en
    # 11 octobre : winget attend la validation de Microsoft, la page ne promet pas la commande
    assert "winget install" not in en and "Coming soon to winget" in en
    assert 'href="/en/what-orion-sends"' in en and 'href="/"' in en


def test_envois_et_hreflang_retour(tmp_path):
    gen_en.main(_site(tmp_path))
    en = (tmp_path / "en" / "what-orion-sends.html").read_text(encoding="utf-8")
    assert '<html lang="en">' in en and "What never leaves" in en
    assert 'hreflang="fr" href="https://orion-launcher.com/ce-qu-orion-envoie"' in en
    fr = (tmp_path / "index.html").read_text(encoding="utf-8")
    assert 'rel="alternate" hreflang="en" href="https://orion-launcher.com/en/"' in fr
    assert 'hreflang="x-default" href="https://orion-launcher.com/"' in fr
    fr2 = (tmp_path / "ce-qu-orion-envoie.html").read_text(encoding="utf-8")
    assert 'hreflang="en" href="https://orion-launcher.com/en/what-orion-sends"' in fr2
    # relance : rien en double
    gen_en.main(tmp_path)
    fr = (tmp_path / "index.html").read_text(encoding="utf-8")
    assert fr.count('hreflang="en"') == 1


def test_sitemap(tmp_path):
    gen_en.main(_site(tmp_path))
    gen_en.main(tmp_path)
    x = (tmp_path / "sitemap.xml").read_text(encoding="utf-8")
    assert x.count("<loc>https://orion-launcher.com/en/</loc>") == 1
    assert x.count("<loc>https://orion-launcher.com/en/what-orion-sends</loc>") == 1
    assert x.index("/en/</loc>") < x.index("/mentions-legales")
