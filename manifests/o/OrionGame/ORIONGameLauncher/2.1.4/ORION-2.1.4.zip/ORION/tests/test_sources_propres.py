"""Un module retire des sources ne doit pas rester dans le dossier compile.

Constat du 7 octobre 2026 : la compilation embarque tout `orion/`
(`--collect-submodules`) et la mise a jour recopie l'archive par-dessus le
dossier sans rien retirer. Un fichier supprime des sources aurait continue
d'etre compile."""
import importlib.util
import zipfile
from pathlib import Path

RACINE = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location("sources_propres", RACINE / "outils" / "sources_propres.py")
sp = importlib.util.module_from_spec(spec)
spec.loader.exec_module(sp)


def _monter(tmp_path, livres, presents):
    dossier = tmp_path / "ORION"
    for nom in presents:
        f = dossier / nom
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text("# essai\n", encoding="utf-8")
    archive = tmp_path / "ORION.zip"
    with zipfile.ZipFile(archive, "w") as z:
        for nom in livres:
            z.writestr("ORION/" + nom, "# essai\n")
    return dossier, archive


def test_un_module_retire_des_sources_est_ecarte_pas_supprime(tmp_path):
    livres = [f"orion/m{i}.py" for i in range(120)] + ["orion/plugins/tweaks/recipes/a.json"]
    presents = livres + ["orion/plugins/scanners/vieux.py", "orion/plugins/tweaks/recipes/vieille.json",
                         "orion/__pycache__/m1.cpython-312.pyc", "tests/test_x.py"]
    dossier, archive = _monter(tmp_path, livres, presents)
    partis = sp.ecarter(dossier, archive, maintenant=0)
    assert [p.as_posix() for p in partis] == ["orion/plugins/scanners/vieux.py",
                                              "orion/plugins/tweaks/recipes/vieille.json"]
    assert not (dossier / "orion/plugins/scanners/vieux.py").exists()
    gardes = list((tmp_path / "_a_supprimer").rglob("vieux.py"))
    assert len(gardes) == 1 and gardes[0].read_text(encoding="utf-8") == "# essai\n"
    assert (dossier / "orion/m5.py").exists() and (dossier / "tests/test_x.py").exists()
    assert sp.ecarter(dossier, archive) == []            # second passage : plus rien


def test_sans_archive_fiable_rien_n_est_touche(tmp_path):
    livres = [f"orion/m{i}.py" for i in range(120)]
    dossier, archive = _monter(tmp_path, livres, livres + ["orion/vieux.py"])
    assert sp.ecarter(dossier, tmp_path / "absente.zip") == []
    # une archive qui n'est pas celle des sources
    dossier2, petite = _monter(tmp_path / "b", ["orion/a.py"], ["orion/a.py", "orion/vieux.py"])
    assert sp.ecarter(dossier2, petite) == [] and (dossier2 / "orion/vieux.py").exists()
    # trop de fichiers en trop : l'archive et le dossier ne vont pas ensemble
    beaucoup = livres + [f"orion/x{i}.py" for i in range(60)]
    dossier3, archive3 = _monter(tmp_path / "c", livres, beaucoup)
    assert sp.ecarter(dossier3, archive3) == [] and (dossier3 / "orion/x1.py").exists()
    assert (dossier / "orion/vieux.py").exists()


def test_la_compilation_lance_la_verification():
    brut = (RACINE / "CONSTRUIRE-EXE.bat").read_bytes()
    script = brut.decode("utf-8")
    assert script.index("sources_propres.py") < script.index("PyInstaller --noconfirm")
    # sources pas a jour : la compilation s'arrete avant PyInstaller
    assert script.index("if errorlevel 3") < script.index("PyInstaller --noconfirm")
    # fichiers .bat en fins de ligne Windows (regle du projet)
    assert brut.count(b"\n") == brut.count(b"\r\n")
    assert brut.isascii()
    # 10 octobre : lance par un autre script, le chemin du script se relisait
    # apres le cd (ORION\\ORION) ; il est lu une fois, avant tout cd
    assert script.index('set "ICI=%~dp0"') < script.index("cd /d")
    assert script.count("%~dp0") == 1
    # lance avec --sans-pause (sortie dans un journal) : aucune attente invisible
    lignes = [l.strip() for l in script.splitlines()]
    assert "pause" not in lignes[:lignes.index('if "%~1"=="--sans-pause" exit /b 0')]
    seul = (RACINE / "outils" / "COMPILER-SEUL.bat").read_bytes()
    assert seul.count(b"\n") == seul.count(b"\r\n") and seul.isascii()
    texte = seul.decode("ascii")
    assert texte.index('set "BASE=%~dp0"') < texte.index("cd /d") and texte.count("%~dp0") == 1
    assert "maj_tmp\\ORION\\*' -Destination '%BASE%ORION'" in texte           # jamais DANS ORION
    assert '"%BASE%ORION\\CONSTRUIRE-EXE.bat" --sans-pause' in texte
    from_build = (RACINE / "outils" / "sources_propres.py").read_text(encoding="utf-8")
    assert "COMPILER-SEUL.bat" in from_build and "COMPILER-SEUL.bat" in script


def _archive(tmp_path, fichiers, version="2.1.0"):
    archive = tmp_path / "ORION.zip"
    with zipfile.ZipFile(archive, "w") as z:
        z.writestr("ORION/orion/version.py", f'APP_VERSION = "{version}"\n')
        for nom, texte in fichiers.items():
            z.writestr("ORION/" + nom, texte)
    return archive


def _poser(dossier, fichiers):
    for nom, texte in fichiers.items():
        f = dossier / nom
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text(texte, encoding="utf-8")


def test_archive_extraite_dans_le_dossier(tmp_path):
    """10 octobre : ORION.zip extrait DANS ORION ; sous Windows « ORION » et
    « orion » sont le meme dossier : tout est tombe dans le paquet, les vrais
    modules sont restes anciens, et la compilation est allee au bout."""
    neuf = {"orion/aide.py": "neuf\n", "CHANGELOG.md": "neuf\n", "tests/test_a.py": "neuf\n"}
    archive = _archive(tmp_path, neuf)
    dossier = tmp_path / "ORION"
    _poser(dossier, {"orion/version.py": 'APP_VERSION = "2.1.0"\n', "orion/aide.py": "vieux\n",
                     "CHANGELOG.md": "vieux\n", "tests/test_a.py": "neuf\n",
                     # la copie imbriquee
                     "orion/orion/aide.py": "neuf\n", "orion/orion/version.py": 'APP_VERSION = "2.1.0"\n',
                     "orion/CHANGELOG.md": "neuf\n", "orion/tests/test_a.py": "neuf\n"})
    partis = sp.ecarter_copie(dossier, archive, maintenant=0)
    assert sorted(p.name for p in partis) == ["CHANGELOG.md", "orion", "tests"]
    assert not (dossier / "orion" / "orion").exists() and (dossier / "orion" / "aide.py").exists()
    assert list((tmp_path / "_a_supprimer").glob("copie-imbriquee-*/orion/aide.py"))
    # les vrais fichiers sont restes anciens : la compilation doit s'arreter
    raison = sp.a_jour(dossier, archive)
    assert "2 fichier(s)" in raison and "orion/aide.py" in raison
    _poser(dossier, {"orion/aide.py": "neuf\r\n", "CHANGELOG.md": "neuf\n"})   # fins de ligne ignorees
    assert sp.a_jour(dossier, archive) == ""
    assert sp.ecarter_copie(dossier, archive) == []


def test_archive_plus_recente_ou_plus_ancienne(tmp_path):
    dossier = tmp_path / "ORION"
    _poser(dossier, {"orion/version.py": 'APP_VERSION = "2.1.0"\n'})
    assert "2.1.1" in sp.a_jour(dossier, _archive(tmp_path, {}, "2.1.1"))
    # dossier plus recent que l'archive (constat du 8 octobre) : pas d'arret
    assert sp.a_jour(dossier, _archive(tmp_path, {"orion/x.py": "1\n"}, "2.0.2")) == ""


def test_le_script_de_compilation_en_cours_n_est_pas_compare(tmp_path):
    archive = _archive(tmp_path, {"CONSTRUIRE-EXE.bat": "nouveau\n"})
    dossier = tmp_path / "ORION"
    _poser(dossier, {"orion/version.py": 'APP_VERSION = "2.1.0"\n', "CONSTRUIRE-EXE.bat": "ancien\n"})
    assert sp.differents(dossier, archive) == []


def test_les_reglages_retires_quittent_le_fichier_de_l_utilisateur(tmp_path, monkeypatch):
    """Menage du 7 octobre 2026 : six reglages que plus rien ne lisait."""
    import json
    from orion.core import config
    for chemin in ("artwork.prefer_animated", "free.country", "perf.min_seconds",
                   "optimizer.close_launcher_on_play", "scan.follow_steam_libraries"):
        bloc, cle = chemin.split(".")
        assert cle not in config.DEFAULTS[bloc], chemin
        assert chemin in config.RETIRES
    assert "integrations" not in config.DEFAULTS and "integrations" in config.RETIRES
    c = config.Config.__new__(config.Config)
    c.data = config._merge(config.DEFAULTS, {"perf": {"min_seconds": 120, "enabled": True},
                                             "integrations": {"claude_api_key": ""},
                                             "free": {"country": "FR"}})
    monkeypatch.setattr(c, "save", lambda *a, **k: None, raising=False)
    assert c._migrate() is True
    assert "min_seconds" not in c.data["perf"] and c.data["perf"]["enabled"] is True
    assert "integrations" not in c.data and "country" not in c.data["free"]
    assert c._migrate() is False
    json.dumps(c.data)


def _version(dossier_ou_archive, version):
    texte = f'APP_VERSION = "{version}"\n'
    if dossier_ou_archive.suffix == ".zip":
        with zipfile.ZipFile(dossier_ou_archive, "a") as z:
            z.writestr("ORION/orion/version.py", texte)
    else:
        (dossier_ou_archive / "orion" / "version.py").write_text(texte, encoding="utf-8")


def test_une_archive_d_une_autre_version_ne_touche_a_rien(tmp_path):
    """8 octobre 2026 : ORION.zip (2.0.1) face au dossier d'essai 2.0.2, les
    sept modules nouveaux de la 2.0.2 ont ete ecartes et la compilation a
    echoue. L'archive doit etre de la version du dossier."""
    livres = [f"orion/m{i}.py" for i in range(120)]
    dossier, archive = _monter(tmp_path, livres, livres + ["orion/bilan.py", "orion/ui/carte.py"])
    _version(dossier, "2.0.2"); _version(archive, "2.0.1")
    assert sp.ecarter(dossier, archive) == []
    assert (dossier / "orion/bilan.py").exists() and (dossier / "orion/ui/carte.py").exists()
    assert sp.archive_de(dossier) is None                 # ORION.zip n'est pas de la bonne version
    # l'archive de la bonne version, a cote, est choisie d'elle-meme
    bonne = tmp_path / "ORION-2.0.2-en-cours.zip"
    with zipfile.ZipFile(bonne, "w") as z:
        for nom in livres + ["orion/bilan.py", "orion/ui/carte.py"]:
            z.writestr("ORION/" + nom, "# essai\n")
    _version(bonne, "2.0.2")
    assert sp.archive_de(dossier) == bonne
    assert sp.ecarter(dossier, bonne) == []
    # meme version : un vrai reste est ecarte
    (dossier / "orion/vieux.py").write_text("# essai\n", encoding="utf-8")
    assert [p.as_posix() for p in sp.ecarter(dossier, bonne, maintenant=0)] == ["orion/vieux.py"]
