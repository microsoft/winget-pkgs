"""L'outil des captures du site vise des widgets qui existent (11 octobre 2026 :
la 2.1.0 avait retire `CarteRecommande`, la capture de la fiche echouait)."""
import re
from pathlib import Path

RACINE = Path(__file__).resolve().parent.parent


def test_les_widgets_vises_par_les_captures_existent():
    from orion.ui.widgets import profile_card
    source = (RACINE / "outils" / "captures_site.py").read_text(encoding="utf-8")
    noms = set(re.findall(r"profile_card\.([A-Za-z_]\w*)", source))
    assert noms, "aucun widget de la fiche vise"
    for nom in noms:
        assert hasattr(profile_card, nom), nom
