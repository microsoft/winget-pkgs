"""« Le processeur freine la carte graphique » seulement quand c'est vrai pour
l'ecran du joueur (10 octobre : Core i9-9900K + RTX 3080 en 2560x1440, la page
Ma machine se contredisait)."""
from types import SimpleNamespace as NS

from orion.hardware import bilan


def _pc(largeur, hauteur):
    from orion.core.models import Display, DisplayMode, GPUInfo, HardwareInfo
    mode = DisplayMode(largeur, hauteur, 180)
    return HardwareInfo(cpu_name="Intel(R) Core(TM) i9-9900K CPU @ 3.60GHz", cpu_cores=8, cpu_threads=16,
                        ram_gb=32, gpus=[GPUInfo(name="NVIDIA GeForce RTX 3080", vendor="nvidia", vram_mb=10240, tier=3)],
                        displays=[Display("\\\\.\\DISPLAY1", "LG", True, mode, mode, 180, [mode])])


def _titres(hw):
    try:
        return {p.title: p.level for p in bilan.analyse(hw)}
    except AttributeError:          # un champ du faux PC manque : le test le dira
        raise


def test_en_1440p_simple_conseil():
    t = _titres(_pc(2560, 1440))
    assert "Le processeur freine la carte graphique" not in t
    assert t.get("Processeur plus ancien que la carte graphique") == "conseil"


def test_en_1080p_alerte():
    t = _titres(_pc(1920, 1080))
    assert t.get("Le processeur freine la carte graphique") == "attention"
