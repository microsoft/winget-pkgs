"""Bibliotheque (2.0, 7 octobre 2026) : filtres rapides, recherche sans
resultat, recherche au clavier, barre d'outils qui tient dans la fenetre."""
from __future__ import annotations

import time

import pytest

from orion.core.models import Game


@pytest.fixture(scope="module")
def app():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


def _jeux():
    maintenant = time.time()
    jour = 86400
    return [
        Game(title="Hades", source="steam", source_id="1", favorite=True,
             last_played=maintenant - 2 * jour, play_seconds=36000),
        Game(title="Control", source="epic", source_id="2",
             last_played=maintenant - 200 * jour, play_seconds=7200),
        Game(title="Portal 2", source="steam", source_id="3"),
        Game(title="Celeste", source="gog", source_id="4",
             last_played=maintenant - 10 * jour, play_seconds=600),
    ]


def _possede():
    return Game(title="Gwent", source="gog", source_id="9", extra={"non_installe": True})


@pytest.fixture
def vue(app):
    from orion.core.config import CONFIG
    from orion.ui.views.library_view import LibraryView
    anciens = {c: CONFIG.get(c) for c in ("ui.sort", "ui.hide_missing", "ui.voir_non_installes")}
    CONFIG.set("ui.sort", "title", save=False)
    CONFIG.set("ui.voir_non_installes", True, save=False)
    v = LibraryView()
    v.resize(1200, 800)
    v.set_games(_jeux())
    v.set_possedes([_possede()])
    yield v
    for c, val in anciens.items():
        CONFIG.set(c, val, save=False)
    v.deleteLater()


def _titres(v):
    return [g.title for g in v.visible_games()]


def test_filtres_rapides_et_leurs_compteurs(vue):
    v = vue
    assert v.filtres["tous"].text() == "Tous  5"
    assert v.filtres["favoris"].text() == "Favoris  1"
    assert v.filtres["recents"].text() == "Joues recemment  2"
    assert v.filtres["jamais"].text() == "Jamais lances  1"      # Gwent n'est pas installe
    v.filtres["recents"].click()
    assert _titres(v) == ["Hades", "Celeste"]                    # le favori reste devant
    v.filtres["jamais"].click()
    assert _titres(v) == ["Portal 2"]
    v.filtres["favoris"].click()
    assert _titres(v) == ["Hades"]
    assert v.count.text().startswith("1 sur 4 jeux")
    v.filtres["tous"].click()
    assert len(_titres(v)) == 5


def test_les_compteurs_suivent_le_filtre_des_sources(vue):
    v = vue
    v.set_source_filter({"steam"})
    assert v.filtres["tous"].text() == "Tous  2"
    assert v.filtres["recents"].text() == "Joues recemment  1"
    v.set_source_filter(None)
    assert v.filtres["tous"].text() == "Tous  5"


def test_le_filtre_rapide_efface_la_banniere(vue):
    v = vue
    v.set_featured(_jeux()[:2])
    assert v.hero._games if hasattr(v.hero, "_games") else True
    v.set_filtre("favoris")
    assert v._filtre == "favoris"
    v.set_filtre("inconnu")                  # cle inconnue : tout
    assert v._filtre == "tous" and v.filtres["tous"].isChecked()


def test_recherche_sans_resultat_propose_la_boutique(vue, app):
    v = vue
    v.show()
    demandes = []
    v.boutique_requested.connect(demandes.append)
    v.search.setText("zelda")
    v.refresh()
    assert not v.aucun.isHidden() and v.holder.isHidden()
    assert "« zelda »" in v.aucun_texte.text()
    assert v.b_boutique.text() == "Chercher « zelda » dans la Boutique"
    assert not v.b_boutique.isHidden() and not v.b_tout_montrer.isHidden()
    v.b_boutique.click()
    assert demandes == ["zelda"]
    v.b_tout_montrer.click()
    assert v.search.text() == "" and v.aucun.isHidden() and not v.holder.isHidden()
    assert len(v._cards) == 5


def test_filtre_sans_resultat_explique_pourquoi(vue):
    v = vue
    for g in v._games:
        g.favorite = False
    v.set_filtre("favoris")
    assert not v.aucun.isHidden()
    assert "Aucun favori" in v.aucun_texte.text()
    assert v.b_boutique.isHidden() and not v.b_tout_montrer.isHidden()
    v.tout_afficher()
    assert v.aucun.isHidden() and v._filtre == "tous"


def test_bibliotheque_vide_garde_son_message_d_accueil(app):
    from orion.ui.views.library_view import LibraryView
    v = LibraryView()
    v.set_games([])
    assert not v.empty.isHidden() and v.aucun.isHidden()
    v.deleteLater()


def test_echap_efface_la_recherche_et_ctrl_f_y_mene(vue, app):
    from PySide6.QtCore import Qt
    from PySide6.QtTest import QTest
    v = vue
    v.show()
    v.activateWindow()
    v.chercher()
    app.processEvents()
    v.search.setText("had")
    QTest.keyClick(v.search, Qt.Key.Key_Escape)
    assert v.search.text() == ""


def test_la_barre_d_outils_tient_a_la_largeur_minimale_de_la_fenetre(app):
    """Fenetre minimale 1080 points, menu 212 : la page dispose de 868 points.
    « Ajouter un jeu » et « Analyser » en sortaient."""
    from PySide6.QtCore import QPoint
    from orion.ui.views.library_view import LibraryView
    v = LibraryView()
    v.set_games(_jeux())
    v.set_possedes([_possede()])
    v.resize(868, 700)
    v.show()
    app.processEvents()
    for bouton in (v.rescan, v.add_game, v.hide_missing, v.voir_possedes, v.sort, v.search):
        assert bouton.mapTo(v, QPoint(bouton.width(), 0)).x() <= 868, bouton
    v.deleteLater()


def test_affichage_salon_enleve_les_filtres(vue):
    v = vue
    v.set_filtre("favoris")
    v.set_big_picture(True)
    assert v._filtre == "tous" and all(b.isHidden() for b in v.filtres.values())
    v.set_big_picture(False)
    assert not any(b.isHidden() for b in v.filtres.values())


# ---------------------------------------------------------------------------
# fenetre : Ctrl+F et recherche envoyee a la Boutique
# ---------------------------------------------------------------------------
@pytest.fixture(scope="module")
def fenetre(app):
    from orion.ui.main_window import MainWindow
    vrai = MainWindow._boot
    MainWindow._boot = lambda self: None           # jamais de demarrage (reseau)
    try:
        w = MainWindow()
    finally:
        MainWindow._boot = vrai
    yield w
    w.close()
    w.deleteLater()


def test_ctrl_f_vise_la_recherche_de_la_page_affichee(fenetre, app):
    w = fenetre
    w.show()
    w.activateWindow()
    app.processEvents()
    for page, champ in (("library", w.library_view.search),
                        ("storage", w.storage_view.recherche),
                        ("settings", w.settings_view.recherche),
                        ("hardware", w.hardware_view.puissance.recherche),
                        ("boutique", w.boutique_view.recherche)):
        w.show_page(page)
        app.processEvents()
        w.chercher_ici()
        app.processEvents()
        assert app.focusWidget() is champ, page
    # page sans recherche : celle de la bibliotheque
    w.show_page("comptes")
    w.chercher_ici()
    app.processEvents()
    from orion.ui.main_window import PAGES
    assert PAGES[w.stack.currentIndex()] == "library"
    assert app.focusWidget() is w.library_view.search


def test_chercher_en_boutique_ouvre_les_offres_avec_le_nom(fenetre, app, monkeypatch):
    w = fenetre
    from orion.ui.main_window import PAGES
    w.boutique_page.montrer("gratuits")
    w.chercher_en_boutique("  zelda ")
    assert PAGES[w.stack.currentIndex()] == "boutique"
    assert w.boutique_page.onglet == "offres"
    assert w.boutique_view.recherche.text() == "zelda"
    w.boutique_view._delai_partout.stop()
    w.boutique_view._delai_saisie.stop()
