"""Tests de la fusion Boutique / Jeux gratuits et des sujets connexes :

* bibliotheque : les filtres (introuvables, sources, non installes) montrent
  ou masquent les tuiles existantes au lieu de les reconstruire ;
* boutique : la case « Afficher les applications » masque logiciels,
  formations et autres non-jeux, persistee dans la configuration ;
* la page Boutique et l'ancienne page « Jeux gratuits » sont reunies en une
  seule page a deux onglets, sans doublon ni entree de barre laterale perdue ;
* les ouvertures de dossier / desinstallation passent par les aides « propres »
  de `orion.core.lancement` (pas d'heritage du chemin des DLL d'ORION).
"""
from __future__ import annotations

import time

import pytest

from orion.core.models import Game


@pytest.fixture(scope="module")
def app():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


def _jeu(uid: str, **kw) -> Game:
    return Game(title=kw.pop("title", uid), source=kw.pop("source", "steam"),
               source_id=uid, uid=uid, **kw)


# ---------------------------------------------------------------------------
# 1. Bibliotheque : filtres instantanes (tuiles reutilisees, pas reconstruites)
# ---------------------------------------------------------------------------
def test_bibliotheque_toggle_introuvables_reutilise_les_tuiles(app):
    from orion.ui.views.library_view import LibraryView

    games = [_jeu(str(i), title=f"Jeu {i}", extra={"missing": i % 7 == 0})
             for i in range(500)]
    lv = LibraryView()
    lv.set_games(games)

    # avec « masquer les introuvables » coche (defaut) : les jeux manquants
    # n'ont pas encore de tuile
    assert lv.hide_missing.isChecked()
    assert len(lv._toutes) == len([g for g in games if not g.extra["missing"]])

    lv.hide_missing.setChecked(False)          # tout montrer : nouvelles tuiles
    assert len(lv._toutes) == 500
    ids_avant = {uid: id(c) for uid, c in lv._toutes.items()}

    # les allers-retours suivants ne doivent plus RIEN reconstruire : chaque
    # bascule doit etre quasi instantanee (le bug signale prenait 10 a 15 s)
    t0 = time.perf_counter()
    lv.hide_missing.setChecked(True)
    lv.hide_missing.setChecked(False)
    lv.hide_missing.setChecked(True)
    lv.hide_missing.setChecked(False)
    lv.hide_missing.setChecked(True)
    duree = time.perf_counter() - t0
    assert duree < 2.0, f"bascule du filtre trop lente : {duree:.2f}s"

    ids_apres = {uid: id(c) for uid, c in lv._toutes.items()}
    assert ids_avant == ids_apres, "les tuiles ont ete reconstruites"

    visibles_final = {uid for uid, c in lv._toutes.items() if not c.isHidden()}
    attendu = {g.uid for g in games if not g.extra["missing"]}   # se termine coche
    assert visibles_final == attendu


def test_bibliotheque_recherche_et_filtre_source_reutilisent_les_tuiles(app):
    from orion.ui.views.library_view import LibraryView

    games = [_jeu(str(i), title=f"Alpha {i}" if i % 2 else f"Beta {i}",
                  source="steam" if i % 3 else "gog")
             for i in range(300)]
    lv = LibraryView()
    lv.hide_missing.setChecked(False)
    lv.set_games(games)
    assert len(lv._toutes) == 300
    ids_avant = {uid: id(c) for uid, c in lv._toutes.items()}

    t0 = time.perf_counter()
    lv.search.setText("Alpha")
    lv.search.setText("")
    lv.set_source_filter({"gog"})
    lv.set_source_filter(None)
    duree = time.perf_counter() - t0
    assert duree < 2.0, f"filtre trop lent : {duree:.2f}s"

    ids_apres = {uid: id(c) for uid, c in lv._toutes.items()}
    assert ids_avant == ids_apres


def test_bibliotheque_tuile_reconstruite_seulement_si_signature_changee(app):
    """Un changement invisible (temps de jeu inchange, jaquette inchangee)
    garde la meme tuile ; un changement visible (titre) la recree."""
    from orion.ui.views.library_view import LibraryView

    g = _jeu("a", title="Jeu")
    lv = LibraryView()
    lv.set_games([g])
    tuile_1 = lv._toutes["a"]

    lv.set_games([_jeu("a", title="Jeu")])       # rien de visible n'a change
    assert lv._toutes["a"] is tuile_1

    lv.set_games([_jeu("a", title="Jeu renomme")])   # titre affiche : change
    assert lv._toutes["a"] is not tuile_1


# ---------------------------------------------------------------------------
# 2. Boutique : masquer les applications (logiciels, formations...)
# ---------------------------------------------------------------------------
def test_est_application_heuristique():
    from orion.boutique import est_application

    # nature donnee par la source : prime sur tout le reste
    assert est_application("N'importe quoi", types=("dlc",))
    assert est_application("N'importe quoi", types=("software",))
    assert not est_application("Half-Life 3", types=("game",))

    # lot explicitement identifie comme formation/certification
    assert est_application("Business Certification Bundle")
    assert est_application("The Complete Python Bootcamp")
    assert est_application("Udemy Photoshop Masterclass")
    assert est_application("Learn to Code : Python Bundle")
    assert est_application("Excel for Business - Training Course")

    # genres Steam propres aux logiciels uniquement
    assert est_application("Mon outil", genres=["Utilities"])
    assert est_application("Mon outil", genres=["Software Training"])

    # titres ambigus mais qui sont bien des jeux
    assert not est_application("Business Tour")
    assert not est_application("Comic Jumper")
    assert not est_application("Kingdom Come: Deliverance")
    assert not est_application("Cyberpunk 2077")


def test_fiche_est_application_depuis_le_type_itad():
    from orion.boutique import Fiche
    from orion.plugins.boutique.base import Offre

    jeu = Fiche(titre="Half-Life 3", offres=[
        Offre(titre="Half-Life 3", boutique="Steam", prix=19.99,
             source="steam", type_article="game")])
    assert not jeu.est_application

    lot = Fiche(titre="Business Certification Bundle", offres=[
        Offre(titre="Business Certification Bundle", boutique="Fanatical",
             prix=9.99, source="itad", type_article="package")])
    assert lot.est_application


def test_boutique_view_masque_les_applications_par_defaut_et_bascule(app):
    from orion.core.config import CONFIG
    from orion.plugins.boutique.base import Offre
    from orion.boutique import Fiche
    from orion.ui.views.boutique_view import BoutiqueView

    valeur_avant = CONFIG.get("boutique.afficher_applications", False)
    CONFIG.set("boutique.afficher_applications", False, save=False)
    try:
        jeu = Fiche(titre="Un Jeu", offres=[
            Offre(titre="Un Jeu", boutique="Steam", prix=9.99,
                 prix_normal=19.99, remise=50, source="steam",
                 type_article="game")])
        appli = Fiche(titre="Business Certification Bundle", offres=[
            Offre(titre="Business Certification Bundle", boutique="Fanatical",
                 prix=4.99, prix_normal=19.99, remise=75, source="itad",
                 type_article="package")])

        vue = BoutiqueView()
        assert not vue.voir_applications.isChecked()
        vue.set_catalogue([jeu, appli], time.time(), 12, True)

        titres = {f.titre for f in vue.visibles()}
        assert "Un Jeu" in titres
        assert "Business Certification Bundle" not in titres
        assert vue._apps_masquees == 1
        # 2.1.0 : plus de case « Afficher les applications » (jugee inutile par
        # l'auteur) ; les applications restent masquees, le resume le dit
        assert vue.voir_applications.isHidden()
        assert "1 application(s) masquee(s)" in vue.resume.text()
    finally:
        CONFIG.set("boutique.afficher_applications", valeur_avant, save=False)


def test_boutique_view_narrete_pas_les_jeux_gratuits_dans_les_offres(app):
    """Les gratuits ont leur propre onglet : la liste des offres ne les
    repete pas (sinon la Boutique et « Jeux gratuits » se recouvrent)."""
    from orion.plugins.boutique.base import Offre
    from orion.boutique import Fiche
    from orion.ui.views.boutique_view import BoutiqueView

    payant = Fiche(titre="Jeu paye", offres=[
        Offre(titre="Jeu paye", boutique="Steam", prix=29.99, prix_normal=49.99,
             source="steam")])
    gratuit = Fiche(titre="Jeu offert", offres=[
        Offre(titre="Jeu offert", boutique="Epic", prix=0.0, source="epic")])

    vue = BoutiqueView()
    vue.set_catalogue([payant, gratuit], time.time(), 12, True)
    titres = {f.titre for f in vue.visibles()}
    assert "Jeu paye" in titres
    assert "Jeu offert" not in titres


# ---------------------------------------------------------------------------
# 3. Fusion Boutique / Jeux gratuits en une seule page
# ---------------------------------------------------------------------------
def test_page_jeux_gratuits_retiree_de_la_barre_laterale():
    from orion.ui.widgets.sidebar import PAGES
    cles = [cle for cle, _ in PAGES]
    assert "free" not in cles
    assert "boutique" in cles
    assert len(cles) == len(set(cles))         # pas de doublon


def test_pages_de_la_fenetre_principale_sans_entree_free_dediee():
    from orion.ui.main_window import ALIAS_PAGES, PAGES
    assert "boutique" in PAGES
    assert "free" not in PAGES                 # plus une page a part
    assert ALIAS_PAGES.get("free") == ("boutique", "gratuits")


def test_boutique_page_bascule_entre_les_deux_onglets_et_garde_les_signaux(app):
    from PySide6.QtWidgets import QWidget
    from orion.ui.views.boutique_page import BoutiquePage, GRATUITS, OFFRES

    class Vue(QWidget):
        def __init__(self):
            super().__init__()
            self.integre = False

        def integrer(self):
            self.integre = True

    offres, gratuits = Vue(), Vue()
    page = BoutiquePage(offres, gratuits)

    # les deux vues sont integrees (plus de second titre de page)
    assert offres.integre and gratuits.integre

    changements = []
    page.onglet_change.connect(changements.append)

    assert page.onglet == OFFRES
    assert page.pile.currentWidget() is offres

    page.montrer(GRATUITS)
    assert page.onglet == GRATUITS
    assert page.pile.currentWidget() is gratuits
    assert changements == [GRATUITS]

    page.montrer(OFFRES)
    assert page.pile.currentWidget() is offres


def test_boutique_page_affiche_le_nombre_de_gratuits_sur_londlet(app):
    from PySide6.QtWidgets import QWidget
    from orion.ui.views.boutique_page import BoutiquePage, GRATUITS

    page = BoutiquePage(QWidget(), QWidget())
    page.set_gratuits(4, urgent=False)
    assert page.boutons[GRATUITS].pastille() == "4"
    page.set_gratuits(0)
    assert page.boutons[GRATUITS].pastille() == ""


def test_show_page_free_ouvre_la_boutique_sur_londlet_gratuits(app):
    from orion.ui.main_window import MainWindow, PAGES

    w = MainWindow()
    try:
        w.show_page("free")
        assert w.stack.currentIndex() == PAGES.index("boutique")
        assert w.stack.currentWidget() is w.boutique_page
        assert w.boutique_page.onglet == "gratuits"

        w.sidebar.select_page("boutique")
        assert w.sidebar.group.checkedButton().property("page") == "boutique"
    finally:
        w.deleteLater()


def test_free_view_garde_tous_ses_signaux_dans_la_page_fusionnee(app):
    from orion.ui.main_window import MainWindow

    w = MainWindow()
    try:
        # les signaux de FreeView existent toujours et sont bien ceux relies
        # par la fenetre principale (voir _wiring dans __init__)
        for signal in ("refresh_requested", "claim_requested", "dismiss_requested",
                      "buy_requested", "uninstall_requested", "remove_requested",
                      "keep_requested", "filter_changed"):
            assert hasattr(w.free_view, signal)
        assert w.boutique_page.gratuits is w.free_view
        assert w.boutique_page.offres is w.boutique_view
    finally:
        w.deleteLater()


# ---------------------------------------------------------------------------
# 4. Lancements externes : passent par orion.core.lancement (pas d'heritage
#    du chemin des DLL ni de l'environnement d'ORION)
# ---------------------------------------------------------------------------
def test_main_window_ouvre_un_dossier_avec_startfile_propre(monkeypatch):
    import orion.core.lancement as lancement
    import orion.core.paths as paths
    from orion.ui import main_window as mw

    appels = []
    monkeypatch.setattr(paths, "is_windows", lambda: True)
    monkeypatch.setattr(lancement, "startfile_propre",
                        lambda cible, dossier=None: appels.append(cible))

    mw.MainWindow._open_folder_path("C:/Jeux/MonJeu")
    assert appels == ["C:/Jeux/MonJeu"]


def test_main_window_desinstalle_steam_avec_startfile_propre(app, monkeypatch):
    import orion.core.lancement as lancement
    import orion.core.paths as paths
    from orion.ui import main_window as mw
    from PySide6.QtWidgets import QMessageBox

    w = mw.MainWindow()
    try:
        jeu = _jeu("123", title="Jeu Steam", source="steam", size_bytes=0)
        monkeypatch.setattr(w.library, "get", lambda uid: jeu)
        monkeypatch.setattr(paths, "is_windows", lambda: True)
        monkeypatch.setattr(QMessageBox, "question",
                            lambda *a, **k: QMessageBox.StandardButton.Yes)
        appels = []
        monkeypatch.setattr(lancement, "startfile_propre",
                            lambda cible, dossier=None: appels.append(cible))

        assert w._uninstall_game("123") is True
        assert appels == ["steam://uninstall/123"]
    finally:
        w.deleteLater()


def test_main_window_desinstalle_avec_popen_propre_pour_une_commande(app, monkeypatch):
    import orion.storage as storage
    import orion.core.lancement as lancement
    from orion.ui import main_window as mw
    from PySide6.QtWidgets import QMessageBox

    w = mw.MainWindow()
    try:
        jeu = _jeu("456", title="Jeu Sans Plateforme", source="dossier")
        monkeypatch.setattr(w.library, "get", lambda uid: jeu)
        monkeypatch.setattr(storage, "uninstall_command",
                            lambda g: ("C:/Jeux/uninstall.exe", "Lance le desinstalleur."))
        monkeypatch.setattr(QMessageBox, "question",
                            lambda *a, **k: QMessageBox.StandardButton.Yes)
        appels = []
        monkeypatch.setattr(lancement, "popen_propre",
                            lambda args, cwd=None, **kw: appels.append((args, kw)))

        assert w._uninstall_game("456") is True
        assert appels == [("C:/Jeux/uninstall.exe", {"shell": True})]
    finally:
        w.deleteLater()


def test_detail_view_ouvre_le_dossier_avec_startfile_propre(app, monkeypatch, tmp_path):
    import orion.core.lancement as lancement
    from orion.ui.views import detail_view as dv
    from orion.core.models import HardwareInfo

    v = dv.DetailView()
    v.set_game(_jeu("a", title="Jeu", install_dir=str(tmp_path)), HardwareInfo())
    monkeypatch.setattr(dv, "is_windows", lambda: True)
    appels = []
    monkeypatch.setattr(lancement, "startfile_propre",
                        lambda cible, dossier=None: appels.append(cible))

    v._open_folder()
    assert appels == [str(tmp_path)]


def test_settings_view_ouvre_le_dossier_avec_startfile_propre(monkeypatch, tmp_path):
    import orion.core.lancement as lancement
    from orion.ui.views import settings_view as sv

    monkeypatch.setattr(sv, "is_windows", lambda: True)
    appels = []
    monkeypatch.setattr(lancement, "startfile_propre",
                        lambda cible, dossier=None: appels.append(cible))

    dossier = tmp_path / "sauvegardes"
    sv.SettingsView._open(dossier)
    assert appels == [str(dossier)]
    assert dossier.is_dir()

