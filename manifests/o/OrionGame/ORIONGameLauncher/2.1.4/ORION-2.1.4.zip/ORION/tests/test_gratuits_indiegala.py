"""Jeux gratuits IndieGala (12 octobre 2026, audit du site) : GamerPower les
range « DRM-Free », mais il faut un compte IndieGala (gratuit) pour les
recuperer, et leur « valeur » (29,99 $ pour Wordle comme pour Best Plumber)
est celle qu'annonce IndieGala, inverifiable."""
from orion.plugins.freebies.base import SHOP_CONDITIONS
from orion.plugins.freebies.gamerpower import GamerPowerFreebies


def _offre(**k):
    e = {"id": 1, "title": "Wordle (IndieGala) Giveaway", "platforms": "PC, DRM-Free", "status": "Active",
         "worth": "$29.99", "type": "Game", "end_date": "N/A",
         "instructions": "1. Click the button. 2. Login into your free IndieGala account.",
         "open_giveaway_url": "https://www.gamerpower.com/open/wordle"}
    e.update(k)
    return GamerPowerFreebies()._one(e)


def test_une_offre_indiegala_dit_sa_boutique_et_tait_sa_valeur():
    fb = _offre()
    assert fb.title == "Wordle" and fb.shop == "IndieGala" and not fb.worth
    assert "Compte IndieGala requis" in SHOP_CONDITIONS["IndieGala"]


def test_une_vraie_offre_sans_drm_reste_sans_drm():
    fb = _offre(title="Best Plumber (PC) Giveaway", instructions="Download the game.")
    assert fb.shop == "Sans DRM" and fb.worth == 29.99
