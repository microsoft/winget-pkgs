"""Cles verifiees des revendeurs, mises en vue sans tricher (7 octobre 2026).

  - A prix egal, la boutique partenaire passe devant (meme prix pour le joueur).
  - La cle verifiee la moins chere d'un revendeur apparait sur la carte et en
    haut de la fiche, quand elle bat les boutiques sures. Jamais comme « la
    meilleure offre », jamais sans les controles du service.
  - Les cartes ne font pas interroger Kinguin en masse : le service ne rend
    que ce qu'il sait deja, plus le prix de Loaded (catalogue partenaire).
"""
import time

import pytest

from orion import boutique, prix_revendeurs
from orion.plugins.boutique.base import Offre
from test_boutique_refonte import _fiche

#: la vraie fonction, que `conftest` remplace pour qu'aucun essai ne joigne le service
LOT = prix_revendeurs.lot
OFFRES = prix_revendeurs.offres

KINGUIN = {"prix": 9.87, "devise": "EUR", "vendeur": "GamingWorld", "note": 98.4, "ventes": 4113959,
           "nom": "Tropico 6 PC Steam CD Key",
           "url": "https://www.kinguin.net/category/61886/tropico-6-pc-steam-cd-key"}
LOADED = {"prix": 12.49, "devise": "EUR", "public": 39.99, "nom": "Tropico 6 PC",
          "url": "https://www.loaded.com/fr_fr/tropico-6-pc-steam"}


@pytest.fixture()
def app():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


def test_a_prix_egal_la_boutique_partenaire_passe_devant():
    from orion.core.config import CONFIG
    CONFIG.set("boutique.liens_partenaires", True, save=False)
    steam = Offre("Hades", "Steam", 12.25, prix_normal=24.5, source="steam",
                  url="https://store.steampowered.com/app/1145360", steam_appid="1145360")
    gp = Offre("Hades", "Gamesplanet", 12.25, prix_normal=24.5, source="gamesplanet",
               url="https://fr.gamesplanet.com/game/hades-steam-key--4567-1", steam_appid="1145360")
    assert boutique.Fiche("Hades", [steam, gp]).meilleure is gp
    assert boutique.Fiche("Hades", [gp, steam]).meilleure is gp
    # jamais au prix d'un centime de plus pour le joueur
    gp.prix = 12.26
    assert boutique.Fiche("Hades", [steam, gp]).meilleure is steam
    # liens partenaires coupes par le joueur : la boutique officielle d'abord, comme avant
    gp.prix = 12.25
    CONFIG.set("boutique.liens_partenaires", False, save=False)
    try:
        assert boutique.Fiche("Hades", [gp, steam]).meilleure is steam
    finally:
        CONFIG.set("boutique.liens_partenaires", True, save=False)


def test_la_meilleure_cle_bat_les_boutiques_sures_ou_n_existe_pas():
    cle = prix_revendeurs.meilleure_cle({"kinguin": KINGUIN, "loaded": LOADED}, 15.99, 39.99)
    assert cle["site"] == "kinguin" and cle["boutique"] == "Kinguin" and cle["prix"] == 9.87
    assert prix_revendeurs.meilleure_cle({"kinguin": None, "loaded": LOADED}, 15.99, 39.99)["boutique"] == "Loaded"
    assert prix_revendeurs.meilleure_cle({"kinguin": KINGUIN}, 9.87, 39.99) is None       # pas moins cher
    assert prix_revendeurs.meilleure_cle({"loaded": LOADED}, 15.99, 9.99) is None         # homonyme : prix public trop loin
    assert prix_revendeurs.meilleure_cle({"loaded": LOADED}, 0, 39.99) is None            # pas de prix officiel
    assert prix_revendeurs.meilleure_cle({"g2a": KINGUIN}, 15.99, 39.99) is None          # site non retenu
    assert prix_revendeurs.meilleure_cle({}, 15.99, 39.99) is None


class _Rep:
    def __init__(self, code, donnees):
        self.status_code, self._d = code, donnees

    def json(self):
        return self._d


@pytest.fixture()
def service(base_neuve, monkeypatch):
    """Le service d'ORION, imite : huit jeux nouveaux par demande."""
    from orion.core import reseau
    etat = {"appels": [], "connus": {}, "code": 200,
            "prix": {"492720": {"kinguin": KINGUIN, "loaded": LOADED},
                     "1145360": {"loaded": None}}}

    def requete(methode, url, **kw):
        corps = kw["json"]
        etat["appels"].append((methode, url, corps))
        if etat["code"] != 200:
            return _Rep(etat["code"], {})
        rendus, neufs = {}, 0
        for j in corps["jeux"]:
            a = j["appid"]
            if a not in etat["connus"]:
                if neufs >= 8:
                    continue
                neufs += 1
                etat["connus"][a] = etat["prix"].get(a, {"loaded": None})
            rendus[a] = etat["connus"][a]
        return _Rep(200, {"prix": rendus, "reste": len(corps["jeux"]) - len(rendus)})
    monkeypatch.setattr(reseau, "requete", requete)
    monkeypatch.setattr(prix_revendeurs, "lot", LOT)
    return etat


def test_le_lot_rend_ce_que_le_service_sait(service):
    recus = prix_revendeurs.lot([("492720", "Tropico 6"), ("1145360", "Hades"), ("x", "pas un numero"),
                                 ("7", "")])
    methode, url, corps = service["appels"][0]
    assert (methode, url) == ("POST", "https://api.orion-launcher.com/prix/lot")
    assert corps == {"pays": "FR", "jeux": [{"appid": "492720", "titre": "Tropico 6"},
                                            {"appid": "1145360", "titre": "Hades"}]}
    assert recus["492720"]["kinguin"]["prix"] == 9.87 and recus["492720"]["loaded"]["prix"] == 12.49
    assert recus["1145360"] == {"loaded": None}                    # Kinguin pas releve : absent
    # garde trois heures sur le PC : aucune nouvelle demande
    del service["appels"][:]
    assert prix_revendeurs.lot([("492720", "Tropico 6")])["492720"]["kinguin"]["prix"] == 9.87
    assert service["appels"] == []


def test_une_page_de_quarante_jeux_vient_en_quelques_passes(service):
    jeux = [(str(1000 + i), f"Jeu {i}") for i in range(40)]
    recus = prix_revendeurs.lot(jeux)
    assert len(recus) == 40
    assert all(len(c["jeux"]) <= 20 for _m, _u, c in service["appels"])
    assert 5 <= len(service["appels"]) <= 12


def test_une_reponse_douteuse_n_affiche_rien(service):
    service["prix"]["492720"] = {"kinguin": {**KINGUIN, "url": "https://kinguin.mechant.example/x"},
                                 "loaded": {**LOADED, "devise": "USD"}}
    assert prix_revendeurs.lot([("492720", "Tropico 6")])["492720"] == {"kinguin": None, "loaded": None}
    # service en panne : rien, et pas d'erreur
    service["code"] = 503
    assert prix_revendeurs.lot([("5", "Autre jeu")]) == {}


def test_le_service_pose_la_cle_sur_les_fiches(service, monkeypatch):
    s = boutique.BoutiqueService()
    tropico = _fiche("Tropico 6", "492720", 15.99, 39.99)
    hades = _fiche("Hades", "1145360", 12.25, 24.5)
    gratuit = _fiche("Gratuit", "730", 0.0, 0.0)
    assert s.cles_revendeurs([tropico, hades, gratuit]) == 1
    assert tropico.revendeur["boutique"] == "Kinguin" and tropico.revendeur["prix"] == 9.87
    assert hades.revendeur is None and gratuit.revendeur is None
    # la cle n'est jamais « la meilleure offre » de la fiche, ni dans son catalogue enregistre
    assert tropico.meilleure.boutique == "Steam" and "revendeur" not in str(tropico.to_dict())
    # encart des revendeurs coupe dans les Reglages : plus rien
    from orion.core.config import CONFIG
    CONFIG.set("marche_gris.afficher", False, save=False)
    try:
        assert s.cles_revendeurs([tropico]) == 0 and tropico.revendeur is None
    finally:
        CONFIG.set("marche_gris.afficher", True, save=False)


def test_la_page_demande_les_cles_une_fois_par_jeu(app):
    from orion.boutique import MEMO
    from orion.ui.views.boutique_view import BoutiqueView
    MEMO.vider()
    v = BoutiqueView()
    demandes = []
    v.cles_demandees.connect(lambda fiches: demandes.append([f.titre for f in fiches]))
    fiches = [_fiche(f"Jeu {i:02d}", str(100 + i), 5.0 + i, 40.0) for i in range(50)] \
        + [_fiche("Gratuit", "730", 0.0, 0.0)]
    v.set_catalogue(fiches, time.time(), 12, True)
    vus = {t for d in demandes for t in d}
    assert vus and "Gratuit" not in vus
    n = len(demandes)
    v._rendre(False)
    assert len(demandes) == n                                      # deja demandees
    v.cles_recues()                                                # ne casse rien


def test_la_carte_et_la_fiche_montrent_la_cle_verifiee(app):
    from PySide6.QtGui import QFont, QImage, QPainter
    from PySide6.QtCore import QRectF
    from orion.ui.views import boutique_view as B
    from orion.ui.widgets import boutique_cartes as C
    f = _fiche("Tropico 6", "492720", 15.99, 39.99)

    def rendu():
        image = QImage(300, 260, QImage.Format.Format_ARGB32)
        image.fill(0)
        p = QPainter(image)
        C.dessiner_carte(p, QRectF(10, 10, 280, 240), f, None, False, QFont())
        p.end()
        return image
    sans = rendu()
    f.revendeur = prix_revendeurs.meilleure_cle({"kinguin": KINGUIN}, 15.99, 39.99)
    assert rendu() != sans                                         # la pastille est dessinee
    # la fiche : un bouton en vue, a cote de « Acheter », qui ouvre la fiche verifiee
    ligne = B.FicheLigne(f, set(), avec_image=False)
    assert ligne.bouton_cle is None
    ligne.remplir_comparatif()
    ligne._prix_revendeur_recu({"kinguin": KINGUIN, "loaded": LOADED})
    assert ligne.bouton_cle is not None and not ligne.bouton_cle.isHidden()
    assert "Kinguin" in ligne.bouton_cle.text() and "9,87" in ligne.bouton_cle.text()
    assert ligne._url_cle == KINGUIN["url"]
    assert "Verifie par ORION" in ligne.bouton_cle.toolTip() and "98 %" in ligne.bouton_cle.toolTip()
    # le prix a remonte : le bouton disparait
    ligne._prix_revendeur_recu({"kinguin": {**KINGUIN, "prix": 19.0}, "loaded": None})
    assert ligne.bouton_cle.isHidden()


def test_loaded_ne_garde_son_lien_que_pour_une_cle_steam_en_stock(app):
    """Essai de l'auteur, 7 octobre : le lien Loaded ouvrait une recherche
    pleine d'autres jeux quand il ne vend pas celui-ci."""
    from orion.ui.views import boutique_view as B

    gardees = []                        # les fiches doivent survivre a la fonction

    def fiche_ouverte(reponse):
        ligne = B.FicheLigne(_fiche("Tropico 6", "492720", 15.99, 39.99), set(), avec_image=False)
        ligne.remplir_comparatif()
        ligne._prix_revendeur_recu(reponse)
        gardees.append(ligne)
        return {l.site.id: l for l in ligne.lignes_revendeurs}
    # le service a repondu « aucune cle sure » : Loaded s'efface, les autres restent
    lignes = fiche_ouverte({"kinguin": None, "loaded": None, "repondu": True})
    assert lignes["loaded"].isHidden() and not lignes["kinguin"].isHidden()
    assert not lignes["instant-gaming"].isHidden()
    assert lignes["instant-gaming"].prix.text() == "Chercher sur le site"
    # une cle Steam en stock, plus chere que Steam : le lien ouvre sa fiche, pas la recherche
    chere = {**LOADED, "prix": 19.99}
    lignes = fiche_ouverte({"kinguin": None, "loaded": chere, "repondu": True})
    assert not lignes["loaded"].isHidden() and lignes["loaded"].url == LOADED["url"]
    # service muet : on ne sait pas, rien n'est efface
    lignes = fiche_ouverte({"kinguin": None, "loaded": None})
    assert not lignes["loaded"].isHidden() and "catalogsearch" in lignes["loaded"].url


def test_les_offres_disent_si_le_service_a_repondu(base_neuve, monkeypatch):
    from orion.core import reseau
    import importlib
    vrai = importlib.import_module("orion.prix_revendeurs")
    codes = [200]
    monkeypatch.setattr(reseau, "get", lambda *a, **k: _Rep(codes[0], {"kinguin": KINGUIN, "loaded": None}))
    monkeypatch.setattr(vrai, "offres", OFFRES)
    recues = vrai.offres("492720", "Tropico 6")
    assert recues["repondu"] is True and recues["kinguin"]["prix"] == 9.87 and recues["loaded"] is None
    assert vrai.offres("492720", "Tropico 6")["repondu"] is True          # relu de la memoire du PC
    codes[0] = 503
    assert "repondu" not in vrai.offres("5", "Autre jeu")                 # service muet
