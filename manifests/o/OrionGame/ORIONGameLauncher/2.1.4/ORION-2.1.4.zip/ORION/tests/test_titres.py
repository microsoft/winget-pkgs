"""Correspondance des titres de jeux avec les boutiques (Steam, GOG, SteamGridDB).

Signalement reel : « RuneScape - Dragonwilds » (installe par le lanceur
Jagex) n'etait pas reconnu sur Steam, ou il s'appelle « RuneScape:
Dragonwilds » : ni fiche boutique, ni captures. Ce genre d'erreur doit etre
evite, sans pour autant confondre deux jeux differents.
"""
import pytest

from orion.core import recherche as R
from orion.core.models import Game


# ----------------------------------------------------------------------
# cle d'egalite
# ----------------------------------------------------------------------
@pytest.mark.parametrize("a, b", [
    ("RuneScape - Dragonwilds", "RuneScape: Dragonwilds"),
    ("RuneScape - Dragonwilds", "RuneScape®: Dragonwilds™"),
    ("RuneScape – Dragonwilds", "RuneScape — Dragonwilds"),
    ("Baldur's Gate 3", "Baldur’s Gate 3"),
    ("Baldur's Gate 3", "Baldur's Gate III"),
    ("DOOM Eternal", "Doom eternal"),
    ("The Witcher 3: Wild Hunt", "The Witcher 3 Wild Hunt GOTY"),
    ("The Witcher 3: Wild Hunt", "The Witcher® 3: Wild Hunt - Game of the Year Edition"),
    ("Ratchet & Clank: Rift Apart", "Ratchet and Clank - Rift Apart"),
    ("Hades 2", "Hades II"),
    ("Pokemon Legends", "Pokémon Legends"),
    ("Baldur's Gate 3", "Baldur's Gate 3 - Digital Deluxe Edition"),
    ("Crimson Desert", "Crimson Desert Enhanced"),
    ("Grand Theft Auto V", "Grand Theft Auto 5"),
    ("Cœur de pierre", "Coeur de Pierre"),
])
def test_meme_cle(a, b):
    assert R.cle_titre(a) and R.cle_titre(a) == R.cle_titre(b)
    assert R.proximite(a, b) >= 0.95


@pytest.mark.parametrize("a, b", [
    ("Fable", "Fable Anniversary"),
    ("Hades", "Hades II"),
    ("Fallout 3", "Fallout 4"),
    ("The Witcher 3: Wild Hunt", "The Witcher 3: Wild Hunt - Blood and Wine"),
    ("Dofus Retro", "DOFUS"),
    ("Mega Man X", "Mega Man 10"),
    ("Dark Souls III", "Dark Souls II"),
    ("Assassin's Creed", "Assassin's Creed Valhalla"),
    ("Cities: Skylines", "Cities: Skylines II"),
])
def test_jeux_differents(a, b):
    assert R.proximite(a, b) == 0.0
    assert R.cle_titre(a) != R.cle_titre(b)


def test_cle_vide_ne_correspond_jamais():
    """Titres sans lettre latine : la cle est vide et ne doit rien rapprocher."""
    assert R.cle_titre("ドラゴンクエスト") == ""
    assert R.proximite("ドラゴンクエスト", "ポケモン") == 0.0
    assert R.proximite("", "") == 0.0
    assert R.meilleur_candidat("ドラゴンクエスト",
                               [{"id": 1, "name": "ポケモン", "type": "app"}]) is None


def test_edition_dans_un_mot_n_est_pas_retiree():
    """« Expedition » contient « edition » : le titre ne doit pas etre ampute."""
    assert R.sans_bruit("Clair Obscur: Expedition 33") == "clairobscurexpedition33"
    assert R.sans_bruit("Skyrim Special Edition") == "skyrim"
    assert R.sans_bruit("Hades GOTY") == "hades"


def test_normaliser_compatible():
    assert R.normaliser("FOR HONOR™") == R.normaliser("For Honor")
    assert R.normaliser("Baldur’s Gate 3") == R.normaliser("Baldur's Gate 3") == "baldursgate3"


def test_titre_et_termes_de_recherche():
    assert R.titre_recherche("RuneScape - Dragonwilds") == "RuneScape Dragonwilds"
    assert R.titre_recherche("The Witcher® 3: Wild Hunt") == "The Witcher 3 Wild Hunt"
    assert R.titre_recherche("Spider-Man") == "Spider-Man"           # tiret interne garde
    t = R.termes_recherche("RuneScape - Dragonwilds")
    assert t[0] == "RuneScape Dragonwilds" and "RuneScape - Dragonwilds" in t
    assert "Baldur's Gate 3" in R.termes_recherche("Baldur's Gate III")
    assert R.termes_recherche("DOOM Eternal") == ["DOOM Eternal"]
    assert R.termes_recherche("") == []


# ----------------------------------------------------------------------
# choix parmi les resultats d'une boutique
# ----------------------------------------------------------------------
def _items(*noms, type_="app"):
    return [{"id": i + 1, "name": n, "type": type_} for i, n in enumerate(noms)]


def test_choix_runescape():
    items = _items("RuneScape", "Old School RuneScape", "RuneScape: Dragonwilds",
                   "RuneScape: Dragonwilds - Soundtrack")
    assert R.meilleur_candidat("RuneScape - Dragonwilds", items)["id"] == 3


def test_choix_prefere_l_egalite_stricte():
    items = _items("The Elder Scrolls V: Skyrim Special Edition", "The Elder Scrolls V: Skyrim")
    assert R.meilleur_candidat("The Elder Scrolls V: Skyrim", items)["id"] == 2
    items = _items("Hades II", "Hades")
    assert R.meilleur_candidat("Hades", items)["id"] == 2
    assert R.meilleur_candidat("Hades", _items("Hades II")) is None
    assert R.meilleur_candidat("Fable", _items("Fable Anniversary", "Fable III")) is None


def test_choix_ecarte_dlc_bande_son_demo():
    items = _items("Hades Soundtrack", "Hades Demo", "Hades Original Soundtrack")
    assert R.meilleur_candidat("Hades", items) is None
    items = [{"id": 1, "name": "Hades", "type": "dlc"}, {"id": 2, "name": "Hades", "type": "game"}]
    assert R.meilleur_candidat("Hades", items)["id"] == 2
    # un mot « interdit » present dans le titre cherche ne bloque pas
    assert R.meilleur_candidat("Demon Slayer Demo Edition",
                               _items("Demon Slayer Demo Edition"))["id"] == 1


def test_choix_prefere_le_type_jeu():
    items = [{"id": 1, "name": "DOOM Eternal", "type": "app"},
             {"id": 2, "name": "DOOM Eternal", "type": "game"}]
    assert R.meilleur_candidat("DOOM Eternal", items)["id"] == 2


def test_choix_dernier_recours_mots():
    """Article en plus ou en moins, mot d'edition inconnu sur un long titre."""
    assert R.meilleur_candidat("Witcher 3: Wild Hunt",
                               _items("The Witcher 3: Wild Hunt"))["id"] == 1
    assert R.meilleur_candidat("Final Fantasy VII Remake",
                               _items("FINAL FANTASY VII REMAKE INTERGRADE"))["id"] == 1
    # trop different : rien plutot qu'un mauvais jeu
    assert R.meilleur_candidat("Assassin's Creed", _items("Assassin's Creed Valhalla")) is None


def test_choix_tolere_les_entrees_abimees():
    items = [None, "texte", {"id": 3}, {"id": 4, "name": None},
             {"id": 5, "name": "RuneScape: Dragonwilds"}]
    assert R.meilleur_candidat("RuneScape - Dragonwilds",
                               [i for i in items if isinstance(i, dict)])["id"] == 5


def test_recherche_tolerante_inchangee():
    assert R.correspond("witcher 3", "The Witcher 3: Wild Hunt")
    assert R.correspond("cyberpounk", "Cyberpunk 2077")
    assert R.correspond("bg3", "Baldur's Gate 3")


# ----------------------------------------------------------------------
# resolution de l'identifiant Steam (sans reseau)
# ----------------------------------------------------------------------
class _Rep:
    def __init__(self, corps, code=200):
        self._corps, self.status_code = corps, code
        self.headers = {}

    def json(self):
        if isinstance(self._corps, Exception):
            raise self._corps
        return self._corps


@pytest.fixture
def steam_libre(monkeypatch):
    from orion.core import reseau, steam_limite
    reseau.lever_pauses()
    monkeypatch.setattr(steam_limite, "en_pause", lambda: False)
    yield
    reseau.lever_pauses()


def test_retrouver_appid_runescape(monkeypatch, steam_libre):
    from orion.core import reseau
    from orion.plugins.market.steam_store import SteamStoreProvider as P
    termes = []

    def faux_get(url, **kw):
        termes.append(kw["params"]["term"])
        return _Rep({"items": [
            {"id": 1343400, "name": "RuneScape", "type": "app"},
            {"id": 1031430, "name": "RuneScape: Dragonwilds", "type": "app"}]})

    monkeypatch.setattr(reseau, "get", faux_get)
    g = Game(title="RuneScape - Dragonwilds", source="jagex")
    g.extra["steam_lookup_v2"] = True       # echec memorise par l'ancienne version
    assert P._retrouver_appid(g) == "1031430"
    assert g.extra["steam_appid"] == "1031430"
    assert g.extra[P.MARQUEUR] is True and "steam_lookup_v2" not in g.extra
    assert termes == ["RuneScape Dragonwilds"]      # separateur retire de la recherche
    # deja recherche : plus d'appel
    assert P._retrouver_appid(g) == "" and len(termes) == 1


def test_retrouver_appid_essaie_plusieurs_termes(monkeypatch, steam_libre):
    from orion.core import reseau
    from orion.plugins.market.steam_store import SteamStoreProvider as P
    termes = []

    def faux_get(url, **kw):
        termes.append(kw["params"]["term"])
        if kw["params"]["term"] == "Baldur's Gate 3":
            return _Rep({"items": [{"id": 1086940, "name": "Baldur’s Gate 3", "type": "app"}]})
        return _Rep({"items": []})

    monkeypatch.setattr(reseau, "get", faux_get)
    g = Game(title="Baldur's Gate III", source="dossier")
    assert P._retrouver_appid(g) == "1086940"
    assert termes == ["Baldur's Gate III", "Baldur's Gate 3"]


def test_retrouver_appid_refuse_un_faux_ami(monkeypatch, steam_libre):
    from orion.core import reseau
    from orion.plugins.market.steam_store import SteamStoreProvider as P
    monkeypatch.setattr(reseau, "get", lambda url, **kw: _Rep({"items": [
        {"id": 288470, "name": "Fable Anniversary", "type": "app"},
        {"id": 105400, "name": "Fable III", "type": "app"}]}))
    g = Game(title="Fable", source="xbox")
    assert P._retrouver_appid(g) == ""
    assert g.extra[P.MARQUEUR] is True and "steam_appid" not in g.extra


def test_retrouver_appid_reponse_vide_pause_sans_marque(monkeypatch, steam_libre):
    """Corps vide = Steam limite : pause demandee, et le jeu sera recherche plus tard."""
    from orion.core import reseau, steam_limite
    from orion.plugins.market.steam_store import SteamStoreProvider as P
    refus = []
    monkeypatch.setattr(steam_limite, "signaler_refus", lambda: refus.append(1))
    monkeypatch.setattr(reseau, "get", lambda url, **kw: _Rep(ValueError("vide")))
    g = Game(title="RuneScape - Dragonwilds", source="jagex")
    assert P._retrouver_appid(g) == ""
    assert refus == [1] and P.MARQUEUR not in g.extra


def test_retrouver_appid_hors_ligne_sans_marque(monkeypatch, steam_libre):
    from orion.core import reseau
    from orion.plugins.market.steam_store import SteamStoreProvider as P

    def panne(url, **kw):
        raise OSError("hors ligne")

    monkeypatch.setattr(reseau, "get", panne)
    g = Game(title="Dofus Retro", source="ankama")
    assert P._retrouver_appid(g) == "" and P.MARQUEUR not in g.extra


def test_jeu_absent_de_steam_dit_pourquoi_pas_de_captures(monkeypatch, steam_libre):
    """Dofus Retro (Ankama) : pas sur Steam, donc pas de captures publiques.
    La fiche le dit au lieu de rester muette."""
    from orion.core import reseau
    from orion.plugins.market.base import MarketInfo
    from orion.plugins.market.steam_store import SteamStoreProvider as P
    monkeypatch.setattr(reseau, "get", lambda url, **kw: _Rep({"items": [
        {"id": 1, "name": "DOFUS", "type": "app"}]}))
    g = Game(title="Dofus Retro", source="ankama")
    info = MarketInfo(game_uid="x", title=g.title)
    P().fetch(g, info)
    assert info.screenshots == []
    assert info.captures_note == P.SANS_CAPTURES
    assert "absent de Steam" in info.captures_note
    # garde dans le cache
    assert MarketInfo.from_dict(info.to_dict()).captures_note == P.SANS_CAPTURES


def test_cache_prix_relance_les_jeux_marques_v2(monkeypatch):
    """Un jeu dont la recherche avait echoue avec l'ancienne comparaison
    (marque v2) est recherche une fois de plus ; plus apres la v3."""
    import time
    from orion.market import MarketService
    from orion.plugins.market.base import MarketInfo
    from orion.plugins.market.steam_store import SteamStoreProvider as P
    svc = MarketService.__new__(MarketService)
    g = Game(title="RuneScape - Dragonwilds", source="jagex", uid="rs-dw")
    svc._cache = {g.uid: MarketInfo(game_uid=g.uid, fetched_at=time.time()).to_dict()}
    g.extra["steam_lookup_v2"] = True
    assert svc.en_cache(g) is None
    g.extra[P.MARQUEUR] = True
    assert svc.en_cache(g) is not None


# ----------------------------------------------------------------------
# visuels et GOG : meme comparaison
# ----------------------------------------------------------------------
def test_jaquettes_steam_meme_comparaison(monkeypatch):
    from orion.core import reseau
    from orion.plugins.artwork.steam_cdn import SteamArtworkProvider as A
    monkeypatch.setattr(reseau, "get", lambda url, **kw: _Rep({"items": [
        {"id": 2, "name": "Hades II", "type": "app"},
        {"id": 3, "name": "RuneScape: Dragonwilds", "type": "app"}]}))
    assert A._search_store("RuneScape - Dragonwilds", "") == "3"
    assert A._search_store("Hades", "") == ""            # plus de « commence par »
    monkeypatch.setattr(reseau, "get", lambda url, **kw: _Rep([
        {"appid": 9, "name": "Fable Anniversary"}, {"appid": 10, "name": "Fable"}]))
    assert A._search_community("Fable", "") == "10"


def test_gog_meme_comparaison(monkeypatch):
    from orion.core import reseau
    from orion.plugins.market.base import MarketInfo
    from orion.plugins.market.gog import GOGProvider

    def produit(titre, prix, type_="game"):
        return {"title": titre, "productType": type_, "slug": titre.lower().replace(" ", "_"),
                "price": {"finalMoney": {"amount": prix, "currency": "EUR"},
                          "baseMoney": {"amount": prix}}}

    monkeypatch.setattr(reseau, "get", lambda url, **kw: _Rep({"products": [
        produit("The Witcher 3: Wild Hunt - Blood and Wine", "9.99", "dlc"),
        produit("The Witcher 3: Wild Hunt - Game of the Year Edition", "14.99")]}))
    info = MarketInfo()
    GOGProvider().fetch(Game(title="The Witcher 3 Wild Hunt", source="dossier"), info)
    assert info.offers and info.offers[0].price == 14.99


def test_page_magasin_recherche_sans_separateur():
    from orion.core.liens import page_magasin
    g = Game(title="RuneScape - Dragonwilds", source="jagex")
    assert page_magasin(g) == "https://store.steampowered.com/search/?term=RuneScape%20Dragonwilds"
    g.extra["steam_appid"] = "1031430"
    assert page_magasin(g) == "https://store.steampowered.com/app/1031430"


# ----------------------------------------------------------------------
# boutiques officielles et affiliation
# ----------------------------------------------------------------------
def test_liens_boutiques_officielles():
    from orion import marche_gris
    from orion.core.config import CONFIG
    CONFIG.set("boutique.liens_partenaires", True)
    d = {s.id: u for s, u in marche_gris.liens_officiels("RuneScape - Dragonwilds")}
    assert d["gamesplanet"] == "https://fr.gamesplanet.com/search?query=RuneScape+Dragonwilds&ref=orion"
    assert set(d) == {"gamesplanet", "gog", "humble", "fanatical", "gmg"}
    assert all(s.genre == marche_gris.BOUTIQUE_OFFICIELLE
               for s, _ in marche_gris.liens_officiels("Hades"))


def test_gamesplanet_identifiant_quand_il_sera_confirme():
    from orion import affiliation as af
    from orion.core.config import CONFIG
    CONFIG.set("boutique.liens_partenaires", True)
    gp = next(p for p in af.PROGRAMMES if p.id == "gamesplanet")
    assert gp.actif                         # identifiant confirme le 30/09/2026
    table = (af.Programme("gamesplanet", "Gamesplanet", ("gamesplanet.com",),
                          {"ref": "Oriongames"}),)
    u = af.affilier("https://fr.gamesplanet.com/search?query=Hades+II", table)
    assert u == "https://fr.gamesplanet.com/search?query=Hades+II&ref=Oriongames"


def test_eneba_et_allkeyshop_sans_affiliation():
    """Candidatures refusees : liens laisses tels quels."""
    from orion import affiliation as af
    from orion import marche_gris
    d = {s.id: u for s, u in marche_gris.liens("Hades II")}
    assert d["eneba"] == "https://www.eneba.com/fr/store/all?text=Hades+II"
    assert d["allkeyshop"] == "https://www.allkeyshop.com/blog/catalogue/search-hades+ii/"
    assert not af.est_partenaire(d["eneba"]) and not af.est_partenaire(d["allkeyshop"])


# ----------------------------------------------------------------------
# complements (audit)
# ----------------------------------------------------------------------
def test_gog_recherche_sans_separateur(monkeypatch):
    from orion.core import reseau
    from orion.plugins.market.base import MarketInfo
    from orion.plugins.market.gog import GOGProvider
    vus = []
    monkeypatch.setattr(reseau, "get", lambda url, **kw: vus.append(kw["params"]["query"])
                        or _Rep({"products": []}))
    GOGProvider().fetch(Game(title="RuneScape - Dragonwilds", source="jagex"), MarketInfo())
    assert vus == ["like:RuneScape Dragonwilds"]


def test_jaquettes_identifiant_steam_du_registre():
    """Jeu Steam trouve par le registre (« native ») : pas de recherche par titre."""
    from orion.plugins.artwork.steam_cdn import SteamArtworkProvider as A
    g = Game(title="RuneScape - Dragonwilds", source="registre")
    g.extra["native"] = ["steam", "1031430"]
    assert A()._appid(g) == "1031430"


def test_message_captures_absentes():
    from orion.plugins.market.steam_store import SteamStoreProvider as P
    assert P.SANS_CAPTURES == "Captures indisponibles : jeu absent de Steam."


def test_edition_nommee_en_fin_de_titre():
    """Jeu Battle.net vendu sur Steam sous un nom d'edition propre au jeu."""
    from orion.core.recherche import meilleur_candidat
    c = [{"name": "Diablo II: Resurrected – Infernal Edition", "id": 2536520, "type": "app"},
         {"name": "Bande originale de Diablo II: Resurrected", "id": 4523200, "type": "app"}]
    assert meilleur_candidat("Diablo II Resurrected", c)["id"] == 2536520
    # les garde-fous restent : autre numero, autre jeu
    assert meilleur_candidat("Hades", [{"name": "Hades II", "id": 1, "type": "app"}]) is None
    assert meilleur_candidat("Fable", [{"name": "Fable Anniversary", "id": 1, "type": "app"}]) is None


def test_nom_francais_d_une_edition_amelioree():
    """GTA V installe par le lanceur Rockstar (« ... Enhanced ») ; Steam en
    francais l'appelle « ... Version améliorée »."""
    from orion.core.recherche import meilleur_candidat
    c = [{"name": "Grand Theft Auto V Version améliorée", "id": 3240220, "type": "app"},
         {"name": "Grand Theft Auto: Vice City – The Definitive Edition", "id": 1546990, "type": "app"}]
    for titre in ("Grand Theft Auto V Enhanced", "Grand Theft Auto V", "Grand Theft Auto V Legacy"):
        assert meilleur_candidat(titre, c)["id"] == 3240220
    assert meilleur_candidat("Hogwarts", [{"name": "Hogwarts Legacy", "id": 9, "type": "app"}]) is None


def test_fiche_steam_reprise_de_la_recherche_des_visuels(monkeypatch):
    """GTA V installe par Rockstar : les visuels avaient trouve la fiche Steam,
    pas les captures ni la bande-annonce. Un seul identifiant pour tout."""
    from orion.core.models import Game, normalize_title
    from orion.plugins.artwork import steam_cdn
    from orion.plugins.market.steam_store import SteamStoreProvider as P
    jeu = Game(title="Grand Theft Auto V Enhanced", source="registre")
    jeu.extra["steam_lookup_v3"] = True                # echec memorise par l'ancienne version
    jeu.extra["art_absent"] = {"hero": 1.0}
    monkeypatch.setattr(steam_cdn, "_load_resolved",
                        lambda: {"__v__": 3, normalize_title(jeu.title): "3240220"})
    assert P._retrouver_appid(jeu) == "3240220"
    assert jeu.extra["steam_appid"] == "3240220" and "art_absent" not in jeu.extra
    assert jeu.extra.get("steam_lookup_v4") and "steam_lookup_v3" not in jeu.extra
