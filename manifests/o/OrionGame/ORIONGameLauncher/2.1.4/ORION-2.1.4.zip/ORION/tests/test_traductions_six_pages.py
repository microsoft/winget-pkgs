"""Les textes des six pages revues le 7 octobre 2026 existent en anglais et
retrouvent leurs accents en francais (le code est ecrit sans accents)."""
from __future__ import annotations

import re

import pytest

from orion import i18n
from orion.puissance import lecture
from orion.puissance.estimation import Machine, estimer
from orion.puissance.exigences import Config, Exigences

#: mots francais qui ne doivent plus se lire dans un texte traduit
FRANCAIS = re.compile(
    r"\b(jeux?|niveau|carte graphique|processeur|memoire|ecran|pour|sur|avec|"
    r"configuration recommandee|estimes?|retient|reglages?|aucun|votre|vos|"
    r"ce qui|dans|indice|environ|images)\b", re.I)


@pytest.fixture
def anglais():
    assert i18n.charger("en")
    yield i18n.traduire
    i18n.charger("fr")
    i18n.traduire.cache_clear()


@pytest.fixture
def francais():
    assert i18n.charger("fr")
    yield i18n.traduire
    i18n.traduire.cache_clear()


def _machine(**k) -> Machine:
    base = dict(gpu=26.0, gpu_nom="NVIDIA GeForce RTX 3060", cpu=38.0,
                cpu_nom="Intel Core i5-7600", vram_go=6.0, ram_go=8.0,
                pixels=3840 * 2160, definition="3840x2160", hz=60, mise_a_l_echelle="DLSS")
    base.update(k)
    return Machine(**base)


def _jeux() -> list[Exigences]:
    return [
        Exigences("1", "A", Config(gpu=9.0, gpu_nom="GTX 970", ram_go=8.0),
                  Config(gpu=19.0, gpu_nom="RTX 2060", cpu=50.0, cpu_nom="8700", ram_go=16.0)),
        Exigences("2", "B", Config(gpu=24.0, gpu_nom="RTX 2070", ram_go=8.0),
                  Config(gpu=50.0, gpu_nom="RTX 4070", cpu=70.0, cpu_nom="12400",
                         ram_go=16.0, vram_go=12.0, cible_fps=30)),
        Exigences("3", "C", Config(gpu=9.0, gpu_nom="GTX 970", ram_go=8.0), None),
        Exigences("4", "D", Config(gpu=3.0, gpu_nom="GTX 750 TI", ram_go=4.0),
                  Config(gpu=5.0, gpu_nom="GTX 1050", cpu=30.0, cpu_nom="4460", ram_go=8.0,
                         cible_px=2560 * 1440)),
    ]


def _textes_de_lecture() -> list[str]:
    """Tout ce que la lecture du PC peut afficher, sur des cas varies."""
    textes: list[str] = []
    for m in (_machine(), _machine(pixels=1920 * 1080, definition="1920x1080", gpu=6.0,
                                   mise_a_l_echelle="FSR"),
              _machine(gpu=90.0, cpu=30.0, vram_go=24.0, ram_go=32.0)):
        resultats = []
        for x in _jeux():
            e = estimer(x.titre, x, m)
            p = lecture.pistes(x.titre, x, m, actuel=e)
            if p:
                textes.append(p[0].court)
            exp = lecture.expliquer(x.titre, e, x, m)
            # (les composants qui retiennent le jeu sont traduits un a un)
            textes += [exp.debut, *exp.retenus] if exp.retenus else [exp.resume]
            textes += [exp.contexte, *exp.manque, *(q.texte for q in exp.pistes)]
            textes += [li.vous for li in exp.lignes] + [li.demande for li in exp.lignes]
            from orion.puissance import Candidat
            resultats.append((Candidat(titre=x.titre, appid=x.appid, installe=True), e))
        textes += [c.verdict for c in lecture.composants(m, resultats)]
        textes.append(lecture.phrase_frein(lecture.freins(resultats)))
    return [t for t in dict.fromkeys(textes) if t]


def test_la_lecture_du_pc_se_dit_en_anglais(anglais):
    textes = _textes_de_lecture()
    assert len(textes) > 25
    restes = {}
    for texte in textes:
        rendu = anglais(texte)
        # les noms de composants (« Ryzen 7 5700X3D ou Core i5-14400 ») ne se traduisent pas
        if FRANCAIS.search(rendu) or rendu == texte and FRANCAIS.search(texte):
            restes[texte] = rendu
    assert not restes, restes


@pytest.mark.parametrize("texte, attendu", [
    ("Rechercher un reglage...", "Search settings..."),
    ("Donnees partagees", "Shared data"),
    ("Avance", "Advanced"),
    ("Joues recemment", "Recently played"),
    ("Jamais lances", "Never launched"),
    ("Chercher « zelda » dans la Boutique", "Search “zelda” in the Store"),
    ("Aucun jeu de votre bibliotheque ne correspond a « zelda ».",
     "No game in your library matches “zelda”."),
    ("17 sur 26 jeux  ·  2 non installe(s)  ·  9 introuvable(s)",
     "17 of 26 games  ·  2 not installed  ·  9 missing"),
    ("Ce qui dort", "Gathering dust"),
    ("180 Go affiches (2 jeux)", "180 GB shown (2 games)"),
    ("A traiter seulement", "To do only"),
    ("Copie !", "Copied!"),
    ("2 conseil(s) masque(s) : ", "2 hidden tip(s): "),
    ("3 point(s) a corriger sur cette machine", "3 point(s) to fix on this machine"),
    ("2 comptes connectes", "2 accounts connected"),
    (" · 12 jamais lances", " · 12 never launched"),
    ("3 jeux presents sur plusieurs plateformes", "3 games available on several platforms"),
    ("Rattrapables", "Playable with tweaks"),
    ("Processeur : Intel Core i9-9900K (8 coeurs / 16 fils)",
     "Processor: Intel Core i9-9900K (8 cores / 16 threads)"),
    ("Ecran : TV, 1920x1080 a 60 Hz (jusqu'a 120 Hz)", "Display: TV, 1920x1080 at 60 Hz (up to 120 Hz)"),
    ("Haute avec DLSS", "High with DLSS"),
    ("Moyenne en 1600x900", "Medium at 1600x900"),
    ("DLSS en mode Qualite : Haute, environ 64 a 88 i/s",
     "DLSS in Quality mode: High, about 64 to 88 fps"),
    ("Pour le niveau Haute : un processeur du niveau d'un Ryzen 7 5700X3D ou Core i5-14400, "
     "une carte graphique du niveau d'une RTX 5070 ou RX 9070 (12 Go de memoire video).",
     "For the High level: a processor on par with a Ryzen 7 5700X3D or Core i5-14400, "
     "a graphics card on par with a RTX 5070 or RX 9070 (12 GB of video memory)."),
    ("Niveau Basse. Ce qui le retient : ", "Low level. What holds it back: "),
    ("Niveau Haute, sous les 60 images par seconde. Ce qui le retient : ",
     "High level, below 60 frames per second. What holds it back: "),
    ("Basse fluide avec DLSS", "Low, smooth with DLSS"),
    ("definition de l'ecran (3840x2160 : la configuration demandee vaut pour 1920x1080)",
     "screen resolution (3840x2160: the required configuration is given for 1920x1080)"),
    ("Pour 60 images par seconde en Haute : un processeur du niveau d'un Ryzen 7 5700 ou Core i5-11400.",
     "For 60 frames per second on High: a processor on par with a Ryzen 7 5700 or Core i5-11400."),
    ("Niveau Haute attendu. Sous la configuration recommandee : ",
     "High level expected. Below the recommended configuration: "),
    ("processeur (au niveau de la demande, sans marge)",
     "processor (on par with the requirement, no headroom)"),
    ("carte graphique (58 % de la demande)", "graphics card (58% of what is required)"),
    ("Trop juste en l'etat. Ce qui manque : ", "Too weak as it stands. What is missing: "),
    ("Pays des prix : US. Boutique, jeux gratuits et envies sont relus dans la nouvelle devise.",
     "Price country: US. Store, free games and wishlist are being read again in the new currency."),
])
def test_textes_des_six_pages_en_anglais(anglais, texte, attendu):
    assert anglais(texte) == attendu


@pytest.mark.parametrize("texte, attendu", [
    ("Rechercher un reglage...", "Rechercher un réglage..."),
    ("Donnees partagees", "Données partagées"),
    ("Avance", "Avancé"),
    ("Joues recemment", "Joués récemment"),
    ("Jamais lances", "Jamais lancés"),
    ("A traiter seulement", "À traiter seulement"),
    ("Copie !", "Copié !"),
    ("Reafficher", "Réafficher"),
    ("2 comptes connectes", "2 comptes connectés"),
    ("1 jeu present sur plusieurs plateformes", "1 jeu présent sur plusieurs plateformes"),
    ("180 Go affiches (2 jeux)", "180 Go affichés (2 jeux)"),
    ("Ecran : TV, 1920x1080 a 60 Hz", "Écran : TV, 1920x1080 à 60 Hz"),
    ("DLSS en mode Qualite : Haute, environ 64 a 88 i/s",
     "DLSS en mode Qualité : Haute, environ 64 à 88 i/s"),
    ("Jeux estimes fluides en Haute : 559 sur 644. Premier frein de ce PC : carte graphique, "
     "pour 41 jeu(x).",
     "Jeux estimés fluides en Haute : 559 sur 644. Premier frein de ce PC : carte graphique, "
     "pour 41 jeu(x)."),
    ("Une carte graphique du niveau d'une RTX 4070 (12 Go de memoire video)".lower(),
     "une carte graphique du niveau d'une rtx 4070 (12 go de mémoire vidéo)"),
])
def test_textes_des_six_pages_avec_leurs_accents(francais, texte, attendu):
    assert francais(texte) == attendu


def test_chaque_nouveaute_du_journal_est_traduite(anglais):
    from orion.nouveautes import JOURNAL
    for point in JOURNAL[0]["points"]:
        assert anglais(point) != point, point[:70]


def test_le_journal_retrouve_ses_accents(francais):
    from orion.nouveautes import JOURNAL
    for point in JOURNAL[0]["points"][:9]:
        assert francais(point) != point, point[:70]


def test_un_texte_deja_traduit_ne_change_plus_au_second_passage(anglais):
    """Un texte traduit par `t()` puis pose dans un libelle Qt est traduit une
    seconde fois. Le modele « {0} a {1} » (« 72 a 99 ») prenait alors l'article
    anglais « a » pour le « a » francais : « Add a game » devenait « Add to
    game », et 329 textes anglais du catalogue etaient ainsi abimes."""
    import json
    from pathlib import Path
    assert anglais("72 a 99") == "72 to 99"            # ce pour quoi le modele existe
    assert anglais("plus de 72 a 99") != "plus de 72 a 99"
    for texte in ("Add a game", "Click a game in the list",
                  "Games with a full copy on another drive.",
                  "For the High level: a graphics card on par with a RTX 5060 or RX 6700 XT."):
        assert anglais(texte) == texte, texte
    catalogue = json.loads((Path(i18n.DOSSIER) / "en.json").read_text("utf-8"))
    abimes = [v for v in catalogue["exact"].values() if anglais(v) != v]
    assert len(abimes) <= 3, abimes[:5]


def test_en_francais_le_verbe_a_ne_prend_pas_d_accent(francais):
    assert francais("72 a 99") == "72 à 99"
    assert francais("ORION a fini") == "ORION a fini"


# ---------------------------------------------------------------------------
# textes dessines ou assembles a la main : ils ne passent par aucune traduction
# automatique (releves sans accents sur les captures du 7 octobre)
# ---------------------------------------------------------------------------
def test_textes_assembles_a_la_main_retrouvent_leurs_accents(francais, monkeypatch):
    from PySide6.QtWidgets import QApplication
    QApplication.instance() or QApplication([])
    monkeypatch.setattr(i18n, "_actif", True)       # comme dans l'application lancee
    from PySide6.QtWidgets import QCheckBox
    from orion.ui.widgets.sidebar import Sidebar
    barre = Sidebar()
    barre.set_sources({"registre": 3}, {"registre": "Programmes installes"})
    textes = [c.text() for c in barre.sources_box.findChildren(QCheckBox)]
    assert textes == ["Programmes installés  (3)"]
    assert francais("Dans la lignee de Hades") == "Dans la lignée de Hades"
    assert francais("Parce que vous jouez a Bodycam") == "Parce que vous jouez à Bodycam"
    assert francais("Revendeur agree") == "Revendeur agréé"
    assert francais("DLSS Qualite") == "DLSS Qualité"
    assert francais("recette generique") == "recette générique"


def test_le_dessin_des_cartes_et_les_libelles_passent_par_la_traduction():
    """Garde-fou de lecture : ces lignes ont ete oubliees une fois."""
    from pathlib import Path
    racine = Path(i18n.__file__).parent
    cartes = (racine / "ui" / "widgets" / "boutique_cartes.py").read_text(encoding="utf-8")
    assert "ligne = t(raison)" in cartes and "t(self.raisons[f.cle])" in cartes
    vue = (racine / "ui" / "views" / "boutique_view.py").read_text(encoding="utf-8")
    assert "t(niveau.libelle)" in vue and "t(m.confiance.libelle)" in vue
    carte = (racine / "ui" / "widgets" / "profile_card.py").read_text(encoding="utf-8")
    assert 't(reco.nom_niveau) + (f" + {t(reco.texte_mode)}"' in carte
    fiche = (racine / "ui" / "views" / "detail_view.py").read_text(encoding="utf-8")
    assert "t(op.label or op.key)" in fiche


def test_consignes_des_jeux_gratuits_avec_accents(francais, monkeypatch):
    """« Connectez-vous a votre compte STOVE Store » releve sur une capture :
    les consignes sont assemblees etape par etape, hors de toute traduction."""
    from orion.core.config import CONFIG
    from orion.plugins.freebies.consignes import traduire_consignes
    monkeypatch.setattr(CONFIG, "get", lambda cle, defaut=None: "fr" if cle == "langue" else defaut)
    fr, complet = traduire_consignes(
        '1. Click the button to visit the giveaway page. 2. Login into your STOVE Store '
        'account. 3. Click the button "Cart" to add the game to your library.')
    assert complet and fr == (
        "1. Cliquez sur « Récupérer » pour ouvrir la page de l'offre. 2. Connectez-vous à "
        "votre compte STOVE Store. 3. Cliquez sur « Cart » pour ajouter le jeu à votre "
        "bibliothèque.")
    # en anglais, la consigne d'origine est gardee telle quelle
    monkeypatch.setattr(CONFIG, "get", lambda cle, defaut=None: "en" if cle == "langue" else defaut)
    brut = "1. Click the button to visit the giveaway page."
    assert traduire_consignes(brut) == (brut, True)
    assert francais("RECUPERE") == "RÉCUPÉRÉ"


def test_les_cartes_de_graphismes_ont_leurs_accents(francais):
    """11 octobre : la carte « Votre ecran » s'affichait sans accent (capture du
    site). Les noms et explications des deux cartes passent par le catalogue."""
    import re
    from orion.optimizer.choix import EXPLICATIONS, NOMS
    for texte in list(NOMS.values()) + list(EXPLICATIONS.values()):
        if re.search(r"ecran|reglage|frequence|defaut|parametre", texte):
            assert francais(texte) != texte, texte
