"""Meilleurs reglages par carte sur les pages de jeux (12 octobre 2026) : le
profil « Recommande » d'ORION, calcule sans PC, carte par carte."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "service" / "site"))
import reglages  # noqa: E402
from orion.puissance.exigences import Exigences  # noqa: E402

CARTES = [("rtx 5070", "GeForce RTX 5070", 12), ("rtx 4070", "GeForce RTX 4070", 12),
          ("rx 7800 xt", "Radeon RX 7800 XT", 16), ("rtx 4060 ti", "GeForce RTX 4060 Ti", 8),
          ("rtx 3070", "GeForce RTX 3070", 8), ("arc b580", "Intel Arc B580", 12),
          ("rtx 4060", "GeForce RTX 4060", 8), ("rx 7600", "Radeon RX 7600", 8),
          ("rtx 3060", "GeForce RTX 3060", 12), ("rx 6600", "Radeon RX 6600", 8),
          ("gtx 1660 super", "GeForce GTX 1660 Super", 6)]
DEFS = [("1080p", "1920x1080", 1920 * 1080), ("1440p", "2560x1440", 2560 * 1440)]


def _exig():
    from orion.puissance.exigences import lire_config
    e = Exigences(appid="1", titre="Jeu d'essai")
    # comme une fiche Steam : une ligne par composant
    e.minimum = lire_config("Processeur : Intel Core i5-8400<br>Mémoire vive : 8 Go de mémoire<br>"
                            "Graphiques : GeForce GTX 1060 6 Go")
    e.recommandee = lire_config("Processeur : Intel Core i7-10700<br>Mémoire vive : 16 Go de mémoire<br>"
                                "Graphiques : GeForce RTX 3070")
    return e


def test_une_carte_puissante_tient_les_reglages_eleves_sans_super_resolution():
    k = reglages.conseiller(_exig(), "GeForce RTX 5070", 12, 1920, 1080)
    assert k is not None and k.niveau == "haute" and k.mode == "off" and k.atteint
    assert k.fps[0] >= 55


def test_une_carte_juste_monte_d_un_cran_avec_la_super_resolution_de_sa_marque():
    e = _exig()
    nvidia = reglages.conseiller(e, "GeForce RTX 3060", 12, 2560, 1440)
    amd = reglages.conseiller(e, "Radeon RX 6600", 8, 2560, 1440)
    assert nvidia.famille == "dlss" and amd.famille == "fsr"
    assert nvidia.niveau != "ultra" and amd.niveau != "ultra"       # jamais Ultra sans mesure
    assert "+ DLSS" in reglages.reglage_txt(nvidia, "fr") and "+ FSR" in reglages.reglage_txt(amd, "en")


def test_un_jeu_sans_configuration_n_a_pas_de_conseil():
    assert reglages.conseiller(Exigences(appid="2", titre="Inconnu"), "GeForce RTX 4060", 8, 1920, 1080) is None


def test_la_section_et_la_question_de_la_page():
    e = _exig()
    conseils = reglages.conseils_du_jeu(e, CARTES, DEFS)
    assert len(conseils) == len(reglages.CARTES_CONSEIL) * 2
    fr = reglages.section("Jeu d'essai", "1", conseils, CARTES, DEFS, "fr")
    en = reglages.section("Jeu d'essai", "1", conseils, CARTES, DEFS, "en")
    assert 'id="reglages"' in fr and "Meilleurs paramètres graphiques de Jeu d&#x27;essai" in fr
    assert 'id="settings"' in en and fr.count("<tr>") == len(reglages.CARTES_CONSEIL) + 1
    assert "perf menu" not in fr                            # pas de recette pour ce jeu
    q, r = reglages.faq("Jeu d'essai", conseils, DEFS, "fr")
    assert "RTX 4060" in q and "images par seconde" in r


def test_le_menu_de_cyberpunk_est_ce_qu_orion_ecrit():
    menu = dict(reglages.menu_du_jeu("1091500", "Cyberpunk 2077"))
    assert len(menu) >= 4
    assert menu["Qualite des textures"] == ["High", "High", "High"]      # 8 Go : textures gardees
    assert menu["Ombres des objets"] == ["Low", "Medium", "High"]
    assert not any("definition" in k.lower() or "dlss" in k.lower() for k in menu)
    assert reglages.menu_du_jeu("292030", "The Witcher 3: Wild Hunt") == []   # valeurs en chiffres
    assert reglages.libelle("Anticrenelage", "fr") == "Anticrénelage"
    assert reglages.libelle("Anticrenelage", "en") == "Anti-aliasing"
