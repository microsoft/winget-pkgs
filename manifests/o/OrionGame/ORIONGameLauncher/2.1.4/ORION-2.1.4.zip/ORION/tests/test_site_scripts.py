"""Scripts du site versionnes et jamais en double (10 octobre : un visiteur
gardait l'ancien comparatif.js 4 h ; clic.js appele deux fois comptait double)."""
import importlib.util
import pathlib

ICI = pathlib.Path(__file__).resolve().parents[1] / "service" / "site" / "assembler.py"


def _assembleur():
    spec = importlib.util.spec_from_file_location("assembleur_essai", ICI)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_empreinte_et_doublons(tmp_path):
    (tmp_path / "clic.js").write_text("a", encoding="utf-8")
    (tmp_path / "comparatif.js").write_text("b", encoding="utf-8")
    page = tmp_path / "jeu.html"
    page.write_text('<script src="/clic.js" defer></script>\n<script src="/comparatif.js" defer></script>\n'
                    '<script src="https://static.cloudflareinsights.com/beacon.min.js"></script>\n'
                    '<script src="/clic.js" defer></script>\n<script src="/comparatif.js?v=ancien" defer></script>\n',
                    encoding="utf-8")
    assert _assembleur().versionner_scripts(tmp_path) == 1
    t = page.read_text(encoding="utf-8")
    assert t.count("/clic.js?v=") == 1 and t.count("/comparatif.js?v=") == 1
    assert "?v=ancien" not in t and "beacon.min.js" in t
    avant = t
    (tmp_path / "comparatif.js").write_text("c", encoding="utf-8")       # nouveau contenu
    _assembleur().versionner_scripts(tmp_path)
    apres = page.read_text(encoding="utf-8")
    assert apres != avant and apres.count("/comparatif.js?v=") == 1


def test_familles_de_pages_des_scripts_du_site():
    """Les familles de pages de clic.js et comparatif.js doivent viser des adresses qui
    existent (le 16/10, les deux testaient « /jeux-gratuits » alors que la page est
    « /gratuits » : les clics y etaient comptes « autre »)."""
    import re
    from service.site.assembler import ENTREES
    reels = {"/", "/jeux/", "/sorties", "/bons-plans", "/recherche", "/en/", "/en"} | {c for c, _ in ENTREES}
    for nom in ("clic.js", "comparatif.js"):
        src = (pathlib.Path(__file__).resolve().parents[1] / "service" / "site" / nom).read_text(encoding="utf-8")
        debut = src.index("location.pathname")
        corps = src[debut:src.index('return "autre"', debut)]
        chemins = set(re.findall(r'"(/[^"]*)"', corps)) - {"/index.html"}
        assert chemins, nom
        for c in chemins:
            assert c in reels or any(r.startswith(c) for r in reels), f"{nom} : {c} n'est pas une adresse du site"
        assert "/gratuits" in chemins, nom
