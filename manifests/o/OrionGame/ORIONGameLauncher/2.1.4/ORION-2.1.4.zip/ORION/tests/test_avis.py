"""« Donnez votre avis » (2.1.2) : trois questions precises plutot que « tu
en penses quoi ? ». Un lien discret sous l'encart de version ; la fenetre ne
s'ouvre jamais d'elle-meme (choix de l'auteur, 12 octobre)."""
import json
import os
from pathlib import Path

from orion import avis

RACINE = Path(__file__).resolve().parent.parent


def _app():
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


def test_le_message_garde_les_reponses_telles_quelles(monkeypatch):
    envois = []
    monkeypatch.setattr("orion.signalement.envoyer", lambda titre, texte: envois.append((titre, texte)) or 7)
    assert avis.envoyer({"utile": "les prix", "gene": "", "manque": "le mode manette"}, "Peut-etre") == 7
    titre, texte = envois[0]
    assert titre == "Avis : Peut-etre"
    assert "les prix" in texte and "le mode manette" in texte and "gene" not in texte.split("\n")[0]
    assert avis.QUESTION_CHOIX in texte
    assert avis.message({"utile": "x"}, "")[0] == "Avis"


def test_un_avis_vide_ne_part_pas():
    assert avis.vide({"utile": " ", "gene": "", "manque": ""}, "")
    assert not avis.vide({"utile": "", "gene": "", "manque": ""}, "Oui")
    assert not avis.vide({"utile": "x"}, "")


def test_jamais_de_fenetre_d_elle_meme():
    # plus de compteur de parties ni de « Plus tard » : rien ne la declenche
    for nom in ("compter_partie", "a_demander", "plus_tard", "jamais"):
        assert not hasattr(avis, nom), nom
    fond = (RACINE / "orion" / "ui" / "fond.py").read_text(encoding="utf-8")
    fenetre = (RACINE / "orion" / "ui" / "main_window.py").read_text(encoding="utf-8")
    assert "_proposer_avis" not in fond and "_proposer_avis" not in fenetre
    assert "from .. import avis" not in fenetre


def test_la_fenetre():
    app = _app()
    from orion.ui.widgets.dialogues import DialogueAvis
    d = DialogueAvis()
    d.zones["gene"].setPlainText("la case DLSS")
    d._envoyer()                               # pas de choix mais du texte : part
    assert d.action == DialogueAvis.ENVOYER
    reponses, choix = d.valeurs()
    assert reponses["gene"] == "la case DLSS" and choix == ""
    vide = DialogueAvis()
    vide._envoyer()
    assert vide.action == DialogueAvis.ANNULER and not vide.aide.isHidden()
    vide.choix_boutons["Non"].setChecked(True)
    assert vide.valeurs()[1] == "Non"
    textes = {b.text() for b in vide.findChildren(type(vide.choix_boutons["Non"]))}
    assert "Plus tard" not in textes and "Ne plus demander" not in textes and "Annuler" in textes
    app.processEvents()


def test_le_lien_est_sous_l_encart_de_version():
    _app()
    from orion.ui.widgets.sidebar import Sidebar
    s = Sidebar()
    lay = s.layout()
    widgets = [lay.itemAt(i).widget() for i in range(lay.count())]
    i_version, i_avis = widgets.index(s.version), widgets.index(s.avis)
    assert i_avis == i_version + 1 and i_avis == len(widgets) - 1
    assert s.avis.text() == "Donnez votre avis" and s.avis.objectName() == "AvisDiscret"
    vus = []
    s.avis_demande.connect(lambda: vus.append(1))
    s.avis.click()
    assert vus == [1]


def test_les_textes_de_la_fenetre_sont_traduits():
    en = json.loads((RACINE / "orion" / "langues" / "en.json").read_text(encoding="utf-8"))["exact"]
    fr = json.loads((RACINE / "orion" / "langues" / "fr.json").read_text(encoding="utf-8"))["exact"]
    for _cle, question in avis.QUESTIONS:
        assert question in en
    for texte in (avis.QUESTION_CHOIX, "Peut-etre", "Donnez votre avis", "Votre avis sur ORION",
                  "Avis envoye. Merci, il sera lu !"):
        assert texte in en, texte
    assert fr["Peut-etre"] == "Peut-être"
    assert "été" in fr["Qu'est-ce qui vous a ete le plus utile ?"]
    assert "Donner mon avis" not in en and "Ne plus demander" not in en
