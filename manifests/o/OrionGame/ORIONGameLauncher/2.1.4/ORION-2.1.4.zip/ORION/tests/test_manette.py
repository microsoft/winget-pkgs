"""Pont manette (orion/ui/gamepad.py) : 15 octobre 2026, journal de l'auteur :
« DRAGON BALL : deja lance » six fois en deux secondes pendant la partie, puis
Start bascule ORION en affichage salon depuis l'arriere-plan (et plantage)."""
import os
import types

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")


@pytest.fixture
def app():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


def _pont(app, boutons: list[int], devant: bool):
    from orion.ui import gamepad as G
    pont = G.GamepadBridge.__new__(G.GamepadBridge)
    from PySide6.QtCore import QObject
    QObject.__init__(pont)
    pont.xinput = object(); pont.available = True
    pont._pressed = {}; pont._was_connected = False
    etats = list(boutons)
    pont._state = lambda: (None if etats[0] is None else types.SimpleNamespace(wButtons=etats[0], sThumbLX=0, sThumbLY=0)) if etats else None
    def avancer():
        etats.pop(0)
    pont.au_premier_plan = lambda: devant
    recues = []
    pont.action.connect(recues.append)
    return pont, recues, avancer


def test_bouton_tenu_a_la_connexion_ne_declenche_rien(app):
    from orion.ui import gamepad as G
    X = next(m for m, n in G.BUTTONS.items() if n == "x")
    # X deja enfonce quand la manette apparait, relache, puis enfonce a nouveau
    pont, recues, avancer = _pont(app, [X, X, 0, X], devant=True)
    for _ in range(4):
        pont._poll(); avancer()
    assert recues == ["x"]                      # un seul appui compte : le vrai


def test_rien_quand_orion_est_derriere_un_jeu(app):
    from orion.ui import gamepad as G
    X = next(m for m, n in G.BUTTONS.items() if n == "x")
    START = next(m for m, n in G.BUTTONS.items() if n == "start")
    pont, recues, avancer = _pont(app, [0, X, 0, START, 0], devant=False)
    for _ in range(5):
        pont._poll(); avancer()
    assert recues == []


def test_manette_perdue_et_retrouvee_pendant_un_appui(app):
    """Le jeu prend la manette (etat illisible), la rend avec X encore
    enfonce : pas de relance."""
    from orion.ui import gamepad as G
    X = next(m for m, n in G.BUTTONS.items() if n == "x")
    pont, recues, avancer = _pont(app, [0, X, None, X, X, 0], devant=True)
    for _ in range(6):
        pont._poll(); avancer()
    assert recues == ["x"]


def test_masques_xinput():
    """A, B, X, Y sont les boutons XInput 0x1000 a 0x8000 ; LB et RB a part."""
    from orion.ui import gamepad as G
    assert G.BUTTONS[0x1000] == "a" and G.BUTTONS[0x2000] == "b"
    assert G.BUTTONS[0x4000] == "x" and G.BUTTONS[0x8000] == "y"
    assert G.BUTTONS[0x0100] == "lb" and G.BUTTONS[0x0200] == "rb"
    assert len(set(G.BUTTONS.values())) == len(G.BUTTONS)
