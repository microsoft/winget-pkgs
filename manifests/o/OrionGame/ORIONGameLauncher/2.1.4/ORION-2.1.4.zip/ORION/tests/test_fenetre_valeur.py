"""« Valeur estimee de ma bibliotheque » (2.1.1) : la liste des jeux comptes,
du plus cher au moins cher, et la carte a enregistrer."""
import pytest

from orion.valeur_catalogue import Valeur


@pytest.fixture(scope="module")
def app():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


def _valeur():
    liste = [{"titre": t, "appid": str(i), "normal": n, "actuel": a, "origine": o}
             for i, (t, n, a, o) in enumerate([("Hades", 24.5, 24.5, "steam"), ("Starfield", 69.99, 34.99, "steam"),
                                               ("Counter-Strike 2", 0.0, 0.0, "steam"),
                                               ("Elden Ring", 59.99, 59.99, "releve")])]
    liste.sort(key=lambda x: (-x["normal"], x["titre"]))
    return Valeur(total=154.48, actuel=119.48, estimes=4, gratuits=1, jeux=5, liste=liste)


def test_estimer_garde_la_liste_triee():
    from orion import valeur_catalogue as vc
    v = vc.estimer([{"uid": "a", "titre": "B", "appid": "", "prix": (10.0, 5.0), "origine": "boutique"},
                    {"uid": "b", "titre": "A", "appid": "", "prix": (30.0, 30.0), "origine": "releve"},
                    {"uid": "c", "titre": "C", "appid": "", "prix": None, "origine": ""}], reseau_autorise=False)
    assert [j["titre"] for j in v.liste] == ["A", "B"] and v.liste[1]["actuel"] == 5.0
    assert Valeur.from_dict(v.to_dict()).liste == v.liste           # gardee entre deux demarrages


def test_fenetre_liste_les_jeux_payants_du_plus_cher(app):
    from PySide6.QtWidgets import QLabel
    from orion.ui.widgets.fenetre_valeur import FenetreValeur, LigneJeu
    f = FenetreValeur(_valeur())
    lignes = f.findChildren(LigneJeu)
    titres = [[l.text() for l in x.findChildren(QLabel)][1] for x in lignes]
    assert titres == ["Starfield", "Elden Ring", "Hades"]               # gratuits a part
    textes = " ".join(l.text() for l in f.findChildren(QLabel))
    assert "1 jeux gratuits" in textes or "1 jeux gratuits, comptes 0." in textes
    assert "1 jeux sans prix connu" in textes
    assert "Steam" in textes and "Fiche du jeu" in textes


def test_carte_de_joueur_avec_pseudo_et_photo(app, tmp_path, monkeypatch):
    from PySide6.QtGui import QColor, QImage
    from orion.core.config import CONFIG
    from orion.ui import carte_joueur
    from orion.ui.widgets.fenetre_valeur import FenetreValeur, image_carte
    gardes = {}
    monkeypatch.setattr(CONFIG, "get", lambda cle, defaut=None: gardes.get(cle, defaut))
    monkeypatch.setattr(CONFIG, "set", lambda cle, valeur, save=True: gardes.__setitem__(cle, valeur))
    v = _valeur()
    sans = image_carte(v)
    assert (sans.width(), sans.height()) == (1200, 630)
    photo = tmp_path / "moi.png"
    img = QImage(300, 200, QImage.Format.Format_RGB32)
    img.fill(QColor("#ff0000"))
    img.save(str(photo))
    assert carte_joueur.photo_carree(photo).width() == 200          # recadree en carre
    assert carte_joueur.photo_carree(tmp_path / "absente.png") is None
    assert carte_joueur.initiales("Fox Sikh") == "FS" and carte_joueur.initiales("Sikher") == "SI"
    f = FenetreValeur(v)
    f.pseudo.setText("Sikher")
    f.poser_photo(str(photo))
    assert gardes == {"carte.pseudo": "Sikher", "carte.photo": str(photo)}   # garde sur ce PC
    assert f.image() != sans and not f.apercu.pixmap().isNull()
    chemin = tmp_path / "carte"
    assert f.enregistrer_carte(str(chemin)) and (tmp_path / "carte.png").stat().st_size > 20_000
    assert "Image enregistree" in f.etat.text()
    f.poser_photo(str(tmp_path / "pas-une-image.png"))
    assert gardes["carte.photo"] == str(photo) and "ne se lit pas" in f.etat.text()


def test_le_bouton_de_la_bibliotheque_ouvre_la_fenetre(app, monkeypatch):
    from orion.ui.views.library_view import LibraryView
    from orion.ui.widgets import fenetre_valeur as fv
    ouvertes = []
    monkeypatch.setattr(fv.FenetreValeur, "exec", lambda self: ouvertes.append(self.valeur) or 0)
    lv = LibraryView()
    lv.set_valeur(_valeur())
    lv.valeur.click()
    assert ouvertes and ouvertes[0].total == pytest.approx(154.48)


def test_titres_sans_marques_et_pas_d_etoile_sous_le_texte(app):
    from PySide6.QtCore import QPointF
    from orion.ui import carte_joueur as cj
    assert cj.titre_propre("Call of Duty®: Modern Warfare® II") == "Call of Duty: Modern Warfare II"
    assert cj.titre_propre("Battlefield™ 6") == "Battlefield 6"
    # pied de la carte : l'etoile qui se lisait comme un accent sous « publicite »
    assert any(z.contains(QPointF(640, 556)) for z in cj.SANS_ETOILES)


def test_la_fenetre_s_ouvre_sans_poser_400_lignes_d_un_coup(app):
    # 2.1.1 : 1,1 a 1,4 s figees a l'ouverture (400 lignes, une feuille de
    # style par element) ; les lignes suivantes arrivent par paquets
    import time
    from orion.ui.widgets import fenetre_valeur as fv
    liste = [{"titre": f"Jeu {i}", "appid": str(i), "normal": 60 - i * 0.1, "actuel": 30.0,
              "origine": "steam"} for i in range(120)]
    f = fv.FenetreValeur(Valeur(total=5000, actuel=3000, estimes=120, gratuits=0, jeux=120, liste=liste))
    assert len(f.findChildren(fv.LigneJeu)) == fv.PREMIERES
    fin = time.perf_counter() + 2
    while time.perf_counter() < fin and len(f.findChildren(fv.LigneJeu)) < 120:
        app.processEvents()
    lignes = [x for x in f.findChildren(fv.LigneJeu)]
    assert len(lignes) == 120
    # dans l'ordre, du plus cher au moins cher, avant les notes du bas
    lay = f._liste_lay
    rangs = [int(lay.itemAt(i).widget().findChildren(fv.QLabel)[0].text()) for i in range(120)]
    assert rangs == list(range(1, 121))
    assert all(not x.styleSheet() for x in lignes[0].findChildren(fv.QLabel))
