"""Actualisation de la Boutique en deux temps (7 octobre 2026).

Chez l'auteur, l'actualisation prenait 95 secondes : sources lues l'une
apres l'autre, prix Steam demandes par quarante avec 1,2 s d'attente entre
deux lectures, puis types de jeu, fiches detaillees et plus bas historiques,
le tout avant d'afficher quoi que ce soit.

  - `actualiser` : les vitrines en meme temps, puis le catalogue avec ce qui
    est deja connu. Rien d'autre.
  - `completer` : le reste, catalogue deja affiche.
"""
import threading
import time

import pytest

from orion import boutique
from orion.plugins.boutique import steam
from orion.plugins.boutique.base import Offre, SourceUnavailable

COMPLETER = boutique.BoutiqueService.completer


class _Vitrine:
    def __init__(self, sid, offres=(), barriere=None, panne=False):
        self.id, self.label = sid, sid.capitalize()
        self.offres, self.barriere, self.panne = list(offres), barriere, panne

    def available(self):
        return True

    def vitrine(self):
        if self.barriere is not None:
            self.barriere.wait()            # ne passe que si toutes les sources sont la ensemble
        if self.panne:
            raise SourceUnavailable(self.id + " injoignable")
        return list(self.offres)


def _offre(titre, appid, prix=9.99, normal=19.99, source="steam", boutique_="Steam"):
    return Offre(titre=titre, boutique=boutique_, prix=prix, prix_normal=normal, source=source,
                 remise=int(round(100 - prix * 100 / normal)) if normal > prix else 0,
                 url=f"https://store.steampowered.com/app/{appid}", steam_appid=str(appid),
                 type_article="game")


@pytest.fixture()
def service(base_neuve, monkeypatch):
    from orion import prix_gamesplanet
    appels = []
    monkeypatch.setattr(prix_gamesplanet, "actualiser", lambda: appels.append("gamesplanet") or False)
    monkeypatch.setattr(boutique.BoutiqueService, "completer", COMPLETER)
    s = boutique.BoutiqueService()
    s.fiches = []
    s.appels = appels
    monkeypatch.setattr(s, "enrichir", lambda appids, limite=600: appels.append("fiches") or 0)
    monkeypatch.setattr(s, "relever_plus_bas", lambda fiches=None: appels.append("plus bas") or 0)
    vraie = s.offres_par_type
    monkeypatch.setattr(s, "offres_par_type",
                        lambda relire=True: (appels.append("types" if relire else "types gardes"),
                                             vraie(relire=False))[1])
    return s


def test_les_vitrines_sont_relevees_en_meme_temps(service):
    barriere = threading.Barrier(3, timeout=5)
    service._sources = [_Vitrine("steam", [_offre("Hades", 1145360)], barriere),
                        _Vitrine("itad", [_offre("Celeste", 504230, source="itad", boutique_="Fanatical")], barriere),
                        _Vitrine("gog", [], barriere)]
    fiches = service.actualiser()
    assert {f.titre for f in fiches} == {"Hades", "Celeste"}
    assert service.etat_sources["steam"] == "1 offres" and service.actualise_le > time.time() - 5


def test_l_actualisation_ne_fait_que_les_prix_du_jour(service):
    service._sources = [_Vitrine("steam", [_offre("Hades", 1145360)])]
    service.actualiser()
    # ni relecture des types, ni fiches detaillees, ni plus bas : c'est pour `completer`
    assert service.appels == ["gamesplanet", "types gardes"]
    assert boutique.BoutiqueService().fiches[0].titre == "Hades"        # enregistre des la premiere partie
    del service.appels[:]
    service.completer()
    assert service.appels[:3] == ["types", "fiches", "plus bas"]


def test_completer_dit_s_il_faut_reafficher(service, monkeypatch):
    service._sources = [_Vitrine("steam", [_offre("Hades", 1145360, 12.25, 24.5)])]
    service.actualiser()
    assert service.completer() is False                 # rien de neuf : la page n'est pas redessinee

    def plus_bas(fiches=None):
        service._table_bas()
        service._bas_memo["1145360"] = {"id": "x", "bas": 12.25, "devise": "EUR", "le": time.time()}
        return 1
    monkeypatch.setattr(service, "relever_plus_bas", plus_bas)
    assert service.completer() is True
    assert service.fiches[0].plus_bas_historique == 12.25 and service.fiches[0].au_plus_bas


def test_une_source_en_panne_garde_ses_offres_et_une_etape_en_echec_n_arrete_rien(service, monkeypatch):
    service._sources = [_Vitrine("steam", [_offre("Hades", 1145360)]),
                        _Vitrine("itad", [_offre("Celeste", 504230, source="itad", boutique_="Fanatical")])]
    service.actualiser()
    avant = service.actualise_le
    service._sources[1].panne = True
    service._sources[0].offres = [_offre("Hades", 1145360, 4.99)]
    fiches = service.actualiser()
    assert {f.titre for f in fiches} == {"Hades", "Celeste"}            # Celeste : offres precedentes
    assert "injoignable" in service.etat_sources["itad"] and service.actualise_le >= avant

    def casse(*a, **k):
        raise RuntimeError("fiches illisibles")
    monkeypatch.setattr(service, "enrichir", casse)
    service.completer()                                 # ne leve pas
    assert "plus bas" in service.appels


def test_la_vitrine_steam_lit_ses_prix_par_cent(monkeypatch):
    """Trois appels groupes au lieu de sept espaces de 1,2 s."""
    vus = {"articles": [], "anciens": 0}

    def fetch(url, params=None, **kw):
        if url == steam.FEATURED:
            return {"specials": {"items": [{"id": 10, "type": 0, "name": "A la une", "final_price": 500,
                                            "original_price": 1000, "discount_percent": 50}]}}
        return {"items": [{"name": f"Jeu {i}", "logo": f"https://x/steam/apps/{100 + i}/c.jpg"}
                          for i in range(3)]}

    def articles(ids):
        vus["articles"].append(list(ids))
        return [{"appid": int(a), "id": int(a), "success": 1, "visible": True, "type": 0,
                 "name": f"Jeu {a}", "best_purchase_option": {"final_price_in_cents": "999"}}
                for a in ids if a != "101"] + [{"appid": 999, "type": 0, "success": 1, "name": "Intrus",
                                                "best_purchase_option": {"final_price_in_cents": "1"}}]
    monkeypatch.setattr(steam, "fetch_json", fetch)
    monkeypatch.setattr(steam, "articles", articles)
    monkeypatch.setattr(steam.SteamBoutique, "prix",
                        lambda self, noms: vus.__setitem__("anciens", vus["anciens"] + 1) or [])
    offres = steam.SteamBoutique().vitrine()
    assert vus["articles"] == [["100", "101", "102"]] and vus["anciens"] == 0
    # le jeu sans prix est absent, l'article non demande aussi
    assert sorted(o.steam_appid for o in offres) == ["10", "100", "102"]
    # service groupe muet : l'ancienne lecture prend le relais
    monkeypatch.setattr(steam, "articles", lambda ids: (_ for _ in ()).throw(SourceUnavailable("x")))
    steam.SteamBoutique().vitrine()
    assert vus["anciens"] == 1
