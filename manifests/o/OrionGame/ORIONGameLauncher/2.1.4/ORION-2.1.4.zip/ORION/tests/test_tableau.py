"""Tableau de suivi de l'auteur : la page servie par le service et la
visionneuse Android qui l'ouvre. Les essais du service lui-meme (cle, lecture
seule, fil horodate) sont dans service/essai_worker.mjs, lances par
test_compteur.py."""
import re
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

from orion import partage

SERVICE = Path(__file__).parents[1] / "service"


def test_le_tableau_dans_un_vrai_navigateur():
    """Cle refusee, cle juste, tris, fil horodate, signalement piege affiche
    comme du texte : a la taille d'un telephone, sur des chiffres inventes."""
    if not shutil.which("node"):
        pytest.skip("node absent")
    pytest.importorskip("playwright")
    r = subprocess.run([sys.executable, "essai_tableau.py"], cwd=SERVICE,
                       capture_output=True, text=True, timeout=180)
    if "Executable doesn't exist" in r.stderr or "ERR_UNKNOWN_BUILTIN_MODULE" in r.stderr:
        pytest.skip("navigateur ou sqlite absent")
    assert r.returncode == 0 and "tableau ok" in r.stdout, r.stderr[-2000:]


def test_aucune_cle_dans_les_sources():
    """La cle du tableau est un secret du service, saisi par l'auteur : ni le
    service, ni la page, ni l'application du telephone n'en contiennent."""
    worker = (SERVICE / "worker.js").read_text(encoding="utf-8")
    assert "env.CLE_TABLEAU" in worker
    assert not re.search(r"CLE_TABLEAU\s*[:=]\s*[\"']", worker)
    java = (SERVICE / "suivi-android" / "src" / "com" / "orionlauncher" / "suivi"
            / "MainActivity.java").read_text(encoding="utf-8")
    assert "Bearer" not in java and "CLE_TABLEAU" not in java
    assert not list((SERVICE / "suivi-android").rglob("*.jks"))
    assert not list((SERVICE / "suivi-android").rglob("*.keystore"))


def test_la_page_n_interprete_jamais_un_texte_recu():
    """Un signalement est un texte libre envoye par n'importe qui."""
    worker = (SERVICE / "worker.js").read_text(encoding="utf-8")
    page = worker[worker.index("const TABLEAU = String.raw`"):worker.index("// Icone de l'application")]
    for interdit in ("innerHTML", "outerHTML", "insertAdjacentHTML", "document.write", "eval(", "new Function"):
        assert interdit not in page, interdit
    assert "default-src 'none'" in worker and "frame-ancestors 'none'" in worker


def test_la_visionneuse_n_ouvre_que_le_service():
    dossier = SERVICE / "suivi-android"
    java = (dossier / "src" / "com" / "orionlauncher" / "suivi" / "MainActivity.java").read_text(encoding="utf-8")
    hote = re.search(r'HOTE = "([^"]+)"', java).group(1)
    assert partage.SERVICE == "https://" + hote
    assert 'ADRESSE = "https://" + HOTE + "/tableau"' in java
    assert "setAllowFileAccess(false)" in java and "MIXED_CONTENT_NEVER_ALLOW" in java
    # 1.1 : la page confie la cle a l'application (veille en arriere-plan), rien d'autre.
    # Le pont n'expose que deux methodes, et ne rend rien a la page.
    assert java.count("@JavascriptInterface") == 2
    assert re.search(r"@JavascriptInterface\s+public void cle\(String", java)
    assert re.search(r"@JavascriptInterface\s+public void oublier\(\)", java)
    assert "addJavascriptInterface(new Pont(), \"Suivi\")" in java
    manifeste = (dossier / "AndroidManifest.xml").read_text(encoding="utf-8")
    assert 'android:allowBackup="false"' in manifeste     # la cle saisie ne part pas dans une sauvegarde
    assert 'android:usesCleartextTraffic="false"' in manifeste
    assert re.findall(r"uses-permission android:name=\"([^\"]+)\"", manifeste) == [
        "android.permission.INTERNET", "android.permission.POST_NOTIFICATIONS", "android.permission.RECEIVE_BOOT_COMPLETED"]
    assert 'android:exported="false"' in manifeste and 'android:name=".Veille"' in manifeste
    # la veille ne lit que le service et les chiffres publics de GitHub, avec la cle rangee en prive
    controle = (dossier / "src" / "com" / "orionlauncher" / "suivi" / "Controle.java").read_text(encoding="utf-8")
    hotes = set(re.findall(r'"https://([a-z0-9.-]+)', controle))
    assert hotes == {"api.github.com"}, hotes             # le service : par MainActivity.HOTE
    assert "MainActivity.HOTE" in controle and "setRequestMethod(\"POST\")" not in controle
    memoire = (dossier / "src" / "com" / "orionlauncher" / "suivi" / "Memoire.java").read_text(encoding="utf-8")
    assert "MODE_PRIVATE" in memoire
    assert not re.search(r"CLE_TABLEAU\s*[:=]\s*[\"']", controle + memoire)
    # la page ne parle a l'application que par ce pont, et seulement pour la cle
    worker = (SERVICE / "worker.js").read_text(encoding="utf-8")
    lignes = worker.splitlines()
    ou = [i for i, l in enumerate(lignes) if "window.Suivi" in l]
    assert len(ou) == 1 and "function pont(" in lignes[ou[0] - 1]   # une seule ligne, dans pont()
    assert 'pont("cle", lire(CLE))' in worker and 'pont("oublier")' in worker
