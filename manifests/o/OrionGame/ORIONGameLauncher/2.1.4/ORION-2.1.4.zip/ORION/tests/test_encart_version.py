"""Encart « version » en bas a gauche (1.7.1) : verification GitHub,
installation en un clic, redemarrage."""
import time

import pytest

PySide6 = pytest.importorskip("PySide6")
from PySide6.QtWidgets import QApplication, QLabel, QWidget  # noqa: E402

from orion import maj  # noqa: E402
from orion.version import APP_VERSION  # noqa: E402


@pytest.fixture(scope="module")
def app():
    return QApplication.instance() or QApplication([])


def attendre(app, condition, secondes=5.0):
    fin = time.time() + secondes
    while time.time() < fin:
        app.processEvents()
        if condition():
            return True
        time.sleep(0.01)
    return condition()


def publication(version, verifiable=True):
    return maj.Publication(version=version, url="https://exemple/i.exe" if verifiable else "",
                           sha256="a" * 64 if verifiable else "",
                           page="https://github.com/x/releases/latest")


@pytest.fixture
def fenetre(app, monkeypatch, tmp_path):
    from orion.core.config import CONFIG
    from orion.ui.fond import FondMixin
    from orion.ui.widgets.sidebar import Sidebar

    CONFIG.set("maj.afficher_version", True)
    CONFIG.set("maj.auto", True)
    CONFIG.set("jeu.discret", True)

    class Fenetre(QWidget, FondMixin):
        def __init__(self):
            super().__init__()
            self.sidebar = Sidebar()
            self.status_label = QLabel()
            self.notes = []
            self._maj_en_cours = False
            self._maj_pub = None
            self._maj_proposee = ""
            self._differe = set()
            self.sessions = []

            class _V:
                actif = False
            self.veille_jeu = _V()

        def notify(self, texte, secondes=5):
            self.notes.append(texte)

    f = Fenetre()
    f.sidebar.version_cliquee.connect(f._version_cliquee)
    return f


def test_encart_a_jour_puis_nouvelle_version(app, fenetre, monkeypatch):
    monkeypatch.setattr(maj, "verifier", lambda garder=1800: publication(APP_VERSION))
    fenetre.verifier_maj(silencieux=True)
    assert attendre(app, lambda: fenetre.sidebar.version.etat == "a_jour")
    assert APP_VERSION in fenetre.sidebar.version.ligne1.text()

    monkeypatch.setattr(maj, "verifier", lambda garder=1800: publication("99.0.0"))
    fenetre.verifier_maj(silencieux=True)
    assert attendre(app, lambda: fenetre.sidebar.version.etat == "disponible")
    assert "99.0.0" in fenetre.sidebar.version.ligne1.text()
    # pas de fenetre surgissante : un simple rappel suffit, une seule fois
    assert sum("99.0.0" in n for n in fenetre.notes) == 1
    fenetre.verifier_maj(silencieux=True)
    attendre(app, lambda: fenetre.sidebar.version.etat == "disponible")
    assert sum("99.0.0" in n for n in fenetre.notes) == 1


def test_clic_telecharge_installe_et_redemarre(app, fenetre, monkeypatch, tmp_path):
    fenetre._maj_pub = publication("99.0.0")
    fenetre.sidebar.set_version("disponible", "99.0.0")
    fichier = tmp_path / "Installateur-ORION-99.0.0.exe"
    fichier.write_bytes(b"x")
    etapes = []

    def telecharger(pub, progress_cb=None):
        for p in (10, 60, 100):
            progress_cb("Telechargement", p)
            etapes.append(p)
        return fichier

    monkeypatch.setattr(maj, "telecharger", telecharger)
    monkeypatch.setattr(maj, "installer", lambda chemin: etapes.append(("installe", chemin)) or True)
    quitte = []
    monkeypatch.setattr(type(fenetre), "_quitter_pour_maj", lambda self: quitte.append(True))

    fenetre._version_cliquee("disponible")
    assert attendre(app, lambda: ("installe", fichier) in etapes)
    assert fenetre.sidebar.version.etat == "installation"
    assert attendre(app, lambda: quitte, 3)
    assert etapes[:3] == [10, 60, 100]


def test_echec_puis_reessai(app, fenetre, monkeypatch):
    from PySide6.QtWidgets import QMessageBox
    monkeypatch.setattr(QMessageBox, "warning", staticmethod(lambda *a, **k: None))
    fenetre._maj_pub = publication("99.0.0")

    def rate(pub, progress_cb=None):
        raise RuntimeError("empreinte differente")
    monkeypatch.setattr(maj, "telecharger", rate)
    fenetre._version_cliquee("disponible")
    assert attendre(app, lambda: fenetre.sidebar.version.etat == "erreur")
    assert fenetre._maj_en_cours is False

    appels = []
    monkeypatch.setattr(fenetre, "_lancer_maj", lambda pub: appels.append(pub.version))
    fenetre._version_cliquee("erreur")
    assert appels == ["99.0.0"]


def test_sans_empreinte_ouvre_la_page(app, fenetre, monkeypatch):
    import webbrowser
    ouvert = []
    monkeypatch.setattr(webbrowser, "open", lambda u: ouvert.append(u))
    fenetre._maj_pub = publication("99.0.0", verifiable=False)
    fenetre._version_cliquee("disponible")
    assert ouvert == ["https://github.com/x/releases/latest"]


def test_hors_ligne_garde_la_derniere_info(app, fenetre, monkeypatch):
    fenetre._maj_pub = publication("99.0.0")

    def injoignable(garder=1800):
        raise ConnectionError("hors ligne")
    monkeypatch.setattr(maj, "verifier", injoignable)
    fenetre.verifier_maj(silencieux=True)
    assert attendre(app, lambda: fenetre.sidebar.version.etat == "disponible")


def test_clic_a_jour_verifie_a_nouveau(app, fenetre, monkeypatch):
    gardes = []
    monkeypatch.setattr(maj, "verifier",
                        lambda garder=1800: gardes.append(garder) or publication(APP_VERSION))
    fenetre._version_cliquee("a_jour")
    assert attendre(app, lambda: gardes and fenetre.sidebar.version.etat == "a_jour")
    assert gardes == [1]          # reponse fraiche quand on clique


def test_option_masque_l_encart(app, fenetre):
    fenetre.sidebar.afficher_version(False)
    assert fenetre.sidebar.version.isHidden()
    fenetre.sidebar.afficher_version(True)
    assert not fenetre.sidebar.version.isHidden()


# ----------------------------------------------------------------------
# installation tout ou rien (panne de la mise a jour 1.7.0 -> 1.7.1)
# ----------------------------------------------------------------------
def _programme(dossier, contenu):
    dossier.mkdir(parents=True)
    (dossier / "ORION.exe").write_text(contenu)
    (dossier / "_internal").mkdir()
    (dossier / "_internal" / "VCRUNTIME140.dll").write_text(contenu)


def test_installation_remplace_tout(tmp_path, monkeypatch):
    from orion.deploiement import installation as inst
    monkeypatch.setattr(inst, "make_shortcut", lambda *a, **k: True)
    monkeypatch.setattr(inst, "register_uninstall", lambda *a, **k: True)
    _programme(tmp_path / "paquet", "neuf")
    _programme(tmp_path / "Programs" / "ORION", "ancien")
    ok, _ = inst.install(tmp_path / "paquet", tmp_path / "Programs" / "ORION", False)
    assert ok
    cible = tmp_path / "Programs" / "ORION"
    assert (cible / "ORION.exe").read_text() == "neuf"
    assert (cible / "_internal" / "VCRUNTIME140.dll").read_text() == "neuf"
    assert sorted(p.name for p in (tmp_path / "Programs").iterdir()) == ["ORION"]


def test_installation_verrouillee_ne_touche_a_rien(tmp_path, monkeypatch):
    """Un fichier encore utilise : l'ancienne version doit rester intacte
    (en 1.7.1, tout etait efface sauf le fichier verrouille)."""
    from pathlib import Path
    from orion.deploiement import installation as inst
    monkeypatch.setattr(inst, "make_shortcut", lambda *a, **k: True)
    monkeypatch.setattr(inst, "register_uninstall", lambda *a, **k: True)
    monkeypatch.setattr(inst, "ATTENTE_VERROU", 1)
    _programme(tmp_path / "paquet", "neuf")
    cible = tmp_path / "Programs" / "ORION"
    _programme(cible, "ancien")
    vrai = Path.rename

    def rename(self, dest):
        if self == cible:
            raise PermissionError("fichier utilise par un autre processus")
        return vrai(self, dest)
    monkeypatch.setattr(Path, "rename", rename)
    ok, message = inst.install(tmp_path / "paquet", cible, False)
    assert not ok and "Rien n'a été modifié" in message
    assert (cible / "ORION.exe").read_text() == "ancien"
    assert (cible / "_internal" / "VCRUNTIME140.dll").read_text() == "ancien"
    assert sorted(p.name for p in (tmp_path / "Programs").iterdir()) == ["ORION"]


def test_installation_repare_un_dossier_a_moitie_vide(tmp_path, monkeypatch):
    from orion.deploiement import installation as inst
    monkeypatch.setattr(inst, "make_shortcut", lambda *a, **k: True)
    monkeypatch.setattr(inst, "register_uninstall", lambda *a, **k: True)
    _programme(tmp_path / "paquet", "neuf")
    cible = tmp_path / "Programs" / "ORION"
    (cible / "_internal").mkdir(parents=True)
    (cible / "_internal" / "VCRUNTIME140.dll").write_text("reste")
    ok, _ = inst.install(tmp_path / "paquet", cible, False)
    assert ok and (cible / "ORION.exe").read_text() == "neuf"


def test_restes_nettoyes(tmp_path):
    from orion.deploiement import installation as inst
    cible = tmp_path / "ORION"
    cible.mkdir()
    (tmp_path / "ORION.ancien-123").mkdir()
    inst.nettoyer_anciennes(cible)
    assert not (tmp_path / "ORION.ancien-123").exists() and cible.exists()


def test_environnement_propre(monkeypatch):
    from orion.deploiement.interface import environnement_propre
    monkeypatch.setenv("_PYI_APPLICATION_HOME_DIR", "x")
    monkeypatch.setenv("_MEIPASS2", "y")
    env = environnement_propre()
    assert "_PYI_APPLICATION_HOME_DIR" not in env and "_MEIPASS2" not in env
    assert env["PYINSTALLER_RESET_ENVIRONMENT"] == "1"
