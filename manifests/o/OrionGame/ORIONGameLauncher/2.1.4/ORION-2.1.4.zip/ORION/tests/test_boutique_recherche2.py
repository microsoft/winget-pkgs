"""Recherche de la Boutique, plus bas historiques, DLC et suivi : defauts
releves sur la 2.0 compilee le 6 octobre 2026.

  - « bo3 », « bo4 » ne trouvaient rien ; « F1 » rendait « Frontline 1942 » ;
    « F1 202 » ne rendait rien ; « borderlands » oubliait le premier
    Borderlands (la recherche Steam ne donnait que dix resultats, DLC compris).
  - « Au plus bas historique » ne montrait que huit jeux.
  - Les DLC s'affichaient sous les offres du jeu au lieu de les remplacer.
  - « Suivre » ne pouvait pas etre annule.
  - Le lien Loaded mettait les versions Xbox en tete.

Reponses de Steam et d'IsThereAnyDeal relevees ce jour-la (formes reelles,
raccourcies)."""
import time

import pytest

from orion import boutique
from orion.core import recherche as R
from orion.plugins.boutique import steam
from orion.plugins.boutique.base import Offre, SourceUnavailable
from test_boutique_refonte import _fiche

#: la vraie methode, que `conftest` remplace pour qu'aucun essai ne joigne le reseau
RELEVER = boutique.BoutiqueService.relever_plus_bas


# ---------------------------------------------------------------------------
# Notation
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("requete, titre, mini", [
    ("bo3", "Call of Duty®: Black Ops III", 0.84),
    ("bo4", "Call of Duty®: Black Ops 4", 0.84),
    ("black ops 3", "Call of Duty®: Black Ops III", 0.88),
    ("hades 2", "Hades II", 1.0),
    ("cs2", "Counter-Strike 2", 0.90),
    ("gta", "Grand Theft Auto V Enhanced", 0.90),
    ("gta5", "Grand Theft Auto V Enhanced", 0.90),
    ("gtav", "Grand Theft Auto V Enhanced", 0.90),
    ("bg3", "Baldur's Gate 3", 0.90),
    ("ff16", "FINAL FANTASY XVI", 0.90),
    ("ffxvi", "FINAL FANTASY XVI", 0.90),
    ("l4d2", "Left 4 Dead 2", 0.90),
    ("tlou", "The Last of Us™ Part I", 0.90),
    ("F1", "F1® 25", 0.97),
    ("F1 202", "F1® 2021", 0.97),
    ("borderland", "Borderlands Game of the Year Enhanced", 0.97),
])
def test_ce_que_les_joueurs_tapent_trouve_le_jeu(requete, titre, mini):
    assert R.score(requete, titre) >= mini


@pytest.mark.parametrize("requete, titre", [
    ("F1", "Frontline 1942"),            # « f » + « 1942 » n'est pas « F1 »
    ("F1", "FINAL FANTASY XVI"),
    ("bo3", "Borderlands 3"),
    ("bo", "Call of Duty®: Black Ops III"),   # deux lettres en cours de titre : n'importe quoi
    ("black ops 3", "Monster Ops 3"),
    ("F1 202", "F1® 25"),
])
def test_et_pas_un_autre(requete, titre):
    assert R.score(requete, titre) < 0.55


def test_sigles_de_serie_developpes():
    assert R.developper("bo3") == ["black ops 3"]
    assert R.developper("bo 4") == ["black ops 4"]
    assert R.developper("cod bo3") == ["call of duty black ops 3"]
    assert R.developper("l4d2") == ["left 4 dead 2"]
    assert R.developper("r6 siege") == ["rainbow six siege"]
    assert R.developper("tw3") == ["the witcher 3", "total war 3"]
    for intact in ("borderlands", "F1 202", "call of duty", "", "hades 2"):
        assert R.developper(intact) == []


def test_terme_sans_son_dernier_mot():
    assert R.raccourcir("F1 202") == "F1"
    assert R.raccourcir("hollow knight silk") == "hollow knight"
    assert R.raccourcir("F1") == "" and R.raccourcir("") == "" and R.raccourcir("a b") == ""


# ---------------------------------------------------------------------------
# Recherche du magasin Steam : les jeux seulement, trente resultats, prix compris
# ---------------------------------------------------------------------------
def _logo(appid):
    return f"https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/{appid}/capsule_sm_120.jpg?t=1"


def _article(appid, nom, final=None, normal=None, remise=0, **plus):
    it = {"item_type": 0, "id": appid, "appid": appid, "success": 1, "visible": True,
          "name": nom, "type": 0, "tagids": [], "assets": {}}
    if final is not None:
        it["best_purchase_option"] = {"final_price_in_cents": str(final)}
        if normal:
            it["best_purchase_option"].update(original_price_in_cents=str(normal), discount_pct=remise)
    it.update(plus)
    return it


BORDERLANDS = {"items": [
    {"name": "Borderlands 4", "logo": _logo(1285190)},
    {"name": "Borderlands 3", "logo": _logo(397540)},
    {"name": "Borderlands 2", "logo": _logo(49520)},
    {"name": "Borderlands Collection: Pandora's Box",
     "logo": "https://shared.akamai.steamstatic.com/store_item_assets/steam/bundles/32848/x/capsule_sm_120.jpg"},
    {"name": "Borderlands Game of the Year Enhanced", "logo": _logo(729040)},
    {"name": "F1® 2020", "logo": _logo(1080110)},
]}
ARTICLES = [
    _article(49520, "Borderlands 2", 499, 1999, 75),
    _article(729040, "Borderlands Game of the Year Enhanced", 599, 2999, 80),
    _article(1285190, "Borderlands 4", 6999),
    _article(397540, "Borderlands 3", 5999),
    _article(1080110, "F1® 2020", unlisted=True),          # retire de la vente : pas de prix
]


@pytest.fixture()
def magasin(monkeypatch):
    vus = {"recherches": [], "articles": []}

    def fetch(url, params=None, **kw):
        vus["recherches"].append((url, dict(params or {})))
        if url == steam.SEARCH_JSON:
            return vus.get("resultats", BORDERLANDS)
        return {"items": [{"type": "app", "id": 7, "name": "Secours",
                           "price": {"initial": 1000, "final": 500, "currency": "EUR"}}]}

    def articles(ids):
        vus["articles"].append(list(ids))
        if vus.get("panne_articles"):
            raise SourceUnavailable("Fiches Steam groupees : panne")
        return [a for a in ARTICLES if str(a["appid"]) in ids]
    def suggestions(terme, nombre=30):
        vus.setdefault("suggestions", []).append((terme, nombre))
        if "rapide" not in vus:
            raise SourceUnavailable("Recherche Steam : reponse 503")
        return vus["rapide"]
    monkeypatch.setattr(steam, "fetch_json", fetch)
    monkeypatch.setattr(steam, "articles", articles)
    monkeypatch.setattr(steam, "suggestions", suggestions)
    return vus


def test_steam_cherche_en_un_seul_appel(magasin):
    """La recherche du magasin rend noms, prix et fiches d'un coup."""
    magasin["rapide"] = [ARTICLES[2], ARTICLES[3], ARTICLES[0], ARTICLES[1], ARTICLES[4],
                         {**ARTICLES[0], "type": 4, "appid": 5, "id": 5, "name": "Un DLC"},
                         {**_article(6, "Reserve", 999), "content_descriptorids": [3]}]
    source = steam.SteamBoutique()
    offres = source.chercher("borderlands")
    assert magasin["suggestions"] == [("borderlands", 30)]
    assert magasin["recherches"] == [] and magasin["articles"] == []       # aucun autre appel
    assert [o.titre for o in offres] == ["Borderlands 4", "Borderlands 3", "Borderlands 2",
                                         "Borderlands Game of the Year Enhanced", "Reserve"]
    assert offres[3].prix == 5.99 and offres[3].remise == 80 and offres[4].adulte
    assert set(source.articles_recus) == {"1285190", "397540", "49520", "729040", "6"}


def test_la_demande_de_recherche_a_steam(monkeypatch):
    import json
    from orion.core import reseau
    vus = []

    class Rep:
        status_code = 200

        @staticmethod
        def json():
            return {"response": {"metadata": {"total_matching_records": 2}, "ids": [],
                                 "store_items": [ARTICLES[0], "x", None]}}

    def get(url, **kw):
        vus.append((url, json.loads(kw["params"]["input_json"])))
        return Rep()
    monkeypatch.setattr(reseau, "get", get)
    assert [i["name"] for i in steam.suggestions("black ops 3")] == ["Borderlands 2"]
    url, q = vus[0]
    assert url == "https://api.steampowered.com/IStoreQueryService/SearchSuggestions/v1/"
    assert q["search_term"] == "black ops 3" and q["max_results"] == 30
    assert q["filters"] == {"type_filters": {"include_games": True}}
    assert q["context"]["country_code"] == "FR"
    Rep.status_code = 503
    with pytest.raises(SourceUnavailable):
        steam.suggestions("black ops 3")


def test_steam_cherche_parmi_les_jeux_et_rend_le_premier_borderlands(magasin):
    source = steam.SteamBoutique()
    offres = source.chercher("borderlands")
    url, params = magasin["recherches"][0]
    assert url == steam.SEARCH_JSON
    assert params["term"] == "borderlands" and params["category1"] == 998 and params["count"] == 30
    # un seul appel groupe pour les prix, le lot (sans numero d'application) n'y est pas
    assert magasin["articles"] == [["1285190", "397540", "49520", "729040", "1080110"]]
    # l'ordre du magasin, le jeu retire de la vente en moins
    assert [o.titre for o in offres] == ["Borderlands 4", "Borderlands 3", "Borderlands 2",
                                         "Borderlands Game of the Year Enhanced"]
    goty = offres[-1]
    assert (goty.prix, goty.prix_normal, goty.remise, goty.steam_appid) == (5.99, 29.99, 80, "729040")
    assert offres[0].prix == offres[0].prix_normal == 69.99 and offres[0].type_article == "game"
    # les fiches lues sont gardees pour ne pas etre redemandees
    assert set(source.articles_recus) == {"1285190", "397540", "49520", "729040"}


def test_steam_sans_resultat_ne_demande_aucun_prix(magasin):
    magasin["resultats"] = {"items": []}
    assert steam.SteamBoutique().chercher("f1 202") == []
    assert magasin["articles"] == []


def test_steam_en_panne_de_fiches_revient_a_l_ancienne_recherche(magasin):
    magasin["panne_articles"] = True
    offres = steam.SteamBoutique().chercher("borderlands")
    assert [o.titre for o in offres] == ["Secours"] and offres[0].prix == 5.0
    assert magasin["recherches"][-1][0] == steam.STORE_SEARCH


# ---------------------------------------------------------------------------
# Service : la question est posee autrement quand la boutique ne comprend pas
# ---------------------------------------------------------------------------
class _Source:
    """Une boutique d'essai (pas une sous-classe de `SourceBoutique` : le
    registre des sources la prendrait pour une vraie)."""
    id, label = "essai", "Essai"

    def available(self):
        return True

    def __init__(self, catalogue):
        self.catalogue, self.demandes = catalogue, []

    def chercher(self, terme):
        self.demandes.append(terme)
        return [Offre(titre=t, boutique="Steam", prix=p, prix_normal=p, source="steam",
                      url=f"https://store.steampowered.com/app/{a}", steam_appid=str(a))
                for t, a, p in self.catalogue.get(terme.lower(), [])]


@pytest.fixture()
def service(base_neuve, monkeypatch):
    reglages = {"boutique.fiches_detaillees": False}
    vrai = boutique.CONFIG.get
    monkeypatch.setattr(boutique.CONFIG, "get",
                        lambda cle, defaut=None: reglages[cle] if cle in reglages else vrai(cle, defaut))
    s = boutique.BoutiqueService()
    s.fiches = []
    s.reglages = reglages
    return s


def _brancher(service, catalogue):
    source = _Source(catalogue)
    service._sources = [source]
    return source


def test_bo3_est_demande_aussi_sous_son_nom(service):
    source = _brancher(service, {
        "bo3": [("Robot Arena", 9, 1.0)],                 # ce que la boutique rend pour « bo3 »
        "black ops 3": [("Call of Duty®: Black Ops III", 311210, 59.99),
                        ("Monster Ops 3", 8, 4.0)]})
    fiches = service.chercher("bo3")
    # un sigle seul ne dit rien a une boutique : seule la forme developpee est posee
    assert source.demandes == ["black ops 3"]
    assert [f.titre for f in fiches] == ["Call of Duty®: Black Ops III"]
    # plusieurs mots : le terme tape est pose aussi
    del source.demandes[:]
    service.chercher("cod bo3")
    assert {"cod bo3", "call of duty black ops 3"} <= set(source.demandes)


def test_f1_202_retombe_sur_f1(service):
    source = _brancher(service, {
        "f1": [("F1® 25", 3059520, 34.99), ("F1® Manager 2024", 2591280, 34.99),
               ("F1® 24", 2488620, 69.99), ("Automobilista 2", 1066890, 36.99)]})
    fiches = service.chercher("F1 202")
    assert source.demandes == ["F1 202", "F1"]
    titres = [f.titre for f in fiches]
    # le titre qui porte « 202 » d'abord, puis les autres F1 ; rien d'etranger
    assert titres[0] == "F1® Manager 2024"
    assert set(titres) == {"F1® Manager 2024", "F1® 25", "F1® 24"}


def test_assez_de_resultats_pas_de_seconde_question(service):
    source = _brancher(service, {"hollow knight": [
        ("Hollow Knight", 1, 14.99), ("Hollow Knight: Silksong", 2, 19.99),
        ("Hollow Knight Pinball", 3, 14.99)]})
    assert len(service.chercher("hollow knight")) == 3
    assert source.demandes == ["hollow knight"]


def test_le_catalogue_repond_aux_sigles(service):
    _brancher(service, {})
    service.fiches = [_fiche("Call of Duty®: Black Ops III", "311210", 23.99, 59.99),
                      _fiche("Frontline 1942", "77", 5.0, 5.0)]
    assert [f.titre for f in service.chercher("bo3")] == ["Call of Duty®: Black Ops III"]
    assert service.chercher("F1") == []


# ---------------------------------------------------------------------------
# Plus bas historique de tout le catalogue
# ---------------------------------------------------------------------------
J = {"311210": "018d937f-0000-7000-8000-000000000001", "729040": "018d937f-0000-7000-8000-000000000002",
     "49520": "018d937f-0000-7000-8000-000000000003"}


@pytest.fixture()
def itad(monkeypatch):
    from orion import itad as acces
    appels = []
    bas = {J["311210"]: 19.79, J["729040"]: 5.99, J["49520"]: 2.99}

    def demander(methode, chemin, params=None, corps=None, timeout=15):
        appels.append((chemin, list(corps or [])))
        if getattr(demander, "panne", False):
            raise acces.Indisponible("IsThereAnyDeal : reponse 400")
        if chemin == "/lookup/id/shop/61/v1":
            return {c: J.get(c.split("/")[1]) for c in corps}
        if chemin == "/games/historylow/v1":
            assert params == {"country": "FR"}
            return [{"id": i, "low": {"shop": {"id": 61, "name": "Steam"},
                                      "price": {"amount": bas[i], "amountInt": int(bas[i] * 100),
                                                "currency": "EUR"}, "cut": 80}} for i in corps if i in bas]
        raise AssertionError(chemin)
    monkeypatch.setattr(acces, "demander", demander)
    monkeypatch.setattr(acces, "actif", lambda: True)
    monkeypatch.setattr(boutique.BoutiqueService, "relever_plus_bas", RELEVER)
    demander.appels = appels
    return demander


def _catalogue_bas():
    return [_fiche("Call of Duty®: Black Ops III", "311210", 59.99, 59.99),      # prix normal
            _fiche("Borderlands Game of the Year Enhanced", "729040", 5.99, 29.99),   # a son record
            _fiche("Borderlands 2", "49520", 4.99, 19.99),                       # en promo, pas au record
            _fiche("Inconnu d'ITAD", "999", 3.0, 10.0),
            _fiche("Gratuit", "730", 0.0, 0.0)]


def test_tous_les_jeux_recoivent_leur_plus_bas(service, itad):
    fiches = _catalogue_bas()
    assert service.relever_plus_bas(fiches) == 3
    chemins = [c for c, _ in itad.appels]
    assert chemins == ["/lookup/id/shop/61/v1", "/games/historylow/v1"]
    # les jeux en promotion d'abord, jamais les gratuits
    assert itad.appels[0][1] == ["app/729040", "app/49520", "app/999", "app/311210"]
    assert set(itad.appels[1][1]) == set(J.values())
    assert service.appliquer_plus_bas(fiches) == 3
    par_titre = {f.titre: f for f in fiches}
    assert par_titre["Borderlands 2"].plus_bas_historique == 2.99
    assert par_titre["Inconnu d'ITAD"].plus_bas_historique == 0
    # au plus bas : le prix du jour egale le record ET le jeu est en promotion
    assert [f.titre for f in fiches if f.au_plus_bas] == ["Borderlands Game of the Year Enhanced"]


def test_un_jeu_jamais_solde_n_est_pas_au_plus_bas():
    f = _fiche("Jamais solde", "5", 59.99, 59.99)
    f.offres[0].plus_bas_historique = 59.99
    assert not f.au_plus_bas
    f = _fiche("Solde", "6", 19.99, 59.99)
    f.offres[0].plus_bas_historique = 19.99
    assert f.au_plus_bas


def test_les_plus_bas_sont_gardes(service, itad):
    fiches = _catalogue_bas()
    service.relever_plus_bas(fiches)
    del itad.appels[:]
    assert service.relever_plus_bas(_catalogue_bas()) == 0
    assert itad.appels == []                 # ni identifiants, ni plus bas, ni le jeu inconnu
    # un autre service (ORION relance) relit la base, sans reseau
    autre = boutique.BoutiqueService()
    neuves = _catalogue_bas()
    assert autre.appliquer_plus_bas(neuves) == 3 and itad.appels == []
    # le lendemain, seuls les jeux en promotion sont relus
    for e in service._bas_memo.values():
        if e.get("le"):
            e["le"] -= 2 * 86400
    service.relever_plus_bas(_catalogue_bas())
    assert [c for c, _ in itad.appels] == ["/games/historylow/v1"]
    assert set(itad.appels[0][1]) == {J["729040"], J["49520"]}


def test_relais_pas_encore_a_jour_ou_en_panne_rien_ne_casse(service, itad):
    itad.panne = True
    fiches = _catalogue_bas()
    assert service.relever_plus_bas(fiches) == 0
    assert service.appliquer_plus_bas(fiches) == 0
    assert not any(f.au_plus_bas for f in fiches)
    # et les jeux seront redemandes au passage suivant
    itad.panne = False
    assert service.relever_plus_bas(fiches) == 3


def test_un_plus_bas_dans_une_autre_monnaie_n_est_pas_pose(service, itad):
    fiches = _catalogue_bas()
    service.relever_plus_bas(fiches)
    for e in service._bas_memo.values():
        if e.get("bas"):
            e["devise"] = "USD"
    assert service.appliquer_plus_bas(fiches) == 0


def test_la_recherche_releve_le_plus_bas_des_jeux_trouves(service, itad):
    _brancher(service, {"borderlands": [("Borderlands Game of the Year Enhanced", 729040, 5.99)]})
    fiches = service.chercher("borderlands")
    assert itad.appels == []                 # la recherche n'attend pas IsThereAnyDeal
    assert service.plus_bas_des_resultats(fiches) == 1       # releve apres l'affichage
    assert [c for c, _ in itad.appels] == ["/lookup/id/shop/61/v1", "/games/historylow/v1"]
    assert fiches[0].plus_bas_historique == 5.99
    del itad.appels[:]
    assert service.chercher("borderlands")[0].plus_bas_historique == 5.99
    assert itad.appels == []                 # deja connu : pose d'office, aucune demande


def test_reglage_coupe_aucune_demande(service, itad):
    service.reglages["boutique.plus_bas"] = False
    assert service.relever_plus_bas(_catalogue_bas()) == 0 and itad.appels == []


# ---------------------------------------------------------------------------
# Fiche : les DLC a la place des offres, « Suivre » reversible
# ---------------------------------------------------------------------------
@pytest.fixture()
def app():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


def test_les_dlc_prennent_la_place_des_offres(app):
    from orion.ui.views import boutique_view as B
    d = B.FicheDialogue(_fiche("Borderlands 3", "397540", 5.99, 59.99), set())
    ligne = d.ligne
    ligne.bouton_comparer.setChecked(True)            # comme a l'ouverture de la fiche
    d.show()
    assert ligne.comparatif.isVisible() and ligne.dlc is None
    ligne.bouton_dlc.setChecked(True)
    assert ligne.dlc.isVisible() and not ligne.comparatif.isVisible()
    assert ligne.bouton_dlc.text() == "Offres du jeu"
    ligne.bouton_dlc.setChecked(False)
    assert ligne.comparatif.isVisible() and not ligne.dlc.isVisible()
    assert ligne.bouton_dlc.text() == "DLC"
    # hors de la fenetre : rouvrir le comparatif referme les DLC
    ligne.bouton_dlc.setChecked(True)
    ligne.bouton_comparer.setChecked(False)
    ligne.bouton_comparer.setChecked(True)
    assert ligne.comparatif.isVisible() and not ligne.dlc.isVisible()
    assert not ligne.bouton_dlc.isChecked()
    d.close()


def test_suivre_puis_annuler_depuis_la_fiche(app):
    from orion.ui.views import boutique_view as B
    from orion.ui.widgets.boutique_cartes import SUIVI
    ligne = B.FicheLigne(_fiche("Borderlands 3", "397540", 5.99, 59.99), set(), avec_image=False)
    suivis, retires = [], []
    ligne.suivre_demande.connect(lambda a, t: suivis.append((a, t)))
    ligne.ne_plus_suivre_demande.connect(lambda a, t: retires.append((a, t)))
    assert ligne.bouton_suivre.text() == "Suivre" and ligne.bouton_suivre.isEnabled()
    ligne.bouton_suivre.click()
    assert suivis == [("397540", "Borderlands 3")] and retires == []
    assert ligne.bouton_suivre.text() == SUIVI and ligne.bouton_suivre.isEnabled()
    ligne.bouton_suivre.click()                       # clic de travers : on annule
    assert retires == [("397540", "Borderlands 3")]
    assert ligne.bouton_suivre.text() == "Suivre"
    # un jeu deja suivi s'ouvre « Suivi », et se retire d'un clic
    deja = B.FicheLigne(_fiche("Borderlands 3", "397540", 5.99, 59.99), {"397540"}, avec_image=False)
    assert deja.bouton_suivre.text() == SUIVI and deja.bouton_suivre.isEnabled()
    # sans numero Steam : pas de suivi possible, pas de bouton
    assert B.FicheLigne(_fiche("Sans numero", "", 5.0, 9.0), set(), avec_image=False).bouton_suivre is None


def test_suivre_puis_annuler_a_la_une(app):
    from orion.ui.views.boutique_view import BoutiqueView
    v = BoutiqueView()
    f = _fiche("Borderlands 3", "397540", 5.99, 59.99)
    suivis, retires = [], []
    v.suivre_demande.connect(lambda a, t: suivis.append(a))
    v.ne_plus_suivre_demande.connect(lambda a, t: retires.append(a))
    v.une.set_fiches([f], set())
    assert v.une.fiche is f and v.une.bouton_suivre.isEnabled()
    v.une.bouton_suivre.click()
    assert suivis == ["397540"] and "397540" in v._suivis and v.une.bouton_suivre.isEnabled()
    v.une.bouton_suivre.click()
    assert retires == ["397540"] and "397540" not in v._suivis


def test_la_fenetre_retire_le_jeu_des_envies():
    from orion.ui import main_window as M
    retires, messages = [], []

    class _Faux:
        def _wishlist_remove(self, appid):
            retires.append(appid)

        def notify(self, message, duree=0):
            messages.append(message)
    M.MainWindow._boutique_ne_plus_suivre(_Faux(), "397540", "Borderlands 3")
    assert retires == ["397540"] and messages == ["Borderlands 3 retire de vos Envies"]


# ---------------------------------------------------------------------------
# Loaded : la recherche tombe sur les versions PC
# ---------------------------------------------------------------------------
def test_la_recherche_loaded_demande_les_versions_pc():
    from urllib.parse import unquote

    from orion import marche_gris
    liens = {site.id: unquote(url) for site, url in marche_gris.liens_revendeurs("F1 25")}
    assert "catalogsearch/result/?q=F1" in liens["loaded"]
    assert liens["loaded"].split("?q=")[-1].split("&")[0].endswith("+PC")


# ---------------------------------------------------------------------------
# Envies : la meme recherche que la Boutique (meme cause, meme correction)
# ---------------------------------------------------------------------------
def test_les_envies_cherchent_comme_la_boutique(monkeypatch, tmp_path):
    from orion import wishlist
    demandes = []
    catalogue = {
        "black ops 3": [("Call of Duty®: Black Ops III", 311210, 59.99), ("Monster Ops 3", 8, 4.0)],
        "f1": [("F1® 25", 3059520, 34.99), ("Frontline 1942", 77, 5.0)],
        "borderlands": [("Borderlands 2", 49520, 4.99), ("Jeu adulte Borderlands", 9, 3.0)]}

    def chercher(self, terme):
        demandes.append(terme)
        out = []
        for t, a, p in catalogue.get(terme.lower(), []):
            o = Offre(titre=t, boutique="Steam", prix=p, prix_normal=p, source="steam",
                      url="", steam_appid=str(a), image="https://img.test/x.jpg")
            o.adulte = t.startswith("Jeu adulte")
            out.append(o)
        return out
    monkeypatch.setattr(steam.SteamBoutique, "chercher", chercher)
    monkeypatch.setattr(wishlist, "_vignette", lambda appid, url: f"vignette-{appid}")
    monkeypatch.setattr(wishlist.WishlistService, "_search_court",
                        staticmethod(lambda term, limit=8: [{"appid": "1", "title": "Secours"}]))
    chercher_envies = wishlist.WishlistService.search
    assert chercher_envies("bo3") == [{"appid": "311210", "title": "Call of Duty®: Black Ops III",
                                       "price": 59.99, "cover": "vignette-311210", "release": ""}]
    assert demandes == ["black ops 3"]              # le sigle seul n'est pas pose a Steam
    del demandes[:]
    assert [r["title"] for r in chercher_envies("F1 202")] == ["F1® 25"]
    assert demandes == ["F1 202", "F1"]
    assert [r["title"] for r in chercher_envies("borderlands")] == ["Borderlands 2"]     # jamais l'adulte
    # rien nulle part : l'ancienne recherche a le dernier mot
    assert chercher_envies("zzzz")[0]["title"] == "Secours"


def test_les_resultats_des_envies_sont_classes_sur_les_memes_lectures(app):
    from orion.ui.views.wishlist_view import WishlistView
    v = WishlistView()
    v.search.setText("F1 202")
    v.set_results([{"appid": "1", "title": "Frontline 1942", "price": 5.0, "cover": ""},
                   {"appid": "2", "title": "F1® 25", "price": 34.99, "cover": ""}])
    assert "1 resultat" in v.results_title.text()
    v.search.setText("bo3")
    v.set_results([{"appid": "3", "title": "Call of Duty®: Black Ops III", "price": 59.99, "cover": ""}])
    assert "1 resultat" in v.results_title.text()


# ---------------------------------------------------------------------------
# Une boutique muette n'est pas une boutique qui ne vend pas le jeu
# ---------------------------------------------------------------------------
class _Muette:
    id, label = "steam", "Steam"

    def available(self):
        return True

    def chercher(self, terme):
        raise SourceUnavailable("https://store.steampowered.com/search/results/ : reponse illisible")


def test_le_service_retient_les_boutiques_qui_n_ont_pas_repondu(service):
    source = _brancher(service, {"hades": [("Hades", 1145360, 24.5)]})
    service._sources = [_Muette(), source]
    assert [f.titre for f in service.chercher("hades")] == ["Hades"]
    assert service.sources_muettes("hades") == ["Steam"]
    service._sources = [source]
    service.chercher("hades")
    assert service.sources_muettes("hades") == [] and service.sources_muettes("jamais cherche") == []


def test_la_page_dit_qu_une_boutique_n_a_pas_repondu(app):
    from orion.ui.views.boutique_view import BoutiqueView
    v = BoutiqueView()
    v.set_catalogue([_fiche("Autre jeu", "5", 5.0, 9.0)], time.time(), 1, True)
    v.recherche.setText("black ops 4")
    v.set_resultats("black ops 4", [], ["Steam"])
    assert v._message_vide().startswith("Steam : pas de reponse pour le moment")
    v.set_resultats("black ops 4", [])
    assert v._message_vide().startswith("Aucune boutique sure ne vend « black ops 4 »")
    # resultats partiels : le resume le signale, et la phrase est traduisible
    v.set_resultats("black ops 4", [_fiche("Call of Duty®: Black Ops 4", "", 59.99, 59.99, boutique="Blizzard")],
                    ["Steam"])
    assert v.resume.text().endswith("sans reponse : Steam") or "Steam" in v.resume.text()
    from orion import i18n
    for phrase in ("2 jeux trouves pour « bo4 »  ·  sans reponse : Steam",
                   "1 jeu trouve pour « bo4 »  ·  3 application(s) masquee(s)  ·  sans reponse : Steam, GOG",
                   "Steam : pas de reponse pour le moment (maintenance ou coupure). Relancez la recherche dans quelques minutes.",
                   "Aucune boutique sure ne vend « bo4 » en ce moment. Essayez le nom complet du jeu : certains ne sont vendus que par leur editeur (Battle.net, EA app, Ubisoft Connect) ou ont quitte la vente."):
        for langue in ("en", "fr"):
            traduit = _traduire(i18n, langue, phrase)
            assert traduit != phrase and "bo4" in traduit or "Steam" in traduit, (langue, phrase, traduit)


def _traduire(i18n, langue, phrase):
    import json
    from pathlib import Path
    table = json.loads((Path(i18n.__file__).parent / "langues" / f"{langue}.json").read_text(encoding="utf-8"))
    import re
    for modele, cible in table["modeles"].items():
        motif = "^" + re.sub(r"\\\{(\d)\\\}", r"(?P<g\1>.+?)", re.escape(modele)) + "$"
        m = re.match(motif, phrase, re.S)
        if m:
            return re.sub(r"\{(\d)\}", lambda g: m.group("g" + g.group(1)), cible)
    return phrase


# ---------------------------------------------------------------------------
# Essais de l'auteur sur la 2.0 compilee, 7 octobre a 1 h 15
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("requete, titre", [
    ("black ops 4", "Call of Duty®: Black Ops 7"),       # un autre numero, un autre jeu
    ("black ops 4", "Call of Duty®: Black Ops II"),
    ("battlefield 3", "Battlefield™ 6"),
    ("battlefield 3", "Battlefield 4™"),
    ("battlefield 3", "Battlefield™ 2042"),
    ("fifa 22", "EA SPORTS FC™ 26"),
])
def test_un_autre_numero_n_est_pas_une_faute_de_frappe(requete, titre):
    assert R.score(requete, titre) < 0.55


@pytest.mark.parametrize("requete, titre", [
    ("battlefield 3", "Battlefield 3™"), ("bo4", "Call of Duty®: Black Ops 4"),
    ("battlefeild", "Battlefield™ 6"), ("cyberpounk", "Cyberpunk 2077"), ("hades 2", "Hades"),
])
def test_les_fautes_et_les_sigles_passent_toujours(requete, titre):
    assert R.score(requete, titre) >= 0.62


def test_bf3_passe_par_le_nom_de_la_serie():
    # « Battlefield » est un seul mot : « bf » n'est pas son sigle, c'est la table des series qui le sait
    assert R.developper("bf3") == ["battlefield 3"]
    assert R.note_variantes(R.variantes("bf3"), "Battlefield 3™") >= 0.9
    assert R.note_variantes(R.variantes("bf3"), "Battlefield™ 6") < 0.55


def test_fifa_mene_aux_jeux_de_foot_d_aujourd_hui():
    assert R.developper("fifa") == ["ea sports fc"]
    assert R.developper("fifa 26") == ["ea sports fc 26"]
    assert R.developper("fc 26") == ["ea sports fc 26"]
    assert R.developper("pes") == ["efootball"]
    assert R.termes_a_poser("fifa") == ["ea sports fc"]
    assert R.termes_a_poser("fifa 26") == ["fifa 26", "ea sports fc 26"]
    assert R.note_variantes(R.variantes("fifa"), "EA SPORTS FC™ 26") >= 0.9


def test_les_sources_sont_interrogees_en_meme_temps(service):
    import threading
    barriere = threading.Barrier(3, timeout=5)

    class _Lente:
        label = "Lente"

        def __init__(self, sid):
            self.id = sid

        def available(self):
            return True

        def chercher(self, terme):
            barriere.wait()                 # ne passe que si les trois sont la ensemble
            return [Offre(titre="Hades", boutique="Steam", prix=24.5, prix_normal=24.5,
                          source="steam", url="", steam_appid="1145360")]
    service._sources = [_Lente("a"), _Lente("b"), _Lente("c")]
    assert [f.titre for f in service.chercher("hades")] == ["Hades"]
    assert service.sources_muettes("hades") == []


def test_une_recherche_plus_recente_annule_l_ancienne(service):
    class _Source2(_Source):
        def chercher(self, terme):
            if terme == "hades":
                service._terme_voulu = "hades 2"         # le joueur a continue de taper
            return super().chercher(terme)
    service._sources = [_Source2({"hades": [("Hades", 1145360, 24.5)]})]
    assert service.chercher("hades") == []


def test_un_nombre_du_titre_n_est_jamais_tranche():
    """Vu dans la version compilee du 7 octobre : « F1 202 » ramenait
    F-117A, F-16, F-19, F11 et F18. Cause : les titres etaient compares
    colles (« f117a... » commence par « f1 »)."""
    from orion.core import recherche as r
    intrus = ["F-117A Nighthawk Stealth Fighter 2.0", "F-16 Multirole Fighter",
              "F-19 Stealth Fighter", "F11 Football Manager", "F18 Carrier Landing",
              "Frontline 1942", "Fallout 4", "Fe"]
    for requete in ("F1", "f1 202", "F1 2"):
        for titre in intrus:
            assert r.score(requete, titre) < r.SEUIL, (requete, titre)
    for titre in ("F1® 25", "F1® 24", "F1 Crazy Stunts", "F1® Manager 2024", "F1 2020"):
        assert r.score("F1", titre) >= 0.9, titre
    # le nombre en cours de saisie reste ouvert
    assert r.score("F1 202", "F1® Manager 2024") >= r.SEUIL
    assert r.score("F1 202", "F1® 25: 2026 Season Edition") >= r.SEUIL
    assert r.score("fifa 2", "EA SPORTS FIFA 23") >= r.SEUIL
    assert r.score("cyberpunk 20", "Cyberpunk 2077") >= r.SEUIL
    # un nombre complet se trouve toujours, ecrit colle ou non
    assert r.score("f16", "F-16 Multirole Fighter") >= 0.9
    assert r.score("f-16", "F-16 Multirole Fighter") >= 0.9
    assert r.score("tir 1", "Tir 01") >= r.SEUIL
    assert r.score("77", "Cyberpunk 2077") < r.SEUIL


def test_une_recherche_courte_ne_se_lit_qu_au_debut_d_un_mot():
    """Vu sur le catalogue reel du 7 octobre : « nba » ramenait DRAGON BALL
    (dragoNBAll), « gta » IGTAP, « tomb » Automobilista."""
    from orion.core import recherche as r
    assert r.score("nba", "DRAGON BALL Z: KAKAROT") < r.SEUIL
    assert r.score("gta", "IGTAP: an Incremental Game That's Also a Platformer") < r.SEUIL
    assert r.score("tomb", "Automobilista 2") < r.SEUIL
    assert r.score("red dead", "The Roottrees are Dead") < r.SEUIL
    assert r.score("nba", "NBA 2K27") >= 0.9
    assert r.score("tomb", "Rise of the Tomb Raider™") >= r.SEUIL
    # un mot compose se trouve par sa fin, si elle est assez longue
    assert r.score("craft", "Minecraft Dungeons") >= r.SEUIL
    assert r.score("field", "Battlefield™ 6") >= r.SEUIL


def test_a_l_oreille_il_faut_des_mots_entiers_et_des_lettres_proches():
    """Vu dans la version compilee du 7 octobre : « fifa » montrait 97 jeux
    (tout titre en F : sa cle sonore se reduisait a « f »). Meme cause pour
    « mario » -> Marvel, Mortal Kombat ; « halo » -> Half-Life, Helldivers ;
    « zelda » -> Metal Gear Solid ; « dota » -> Detroit, Death Stranding."""
    from orion.core import recherche as r
    bruit = {
        "fifa": ["Far Cry® 6", "Forza Horizon 6", "FINAL FANTASY VII REBIRTH", "Phasmophobia",
                 "Fallout 76", "Far Far West", "Fsh", "Flappy Wings Multiplayer"],
        "mario": ["Marvel Rivals", "Mortal Kombat 11", "Mirror's Edge™", "MORDHAU", "Marathon"],
        "halo": ["HELLDIVERS™ 2", "Half-Life 2", "Hollow Knight", "Hell Let Loose"],
        "zelda": ["METAL GEAR SOLID V: THE PHANTOM PAIN", "Children of the Sun"],
        "dota": ["Detroit: Become Human", "DEATH STRANDING 2: ON THE BEACH", "Death's Door"],
        "sims": ["Bills Must Be Paid", "Styx: Master of Shadows"],
        "red dead": ["Ready or Not", "Riders Republic", "Redout 2", "RIDE 6"],
    }
    for requete, titres in bruit.items():
        for titre in titres:
            assert r.score(requete, titre) < r.SEUIL, (requete, titre)
    # ce que l'oreille doit toujours trouver
    assert r.score("ciberpunk", "Cyberpunk 2077") >= r.SEUIL
    assert r.score("wakfou", "WAKFU") >= r.SEUIL
    assert r.score("asasin crid", "Assassin's Creed Shadows") >= r.SEUIL
    assert r.score("red ded", "Red Dead Redemption 2") >= r.SEUIL
    assert r.score("teh witcher", "The Witcher 3: Wild Hunt") >= r.SEUIL
    assert r.score("cyberpounk", "Cyberpunk 2077") >= r.SEUIL


def test_un_a_peu_pres_ne_remplace_pas_un_mot_ni_un_numero():
    from orion.core import recherche as r
    # « fifa » se lit « ea sports fc » : pas les autres jeux EA SPORTS
    for titre in ("EA SPORTS™ WRC", "EA SPORTS™ College Football 27",
                  "EA SPORTS™ Madden NFL 27", "Esports Life Tycoon"):
        assert r.note_variantes(r.variantes("fifa"), titre) < r.SEUIL, titre
    assert r.note_variantes(r.variantes("fifa"), "EA SPORTS FC™ 27") >= 0.9
    # « bf3 » : le numero fait loi
    v = r.variantes("bf3")
    assert r.note_variantes(v, "Battlefield 3™") >= 0.9
    for titre in ("War Dust VR: 32v32 Battlefield Sim", "Three Kingdoms: Ancient battlefield",
                  "Endless Battlefield"):
        assert r.note_variantes(v, titre) < 0.55, titre
    # un autre jeu de la serie reste, en fin de liste
    assert 0.55 <= r.note_variantes(v, "Battlefield™ REDSEC") < 0.7
    assert 0.55 <= r.score("resident evil 4", "Resident Evil Village") < 0.7
    assert r.score("resident evil 4", "Resident Evil 4") == 1.0


def test_le_sigle_part_du_debut_du_titre_ou_d_un_sous_titre():
    from orion.core import recherche as r
    assert r.sigle("bo3", "Call of Duty®: Black Ops III") >= 0.84
    assert r.sigle("mw2", "Call of Duty®: Modern Warfare® II") >= 0.84
    assert r.sigle("w3", "The Witcher 3: Wild Hunt") >= 0.84
    assert r.sigle("gta", "Grand Theft Auto V") >= 0.9
    assert r.sigle("gta", "IGTAP: an Incremental Game That's Also a Platformer") == 0.0


def test_a_note_egale_le_jeu_connu_passe_devant():
    from orion.core import recherche as r
    jeux = [("Cyberpunk SFX", 0.1), ("Cyberpunk 2077", 0.9), ("Cyberpunk 2077 : Édition Ultime", 0.5)]
    classes = r.classer_variantes(r.variantes("cyberpunk"), jeux, cle=lambda j: j[0],
                                  departage=lambda j: j[1])
    assert [j[0] for j in classes][0] == "Cyberpunk 2077"


def test_red_ded_trouve_ses_jeux_sans_lecture_raccourcie(service):
    """« red ded » trouvait Red Dead Redemption 1 et 2, puis ajoutait tout
    ce qui commence par « red » (lecture raccourcie) : onze jeux affiches."""
    source = _brancher(service, {
        "red ded": [("Red Dead Redemption 2", 1174180, 59.99), ("Red Dead Redemption", 2668510, 49.99)],
        "red": [("Redout 2", 5, 9.0), ("Redeemer: Enhanced Edition", 6, 9.0)]})
    titres = [f.titre for f in service.chercher("red ded")]
    assert source.demandes == ["red ded"]
    assert titres == ["Red Dead Redemption 2", "Red Dead Redemption"]
    from orion.core import recherche as r
    assert r.faut_raccourcir("F1 202", 2) and not r.faut_raccourcir("F1 202", 3)
    assert r.faut_raccourcir("hollow knight silk", 0) and not r.faut_raccourcir("red ded", 2)
    assert not r.faut_raccourcir("fifa", 0)


def test_tropico_6_ne_ramene_pas_les_autres_numeros(service):
    """Vu dans la version compilee du 7 octobre : « tropico 6 » montrait
    aussi Tropico 5, 4, 3 et Reloaded (lecture raccourcie « tropico »)."""
    source = _brancher(service, {
        "tropico 6": [("Tropico 6", 492720, 11.99), ("Tropico 6 El Prez Edition", 9001, 13.49)],
        "tropico": [("Tropico 5", 245620, 6.99), ("Tropico 4", 57690, 4.49)]})
    titres = [f.titre for f in service.chercher("tropico 6")]
    assert source.demandes == ["tropico 6"]
    assert titres == ["Tropico 6", "Tropico 6 El Prez Edition"]
    from orion.core import recherche as r
    assert not r.faut_raccourcir("tropico 6", 2, 1.0)
    assert r.faut_raccourcir("F1 202", 2, 0.86)
