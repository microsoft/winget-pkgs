"""Adresses de courriel du site (12 octobre 2026). Cloudflare remplacait
l'adresse de contact par un lien vers /cdn-cgi/l/email-protection : Google
suivait ce lien et signalait une page introuvable (404) dans la Search
Console, et sans JavaScript on lisait « [email protected] »."""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "service" / "site"))
import assembler  # noqa: E402


def test_le_corps_d_une_page_avec_adresse_est_laisse_en_clair(tmp_path):
    (tmp_path / "en").mkdir()
    (tmp_path / "contact.html").write_text(
        '<html><head><meta name="x" content="a"></head><body class="b"><p>Ecrire a '
        '<a href="mailto:contact@exemple.fr">contact@exemple.fr</a></p></body></html>', encoding="utf-8")
    (tmp_path / "en" / "sans.html").write_text("<html><body><p>rien</p></body></html>", encoding="utf-8")
    assert assembler.proteger_courriels(tmp_path) == 1
    s = (tmp_path / "contact.html").read_text(encoding="utf-8")
    assert s.startswith('<html><head><meta name="x" content="a"></head><body class="b"><!--email_off--><p>')
    assert s.endswith("</p><!--/email_off--></body></html>")
    assert "email_off" not in (tmp_path / "en" / "sans.html").read_text(encoding="utf-8")
    # une seconde fois : rien ne change
    assert assembler.proteger_courriels(tmp_path) == 0
    assert s == (tmp_path / "contact.html").read_text(encoding="utf-8")


def test_une_adresse_hors_d_une_vraie_page_est_une_erreur(tmp_path):
    (tmp_path / "morceau.html").write_text("<p>contact@exemple.fr</p>", encoding="utf-8")
    with pytest.raises(RuntimeError):
        assembler.proteger_courriels(tmp_path)


def test_ce_que_cloudflare_prend_pour_une_adresse_est_protege_aussi(tmp_path):
    # Days Gone, fiche Steam : « Intel Core i5-2500K@3.3GHz » (12 octobre)
    (tmp_path / "jeu.html").write_text("<html><body><dd>Intel Core i5-2500K@3.3GHz</dd></body></html>",
                                       encoding="utf-8")
    (tmp_path / "pseudo.html").write_text('<html><body><a href="https://x.com/OrionLauncher">'
                                          '@OrionLauncher</a></body></html>', encoding="utf-8")
    assert assembler.proteger_courriels(tmp_path) == 1
    assert "<!--email_off-->" in (tmp_path / "jeu.html").read_text(encoding="utf-8")


def test_images_et_polices_ont_une_adresse_qui_change_avec_leur_contenu(tmp_path):
    (tmp_path / "img").mkdir()
    (tmp_path / "polices").mkdir()
    (tmp_path / "img" / "a.jpg").write_bytes(b"v1")
    (tmp_path / "polices" / "p.woff2").write_bytes(b"f")
    page = tmp_path / "index.html"
    page.write_text('<html><head><meta property="og:image" content="https://orion-launcher.com/img/a.jpg">'
                    '<style>@font-face{src:url("/polices/p.woff2")}</style></head>'
                    '<body><img src="/img/a.jpg"><img src="/img/absente.png"></body></html>', encoding="utf-8")
    assert assembler.versionner_fichiers(tmp_path) == 1
    s = page.read_text(encoding="utf-8")
    assert s.count("/img/a.jpg?v=") == 2 and '/polices/p.woff2?v=' in s and 'src="/img/absente.png"' in s
    assert assembler.versionner_fichiers(tmp_path) == 0          # deja fait : rien ne change
    v1 = s.split("/img/a.jpg?v=")[1][:10]
    (tmp_path / "img" / "a.jpg").write_bytes(b"v2")
    page.write_text(s.replace("?v=" + v1, ""), encoding="utf-8")
    assembler.versionner_fichiers(tmp_path)
    assert v1 not in page.read_text(encoding="utf-8")
