"""9 octobre (« si c'est pour se prendre un vacban c'est dommage ») : ORION
n'ecrit jamais pendant une partie, et ne devine jamais un fichier dans le
dossier d'installation d'un jeu."""
import sys
import types

from orion.core.models import Game
from orion.optimizer import securite


class _Proc:
    def __init__(self, name, exe):
        self.info = {"name": name, "exe": exe}


def _psutil(monkeypatch, procs):
    faux = types.SimpleNamespace(process_iter=lambda attrs=None: iter(procs))
    monkeypatch.setitem(sys.modules, "psutil", faux)


def test_jeu_ouvert_par_son_dossier(monkeypatch, tmp_path):
    jeu = tmp_path / "Aniimo"
    _psutil(monkeypatch, [_Proc("Aniimo.exe", str(jeu / "Aniimo.exe"))])
    assert securite.jeu_ouvert(Game(title="Aniimo", source="steam", install_dir=str(jeu)))
    # un dossier voisin au nom proche n'est pas le jeu
    _psutil(monkeypatch, [_Proc("x.exe", str(tmp_path / "Aniimo2" / "x.exe"))])
    assert not securite.jeu_ouvert(Game(title="Aniimo", source="steam", install_dir=str(jeu)))


def test_jeu_protege_reconnu_a_son_nom_jamais_un_nom_generique(monkeypatch, tmp_path):
    jeu = tmp_path / "Aniimo"
    # chemin illisible (anti-triche) : le nom suffit
    _psutil(monkeypatch, [_Proc("Aniimo.exe", None)])
    assert securite.jeu_ouvert(Game(title="Aniimo", source="steam", install_dir=str(jeu),
                                    executable=str(jeu / "Aniimo.exe")))
    # « launcher.exe » d'un autre jeu : jamais pris pour celui-ci
    _psutil(monkeypatch, [_Proc("launcher.exe", None)])
    assert not securite.jeu_ouvert(Game(title="X", source="steam", install_dir=str(jeu),
                                        executable=str(jeu / "launcher.exe")))


def test_rien_n_est_ecrit_pendant_une_partie(monkeypatch):
    from orion.core.models import OptimizationPlan, TweakOp
    from orion.optimizer.engine import Optimizer
    eng = Optimizer.__new__(Optimizer)
    eng.relire = lambda plan: None
    plan = OptimizationPlan(game_uid="steam:1", profile="ecran")
    plan.ops = [TweakOp(kind="registry", target="HKCU/Software/X", key="k", value="1", current="0")]
    monkeypatch.setattr(securite, "jeu_ouvert", lambda g: True)
    ok, msg = eng.apply_plan(Game(title="Aniimo", source="steam"), plan)
    assert not ok and "ouvert" in msg and plan.ops[0].current == "0"


def test_l_apprentissage_ne_fouille_pas_le_dossier_du_jeu(monkeypatch, tmp_path):
    from orion.optimizer import apprentissage
    jeu = tmp_path / "Jeu Inconnu"
    (jeu / "Config").mkdir(parents=True)
    (jeu / "Config" / "settings.ini").write_text("[Video]\nResolutionX=1920\n", encoding="utf-8")
    donnees = tmp_path / "local"
    (donnees / "Jeu Inconnu").mkdir(parents=True)
    (donnees / "Jeu Inconnu" / "settings.ini").write_text("[Video]\nResolutionX=1920\n", encoding="utf-8")
    import orion.optimizer.discovery as disc
    monkeypatch.setattr(disc, "context_for", lambda g: {"localappdata": str(donnees)})
    trouves = [str(p) for p in apprentissage._candidats(Game(title="Jeu Inconnu", source="steam", install_dir=str(jeu)))]
    assert any(str(donnees) in p for p in trouves)
    assert not any(str(jeu) + "/" in p or str(jeu) + "\\" in p for p in trouves)
