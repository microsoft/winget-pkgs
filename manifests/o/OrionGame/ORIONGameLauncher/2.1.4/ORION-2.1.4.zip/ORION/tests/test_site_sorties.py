"""Page Sorties et page Modern Warfare 4 (10 octobre, relecture « responsable
marketing et referencement ») : francais correct, revendeurs seulement dans
« Prix et boutiques » apres les boutiques officielles, aucune mention fausse."""
import json
import re
import sys
from pathlib import Path

RACINE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RACINE / "service" / "site"))


def _site(tmp_path):
    from orion import sorties
    (tmp_path / "index.html").write_text("<html><style>body{}</style></html>", encoding="utf-8")
    (tmp_path / "sitemap.xml").write_text("<urlset>\n</urlset>\n", encoding="utf-8")
    (tmp_path / "img" / "sorties").mkdir(parents=True)
    (tmp_path / "sorties.json").write_text(json.dumps(
        {"format": sorties.FORMAT, "maj": sorties.MAJ, "sorties": sorties.EMBARQUEE}, ensure_ascii=False),
        encoding="utf-8")
    import gen_sorties
    import gen_une
    gen_sorties.main(tmp_path)
    gen_une.main(tmp_path)
    return ((tmp_path / "sorties.html").read_text(encoding="utf-8"),
            (tmp_path / "call-of-duty-modern-warfare-4.html").read_text(encoding="utf-8"))


def test_page_sorties(tmp_path):
    page, _ = _site(tmp_path)
    assert "Précommandes ouvertes" in page and "Precommandes" not in page
    assert "date non annoncee" not in page
    # aucune ligne de revendeur sur les fiches : seulement dans le comparateur
    corps = page.split("<main", 1)[1]
    assert 'class="achat"' not in corps and "igr=Sikher" not in corps
    assert corps.count("lien partenaire") + corps.count("liens partenaires") <= 1
    # chaque fiche achetable a son bloc, avec ses fiches choisies a la main
    assert 'id="gta-6"' in page and re.search(r'id="gta-6".*?data-revendeurs="[^"]*15506', page, re.S)
    assert re.search(r'id="gta-6".*?data-officiels="[^"]*rockstargames', page, re.S)
    # la une n'est pas repetee dans les vignettes du dessous
    trio = re.search(r'<div class="trio".*?</div>', page, re.S)
    assert trio is None or "call-of-duty-modern-warfare-4" not in trio.group(0)


def test_page_modern_warfare_4(tmp_path):
    _, page = _site(tmp_path)
    assert "Clé Steam vérifiée" not in page and "ne montre qu'une clé Steam" not in page
    titre = re.search(r"<title>(.*?)</title>", page).group(1)
    desc = re.search(r'<meta name="description" content="([^"]*)"', page).group(1)
    assert len(titre) <= 60 and len(desc) <= 155, (titre, desc)
    assert '<a href="/sorties" aria-current="page">Sorties</a>' in page and 'href="/#faq"' in page
    assert '"BreadcrumbList"' in page and 'data-une="1"' in page
    assert "clé Microsoft Store PC (Europe, précommande)" in page.replace("&quot;", '"')
