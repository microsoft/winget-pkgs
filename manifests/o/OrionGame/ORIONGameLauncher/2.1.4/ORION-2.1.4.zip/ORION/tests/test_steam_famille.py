"""Jeux de la famille Steam (2.1.2, demande de l'auteur le 12 octobre) :
marques « (Steam Family) » sur la carte de joueur et dans la valeur, et la
bibliotheque peut les montrer ou non. WRC 10 etait le plus cher de sa carte
sans etre a lui."""
import os

from orion import steam_famille as sf
from orion.core.models import Game

MOI = "76561198010852637"


def test_comptes_du_pc_et_manifeste(tmp_path):
    (tmp_path / "userdata" / "50586909").mkdir(parents=True)        # dossier = identifiant de compte
    (tmp_path / "userdata" / "0").mkdir()
    locaux = sf.comptes_locaux(tmp_path)
    assert locaux == {MOI}
    assert sf.prete("76561198000000001", locaux)                     # licence d'un proche
    assert not sf.prete(MOI, locaux) and not sf.prete("0", locaux) and not sf.prete("", locaux)
    assert not sf.prete("76561198000000001", set())                  # comptes inconnus : on ne devine pas


def test_le_scanner_marque_un_jeu_prete(tmp_path, monkeypatch):
    from orion.plugins.scanners import steam
    (tmp_path / "userdata" / "50586909").mkdir(parents=True)
    apps = tmp_path / "steamapps"
    (apps / "common").mkdir(parents=True)
    for appid, nom, proprio in (("1462810", "WRC 10", "76561198000000001"), ("1091500", "Cyberpunk 2077", MOI)):
        (apps / f"appmanifest_{appid}.acf").write_text(
            f'"AppState"\n{{\n\t"appid"\t\t"{appid}"\n\t"name"\t\t"{nom}"\n\t"StateFlags"\t\t"4"\n'
            f'\t"installdir"\t\t"{nom}"\n\t"LastOwner"\t\t"{proprio}"\n}}\n', encoding="utf-8")
    monkeypatch.setattr(steam, "steam_root", lambda: tmp_path)
    monkeypatch.setattr(steam, "steam_libraries", lambda root: [tmp_path])
    jeux = {g.title: g for g in steam.SteamScanner().scan()}
    assert jeux["WRC 10"].extra.get(sf.PRETE) is True
    assert sf.PRETE not in jeux["Cyberpunk 2077"].extra


def test_hors_du_compte_et_payant_seulement():
    hors = Game(title="WRC 10", source="steam", source_id="1462810",
                extra={"steam_appid": "1462810", sf.HORS_COMPTE: True})
    gratuit = Game(title="Lost Ark", source="steam", source_id="1599340",
                   extra={"steam_appid": "1599340", sf.HORS_COMPTE: True})
    a_moi = Game(title="Hades", source="steam", source_id="1145360", extra={"steam_appid": "1145360"})

    class V:
        liste = [{"appid": "1462810", "normal": 90.97}, {"appid": "1599340", "normal": 0.0},
                 {"appid": "1145360", "normal": 24.5}]
    p = sf.payants(V)
    assert sf.de_la_famille(hors, p) and not sf.de_la_famille(gratuit, p) and not sf.de_la_famille(a_moi, p)
    assert not sf.de_la_famille(hors, set())                          # valeur pas encore calculee
    assert sf.avec_mention("WRC 10", True) == "WRC 10 (Steam Family)"


def test_la_valeur_garde_le_jeu_et_le_marque():
    from orion import valeur_catalogue as vc
    v = vc.estimer([
        {"uid": "a", "titre": "WRC 10", "appid": "", "prix": (90.97, 36.7), "origine": "boutique", "famille": "hors_compte"},
        {"uid": "b", "titre": "Lost Ark", "appid": "", "prix": (0.0, 0.0), "origine": "boutique", "famille": "hors_compte"},
        {"uid": "c", "titre": "Prete", "appid": "", "prix": (20.0, 20.0), "origine": "boutique", "famille": "oui"},
        {"uid": "d", "titre": "Hades", "appid": "", "prix": (24.5, 24.5), "origine": "boutique", "famille": ""}],
        reseau_autorise=False)
    par = {j["titre"]: j for j in v.liste}
    assert v.total == 135.47                                          # toujours comptes
    assert par["WRC 10"].get("famille") and par["Prete"].get("famille")
    assert not par["Lost Ark"].get("famille") and not par["Hades"].get("famille")


def test_carte_liste_et_case_de_la_bibliotheque():
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    from PySide6.QtWidgets import QApplication, QLabel
    app = QApplication.instance() or QApplication([])
    from orion.core.config import CONFIG
    from orion.ui.views.library_view import LibraryView
    from orion.ui.widgets import fenetre_valeur as fv
    from orion.valeur_catalogue import Valeur
    liste = [{"titre": "WRC 10", "appid": "1462810", "normal": 90.97, "actuel": 36.7, "origine": "boutique",
              "famille": True},
             {"titre": "Hades", "appid": "1145360", "normal": 24.5, "actuel": 24.5, "origine": "boutique"}]
    valeur = Valeur(total=115.47, actuel=61.2, estimes=2, gratuits=0, jeux=2, liste=liste)
    f = fv.FenetreValeur(valeur)
    textes = [l.text() for l in f.findChildren(QLabel)]
    assert "WRC 10 (Steam Family)" in textes and "Hades" in textes
    vus = []
    import orion.ui.carte_joueur as cj
    vrai = cj.dessiner
    cj.dessiner = lambda *a, **k: vus.append(a[3]) or vrai(*a, **k)
    try:
        fv.image_carte(valeur)
    finally:
        cj.dessiner = vrai
    assert vus[0][0][0] == "WRC 10 (Steam Family)" and vus[0][1][0] == "Hades"

    CONFIG.set("ui.voir_steam_family", True, save=False)
    vue = LibraryView()
    prete = Game(title="WRC 10", source="steam", source_id="1462810",
                 extra={"steam_appid": "1462810", sf.PRETE: True})
    a_moi = Game(title="Hades", source="steam", source_id="1145360", extra={"steam_appid": "1145360"})
    vue.set_valeur(valeur)
    vue.set_games([prete, a_moi])
    jeux, _ = vue._base()
    assert len(jeux) == 2 and not vue.voir_famille.isHidden() and "(1)" in vue.voir_famille.text()
    vue.voir_famille.setChecked(False)
    jeux, _ = vue._base()
    assert [g.title for g in jeux] == ["Hades"]
    CONFIG.set("ui.voir_steam_family", True, save=False)
    app.processEvents()
