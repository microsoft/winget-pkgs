"""Revue de la chaine mise a jour / installation / demarrage.

Lancements « propres » des jeux, fin de session garantie, mise a jour
reportee en fin de partie, base SQLite abimee, configuration illisible,
installation silencieuse qui relance toujours ORION. Les parties propres a
Windows (ShellExecute, registre, psutil) sont simulees.
"""
import json
import os
import sqlite3
import sys
import threading
import time
from pathlib import Path

import pytest

from orion.core import lancement
from orion.core.models import Game


# --------------------------------------------------------------------------
# 1. Lancement des jeux
# --------------------------------------------------------------------------

@pytest.fixture
def windows(monkeypatch):
    from orion.launch import launcher
    monkeypatch.setattr(launcher, "is_windows", lambda: True)
    return launcher


def _jeu(tmp_path, **kw):
    dossier = tmp_path / "Jeux" / "Foo"
    dossier.mkdir(parents=True, exist_ok=True)
    exe = dossier / "foo.exe"
    exe.write_text("x")
    valeurs = dict(title="Foo", source="dossier", uid="foo",
                   install_dir=str(dossier), executable=str(exe))
    valeurs.update(kw)
    return Game(**valeurs)


def test_lancement_direct_passe_par_popen_propre(windows, tmp_path, monkeypatch):
    appels = []
    monkeypatch.setattr(lancement, "popen_propre",
                        lambda args, cwd=None, **kw: appels.append((args, cwd, kw)))
    game = _jeu(tmp_path, launch_args=["-dx12"])
    ok, _ = windows.launch_target(game)
    assert ok
    args, cwd, kw = appels[0]
    assert args == [game.executable, "-dx12"]
    assert cwd == game.install_dir                      # dossier du jeu
    assert kw["creationflags"] == windows.DETACHED_PROCESS


def test_dossier_de_travail_absent_remplace_par_celui_du_jeu(windows, tmp_path, monkeypatch):
    appels = []
    monkeypatch.setattr(lancement, "popen_propre",
                        lambda args, cwd=None, **kw: appels.append(cwd))
    game = _jeu(tmp_path, working_dir=str(tmp_path / "nexiste-pas"))
    assert windows.launch_target(game)[0]
    assert appels == [game.install_dir]


def test_adresse_de_plateforme_par_startfile_propre(windows, tmp_path, monkeypatch):
    vus = []
    monkeypatch.setattr(lancement, "startfile_propre",
                        lambda cible, dossier=None: vus.append(cible))
    ok, msg = windows.launch_target(Game(title="S", source="steam",
                                         launch_uri="steam://rungameid/1"))
    assert ok and vus == ["steam://rungameid/1"]


def test_application_du_store_par_explorer_propre(windows, monkeypatch):
    vus = []
    monkeypatch.setattr(lancement, "popen_propre",
                        lambda args, cwd=None, **kw: vus.append(args))
    ok, _ = windows.launch_target(Game(title="X", source="xbox",
                                       launch_uri="shell:AppsFolder\\X!App"))
    assert ok and vus == [["explorer.exe", "shell:AppsFolder\\X!App"]]


def test_elevation_740_par_shell_execute_runas(windows, tmp_path, monkeypatch):
    def refuse(args, cwd=None, **kw):
        exc = OSError("elevation requise")
        exc.winerror = 740
        raise exc
    vus = []
    monkeypatch.setattr(lancement, "popen_propre", refuse)
    monkeypatch.setattr(lancement, "shell_execute",
                        lambda cible, parametres=None, dossier=None, verbe=None:
                        vus.append((cible, parametres, dossier, verbe)) or 42)
    game = _jeu(tmp_path, launch_args=["-a b"])
    ok, msg = windows.launch_target(game)
    assert ok and "administrateur" in msg
    assert vus == [(game.executable, '"-a b"', game.install_dir, "runas")]

    monkeypatch.setattr(lancement, "shell_execute", lambda *a, **k: 5)   # refus
    ok, msg = windows.launch_target(game)
    assert not ok and "autorisation" in msg


def test_le_lanceur_n_appelle_plus_os_startfile_ni_popen_direct():
    source = Path(__file__).resolve().parents[1] / "orion" / "launch" / "launcher.py"
    texte = source.read_text(encoding="utf-8")
    assert "os.startfile(" not in texte
    assert "subprocess.Popen(" not in texte
    assert "windll.shell32" not in texte


# --------------------------------------------------------------------------
# 1 bis. Reconnaissance du processus et fin de session
# --------------------------------------------------------------------------

def test_processus_du_meme_nom_ailleurs_n_est_pas_le_jeu(tmp_path):
    from orion.launch.launcher import _correspond, _dossier_jeu
    game = _jeu(tmp_path)
    racine = _dossier_jeu(game)
    assert racine.endswith(os.sep)
    autre = str(tmp_path / "Autre" / "foo.exe")
    assert not _correspond({"name": "foo.exe", "exe": autre}, "foo.exe", racine, 0)
    # « Foo » ne reconnait pas « Foobar »
    voisin = str(tmp_path / "Jeux" / "Foobar" / "bar.exe")
    assert not _correspond({"name": "bar.exe", "exe": voisin}, "foo.exe", racine, 0)
    # dans le dossier du jeu : oui, quel que soit le nom
    dedans = str(tmp_path / "Jeux" / "Foo" / "bin" / "Foo-Win64.exe")
    assert _correspond({"name": "Foo-Win64.exe", "exe": dedans}, "foo.exe", racine, 0)
    # chemin illisible (droits administrateur) : le nom suffit seulement
    # pour un processus ne apres le lancement
    assert _correspond({"name": "foo.exe", "exe": None, "create_time": 200.0},
                       "foo.exe", racine, 100.0)
    assert not _correspond({"name": "foo.exe", "exe": None, "create_time": 50.0},
                           "foo.exe", racine, 100.0)


def test_racine_de_disque_jamais_prise_pour_un_jeu():
    from orion.launch.launcher import _dossier_jeu
    assert _dossier_jeu(Game(title="X", source="d", install_dir=os.sep)) == ""


def _session(tmp_path, monkeypatch):
    from orion.launch import launcher
    monkeypatch.setattr(launcher.BUS, "emit", lambda *a, **k: None)
    fins = []
    s = launcher.GameSession(_jeu(tmp_path), None,
                             on_finished=lambda g, sec: fins.append(sec))
    s.started_at = time.time()
    return s, fins


def test_session_terminee_meme_apres_une_exception(tmp_path, monkeypatch):
    s, fins = _session(tmp_path, monkeypatch)

    def plante(timeout=150):
        raise RuntimeError("psutil en panne")
    monkeypatch.setattr(s, "_wait_for_process", plante)
    s._watch()
    assert s.termine and s.seconds >= 1 and fins == [s.seconds]


def test_attente_du_jeu_bornee(tmp_path, monkeypatch):
    from orion.launch import launcher
    monkeypatch.setattr(launcher, "INTERVALLE_ATTENTE", 0.01)
    s, fins = _session(tmp_path, monkeypatch)

    class TimeoutExpired(Exception):
        pass

    class Fige:
        info = {"name": "foo.exe"}

        def wait(self, timeout=None):
            time.sleep(timeout or 0)
            raise TimeoutExpired()
    monkeypatch.setattr(s, "_wait_for_process", lambda timeout=150: Fige())
    s.duree_max = 0.2
    debut = time.monotonic()
    s._watch()
    assert time.monotonic() - debut < 5
    assert s.termine and fins


def test_echec_de_lancement_marque_la_session_terminee(tmp_path, monkeypatch):
    from orion.launch import launcher
    monkeypatch.setattr(launcher, "launch_target", lambda g: (False, "non"))
    s = launcher.GameSession(_jeu(tmp_path), None)
    ok, _ = s.start()
    assert not ok and s.termine


# --------------------------------------------------------------------------
# Fenetre (fond) : partie en cours, mise a jour reportee
# --------------------------------------------------------------------------

PySide6 = pytest.importorskip("PySide6")
from PySide6.QtWidgets import QApplication, QLabel, QWidget  # noqa: E402


@pytest.fixture(scope="module")
def app():
    return QApplication.instance() or QApplication([])


class _Session:
    def __init__(self, termine=False):
        self.termine = termine
        self.seconds = 0


@pytest.fixture
def fenetre(app, monkeypatch):
    from orion.core.config import CONFIG
    from orion.ui import fond
    from orion.ui.fond import FondMixin
    from orion.ui.widgets.sidebar import Sidebar

    CONFIG.set("jeu.discret", True, save=False)
    monkeypatch.setattr(fond.QMessageBox, "warning", lambda *a, **k: None)

    class Fenetre(QWidget, FondMixin):
        def __init__(self):
            super().__init__()
            self.sidebar = Sidebar()
            self.status_label = QLabel()
            self.notes = []
            self._maj_en_cours = False
            self._maj_en_attente = None
            self._maj_pub = None
            self._maj_proposee = ""
            self._differe = set()
            self.sessions = []

            class _V:
                actif = False
            self.veille_jeu = _V()

            class _L:
                def save(self):
                    pass
            self.library = _L()

        def notify(self, texte, secondes=5):
            self.notes.append(texte)

    f = Fenetre()
    monkeypatch.setattr(type(f), "_quitter_pour_maj", lambda self: self.notes.append("QUITTE"))
    return f


def test_en_partie_suit_le_drapeau_termine(fenetre):
    s = _Session()
    fenetre.sessions.append(s)
    assert fenetre.en_partie
    s.termine = True
    s.seconds = 0             # ancienne logique (seconds == 0) : restait vraie
    assert not fenetre.en_partie
    fenetre._purger_sessions()
    assert fenetre.sessions == []


def test_en_partie_objet_sans_drapeau(fenetre):
    class Ancien:
        seconds = 0
    fenetre.sessions.append(Ancien())
    assert fenetre.en_partie
    Ancien.seconds = 12
    assert not fenetre.en_partie


def test_maj_telechargee_en_partie_attend_la_fin(fenetre, monkeypatch, tmp_path):
    from orion import maj
    from orion.ui.fond import MESSAGE_FIN_PARTIE
    lances = []
    monkeypatch.setattr(maj, "installer", lambda chemin: lances.append(chemin) or True)
    installateur = tmp_path / "Installateur-ORION-99.0.0.exe"
    installateur.write_text("x")
    partie = _Session()
    fenetre.sessions.append(partie)
    fenetre._maj_en_cours = True

    fenetre._maj_telechargee(installateur)
    assert lances == [] and "QUITTE" not in fenetre.notes
    assert MESSAGE_FIN_PARTIE in fenetre.notes
    assert fenetre._maj_en_attente == installateur

    # clic sur l'encart pendant la partie : rien n'est installe
    class Pub:
        version, verifiable, disponible, page = "99.0.0", True, True, ""
    fenetre.installer_maj(Pub())
    assert lances == []

    # tant que la partie dure, la reprise ne fait rien
    assert not fenetre._installer_maj_en_attente()
    partie.termine = True
    fenetre._reprendre()
    assert lances == [installateur]
    assert fenetre._maj_en_attente is None
    app = QApplication.instance()
    fin = time.time() + 3
    while "QUITTE" not in fenetre.notes and time.time() < fin:
        app.processEvents()
        time.sleep(0.02)
    assert "QUITTE" in fenetre.notes


def test_maj_telechargee_hors_partie_installe_tout_de_suite(fenetre, monkeypatch, tmp_path):
    from orion import maj
    lances = []
    monkeypatch.setattr(maj, "installer", lambda chemin: lances.append(chemin) or True)
    fenetre._maj_telechargee(tmp_path / "i.exe")
    assert lances == [tmp_path / "i.exe"] and fenetre._maj_en_attente is None


def test_installateur_disparu_pendant_la_partie(fenetre, monkeypatch, tmp_path):
    from orion import maj
    monkeypatch.setattr(maj, "installer", lambda chemin: pytest.fail("ne doit pas installer"))
    fenetre._maj_en_attente = tmp_path / "absent.exe"
    fenetre._maj_en_cours = True
    assert not fenetre._installer_maj_en_attente()
    assert fenetre._maj_en_attente is None and not fenetre._maj_en_cours


def test_nettoyage_au_demarrage_hors_du_fil_de_l_interface(fenetre, monkeypatch):
    from orion import maj
    from orion.core.config import CONFIG
    fils = []
    fini = threading.Event()

    def nettoyer():
        fils.append(threading.current_thread() is threading.main_thread())
        fini.set()
    monkeypatch.setattr(maj, "nettoyer", nettoyer)
    monkeypatch.setitem(CONFIG.data.setdefault("bibliotheque", {}), "non_installes", False)

    class _Vue:
        def set_possedes(self, x):
            pass

    class _Possedes:
        def tous(self):
            return []
    fenetre._arret_brutal = False
    fenetre.library_view = _Vue()
    fenetre.possedes = _Possedes()
    fenetre._boot_fond()
    try:
        assert fini.wait(5)
        assert fils == [False]
    finally:
        fenetre._timer_jeu.stop()
        fenetre._timer_maj.stop()
        # detruit la fenetre : ses minuteries « une fois » ne partiront pas
        # pendant un test suivant
        import shiboken6
        shiboken6.delete(fenetre)


def test_nettoyage_qui_echoue_ne_remonte_pas(monkeypatch):
    from orion import maj
    from orion.ui.fond import FondMixin
    monkeypatch.setattr(maj, "nettoyer", lambda: 1 / 0)
    FondMixin._nettoyer_maj()


# --------------------------------------------------------------------------
# maj : lancement de l'installateur, nettoyage
# --------------------------------------------------------------------------

def test_installateur_lance_proprement_avec_le_vrai_dossier(monkeypatch, tmp_path):
    from orion import maj
    exe = tmp_path / "D" / "Mes Jeux" / "ORION" / "ORION.exe"
    exe.parent.mkdir(parents=True)
    exe.write_text("x")
    monkeypatch.setattr(sys, "frozen", True, raising=False)
    monkeypatch.setattr(sys, "executable", str(exe))
    vus = []
    monkeypatch.setattr(lancement, "popen_propre",
                        lambda args, cwd=None, **kw: vus.append((args, cwd, kw)))
    assert maj.installer(tmp_path / "Installateur-ORION-9.exe")
    args, cwd, _ = vus[0]
    assert args[1] == "--silencieux" and "--relancer" in args
    assert args[args.index("--attendre") + 1] == str(os.getpid())
    assert Path(args[args.index("--cible") + 1]) == exe.parent.resolve()
    assert cwd is None                    # dossier neutre choisi par popen_propre


def test_installateur_hors_compilation_vise_le_dossier_installe(monkeypatch, tmp_path):
    from orion import maj
    from orion.deploiement import installation as inst
    monkeypatch.setattr(sys, "frozen", False, raising=False)
    monkeypatch.setattr(inst, "dossier_installe", lambda: tmp_path / "ORION")
    args = maj.arguments_installateur(Path("i.exe"), pid=7)
    assert args[args.index("--cible") + 1] == str(tmp_path / "ORION")


def test_maj_n_a_plus_son_propre_nettoyage_d_environnement():
    texte = (Path(__file__).resolve().parents[1] / "orion" / "maj.py").read_text("utf-8")
    assert "SetDllDirectoryW" not in texte and "_PYI_" not in texte
    assert "subprocess.Popen" not in texte


def test_nettoyer_continue_apres_un_fichier_verrouille(monkeypatch, tmp_path):
    from orion import maj
    temp = tmp_path / "temp"
    temp.mkdir()
    for v in ("0.1.0", "0.2.0", "0.3.0"):
        (temp / f"Installateur-ORION-{v}.exe").write_text("x")
    (temp / "Installateur-ORION-99.0.0.exe").write_text("garde")
    vieux = temp / "Installateur-ORION-99.0.0.exe.partiel"
    vieux.write_text("x")
    os.utime(vieux, (time.time() - 7200, time.time() - 7200))
    programme = tmp_path / "Programs" / "ORION"
    programme.mkdir(parents=True)
    (programme / "ORION.exe").write_text("x")
    (tmp_path / "Programs" / "ORION.nouveau").mkdir()
    (tmp_path / "Programs" / "ORION.nouveau-123").mkdir()
    (tmp_path / "Programs" / "ORION.ancien-5").mkdir()
    monkeypatch.setattr(maj, "dossier_temporaire", lambda: temp)
    monkeypatch.setattr(maj, "dossier_programme", lambda: programme)

    vrai = Path.unlink

    def unlink(self, missing_ok=False):
        if self.name == "Installateur-ORION-0.1.0.exe":
            raise PermissionError("verrouille")
        return vrai(self, missing_ok=missing_ok)
    monkeypatch.setattr(Path, "unlink", unlink)
    maj.nettoyer()
    restants = sorted(p.name for p in temp.iterdir())
    assert restants == ["Installateur-ORION-0.1.0.exe", "Installateur-ORION-99.0.0.exe"]
    assert sorted(p.name for p in (tmp_path / "Programs").iterdir()) == ["ORION"]


# --------------------------------------------------------------------------
# Installation silencieuse : ORION toujours relance
# --------------------------------------------------------------------------

@pytest.fixture
def silencieux(monkeypatch, tmp_path):
    from orion.deploiement import installation as inst
    from orion.deploiement import interface
    relances = []
    monkeypatch.setattr(interface, "relancer",
                        lambda exe, apres_maj=True: relances.append((Path(exe), apres_maj)))
    monkeypatch.setattr(interface, "attendre_fin", lambda pid, secondes=90: True)
    monkeypatch.setattr(interface, "_raccourci_bureau_voulu", lambda: False)
    cible = tmp_path / "D" / "ORION"
    cible.mkdir(parents=True)
    (cible / "ORION.exe").write_text("ancien")
    monkeypatch.setattr(inst, "dossier_installe", lambda: tmp_path / "ailleurs")
    monkeypatch.setattr(sys, "argv", ["Installateur-ORION.exe", "--silencieux",
                                      "--attendre", "123", "--cible", str(cible),
                                      "--relancer"])
    return interface, inst, cible, relances


def test_silencieux_programme_absent_relance_quand_meme(silencieux, monkeypatch, tmp_path):
    interface, inst, cible, relances = silencieux
    monkeypatch.setattr(interface, "payload_dir", lambda: tmp_path / "vide")
    assert interface.silencieux("installer") == 1
    assert relances == [(cible / "ORION.exe", False)]


def test_silencieux_exception_relance_avec_maj_echouee(silencieux, monkeypatch, tmp_path):
    interface, inst, cible, relances = silencieux
    paquet = tmp_path / "paquet"
    paquet.mkdir()
    (paquet / "ORION.exe").write_text("neuf")
    monkeypatch.setattr(interface, "payload_dir", lambda: paquet)

    def plante(**kw):
        raise RuntimeError("disque plein")
    monkeypatch.setattr(inst, "install", plante)
    assert interface.silencieux("installer") == 1
    assert relances == [(cible / "ORION.exe", False)]


def test_silencieux_installe_dans_le_dossier_cible(silencieux, monkeypatch, tmp_path):
    interface, inst, cible, relances = silencieux
    paquet = tmp_path / "paquet"
    paquet.mkdir()
    (paquet / "ORION.exe").write_text("neuf")
    monkeypatch.setattr(interface, "payload_dir", lambda: paquet)
    vus = []
    monkeypatch.setattr(inst, "install",
                        lambda payload, target, desktop_shortcut=True, progress=None:
                        vus.append(Path(target)) or (True, str(target)))
    assert interface.silencieux("installer") == 0
    assert vus == [cible]
    assert relances == [(cible / "ORION.exe", True)]


def test_silencieux_sans_cible_prend_le_dossier_installe(monkeypatch, tmp_path):
    from orion.deploiement import installation as inst
    from orion.deploiement import interface
    monkeypatch.setattr(inst, "dossier_installe", lambda: tmp_path / "X" / "ORION")
    monkeypatch.setattr(sys, "argv", ["i.exe", "--silencieux"])
    assert interface.cible_silencieuse() == tmp_path / "X" / "ORION"
    monkeypatch.setattr(sys, "argv", ["i.exe", "--silencieux", "--cible", "relatif"])
    assert interface.cible_silencieuse() == tmp_path / "X" / "ORION"


def test_raccourci_en_erreur_ne_fait_pas_echouer_l_installation(tmp_path, monkeypatch):
    from orion.deploiement import installation as inst
    paquet = tmp_path / "paquet"
    (paquet / "_internal").mkdir(parents=True)
    (paquet / "ORION.exe").write_text("neuf")

    def plante(*a, **k):
        raise RuntimeError("COM indisponible")
    monkeypatch.setattr(inst, "make_shortcut", plante)
    monkeypatch.setattr(inst, "desktop_dir", plante)
    monkeypatch.setattr(inst, "register_uninstall", plante)
    ok, message = inst.install(paquet, tmp_path / "Programs" / "ORION", True)
    assert ok, message
    assert (tmp_path / "Programs" / "ORION" / "ORION.exe").read_text() == "neuf"


def test_lancer_detache_dossier_neutre(monkeypatch, tmp_path):
    from orion.deploiement import interface
    vus = []
    monkeypatch.setattr(lancement, "popen_propre",
                        lambda args, cwd=None, **kw: vus.append(cwd))
    assert interface.lancer_detache([str(tmp_path / "ORION" / "ORION.exe")])
    assert vus == [None]


# --------------------------------------------------------------------------
# Base SQLite abimee
# --------------------------------------------------------------------------

def test_base_illisible_mise_de_cote_avec_wal(base_neuve):
    base = base_neuve
    base.FICHIER.write_bytes(b"ceci n'est pas une base " * 200)
    wal = base.FICHIER.with_name(base.FICHIER.name + "-wal")
    wal.write_bytes(b"journal abime")
    doc = base.Document("essai")
    assert doc.lire("defaut") == "defaut"
    assert doc.ecrire({"a": 1}) and doc.lire() == {"a": 1}
    noms = sorted(p.name for p in base.FICHIER.parent.iterdir())
    assert any(n.startswith("orion.abimee-") and n.endswith(".db") for n in noms)
    # la nouvelle base est saine
    base.fermer()
    cx = sqlite3.connect(str(base.FICHIER))
    assert cx.execute("PRAGMA quick_check").fetchone()[0] == "ok"
    cx.close()


def test_mise_de_cote_deplace_aussi_wal_et_shm(base_neuve):
    base = base_neuve
    for suffixe in ("", "-wal", "-shm"):
        base.FICHIER.with_name(base.FICHIER.name + suffixe).write_bytes(b"x")
    assert base._mettre_de_cote(base.FICHIER)
    noms = sorted(p.name for p in base.FICHIER.parent.iterdir())
    assert not [n for n in noms if n.startswith("orion.db")]
    assert len([n for n in noms if n.startswith("orion.abimee-")]) == 3
    assert any(n.endswith(".db-wal") for n in noms)
    assert any(n.endswith(".db-shm") for n in noms)


def test_base_illisible_et_impossible_a_deplacer(base_neuve, monkeypatch):
    base = base_neuve
    base.FICHIER.write_bytes(b"pas une base " * 200)
    vrai = Path.replace

    def replace(self, cible):
        if self.name.startswith("orion.db"):
            raise PermissionError("utilise par un autre processus")
        return vrai(self, cible)
    monkeypatch.setattr(Path, "replace", replace)
    table = base.Table("essai")
    table.set("k", 1)                       # base en memoire : ne plante pas
    assert table.get("k") == 1 and len(table) == 1
    assert base.FICHIER.exists()            # rien n'a ete detruit


def test_connexion_refermee_si_la_preparation_echoue(monkeypatch, tmp_path):
    from orion.core import base
    fermees = []

    class Cx:
        def execute(self, *a):
            raise sqlite3.DatabaseError("file is not a database")

        def close(self):
            fermees.append(True)
    monkeypatch.setattr(base.sqlite3, "connect", lambda *a, **k: Cx())
    with pytest.raises(sqlite3.DatabaseError):
        base._connecter(tmp_path / "x.db")
    assert fermees == [True]


def test_fenetre_principale_demarre_sur_une_base_abimee(app, base_neuve):
    base_neuve.FICHIER.write_bytes(b"\x00garbage" * 512)
    from orion.ui.main_window import MainWindow
    w = MainWindow()
    try:
        assert w is not None
    finally:
        for t in ("_timer_jeu", "_timer_maj"):
            if hasattr(w, t):
                getattr(w, t).stop()
        w.deleteLater()


# --------------------------------------------------------------------------
# Configuration
# --------------------------------------------------------------------------

@pytest.fixture
def config_isolee(monkeypatch, tmp_path):
    from orion.core import config
    fichier = tmp_path / "config.json"
    monkeypatch.setattr(config, "CONFIG_FILE", fichier)
    return config, fichier


def test_config_illisible_copiee_avant_tout_enregistrement(config_isolee):
    config, fichier = config_isolee
    fichier.write_text('{"ai": {"api_key": "sk-secret", ', encoding="utf-8")
    c = config.Config()
    copies = list(fichier.parent.glob("config.json.illisible-*"))
    assert len(copies) == 1 and "sk-secret" in copies[0].read_text("utf-8")
    assert c.illisible == copies[0]
    c.set("ui.accent", "#fff")
    assert json.loads(fichier.read_text("utf-8"))["ui"]["accent"] == "#fff"
    assert "sk-secret" in copies[0].read_text("utf-8")


def test_config_non_objet_traitee_comme_illisible(config_isolee):
    config, fichier = config_isolee
    fichier.write_text("[1, 2]", encoding="utf-8")
    c = config.Config()
    assert c.get("ui.accent") == config.DEFAULTS["ui"]["accent"]
    assert list(fichier.parent.glob("config.json.illisible-*"))


def test_defauts_jamais_modifies(config_isolee):
    config, fichier = config_isolee
    avant = json.dumps(config.DEFAULTS, sort_keys=True)
    c = config.Config()                       # fichier absent : valeurs par defaut
    c.set("ui.accent", "#123456")
    c.get("scan.extra_folders").append("D:/Jeux")
    fichier.write_text('{"maj": {"auto": false}}', encoding="utf-8")
    c2 = config.Config()
    c2.set("maj.derniere_vue", "9.9")
    c2.get("free.sources").append("x")
    assert json.dumps(config.DEFAULTS, sort_keys=True) == avant


def test_enregistrements_simultanes(config_isolee):
    config, fichier = config_isolee
    c = config.Config()
    erreurs = []

    def ecrire(i):
        try:
            for j in range(20):
                c.set(f"essai.f{i}", j)
        except Exception as exc:              # pragma: no cover
            erreurs.append(exc)
    fils = [threading.Thread(target=ecrire, args=(i,)) for i in range(6)]
    for f in fils:
        f.start()
    for f in fils:
        f.join()
    assert not erreurs
    donnees = json.loads(fichier.read_text("utf-8"))
    assert all(donnees["essai"][f"f{i}"] == 19 for i in range(6))
    assert not list(fichier.parent.glob("*.tmp"))


def test_ecrire_atomique_noms_provisoires_uniques(tmp_path, monkeypatch):
    from orion.core import paths
    noms = {paths._nom_provisoire(tmp_path / "a.json") for _ in range(50)}
    assert len(noms) == 50
    assert all(str(os.getpid()) in n.name for n in noms)

    fichier = tmp_path / "b.json"
    fichier.write_text("ancien", encoding="utf-8")

    def rate(source, cible):
        raise OSError("disque plein")
    monkeypatch.setattr(paths.os, "replace", rate)
    with pytest.raises(OSError):
        paths.ecrire_atomique(fichier, "neuf")
    assert fichier.read_text("utf-8") == "ancien"
    assert not list(tmp_path.glob("*.tmp"))


# --------------------------------------------------------------------------
# Demarrage : dossier courant neutre
# --------------------------------------------------------------------------

def test_demarrage_quitte_le_dossier_d_installation(monkeypatch, tmp_path):
    from orion import app as application
    donnees = tmp_path / "donnees"
    monkeypatch.setattr(application, "DATA_DIR", donnees)
    installe = tmp_path / "Programs" / "ORION"
    installe.mkdir(parents=True)
    avant = os.getcwd()
    try:
        os.chdir(installe)
        assert application.dossier_courant_neutre() == donnees
        assert Path(os.getcwd()).resolve() == donnees.resolve()
    finally:
        os.chdir(avant)


# --------------------------------------------------------------------------
# complements (audit)
# --------------------------------------------------------------------------

def test_nom_seul_sans_dossier_connu_exige_un_processus_recent():
    """Dossier du jeu inconnu : un « game.exe » deja ouvert ailleurs n'est
    pas le jeu ; seul un processus apparu apres le lancement l'est."""
    from orion.launch.launcher import _correspond
    ancien = {"name": "game.exe", "exe": "C:\\Autre\\game.exe", "create_time": 50.0}
    recent = {"name": "game.exe", "exe": "C:\\Autre\\game.exe", "create_time": 200.0}
    assert not _correspond(ancien, "game.exe", "", 100.0)
    assert _correspond(recent, "game.exe", "", 100.0)


def test_silencieux_attend_orion_avant_de_le_relancer(silencieux, monkeypatch, tmp_path):
    """Programme absent de l'installateur : ORION n'est relance qu'une fois
    l'ancien ferme (sinon le nouveau s'efface devant lui : une seule instance)."""
    interface, inst, cible, relances = silencieux
    ordre = []
    monkeypatch.setattr(interface, "attendre_fin",
                        lambda pid, secondes=90: ordre.append(("attente", pid)) or True)
    monkeypatch.setattr(interface, "relancer",
                        lambda exe, apres_maj=True: ordre.append(("relance", apres_maj)))
    monkeypatch.setattr(interface, "payload_dir", lambda: tmp_path / "vide")
    assert interface.silencieux("installer") == 1
    assert ordre == [("attente", 123), ("relance", False)]


def test_silencieux_attente_qui_plante_relance_quand_meme(silencieux, monkeypatch, tmp_path):
    interface, inst, cible, relances = silencieux

    def plante(pid, secondes=90):
        raise OSError("acces refuse")
    monkeypatch.setattr(interface, "attendre_fin", plante)
    monkeypatch.setattr(interface, "payload_dir", lambda: tmp_path / "vide")
    assert interface.silencieux("installer") == 1
    assert relances == [(cible / "ORION.exe", False)]


def test_base_qui_echoue_au_controle_mise_de_cote(base_neuve, monkeypatch):
    """Base ouvrable mais abimee (controle d'integrite en echec, meme apres
    reconstruction des index) : mise de cote, ORION repart d'une base neuve."""
    base = base_neuve
    cx = sqlite3.connect(str(base.FICHIER))
    cx.execute("CREATE TABLE t(x)")
    cx.commit()
    cx.close()
    controles = iter([False, False])            # premiere base : abimee
    monkeypatch.setattr(base, "_saine", lambda cx: next(controles, True))
    doc = base.Document("essai")
    assert doc.ecrire({"a": 1}) and doc.lire() == {"a": 1}
    assert [p for p in base.FICHIER.parent.iterdir() if p.name.startswith("orion.abimee-")]


def test_index_abime_reconstruit_sans_perte(base_neuve, monkeypatch):
    base = base_neuve
    base.Document("essai").ecrire({"a": 1})
    base.fermer()
    controles = iter([False, True])             # REINDEX suffit
    monkeypatch.setattr(base, "_saine", lambda cx: next(controles, True))
    assert base.Document("essai").lire() == {"a": 1}
    assert not [p for p in base.FICHIER.parent.iterdir() if "abimee" in p.name]


def test_config_illisible_renommee_si_la_copie_echoue(config_isolee, monkeypatch):
    config, fichier = config_isolee
    fichier.write_text('{"ai": {"api_key": "sk-secret", ', encoding="utf-8")

    def plante(*a, **k):
        raise OSError("disque plein")
    monkeypatch.setattr(config.shutil, "copy2", plante)
    c = config.Config()
    assert c.illisible is not None and "sk-secret" in c.illisible.read_text("utf-8")
    c.set("ui.accent", "#fff")                   # l'original n'est pas ecrase
    assert "sk-secret" in c.illisible.read_text("utf-8")
