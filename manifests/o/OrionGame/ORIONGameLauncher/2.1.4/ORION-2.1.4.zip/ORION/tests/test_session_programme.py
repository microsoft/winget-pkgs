"""La session d'un jeu suit le bon programme.

Constate dans le journal de l'auteur (Cyberpunk 2077, 4 octobre) : la mesure
des images s'accrochait a « REDprelauncher.exe » ou a
« REDEngineErrorReporter.exe », parce que le premier programme vu dans le
dossier du jeu etait pris pour le jeu. Vrai pour tout jeu qui a un lanceur."""
import threading
import time
import types

import pytest

from orion.core.models import Game
from orion.launch import launcher


class TimeoutExpired(Exception):
    pass


class Programme:
    """Un faux processus : vivant de `debut` a `fin` (secondes apres t0)."""

    def __init__(self, monde, pid, nom, debut, fin, memoire=100):
        self.monde, self.pid, self.debut, self.fin, self.memoire = monde, pid, debut, fin, memoire
        self.info = {"name": nom, "exe": str(monde.dossier / nom), "create_time": time.time() + 100}

    def vivant(self):
        return self.debut <= self.monde.age() < self.fin

    def is_running(self):
        return self.vivant()

    def wait(self, timeout=None):
        limite = time.monotonic() + (timeout or 0)
        while time.monotonic() < limite:
            if not self.vivant():
                return 0
            time.sleep(0.005)
        if self.vivant():
            raise TimeoutExpired()
        return 0

    def memory_info(self):
        return types.SimpleNamespace(rss=self.memoire)


class Monde:
    def __init__(self, dossier):
        self.dossier, self.t0, self.programmes = dossier, time.monotonic(), []

    def age(self):
        return time.monotonic() - self.t0

    def ajouter(self, nom, debut, fin, memoire=100):
        p = Programme(self, len(self.programmes) + 1, nom, debut, fin, memoire)
        self.programmes.append(p)
        return p

    def process_iter(self, _champs=None):
        return [p for p in self.programmes if p.vivant()]


@pytest.fixture()
def partie(tmp_path, monkeypatch):
    import psutil
    dossier = tmp_path / "Cyberpunk 2077"
    dossier.mkdir()
    monde = Monde(dossier)
    monkeypatch.setattr(psutil, "process_iter", monde.process_iter)
    monkeypatch.setattr(launcher.BUS, "emit", lambda *a, **k: None)
    for nom, valeur in (("INTERVALLE_ATTENTE", 0.02), ("PAUSE_RECHERCHE", 0.01),
                        ("PATIENCE_LANCEUR", 0.25), ("RELAIS", 0.3)):
        monkeypatch.setattr(launcher, nom, valeur)
    jeu = Game(title="Cyberpunk 2077", source="steam", source_id="1091500", uid="s1",
               install_dir=str(dossier), executable=str(dossier / "Cyberpunk2077.exe"))
    s = launcher.GameSession(jeu, None)
    s.started_at = time.time()
    mesures = []
    monkeypatch.setattr(s, "_start_capture", lambda nom, pid=0: mesures.append(nom))
    return monde, s, mesures


def _jouer(s, delai=5.0):
    fil = threading.Thread(target=s._watch, daemon=True)
    fil.start()
    fil.join(delai)
    assert not fil.is_alive(), "la session ne s'est pas terminee"


def test_le_lanceur_passe_la_main_au_jeu(partie):
    monde, s, mesures = partie
    monde.ajouter("REDprelauncher.exe", 0.0, 0.10)
    monde.ajouter("Cyberpunk2077.exe", 0.08, 0.60, memoire=9000)
    monde.ajouter("REDEngineErrorReporter.exe", 0.12, 2.0)      # reste ouvert apres le jeu
    _jouer(s)
    assert mesures == ["Cyberpunk2077.exe"]            # ni le lanceur, ni le rapporteur
    assert s.termine and 0.5 <= monde.age() < 1.6      # finie avec le jeu, pas avec le rapporteur


def test_un_lanceur_seul_n_est_pas_pris_pour_le_jeu_tant_qu_on_peut_attendre(partie):
    monde, s, mesures = partie
    monde.ajouter("launcher.exe", 0.0, 5.0)
    jeu = monde.ajouter("Game-Win64-Shipping.exe", 0.12, 0.5)
    assert s._wait_for_process(timeout=3) is jeu       # le jeu, arrive apres le lanceur


def test_lanceur_qui_reste_puis_jeu_qui_arrive_tard(partie):
    monde, s, mesures = partie
    monde.ajouter("launcher.exe", 0.0, 5.0)            # reste ouvert toute la partie
    monde.ajouter("Game-Win64-Shipping.exe", 0.45, 0.9)  # apres le delai de patience
    _jouer(s)
    assert mesures == ["Game-Win64-Shipping.exe"]      # le lanceur n'est jamais mesure
    assert 0.85 <= monde.age() < 2.0                   # finie avec le jeu : le lanceur ouvert ne prolonge rien


def test_lanceur_ferme_avant_que_le_jeu_n_apparaisse(partie):
    monde, s, mesures = partie
    monde.ajouter("launcher.exe", 0.0, 0.30)           # pris faute de mieux, puis il se ferme
    monde.ajouter("Game.exe", 0.42, 0.8)               # le jeu arrive dans le delai de relais
    _jouer(s)
    assert mesures == ["Game.exe"] and monde.age() >= 0.75


def test_jeu_sans_lanceur_comme_avant(partie):
    monde, s, mesures = partie
    monde.ajouter("Cyberpunk2077.exe", 0.0, 0.3)
    _jouer(s)
    assert mesures == ["Cyberpunk2077.exe"] and s.termine and monde.age() < 1.2


def test_a_rang_egal_le_plus_gros_programme_est_le_jeu(partie):
    monde, s, _ = partie
    s.game.executable = ""                              # executable inconnu
    monde.ajouter("CefSharp.BrowserSubprocess.exe", 0.0, 5.0, memoire=200)
    gros = monde.ajouter("Game-Win64-Shipping.exe", 0.0, 5.0, memoire=6000)
    monde.ajouter("CrashReportClient.exe", 0.0, 5.0, memoire=99999)
    assert s._processus_du_jeu()[0] is gros
    # le navigateur integre d'un lanceur (Larian) n'est plus jamais pris pour le jeu
    assert [s._rang(p) for p in s._processus_du_jeu()] == [1, 2, 2]


def test_l_amorce_unreal_n_est_pas_le_jeu(partie):
    """Journal de l'auteur (Aniimo, 7 octobre) : « Mesure demarree sur
    Aniimo.exe » et jamais de « Mesure : ... ». Sur Unreal, l'executable a
    la racine n'est qu'une amorce qui lance <Projet>-Win64-Shipping.exe et
    reste ouverte derriere lui sans rien afficher."""
    monde, s, mesures = partie
    s.game.executable = str(monde.dossier / "Aniimo.exe")
    rendu = monde.dossier / "Aniimo" / "Binaries" / "Win64"
    rendu.mkdir(parents=True)
    (rendu / "Aniimo-Win64-Shipping.exe").write_bytes(b"MZ")
    monde.ajouter("Aniimo.exe", 0.0, 5.0, memoire=30)                   # l'amorce, ouverte toute la partie
    monde.ajouter("Aniimo-Win64-Shipping.exe", 0.10, 0.6, memoire=9000)
    monde.ajouter("CrashReportClient.exe", 0.12, 5.0)
    _jouer(s)
    assert mesures == ["Aniimo-Win64-Shipping.exe"]    # le programme qui affiche, pas l'amorce
    assert s.termine and 0.55 <= monde.age() < 1.5     # finie avec le jeu, pas avec l'amorce


def test_sans_programme_de_rendu_l_executable_declare_reste_le_jeu(partie):
    monde, s, _ = partie
    s.game.executable = str(monde.dossier / "Aniimo.exe")
    s._rendu = launcher._programmes_de_rendu(s.game)   # dossier sans *-Win64-Shipping.exe
    assert s._rendu == set()
    assert s._rang(monde.ajouter("Aniimo.exe", 0.0, 5.0)) == 0


def test_une_mesure_vide_est_dite_dans_le_journal(partie, monkeypatch):
    monde, s, _ = partie
    journal = []
    monkeypatch.setattr(launcher.log, "info", lambda msg, *a: journal.append(msg % a))
    jeu = monde.ajouter("Cyberpunk2077.exe", 0.0, 0.2)
    s.capture = types.SimpleNamespace(stop=lambda: None)
    s._mesure_sur, s._mesure_pid = "cyberpunk2077.exe", jeu.pid
    _jouer(s)
    assert "Mesure sans resultat sur cyberpunk2077.exe : aucune image relevee" in journal


def test_les_programmes_qui_ne_sont_pas_le_jeu():
    from orion.en_jeu import auxiliaire
    for nom in ("REDprelauncher.exe", "REDEngineErrorReporter.exe", "UnityCrashHandler64.exe",
                "CrashReportClient.exe", "EasyAntiCheat_Setup.exe", "launcher.exe", "BEService.exe",
                "vc_redist.x64.exe", "Updater.exe"):
        assert auxiliaire(nom), nom
    for nom in ("Cyberpunk2077.exe", "cs2.exe", "t6mp.exe", "cstrike_win64.exe", "Aniimo.exe",
                "eldenring.exe", "bg3_dx11.exe"):
        assert not auxiliaire(nom), nom


def test_un_second_clic_sur_jouer_ne_lance_pas_deux_parties():
    """Journal de l'auteur, 5 octobre : « Mesure demarree sur t6mp.exe » deux
    fois a une seconde d'ecart."""
    PySide6 = pytest.importorskip("PySide6")  # noqa: F841
    from orion.ui.main_window import MainWindow
    jeu = Game(title="Black Ops II", source="steam", source_id="202990", uid="s2")
    messages = []

    def interdit(*a, **k):
        raise AssertionError("le jeu ne doit pas etre relance")
    faux = types.SimpleNamespace(
        library=types.SimpleNamespace(get=lambda uid: jeu), _lancement_bloque=lambda g: False,
        sessions=[types.SimpleNamespace(game=jeu, termine=False)], notify=lambda m, *a: messages.append(m),
        detail_view=types.SimpleNamespace(plan=None), optimizer=types.SimpleNamespace(build_plan=interdit),
        _display_for=interdit)
    MainWindow.play(faux, "s2", "equilibre")
    assert messages == ["Black Ops II : deja lance"]
    # la partie precedente est finie : le jeu se relance
    faux.sessions[0].termine = True
    with pytest.raises(AssertionError):
        MainWindow.play(faux, "s2", "equilibre")


def test_un_outil_vite_ferme_ne_termine_pas_la_partie(partie):
    """10 octobre (Baldur's Gate 3) : « DriverVersionChecker.exe », un outil du
    lanceur range dans le dossier du jeu, a ete suivi puis s'est ferme : la
    session s'est crue finie au bout de 6 s. Un programme du dossier qui se
    ferme vite passe la main au jeu, comme un lanceur."""
    monde, s, mesures = partie
    monde.ajouter("OutilMaison.exe", 0.0, 0.10)                  # pas le jeu, nom inconnu
    monde.ajouter("Cyberpunk2077.exe", 0.18, 0.70, memoire=9000)
    _jouer(s)
    assert mesures[-1] == "Cyberpunk2077.exe" and s.termine and monde.age() >= 0.7


def test_les_outils_du_lanceur_larian_ne_sont_pas_le_jeu():
    from orion.en_jeu import auxiliaire
    for nom in ("DriverVersionChecker.exe", "CefSharp.BrowserSubprocess.exe", "LariLauncher.exe"):
        assert auxiliaire(nom), nom
    for nom in ("bg3.exe", "bg3_dx11.exe"):
        assert not auxiliaire(nom), nom


def test_un_jeu_qui_se_relance_est_mesure_sur_son_nouveau_processus(partie):
    """10 octobre (Baldur's Gate 3) : le premier « bg3_dx11.exe » s'est ferme
    aussitot et un second a pris la suite ; la mesure restait accrochee au
    premier, aucune image relevee."""
    monde, s, mesures = partie
    monde.ajouter("OutilMaison.exe", 0.0, 0.05)
    premier = monde.ajouter("Cyberpunk2077.exe", 0.02, 0.10, memoire=9000)
    second = monde.ajouter("Cyberpunk2077.exe", 0.16, 0.70, memoire=9000)
    _jouer(s)
    assert mesures.count("Cyberpunk2077.exe") == 2 and s._mesure_pid == second.pid != premier.pid


def test_orion_est_prevenu_quand_la_fenetre_du_jeu_est_la(partie, monkeypatch):
    """15 octobre (enregistrement de l'auteur) : ORION se reduisait 1,5 s apres
    le clic et le bureau restait vide les 40 s de demarrage. Il est prevenu
    quand le jeu lui-meme (jamais le lanceur) montre une fenetre."""
    monde, s, mesures = partie
    vues = []
    s.on_fenetre = lambda jeu: vues.append((jeu.title, round(monde.age(), 1)))
    monde.ajouter("REDprelauncher.exe", 0.0, 0.10)
    jeu = monde.ajouter("Cyberpunk2077.exe", 0.08, 0.60, memoire=9000)
    fenetre_depuis = 0.30
    monkeypatch.setattr(launcher, "fenetre_visible",
                        lambda pid: pid == jeu.pid and monde.age() >= fenetre_depuis)
    monkeypatch.setattr(launcher, "ATTENTE_FENETRE", 2)
    monkeypatch.setattr(launcher, "PAUSE_FENETRE", 0.02)
    _jouer(s)
    assert len(vues) == 1 and vues[0][0] == "Cyberpunk 2077"
    assert fenetre_depuis <= vues[0][1] < 0.6               # ni avant la fenetre, ni apres le jeu


def test_sans_fenetre_visible_orion_n_est_pas_retenu_indefiniment(partie, monkeypatch):
    monde, s, mesures = partie
    vues = []
    s.on_fenetre = lambda jeu: vues.append(jeu.title)
    monde.ajouter("Cyberpunk2077.exe", 0.0, 0.8, memoire=9000)
    monkeypatch.setattr(launcher, "fenetre_visible", lambda pid: False)
    monkeypatch.setattr(launcher, "ATTENTE_FENETRE", 0.2)
    _jouer(s)
    assert vues == ["Cyberpunk 2077"]                       # a l'echeance : lance quand meme


def test_hors_windows_la_fenetre_est_supposee_la(partie, monkeypatch):
    monde, s, mesures = partie
    vues = []
    s.on_fenetre = lambda jeu: vues.append(jeu.title)
    monde.ajouter("Cyberpunk2077.exe", 0.0, 0.4, memoire=9000)
    monkeypatch.setattr(launcher, "fenetre_visible", lambda pid: None)
    _jouer(s)
    assert vues == ["Cyberpunk 2077"]
