"""Revue 1.8 : deplacement de jeux, comptes, journal, taches — correctifs."""
import logging
import os
from pathlib import Path

import pytest


@pytest.fixture(scope="module")
def app():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


def _jeu_factice(dossier):
    (dossier / "bin").mkdir(parents=True)
    (dossier / "jeu.exe").write_bytes(b"x" * 1000)
    (dossier / "bin" / "data.pak").write_bytes(b"y" * 5000)


@pytest.fixture
def dep(monkeypatch):
    from orion import deplacement
    monkeypatch.setattr(deplacement, "MARGE_FIXE", 0)
    return deplacement


def _deplace(tmp_path, dep):
    src = tmp_path / "C" / "Jeux" / "MonJeu"
    _jeu_factice(src)
    vers = Path(dep.deplacer(str(src), str(tmp_path / "D")))
    return src, vers


# ----------------------------------------------------------------------
# ramener : transactionnel
# ----------------------------------------------------------------------
def test_ramener_echec_apres_retrait_jonction_remet_tout(tmp_path, dep, monkeypatch):
    src, vers = _deplace(tmp_path, dep)
    vrai = Path.rename

    def rename(self, cible):
        if str(self).endswith(dep.SUFFIXE_RETOUR):
            raise PermissionError(13, "verrouille par l'antivirus")
        return vrai(self, cible)
    monkeypatch.setattr(Path, "rename", rename)
    with pytest.raises(dep.DeplacementImpossible) as err:
        dep.ramener(str(src), attendu=str(vers))
    texte = str(err.value)
    assert "Etat du jeu : inchange" in texte and "A REPARER" not in texte
    # le jeu est toujours accessible, rien ne traine
    assert dep.est_jonction(src) and (src / "bin" / "data.pak").read_bytes() == b"y" * 5000
    assert vers.is_dir() and not vers.with_name(vers.name + dep.SUFFIXE_ANCIEN).exists()
    assert not src.with_name(src.name + dep.SUFFIXE_RETOUR).exists()


def test_ramener_retour_arriere_impossible_decrit_l_etat(tmp_path, dep, monkeypatch):
    src, vers = _deplace(tmp_path, dep)
    vrai = Path.rename

    def rename(self, cible):
        if str(self).endswith(dep.SUFFIXE_RETOUR) or str(self).endswith(dep.SUFFIXE_ANCIEN):
            raise PermissionError(13, "verrouille")
        return vrai(self, cible)
    monkeypatch.setattr(Path, "rename", rename)
    with pytest.raises(dep.DeplacementImpossible) as err:
        dep.ramener(str(src))
    assert "A REPARER" in str(err.value) and dep.SUFFIXE_RETOUR in str(err.value)
    # la copie verifiee n'a pas ete supprimee
    assert (src.with_name(src.name + dep.SUFFIXE_RETOUR) / "jeu.exe").exists()


def test_ramener_refuse_une_autre_destination(tmp_path, dep):
    src, vers = _deplace(tmp_path, dep)
    with pytest.raises(dep.DeplacementImpossible, match="par securite"):
        dep.ramener(str(src), attendu=str(tmp_path / "E" / "Jeux ORION" / "MonJeu"))
    assert dep.est_jonction(src) and vers.is_dir()


def test_ramener_refuse_une_jonction_hors_jeux_orion(tmp_path, dep):
    cible = tmp_path / "Partage" / "Contenu"
    _jeu_factice(cible)
    lien = tmp_path / "C" / "MonJeu"
    lien.parent.mkdir(parents=True)
    dep.creer_lien(cible, lien)
    with pytest.raises(dep.DeplacementImpossible, match="Jeux ORION"):
        dep.ramener(str(lien))
    assert (cible / "jeu.exe").exists()


def test_ramener_detecte_une_modification_pendant_la_copie(tmp_path, dep, monkeypatch):
    src, vers = _deplace(tmp_path, dep)
    vrai = dep._copier

    def copier(a, b, total, progression):
        vrai(a, b, total, progression)
        (vers / "sauvegarde.dat").write_bytes(b"partie")     # le jeu ecrit
    monkeypatch.setattr(dep, "_copier", copier)
    with pytest.raises(dep.DeplacementImpossible, match="modifie pendant la copie"):
        dep.ramener(str(src))
    assert dep.est_jonction(src) and (vers / "sauvegarde.dat").exists()


def test_ramener_signale_les_restes(tmp_path, dep, monkeypatch):
    src, vers = _deplace(tmp_path, dep)
    vrai = dep._supprimer
    monkeypatch.setattr(dep, "_supprimer", lambda c: ["fichier verrouille"]
                        if str(c).endswith(dep.SUFFIXE_ANCIEN) else vrai(c))
    restes = []
    dep.ramener(str(src), attendu=str(vers), restes=restes)
    assert not dep.est_jonction(src) and (src / "jeu.exe").exists()
    assert restes and "supprimez ce dossier" in restes[0]


# ----------------------------------------------------------------------
# deplacer : controles, verification, retour arriere
# ----------------------------------------------------------------------
def test_deplacer_detecte_une_modification_de_l_original(tmp_path, dep, monkeypatch):
    src = tmp_path / "C" / "MonJeu"
    _jeu_factice(src)
    vrai = dep._copier

    def copier(a, b, total, progression):
        vrai(a, b, total, progression)
        f = src / "jeu.exe"
        os.utime(f, ns=(f.stat().st_atime_ns, f.stat().st_mtime_ns + 5_000_000_000))
    monkeypatch.setattr(dep, "_copier", copier)
    with pytest.raises(dep.DeplacementImpossible, match="modifie pendant la copie") as err:
        dep.deplacer(str(src), str(tmp_path / "D"))
    assert "intact" in str(err.value)
    assert not dep.est_jonction(src) and (src / "jeu.exe").exists()
    assert not any((tmp_path / "D" / "Jeux ORION").iterdir())


def test_deplacer_verifie_chaque_fichier(tmp_path, dep, monkeypatch):
    src = tmp_path / "C" / "MonJeu"
    _jeu_factice(src)
    vrai = dep._copier

    def copier(a, b, total, progression):
        vrai(a, b, total, progression)
        # memes totaux, mais deux fichiers faux
        (Path(b) / "jeu.exe").write_bytes(b"x" * 1001)
        (Path(b) / "bin" / "data.pak").write_bytes(b"y" * 4999)
    monkeypatch.setattr(dep, "_copier", copier)
    with pytest.raises(dep.DeplacementImpossible, match="incomplete ou differente"):
        dep.deplacer(str(src), str(tmp_path / "D"))
    assert (src / "jeu.exe").read_bytes() == b"x" * 1000


def test_deplacer_refuse_un_reste_ancien_avant_la_copie(tmp_path, dep, monkeypatch):
    src = tmp_path / "C" / "MonJeu"
    _jeu_factice(src)
    (tmp_path / "C" / "MonJeu.ancien-orion").mkdir()
    copies = []
    monkeypatch.setattr(dep, "_copier", lambda *a: copies.append(a))
    with pytest.raises(dep.DeplacementImpossible, match="existe deja"):
        dep.deplacer(str(src), str(tmp_path / "D"))
    assert not copies


def test_deplacer_refuse_un_dossier_non_modifiable(tmp_path, dep, monkeypatch):
    src = tmp_path / "C" / "MonJeu"
    _jeu_factice(src)
    vrai = Path.mkdir

    def mkdir(self, *a, **k):
        if self.name.startswith(".orion-essai") and self.parent == src.parent:
            raise PermissionError(13, "Acces refuse")
        return vrai(self, *a, **k)
    monkeypatch.setattr(Path, "mkdir", mkdir)
    with pytest.raises(dep.DeplacementImpossible, match=r"protege.*\n\nEtat du jeu : intact"):
        dep.deplacer(str(src), str(tmp_path / "D"))


def test_deplacer_message_avec_code_erreur(tmp_path, dep, monkeypatch):
    src = tmp_path / "C" / "MonJeu"
    _jeu_factice(src)
    vrai = Path.rename

    def rename(self, cible):
        if self == src:
            raise PermissionError(13, "Acces refuse")
        return vrai(self, cible)
    monkeypatch.setattr(Path, "rename", rename)
    with pytest.raises(dep.DeplacementImpossible, match=r"\[13\] Acces refuse"):
        dep.deplacer(str(src), str(tmp_path / "D"))


def test_deplacer_jonction_impossible_retour_a_l_etat_initial(tmp_path, dep, monkeypatch):
    src = tmp_path / "C" / "MonJeu"
    _jeu_factice(src)

    def creer_lien(cible, lien):
        raise OSError(1, "jonction refusee")
    monkeypatch.setattr(dep, "creer_lien", creer_lien)
    with pytest.raises(dep.DeplacementImpossible, match="Etat du jeu : intact"):
        dep.deplacer(str(src), str(tmp_path / "D"))
    assert (src / "jeu.exe").exists() and not dep.est_jonction(src)
    assert not (tmp_path / "C" / "MonJeu.ancien-orion").exists()
    assert not any((tmp_path / "D" / "Jeux ORION").iterdir())


def test_deplacer_retour_arriere_impossible_dit_ou_est_le_jeu(tmp_path, dep, monkeypatch):
    src = tmp_path / "C" / "MonJeu"
    _jeu_factice(src)
    monkeypatch.setattr(dep, "creer_lien", lambda c, l: (_ for _ in ()).throw(OSError("non")))
    vrai = Path.rename

    def rename(self, cible):
        if str(self).endswith(dep.SUFFIXE_ANCIEN):
            raise PermissionError(13, "verrouille")
        return vrai(self, cible)
    monkeypatch.setattr(Path, "rename", rename)
    with pytest.raises(dep.DeplacementImpossible, match="A REPARER") as err:
        dep.deplacer(str(src), str(tmp_path / "D"))
    assert "MonJeu.ancien-orion" in str(err.value)
    assert (tmp_path / "C" / "MonJeu.ancien-orion" / "jeu.exe").exists()


def test_deplacer_signale_l_ancien_non_supprime(tmp_path, dep, monkeypatch):
    src = tmp_path / "C" / "MonJeu"
    _jeu_factice(src)
    vrai = dep._supprimer
    monkeypatch.setattr(dep, "_supprimer", lambda c: ["verrouille"]
                        if str(c).endswith(dep.SUFFIXE_ANCIEN) else vrai(c))
    restes = []
    dep.deplacer(str(src), str(tmp_path / "D"), restes=restes)
    assert dep.est_jonction(src) and restes and "MonJeu.ancien-orion" in restes[0]


def test_supprimer_retire_les_fichiers_en_lecture_seule(tmp_path, dep):
    d = tmp_path / "X"
    _jeu_factice(d)
    os.chmod(d / "jeu.exe", 0o444)
    assert dep._supprimer(d) == [] and not d.exists()


def test_progression_injectee_par_la_tache(app):
    from orion import deplacement
    from orion.core.tasks import Task
    t = Task(deplacement.deplacer, "C:\\Jeux\\X", "D:", restes=[])
    assert "progress_cb" in t.kwargs
    t = Task(deplacement.ramener, "C:\\Jeux\\X", attendu="")
    assert "progress_cb" in t.kwargs


# ----------------------------------------------------------------------
# remise en ordre au demarrage
# ----------------------------------------------------------------------
def _fiche(src, **extra):
    from orion.core.models import Game
    return Game(title="Mon Jeu", source="steam", source_id="42", install_dir=str(src),
                extra=dict(extra))


def test_reparer_aller_interrompu(tmp_path, dep):
    src = tmp_path / "C" / "MonJeu"
    _jeu_factice(src.with_name("MonJeu.ancien-orion"))
    copie = tmp_path / "D" / "Jeux ORION" / "MonJeu.copie-en-cours"
    _jeu_factice(copie)
    r = dep.reparer_restes([_fiche(src)], [str(tmp_path / "D")])
    assert (src / "jeu.exe").exists() and not copie.exists()
    assert len(r.actions) == 2 and not r.restes


def test_reparer_retour_interrompu_remet_la_jonction(tmp_path, dep):
    src, vers = _deplace(tmp_path, dep)
    # arret brutal : destination renommee, jonction retiree, copie de retour faite
    vers.rename(vers.with_name(vers.name + dep.SUFFIXE_ANCIEN))
    dep.retirer_lien(src)
    _jeu_factice(src.with_name(src.name + dep.SUFFIXE_RETOUR))
    g = _fiche(src, deplace={"vers": str(vers), "le": 1})
    r = dep.reparer_restes([g], [])
    assert dep.est_jonction(src) and (src / "jeu.exe").exists() and vers.is_dir()
    assert not src.with_name(src.name + dep.SUFFIXE_RETOUR).exists()
    assert g.extra["deplace"]["vers"] == str(vers) and not r.restes


def test_reparer_enregistre_un_deplacement_non_note(tmp_path, dep):
    src, vers = _deplace(tmp_path, dep)
    g = _fiche(src)
    r = dep.reparer_restes([g], [])
    assert r.modifie and os.path.samefile(g.extra["deplace"]["vers"], vers)


def test_reparer_oublie_un_retour_non_note(tmp_path, dep):
    src = tmp_path / "C" / "MonJeu"
    _jeu_factice(src)
    g = _fiche(src, deplace={"vers": str(tmp_path / "D" / "Jeux ORION" / "MonJeu")})
    r = dep.reparer_restes([g], [])
    assert r.modifie and "deplace" not in g.extra


def test_reparer_garde_la_copie_si_le_jeu_manque(tmp_path, dep):
    src = tmp_path / "C" / "MonJeu"                  # ni dossier ni ancien
    src.parent.mkdir(parents=True)
    copie = tmp_path / "D" / "Jeux ORION" / "MonJeu.copie-en-cours"
    _jeu_factice(copie)
    r = dep.reparer_restes([_fiche(src)], [str(tmp_path / "D")])
    assert copie.exists() and r.restes


# ----------------------------------------------------------------------
# bibliotheque : le drapeau « deplace » survit a un nouveau scan
# ----------------------------------------------------------------------
def test_merge_scan_garde_le_deplacement(base_neuve, tmp_path):
    from orion.core.models import Game
    from orion.core.store import LibraryStore
    store = LibraryStore()
    ancien = Game(title="Mon Jeu", source="steam", source_id="42",
                  install_dir=str(tmp_path), extra={"deplace": {"vers": "D:\\Jeux ORION\\X"},
                                                    "manifeste": "vieux"})
    store.games[ancien.uid] = ancien
    neuf = Game(title="Mon Jeu", source="steam", source_id="42", install_dir=str(tmp_path),
                extra={"manifeste": "neuf"})
    store.merge_scan([neuf])
    g = store.games[neuf.uid]
    assert g.extra["deplace"] == {"vers": "D:\\Jeux ORION\\X"}
    assert g.extra["manifeste"] == "neuf"            # la valeur du scan prime


# ----------------------------------------------------------------------
# journal et rapports
# ----------------------------------------------------------------------
def test_journal_masque_la_trace_des_exceptions():
    import io
    from orion.core.logging_setup import MasqueSecrets
    flux = io.StringIO()
    h = logging.StreamHandler(flux)
    h.addFilter(MasqueSecrets())
    h.setFormatter(logging.Formatter("%(message)s"))
    lg = logging.getLogger("revue.masque")
    lg.addHandler(h)
    lg.propagate = False
    try:
        try:
            raise RuntimeError("Max retries exceeded with url: /token?client_id=1&"
                               "client_secret=SECRETSECRET&refresh_token=JETON123456")
        except RuntimeError as exc:
            raise ValueError("connexion requise") from exc
    except ValueError:
        lg.exception("Tache en echec : %s", "travail")
    lg.info("pile", stack_info=True, extra={})
    texte = flux.getvalue()
    assert "Traceback" in texte and "connexion requise" in texte
    assert "SECRETSECRET" not in texte and "JETON123456" not in texte


def test_rapport_masque_les_secrets_oauth():
    from orion.signalement import anonymiser
    t = anonymiser('GET /token?client_secret=ABCDEF&x=1 {"ms_refresh": "M.R3_BAY.abc"}')
    assert "ABCDEF" not in t and "M.R3_BAY" not in t


# ----------------------------------------------------------------------
# comptes : connexion inachevee, deconnexion pendant une actualisation
# ----------------------------------------------------------------------
def _plateforme_test(lire_profil):
    from orion.comptes.base import Plateforme, Profil

    class Test(Plateforme):
        id = "test"
        nom = "Test"

        def retour_connexion(self, adresse):
            return {"jeton": adresse}

        def _lire_profil(self):
            return lire_profil(self) or Profil(plateforme="test", id="1", pseudo="moi")
    return Test()


def test_connexion_sans_profil_ne_garde_pas_de_jeton(base_neuve):
    def echec(p):
        raise RuntimeError("reseau coupe")
    p = _plateforme_test(echec)
    with pytest.raises(RuntimeError):
        p.connecter("neuf")
    assert not p.connecte()


def test_reconnexion_ratee_garde_l_ancienne_connexion(base_neuve):
    from orion.comptes import coffre
    etat = {"echec": False}

    def lire(p):
        if etat["echec"]:
            raise RuntimeError("reseau coupe")
    p = _plateforme_test(lire)
    p.connecter("ancien")
    etat["echec"] = True
    with pytest.raises(RuntimeError):
        p.connecter("neuf")
    assert coffre.lire("test") == {"jeton": "ancien"}


def test_deconnexion_pendant_actualisation_n_ecrit_plus_rien(base_neuve):
    from orion.comptes import ConnexionRequise
    etat = {"deconnecter": False}

    def lire(p):
        if etat["deconnecter"]:
            p.deconnecter()                     # le joueur clique pendant la lecture
    p = _plateforme_test(lire)
    p.connecter("x")
    etat["deconnecter"] = True
    with pytest.raises(ConnexionRequise):
        p.profil(forcer=True)
    assert p.profil_garde() is None and not p.connecte()


def test_carte_compte_bloque_la_deconnexion_pendant_l_actualisation(app):
    from orion.comptes import Profil
    from orion.ui.views.comptes_view import CarteCompte
    c = CarteCompte("gog")
    c.definir(Profil(plateforme="gog", id="1", pseudo="moi"), [], "", occupe=True)
    assert not c.b_deconnecter.isEnabled()
    c.definir(Profil(plateforme="gog", id="1", pseudo="moi"), [], "", occupe=False)
    assert c.b_deconnecter.isEnabled()


# ----------------------------------------------------------------------
# page Stockage
# ----------------------------------------------------------------------
def test_stockage_boutons_suivent_les_donnees(app, tmp_path):
    from orion.core.models import Game, HardwareInfo
    from orion.storage import Entry
    from orion.ui.views.storage_view import StorageView
    v = StorageView()
    g = Game(title="Mon Jeu", source="steam", source_id="42", install_dir="C:\\Jeux\\X")
    v.set_data([Entry(game=g, disk="C:")], [], HardwareInfo())
    v.table.setCurrentCell(0, 0)
    assert not v.sauvegarder.isHidden() and v.ramener.isHidden()
    g.extra["deplace"] = {"vers": "D:\\Jeux ORION\\X"}
    v.set_data([Entry(game=g, disk="D:")], [], HardwareInfo())   # sans nouveau clic
    assert v.sauvegarder.isHidden() and not v.ramener.isHidden()
    v.set_occupe(True)
    assert not v.ramener.isEnabled() and not v.uninstall.isEnabled()
    v.set_occupe(False)
    assert v.ramener.isEnabled()


# ----------------------------------------------------------------------
# taches : l'objet des signaux est libere apres livraison
# ----------------------------------------------------------------------
def test_tache_libere_ses_signaux_apres_livraison(app):
    import shiboken6
    from PySide6.QtCore import QCoreApplication, QEventLoop, QThreadPool, QTimer
    from orion.core.tasks import Task
    recu = []
    t = Task(lambda: 42)
    signaux = t.signals
    t.signals.finished.connect(recu.append)
    t.start()
    QThreadPool.globalInstance().waitForDone(5000)
    boucle = QEventLoop()
    QTimer.singleShot(100, boucle.quit)
    boucle.exec()
    QCoreApplication.sendPostedEvents(None, 0)       # destructions differees
    assert recu == [42]
    assert not shiboken6.isValid(signaux)


# ----------------------------------------------------------------------
# fenetre principale : blocage du lancement, message d'echec honnete
# ----------------------------------------------------------------------
def test_mixin_stockage_bloque_et_decrit_l_etat(app, monkeypatch):
    from PySide6.QtWidgets import QMessageBox, QWidget
    from orion.core.models import Game
    from orion.ui.comptes_mixin import StockageMixin
    from orion.ui.views.storage_view import StorageView

    g = Game(title="Mon Jeu", source="steam", source_id="42", install_dir="C:\\Jeux\\X")

    class Hote(StockageMixin, QWidget):
        def __init__(self):
            super().__init__()
            self.storage_view = StorageView()
            self.library = type("B", (), {"get": staticmethod(lambda uid: g)})()
            self.rafraichi = 0
            self._init_stockage()

        def refresh_storage(self):
            self.rafraichi += 1

    boites = []
    monkeypatch.setattr(QMessageBox, "information", lambda *a: boites.append(("i", a[2])))
    monkeypatch.setattr(QMessageBox, "warning", lambda *a: boites.append(("w", a[2])))
    monkeypatch.setattr(QMessageBox, "critical", lambda *a: boites.append(("c", a[2])))
    h = Hote()
    h._deplacement_en_cours, h._deplacement_uid = True, g.uid
    assert h._lancement_bloque(g) and boites[-1][0] == "i"
    h._deplacement_echec(g.uid, "deplacer", "boom inattendu")
    assert boites[-1][0] == "c" and "Etat du jeu : inconnu" in boites[-1][1]
    assert not h._deplacement_en_cours and not h._lancement_bloque(g)
    h._deplacement_echec(g.uid, "ramener", "copie impossible\n\nEtat du jeu : inchange.")
    assert boites[-1][0] == "w" and "inconnu" not in boites[-1][1]


# ----------------------------------------------------------------------
# page Comptes (2.0) : synthese, tout actualiser, jeux en double
# ----------------------------------------------------------------------
def _profil(pid, pseudo="Joueur"):
    from orion.comptes import Profil
    return Profil(plateforme=pid, id="1", pseudo=pseudo, maj=1_780_000_000)


def _jeu_compte(pid, titre, minutes=0, succes=0, recent=0):
    from orion.comptes import JeuCompte
    return JeuCompte(plateforme=pid, id=titre, titre=titre, minutes=minutes,
                     succes_obtenus=succes, minutes_2sem=recent)


def test_jeux_en_double_entre_plateformes():
    from orion.comptes import doublons
    d = doublons({
        "Steam": ["Hades", "Control", "Portal 2"],
        "GOG": ["HADES", "Control Ultimate Edition", "Gwent"],
        "Epic Games": ["Control", "Hades"],
        "Xbox": [""],
    })
    assert d == [("Control", ["Epic Games", "GOG", "Steam"]),
                 ("Hades", ["Epic Games", "GOG", "Steam"])]
    # le meme jeu deux fois sur la meme plateforme n'est pas un doublon
    assert doublons({"Steam": ["Hades", "Hades"]}) == []
    assert doublons({}) == []


def test_page_comptes_synthese_et_tout_actualiser(app):
    from orion.ui.views.comptes_view import ComptesView, synthese
    v = ComptesView()
    assert v.synthese.isHidden() and v.b_tout.isHidden() and v.doublons.isHidden()
    v.set_compte("steam", _profil("steam"), [
        _jeu_compte("steam", "Hades", minutes=600, succes=10, recent=120),
        _jeu_compte("steam", "Portal 2", minutes=60),
        _jeu_compte("steam", "Jamais Ouvert")])
    assert not v.synthese.isHidden()
    assert v.synthese.text() == ("1 compte connecte · 3 jeux · 11 h de jeu · 10 succes"
                                 " · 1 jamais lances")
    assert "2,0 h ces deux dernieres semaines" in v.cartes["steam"].chiffres.text()
    assert v.b_tout.isHidden()                       # un seul compte : son propre bouton suffit
    v.set_compte("gog", _profil("gog"), [_jeu_compte("gog", "HADES", minutes=30)])
    assert v.synthese.text().startswith("2 comptes connectes · 4 jeux")
    assert not v.b_tout.isHidden() and v.b_tout.isEnabled()
    demandes = []
    v.tout_actualiser.connect(lambda: demandes.append(1))
    v.b_tout.click()
    assert demandes == [1]
    # pendant une actualisation, pas de seconde demande
    v.set_compte("gog", _profil("gog"), [_jeu_compte("gog", "HADES")], occupe=True)
    assert not v.b_tout.isEnabled() and v.b_tout.text() == "Actualisation..."
    v.set_compte("gog", _profil("gog"), [_jeu_compte("gog", "HADES")])
    assert v.b_tout.isEnabled()
    # jeu present sur Steam et GOG
    assert not v.doublons.isHidden()
    assert v.doublons_titre.text() == "1 jeu present sur plusieurs plateformes"
    assert "Hades (GOG, Steam)" in v.doublons_liste.text()
    # un jeu installe depuis une autre plateforme compte aussi
    v.set_bibliotheque({"Epic Games": ["Portal 2"], "Steam": ["Hades"]})
    assert v.doublons_titre.text() == "2 jeux presents sur plusieurs plateformes"
    assert "Portal 2 (Epic Games, Steam)" in v.doublons_liste.text()
    # deconnexion : la synthese et les doublons suivent
    v.set_compte("steam", None, [])
    v.set_compte("gog", None, [])
    assert synthese(v._comptes) == "" and v.synthese.isHidden()
    assert v.doublons.isHidden() and v.b_tout.isHidden()


def test_comptes_plus_de_promesse_datee_dans_les_autres_plateformes():
    from orion.comptes import CATALOGUE_LOCAL
    for _pid, _nom, _nature, texte in CATALOGUE_LOCAL:
        assert "prochaine version" not in texte


def test_les_plateformes_locales_ne_sont_refaites_que_si_les_chiffres_changent(app):
    from PySide6.QtWidgets import QFrame
    from orion.ui.views.comptes_view import ComptesView
    v = ComptesView()
    v.set_locales({"epic": 3})
    lignes = [f for f in v.findChildren(QFrame) if f.objectName() == "PanelFlat"
              and f is not v.doublons and not f.signalsBlocked()]
    v.set_locales({"epic": 3})
    assert [f for f in v.findChildren(QFrame) if f.objectName() == "PanelFlat"
            and f is not v.doublons and not f.signalsBlocked()] == lignes
    v.set_locales({"epic": 4})
    assert [f for f in v.findChildren(QFrame) if f.objectName() == "PanelFlat"
            and f is not v.doublons and not f.signalsBlocked()] != lignes


def test_tout_actualiser_relit_chaque_compte_connecte(app, monkeypatch):
    from orion.ui import comptes_mixin as cm

    class P:
        def __init__(self, oui):
            self._oui = oui

        def connecte(self):
            return self._oui
    monkeypatch.setattr(cm, "PLATEFORMES", {"steam": P(True), "gog": P(False), "xbox": P(True)})

    class H(cm.ComptesMixin):
        def __init__(self):
            self.appels = []

        def actualiser_compte(self, pid, auto=True):
            self.appels.append((pid, auto))
    h = H()
    h.actualiser_tous_les_comptes()
    assert h.appels == [("steam", False), ("xbox", False)]
