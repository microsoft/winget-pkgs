"""Tous les jeux, pas que Steam (2.1.0) : ecrivains XML / KeyValues / texte,
recettes par moteur et par titre, apprentissage d'un fichier inconnu.
Regles : jamais une cle creee, forme de la valeur conservee, sauvegarde
avant, relecture apres."""
from __future__ import annotations

import json
import shutil
from pathlib import Path

import pytest

from orion.core.models import Game
from test_reglages_recommande import _hw

GTA = '''<?xml version="1.0" encoding="UTF-8"?>
<Settings>
  <graphics>
    <ShadowQuality value="2" />
    <TextureQuality value="2" />
    <PostFX value="2" />
  </graphics>
  <video>
    <ScreenWidth value="3840" />
    <ScreenHeight value="2160" />
    <RefreshRate value="60" />
    <Windowed value="1" />
    <VSync value="1" />
  </video>
</Settings>
'''
BG3 = '''<?xml version="1.0" encoding="UTF-8"?>
<save>
    <version major="4" minor="8" revision="0" build="700"/>
    <region id="Config">
        <node id="root">
            <attribute id="Version64" type="int64" value="36169534507319298"/>
            <children>
                <node id="ConfigEntry">
                    <attribute id="MapKey" type="FixedString" value="AntiAliasing"/>
                    <attribute id="Type" type="int32" value="0"/>
                    <attribute id="Value" type="int32" value="0"/>
                </node>
                <node id="ConfigEntry">
                    <attribute id="MapKey" type="FixedString" value="CurrentSettings"/>
                    <attribute id="Type" type="int32" value="4"/>
                    <attribute id="Value" type="LSString" value="Custom"/>
                </node>
                <node id="ConfigEntry">
                    <attribute id="MapKey" type="FixedString" value="HDRGamma"/>
                    <attribute id="Type" type="int32" value="2"/>
                    <attribute id="Value" type="float" value="1.0245117"/>
                </node>
                <node id="ConfigEntry">
                    <attribute id="MapKey" type="FixedString" value="ScreenHeight"/>
                    <attribute id="Type" type="int32" value="0"/>
                    <attribute id="Value" type="int32" value="2036"/>
                </node>
                <node id="ConfigEntry">
                    <attribute id="MapKey" type="FixedString" value="ScreenWidth"/>
                    <attribute id="Type" type="int32" value="0"/>
                    <attribute id="Value" type="int32" value="3620"/>
                </node>
                <node id="ConfigEntry">
                    <attribute id="MapKey" type="FixedString" value="VSync"/>
                    <attribute id="Type" type="int32" value="0"/>
                    <attribute id="Value" type="int32" value="1"/>
                </node>
            </children>
        </node>
    </region>
</save>
'''
FROSTBITE = ("GstRender.FullscreenEnabled 0\r\nGstRender.ResolutionWidth 1280\r\nGstRender.ResolutionHeight 720\r\n"
             "GstRender.OverallGraphicsQuality 3\r\nGstRender.TextureQuality 3\r\nGstRender.ShadowQuality 3\r\n"
             "GstRender.VSyncEnabled 1\r\nGstRender.FrameRateLimit 60.000000\r\nGstInput.MouseSensitivity 0.5\r\n")
MINECRAFT = "version:3700\nfullscreen:false\nmaxFps:60\nenableVsync:true\nrenderDistance:12\ngraphicsMode:2\n"
APEX = ('"VideoConfig"\n{\n\t"setting.defaultres"\t\t"1280"\n\t"setting.defaultresheight"\t\t"720"\n'
        '\t"setting.fullscreen"\t\t"0"\n\t"setting.mat_vsync_mode"\t\t"1"\n\t"setting.shadow_enable"\t\t"1"\n}\n')


def _env(tmp_path, monkeypatch):
    docs = tmp_path / "Documents"
    (docs / "My Games").mkdir(parents=True)
    (tmp_path / "Saved Games").mkdir()
    monkeypatch.setenv("LOCALAPPDATA", str(tmp_path / "local"))
    monkeypatch.setenv("APPDATA", str(tmp_path / "roaming"))
    (tmp_path / "local").mkdir(); (tmp_path / "roaming").mkdir()
    from orion.optimizer import discovery
    monkeypatch.setattr(discovery, "documents_dir", lambda: docs)
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))
    return docs


def _plan(jeu, moteur, hw, ecran):
    plan = moteur.build_plan(jeu, "recommande", hw, ecran)
    assert plan.tunable, plan.advice
    assert not [o for o in plan.ops if "{" in o.value]
    assert all(o.current is not None for o in plan.ops), [o.key for o in plan.ops if o.current is None]
    ok, msg = moteur.apply_plan(jeu, plan)
    assert ok, msg
    return plan


@pytest.fixture
def moteur():
    from orion.optimizer.engine import Optimizer
    return Optimizer()


def test_gta_v_xml_attributs(tmp_path, monkeypatch, moteur):
    docs = _env(tmp_path, monkeypatch)
    f = docs / "Rockstar Games" / "GTA V" / "settings.xml"
    f.parent.mkdir(parents=True); f.write_text(GTA, "utf-8")
    hw, ecran = _hw()
    jeu = Game(title="Grand Theft Auto V", source="dossier", install_dir=str(tmp_path))
    plan = _plan(jeu, moteur, hw, ecran)
    assert plan.confidence == "moteur" and "RAGE" in plan.recipe_name
    t = f.read_text("utf-8")
    assert '<ScreenWidth value="2560" />' in t and '<ScreenHeight value="1440" />' in t
    assert '<RefreshRate value="165" />' in t and '<VSync value="0" />' in t
    assert "<ShadowQuality value=" in t and "<?xml" in t                # mise en forme conservee
    # les cles que ce fichier n'a pas (Reflets, Eau...) ne sont pas inventees
    assert "ReflectionQuality" not in t and any("Non ecrits" in a for a in plan.advice)


def test_baldurs_gate_3_attributs_larian(tmp_path, monkeypatch, moteur):
    _env(tmp_path, monkeypatch)
    f = tmp_path / "local" / "Larian Studios" / "Baldur's Gate 3" / "graphicSettings.lsx"
    f.parent.mkdir(parents=True); f.write_text(BG3, "utf-8")
    hw, ecran = _hw()
    jeu = Game(title="Baldur's Gate 3", source="steam", source_id="1086940", install_dir=str(tmp_path))
    plan = _plan(jeu, moteur, hw, ecran)
    assert plan.confidence == "exact"
    t = f.read_text("utf-8")
    # structure reelle (fichier lu le 9 octobre) : une entree MapKey / Value par option
    assert 'value="ScreenWidth"/>\n                    <attribute id="Type" type="int32" value="0"/>\n                    <attribute id="Value" type="int32" value="2560"/>' in t
    assert 'value="VSync"/>\n                    <attribute id="Type" type="int32" value="0"/>\n                    <attribute id="Value" type="int32" value="0"/>' in t
    assert 'value="AntiAliasing"/>' in t and 'value="1.0245117"' in t       # le reste intact
    # le niveau du jeu : CurrentSettings ecrit seul est retire par le jeu au
    # demarrage (essai du 10 octobre) ; sans apprentissage, ORION ne l'ecrit
    # plus et guide le menu Video
    assert not any("CurrentSettings" in o.key for o in plan.ops)
    assert 'value="Custom"' in t
    assert any("Apprendre les niveaux" in a for a in plan.advice)
    assert not any("config.lsf" in a for a in plan.advice)


def test_frostbite_texte_cle_valeur(tmp_path, monkeypatch, moteur):
    docs = _env(tmp_path, monkeypatch)
    f = docs / "Battlefield 6" / "settings" / "PROFSAVE_profile"
    f.parent.mkdir(parents=True); f.write_bytes(FROSTBITE.encode("utf-8"))
    hw, ecran = _hw()
    jeu = Game(title="Battlefield™ 6", source="ea", install_dir=str(tmp_path))
    plan = _plan(jeu, moteur, hw, ecran)
    assert "Frostbite" in plan.recipe_name
    t = f.read_bytes().decode("utf-8")
    assert "GstRender.ResolutionWidth 2560\r\n" in t and "GstRender.FullscreenEnabled 1\r\n" in t
    assert "GstRender.VSyncEnabled 0\r\n" in t and "GstRender.FrameRateLimit 163\r\n" in t
    assert "GstInput.MouseSensitivity 0.5\r\n" in t                     # le reste intact, CRLF conserve
    assert "GstRender.MeshQuality" not in t                               # absente : pas creee


def test_minecraft_options_txt(tmp_path, monkeypatch, moteur):
    _env(tmp_path, monkeypatch)
    f = tmp_path / "roaming" / ".minecraft" / "options.txt"
    f.parent.mkdir(parents=True); f.write_text(MINECRAFT, "utf-8")
    hw, ecran = _hw()
    jeu = Game(title="Minecraft", source="dossier", install_dir=str(tmp_path))
    _plan(jeu, moteur, hw, ecran)
    t = f.read_text("utf-8")
    assert "fullscreen:true\n" in t and "maxFps:163\n" in t and "enableVsync:false\n" in t
    assert "version:3700\n" in t and t.count("maxFps") == 1


def test_apex_keyvalues(tmp_path, monkeypatch, moteur):
    _env(tmp_path, monkeypatch)
    f = tmp_path / "Saved Games" / "Respawn" / "Apex" / "local" / "videoconfig.txt"
    f.parent.mkdir(parents=True); f.write_text(APEX, "utf-8")
    hw, ecran = _hw()
    jeu = Game(title="Apex Legends", source="steam", source_id="1172470", install_dir=str(tmp_path))
    _plan(jeu, moteur, hw, ecran)
    t = f.read_text("utf-8")
    assert '"setting.defaultres"\t\t"2560"' in t and '"setting.fullscreen"\t\t"1"' in t
    assert '"setting.mat_vsync_mode"\t\t"0"' in t and "r_lod_switch_scale" not in t


def test_moteur_inconnu_apprend_les_cles_sures(tmp_path, monkeypatch, moteur):
    """Un jeu sans recette : ORION trouve son fichier et ne touche qu'aux
    cles sures, dans la forme du fichier ; les niveaux restent au guide."""
    docs = _env(tmp_path, monkeypatch)
    f = docs / "My Games" / "Jeu Maison" / "settings.ini"
    f.parent.mkdir(parents=True)
    f.write_text("[Video]\nScreenWidth=1280\nScreenHeight=720\nFullscreen=false\nVSync=true\n"
                 "MaxFPS=60\nShadowLevel=3\n[Audio]\nVolume=0.8\n", "utf-8")
    hw, ecran = _hw()
    jeu = Game(title="Jeu Maison", source="dossier", install_dir=str(tmp_path / "jeu"))
    (tmp_path / "jeu").mkdir()
    plan = _plan(jeu, moteur, hw, ecran)
    assert plan.confidence == "appris" and "settings.ini" in plan.recipe_name
    t = f.read_text("utf-8")
    assert "ScreenWidth=2560\n" in t and "ScreenHeight=1440\n" in t
    assert "Fullscreen=true\n" in t and "VSync=false\n" in t and "MaxFPS=163\n" in t
    assert "ShadowLevel=3\n" in t and "Volume=0.8\n" in t                  # jamais touche
    assert plan.guide, "les niveaux de qualite restent au guide"
    # un fichier sans cle sure : rien d'appris, pas d'invention
    g = docs / "My Games" / "Autre Jeu" / "config.ini"
    g.parent.mkdir(parents=True); g.write_text("[Misc]\nSeed=42\n", "utf-8")
    autre = Game(title="Autre Jeu", source="dossier", install_dir=str(tmp_path / "autre"))
    (tmp_path / "autre").mkdir()
    plan2 = moteur.build_plan(autre, "recommande", hw, ecran)
    assert not plan2.tunable and g.read_text("utf-8") == "[Misc]\nSeed=42\n"


def test_valeur_d_une_autre_forme_jamais_ecrite():
    from orion.optimizer.apprentissage import _type_valeur, _valeur
    s = {"resolution_w": 2560, "resolution_h": 1440, "fps_cap": 163, "window_mode": "fullscreen", "vsync": False}
    assert _valeur("plein_ecran", _type_valeur("false"), "false", s) == "true"
    assert _valeur("plein_ecran", _type_valeur("False"), "False", s) == "True"
    assert _valeur("plein_ecran", _type_valeur("0"), "0", s) == "1"
    assert _valeur("plein_ecran", _type_valeur("2"), "2", s) is None       # un mode 0/1/2 : trop ambigu
    assert _valeur("limite", _type_valeur("60.000000"), "60.000000", s) == "163.000000"
    assert _valeur("limite", _type_valeur("unlimited"), "unlimited", s) is None
    assert _valeur("largeur", _type_valeur("1920"), "1920", s) == "2560"


def test_recettes_livrees_ne_creent_jamais_de_cle():
    dossier = Path(__file__).resolve().parents[1] / "orion" / "plugins" / "tweaks" / "recipes"
    for nom in ("rage", "dunia", "elden_ring", "baldurs_gate_3", "frostbite", "creation", "minecraft", "respawn", "witcher_3"):
        d = json.loads((dossier / f"{nom}.json").read_text("utf-8"))
        assert d.get("creer_cles") is False, nom
        assert all(t["format"] in ("xml", "keyvalues", "texte", "ini") for t in d["targets"]), nom


def test_moteurs_rage_et_re_detectes(tmp_path):
    from orion.plugins.scanners.base import detect_engine
    gta = tmp_path / "gta"; gta.mkdir()
    (gta / "GTA5.exe").write_bytes(b"x"); (gta / "x64a.rpf").write_bytes(b"x")
    assert detect_engine(gta) == "rage"
    re_ = tmp_path / "re"; re_.mkdir()
    (re_ / "re_chunk_000.pak").write_bytes(b"x")
    assert detect_engine(re_) == "re"
    shutil.rmtree(gta)


def test_noms_unity_calcules_et_jamais_crees():
    """9 octobre (Aniimo) : les empreintes des noms Unity etaient recopiees a
    la main, et fausses : ORION ecrivait sous un nom que le jeu ne lit pas."""
    import json
    from pathlib import Path
    from orion.optimizer.engine import cle_unity
    assert cle_unity("UnityGraphicsQuality") == "UnityGraphicsQuality_h1669003810"
    assert cle_unity("Screenmanager Resolution Width") == "Screenmanager Resolution Width_h182942802"
    assert cle_unity("Screenmanager Fullscreen mode") == "Screenmanager Fullscreen mode_h3630240806"
    assert cle_unity("CBT2_targetFramerate") == "CBT2_targetFramerate_h63342163"
    import orion.plugins.tweaks as tw
    d = json.loads((Path(tw.__file__).parent / "recipes" / "unity_generic.json").read_text("utf-8"))
    assert d["targets"][0]["unity_prefs"] is True and d["creer_cles"] is False
    assert all("_h" not in e["key"] for e in d["targets"][0]["entries"])


def test_recette_aniimo_valeurs_lues_sur_le_pc():
    """Aniimo (Unity) : ses propres options CBT2_*, noms calcules ; Basse =
    Performances (1), Moyenne = Faible (2), Haute et Ultra = Haut (4), chaque
    fois avec toutes les options du niveau ; limite d'images en clair,
    « Inactif » = -1 (0xFFFFFFFF)."""
    from orion.core.models import Game
    from orion.optimizer.engine import _apply_derive, select_recipe
    r = select_recipe(Game(title="Aniimo", source="steam"))
    assert r.id == "aniimo" and r.creer_cles is False
    d = r.derive if hasattr(r, "derive") else r.data["derive"]
    # niveau ET chacune de ses options, valeurs relevees dans le jeu (le menu
    # les ecrit toutes ; le niveau seul ne change rien au demarrage)
    assert _apply_derive(d, {"quality": 0, "fps_cap": 120, "upscaler": "dlss_balanced"}) == {
        "aniimo_niveau": "1", "aniimo_gi": "1", "aniimo_ombres": "1", "aniimo_reflets": "2",
        "aniimo_occlusion": "3", "aniimo_animations": "2", "aniimo_fps": "120",
        "aniimo_aa": "DeepLearningSuperSampling", "aniimo_dlss": "2"}
    assert _apply_derive(d, {"quality": 3, "fps_cap": 0, "upscaler": "off"}) == {
        "aniimo_niveau": "4", "aniimo_gi": "4", "aniimo_ombres": "3", "aniimo_reflets": "0",
        "aniimo_occlusion": "0", "aniimo_animations": "3", "aniimo_fps": "4294967295",
        "aniimo_aa": "TemporalAntialiasing", "aniimo_dlss": "1"}
    # FSR : nom inconnu dans Aniimo, l'anticrenelage n'est pas touche
    assert "aniimo_aa" not in _apply_derive(d, {"quality": 3, "fps_cap": 0, "upscaler": "fsr_quality"})
    # Moyenne : le niveau Faible complet (le Moyen du jeu n'est pas encore
    # releve) ; jamais un niveau seul sans ses options
    moy = _apply_derive(d, {"quality": 1, "fps_cap": 60})
    assert moy["aniimo_niveau"] == "2" and moy["aniimo_reflets"] == "1" and len(moy) == 7
    assert "upscaler" in r.capacites


def test_texte_binaire_unity():
    """Aniimo range son anticrenelage en texte binaire termine par un zero :
    ORION le lit comme du texte et le reecrit sous la meme forme."""
    from orion.plugins.tweaks.registry_writer import texte_binaire
    assert texte_binaire(bytes.fromhex("446565704C6561726E696E67537570657253616D706C696E6700")) == "DeepLearningSuperSampling"
    assert texte_binaire(b"None\x00") == "None"
    assert texte_binaire(b"\x01\x02\xff") == "0102ff"
