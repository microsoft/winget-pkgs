"""Objectif de l'editeur et jeux bloques (13 octobre 2026).

Monster Hunter Wilds recommande « 1080p/60 fps (avec Frame Generation
activé) avec les paramètres graphiques sur "Moyen" » : ORION lisait 60 fps
en reglages eleves et annoncait une RTX 4060 « Élevés, 62–86 i/s », deux
fois trop. Elden Ring ne depasse jamais 60 i/s : le site annoncait 121.
"""
import sys
from dataclasses import asdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "service" / "site"))

from orion.puissance import exigences as X  # noqa: E402
from orion.puissance.estimation import Machine, estimer  # noqa: E402
from orion.puissance.exigences import Exigences, lire_config  # noqa: E402

TETE = ("Recommandée :\nSystème d'exploitation : Windows 11\nProcesseur : Intel Core i5-10400 or AMD Ryzen 5 3600\n"
        "Mémoire vive : 16 GB de mémoire\nGraphiques : NVIDIA GeForce RTX 2060 Super(VRAM 8GB) or AMD Radeon RX 6600"
        "(VRAM 8GB)\nDirectX : Version 12\nEspace disque : 75 GB d'espace disque disponible\n")
WILDS_REC = TETE + ("Notes supplémentaires : SSD requis. Performances visées : 1080p/60 fps (avec Frame Generation "
                    "activé) avec les paramètres graphiques sur \"Moyen\". DirectStorage pris en charge.")
WILDS_MIN = TETE + ("Notes supplémentaires : SSD requis. Performances visées : 1080p (upscalé depuis une résolution "
                    "native 720p) / 30 fps avec les paramètres graphiques sur \"Très bas\". DirectStorage pris en charge.")
RONIN = TETE + ("Notes supplémentaires : SSD required. This game is expected to run at 1080p/60FPS under the standard "
                "graphics settings (upscaled). Frame Generation can be used to increase FPS.")
STELLAR = TETE + "Notes supplémentaires : 1080P. Graphics Quality Preset “Low”. 60FPS Target. HDD Supported."
SILENT = TETE + ("Notes supplémentaires : Playing on recommended requirements should enable to play on Medium quality "
                 "settings in 60 FPS or High quality settings in 30 FPS, in FullHD (or 4k using DLSS or similar "
                 "technology). SSD is recommended.")
STALKER = TETE + ("Notes supplémentaires : Graphics Preset: HIGH / Resolution: 1440p / Target FPS: 30. SSD required. "
                  "The above specifications were tested with TSR, DLSS, FSR and XeSS.")
NIOH = TETE + ("Notes supplémentaires : Jouable en 1080p à 60 ips en utilisant le préréglage graphique standard (avec "
               "upscaling). Génération d'images additionnelles prise en charge.")
ROME = TETE + ("Notes supplémentaires : * Les chipsets graphiques intégrés des PC nécessitent 8 Go de RAM, par exemple "
               ": Série Intel HD/UHD\n* Performances estimées en configuration Élevé à 1080p : 60 FPS")
SANS_NOTE = TETE


def test_l_objectif_complet_est_lu():
    rec, mini = lire_config(WILDS_REC), lire_config(WILDS_MIN)
    assert (rec.cible_fps, rec.cible_px, rec.cible_niveau, rec.generation_images, rec.rendu_px) == \
        (60, 1920 * 1080, "moyenne", True, None)
    assert (mini.cible_fps, mini.cible_niveau, mini.generation_images, mini.rendu_px) == \
        (30, "basse", False, 1280 * 720)
    ronin = lire_config(RONIN)                         # « can be used » : pas l'objectif
    assert not ronin.generation_images and ronin.cible_niveau == "moyenne"
    assert ronin.rendu_px == round(1920 * 1080 * 4 / 9)
    stellar = lire_config(STELLAR)                     # l'objectif en trois phrases courtes
    assert (stellar.cible_fps, stellar.cible_niveau) == (60, "basse")
    silent = lire_config(SILENT)                       # la seconde possibilite ne compte pas
    assert (silent.cible_fps, silent.cible_niveau, silent.cible_px, silent.rendu_px) == \
        (60, "moyenne", 1920 * 1080, None)
    stalker = lire_config(STALKER)
    assert (stalker.cible_fps, stalker.cible_niveau, stalker.cible_px) == (30, "haute", 2560 * 1440)
    assert stalker.rendu_px == round(2560 * 1440 * 4 / 9)
    nioh = lire_config(NIOH)
    assert (nioh.cible_fps, nioh.cible_niveau, nioh.generation_images) == (60, "moyenne", False)
    rome = lire_config(ROME)                           # « Intel HD/UHD » n'est pas un objectif 4K
    assert (rome.cible_fps, rome.cible_px, rome.cible_niveau) == (60, 1920 * 1080, "haute")
    nu = lire_config(SANS_NOTE)
    assert (nu.cible_niveau, nu.generation_images, nu.rendu_px) == (None, False, None)


def _exig(rec_texte, appid="1"):
    return Exigences(appid=appid, titre="Jeu", minimum=lire_config(WILDS_MIN), recommandee=lire_config(rec_texte))


RTX_4060 = Machine(gpu=31.0, gpu_nom="NVIDIA GeForce RTX 4060", cpu=80.0, cpu_nom="Ryzen 5 7600", vram_go=8.0,
                   ram_go=32.0)


def test_generation_d_images_et_reglages_moyens_divisent_l_estimation():
    avant = estimer("Jeu", _exig(SANS_NOTE), RTX_4060)
    wilds = estimer("Jeu", _exig(WILDS_REC), RTX_4060)
    assert avant.niveau == "haute"
    rapport = wilds.fps["haute"][1] / avant.fps["haute"][1]
    assert 0.42 <= rapport <= 0.48                     # 1 / (1,7 x 1,3)
    assert wilds.niveau == "basse" and wilds.fps["haute"][1] < 45      # plus jamais « Élevés, 62–86 »


def test_l_explication_le_dit():
    from orion.puissance import lecture
    exig = _exig(WILDS_REC)
    x = lecture.expliquer("Jeu", estimer("Jeu", exig, RTX_4060), exig, RTX_4060)
    assert "vaut pour des reglages Moyenne" in x.contexte and lecture.SUPPOSE_GENERATION in x.contexte


def test_jeu_bloque_a_60_images():
    import reglages
    elden = estimer("Elden Ring", _exig(SANS_NOTE, appid="1245620"), RTX_4060)
    assert all(h <= 60 for _b, h in elden.fps.values())
    assert elden.niveau == "haute" and elden.fps["haute"] == (60, 60)
    assert "Le jeu est limite a 60 images par seconde." in elden.notes
    assert reglages.fourchette(60, 60, "fr") == "60 i/s"
    assert reglages.fourchette(60, 60, "fr", "long") == "60 images par seconde"


def test_une_fiche_abregee_avant_ses_notes_est_relue_sur_steam(base_neuve):
    from orion.core.base import Table
    abregee = Exigences("9", "Jeu", None, lire_config(WILDS_REC), lu_le=9e9)
    memo = asdict(abregee)
    # avant la regle 4 : texte garde coupe a 600 caracteres, notes perdues
    memo["recommandee"]["texte"] = ("Configuration longue\n" * 40)[:X.ANCIEN_TEXTE]
    for champ in ("generation_images", "cible_niveau", "rendu_px"):
        memo["recommandee"].pop(champ)                 # ecrite par une version d'avant
    Table("exigences").set("9", dict(memo, regle=3))
    assert X.perimee(Table("exigences").get("9")) and X.a_relire("9")
    assert X.en_cache("9") is not None                 # sert en attendant
    assert Table("exigences").get("9")["regle"] == 3   # mais reste a relire
    complete = dict(asdict(abregee), regle=X.REGLE)
    Table("exigences").set("9", complete)
    assert not X.a_relire("9") and X.en_cache("9").recommandee.generation_images
    courte = dict(asdict(Exigences("8", "Court", None, lire_config(SANS_NOTE), lu_le=1.0)), regle=3)
    assert not X.perimee(courte)                       # texte entier : relu sans reseau


def test_un_champ_inconnu_ne_casse_pas_la_lecture(base_neuve):
    from orion.core.base import Table
    memo = dict(asdict(Exigences("5", "Jeu", None, lire_config(SANS_NOTE), lu_le=9e9)), regle=X.REGLE)
    memo["recommandee"]["champ_futur"] = 1
    Table("exigences").set("5", memo)
    assert X.en_cache("5").recommandee.gpu


def test_la_fiche_du_site_explique_l_objectif():
    import gen_jeux
    exig = _exig(WILDS_REC, appid="2246340")
    texte = gen_jeux.objectif_editeur({"exig": exig, "nom": "Monster Hunter Wilds", "appid": "2246340"})
    assert "des réglages moyens et la génération d'images" in texte
    elden = gen_jeux.objectif_editeur({"exig": _exig(SANS_NOTE), "nom": "Elden Ring", "appid": "1245620"})
    assert elden.startswith("Elden Ring est limité à 60 images par seconde")
