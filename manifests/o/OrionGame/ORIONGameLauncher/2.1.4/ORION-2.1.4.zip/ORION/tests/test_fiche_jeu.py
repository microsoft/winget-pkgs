"""Fiche d'un jeu de la bibliotheque (1.9) et valeur du catalogue possede.

Fiche : plus d'achat ni de marche gris (le jeu est possede), panneau Infos,
succes compacts, captures puis videos, rien du jeu precedent ne survit.
Valeur : prix actuels hors promotion, gratuits a 0, couverture honnete."""
from __future__ import annotations

import time

import pytest

from orion.core.models import Game, HardwareInfo
from orion.plugins.market.base import MarketInfo, Offer


@pytest.fixture(scope="module")
def app():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


def _jeu(uid: str, titre: str = "", source: str = "manuel", source_id: str = "",
         **kw) -> Game:
    return Game(title=titre or uid, source=source, source_id=source_id or uid, uid=uid, **kw)


def _succes(n: int, obtenus: int):
    from orion.comptes.base import Succes
    return [Succes(id=str(i), nom=f"S{i}", obtenu=i < obtenus, rarete=90 - i * 2.0,
                   date=time.time() - i) for i in range(n)]


def _info(uid: str, **kw) -> MarketInfo:
    base = dict(game_uid=uid, title=uid, developer="Studio A", publisher="Editeur B",
                release_date="1 janv. 2020", genres=["Action", "RPG"], review_score=91,
                review_count=1200, review_label="Tres positives", metacritic=88,
                current=Offer("Steam", 19.99), best=Offer("Boutique X", 9.99, url="https://x"),
                offers=[Offer("Boutique X", 9.99)],
                screenshots=[{"thumb": "", "full": "", "local": ""}],
                news=[{"title": "Maj", "body": "texte"}])
    base.update(kw)
    return MarketInfo(**base)


def _textes(layout) -> list[str]:
    out = []
    for i in range(layout.count()):
        w = layout.itemAt(i).widget()
        if w is not None and hasattr(w, "text"):
            out.append(w.text())
    return out


# ---------------------------------------------------------------------------
# fiche
# ---------------------------------------------------------------------------
def test_fiche_sans_achat_ni_marche_gris(app):
    from orion.ui.views.detail_view import DetailView
    v = DetailView()
    v.set_game(_jeu("a", source="steam", source_id="620"), HardwareInfo())
    v.set_market(_info("a"))
    for attr in ("buy_btn", "deals_btn", "offers_table", "gris_panel"):
        assert not hasattr(v, attr), attr
    textes = " ".join(_textes(v.infos_grid))
    assert "Studio A" in textes and "Editeur B" in textes and "1 janv. 2020" in textes
    assert "91 % positifs" in textes and "88 / 100" in textes
    assert "EUR" not in textes and "9.99" not in textes       # aucun prix
    # le lien vers la boutique reste
    assert v.store_btn.text() == "Boutique" and not v.store_btn.isHidden()


def test_infos_resument_les_succes(app):
    from orion.ui.views.detail_view import DetailView
    v = DetailView()
    v.set_game(_jeu("a"), HardwareInfo())
    v.set_market(_info("a"))
    v.succes.definir(_succes(10, 4), "Steam")
    assert "4/10 · 40 %" in " ".join(_textes(v.infos_grid))
    # succes compacts : resume, barre, six succes a viser, « Voir tout »
    assert v.succes.grille.count() == 6
    assert v.succes.b_tout.text() == "Voir tout (10)"
    v.succes.deplier(True)
    assert v.succes.grille.count() == 0 and v.succes.lignes.count() == 6   # 6 manquants
    v.succes.deplier(False)
    assert v.succes.grille.count() == 6


def test_changer_de_jeu_vide_tous_les_panneaux(app):
    from orion.ui.views.detail_view import DetailView
    v = DetailView()
    v.set_game(_jeu("a", source="steam", source_id="620"), HardwareInfo())
    v.set_market(_info("a"))
    v.succes.definir(_succes(5, 5), "Steam")
    v.set_joueurs("12 joueurs")
    assert v.infos_grid.count() > 0 and not v.news_panel.isHidden()

    v.set_game(_jeu("b"), HardwareInfo())
    assert v.market is None
    assert v.infos_grid.count() == 0
    assert v.news_panel.isHidden() and v.shots_panel.isHidden()
    assert v.succes.isHidden() and v._resume_succes == {}
    assert v.en_ligne.isHidden()
    assert v.lecteur.game.uid == "b" and v.lecteur.appid == "" and not v.lecteur.films
    assert v.plan is None


def test_ordre_de_la_fiche(app):
    """Le jeu (bandeau + infos + succes), puis les captures, puis les videos."""
    from orion.ui.views.detail_view import DetailView
    v = DetailView()
    ordre = []
    for i in range(v.root.count()):
        item = v.root.itemAt(i)
        w = item.widget()
        if w is None and item.layout() is not None:
            for j in range(item.layout().count()):
                ww = item.layout().itemAt(j).widget()
                if ww in (v.hero, v.infos_panel):
                    ordre.append(ww)
        elif w is not None:
            ordre.append(w)
    pos = {id(w): k for k, w in enumerate(ordre)}
    assert pos[id(v.hero)] < pos[id(v.infos_panel)] < pos[id(v.succes)] \
        < pos[id(v.shots_panel)] < pos[id(v.lecteur)] < pos[id(v.news_panel)]


def test_lecteur_onglets_et_sans_moteur_web(app, monkeypatch):
    from orion.ui.widgets import lecteur_video as lv
    assert [t for _, t in lv.ONGLETS] == ["Bande-annonce", "Gameplay (FR)", "En direct"]
    assert not lv.web_disponible()             # tests hors ecran : pas de Chromium
    ouverts = []
    monkeypatch.setattr(lv, "ouvrir_externe", ouverts.append)
    l = lv.LecteurVideo()
    l.definir_jeu(_jeu("a", "Hades II"))
    assert l.onglet == lv.GAMEPLAY and l.vue is None
    l._lancer()                                 # sans moteur web : le navigateur
    assert ouverts and "youtube.com/results" in ouverts[-1]
    assert "gameplay+fr" in ouverts[-1]
    l.choisir_onglet(lv.DIRECT, par_joueur=True)
    l._lancer()
    assert "sp=EgJAAQ" in ouverts[-1]          # filtre « en direct »
    textes = [l.actions.itemAt(i).widget().text() for i in range(l.actions.count())]
    assert "Voir sur Twitch" in textes and "Ouvrir sur YouTube" in textes
    assert l.vue is None                       # jamais de moteur web cree


def test_lecteur_ne_charge_rien_avant_d_etre_visible(app, monkeypatch):
    from orion.ui.widgets import lecteur_video as lv
    appels = []
    monkeypatch.setattr(lv.LecteurVideo, "_films_et_miniatures",
                        staticmethod(lambda appid: appels.append(appid) or ([], {})))
    l = lv.LecteurVideo()
    l.definir_jeu(_jeu("a", source="steam", source_id="620"), "620")
    assert not l._actif and l._films_pour is None
    l.activer()
    assert l._films_pour == "620"
    # autre jeu : tout est oublie, rien n'est demande tant qu'il n'est pas vu
    l.definir_jeu(_jeu("b"), "")
    assert not l._actif and l._films_pour is None and l.films == []


def test_video_retenue_affichee_avec_titre_et_chaine(app, monkeypatch):
    from orion import videos
    from orion.ui.widgets import lecteur_video as lv
    monkeypatch.setattr(lv.LecteurVideo, "_infos_youtube", lambda *a, **k: None)
    videos.retenir_video("zz", "dQw4w9WgXcQ", "Gameplay FR partie 1", "Chaine FR")
    l = lv.LecteurVideo()
    l.definir_jeu(_jeu("zz", "Jeu"))
    assert l.c_titre.text() == "Gameplay FR partie 1"
    assert l.c_source.text().startswith("Chaine FR")
    assert l.url_externe() == "https://www.youtube.com/watch?v=dQw4w9WgXcQ"


# ---------------------------------------------------------------------------
# valeur de la bibliotheque
# ---------------------------------------------------------------------------
def test_valeur_releve_boutique_et_gratuits(monkeypatch):
    from orion import valeur_catalogue as vc
    jeux = [
        _jeu("a", "Alpha", source="steam", source_id="10"),
        _jeu("b", "Beta", source="epic", source_id="x"),
        _jeu("c", "Gamma", source="steam", source_id="30"),
        _jeu("d", "Delta", source="gog", source_id="d"),         # aucun prix
        _jeu("a2", "Alpha", source="steam", source_id="10"),     # doublon
        _jeu("h", "Cache", source="steam", source_id="50", hidden=True),
    ]
    releves = {"a": {"base_price": 29.99, "current": {"price": 14.99, "cut": 50}},
               "b": {"free": True}}

    class Fiche:
        def __init__(self, titre, appid, normal, prix):
            self.titre, self.steam_appid = titre, appid
            self.prix_normal, self.gratuit = normal, prix == 0
            self.meilleure = type("O", (), {"prix": prix})()

    instantane = vc.preparer(jeux, releves, [Fiche("Gamma", "30", 20.0, 10.0)])
    assert len(instantane) == 4                       # doublon et jeu cache ignores
    monkeypatch.setattr(vc, "_prix_steam", lambda *a, **k: pytest.fail("reseau"))
    v = vc.estimer(instantane)
    assert v.jeux == 4 and v.estimes == 3 and v.gratuits == 1
    assert v.total == pytest.approx(49.99) and v.actuel == pytest.approx(24.99)
    assert "49 EUR" not in v.texte() and "50 EUR" in v.texte()
    assert "3 jeux sur 4 estimes" in v.texte()
    assert "hors promotion" in v.texte()


def test_valeur_prix_steam_groupes_et_gardes(monkeypatch):
    from orion import valeur_catalogue as vc
    from orion.core import reseau, steam_limite
    monkeypatch.setattr(steam_limite, "en_pause", lambda: False)
    demandes = []

    class Rep:
        status_code = 200

        def __init__(self, data):
            self._d = data

        def json(self):
            return self._d

    def get(url, params=None, **kw):
        ids = params["appids"].split(",")
        demandes.append(ids)
        assert params["filters"] == "price_overview"
        d = {}
        for a in ids:
            if a == "71":
                d[a] = {"success": True, "data": {"price_overview": {
                    "currency": "EUR", "initial": 3999, "final": 999}}}
            elif a == "72":
                d[a] = {"success": True, "data": []}       # gratuit
            else:
                d[a] = {"success": False}                  # retire de la vente
        return Rep(d)

    monkeypatch.setattr(reseau, "get", get)
    jeux = [_jeu(f"s{a}", f"Jeu {a}", source="steam", source_id=a) for a in ("71", "72", "73")]
    v = vc.estimer(vc.preparer(jeux))
    assert demandes == [["71", "72", "73"]]                # un seul appel groupe
    assert v.estimes == 2 and v.gratuits == 1 and v.jeux == 3
    assert v.total == pytest.approx(39.99) and v.actuel == pytest.approx(9.99)
    # deuxieme calcul : tout vient de la memoire, aucun appel
    vc.estimer(vc.preparer(jeux))
    assert len(demandes) == 1


def test_valeur_affichee_dans_l_en_tete(app):
    from orion.ui.views.library_view import LibraryView
    from orion.valeur_catalogue import Valeur
    lv = LibraryView()
    assert lv.valeur.isHidden()
    lv.set_valeur(Valeur(total=1234.4, estimes=312, jeux=340, gratuits=12))
    assert not lv.valeur.isHidden()
    texte = lv.valeur.text()
    # 2.1.1 : un bouton « Valeur estimee de ma bibliotheque » qui ouvre la liste
    assert "Valeur estimee de ma bibliotheque" in texte and "1 234" in texte and "312 jeux sur 340" in texte
    assert "gratuits" in lv.valeur.toolTip() and "hors promotion" in lv.valeur.toolTip()
    lv.set_valeur(Valeur())                                # rien de connu
    assert lv.valeur.isHidden()


def test_en_tete_previent_quand_la_liste_change(app):
    from orion.ui.views.library_view import LibraryView
    lv = LibraryView()
    recus = []
    lv.contenu_change.connect(lambda: recus.append(1))
    lv.set_games([_jeu("a")])
    lv.set_possedes([_jeu("b")])
    assert len(recus) == 2


class _FauxSignal:
    def connect(self, *_a):
        pass


class _FaussePage:
    intercepter = False


class _FausseVue:
    def __init__(self):
        self.pages = []

    def page(self):
        return _FaussePage()

    def setHtml(self, page, _url):
        self.pages.append(page)

    def stop(self):
        pass


def _attendre(app, ms: int) -> None:
    """Laisse tourner la boucle Qt `ms` millisecondes (minuteurs compris)."""
    import time
    fin = time.monotonic() + ms / 1000
    while time.monotonic() < fin:
        app.processEvents()
        time.sleep(0.01)


def _lecteur_auto(monkeypatch, appid="1145350"):
    from orion.ui.widgets import lecteur_video as lv
    monkeypatch.setattr(lv, "web_disponible", lambda: True)
    l = lv.LecteurVideo()
    vue = _FausseVue()
    monkeypatch.setattr(l, "_charger_films", lambda: None)
    monkeypatch.setattr(l, "_vue", lambda: vue)
    l.vue = vue
    l.definir_jeu(_jeu("b", "Hades II"), appid)
    return lv, l, vue


def _film(**plus):
    from orion import videos
    base = dict(id="1", nom="Trailer", miniature="", dash_av1="", dash_h264="",
                hls_h264="", webm="https://x/a.webm", mp4="", vedette=True, appid="1145350")
    base.update(plus)
    return videos.BandeAnnonce(**base)


def test_bande_annonce_en_tete_et_lecture_auto(app, monkeypatch):
    """Jeu Steam : l'onglet Bande-annonce s'ouvre ; la video se charge
    derriere l'affiche et ne la remplace qu'a la premiere image."""
    lv, l, vue = _lecteur_auto(monkeypatch)
    assert l.onglet == lv.BANDE and not [p for p in vue.pages if "<video" in p]
    l.activer()
    l._films_lus("1145350", ([_film()], {}))
    # 15/10 : la lecture part un peu apres, une fois la fiche posee (le
    # `setHtml` du navigateur fige la fenetre), jamais pendant sa construction
    assert not [p for p in vue.pages if "<video" in p]
    _attendre(app, lv.DELAI_AVANT_AUTO + 100)
    videos_chargees = [p for p in vue.pages if "<video" in p]
    assert len(videos_chargees) == 1
    assert " muted" in videos_chargees[0] and " autoplay" in videos_chargees[0]
    assert "ORION-LECTURE" in videos_chargees[0] and "ORION-ECHEC" in videos_chargees[0]
    assert not l.lecture                                 # l'affiche est encore a l'ecran
    l._signal_page("ORION-LECTURE")                      # premiere image
    assert l.lecture and l.ecran.currentWidget() is l.support
    l.arreter()
    l._films_lus("1145350", ([_film()], {}))             # arretee : ne repart pas
    _attendre(app, lv.DELAI_AVANT_AUTO + 100)
    assert len([p for p in vue.pages if "<video" in p]) == 1


def test_bande_annonce_illisible_laisse_l_affiche(app, monkeypatch):
    """La lecture echoue : jamais d'ecran noir, l'affiche reste."""
    lv, l, vue = _lecteur_auto(monkeypatch)
    l.activer()
    l._films_lus("1145350", ([_film()], {}))
    _attendre(app, lv.DELAI_AVANT_AUTO + 100)
    l._signal_page("ORION-ECHEC")
    assert not l.lecture and l.ecran.currentWidget() is l.affiche


def test_jeu_sans_bande_annonce_montre_le_gameplay(app, monkeypatch):
    lv, l, vue = _lecteur_auto(monkeypatch)
    l.activer()
    l._films_lus("1145350", ([], {}))
    assert l.onglet == lv.GAMEPLAY and not l.lecture


def test_fiche_steam_tardive_ne_fait_pas_sauter_l_onglet(app, monkeypatch):
    """Jeu hors Steam deja affiche sur « Gameplay » : si son identifiant Steam
    arrive apres coup, l'onglet ne change pas sous les yeux du joueur."""
    lv, l, vue = _lecteur_auto(monkeypatch, appid="")
    assert l.onglet == lv.GAMEPLAY
    l.activer()
    l.definir_appid("1145350")
    assert l.onglet == lv.GAMEPLAY
    # pas encore montree : la bande-annonce peut passer en tete
    lv2, l2, _ = _lecteur_auto(monkeypatch, appid="")
    l2.definir_appid("1145350")
    assert l2.onglet == lv2.BANDE


def test_jeu_hors_steam_attend_sa_fiche_puis_montre_la_bande_annonce(app, monkeypatch):
    """Jeu Battle.net dont la fiche Steam est en cours de recherche : on
    patiente sur l'onglet Bande-annonce, sans passer par le gameplay."""
    from orion.ui.widgets import lecteur_video as lv
    monkeypatch.setattr(lv, "web_disponible", lambda: True)
    l = lv.LecteurVideo()
    vue = _FausseVue()
    monkeypatch.setattr(l, "_charger_films", lambda: None)
    monkeypatch.setattr(l, "_vue", lambda: vue)
    l.definir_jeu(_jeu("c", "Diablo II Resurrected"), "", en_recherche=True)
    assert l.onglet == lv.BANDE and l._attente_fiche
    l.activer()
    l.definir_appid("", cherche=False)              # releve pas encore fini
    assert l.onglet == lv.BANDE
    l.definir_appid("2536520")                       # la fiche arrive
    assert l.onglet == lv.BANDE and l.appid == "2536520" and not l._attente_fiche
    # autre jeu : recherche finie sans fiche Steam -> gameplay
    l.definir_jeu(_jeu("d", "Aniimo"), "", en_recherche=True)
    l.definir_appid("", cherche=True)
    assert l.onglet == lv.GAMEPLAY and not l._attente_fiche
    # trop long : gameplay, la bande-annonce arrivera dans son onglet
    j = _jeu("e", "Dofus Retro")
    l.definir_jeu(j, "", en_recherche=True)
    l._fiche_trop_longue(j)
    assert l.onglet == lv.GAMEPLAY


def test_identifiant_steam_repris_des_visuels(monkeypatch):
    from orion.core.models import normalize_title
    from orion.plugins.artwork import steam_cdn
    monkeypatch.setattr(steam_cdn, "_load_resolved",
                        lambda: {"__v__": 3, normalize_title("Grand Theft Auto V Enhanced"): 3240220,
                                 "__misses__": {"x": 1}})
    assert steam_cdn.appid_deja_trouve("Grand Theft Auto V Enhanced") == "3240220"
    assert steam_cdn.appid_deja_trouve("Jeu inconnu") == ""
    assert steam_cdn.appid_deja_trouve("") == ""


def test_les_cartes_ne_sont_ancrees_qu_apres_un_clic(app, monkeypatch):
    """15 octobre (video de l'auteur, 0:05) : a l'ouverture d'une fiche, le
    plan arrivait avant les captures et les videos ; les cartes, ancrees en
    haut d'une page encore courte, entrainaient la page jusqu'a elles des que
    les panneaux du dessus se remplissaient. L'ancrage ne sert qu'apres un
    clic sur une carte."""
    from orion.ui.views.detail_view import DetailView
    v = DetailView()
    v.resize(900, 700)
    v.show()
    v.set_game(_jeu("a", "Hades II"), HardwareInfo())
    app.processEvents()
    v._haut_jeton = None                        # le joueur a fait defiler lui-meme
    mesures = []
    original = v.__class__._ancrer

    def ancrer(self):
        mesures.append(self._ancrer_apres_clic)
        original(self)
    monkeypatch.setattr(v.__class__, "_ancrer", ancrer)
    v.set_graphismes({})                        # le plan arrive : la fiche se construit
    assert mesures == [False] and getattr(v, "_ancre_jeton", None) is None
    v._choix_fait("eleve", 60)                  # clic sur une carte
    v.set_graphismes({})
    assert mesures == [False, True] and v._ancrer_apres_clic is False     # consomme
    v.set_graphismes({})                        # un second plan, sans clic : rien
    assert mesures == [False, True, False]
    v._sr_cliquee("ecran", True)
    assert v._ancrer_apres_clic is True
    v.set_game(_jeu("b", "Autre"), HardwareInfo())
    assert v._ancrer_apres_clic is False
