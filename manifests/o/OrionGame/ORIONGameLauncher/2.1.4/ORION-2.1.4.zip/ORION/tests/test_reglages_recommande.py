"""Lancement avec reglages graphiques et profil « Recommande ».

Couvre la chaine profil -> plan -> ecriture -> relecture -> etat affiche,
les defauts corriges (fichier .cfg vide a la 2e application, JSON ecrase,
valeurs equivalentes vues comme des changements, plan perime au lancement,
fichier en lecture seule qui bloquait tout), le choix du niveau
Recommande, et les deux widgets : bloc « Graphismes » de la fiche et
panneau « Ce que votre PC peut faire ».
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from orion.core.models import (Display, DisplayMode, Game, GPUInfo, HardwareInfo,
                               OptimizationPlan, TweakOp)


# ---------------------------------------------------------------------------
# materiel et jeux factices
# ---------------------------------------------------------------------------
def _hw(w=2560, h=1440, hz=165, tier=2, feats=("dlss", "rt", "reflex")):
    natif = DisplayMode(w, h, hz)
    ecran = Display(device="D1", primary=True, current=natif, native=natif,
                    max_refresh_at_native=hz, modes=[natif])
    gpu = GPUInfo(name="NVIDIA GeForce RTX 3070", vendor="nvidia", vram_mb=8192,
                  tier=tier, features=list(feats))
    return HardwareInfo(cpu_name="AMD Ryzen 7 5800X", cpu_threads=16, ram_gb=32,
                        gpus=[gpu], displays=[ecran]), ecran


def _jeu_unreal(tmp_path, monkeypatch, contenu: str | None = "") -> tuple[Game, Path]:
    local = tmp_path / "local"
    monkeypatch.setenv("LOCALAPPDATA", str(local))
    inst = tmp_path / "jeux" / "MonJeu"
    (inst / "MonJeu" / "Binaries" / "Win64").mkdir(parents=True)
    dossier = local / "MonJeu" / "Saved" / "Config" / "Windows"
    fichier = dossier / "GameUserSettings.ini"
    if contenu is not None:
        dossier.mkdir(parents=True)
        fichier.write_text(contenu or "[/Script/Engine.GameUserSettings]\n", "utf-8")
    jeu = Game(title="Mon Jeu", source="dossier", install_dir=str(inst), engine="unreal")
    return jeu, fichier


@pytest.fixture
def moteur():
    from orion.optimizer.engine import Optimizer
    return Optimizer()


# ---------------------------------------------------------------------------
# ecrivains
# ---------------------------------------------------------------------------
def test_cfg_garde_les_commandes_inchangees_a_la_deuxieme_application(tmp_path):
    from orion.plugins.tweaks.cfg_writer import CfgWriter
    f = tmp_path / "autoexec.cfg"
    f.write_text("bind w +forward\nfps_max 0\n", "utf-8")
    w = CfgWriter()
    ops = [TweakOp("cfg", str(f), key="fps_max", value="163"),
           TweakOp("cfg", str(f), key="mat_vsync", value="0")]
    assert w.write(ops)[0] == 2
    # seconde application : seul fps_max change (ORION n'ecrit que ce qui change)
    assert w.write([TweakOp("cfg", str(f), key="fps_max", value="141")])[0] == 1
    texte = f.read_text("utf-8")
    assert "mat_vsync 0" in texte                   # n'a pas disparu
    assert texte.count("ORION : debut") == 1
    assert "bind w +forward" in texte
    # la derniere definition compte (celle du bloc ORION, en fin de fichier)
    assert w.read(TweakOp("cfg", str(f), key="fps_max")) == "141"


def test_json_illisible_n_est_jamais_ecrase(tmp_path):
    from orion.plugins.tweaks.json_writer import JsonWriter
    f = tmp_path / "settings.json"
    original = '{\n  // commentaire que json ne sait pas lire\n  "Gfx": {"Preset": 2}\n}'
    f.write_text(original, "utf-8")
    n, msg = JsonWriter().write([TweakOp("json", str(f), key="Gfx.Preset", value="3")])
    assert n == 0 and "pas pu etre lu" in msg
    assert f.read_text("utf-8") == original


def test_json_avec_bom_est_lu_et_ecrit(tmp_path):
    from orion.plugins.tweaks.json_writer import JsonWriter
    f = tmp_path / "settings.json"
    f.write_bytes(b'\xef\xbb\xbf{"Gfx": {"Preset": 2, "Autre": true}}')
    w = JsonWriter()
    op = TweakOp("json", str(f), key="Gfx.Preset", value="3")
    assert w.read(op) == "2"
    assert w.write([op])[0] == 1
    data = json.loads(f.read_text("utf-8"))
    assert data["Gfx"] == {"Preset": 3, "Autre": True}


def test_ini_en_lecture_seule_n_empeche_pas_les_autres_fichiers(tmp_path, monkeypatch):
    from orion.plugins.tweaks import ini_writer
    a, b = tmp_path / "a.ini", tmp_path / "b.ini"
    a.write_text("[S]\nk=1\n", "utf-8")
    b.write_text("[S]\nk=1\n", "utf-8")
    vrai = ini_writer.os.access
    monkeypatch.setattr(ini_writer.os, "access",
                        lambda p, m: False if Path(p) == a else vrai(p, m))
    n, msg = ini_writer.IniWriter().write([TweakOp("ini", str(a), "S", "k", "2"),
                                           TweakOp("ini", str(b), "S", "k", "2")])
    assert n == 1 and "lecture seule" in msg
    assert "k=2" in b.read_text("utf-8") and "k=1" in a.read_text("utf-8")


# ---------------------------------------------------------------------------
# plan, application, etat
# ---------------------------------------------------------------------------
def test_valeurs_equivalentes_ne_sont_pas_des_changements(tmp_path, monkeypatch, moteur):
    jeu, f = _jeu_unreal(tmp_path, monkeypatch,
                         "[/Script/Engine.GameUserSettings]\nbUseVSync=false\n"
                         "[ScalabilityGroups]\nsg.ShadowQuality=2.000000\n")
    hw, ecran = _hw()
    plan = moteur.build_plan(jeu, "detente", hw, ecran)
    par_cle = {o.key: o for o in plan.ops}
    assert not par_cle["bUseVSync"].changed            # « false » = « False »
    assert not par_cle["sg.ShadowQuality"].changed     # « 2.000000 » = « 2 »


def test_application_puis_etat_reglages_appliques(tmp_path, monkeypatch, moteur):
    from orion.optimizer import fiabilite
    jeu, f = _jeu_unreal(tmp_path, monkeypatch)
    hw, ecran = _hw()
    plan = moteur.build_plan(jeu, "recommande", hw, ecran)
    assert plan.ops and plan.has_changes
    st = fiabilite.statut(plan, jeu)
    assert st.cle == fiabilite.A_ECRIRE and st.total == len(plan.ops)
    ok, msg = moteur.apply_plan(jeu, plan)
    assert ok, msg
    st = fiabilite.statut(moteur.build_plan(jeu, "recommande", hw, ecran), jeu)
    assert st.cle == fiabilite.AUTO
    assert st.titre == f"Reglages appliques : {st.total} sur {st.total}"
    assert "sg.TextureQuality=" in f.read_text("utf-8")


def test_plan_perime_relu_avant_lancement(tmp_path, monkeypatch, moteur):
    """Le jeu a remis ses reglages apres la construction du plan : sans
    relecture, ORION croyait tout en place et ne reecrivait rien."""
    jeu, f = _jeu_unreal(tmp_path, monkeypatch)
    hw, ecran = _hw()
    plan = moteur.build_plan(jeu, "recommande", hw, ecran)
    moteur.apply_plan(jeu, plan)
    assert not plan.has_changes
    f.write_text(f.read_text("utf-8").replace("sg.ShadowQuality=", "sg.ShadowQuality=9#"),
                 "utf-8")
    assert not plan.has_changes                        # plan perime
    assert moteur.relire(plan)                         # la relecture le voit
    ok, _msg = moteur.apply_plan(jeu, plan)
    assert ok and "sg.ShadowQuality=9" not in f.read_text("utf-8")


def test_echec_partiel_continue_et_n_accuse_pas_le_jeu(tmp_path, monkeypatch, moteur):
    from orion.optimizer import fiabilite
    jeu, f = _jeu_unreal(tmp_path, monkeypatch)
    hw, ecran = _hw()
    plan = moteur.build_plan(jeu, "recommande", hw, ecran)
    note = TweakOp("registry", "HKCU/Software/X", key="Q", value="3", label="Qualite")
    plan.ops.append(note)                   # format qui echoue hors Windows
    ok, msg = moteur.apply_plan(jeu, plan)
    assert not ok and "non pris en compte" in msg
    assert "sg.ShadowQuality=" in f.read_text("utf-8")  # le reste est ecrit
    memo = jeu.extra[fiabilite.CLE]
    assert memo["refuses"] == ["Qualite"]
    assert not any(k.startswith("HKCU") for k in memo["valeurs"])
    st = fiabilite.statut(plan, jeu)
    assert st.titre.startswith("Reglages appliques : ") and st.en_place < st.total


def test_jeu_sans_recette_n_est_pas_pris_en_charge(moteur):
    from orion.optimizer import fiabilite
    hw, ecran = _hw()
    plan = moteur.build_plan(Game(title="Jeu maison", source="dossier"), "recommande",
                             hw, ecran)
    st = fiabilite.statut(plan, None)
    assert st.cle == fiabilite.NON_PRIS and not st.pris_en_charge
    assert st.titre == "Ce jeu n'est pas encore pris en charge"


def test_recette_connue_sans_fichier_demande_une_premiere_partie(tmp_path, monkeypatch,
                                                                moteur):
    from orion.optimizer import fiabilite
    jeu, _f = _jeu_unreal(tmp_path, monkeypatch, contenu=None)
    hw, ecran = _hw()
    plan = moteur.build_plan(jeu, "recommande", hw, ecran)
    st = fiabilite.statut(plan, jeu)
    assert not plan.ops and st.cle == fiabilite.GERE_PAR_LE_JEU
    assert "Lancez le jeu une fois" in st.titre


def test_reecriture_identique_evite_de_redemander(tmp_path, monkeypatch, moteur):
    from orion.optimizer import fiabilite
    jeu, f = _jeu_unreal(tmp_path, monkeypatch)
    hw, ecran = _hw()
    plan = moteur.build_plan(jeu, "recommande", hw, ecran)
    assert not fiabilite.reecriture_identique(jeu, plan)     # premiere fois
    moteur.apply_plan(jeu, plan)
    f.write_text(f.read_text("utf-8").replace("sg.EffectsQuality=", "sg.EffectsQuality=0#"),
                 "utf-8")
    plan = moteur.build_plan(jeu, "recommande", hw, ecran)
    assert plan.has_changes and fiabilite.reecriture_identique(jeu, plan)


def test_bilan_apres_partie_compte_les_reglages_remplaces(tmp_path, monkeypatch, moteur):
    import time
    jeu, f = _jeu_unreal(tmp_path, monkeypatch)
    hw, ecran = _hw()
    jeu.preferred_profile = "recommande"
    moteur.apply_plan(jeu, moteur.build_plan(jeu, "recommande", hw, ecran))
    jeu.last_played = time.time() + 5
    f.write_text(f.read_text("utf-8").replace("sg.ShadowQuality=", "sg.ShadowQuality=0#"),
                 "utf-8")
    assert moteur.bilan_apres_partie(jeu, hw) == 1


# ---------------------------------------------------------------------------
# profil Recommande
# ---------------------------------------------------------------------------
def _exig(gpu):
    from orion.puissance.exigences import Config, Exigences
    return Exigences("1", "Jeu", recommandee=Config(gpu=gpu, cpu=40, ram_go=16, vram_go=6))


def test_recommande_est_premier_et_par_defaut():
    from orion.optimizer.profiles import ORDER, PROFILES, profil_par_defaut
    assert ORDER == ["recommande"] and PROFILES["recommande"].label == "Votre ecran"
    assert profil_par_defaut() == "recommande"


def test_recommande_explique_son_choix_en_une_phrase():
    from orion.optimizer.recommande import recommander
    hw, ecran = _hw()
    r = recommander(Game(title="Jeu", source="dossier"), hw, ecran, ["upscaler"], runs={},
                    exig=_exig(30), refresh=60)
    assert r.niveau == "haute" and r.famille == "dlss" and r.mode != "off"
    assert r.phrase.startswith("Haute + DLSS ")
    assert "i/s attendues sur votre RTX 3070 en 1440p" in r.phrase
    assert r.atteint and r.fps[0] >= 55 and r.palier == 60


def test_ecran_rapide_vise_l_ecran_puis_le_plus_haut_palier():
    """Le but est d'exploiter l'ecran : sur un 165 Hz que la carte ne tient
    pas, ORION vise le plus haut palier tenable et bride dessus."""
    from orion.optimizer.profiles import PROFILES, compute_settings
    from orion.optimizer.recommande import recommander, noter_capacites
    hw, ecran = _hw()
    jeu = Game(title="Jeu", source="dossier")
    r = recommander(jeu, hw, ecran, ["upscaler"], runs={}, exig=_exig(30), refresh=165)
    assert r.cible == 165 and not r.atteint
    assert r.palier == 120 and r.fps[0] >= 120 * 0.92
    assert "ce PC en tient 120" in r.sous_titre
    # chaque niveau est pousse au maximum de ce que le materiel donne
    for n in ("moyenne", "ultra"):
        assert r.options[n].mode == "performance"
    # « Haute » est l'autre proposition : la plus belle image qui reste fluide
    assert r.niveau_beau == "haute" and r.options["haute"].mode != "performance"


def test_1440p_n_est_pas_traite_comme_de_la_4k():
    from orion.optimizer.recommande import recommander
    hw, ecran = _hw(2560, 1440)
    r = recommander(Game(title="Inconnu", source="dossier"), hw, ecran, ["upscaler"], runs={}, refresh=165)
    assert r.source == "inconnu" and r.mode == "off"          # pas de DLSS impose
    hw4k, ecran4k = _hw(3840, 2160, 60)
    r = recommander(Game(title="Inconnu", source="dossier"), hw4k, ecran4k, ["upscaler"], runs={}, refresh=60)
    assert r.mode == "quality" and r.definition == "4K"


def test_sans_super_resolution_ecrivable_pas_de_dlss_promis():
    from orion.optimizer.recommande import recommander
    hw, ecran = _hw()
    r = recommander(Game(title="Jeu", source="dossier"), hw, ecran, [], runs={}, exig=_exig(30), refresh=165)
    assert r.mode == "off" and r.upscaler == "off" and r.niveau in ("moyenne", "basse")


def test_echelle_de_rendu_unreal_nommee_clairement():
    from orion.optimizer.recommande import recommander
    hw, ecran = _hw()
    r = recommander(Game(title="Jeu", source="dossier"), hw, ecran, ["echelle_resolution"], runs={},
                    exig=_exig(38), refresh=165)
    assert r.famille == "echelle" and r.texte_mode.startswith("Rendu ")


def test_niveau_deduit_d_une_mesure_n_est_pas_dit_mesure():
    from orion.optimizer.recommande import recommander
    hw, ecran = _hw()
    runs = {"recommande": {"fps_avg": 85, "fps_low_1": 60, "preset": "haute",
                           "upscaler_mode": "off", "at": 1}}
    r = recommander(Game(title="Jeu", source="dossier"), hw, ecran, [], runs=runs, refresh=165)
    assert r.source == "mesure"
    if r.niveau == "haute":
        assert "mesurees" in r.phrase
    else:
        assert "d'apres vos mesures" in r.phrase


def test_niveau_force_garde_la_super_resolution_la_plus_fine():
    from orion.optimizer.recommande import choisir_niveau, recommander
    hw, ecran = _hw()
    jeu = Game(title="Jeu", source="dossier")
    choisir_niveau(jeu, "ultra")
    r = recommander(jeu, hw, ecran, ["upscaler"], runs={}, exig=_exig(30), refresh=165)
    # niveau choisi a la main : pousse lui aussi au maximum d'images
    assert r.force and r.niveau == "ultra" and r.mode == "performance"
    assert "conseille : Basse" in r.sous_titre
    assert r.palier == 50 and not r.atteint


def test_jeu_competitif_vise_la_frequence_de_l_ecran():
    from orion.optimizer.recommande import cible_fps
    assert cible_fps(Game(title="Counter-Strike 2", source="steam", source_id="730"),
                     165) == 165
    # un jeu solo vise lui aussi la frequence de l'ecran
    assert cible_fps(Game(title="Baldur's Gate 3", source="dossier"), 165) == 165


def test_donnees_fiche_completes():
    from orion.optimizer.choix import IDS
    from orion.optimizer.profiles import donnees_fiche
    hw, ecran = _hw()
    jeu = Game(title="Jeu", source="dossier")
    d = donnees_fiche(jeu, hw, ecran, None)
    # les deux cartes, « Votre ecran » en place, « Mon choix » en Ultra a l'ecran
    assert [c.id for c in d["choix"]] == list(IDS) and d["choix_id"] == "ecran"
    assert d["cible"] == 0 and d["niveau"] == "ultra" and d["objectifs"][0] == d["choix"][0].cible
    assert d["recommandation"].niveau and d["statut"].titre
    assert all(c.to_dict()["fps_court"] and c.reglage for c in d["choix"])
    assert d["sauvegarde_origine"] is False
    # avec un choix memorise : il est repris
    jeu.extra["cible_fps"] = 90
    jeu.extra["recommande_niveau"] = "haute"
    d = donnees_fiche(jeu, hw, ecran, None)
    assert d["choix_id"] == "choix" and d["cible"] == 90 and d["niveau"] == "haute"
    assert (d["choix"][1].niveau, d["choix"][1].cible) == ("haute", 90)


# ---------------------------------------------------------------------------
# widgets
# ---------------------------------------------------------------------------
@pytest.fixture
def app():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


def test_bloc_graphismes(app):
    from orion.optimizer import fiabilite
    from orion.optimizer.profiles import donnees_fiche
    from orion.ui.widgets.profile_card import ChoixGraphismes
    hw, ecran = _hw()
    c = ChoixGraphismes()
    plan = OptimizationPlan(game_uid="x", profile="recommande")
    plan.ops.append(TweakOp("ini", "C:/a/GameUserSettings.ini", key="k", value="1",
                            current="1"))
    plan.reglages_prevus = 2
    c.set_donnees(donnees_fiche(Game(title="Jeu", source="dossier"), hw, ecran, plan))
    assert c.statut.titre.text() == "Reglages appliques : 1 sur 2"
    # la carte « Votre ecran » est conseillee et en place
    assert c.choix_id == "ecran" and not c.cartes["ecran"].marque.isHidden()
    assert c.cartes["ecran"].property("selected") == "true"
    assert c.defaut.isHidden()                         # pas encore de sauvegarde d'origine
    choisis, defauts = [], []
    c.choix_fait.connect(choisis.append)
    c.defaut_demande.connect(lambda: defauts.append(1))
    c.choix_fait.disconnect()
    c.choix_fait.connect(lambda n, f: choisis.append((n, f)))
    c.cartes["choix"].selected.emit("choix")
    assert choisis == [("ultra", c.cible())] and c.cible() and c.choix_id == "choix"
    c.defaut.click()
    assert defauts == [1]
    assert "i/s" in c.cartes["ecran"].fps.text() and c.cartes["ecran"].reglage.text()
    # jeu non pris en charge : niveau conseille a regler dans le jeu
    c.set_donnees(donnees_fiche(Game(title="Jeu", source="dossier"), hw, ecran,
                                OptimizationPlan(game_uid="x", profile="recommande")))
    assert "options graphiques du jeu" in c.manuel.text()
    assert c.statut.titre.text() == fiabilite.TITRE_NON_PRIS


def _resultats():
    from orion.puissance import Candidat
    from orion.puissance.estimation import Evaluation

    def ev(niveau, fps, src="estime"):
        return Evaluation(titre="", source=src, niveau=niveau, fps=fps)
    return [
        (Candidat("Zeta", installe=True, possede=True, uid="z"), ev("haute", {"haute": (60, 80)})),
        (Candidat("Alpha", prix=30.0, url="u"), ev("basse", {"basse": (40, 50)})),
        (Candidat("Beta", prix=5.0, url="u"), ev("ultra", {"ultra": (90, 120)}, "mesure")),
        (Candidat("Gamma", possede=True, uid="g"), ev("insuffisant", {"basse": (20, 25)})),
    ]


def test_panneau_puissance_filtres_tri_recherche_sans_reconstruction(app):
    from orion.ui.widgets.puissance_panel import (COL_JEU, COL_NIVEAU, NIVEAU,
                                                  PuissancePanel)
    p = PuissancePanel()
    p.set_resultats(_resultats())
    assert p._filtre_actif == "mes"                    # vos jeux d'abord
    visibles = p.titres_visibles
    assert visibles() == ["Zeta", "Gamma"]             # trie par niveau
    remises_a_zero = []
    p._montrer("acheter")
    assert visibles() == ["Beta", "Alpha"]
    p._montrer("tous")
    assert p.modele.rowCount() == 4 and len(visibles()) == 4
    # filtrer, trier, chercher : le contenu du modele n'est pas refait
    contenu = p.modele.tout
    p.modele.modelReset.connect(lambda: remises_a_zero.append(1))
    p.trier("prix")
    assert visibles()[:2] == ["Gamma", "Zeta"] and visibles()[2:] == ["Beta", "Alpha"]
    p.trier("nom")
    assert visibles() == ["Alpha", "Beta", "Gamma", "Zeta"]
    p.trier("nom")                                     # meme ordre : rien ne bouge
    avant = len(remises_a_zero)
    p.trier("nom")
    assert len(remises_a_zero) == avant
    p.recherche.setText("et")
    p._appliquer_filtre()                              # (la frappe attend 120 ms)
    assert visibles() == ["Beta", "Zeta"]
    assert p.modele.tout is contenu
    p.recherche.setText("")
    p._appliquer_filtre()
    niveaux = {p.modele.index(i, COL_JEU).data(): p.modele.index(i, COL_NIVEAU).data(NIVEAU)
               for i in range(4)}
    assert niveaux == {"Zeta": "haute", "Alpha": "basse", "Beta": "ultra",
                       "Gamma": "insuffisant"}
    assert p.filtres["tous"].text().endswith("4")
    assert p.compteurs["ultra"].text().endswith("1")


def test_panneau_puissance_ancien_onglet_vos(app):
    from orion.ui.widgets.puissance_panel import PuissancePanel
    p = PuissancePanel()
    p.set_resultats(_resultats())
    p._montrer("vos")
    assert p._filtre_actif == "mes"
    p._montrer("haute")
    assert p._filtre_actif == "tous"
