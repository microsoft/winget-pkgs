"""Prix de Gamesplanet (2.0) : distributeur officiel partenaire, prix lus
dans le fichier que releve la tache planifiee du depot public.

Regles verifiees ici : correspondance par numero Steam, jamais une edition
prise pour le jeu, jamais un prix perime, jamais hors de la zone euro, et le
lien porte l'identifiant partenaire.
"""
from __future__ import annotations

import io
import sys
import time
from pathlib import Path

import pytest

CATALOGUE = {
    "2183900": [
        ["Warhammer 40,000: Space Marine 2", 53.99, 59.99, "warhammer-40-000-space-marine-2-steam-key--5451-1", "steam", "", ""],
        ["Warhammer 40,000: Space Marine 2 - 1-Year Anniversary Edition", 80.99, 89.99, "sm2-1y-steam-key--5451-9", "steam", "", ""],
    ],
    "1486920": [["Tempest Rising: Gold Edition", 35.19, 54.99, "tempest-rising-gold-steam-key--1-2", "steam", "", ""]],
    "500": [["Jeu de Tir - Standard Edition", 17.99, 19.99, "jeu-de-tir-steam-key--500-1", "steam", "", ""]],
    "600": [["Pas en Allemagne", 9.0, 10.0, "pas-de--600-1", "uplay", "", "AT,DE"]],
    "700": [["France et Belgique", 9.0, 10.0, "frbe--700-1", "steam", "BE,FR", ""]],
    "800": [["Adresse Fausse", 9.0, 10.0, "../mechant", "steam", "", ""]],
}


@pytest.fixture(scope="module")
def app():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


@pytest.fixture
def gp(monkeypatch):
    from orion import prix_gamesplanet as G
    from orion.core import region
    monkeypatch.setattr(region, "devise", lambda: "EUR")
    monkeypatch.setattr(region, "pays", lambda: "FR")
    monkeypatch.setitem(G._memo, "releve", time.time() - 600)
    monkeypatch.setitem(G._memo, "jeux", CATALOGUE)
    return G


def _fiche(titre, appid, prix=59.99, normal=59.99, boutique="Steam", source="steam"):
    from orion.boutique import Fiche
    from orion.plugins.boutique.base import Offre
    return Fiche(titre=titre, offres=[Offre(
        titre=titre, boutique=boutique, prix=prix, prix_normal=normal,
        url=f"https://store.steampowered.com/app/{appid}", source=source, steam_appid=appid)])


def test_offre_par_numero_steam_et_jamais_une_edition(gp):
    o = gp.offre("2183900", "Warhammer 40,000: Space Marine 2")
    assert (o.boutique, o.prix, o.prix_normal, o.remise) == ("Gamesplanet", 53.99, 59.99, 10)
    assert o.url == "https://fr.gamesplanet.com/game/warhammer-40-000-space-marine-2-steam-key--5451-1"
    assert o.sure and o.drm == "Cle Steam" and o.source == "gamesplanet"
    # seule l'edition « Gold » est vendue : ce n'est pas le jeu demande
    assert gp.offre("1486920", "Tempest Rising", 39.99) is None
    # nom ecrit autrement, meme prix normal : c'est bien le jeu
    assert gp.offre("500", "Jeu de Tir", 19.99).prix == 17.99
    assert gp.offre("500", "Jeu de Tir", 49.99) is None          # prix normal tres different
    assert gp.offre("500", "Jeu de Tir") is None                 # aucun prix normal pour comparer
    assert gp.offre("999", "Inconnu") is None and gp.offre("", "x") is None
    assert gp.offre("800", "Adresse Fausse") is None             # adresse refusee


def test_pays_et_zone_euro(gp, monkeypatch):
    from orion.core import region
    assert gp.offre("600", "Pas en Allemagne").drm == "Cle Ubisoft Connect"
    assert gp.offre("700", "France et Belgique") is not None
    monkeypatch.setattr(region, "pays", lambda: "DE")
    assert gp.offre("600", "Pas en Allemagne") is None           # pays exclu
    assert gp.offre("700", "France et Belgique") is None         # pays non autorise
    monkeypatch.setattr(region, "devise", lambda: "USD")
    assert gp.offre("2183900", "Warhammer 40,000: Space Marine 2") is None


def test_releve_perime_plus_aucun_prix(gp, monkeypatch):
    monkeypatch.setitem(gp._memo, "releve", time.time() - gp.PERIME - 60)
    assert not gp.valable()
    assert gp.offre("2183900", "Warhammer 40,000: Space Marine 2") is None
    f = _fiche("Warhammer 40,000: Space Marine 2", "2183900")
    monkeypatch.setitem(gp._memo, "releve", time.time())
    assert gp.completer([f]) == 1 and len(f.offres) == 2
    monkeypatch.setitem(gp._memo, "releve", time.time() - gp.PERIME - 60)
    assert gp.completer([f]) == 0 and [o.boutique for o in f.offres] == ["Steam"]   # l'ancien prix est retire


def test_completer_les_fiches(gp):
    from orion.plugins.boutique.base import Offre
    f = _fiche("Warhammer 40,000: Space Marine 2", "2183900")
    # offre du comparateur pour la meme boutique : la notre la remplace (lien partenaire)
    f.offres.append(Offre(titre=f.titre, boutique="GamesPlanet FR", prix=54.5, prix_normal=59.99,
                          url="https://itad.link/x", source="itad", steam_appid="2183900"))
    f.offres.append(Offre(titre=f.titre, boutique="GamesPlanet UK", prix=50, prix_normal=59.99,
                          url="https://itad.link/y", source="itad", steam_appid="2183900"))
    assert gp.completer([f]) == 1
    # la vitrine d'une autre region ne concerne pas un joueur francais
    assert sorted(o.boutique for o in f.offres) == ["Gamesplanet", "Steam"]
    assert gp.completer([f]) == 1 and len(f.offres) == 2          # pas de doublon au second passage
    assert f.prix_normal == 59.99
    # jeu gratuit sur Steam : rien a vendre
    g = _fiche("Jeu de Tir", "500", prix=0.0, normal=19.99)
    assert gp.completer([g]) == 0 and len(g.offres) == 1
    # sans numero Steam, ou inconnu de Gamesplanet : fiche intacte
    h = _fiche("Autre", "424242")
    assert gp.completer([h, None]) == 0 and len(h.offres) == 1


def test_boutique_affiche_le_prix_gamesplanet(app, gp, monkeypatch):
    """La meilleure offre devient Gamesplanet quand il est moins cher, et son
    lien porte l'identifiant partenaire."""
    import webbrowser
    from orion.core.config import CONFIG
    from orion.ui.views import boutique_view as B
    CONFIG.set("boutique.liens_partenaires", True)
    ouverts = []
    monkeypatch.setattr(webbrowser, "open", ouverts.append)
    f = _fiche("Warhammer 40,000: Space Marine 2", "2183900")
    gp.completer([f])
    assert f.meilleure.boutique == "Gamesplanet" and f.nb_boutiques == 2 and f.remise == 10
    # Steam moins cher : Gamesplanet garde son bouton, avec son vrai prix
    s = _fiche("Warhammer 40,000: Space Marine 2", "2183900", prix=29.99)
    gp.completer([s])
    ligne = B.FicheLigne(s, set(), avec_image=False)
    assert ligne.bouton_officiel.text() == "Gamesplanet  ·  53,99 €"
    ligne.bouton_officiel.click()
    assert ouverts == ["https://fr.gamesplanet.com/game/warhammer-40-000-space-marine-2-steam-key--5451-1?ref=orion"]
    # jeu que Gamesplanet ne vend pas (absent de son catalogue complet) : pas de
    # bouton, sa recherche ne montrerait que des jeux sans rapport
    assert gp.vendu("424242", "Autre") is False and gp.vendu("2183900") is True
    autre = B.FicheLigne(_fiche("Autre", "424242"), set(), avec_image=False)
    assert autre.bouton_officiel is None
    # meme jeu sans numero Steam (fiche venue d'un comparateur) : reconnu par son nom
    assert gp.vendu("", "Warhammer 40,000: Space Marine 2") is True
    # catalogue inconnu (fichier absent ou trop vieux) : on ne sait pas, la recherche reste
    monkeypatch.setitem(gp._memo, "releve", 0.0)
    assert gp.vendu("424242", "Autre") is None
    inconnu = B.FicheLigne(_fiche("Autre", "424242"), set(), avec_image=False)
    assert inconnu.bouton_officiel.text() == "Chercher sur Gamesplanet"


def test_lecture_du_fichier_des_prix(monkeypatch):
    import importlib
    from orion import prix_gamesplanet
    from orion.core import reseau
    G = importlib.reload(prix_gamesplanet)          # la vraie fonction (remplacee pendant les tests)
    appels = []
    reponse = {"v": 1, "releve": time.time() - 100, "boutique": "fr", "devise": "EUR", "jeux": CATALOGUE}

    def get_json(url, garder=0, **k):
        appels.append((url, garder))
        if isinstance(reponse, Exception):
            raise reponse
        return reponse
    monkeypatch.setattr(reseau, "get_json", get_json)
    assert G.actualiser() is True and G.valable()
    assert appels == [(G.ADRESSE, G.RELIRE)] and G.ADRESSE.startswith("https://raw.githubusercontent.com/Sikher-kisa/")
    # fichier inattendu ou reseau coupe : le catalogue en memoire reste, sans erreur
    for mauvaise in ({"v": 2, "jeux": {}}, {"v": 1, "devise": "GBP", "jeux": CATALOGUE}, [], OSError("coupe")):
        reponse = mauvaise
        assert G.actualiser() is True
    G._memo.update(releve=0.0, jeux={})
    assert G.actualiser() is False


def test_releve_du_flux():
    """Le script lance par GitHub : du flux XML au fichier compact."""
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "service" / "gamesplanet"))
    import releve_gamesplanet as R

    def prod(nom, prix, base, lien, steam="app/1", type_="steam", wl="", bl="AE,RU", pc="true"):
        return (f"<product><uid>1</uid><name>{nom}</name><desc>d</desc><price>{prix}</price>"
                f"<price_base>{base}</price_base><link>https://fr.gamesplanet.com/game/{lien}</link>"
                f"<delivery_type>{type_}</delivery_type><country_whitelist>{wl}</country_whitelist>"
                f"<country_blacklist>{bl}</country_blacklist><steam_id>{steam}</steam_id>"
                f"<platforms><pc>{pc}</pc><mac>false</mac></platforms></product>")
    xml = "<products>" + "".join([
        prod("Jeu - Edition Or", 80, 90, "jeu-or--1-2", "app/42"),
        prod("Jeu", 50, 60, "jeu--1-1", "app/42"),
        prod("Tom &amp; Jerry", 9.49, 9.99, "aerial_knight-s--7099-1", "app/77"),
        prod("Lot", 9, 10, "lot--1", "sub/123"), prod("Sans numero", 9, 10, "sans--2", ""),
        prod("Mac", 9, 10, "mac--3", "app/3", pc="false"), prod("Prix faux", "abc", 10, "faux--4", "app/4"),
        prod("Plus cher que normal", 12, 10, "cher--4", "app/4"), prod("Adresse", 9, 10, "../x", "app/5"),
        prod("Hors zone euro", 9, 10, "us--6", "app/6", wl="US,CA"),
        prod("Europe entiere", 9, 10, "eu--7", "app/7", wl="AD,EU,GB"),
        prod("France et Belgique", 9, 10, "frbe--8", "app/8", wl="FR,BE,US"),
        prod("Pas en Allemagne", 9, 10, "de--9", "app/9", bl="DE,RU,AT", type_="uplay"),
    ]) + "</products>"
    d = R.construire(io.BytesIO(xml.encode()), 1791200000)
    j = d["jeux"]
    assert list(j) == ["7", "8", "9", "42", "77"]
    assert [p[0] for p in j["42"]] == ["Jeu", "Jeu - Edition Or"]             # l'edition standard d'abord
    assert j["77"][0][0] == "Tom & Jerry" and j["77"][0][3] == "aerial_knight-s--7099-1"
    assert j["7"][0][5] == "" and j["8"][0][5] == "BE,FR" and j["9"][0][4:] == ["uplay", "", "AT,DE"]
    assert (d["v"], d["releve"], d["devise"]) == (1, 1791200000, "EUR")
    # le fichier produit est exactement ce que lit ORION
    from orion import prix_gamesplanet as G
    assert all(len(p) == 7 for produits in j.values() for p in produits) and G.FICHE.endswith("/game/")


def test_fragments_de_prix_pour_les_pages_du_site():
    """Cent petits fichiers : une page du site ne lit que celui de son jeu,
    et seulement des produits vendus en France."""
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "service" / "gamesplanet"))
    import releve_gamesplanet as R
    document = {"v": 1, "releve": 1791200000, "jeux": {
        "1245620": [["ELDEN RING", 53.99, 59.99, "elden-ring--1", "steam", "", ""]],
        "7": [["Europe entiere", 9.0, 10.0, "eu--7", "steam", "", ""]],
        "107": [["France et Belgique", 9.0, 10.0, "frbe--8", "steam", "BE,FR", ""],
                ["Allemagne seulement", 8.0, 10.0, "de--8", "steam", "AT,DE", ""]],
        "207": [["Pas en France", 9.0, 10.0, "nofr--9", "steam", "", "FR"]],
    }}
    f = R.fragments(document)
    assert sorted(f) == [f"{i:02d}" for i in range(100)]
    # les numeros Steam finissent presque tous par zero : le fichier d'un jeu
    # est choisi par ses dizaines et ses centaines
    assert (R.cle_fragment("1245620"), R.cle_fragment(7), R.cle_fragment("107")) == ("62", "00", "10")
    assert f["62"]["jeux"] == {"1245620": [["ELDEN RING", 53.99, 59.99, "elden-ring--1", "steam"]]}
    assert f["62"]["releve"] == 1791200000
    assert list(f["00"]["jeux"]) == ["7"] and "207" not in f["20"]["jeux"]   # 207 : pas vendu en France
    assert [p[3] for p in f["10"]["jeux"]["107"]] == ["frbe--8"]
    assert f["99"]["jeux"] == {}
    # bien repartis : mille jeux numerotes de dix en dix remplissent les cent fichiers
    gros = {"v": 1, "releve": 1, "jeux": {str(a): [["J", 1.0, 2.0, "j--1", "steam", "", ""]]
                                          for a in range(10, 10010, 10)}}
    assert {len(x["jeux"]) for x in R.fragments(gros).values()} == {10}


def _fiches():
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "service" / "gamesplanet"))
    import fiches_jeux as F
    return F


def test_fiches_des_jeux_tri_des_articles_steam():
    F = _fiches()
    jeu = {"appid": 1245620, "success": 1, "visible": True, "type": 0, "name": "ELDEN  RING",
           "content_descriptorids": [2, 5],
           "reviews": {"summary_filtered": {"review_count": 832711, "percent_positive": 93}}}
    assert F.lire_article(jeu) == {"avis": 832711, "positifs": 93, "nom": "ELDEN RING"}
    assert F.lire_article(dict(jeu, type=4)) is None                       # DLC
    assert F.lire_article(dict(jeu, type=11)) is None                      # bande originale
    assert F.lire_article(dict(jeu, content_descriptorids=[1, 3])) is None  # reserve aux adultes
    assert F.lire_article(dict(jeu, visible=False)) is None
    assert F.lire_article({"appid": 9, "success": 2}) is None
    assert F.lire_article(dict(jeu, reviews=None))["avis"] == 0

    appels = []

    def appeler(url, params):
        ids = [x["appid"] for x in __import__("json").loads(params["input_json"])["ids"]]
        appels.append(len(ids))
        if len(appels) == 2:
            raise OSError("panne")                     # un lot perdu n'arrete rien
        return {"response": {"store_items": [dict(jeu, appid=a, name=f"Jeu {a}") for a in ids]
                             + [dict(jeu, appid=424242)]}}     # article non demande : ignore
    out = F.classer([str(i) for i in range(1, 251)], appeler)
    assert appels == [100, 100, 50] and len(out) == 150 and "424242" not in out
    assert out["1"]["nom"] == "Jeu 1" and "150" not in out and "201" in out

    xml = ("<products>"
           "<product><steam_id>app/10</steam_id><delivery_type>steam</delivery_type><platforms><pc>true</pc></platforms></product>"
           "<product><steam_id>app/10</steam_id><delivery_type>steam</delivery_type><platforms><pc>true</pc></platforms></product>"
           "<product><steam_id>app/20</steam_id><delivery_type>uplay</delivery_type><platforms><pc>true</pc></platforms></product>"
           "<product><steam_id>sub/30</steam_id><delivery_type>steam</delivery_type><platforms><pc>true</pc></platforms></product>"
           "<product><steam_id>app/40</steam_id><delivery_type>steam</delivery_type><platforms><pc>false</pc></platforms></product>"
           "<product><steam_id>app/50</steam_id><delivery_type>Steam</delivery_type><platforms><pc>true</pc></platforms></product>"
           "</products>")
    assert F.numeros_du_flux(io.BytesIO(xml.encode())) == ["10", "50"]


FICHE_STEAM = {
    "type": "game", "name": "ELDEN RING", "is_free": False,
    "short_description": "LE NOUVEL ACTION-RPG &quot;FANTASY&quot;.<br>Levez-vous.",
    "pc_requirements": {
        "minimum": "<strong>Minimale :</strong><br><ul class=\"bb_ul\"><li><strong>Système d'exploitation :</strong> Windows 10<br></li>"
                   "<li><strong>Processeur :</strong> INTEL CORE I5-8400<br></li><li><strong>Mémoire vive :</strong> 12 GB de mémoire<br></li>"
                   "<li><strong>Graphiques :</strong> NVIDIA GEFORCE GTX 1060 3 GB<br></li></ul>",
        "recommended": "<strong>Recommandée :</strong><br><ul class=\"bb_ul\"><li><strong>Graphiques :</strong> NVIDIA GEFORCE GTX 1070 8 GB</li></ul>"},
    "developers": ["FromSoftware, Inc."], "genres": [{"id": "1", "description": "Action"}, {"id": "3", "description": "RPG"}],
    "release_date": {"coming_soon": False, "date": "24 févr. 2022"},
    "header_image": "https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/1245620/header.jpg?t=1",
    "content_descriptors": {"ids": [2, 5], "notes": None},
}


def test_fiches_des_jeux_lecture_d_une_fiche_steam():
    F = _fiches()
    f = F.lire_fiche(FICHE_STEAM)
    assert f["n"] == "ELDEN RING" and f["d"] == "24 févr. 2022" and f["g"] == ["Action", "RPG"]
    assert f["dev"] == "FromSoftware, Inc." and f["free"] is False and f["img"].endswith("header.jpg?t=1")
    assert f["s"] == 'LE NOUVEL ACTION-RPG "FANTASY". Levez-vous.'
    assert f["min"].split("\n") == [
        "Minimale :", "Système d'exploitation : Windows 10", "Processeur : INTEL CORE I5-8400",
        "Mémoire vive : 12 GB de mémoire", "Graphiques : NVIDIA GEFORCE GTX 1060 3 GB"]
    assert f["rec"].split("\n") == ["Recommandée :", "Graphiques : NVIDIA GEFORCE GTX 1070 8 GB"]
    # le generateur du site sait lire ces lignes (meme moteur que l'application)
    from orion.puissance.exigences import lire_config
    assert lire_config(f["min"]).gpu and lire_config(f["rec"]).gpu > lire_config(f["min"]).gpu
    # pas un jeu, reserve aux adultes, ou sans configuration PC : pas de page
    assert F.lire_fiche(dict(FICHE_STEAM, type="dlc")) is None
    assert F.lire_fiche(dict(FICHE_STEAM, content_descriptors={"ids": [3]})) is None
    assert F.lire_fiche(dict(FICHE_STEAM, pc_requirements=[])) is None
    assert F.lire_fiche(None) is None
    assert F.lire_fiche(dict(FICHE_STEAM, release_date={"coming_soon": True, "date": "2027"}))["d"] == ""


def test_fiches_des_jeux_reprise_et_prudence_avec_steam():
    """Les plus connus d'abord ; une fiche fraiche n'est pas redemandee ; un
    refus de Steam met en pause, trois refus arretent le passage sans rien
    perdre ; un jeu sans configuration est note pour ne pas etre redemande."""
    import urllib.error
    F = _fiches()
    horloge = {"t": 1_800_000_000.0}
    pauses = []

    def dormir(s):
        pauses.append(s)
        horloge["t"] += s
    notoriete = {"1": {"avis": 9000, "positifs": 90, "nom": "A"}, "2": {"avis": 50000, "positifs": 80, "nom": "B"},
                 "3": {"avis": 700, "positifs": 70, "nom": "C"}, "4": {"avis": 120, "positifs": 99, "nom": "Confidentiel"},
                 "5": {"avis": 2000, "positifs": 60, "nom": "Sans config"}}
    ancien = {"1": {"n": "A", "min": "x", "le": horloge["t"] - 86400},              # fraiche
              "3": {"n": "C ancien", "min": "x", "le": horloge["t"] - 60 * 86400}}   # a relire
    demandes = []

    def appeler(url, params):
        a = params["appids"]
        demandes.append(a)
        if a == "5":
            return {a: {"success": True, "data": dict(FICHE_STEAM, pc_requirements=[])}}
        return {a: {"success": True, "data": dict(FICHE_STEAM, name=f"Jeu {a}")}}
    jeux = F.completer(notoriete, ancien, appeler, lambda: horloge["t"], dormir)
    assert demandes == ["2", "5", "3"]                       # par notoriete ; 1 est fraiche, 4 trop confidentiel
    assert list(jeux) == ["2", "1", "5", "3"]
    assert jeux["1"]["n"] == "A" and jeux["1"]["avis"] == 9000
    assert jeux["2"]["n"] == "Jeu 2" and jeux["2"]["positifs"] == 80 and jeux["2"]["le"] > 0
    assert jeux["5"] == {"err": 1, "le": jeux["5"]["le"], "avis": 2000, "positifs": 60}
    assert jeux["3"]["n"] == "Jeu 3" and pauses == [F.PAUSE] * 3

    # Steam refuse : pause longue, puis arret apres trois refus ; l'ancien est garde
    pauses.clear()

    def refuse(url, params):
        raise urllib.error.HTTPError(url, 429, "Too Many Requests", None, None)
    vieux = {a: {"n": f"Ancien {a}", "min": "x", "le": 1.0} for a in ("1", "2", "3", "5")}
    demandes.clear()
    compte = []
    jeux = F.completer(notoriete, vieux, lambda u, p: (compte.append(1), refuse(u, p))[1],
                       lambda: horloge["t"], dormir)
    assert len(compte) == 3 and pauses == [F.ATTENTE_REFUS] * 3
    assert {a: j["n"] for a, j in jeux.items()} == {a: f"Ancien {a}" for a in ("1", "2", "3", "5")}

    # temps ecoule : plus aucun appel, les fiches connues restent
    appels = []
    jeux = F.completer(notoriete, vieux, lambda u, p: appels.append(1), lambda: horloge["t"],
                       dormir, budget=-1)
    assert appels == [] and len(jeux) == 4


def test_une_seule_vitrine_gamesplanet_celle_du_joueur(gp, monkeypatch):
    """Vu dans la version compilee du 7 octobre : la fiche de Tropico 6
    montrait Gamesplanet, GamesPlanet US, DE et UK."""
    from orion.core import region
    from orion.plugins.boutique.base import Offre

    def fiche():
        f = _fiche("Jeu sans offre Gamesplanet a nous", "999999")
        for nom in ("GamesPlanet US", "GamesPlanet DE", "GamesPlanet UK", "GamesPlanet FR"):
            f.offres.append(Offre(titre=f.titre, boutique=nom, prix=30, prix_normal=40,
                                  url="https://itad.link/z", source="itad", steam_appid="999999"))
        return f
    monkeypatch.setattr(region, "pays", lambda: "FR")
    f = fiche(); gp.completer([f])
    assert sorted(o.boutique for o in f.offres) == ["GamesPlanet FR", "Steam"]
    monkeypatch.setattr(region, "pays", lambda: "US")
    f = fiche(); gp.completer([f])
    assert sorted(o.boutique for o in f.offres) == ["GamesPlanet US", "Steam"]
    monkeypatch.setattr(region, "pays", lambda: "BE")       # pas de vitrine belge : rien n'est retire
    f = fiche(); gp.completer([f])
    assert len(f.offres) == 5
