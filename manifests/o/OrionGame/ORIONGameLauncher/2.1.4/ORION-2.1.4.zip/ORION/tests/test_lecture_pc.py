"""Lecture du PC (2.0) : ce qui freine, ce qu'il manque, comment jouer quand
meme. Objectif du projet : que le joueur tire le maximum de sa machine, y
compris sur des jeux qu'il ne pensait pas pouvoir lancer."""
from __future__ import annotations

from dataclasses import replace

import pytest

from orion.puissance import Candidat, evaluer_tout, lecture
from orion.puissance.estimation import ESTIME, Evaluation, Machine, estimer, machine_depuis
from orion.puissance.exigences import Config, Exigences

PX_1080, PX_4K = 1920 * 1080, 3840 * 2160


def _machine(**k) -> Machine:
    base = dict(gpu=26.0, gpu_nom="NVIDIA GeForce RTX 3060", cpu=59.0,
                cpu_nom="AMD Ryzen 5 5600", vram_go=12.0, ram_go=16.0, pixels=PX_1080,
                definition="1920x1080", hz=60, mise_a_l_echelle="DLSS")
    base.update(k)
    return Machine(**base)


def _jeu(rec_gpu=38.0, rec_cpu=54.0, rec_ram=16.0, rec_vram=None, min_gpu=14.0,
         min_ram=8.0, rec=True) -> Exigences:
    return Exigences(
        appid="1", titre="Jeu",
        minimum=Config(gpu=min_gpu, gpu_nom="GTX 1660", cpu=36.0, cpu_nom="8100",
                       ram_go=min_ram),
        recommandee=Config(gpu=rec_gpu, gpu_nom="RTX 3070", cpu=rec_cpu, cpu_nom="9700K",
                           ram_go=rec_ram, vram_go=rec_vram) if rec else None)


# ---------------------------------------------------------------------------
# le moteur dit ce qui retient un jeu sous « Haute »
# ---------------------------------------------------------------------------
def test_le_frein_est_la_carte_quand_le_processeur_suit():
    e = estimer("Jeu", _jeu(), _machine())
    assert e.niveau in ("moyenne", "basse") and e.frein == "gpu" and e.base == "recommandee"
    assert lecture.frein(e) == "gpu"


def test_le_frein_est_le_processeur_quand_il_plafonne_le_niveau_haute():
    e = estimer("Jeu", _jeu(rec_gpu=20.0, rec_cpu=90.0), _machine(cpu=40.0))
    assert not e.fluide and e.frein == "cpu" and lecture.frein(e) == "cpu"


def test_le_frein_est_la_memoire_quand_les_images_y_sont():
    e = estimer("Jeu", _jeu(rec_gpu=12.0, rec_vram=16.0), _machine())
    assert e.niveau == "moyenne" and e.frein == "vram"
    e = estimer("Jeu", _jeu(rec_gpu=12.0, rec_ram=32.0), _machine())
    assert e.niveau == "moyenne" and e.frein == "ram"
    # sans plafond du processeur, la colonne « Niveau » le dit aussi
    e = estimer("Jeu", _jeu(rec_gpu=22.0, rec_cpu=30.0, rec_ram=32.0), _machine())
    assert e.niveau == "moyenne" and e.frein == "ram" and e.limite == "ram"
    e = estimer("Jeu", _jeu(min_ram=32.0), _machine())
    assert e.niveau == "insuffisant" and e.frein == "ram"


def test_pas_de_frein_pour_un_jeu_fluide_en_haute_ni_pour_une_mesure():
    e = estimer("Jeu", _jeu(rec_gpu=12.0), _machine())
    assert e.niveau == "haute" and e.frein == "" and lecture.frein(e) == ""
    mesure = Evaluation(titre="Jeu", source="mesure", niveau="basse")
    assert lecture.frein(mesure) == ""


# ---------------------------------------------------------------------------
# par composant
# ---------------------------------------------------------------------------
def _resultats(machine):
    jeux = [("Leger", _jeu(rec_gpu=10.0)), ("Leger 2", _jeu(rec_gpu=12.0)),
            ("Gourmand", _jeu(rec_gpu=60.0)), ("Tres gourmand", _jeu(rec_gpu=90.0)),
            ("Calcul", _jeu(rec_gpu=12.0, rec_cpu=95.0)),
            ("Textures", _jeu(rec_gpu=12.0, rec_vram=16.0))]
    sortie = []
    for i, (titre, exig) in enumerate(jeux):
        e = estimer(titre, exig, machine)
        sortie.append((Candidat(titre=titre, appid=str(i), installe=i < 2,
                                possede=i < 2), e))
    return sortie


def test_bilan_des_freins_et_premier_frein():
    m = _machine()
    res = _resultats(m)
    b = lecture.freins(res)
    assert b["evalues"] == 6 and b["fluides"] == 2
    assert (b["gpu"], b["cpu"], b["vram"], b["ram"]) == (2, 1, 1, 0)
    assert lecture.premier_frein(b) == "gpu"
    phrase = lecture.phrase_frein(b)
    assert phrase == ("Jeux estimes fluides en Haute : 2 sur 6. Premier frein de ce PC : "
                      "carte graphique, pour 2 jeu(x).")
    mes = lecture.freins(res, seulement_mes=True)
    assert mes["evalues"] == 2 and mes["fluides"] == 2
    assert lecture.phrase_frein(mes).endswith("Aucun composant ne retient les autres.")
    assert lecture.phrase_frein(lecture.freins([])) == ""


def test_les_quatre_composants_ont_un_verdict():
    m = _machine()
    c = {x.cle: x for x in lecture.composants(m, _resultats(m))}
    assert list(c) == ["gpu", "cpu", "vram", "ram"]
    assert c["gpu"].retenus == 2 and c["gpu"].etat == "attention"      # 2 sur 6
    assert c["gpu"].verdict == "retient 2 jeu(x) sur 6 sous le niveau Haute"
    assert c["cpu"].retenus == 1 and c["cpu"].etat == "conseil"
    assert c["ram"].etat == "ok" and "ne retient aucun" in c["ram"].verdict
    assert c["vram"].valeur == "12 Go" and c["ram"].valeur == "16 Go"
    assert c["gpu"].indice == 26.0 and c["vram"].indice is None


def test_composant_non_reconnu_le_dit():
    m = Machine()
    c = {x.cle: x for x in lecture.composants(m, [])}
    assert c["gpu"].etat == "inconnu" and "non reconnu" in c["gpu"].verdict
    assert c["gpu"].valeur == "non reconnue"


def test_equivalents_cartes_et_processeurs_voisins():
    assert lecture.equivalents_gpu(49, "NVIDIA GeForce RTX 3080") == "RTX 4070, RX 6800 XT"
    assert "RTX 3080" not in lecture.equivalents_gpu(49, "nvidia geforce rtx 3080")
    assert lecture.equivalents_gpu(None) == ""
    proches = lecture.equivalents_cpu(57, "Intel Core i9-9900K")
    assert proches and "9900K" not in proches


def test_noms_lisibles_des_references():
    assert lecture.joli_gpu("rtx 4060 ti") == "RTX 4060 Ti"
    assert lecture.joli_gpu("rx 7900 xtx") == "RX 7900 XTX"
    assert lecture.joli_gpu("gtx 1660 super") == "GTX 1660 Super"
    assert lecture.joli_gpu("arc b580") == "Arc B580"
    assert lecture.joli_gpu("gtx 1060 6gb") == "GTX 1060 6 Go"
    assert lecture.joli_cpu("5800x3d", True) == "Ryzen 7 5800X3D"
    assert lecture.joli_cpu("5600", True) == "Ryzen 5 5600"
    assert lecture.joli_cpu("9950x", True) == "Ryzen 9 9950X"
    assert lecture.joli_cpu("1200", True) == "Ryzen 3 1200"
    assert lecture.joli_cpu("fx 8350", True) == "FX-8350"
    assert lecture.joli_cpu("12400", False) == "Core i5-12400"
    assert lecture.joli_cpu("9900k", False) == "Core i9-9900K"
    assert lecture.joli_cpu("4790k", False) == "Core i7-4790K"
    assert lecture.joli_cpu("2600", False) == "Core i7-2600"
    assert lecture.joli_cpu("8350k", False) == "Core i3-8350K"
    assert lecture.joli_cpu("285k", False) == "Core Ultra 9 285K"


# ---------------------------------------------------------------------------
# pistes : jouer quand meme, sans rien acheter
# ---------------------------------------------------------------------------
def test_piste_mise_a_l_echelle_puis_definition_inferieure():
    m = _machine(pixels=PX_4K, definition="3840x2160")
    exig = _jeu(rec_gpu=30.0)
    actuel = estimer("Jeu", exig, m)
    assert actuel.niveau in ("basse", "insuffisant")
    p = lecture.pistes("Jeu", exig, m, actuel=actuel)
    assert p and p[0].genre == "echelle" and p[0].libelle == "DLSS en mode Qualite"
    assert lecture.RANG[p[0].niveau] < lecture.RANG[actuel.niveau]
    assert p[0].fps and p[0].texte.startswith("DLSS en mode Qualite : ")
    assert "i/s" in p[0].texte and p[0].court.endswith("avec DLSS")
    # chaque piste suivante fait strictement mieux que la precedente
    # (meme niveau possible : « Basse » a 44 i/s puis « Basse » a 73 i/s, fluide)
    rangs = [lecture.RANG[x.niveau] for x in p]
    images = [x.fps[0] for x in p]
    assert rangs == sorted(rangs, reverse=True) and images == sorted(set(images))
    if len(p) > 1:
        assert p[1].genre == "definition" and p[1].court.split(" en ")[1] in (
            "2560x1440", "1920x1080")


def test_la_technique_suit_la_carte():
    from orion.core.models import Display, DisplayMode, GPUInfo, HardwareInfo
    hw = HardwareInfo(cpu_name="AMD Ryzen 5 5600", ram_gb=16,
                      gpus=[GPUInfo(name="AMD Radeon RX 6600", vram_mb=8192,
                                    features=["fsr", "rt"])],
                      displays=[Display(device="d", primary=True,
                                        current=DisplayMode(1920, 1080, 60),
                                        native=DisplayMode(1920, 1080, 60))])
    assert machine_depuis(hw).mise_a_l_echelle == "FSR"
    hw.gpus = [GPUInfo(name="NVIDIA GeForce RTX 3060", vram_mb=12288, features=["dlss"])]
    assert machine_depuis(hw).mise_a_l_echelle == "DLSS"
    hw.gpus = [GPUInfo(name="Intel Arc B580", vram_mb=12288, features=["xess"])]
    assert machine_depuis(hw).mise_a_l_echelle == "XeSS"
    hw.gpus = []
    assert machine_depuis(hw).mise_a_l_echelle == ""


def test_pas_de_piste_quand_la_definition_n_y_peut_rien():
    m = _machine()
    # deja en Haute
    assert lecture.pistes("Jeu", _jeu(rec_gpu=12.0), m) == []
    # memoire vive sous le minimum : changer la definition n'aide pas
    assert lecture.pistes("Jeu", _jeu(min_ram=64.0), m) == []
    # le processeur plafonne tout : moins de points a calculer n'y change rien
    cpu = _machine(cpu=20.0, gpu=80.0)
    exig = _jeu(rec_gpu=20.0, rec_cpu=100.0)
    assert estimer("Jeu", exig, cpu).frein == "cpu"
    assert lecture.pistes("Jeu", exig, cpu) == []
    # mesure reelle, jeu inconnu, carte inconnue
    assert lecture.pistes("Jeu", None, m) == []
    assert lecture.pistes("Jeu", _jeu(), Machine()) == []


def test_les_pistes_sont_attachees_aux_jeux_evalues(monkeypatch):
    from orion.puissance import exigences
    exig = _jeu(rec_gpu=30.0)
    monkeypatch.setattr(exigences, "en_cache", lambda appid: exig)
    m = _machine(pixels=PX_4K, definition="3840x2160")
    res = evaluer_tout([Candidat(titre="Jeu", appid="1")], m)
    e = res[0][1]
    assert e.source == ESTIME and e.piste and e.niveau_piste
    assert lecture.RANG[e.niveau_piste] < lecture.RANG[e.niveau]
    assert e.calibration == 1.0
    # un jeu deja fluide en Haute n'en a pas
    monkeypatch.setattr(exigences, "en_cache", lambda appid: _jeu(rec_gpu=5.0))
    e = evaluer_tout([Candidat(titre="Jeu", appid="1")], _machine())[0][1]
    assert e.niveau == "haute" and e.piste == "" and e.niveau_piste == ""


# ---------------------------------------------------------------------------
# ce qu'il manque
# ---------------------------------------------------------------------------
def test_ce_qu_il_manque_designe_la_carte_juste_suffisante():
    m = _machine()
    exig = _jeu(rec_gpu=45.0)
    actuel = estimer("Jeu", exig, m)
    assert actuel.niveau != "haute"
    phrases = lecture.manque("Jeu", exig, m, actuel=actuel)
    assert len(phrases) == 1 and phrases[0].startswith("Pour le niveau Haute : ")
    assert "une carte graphique du niveau d'une " in phrases[0]
    # les cartes citees suffisent vraiment, sans viser beaucoup plus haut que
    # la plus petite carte qui suffit
    from orion.puissance.references import GPU
    suffisantes = sorted(v for v in set(GPU.values())
                         if estimer("Jeu", exig, replace(m, gpu=v)).niveau == "haute")
    citees = phrases[0].split("d'une ")[1].rstrip(".").lower().split(" ou ")
    assert 1 <= len(citees) <= 2
    for carte in citees:
        assert suffisantes[0] <= GPU[carte] <= suffisantes[0] * 1.12, carte
    assert not any(c.startswith(("radeon", "uhd", "iris")) for c in citees)


def test_ce_qu_il_manque_processeur_et_memoire():
    m = _machine(cpu=30.0, gpu=80.0)
    exig = _jeu(rec_gpu=20.0, rec_cpu=80.0)
    phrases = lecture.manque("Jeu", exig, m)
    assert phrases and "un processeur du niveau d'un " in phrases[-1]
    assert "carte graphique" not in phrases[-1]
    # memoire video : dite avec la carte, une seule fois
    m = _machine(vram_go=6.0)
    phrases = lecture.manque("Jeu", _jeu(rec_gpu=45.0, rec_vram=12.0), m)
    assert phrases[-1].count("carte graphique") == 1
    assert "(12 Go de memoire video)" in phrases[-1]
    # memoire vive seule
    phrases = lecture.manque("Jeu", _jeu(rec_gpu=12.0, rec_ram=32.0), _machine())
    assert phrases == ["Pour le niveau Haute : 32 Go de memoire vive."]


def test_jeu_trop_juste_deux_objectifs_jouable_puis_haute():
    m = _machine(gpu=6.0, gpu_nom="NVIDIA GeForce GTX 960")
    exig = _jeu(rec_gpu=40.0, min_gpu=20.0)
    assert estimer("Jeu", exig, m).niveau == "insuffisant"
    phrases = lecture.manque("Jeu", exig, m)
    assert [p.split(" : ")[0] for p in phrases] == ["Pour qu'il soit jouable",
                                                     "Pour le niveau Haute"]


def test_rien_a_viser_quand_seul_le_minimum_est_connu_ou_que_tout_va():
    m = _machine(gpu=10.0)
    seul_minimum = _jeu(rec=False, min_gpu=14.0)
    assert estimer("Jeu", seul_minimum, m).base == "minimale"
    assert lecture.manque("Jeu", seul_minimum, m) == []
    assert lecture.manque("Jeu", _jeu(rec_gpu=5.0), _machine()) == []
    assert lecture.manque("Jeu", None, _machine()) == []


# ---------------------------------------------------------------------------
# explication complete d'un jeu
# ---------------------------------------------------------------------------
def test_explication_composant_par_composant():
    m = _machine()
    exig = _jeu(rec_gpu=45.0, rec_cpu=70.0, rec_vram=8.0)
    e = estimer("Jeu", exig, m)
    x = lecture.expliquer("Jeu", e, exig, m)
    assert x.base == "recommandee"
    par = {li.cle: li for li in x.lignes}
    assert list(par) == ["gpu", "cpu", "vram", "ram"]
    assert par["gpu"].etat == "manque" and round(par["gpu"].rapport, 2) == round(26 / 45, 2)
    assert par["cpu"].etat == "juste" and par["vram"].etat == "ok" and par["ram"].etat == "ok"
    assert par["gpu"].demande == "RTX 3070 (indice 45)"
    assert par["cpu"].demande == "Core i7-9700K (indice 70)"
    assert par["gpu"].vous == "NVIDIA GeForce RTX 3060 (indice 26)"
    assert x.debut.startswith("Niveau ") and x.debut.endswith("Ce qui le retient : ")
    assert x.retenus == ["carte graphique (58 % de la demande)",
                         "processeur (84 % de la demande)"]
    assert x.resume == x.debut + " · ".join(x.retenus) + "."
    assert x.manque and x.manque[0].startswith("Pour le niveau Haute")


def test_explication_d_un_jeu_fluide_et_d_une_mesure():
    m = _machine()
    exig = _jeu(rec_gpu=10.0)
    x = lecture.expliquer("Jeu", estimer("Jeu", exig, m), exig, m)
    assert x.resume == "Votre PC depasse la configuration recommandee : niveau Haute attendu."
    assert x.pistes == [] and x.manque == []
    mesure = Evaluation(titre="Jeu", source="mesure", niveau="ultra")
    x = lecture.expliquer("Jeu", mesure, exig, m)
    assert x.resume == "Mesure sur votre PC : niveau Ultra." and x.lignes
    inconnu = Evaluation(titre="Jeu")
    assert "Pas assez d'informations" in lecture.expliquer("Jeu", inconnu, None, m).resume


def test_explication_prudente_quand_seul_le_minimum_est_publie():
    m = _machine(gpu=14.0)
    exig = _jeu(rec=False, min_gpu=14.0)
    e = estimer("Jeu", exig, m)
    x = lecture.expliquer("Jeu", e, exig, m)
    assert x.base == "minimale" and "estimation tres prudente" in x.resume
    assert x.manque == []                       # on ne designe pas de composant a acheter
    assert "Ce qui le retient" not in x.resume


def test_le_contexte_dit_ce_que_le_jeu_promet_quand_ce_n_est_pas_l_usage():
    """PC deux fois plus fort que la carte recommandee, et pourtant « Basse » :
    le jeu donnait sa configuration pour 30 images par seconde."""
    m = _machine(gpu=49.0)
    exig = _jeu(rec_gpu=27.0, rec_cpu=36.0)
    exig.recommandee.cible_fps = 30
    e = estimer("Jeu", exig, m)
    assert e.niveau != "haute"
    x = lecture.expliquer("Jeu", e, exig, m)
    assert x.contexte == ("Le jeu donne sa configuration recommandee pour 30 images par "
                          "seconde (l'usage est 60 images par seconde en 1920x1080).")
    exig.recommandee.cible_fps = None
    exig.recommandee.cible_px = 3840 * 2160
    x = lecture.expliquer("Jeu", estimer("Jeu", exig, m), exig, m)
    assert "un affichage en 3840x2160" in x.contexte
    exig.recommandee.cible_px = None
    assert lecture.expliquer("Jeu", estimer("Jeu", exig, m), exig, m).contexte == ""


def test_une_seule_note_pour_le_pc():
    """La page affichait « indice 74 » en haut et « Note 55 » dans le panneau."""
    from orion.core.models import Display, DisplayMode, GPUInfo, HardwareInfo
    from orion.hardware import probe
    hw = HardwareInfo(cpu_name="Intel(R) Core(TM) i9-9900K CPU @ 3.60GHz", cpu_cores=8,
                      cpu_threads=16, cpu_ghz=3.6, ram_gb=31.9,
                      gpus=[GPUInfo(name="NVIDIA GeForce RTX 3080", vram_mb=10240, tier=3)],
                      displays=[Display(device="d", primary=True,
                                        current=DisplayMode(1920, 1080, 60),
                                        native=DisplayMode(1920, 1080, 60))])
    assert probe.note(hw) == machine_depuis(hw).score
    inconnue = HardwareInfo(cpu_name="Processeur", cpu_threads=8, cpu_ghz=3.0, ram_gb=16,
                            gpus=[GPUInfo(name="Carte Inconnue 9000", tier=1)])
    assert machine_depuis(inconnue).score is None
    assert probe.note(inconnue) == probe._score(inconnue)       # ancienne estimation


# ---------------------------------------------------------------------------
# le moteur lit ce que l'editeur a ecrit, sans en rajouter (regle 2)
# ---------------------------------------------------------------------------
CYBERPUNK = ("<strong>Recommandee :</strong><br><ul><li><strong>Processeur :</strong> Intel Core "
             "i7-12700 or AMD Ryzen 7 7800X3D<br></li><li><strong>Memoire vive :</strong> 16 GB "
             "de memoire<br></li><li><strong>Graphiques :</strong> Nvidia GeForce RTX 2060 SUPER "
             "or AMD Radeon RX 5700XT or Intel Arc A770<br></li></ul>")


def test_plusieurs_composants_cites_le_moins_puissant_suffit():
    from orion.puissance.exigences import lire_config
    c = lire_config(CYBERPUNK)
    assert (c.cpu_nom, c.cpu) == ("12700", 74)          # pas le Ryzen 7 7800X3D (90)
    assert (c.gpu_nom, c.gpu) == ("RTX 2060 SUPER", 22)  # pas l'Arc A770 (29)
    seul = lire_config("<li><strong>Graphiques :</strong> GeForce GTX 1060</li>")
    assert seul.gpu_nom == "GTX 1060"


def test_cyberpunk_n_est_plus_classe_basse_sur_un_i9_9900k():
    """Dette notee le 4 octobre : « Cyberpunk 2077 estime trop bas (Basse, 39-54
    i/s) » sur Core i9-9900K + RTX 3080. Le processeur plafonne, il ne
    condamne pas le jeu."""
    from orion.puissance.exigences import lire_config
    exig = Exigences("1091500", "Cyberpunk 2077",
                     Config(gpu=11.0, gpu_nom="GTX 1060", cpu=41.0, cpu_nom="7700", ram_go=12.0),
                     lire_config(CYBERPUNK))
    m = Machine(gpu=49.0, gpu_nom="NVIDIA GeForce RTX 3080", cpu=57.0,
                cpu_nom="Intel Core i9-9900K", vram_go=10.0, ram_go=31.9,
                pixels=1920 * 1080, definition="1920x1080", mise_a_l_echelle="DLSS")
    e = estimer("Cyberpunk 2077", exig, m)
    assert e.niveau == "haute" and e.limite == "cpu"    # « Haute », plafonne par le processeur
    assert 55 <= e.fps["haute"][0] <= 60 and e.fps["haute"][1] <= 80
    # un processeur nettement sous le recommande reste retenu
    faible = estimer("Cyberpunk 2077", exig, replace(m, cpu=38.0))
    assert not faible.fluide and faible.frein == "cpu" and faible.limite == "cpu"


def test_une_fiche_gardee_avec_l_ancienne_regle_est_relue_une_fois(base_neuve):
    from dataclasses import asdict
    from orion.core.base import Table
    from orion.puissance import exigences as X
    ancienne = X.Exigences(
        "7", "Jeu", None,
        X.Config(gpu=29.0, gpu_nom="ARC A770", cpu=90.0, cpu_nom="7800X3D", ram_go=16.0,
                 texte="Processeur : Intel Core i7-12700 or AMD Ryzen 7 7800X3D\n"
                       "Graphiques : RTX 2060 SUPER or RX 5700XT or Arc A770"), lu_le=1.0)
    Table("exigences").set("7", asdict(ancienne))               # sans « regle »
    lue = X.en_cache("7")
    assert (lue.recommandee.cpu_nom, lue.recommandee.gpu_nom) == ("12700", "RTX 2060 SUPER")
    garde = Table("exigences").get("7")
    assert garde["regle"] == X.REGLE and garde["recommandee"]["cpu"] == 74
    # deja a la bonne regle : rien n'est relu ni reecrit
    garde["recommandee"]["cpu_nom"] = "TEMOIN"
    Table("exigences").set("7", garde)
    assert X.en_cache("7").recommandee.cpu_nom == "TEMOIN"
    assert X.en_cache("inconnu") is None


def test_composant_au_niveau_demande_mais_sans_marge():
    m = _machine(gpu=40.0)
    exig = _jeu(rec_gpu=38.0, rec_cpu=30.0)
    e = estimer("Jeu", exig, m)
    assert e.niveau == "moyenne" and e.frein == "gpu"       # 105 % : pas de marge
    x = lecture.expliquer("Jeu", e, exig, m)
    assert x.retenus == ["carte graphique (au niveau de la demande, sans marge)"]


def test_haute_mais_processeur_sous_la_demande_n_est_pas_dit_au_dessus():
    """Cyberpunk 2077 sur Core i9-9900K : « Haute », mais le processeur est a
    77 % du recommande. Dire « votre PC depasse la configuration » est faux."""
    m = _machine(gpu=49.0, cpu=57.0)
    exig = _jeu(rec_gpu=20.0, rec_cpu=74.0)
    e = estimer("Jeu", exig, m)
    assert e.niveau == "haute"
    x = lecture.expliquer("Jeu", e, exig, m)
    assert "depasse" not in x.resume
    assert x.debut == "Niveau Haute attendu. Sous la configuration recommandee : "
    assert x.retenus == ["processeur (77 % de la demande)"]
    assert not x.pistes and not x.manque


def test_en_4k_c_est_l_ecran_qui_retient_pas_la_carte():
    """RTX 3060 sur un ecran 4K : la carte vaut celle demandee (pour du
    1920x1080), le jeu est pourtant en « Basse ». Le coupable est l'ecran."""
    m = _machine(gpu=26.0, cpu=59.0, pixels=3840 * 2160, definition="3840x2160")
    exig = _jeu(rec_gpu=25.0, rec_cpu=54.0)
    e = estimer("Jeu", exig, m)
    assert e.niveau in ("basse", "moyenne", "insuffisant") and e.frein == "gpu"
    x = lecture.expliquer("Jeu", e, exig, m)
    assert x.retenus[0] == ("definition de l'ecran (3840x2160 : la configuration demandee "
                            "vaut pour 1920x1080)")
    assert not any(r.startswith("carte graphique") for r in x.retenus)
    # meme carte, ecran 1920x1080 : rien de tel
    m2 = _machine(gpu=26.0, cpu=59.0)
    e2 = estimer("Jeu", exig, m2)
    x2 = lecture.expliquer("Jeu", e2, exig, m2)
    assert not any("definition" in r for r in x2.retenus)


# ---------------------------------------------------------------------------
# processeur qui plafonne : baisser les reglages ne rend pas d'images
# ---------------------------------------------------------------------------
def test_processeur_qui_plafonne_le_niveau_reste_le_plus_beau():
    """RTX 4060 de portable + Core i5-12450H dans un jeu qui recommande un
    Core i7-12700 : 51 a 70 images/s a TOUS les niveaux. « Basse » ferait
    baisser les reglages pour rien ; le profil « Recommande » garde deja le
    plus beau reglage dans ce cas."""
    m = _machine(gpu=23.2, cpu=52.7)
    exig = _jeu(rec_gpu=22.0, rec_cpu=74.0)
    e = estimer("Jeu", exig, m)
    assert e.niveau == "haute" and not e.fluide
    assert e.frein == "cpu" and e.limite == "cpu"
    assert e.fps["haute"][0] >= e.fps["basse"][0] - 2 and e.fps["haute"][0] < 55
    # il ne compte pas parmi les jeux « fluides en Haute »
    bilan = lecture.freins([(Candidat(titre="Jeu", appid="1"), e)])
    assert bilan["fluides"] == 0 and bilan["cpu"] == 1
    x = lecture.expliquer("Jeu", e, exig, m)
    assert x.debut == "Niveau Haute, sous les 60 images par seconde. Ce qui le retient : "
    assert x.retenus[0].startswith("processeur (71 % de la demande)")
    assert not x.pistes                      # ni DLSS ni definition n'y changent rien
    assert x.manque and x.manque[0].startswith(
        "Pour 60 images par seconde en Haute : un processeur du niveau d'un ")


def test_carte_trop_faible_le_niveau_reste_basse():
    """Sans plafond du processeur, « Basse » garde son sens : c'est en
    baissant les reglages qu'on gagne des images."""
    e = estimer("Jeu", _jeu(rec_gpu=60.0, rec_cpu=30.0), _machine(gpu=30.0))
    assert e.niveau == "basse" and e.frein == "gpu" and e.limite != "cpu"


def test_memoire_insuffisante_et_processeur_qui_plafonne():
    """Le niveau « Haute » reste interdit par la memoire video, meme quand
    le processeur egalise les niveaux."""
    m = _machine(gpu=23.2, cpu=52.7, vram_go=6.0)
    e = estimer("Jeu", _jeu(rec_gpu=22.0, rec_cpu=74.0, rec_vram=8.0), m)
    assert e.niveau == "moyenne" and not e.fluide


def test_piste_qui_rend_fluide_sans_changer_de_niveau():
    """« Basse » a 37 images/s, « Basse » a 63 avec DLSS : la colonne ne doit
    pas afficher « Basse → Basse avec DLSS »."""
    m = _machine(gpu=26.0, cpu=59.0, pixels=PX_4K, definition="3840x2160")
    exig = _jeu(rec_gpu=20.0, rec_cpu=30.0)
    e = estimer("Jeu", exig, m)
    assert e.niveau == "basse" and not e.fluide
    p = lecture.pistes("Jeu", exig, m, actuel=e)
    assert p[0].niveau == "basse" and p[0].meme_niveau and p[0].fps[0] >= 55
    assert p[0].court == "Basse fluide avec DLSS"
    assert p[1].court == "Haute en 1920x1080" and not p[1].meme_niveau


@pytest.mark.parametrize("brut, propre", [
    ("Intel(R) Core(TM) i9-9900K CPU @ 3.60GHz", "Intel Core i9-9900K"),
    ("12th Gen Intel(R) Core(TM) i5-12450H", "Intel Core i5-12450H"),
    ("AMD Ryzen 7 7735HS with Radeon Graphics", "AMD Ryzen 7 7735HS"),
    ("AMD Ryzen 5 7500F 6-Core Processor", "AMD Ryzen 5 7500F"),
    ("AMD Ryzen AI 9 HX 370 w/ Radeon 890M", "AMD Ryzen AI 9 HX 370"),
    ("NVIDIA GeForce RTX 3080", "NVIDIA GeForce RTX 3080"),
    ("AMD Radeon(TM) Graphics", "AMD Radeon Graphics"),
    ("", ""),
])
def test_nom_de_composant_sans_mentions_de_marque(brut, propre):
    assert lecture.nom_propre(brut) == propre
