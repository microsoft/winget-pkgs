"""Catalogues de pilotes des constructeurs (Dell, Lenovo, HP) : lectures sur
des extraits de vrais fichiers (8 octobre 2026), appariement par identifiant
materiel, et conseil « plus recent chez le constructeur »."""
from __future__ import annotations

import datetime as dt
import json
import time
from pathlib import Path

import pytest

from orion.hardware import catalogues as c
from orion.hardware import systeme as s

DONNEES = Path(__file__).parent / "donnees" / "catalogues"


def _lire(nom: str) -> bytes:
    return (DONNEES / nom).read_bytes()


class _P:
    def __init__(self, id_materiel, version, bus="PCI"):
        self.id_materiel, self.version, self.bus = id_materiel, version, bus


# ----------------------------------------------------------------------
# briques
# ----------------------------------------------------------------------

def test_identifiants_et_versions():
    assert c._normaliser("PCI\\VEN_8086&DEV_15BB&SUBSYS_83E0103C&REV_10") == "8086:15BB"
    assert c._normaliser("VEN_10EC&DEV_0257") == "10EC:0257"
    assert c._normaliser("USB\\VID_8087&PID_0026&REV_0001") == "8087:0026"
    assert c._normaliser("SWC\\VEN_DOLBY&PID_DAX3APOSVC") == "" and c._normaliser("ACPI\\INTC1055") == ""
    # sous-systeme : PCI ecrit modele puis fabricant, HDAUDIO fabricant puis modele
    assert c.sous_systeme("PCI\\VEN_1D6A&DEV_07B1&SUBSYS_87411043&REV_02") == "1043:8741"
    assert c.sous_systeme("HDAUDIO\\FUNC_01&VEN_10EC&DEV_0295&SUBSYS_102809CD") == "1028:09CD"
    assert c.sous_systeme("PCI\\VEN_8086&DEV_15BB") == ""
    assert c.plus_recente("12.19.2.45", "12.19.2.62") and not c.plus_recente("12.19.2.62", "12.19.2.62")
    assert not c.plus_recente("1168.9.614.2022", "1168.009.0614.2022")        # meme version, zeros en plus
    assert not c.plus_recente("32.0.15.6174", "561.74")                        # deux schemas : on ne compare pas
    assert not c.plus_recente("", "1.0") and not c.plus_recente("1.0", "")
    assert c._date_en("January 15, 2023") == "2023-01-15" and c._date_en("2024-07-18") == "2024-07-18"
    assert c._date_en("hier") == ""


def test_identite_du_pc_chez_son_constructeur():
    e = s.EtatSysteme()
    e.pc = ("Dell Inc.", "XPS 15 9530"); e.pc_sku = "0BEB"
    assert c.identite(e) == ("Dell", "0BEB")
    e.pc_sku = "Default string"
    assert c.identite(e) == ("", "")
    e.pc = ("LENOVO", "20U9S0PR00"); e.pc_sku = "LENOVO_MT_20U9_BU_Think_FM_ThinkPad T14 Gen 1"
    assert c.identite(e) == ("Lenovo", "20U9")
    e.pc = ("LENOVO", "82K2"); e.pc_sku = ""
    assert c.identite(e) == ("Lenovo", "82K2")
    e.pc = ("HP", "HP EliteDesk 800 G4 WKS TWR"); e.pc_sku = "4RX11ET#ABF"; e.carte_mere = ("HP", "83E0")
    assert c.identite(e) == ("HP", "83E0")
    e.pc = ("Micro-Star International Co., Ltd.", "MS-7B51"); e.carte_mere = ("MSI", "MPG Z390")
    assert c.identite(e) == ("", "")
    assert c.identite(None) == ("", "")


# ----------------------------------------------------------------------
# Dell
# ----------------------------------------------------------------------

def test_dell_index_et_catalogue_du_modele():
    index = c.lire_dell_index(_lire("dell-CatalogIndexPC-extrait.xml"))
    assert index["0BEB"] == ("XPS 15 9530", "FOLDER15093790M/1/XPS_Notebook_0BEB.cab")
    assert index["0C0C"][0] == "Latitude 7440" and "0BF7" in index
    offres = c.lire_dell(_lire("dell-XPS_Notebook_0BEB-extrait.xml"))
    par_nom = {o.nom: o for o in offres}
    audio = par_nom["Realtek High Definition Audio Driver"]
    assert audio.source == "Dell" and audio.version == "6.0.9954.2" and audio.date == "2026-06-09"
    assert audio.categorie == "Audio" and "10EC:0236:1028:083F" in audio.ids
    assert audio.details == "https://www.dell.com/support/home/fr-fr/drivers/driversdetails?driverid=J3VXM"
    assert audio.fichier.startswith("https://downloads.dell.com/FOLDER") and audio.fichier.endswith(".EXE")
    wifi = next(o for o in offres if o.nom.startswith("Intel BE202"))
    assert wifi.version == "23.20.1.1" and "8086:54F0:1A56:1691" in wifi.ids
    # un composant sans PCIInfo ni Generic ne donne rien ; les BIOS et applications non plus
    assert all(o.ids for o in offres) and not any("BIOS" in o.categorie for o in offres)


def test_dell_appariement_et_choix_de_la_version():
    cat = c.Catalogue("Dell", "0BEB", time.time(), c.lire_dell(_lire("dell-XPS_Notebook_0BEB-extrait.xml")))
    # codec Realtek de ce modele (sous-systeme Dell 1028:083F), pilote de 2022 installe
    o = cat.pour(_P("HDAUDIO\\FUNC_01&VEN_10EC&DEV_0236&SUBSYS_1028083F&REV_1000", "6.0.9239.1", "HDAUDIO"))
    assert o is not None and o.version == "6.0.9954.2"
    # meme codec, autre sous-systeme : la puce suffit (score 1)
    assert cat.pour(_P("HDAUDIO\\FUNC_01&VEN_10EC&DEV_0236&SUBSYS_10280000", "6.0.9239.1", "HDAUDIO")).version == "6.0.9954.2"
    # deja a jour, ou plus recent que le catalogue : rien
    assert cat.pour(_P("HDAUDIO\\FUNC_01&VEN_10EC&DEV_0236&SUBSYS_1028083F", "6.0.9954.2", "HDAUDIO")) is None
    assert cat.pour(_P("HDAUDIO\\FUNC_01&VEN_10EC&DEV_0236&SUBSYS_1028083F", "6.0.9999.1", "HDAUDIO")) is None
    # Wi-Fi Intel AX211 en version Killer (sous-systeme 1A56:1691)
    o = cat.pour(_P("PCI\\VEN_8086&DEV_54F0&SUBSYS_16911A56&REV_1A", "22.190.0.4"))
    assert o is not None and o.version == "23.20.1.1" and o.details.endswith("driverid=8NG3N")
    # puce inconnue du catalogue, ou sans identifiant
    assert cat.pour(_P("PCI\\VEN_8086&DEV_15BB", "1.0")) is None and cat.pour(_P("", "1.0")) is None
    # NVIDIA : le catalogue a une version, mais l'appelant (advisor) l'ignore ; ici l'appariement marche
    assert cat.pour(_P("PCI\\VEN_10DE&DEV_28A0&SUBSYS_0C631028", "31.0.15.3209")).version == "31.0.15.4659"


# ----------------------------------------------------------------------
# Lenovo
# ----------------------------------------------------------------------

def test_lenovo_index_et_fiches():
    fiches = c.lire_lenovo_index(_lire("lenovo-20U9_Win11.xml"))
    cats = {cat for cat, _u in fiches}
    assert ("Networking LAN Ethernet", "https://download.lenovo.com/pccbbs/mobiles/n2wrw06w_2_.xml") in fiches
    assert "Audio" in cats and "BIOS UEFI" not in cats and "Software and Utilities" not in cats
    assert "Fingerprint reader" not in cats and len(fiches) < 37
    lan = c.lire_lenovo_paquet(_lire("lenovo-n2wrw06w_2_.xml"),
                               "https://download.lenovo.com/pccbbs/mobiles/n2wrw06w_2_.xml", "Networking LAN Ethernet")
    assert len(lan) == 1 and lan[0].source == "Lenovo" and lan[0].version == "12.19.2.62" and lan[0].date == "2024-07-18"
    assert "8086:15BB" in lan[0].ids and lan[0].categorie == "Networking LAN Ethernet"
    assert lan[0].fichier == "https://download.lenovo.com/pccbbs/mobiles/n2wrw06w.exe"
    assert lan[0].details == "https://download.lenovo.com/pccbbs/mobiles/n2wrw06w.html"
    # la fiche audio porte le codec Realtek (6.0.9590.1) et, a part, Dolby (SWC, sans identifiant PCI : ignore)
    audio = c.lire_lenovo_paquet(_lire("lenovo-n2wa126w_2_.xml"), "https://download.lenovo.com/pccbbs/mobiles/n2wa126w_2_.xml", "Audio")
    assert [o.version for o in audio] == ["6.0.9590.1"] and "10EC:0257" in audio[0].ids
    # fiche grand public : identifiant avec sous-systeme Lenovo, version ecrite avec des zeros
    lan2 = c.lire_lenovo_paquet(_lire("lenovo-51l304afqz81hgc0_82k2_11_2_.xml"),
                                "https://download.lenovo.com/consumer/mobiles/51l304afqz81hgc0_82k2_11_2_.xml", "Networking LAN Ethernet")
    assert lan2[0].ids == ["10EC:8168:17AA:3909"] and lan2[0].version == "1168.009.0614.2022"
    assert c.lire_lenovo_paquet(b"pas du xml", "", "") == []


def test_lenovo_appariement():
    offres = c.lire_lenovo_paquet(_lire("lenovo-n2wrw06w_2_.xml"), "https://download.lenovo.com/pccbbs/mobiles/n2wrw06w_2_.xml", "Networking LAN Ethernet")
    offres += c.lire_lenovo_paquet(_lire("lenovo-51l304afqz81hgc0_82k2_11_2_.xml"), "https://x/y.xml", "Networking LAN Ethernet")
    cat = c.Catalogue("Lenovo", "20U9", time.time(), offres)
    assert cat.pour(_P("PCI\\VEN_8086&DEV_15BB&SUBSYS_229817AA&REV_10", "12.19.2.45")).version == "12.19.2.62"
    assert cat.pour(_P("PCI\\VEN_8086&DEV_15BB&SUBSYS_229817AA&REV_10", "12.19.2.62")) is None
    # Realtek 8168 du 82K2 : version installee egale sous une autre ecriture -> rien
    assert cat.pour(_P("PCI\\VEN_10EC&DEV_8168&SUBSYS_390917AA", "1168.9.614.2022")) is None
    assert cat.pour(_P("PCI\\VEN_10EC&DEV_8168&SUBSYS_390917AA", "1168.9.600.2021")).version == "1168.009.0614.2022"


# ----------------------------------------------------------------------
# cache, fil de fond, conseils
# ----------------------------------------------------------------------

def test_cache_json_aller_retour_et_fraicheur(tmp_path, monkeypatch):
    offres = c.lire_lenovo_paquet(_lire("lenovo-n2wrw06w_2_.xml"), "https://download.lenovo.com/pccbbs/mobiles/n2wrw06w_2_.xml", "LAN")
    cat = c.Catalogue("Lenovo", "20U9", time.time(), offres)
    d = json.loads(json.dumps(cat.vers_json()))
    cat2 = c.Catalogue.depuis_json(d)
    assert cat2.source == "Lenovo" and cat2.modele == "20U9" and cat2.offres[0].ids == offres[0].ids
    e = s.EtatSysteme(); e.pc = ("LENOVO", "20U9S0PR00"); e.pc_sku = ""
    assert c.frais(cat2, e) and not c.frais(None) and not c.frais(c.Catalogue("Lenovo", "20U9", 0))
    e.pc = ("Dell Inc.", "XPS"); e.pc_sku = "0BEB"
    assert not c.frais(cat2, e)                       # catalogue d'un autre PC
    monkeypatch.setattr(c, "FICHIER", tmp_path / "pilotes-constructeur.json")
    monkeypatch.setattr(c, "_DERNIER", None)
    assert c.dernier() is None
    (tmp_path / "pilotes-constructeur.json").write_text(json.dumps(cat.vers_json()), encoding="utf-8")
    assert c.dernier().modele == "20U9"
    # hors Windows ou PC sans constructeur : pas de fil
    monkeypatch.setattr(c, "is_windows", lambda: False)
    assert c.lancer(e, "26100") is False
    monkeypatch.setattr(c, "is_windows", lambda: True)
    e2 = s.EtatSysteme(); e2.pc = ("ASUS", "System Product Name")
    assert c.lancer(e2, "26100") is False


@pytest.fixture
def advisor():
    from orion.optimizer import advisor
    return advisor


def test_conseil_plus_recent_chez_le_constructeur(advisor):
    """ThinkPad T14 (20U9) : l'Intel I219-LM en 12.19.2.45, Lenovo publie la
    12.19.2.62 ; Windows Update ne propose rien, et le conseil « ancien »
    n'est pas doublonne."""
    from orion.hardware import maj_pilotes as wu
    from tests.test_conseils import _p, donnees_factices, machine_factice, AUJOURDHUI

    def h(nom, classe, version, date, fournisseur, hid, did):
        return dict(_p(nom, classe, version, date, fournisseur), HardwareID=hid, DeviceID=did)
    d = donnees_factices(pc={"fabricant": "LENOVO", "modele": "20U9S0PR00", "type": 2, "pagination_auto": True,
                             "sku": "LENOVO_MT_20U9_BU_Think_FM_ThinkPad T14 Gen 1"},
                         carte_mere={"fabricant": "LENOVO", "modele": "20U9S0PR00"}, boitier=[10], batteries=1,
                         pilotes=[
        h("Intel(R) Ethernet Connection (10) I219-LM", "NET", "12.19.2.45", "2022-01-30", "Intel",
          "PCI\\VEN_8086&DEV_15BB&SUBSYS_229817AA&REV_10", "PCI\\VEN_8086&DEV_15BB&SUBSYS_229817AA&REV_10\\3&1&0&FE"),
        h("Realtek(R) Audio", "MEDIA", "6.0.9239.1", "2021-09-14", "Realtek Semiconductor Corp.",
          "HDAUDIO\\FUNC_01&VEN_10EC&DEV_0257&SUBSYS_17AA2298", "HDAUDIO\\FUNC_01&VEN_10EC&DEV_0257&SUBSYS_17AA2298\\4&1&0&0001"),
    ])
    etat = s.interpreter(d)
    assert c.identite(etat) == ("Lenovo", "20U9")
    offres = c.lire_lenovo_paquet(_lire("lenovo-n2wrw06w_2_.xml"), "https://download.lenovo.com/pccbbs/mobiles/n2wrw06w_2_.xml", "Networking LAN Ethernet")
    offres += c.lire_lenovo_paquet(_lire("lenovo-n2wa126w_2_.xml"), "https://download.lenovo.com/pccbbs/mobiles/n2wa126w_2_.xml", "Audio")
    cat = c.Catalogue("Lenovo", "20U9", 1_800_000_000, offres)
    maj = wu.interpreter({"pilotes": []}, lu=1_800_000_000)
    conseils = advisor.conseils_pilotes(etat, machine_factice(), AUJOURDHUI, maj=maj, nvidia={}, catalogue=cat)
    par_titre = {a.title: a for a in conseils}
    lan = par_titre["Pilote plus recent chez Lenovo : reseau"]
    assert "12.19.2.45" in lan.detail and "12.19.2.62" in lan.detail and "18/07/2024" in lan.detail
    assert lan.action == "Ouvrir la page du pilote" and lan.action_url == "https://download.lenovo.com/pccbbs/mobiles/n2wrw06w.html"
    assert "Fichier : https://download.lenovo.com/pccbbs/mobiles/n2wrw06w.exe" in lan.preuve
    assert "Pilote reseau ancien" not in par_titre                 # pas de doublon pour la meme puce
    audio = par_titre["Pilote plus recent chez Lenovo : audio"]
    assert "6.0.9590.1" in audio.detail and "Pilote audio ancien" not in par_titre
    # catalogue lu mais rien pour une puce ancienne : la phrase le dit, a la place de Windows Update
    cat_vide = c.Catalogue("Lenovo", "20U9", 1_800_000_000, [offres[0]])
    conseils = advisor.conseils_pilotes(etat, machine_factice(), AUJOURDHUI, maj=maj, nvidia={}, catalogue=cat_vide)
    par_titre = {a.title: a for a in conseils}
    assert "Le catalogue Lenovo de ce modele n'en propose pas de plus recent" in par_titre["Pilote audio ancien"].detail
    # catalogue d'un autre PC en cache : ignore par defaut (dernier() rend un Dell)
    autre = c.Catalogue("Dell", "0BEB", 1_800_000_000, offres)
    import orion.hardware.catalogues as mod
    mod._DERNIER = autre
    try:
        conseils = advisor.conseils_pilotes(etat, machine_factice(), AUJOURDHUI, maj=maj, nvidia={})
        assert not any("chez Dell" in a.title for a in conseils)
    finally:
        mod._DERNIER = None


@pytest.mark.parametrize("build,attendu", [("26100", "24H2"), ("22631", "23H2"), ("99999", "25H2")])
def test_release_hp_depuis_le_build(build, attendu):
    assert c.RELEASES.get(build, "25H2") == attendu
