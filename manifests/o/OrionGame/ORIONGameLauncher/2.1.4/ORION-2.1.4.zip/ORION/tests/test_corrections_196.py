"""Corrections de la 1.9.6 relevees pendant les captures du Store."""
from orion.core import recherche
from orion.optimizer import recommande as R
from orion.plugins.scanners.base import detect_engine


def test_cyberpunk_n_est_pas_unreal(tmp_path):
    # REDengine : dossiers « engine », « r6 » et « archive » a la racine
    for d in ("engine", "r6", "archive", "bin"):
        (tmp_path / d).mkdir()
    assert detect_engine(tmp_path) == "redengine"


def test_unreal_toujours_reconnu(tmp_path):
    (tmp_path / "Engine").mkdir()
    (tmp_path / "MonJeu" / "Content" / "Paks").mkdir(parents=True)
    assert detect_engine(tmp_path) == "unreal"


def test_ready_ne_trouve_plus_half_sword():
    assert recherche.correspond("ready", "Ready or Not")
    assert not recherche.correspond("ready", "Half Sword")
    # l'ecoute « a l'oreille » marche toujours
    assert recherche.correspond("rokett", "Rocket League")
    assert recherche.correspond("ciberpunk", "Cyberpunk 2077")
    assert recherche.correspond("wakfou", "Wakfu")


def _milieux(r):
    return [R._milieu(r.options.get(n)) for n in R.NIVEAUX]


def _reco(table, conseille, options, beau=""):
    r = R.Recommandation(cible=180)
    r.options = dict(options)
    r.niveau_conseille = conseille
    r.niveau_beau = beau or conseille
    return r


def test_un_niveau_plus_leger_n_affiche_pas_moins_d_images():
    # processeur qui plafonne a 120 : en Basse sans super-resolution le bas
    # de la fourchette est a 90, alors que Haute + super-resolution tient 120
    t = R.Table({"basse": (90.0, 140.0), "moyenne": (85.0, 130.0),
                 "haute": (72.0, 100.0), "ultra": (55.0, 77.0)},
                "estime", plafond_cpu=120.0)
    modes = ["off", "quality", "balanced", "performance"]
    options = {n: R._option(t, n, "off", 180) for n in R.NIVEAUX}
    options["haute"] = R._option(t, "haute", "performance", 120)
    r = _reco(t, "haute", options)
    avant = _milieux(r)
    assert avant[0] < avant[2]            # le defaut : Basse sous Haute
    R._ordonner(r, t, modes)
    m = _milieux(r)
    assert m[0] >= m[1] >= m[2] >= m[3], m
    assert r.options["haute"].mode == "performance"     # repere intact


def test_un_niveau_plus_lourd_n_affiche_pas_plus_d_images():
    t = R.Table({"basse": (150.0, 190.0), "moyenne": (110.0, 140.0),
                 "haute": (85.0, 110.0), "ultra": (65.0, 85.0)}, "estime")
    modes = ["off", "quality", "balanced", "performance"]
    options = {n: R._option(t, n, "off", 180) for n in R.NIVEAUX}
    options["ultra"] = R._option(t, "ultra", "performance", 180)   # 110 a 144
    r = _reco(t, "moyenne", options)
    R._ordonner(r, t, modes)
    m = _milieux(r)
    assert m[0] >= m[1] >= m[2] >= m[3], m
    assert r.options["moyenne"].mode == "off"


def test_table_incoherente_alignee_sur_le_niveau_voisin():
    # mesures bruitees : Basse mesuree plus lente que Moyenne
    t = R.Table({"basse": (40.0, 72.0), "moyenne": (60.0, 84.0),
                 "haute": (55.0, 76.0), "ultra": (50.0, 75.0)}, "mesure")
    options = {n: R._option(t, n, "off", 180) for n in R.NIVEAUX}
    r = _reco(t, "moyenne", options)
    R._ordonner(r, t, ["off"])
    m = _milieux(r)
    assert m[0] >= m[1] >= m[2] >= m[3], m


def test_recommandation_complete_reste_ordonnee():
    """Sur de vraies recommandations, le curseur ne remonte jamais."""
    import tests.test_reglages_recommande as T
    from orion.core.models import Game
    for tier, hz in ((0, 60), (1, 144), (2, 165), (2, 240), (3, 180)):
        for score in (15, 30, 45, 60):
            hw, ecran = T._hw(hz=hz, tier=tier)
            r = R.recommander(Game(title="Jeu", source="dossier"), hw, ecran,
                              ["upscaler"], runs={}, exig=T._exig(score), refresh=hz)
            m = [x for x in _milieux(r) if x is not None]
            pivot = R.NIVEAUX.index(r.niveau_conseille)
            leger = [x for x in _milieux(r)[:pivot + 1] if x is not None]
            assert leger == sorted(leger, reverse=True), (tier, hz, score, m)


def test_la_page_ne_saute_pas_quand_le_focus_change_tout_seul(qapp=None):
    """Un bouton qui disparait donne le focus au suivant : la page ne doit
    pas defiler jusqu'a lui (c'est ce qui ouvrait les fiches au milieu)."""
    import pytest
    QtW = pytest.importorskip("PySide6.QtWidgets")
    app = QtW.QApplication.instance() or QtW.QApplication([])
    from orion.ui.defilement import ZoneDefilante
    zone = ZoneDefilante()
    zone.setWidgetResizable(True)
    contenu = QtW.QWidget()
    pile = QtW.QVBoxLayout(contenu)
    haut = QtW.QPushButton("haut")
    pile.addWidget(haut)
    for i in range(60):
        pile.addWidget(QtW.QLabel(f"ligne {i}"))
    pile.addWidget(QtW.QPushButton("bas"))
    zone.setWidget(contenu)
    zone.resize(400, 300)
    zone.show()
    app.processEvents()
    zone.activateWindow()
    haut.setFocus()
    app.processEvents()
    haut.hide()
    app.processEvents()
    assert zone.verticalScrollBar().value() == 0
    zone.close()


def test_dossier_engine_seul_ne_designe_aucun_moteur(tmp_path):
    """La cause, pas le cas : un dossier banal ne suffit pas, quel que soit
    le jeu. Cyberpunk n'est qu'un exemple parmi d'autres."""
    (tmp_path / "engine" / "config").mkdir(parents=True)
    (tmp_path / "engine" / "tools").mkdir()
    (tmp_path / "bin" / "x64").mkdir(parents=True)
    assert detect_engine(tmp_path) == ""
    (tmp_path / "engine" / "Binaries" / "ThirdParty").mkdir(parents=True)
    assert detect_engine(tmp_path) == "unreal"


def test_boutons_standard_traduits_dans_toute_boite():
    """La cause, pas le cas : n'importe quelle boite, pas seulement la
    question Oui/Non, et sans ecraser un libelle choisi par ORION."""
    import pytest
    QtW = pytest.importorskip("PySide6.QtWidgets")
    app = QtW.QApplication.instance() or QtW.QApplication([])
    from orion.ui import boites
    B = QtW.QMessageBox.StandardButton
    boite = QtW.QMessageBox(QtW.QMessageBox.Icon.Question, "t", "q", B.Yes | B.No)
    assert boites.renommer(boite) == 2
    assert boite.button(B.Yes).text() == "Oui" and boite.button(B.No).text() == "Non"
    boite.deleteLater()

    # une boite quelconque, ecrite a la main, et une saisie de texte
    D = QtW.QDialogButtonBox.StandardButton
    dialogue = QtW.QDialog()
    barre = QtW.QDialogButtonBox(D.Save | D.Cancel | D.Ok, dialogue)
    barre.button(D.Ok).setText("Installer")            # libelle d'ORION
    assert boites.renommer(dialogue) == 2
    assert barre.button(D.Save).text() == "Enregistrer"
    assert barre.button(D.Cancel).text() == "Annuler"
    assert barre.button(D.Ok).text() == "Installer"
    dialogue.deleteLater()

    saisie = QtW.QInputDialog()
    saisie.show()                                       # le filtre de l'application
    filtre = boites.installer(app)
    saisie.hide(); saisie.show()
    app.processEvents()
    textes = {b.text() for b in saisie.findChildren(QtW.QAbstractButton)}
    assert "Annuler" in textes and "Cancel" not in textes
    saisie.close(); app.removeEventFilter(filtre)


def test_aucune_zone_defilante_brute_dans_l_interface():
    """Garde-fou : une page ecrite demain avec `QScrollArea()` retrouverait
    le saut de page (Qt y fait defiler vers le widget qui prend le focus)."""
    import re
    from pathlib import Path
    import orion.ui as ui
    racine = Path(ui.__file__).parent
    fautifs = [str(f.relative_to(racine)) for f in racine.rglob("*.py")
               if f.name != "defilement.py"
               and re.search(r"\bQScrollArea\(\s*\)|\bQScrollArea\(self|class \w+\([^)]*\bQScrollArea\b", f.read_text(encoding="utf-8"))]
    assert not fautifs, "utiliser ZoneDefilante : " + ", ".join(fautifs)


def test_images_par_seconde_une_seule_mise_en_forme():
    assert R.plage_fps((72, 99)) == "72 a 99"
    assert R.plage_fps((144, 144)) == "144"
    assert R.plage_fps((1035, 1423)) == "plus de 300"
    assert R.plage_fps((250, 400)) == "plus de 250"
    assert R.court_fps((80, 90)) == "~85" and R.court_fps((80, 90), "mesure") == "~90"
    assert R.court_fps((900, 1100)) == "300+"
    assert R.texte_fps((1035, 1423), 60) == "plus de 300 i/s (objectif 60)"
    assert R.texte_fps((72, 99), 60) == "environ 72 a 99 i/s (objectif 60)"
    # garde-fou : aucun ecran ne refait sa propre mise en forme
    import re
    from pathlib import Path
    import orion.ui as ui
    racine = Path(ui.__file__).parent
    fautifs = [f.name for f in racine.rglob("*.py")
               if re.search(r"fps\[0\] \+ .*fps\[1\]\) // 2", f.read_text(encoding="utf-8"))]
    assert not fautifs, fautifs


def test_alerte_recette_modifiee_une_seule_fois():
    from orion.optimizer import engine
    assert isinstance(engine._RECETTES_SIGNALEES, set)


def test_filtre_des_gratuits_tolere_les_fautes():
    from orion.core.recherche import correspond
    assert correspond("bounti", "Bounty Train")
    assert correspond("gta", "Grand Theft Auto V Enhanced")


def test_appel_differe_abandonne_si_le_proprietaire_disparait():
    """La cause de l'« erreur imprevue » a la fermeture d'une page : une
    minuterie sans proprietaire part meme si son widget n'existe plus."""
    import time
    import pytest
    QtW = pytest.importorskip("PySide6.QtWidgets")
    app = QtW.QApplication.instance() or QtW.QApplication([])
    from shiboken6 import delete
    from orion.ui.minuteur import plus_tard
    appels = []
    vivant, detruit = QtW.QWidget(), QtW.QWidget()
    plus_tard(vivant, 20, lambda: appels.append("vivant"))
    plus_tard(detruit, 20, lambda: appels.append("detruit"))
    delete(detruit)
    fin = time.time() + 1
    while time.time() < fin and not appels:
        app.processEvents()
        time.sleep(0.01)
    app.processEvents()
    assert appels == ["vivant"]
    vivant.deleteLater()


def test_aucune_minuterie_sans_proprietaire():
    import re
    from pathlib import Path
    import orion
    racine = Path(orion.__file__).parent
    fautifs = []
    for f in racine.rglob("*.py"):
        if f.name == "minuteur.py":
            continue
        for ligne in f.read_text(encoding="utf-8").splitlines():
            if re.search(r"\bsingleShot\(", ligne):
                fautifs.append(f.name)
    assert not fautifs, "utiliser ui.minuteur.plus_tard : " + ", ".join(sorted(set(fautifs)))


# -- trouve a l'ecran sur la 1.9.6 compilee --------------------------------
def test_libelle_traduit_ne_decide_pas_quand_l_identifiant_existe():
    """GOG en francais : l'etiquette d'identifiant « nsfw » s'affiche
    « Adulte ». POSTAL 2 (violent, pas pornographique) etait ecarte."""
    from orion.contenu_adulte import produit_adulte
    postal = {"tags": [{"name": "Mature", "slug": "mature"}, {"name": "Violent", "slug": "violent"},
                       {"name": "Gore", "slug": "gore"}, {"name": "Adulte", "slug": "nsfw"}]}
    roman = {"tags": [{"name": "Contenu à caractère sexuel", "slug": "sexual-content"},
                      {"name": "Nudité", "slug": "nudity"}, {"name": "Adulte", "slug": "nsfw"}]}
    assert not produit_adulte(postal)
    assert produit_adulte(roman)


def test_steam_les_descripteurs_font_foi_sur_les_etiquettes_des_joueurs():
    from orion.contenu_adulte import produit_adulte
    # classe par Steam, pas « reserve aux adultes » : les etiquettes ne contredisent pas
    assert not produit_adulte({"content_descriptorids": [1, 5], "tags": ["NSFW", "Nudité"]})
    assert produit_adulte({"content_descriptorids": [1, 3], "tags": ["RPG"]})
    assert produit_adulte({"content_descriptorids": [1], "tags": ["Hentai"]})
    # jamais classe : les etiquettes sont tout ce qu'on a
    assert produit_adulte({"tags": ["NSFW", "Contenu à caractère sexuel"]})
    assert not produit_adulte({"tags": ["NSFW", "Gore"]})


def test_recherche_steam_ne_classe_plus_tout_en_application(monkeypatch):
    """La recherche Steam repond « app » pour tout : POSTAL 2 etait masque
    comme une application."""
    from orion import boutique
    from orion.plugins.boutique import steam
    monkeypatch.setattr(steam, "fetch_json", lambda *a, **k: {"items": [
        {"id": 223470, "name": "POSTAL 2", "type": "app", "price": {"initial": 999, "final": 97}},
        {"id": 1986830, "name": "POSTAL 2 - Musique", "type": "app"}]})
    # (depuis la 2.0 c'est la recherche de secours : la premiere, limitee aux
    # jeux, donne leur nature d'office)
    offres = steam.SteamBoutique()._chercher_court("postal 2")
    assert [o.type_article for o in offres] == ["", ""]
    jeu, musique = (boutique.Fiche(o.titre, [o]) for o in offres)
    fiches = {"223470": {"jeu": True}, "1986830": {"jeu": False}}
    monkeypatch.setattr(boutique.MEMO, "get", lambda appid: fiches.get(str(appid), {}))
    assert not jeu.est_application and musique.est_application


def test_recherche_tolerante_sens_unique():
    assert recherche.correspond("conter strike", "Counter-Strike 2")
    assert not recherche.correspond("conter strike", "Stray")
    assert not recherche.correspond("conter strike", "Rust")
    assert recherche.correspond("bounti", "Bounty Train")
    assert recherche.correspond("cyberpnk", "Cyberpunk 2077")


def test_veille_rapide_rafraichit_le_moteur(tmp_path, base_neuve, monkeypatch):
    """Cyberpunk restait « unreal » apres la mise a jour : la veille rapide du
    demarrage ne touchait pas aux jeux deja connus."""
    from orion.core.models import Game
    from orion.library import LibraryService
    dossier = tmp_path / "Cyberpunk 2077"
    for d in ("engine/config", "r6", "archive/pc", "bin/x64"):
        (dossier / d).mkdir(parents=True)

    def jeu(moteur):
        return Game(title="Cyberpunk 2077", source="steam", source_id="1091500",
                    install_dir=str(dossier), engine=moteur)

    class Faux:
        id, label = "steam", "Steam"

        def scan(self):
            return [jeu(detect_engine(dossier))]

    service = LibraryService()
    service._scanners = [Faux()]
    ancien = jeu("unreal")                           # detection d'avant la 1.9.6
    service.store.games = {ancien.uid: ancien}
    monkeypatch.setattr(service, "_desinstallations", lambda *a, **k: (0, 0))
    service.scan(quick=True)
    assert service.store.games[ancien.uid].engine == "redengine"


def test_tache_interrompue_par_la_fermeture_n_est_pas_une_erreur(monkeypatch):
    """Une tache qui echoue parce qu'ORION se ferme sous elle (pool de fils
    arrete) est un abandon : ni erreur au journal, ni signal d'echec. Et
    aucune tache n'est lancee une fois la fermeture commencee."""
    from PySide6.QtWidgets import QApplication
    from orion.core import tasks
    app = QApplication.instance() or QApplication([])

    def casse():
        raise RuntimeError("cannot schedule new futures after shutdown")

    echecs, notes = [], []
    monkeypatch.setattr(tasks.log, "exception", lambda *a, **k: notes.append(a))
    t = tasks.Task(casse)
    t.signals.failed.connect(echecs.append)
    monkeypatch.setattr(tasks, "_fermeture", True)
    t.run()
    app.processEvents()
    assert not echecs and not notes
    avant = len(tasks._ACTIVE)
    tasks.Task(casse).start()
    assert len(tasks._ACTIVE) == avant
    # hors fermeture, la meme panne reste une erreur
    monkeypatch.setattr(tasks, "_fermeture", False)
    t2 = tasks.Task(casse)
    t2.signals.failed.connect(echecs.append)
    t2.run()
    app.processEvents()
    assert echecs and notes
