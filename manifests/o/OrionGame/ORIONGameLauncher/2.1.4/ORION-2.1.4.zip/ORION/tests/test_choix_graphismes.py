"""Le choix des graphismes (2.1.0) : « Votre ecran » (le plus beau reglage
qui tient la frequence de l'ecran) et « Mon choix » (niveau et images par
seconde choisis par le joueur) ; un clic ecrit ; « Redefinir les parametres
par defaut » remet la premiere sauvegarde."""
from __future__ import annotations

import pytest

from orion.core.models import Game
from test_reglages_recommande import _exig, _hw, _jeu_unreal


def _choix(tier=2, exig=30, hz=165, feats=("dlss", "rt", "reflex"), runs=None,
           capacites=("upscaler",), jeu=None):
    from orion.optimizer import choix
    hw, ecran = _hw(hz=hz, tier=tier, feats=feats)
    return choix.les_choix(jeu or Game(title="Jeu", source="dossier"), hw, ecran, list(capacites),
                           runs=runs or {}, exig=_exig(exig) if exig else None, refresh=hz)


def _mon_choix(niveau, cible, tier=2, exig=30, hz=165, feats=("dlss", "rt", "reflex"), jeu=None):
    from orion.optimizer import choix
    hw, ecran = _hw(hz=hz, tier=tier, feats=feats)
    return choix.pour_choix(jeu or Game(title="Jeu", source="dossier"), hw, ecran, niveau, cible,
                            ["upscaler"], runs={}, exig=_exig(exig) if exig else None, refresh=hz)


def test_la_carte_ecran_vise_la_frequence_de_l_ecran():
    ecran, _choix_joueur = _choix()
    assert ecran.id == "ecran" and ecran.cible == 165
    assert ecran.titre == "Votre ecran · 165 i/s"
    # 165 i/s hors de portee de ce PC : le plus haut palier tenu, en Basse
    assert not ecran.atteint and ecran.palier and ecran.niveau == "basse"
    assert ecran.tenue.startswith("jusqu'a")
    assert ecran.origine == "d'apres la configuration recommandee du jeu"
    d = ecran.to_dict()
    assert d["nom"] == "Votre ecran" and d["fps_court"].startswith("~") and d["reglage"]
    # ecran 60 Hz tenu : la carte le dit
    ecran, _c = _choix(tier=0, exig=38, hz=60, feats=())
    assert ecran.atteint and ecran.tenue == "tient 60 i/s"


def test_mon_choix_montre_ce_que_donne_le_niveau_choisi():
    from orion.optimizer.recommande import QUALITE
    # par defaut : Ultra a la frequence de l'ecran, images par seconde attendues
    ecran, joueur = _choix()
    assert joueur.id == "choix" and joueur.niveau == "ultra" and joueur.cible == 165
    assert joueur.titre == "Mon choix · Ultra · 165 i/s" and joueur.fps
    assert not joueur.atteint and joueur.tenue.startswith("jusqu'a")
    assert QUALITE[joueur.niveau] > QUALITE[ecran.niveau]
    # Haute a 60 : tenu, avec la super-resolution qui suffit
    c = _mon_choix("haute", 60)
    assert c.niveau == "haute" and c.cible == 60 and c.atteint and c.palier >= 60
    # un niveau plus leger au meme objectif ne donne jamais moins d'images
    m = lambda x: (x.fps[0] + x.fps[1]) / 2   # noqa: E731
    assert m(_mon_choix("basse", 60)) >= m(c)
    # au-dessus de l'ecran : ramene a la frequence de l'ecran ; niveau inconnu : Ultra
    c = _mon_choix("n'importe", 300)
    assert c.niveau == "ultra" and c.cible == 165
    # le meme reglage que « Votre ecran » : la carte le dit
    jeu = Game(title="Jeu", source="dossier")
    ecran, _c = _choix(jeu=jeu)
    from orion.optimizer import choix
    choix.choisir(jeu, ecran.niveau, 0)
    _e, joueur = _choix(jeu=jeu)
    assert joueur.identique == "ecran"


def test_ultra_seulement_quand_les_images_le_permettent():
    # par estimation, Ultra n'est autorise que si la fiche du jeu le permet
    ecran, _c = _choix(tier=3, exig=20, hz=144, feats=("dlss",))
    assert ecran.niveau != "ultra"
    # apres une mesure reelle, Ultra sans condition
    runs = {"recommande": {"preset": "haute", "fps_avg": 150, "fps_low_1": 110, "at": 1.0, "upscaler_mode": "off"}}
    ecran, _c = _choix(exig=None, runs=runs, hz=60)
    assert ecran.niveau == "ultra" and ecran.source == "mesure"
    assert ecran.origine == "d'apres vos parties mesurees"


def test_les_objectifs_proposes_suivent_l_ecran():
    from orion.optimizer.choix import objectifs
    assert objectifs(165) == [165, 144, 120, 100, 90, 75, 60, 45, 30]
    assert objectifs(60) == [60, 45, 30]
    assert objectifs(0)[0] == 60


def test_le_choix_est_memorise_par_jeu_et_relu_par_le_moteur():
    from orion.optimizer import choix
    from orion.optimizer.recommande import cible_fps, niveau_choisi
    jeu = Game(title="Jeu", source="dossier")
    assert choix.choix_du_jeu(jeu) == "ecran" and choix.choix_memorise(jeu) == ("ultra", 0)
    choix.choisir(jeu, "haute", 120)
    assert choix.choix_du_jeu(jeu) == "choix" and choix.choix_memorise(jeu) == ("haute", 120)
    assert cible_fps(jeu, 165) == 120                 # le moteur vise l'objectif du joueur
    assert cible_fps(jeu, 100) == 100                 # jamais plus que l'ecran
    assert niveau_choisi(jeu) == "haute"              # et impose le niveau
    # la carte « Votre ecran » ignore le choix memorise, la seconde carte le reprend
    ecran, joueur = _choix(jeu=jeu)
    assert ecran.cible == 165 and (joueur.niveau, joueur.cible) == ("haute", 120)
    choix.choisir(jeu, "", 0)
    assert choix.choix_du_jeu(jeu) == "ecran" and "cible_fps" not in jeu.extra and niveau_choisi(jeu) == ""
    choix.choisir(jeu, "ultra", 0)                    # Ultra a la frequence de l'ecran
    assert choix.choix_du_jeu(jeu) == "choix" and choix.choix_memorise(jeu) == ("ultra", 0)
    choix.oublier(jeu)
    assert "cible_fps" not in jeu.extra and niveau_choisi(jeu) == ""


def test_anciens_profils_retombent_sur_le_profil_unique():
    from orion.optimizer.profiles import ORDER, PROFILES, profil_valide
    assert ORDER == ["recommande"] and set(PROFILES) == {"recommande"}
    for ancien in ("esport", "detente", "photo", "", None):
        assert profil_valide(ancien) == "recommande"


@pytest.fixture
def app():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


def test_le_bloc_de_la_fiche_montre_les_deux_cartes(app):
    from orion.optimizer import choix
    from orion.ui.widgets.profile_card import ChoixGraphismes
    hw, ecran = _hw(hz=165)
    jeu = Game(title="Jeu", source="dossier")
    bloc = ChoixGraphismes()
    recus = []
    bloc.choix_fait.connect(lambda n, c: recus.append((n, c)))
    bloc.apercu_demande.connect(lambda n, c: recus.append(("apercu", n, c)))
    bloc.set_donnees({"choix": choix.les_choix(jeu, hw, ecran, ["upscaler"], runs={}, refresh=165),
                      "choix_id": "ecran", "niveau": "ultra", "cible": 0,
                      "objectifs": choix.objectifs(165)})
    assert bloc.choix_id == "ecran" and bloc.cartes["ecran"].marque.isVisibleTo(bloc)
    # « Mon choix » par defaut : Ultra a la frequence de l'ecran
    assert (bloc.niveau(), bloc.cible()) == ("ultra", 165)
    assert "165" in bloc.cartes["choix"].objectif.text()
    carte = bloc.cartes["choix"]
    carte.selecteur.setCurrentIndex(carte.selecteur.findData(120))
    assert recus[-1] == ("apercu", "ultra", 120)
    carte.niveaux.setCurrentIndex(carte.niveaux.findData("haute"))
    assert recus[-1] == ("apercu", "haute", 120)
    bloc.set_apercu(choix.pour_choix(jeu, hw, ecran, "haute", 120, ["upscaler"], runs={}, refresh=165))
    assert "120" in carte.objectif.text()
    carte.selected.emit("choix")
    assert recus[-1] == ("haute", 120) and bloc.choix_id == "choix"
    bloc.cartes["ecran"].selected.emit("ecran")
    assert recus[-1] == ("", 0) and bloc.choix_id == "ecran"
    # choix memorise : repris par les selecteurs et la carte
    choix.choisir(jeu, "moyenne", 90)
    bloc.set_donnees({"choix": choix.les_choix(jeu, hw, ecran, ["upscaler"], runs={}, refresh=165),
                      "choix_id": "choix", "niveau": "moyenne", "cible": 90,
                      "objectifs": choix.objectifs(165)})
    assert (bloc.niveau(), bloc.cible()) == ("moyenne", 90) and bloc.choix_id == "choix"


def test_un_clic_ecrit_tout_de_suite_et_le_bouton_par_defaut_remet_l_origine(app, tmp_path, monkeypatch):
    """Le clic sur une carte ecrit sans fenetre de confirmation ; « Redefinir
    les parametres par defaut » remet la PREMIERE sauvegarde."""
    from PySide6.QtWidgets import QMessageBox
    from orion.core import paths
    from orion.optimizer import backup, choix
    from orion.optimizer.engine import Optimizer
    from orion.plugins.tweaks.ini_writer import lire_valeur
    monkeypatch.setattr(paths, "BACKUP_DIR", tmp_path / "backups", raising=False)
    monkeypatch.setattr(backup, "BACKUP_DIR", tmp_path / "backups", raising=False)
    jeu, fichier = _jeu_unreal(tmp_path, monkeypatch,
                               "[/Script/Engine.GameUserSettings]\nFrameRateLimit=0.000000\n"
                               "[ScalabilityGroups]\nsg.ShadowQuality=3\nsg.TextureQuality=3\n")
    hw, ecran = _hw()
    moteur = Optimizer()
    origine = fichier.read_text("utf-8")
    # le moteur lit la fiche du jeu dans le cache des configurations
    from orion.puissance import exigences
    jeu.extra["steam_appid"] = "424242"
    monkeypatch.setattr(exigences, "en_cache", lambda appid: _exig(30))
    # 1. « Votre ecran » (165 i/s, hors de portee : Basse) : ecrit
    carte, _c = choix.les_choix(jeu, hw, ecran, ["upscaler"], runs={}, refresh=165)
    assert carte.niveau == "basse"
    choix.choisir(jeu, "", 0)
    plan = moteur.build_plan(jeu, "recommande", hw, ecran)
    assert plan.tunable
    ok, msg = moteur.apply_plan(jeu, plan)
    assert ok, msg
    assert lire_valeur(fichier.read_text("utf-8"), "ScalabilityGroups", "sg.ShadowQuality") in ("0", "1")
    premiere = backup.list_backups(jeu)
    assert premiere, "une sauvegarde est faite avant la premiere ecriture"
    # 2. « Mon choix » Haute a 60 i/s : une seconde ecriture, une seconde sauvegarde,
    #    et la limite d'images du jeu posee sur 60
    choix.choisir(jeu, "haute", 60)
    plan = moteur.build_plan(jeu, "recommande", hw, ecran)
    ok, msg = moteur.apply_plan(jeu, plan)
    assert ok, msg
    texte = fichier.read_text("utf-8")
    assert lire_valeur(texte, "ScalabilityGroups", "sg.ShadowQuality") == "2"
    assert lire_valeur(texte, "/Script/Engine.GameUserSettings", "FrameRateLimit").startswith("60")
    assert len(backup.list_backups(jeu)) == 2
    # 3. par defaut : la plus ancienne sauvegarde (= l'etat d'origine) revient
    slots = backup.list_backups(jeu)
    ok, msg = backup.restore(slots[-1]["path"])
    assert ok, msg
    assert fichier.read_text("utf-8") == origine
    choix.oublier(jeu)
    assert choix.choix_du_jeu(jeu) == "ecran"
    # la fenetre pose la question avant (QMessageBox.question) : verifie par
    # lecture du code, le dialogue ne se teste pas hors ecran
    import inspect
    from orion.ui.main_window import MainWindow
    src = inspect.getsource(MainWindow._defaut_graphismes)
    assert "QMessageBox.question" in src and "slots[-1]" in src
    src2 = inspect.getsource(MainWindow._plan_choisi_pret)
    assert "_confirm_changes" not in src2 and "_ecrire_plan" in src2
    assert QMessageBox is not None


def test_case_dlss_sur_les_deux_cartes_avec_le_gain():
    """10 octobre : « une coche » DLSS sur les deux cartes, et le gain d'images
    par seconde affiche tout de suite. Cochee : toujours active ; decochee :
    jamais ; sans y toucher : seulement s'il en faut."""
    from orion.optimizer import choix
    jeu = Game(title="Jeu", source="dossier")
    for c in _choix(jeu=jeu):
        assert c.sr_dispo and c.nom_sr == "DLSS"
        avec, sans = c.variantes["avec"], c.variantes["sans"]
        assert avec["sr"] is True and sans["sr"] is False
        assert c.gain >= 0 and avec["gain"] == sans["gain"] == c.gain
    # decochee sur « Mon choix » : jamais de DLSS ; cochee : toujours
    choix.choisir_sr(jeu, "choix", False)
    assert _mon_choix("ultra", 60, jeu=jeu).sr is False
    choix.choisir_sr(jeu, "choix", True)
    c = _mon_choix("ultra", 60, jeu=jeu)
    assert c.sr is True and c.mode in ("quality", "balanced", "performance")
    # la case de « Votre ecran » est a part
    assert jeu.extra["sr"] == {"choix": True}
    choix.oublier(jeu)
    assert "sr" not in jeu.extra


def test_sans_super_resolution_pas_de_case():
    from orion.optimizer import choix
    from test_reglages_recommande import _hw
    hw, ecran = _hw(hz=165, tier=2, feats=("dlss",))
    c = choix.pour_choix(Game(title="Jeu", source="dossier"), hw, ecran, "ultra", 60, [], runs={},
                         exig=None, refresh=165)
    assert c.sr_dispo is False and not c.variantes        # la recette ne sait pas l'ecrire


def test_la_carte_bascule_au_clic_et_previent(qapp=None):
    import os
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    from PySide6.QtWidgets import QApplication
    app = QApplication.instance() or QApplication([])
    from orion.ui.widgets.profile_card import CarteChoix
    c = _mon_choix("ultra", 165)
    carte = CarteChoix("choix")
    vus = []
    carte.sr_demande.connect(lambda cid, coche: vus.append((cid, coche)))
    carte.set_choix(c, conseille=False)
    avant = carte.fps.text()
    carte.case_sr.setChecked(not carte.case_sr.isChecked())
    assert vus == [("choix", carte.case_sr.isChecked())]
    autre = c.variantes["avec" if carte.case_sr.isChecked() else "sans"]
    assert (autre["fps_court"] in carte.fps.text()) and ("i/s" in carte.gain_sr.text() or "images" in carte.gain_sr.text())
    assert app is not None and avant


def test_reglage_utilise_seulement_si_orion_ecrit(app):
    """15 octobre (Rocket League, qui gere ses reglages lui-meme) : la carte
    choisie disait « Reglage utilise » alors qu'ORION n'ecrit rien."""
    from orion.ui.widgets.profile_card import ChoixGraphismes
    bloc = ChoixGraphismes()
    bloc.show()
    bloc.set_selected("ecran")
    assert not bloc.cartes["ecran"].en_place.isHidden()
    bloc.set_pris_en_charge(False, None)
    assert bloc.cartes["ecran"].en_place.isHidden()
    bloc.set_selected("choix")                       # un clic ne la fait pas revenir
    assert bloc.cartes["choix"].en_place.isHidden() and bloc.cartes["ecran"].en_place.isHidden()
    bloc.set_pris_en_charge(True, None)
    assert not bloc.cartes["choix"].en_place.isHidden() and bloc.cartes["ecran"].en_place.isHidden()
