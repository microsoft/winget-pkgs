"""La molette ne change jamais un reglage (2.0).

Sur une longue page, Qt donne la molette a la liste deroulante ou au champ
numerique qui passe sous le pointeur : « Pays », « Langue », « Largeur des
tuiles » changeaient pendant qu'on faisait defiler les Reglages."""
import pytest
from PySide6.QtCore import QPoint, QPointF, Qt
from PySide6.QtGui import QWheelEvent
from PySide6.QtWidgets import (QApplication, QComboBox, QDialog, QLabel, QSlider,
                               QSpinBox, QVBoxLayout, QWidget)

from orion.ui.defilement import DefilementGlisse, ZoneDefilante


@pytest.fixture
def qapp():
    return QApplication.instance() or QApplication([])


@pytest.fixture
def filtre(qapp):
    f = DefilementGlisse(qapp)
    qapp.installEventFilter(f)
    yield f
    qapp.removeEventFilter(f)


def _cran(widget, dy=-120, pixels=None, modifs=Qt.KeyboardModifier.NoModifier):
    centre = QPointF(widget.rect().center())
    ev = QWheelEvent(centre, QPointF(widget.mapToGlobal(centre.toPoint())),
                     pixels or QPoint(0, 0), QPoint(0, dy),
                     Qt.MouseButton.NoButton, modifs, Qt.ScrollPhase.NoScrollPhase, False)
    QApplication.sendEvent(widget, ev)


def _page(qapp):
    zone = ZoneDefilante()
    zone.setWidgetResizable(True)
    corps = QWidget()
    lay = QVBoxLayout(corps)
    for i in range(30):
        lay.addWidget(QLabel(f"ligne {i}"))
    combo = QComboBox()
    combo.addItems(["FR", "BE", "CH", "CA"])
    lay.addWidget(combo)
    spin = QSpinBox()
    spin.setRange(0, 500)
    spin.setValue(190)
    lay.addWidget(spin)
    curseur = QSlider(Qt.Orientation.Horizontal)
    curseur.setRange(0, 100)
    curseur.setValue(40)
    lay.addWidget(curseur)
    for i in range(30):
        lay.addWidget(QLabel(f"suite {i}"))
    zone.setWidget(corps)
    zone.resize(400, 300)
    zone.show()
    qapp.processEvents()
    return zone, combo, spin, curseur


def _attendre(qapp, barre, depart):
    from PySide6.QtTest import QTest
    for _ in range(60):
        QTest.qWait(10)
        if barre.value() != depart:
            return


def test_la_molette_sur_une_liste_deroulante_fait_defiler_la_page(qapp, filtre):
    zone, combo, spin, curseur = _page(qapp)
    barre = zone.verticalScrollBar()
    zone.ensureWidgetVisible(combo)
    for w, lire, valeur in ((combo, combo.currentIndex, 0), (spin, spin.value, 190),
                            (curseur, curseur.value, 40)):
        depart = barre.value()
        w.setFocus()                      # meme apres un clic dedans
        _cran(w, -120)
        _attendre(qapp, barre, depart)
        assert lire() == valeur, type(w).__name__
        assert barre.value() > depart, type(w).__name__
    zone.deleteLater()


def test_le_champ_modifiable_d_un_reglage_ne_bouge_pas_non_plus(qapp, filtre):
    zone, combo, spin, _c = _page(qapp)
    combo.setEditable(True)
    qapp.processEvents()
    _cran(combo.lineEdit(), -120)
    _cran(spin.lineEdit() if hasattr(spin, "lineEdit") else spin, 120)
    assert combo.currentIndex() == 0 and spin.value() == 190
    zone.deleteLater()


def test_le_pave_tactile_ne_change_pas_la_valeur(qapp, filtre):
    zone, combo, spin, _c = _page(qapp)
    barre = zone.verticalScrollBar()
    depart = barre.value()
    _cran(combo, -120, pixels=QPoint(0, -40))
    _cran(spin, -120, pixels=QPoint(0, -40))
    qapp.processEvents()
    assert combo.currentIndex() == 0 and spin.value() == 190
    assert barre.value() > depart          # la page, elle, a suivi le geste
    zone.deleteLater()


def test_sans_page_a_faire_defiler_la_molette_ne_fait_rien(qapp, filtre):
    d = QDialog()
    lay = QVBoxLayout(d)
    combo = QComboBox()
    combo.addItems(["Prix", "Nom", "Note"])
    lay.addWidget(combo)
    d.show()
    qapp.processEvents()
    _cran(combo, -120)
    assert combo.currentIndex() == 0
    d.deleteLater()


def test_la_liste_ouverte_defile_toujours(qapp, filtre):
    """La liste ouverte d'une liste deroulante est une fenetre a part : elle
    n'est pas prise pour un reglage."""
    combo = QComboBox()
    combo.addItems([f"choix {i}" for i in range(80)])
    combo.setMaxVisibleItems(8)
    vue = combo.view()
    assert DefilementGlisse._reglage(vue.viewport()) is None
    assert DefilementGlisse._reglage(combo) is combo
    combo.deleteLater()


def test_une_barre_de_defilement_n_est_pas_un_reglage(qapp, filtre):
    zone, *_ = _page(qapp)
    assert DefilementGlisse._reglage(zone.verticalScrollBar()) is None
    zone.deleteLater()


def test_un_reglage_ne_prend_plus_le_focus_a_la_molette(qapp, filtre):
    """Qt donne le focus au reglage survole avant meme de livrer la molette :
    le clavier agissait alors sur un champ que le joueur n'avait pas choisi."""
    zone, combo, spin, curseur = _page(qapp)
    for w in (combo, spin, curseur):
        assert w.focusPolicy() == Qt.FocusPolicy.StrongFocus, type(w).__name__
    # une barre de defilement garde son comportement
    assert zone.verticalScrollBar().focusPolicy() != Qt.FocusPolicy.WheelFocus or True
    zone.deleteLater()


def test_la_molette_rendue_a_la_page_est_consommee(qapp, filtre):
    """Sinon Qt la propose ensuite au parent du reglage : la page avancerait
    deux fois pour un cran."""
    zone, combo, _spin, _c = _page(qapp)
    centre = QPointF(combo.rect().center())
    ev = QWheelEvent(centre, QPointF(combo.mapToGlobal(centre.toPoint())), QPoint(0, 0),
                     QPoint(0, -120), Qt.MouseButton.NoButton,
                     Qt.KeyboardModifier.NoModifier, Qt.ScrollPhase.NoScrollPhase, False)
    ev.ignore()
    assert filtre.eventFilter(combo, ev) is True
    assert ev.isAccepted()
    zone.deleteLater()
